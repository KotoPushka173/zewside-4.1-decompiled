package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockStem extends BlockBush implements IGrowable {
   // $FF: synthetic field
   private final Block crop;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] STEM_AABB;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   public static final PropertyInteger AGE;
   // $FF: synthetic field
   private static final String[] I;

   protected BlockStem(Block var1) {
      this.setDefaultState(this.blockState.getBaseState().withProperty(AGE, "".length()).withProperty(FACING, EnumFacing.UP));
      this.crop = var1;
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab((CreativeTabs)null);
   }

   public void growStem(World var1, BlockPos var2, IBlockState var3) {
      int var4 = (Integer)var3.getValue(AGE) + MathHelper.getInt(var1.rand, "  ".length(), 123 ^ 126);
      var1.setBlockState(var2, var3.withProperty(AGE, Math.min(160 ^ 167, var4)), "  ".length());
      I[71 ^ 65].length();
      I[179 ^ 180].length();
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return STEM_AABB[(Integer)var1.getValue(AGE)];
   }

   public boolean canGrow(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      int var10000;
      if ((Integer)var3.getValue(AGE) != (152 ^ 159)) {
         var10000 = " ".length();
         "".length();
         if (2 <= -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public void grow(World var1, Random var2, BlockPos var3, IBlockState var4) {
      this.growStem(var1, var3, var4);
   }

   @Nullable
   protected Item getSeedItem() {
      if (this.crop == Blocks.PUMPKIN) {
         return Items.PUMPKIN_SEEDS;
      } else {
         Item var10000;
         if (this.crop == Blocks.MELON_BLOCK) {
            var10000 = Items.MELON_SEEDS;
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10000 = null;
         }

         return var10000;
      }
   }

   protected boolean canSustainBush(IBlockState var1) {
      int var10000;
      if (var1.getBlock() == Blocks.FARMLAND) {
         var10000 = " ".length();
         "".length();
         if (0 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   static {
      I();
      AGE = PropertyInteger.create(I[66 ^ 105], "".length(), 39 ^ 32);
      FACING = BlockTorch.FACING;
      AxisAlignedBB[] var10000 = new AxisAlignedBB[45 ^ 37];
      var10000["".length()] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 0.125D, 0.625D);
      var10000[" ".length()] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 0.25D, 0.625D);
      var10000["  ".length()] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 0.375D, 0.625D);
      var10000["   ".length()] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 0.5D, 0.625D);
      var10000[5 ^ 1] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 0.625D, 0.625D);
      var10000[152 ^ 157] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 0.75D, 0.625D);
      var10000[52 ^ 50] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 0.875D, 0.625D);
      var10000[156 ^ 155] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 1.0D, 0.625D);
      STEM_AABB = var10000;
   }

   public boolean canUseBonemeal(World var1, Random var2, BlockPos var3, IBlockState var4) {
      return (boolean)" ".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      super.updateTick(var1, var2, var3, var4);
      if (var1.getLightFromNeighbors(var2.up()) >= (76 ^ 69)) {
         float var5 = BlockCrops.getGrowthChance(this, var1, var2);
         if (var4.nextInt((int)(25.0F / var5) + " ".length()) == 0) {
            int var6 = (Integer)var3.getValue(AGE);
            if (var6 < (69 ^ 66)) {
               var3 = var3.withProperty(AGE, var6 + " ".length());
               var1.setBlockState(var2, var3, "  ".length());
               I["".length()].length();
               I[" ".length()].length();
               "".length();
               if (3 <= 1) {
                  throw null;
               }
            } else {
               Iterator var7 = EnumFacing.Plane.HORIZONTAL.iterator();

               while(var7.hasNext()) {
                  EnumFacing var8 = (EnumFacing)var7.next();
                  if (var1.getBlockState(var2.offset(var8)).getBlock() == this.crop) {
                     return;
                  }

                  "".length();
                  if (2 != 2) {
                     throw null;
                  }
               }

               var2 = var2.offset(EnumFacing.Plane.HORIZONTAL.random(var4));
               Block var9 = var1.getBlockState(var2.down()).getBlock();
               if (var1.getBlockState(var2).getBlock().blockMaterial == Material.AIR && (var9 == Blocks.FARMLAND || var9 == Blocks.DIRT || var9 == Blocks.GRASS)) {
                  var1.setBlockState(var2, this.crop.getDefaultState());
                  I["  ".length()].length();
                  I["   ".length()].length();
                  I[56 ^ 60].length();
                  I[111 ^ 106].length();
               }
            }
         }
      }

   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(AGE, var1);
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(AGE);
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[68 ^ 75];
      String var10001 = I[46 ^ 62];
      String var10002 = I[54 ^ 39];
      var10001 = I[186 ^ 168];
      Item var4 = this.getSeedItem();
      ItemStack var5;
      if (var4 == null) {
         var5 = ItemStack.field_190927_a;
         "".length();
         if (3 < 3) {
            throw null;
         }
      } else {
         I[62 ^ 45].length();
         I[108 ^ 120].length();
         I[176 ^ 165].length();
         var5 = new ItemStack(var4);
      }

      return var5;
   }

   private static void I() {
      I = new String[161 ^ 141];
      I["".length()] = I("惾哾朁垲摪", "VTmWh");
      I[" ".length()] = I("檓", "vpSCF");
      I["  ".length()] = I("懻滒掼", "zpqbj");
      I["   ".length()] = I("兝洿克勨", "dOhFR");
      I[181 ^ 177] = I("煥俇堭", "oDQhU");
      I[180 ^ 177] = I("廐灟塮", "QEavD");
      I[19 ^ 21] = I("姙", "pFoeS");
      I[29 ^ 26] = I("檝斢姑宁", "dpZSW");
      I[14 ^ 6] = I("烊渪", "SGcql");
      I[55 ^ 62] = I("唊柏", "faAhZ");
      I[113 ^ 123] = I("妞檆", "ocMpg");
      I[32 ^ 43] = I("沎壑", "OFxWR");
      I[75 ^ 71] = I("哷扻瀲摩", "gGCkx");
      I[58 ^ 55] = I("佛", "LGRvR");
      I[73 ^ 71] = I("依", "duNTv");
      I[168 ^ 167] = I("棣剌", "GANyc");
      I[25 ^ 9] = I("煸屚", "sWSKt");
      I[47 ^ 62] = I("冁崋", "HfViH");
      I[147 ^ 129] = I("澩慽", "Pddcb");
      I[49 ^ 34] = I("屾挎", "FvsCu");
      I[103 ^ 115] = I("扣", "LCFWu");
      I[171 ^ 190] = I("昏攳", "nDfJK");
      I[126 ^ 104] = I("樹嗣", "hoeYL");
      I[149 ^ 130] = I("刉樳", "IaoFK");
      I[184 ^ 160] = I("娭澅", "IPcyg");
      I[51 ^ 42] = I("岅弪", "UBijA");
      I[110 ^ 116] = I("捱氕", "oRKsf");
      I[26 ^ 1] = I("斗欪", "lyIqT");
      I[125 ^ 97] = I("僠呠", "NdPFw");
      I[55 ^ 42] = I("椈煰", "GWYLt");
      I[113 ^ 111] = I("嘕柉", "vsfRF");
      I[222 ^ 193] = I("櫅寖", "uHfLJ");
      I[32 ^ 0] = I("気測", "QuSgu");
      I[107 ^ 74] = I("均卭", "AyzUo");
      I[80 ^ 114] = I("煂咴佦", "WtRaS");
      I[178 ^ 145] = I("擕枘灐掛榦", "fOikE");
      I[68 ^ 96] = I("涣慰漪焌", "cxQMW");
      I[28 ^ 57] = I("州涯淄", "tlagj");
      I[173 ^ 139] = I("寓", "ReisR");
      I[20 ^ 51] = I("僔", "dgVem");
      I[168 ^ 128] = I("幝娪樽嵿捝", "kcslr");
      I[18 ^ 59] = I("懘傍槿", "RIteO");
      I[233 ^ 195] = I("僀", "dyFIg");
      I[164 ^ 143] = I(".1\u0000", "OVeiv");
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      String var10000 = I[186 ^ 178];
      String var10001 = I[28 ^ 21];
      String var10002 = I[66 ^ 72];
      var10001 = I[191 ^ 180];
      super.dropBlockAsItemWithChance(var1, var2, var3, var4, var5);
      if (!var1.isRemote) {
         Item var6 = this.getSeedItem();
         if (var6 != null) {
            int var7 = (Integer)var3.getValue(AGE);
            int var8 = "".length();

            while(var8 < "   ".length()) {
               if (var1.rand.nextInt(95 ^ 80) <= var7) {
                  I[153 ^ 149].length();
                  I[202 ^ 199].length();
                  I[13 ^ 3].length();
                  spawnAsEntity(var1, var2, new ItemStack(var6));
               }

               ++var8;
               "".length();
               if (2 >= 3) {
                  throw null;
               }
            }
         }
      }

   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[182 ^ 160];
      String var10001 = I[62 ^ 41];
      String var10002 = I[188 ^ 164];
      var10001 = I[62 ^ 39];
      var10000 = I[24 ^ 2];
      var10001 = I[190 ^ 165];
      var10002 = I[64 ^ 92];
      var10001 = I[76 ^ 81];
      var10000 = I[164 ^ 186];
      var10001 = I[95 ^ 64];
      var10002 = I[19 ^ 51];
      var10001 = I[84 ^ 117];
      I[113 ^ 83].length();
      I[172 ^ 143].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[186 ^ 158].length();
      I[90 ^ 127].length();
      I[178 ^ 148].length();
      var10003["".length()] = AGE;
      I[18 ^ 53].length();
      I[45 ^ 5].length();
      I[119 ^ 94].length();
      I[131 ^ 169].length();
      var10003[" ".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      int var4 = (Integer)var1.getValue(AGE);
      var1 = var1.withProperty(FACING, EnumFacing.UP);
      Iterator var5 = EnumFacing.Plane.HORIZONTAL.iterator();

      while(var5.hasNext()) {
         EnumFacing var6 = (EnumFacing)var5.next();
         if (var2.getBlockState(var3.offset(var6)).getBlock() == this.crop && var4 == (38 ^ 33)) {
            var1 = var1.withProperty(FACING, var6);
            "".length();
            if (2 <= 1) {
               throw null;
            }
            break;
         }

         "".length();
         if (0 >= 1) {
            throw null;
         }
      }

      return var1;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.field_190931_a;
   }
}

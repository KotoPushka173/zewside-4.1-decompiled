package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;

public class UsedEnderEyeTrigger implements ICriterionTrigger<UsedEnderEyeTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_192242_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, UsedEnderEyeTrigger.Listeners> field_192243_b = Maps.newHashMap();

   public ResourceLocation func_192163_a() {
      return field_192242_a;
   }

   public void func_192239_a(EntityPlayerMP var1, BlockPos var2) {
      UsedEnderEyeTrigger.Listeners var3 = (UsedEnderEyeTrigger.Listeners)this.field_192243_b.get(var1.func_192039_O());
      if (var3 != null) {
         double var10000 = var1.posX;
         double var10001 = (double)var2.getX();
         I[34 ^ 49].length();
         I[125 ^ 105].length();
         I[41 ^ 60].length();
         I[111 ^ 121].length();
         double var4 = var10000 - var10001;
         var10000 = var1.posZ;
         var10001 = (double)var2.getZ();
         I[151 ^ 128].length();
         double var6 = var10000 - var10001;
         var3.func_192543_a(var4 * var4 + var6 * var6);
      }

   }

   static {
      I();
      field_192242_a = new ResourceLocation(I[81 ^ 73]);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 2);

      throw null;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<UsedEnderEyeTrigger.Instance> var2) {
      UsedEnderEyeTrigger.Listeners var3 = (UsedEnderEyeTrigger.Listeners)this.field_192243_b.get(var1);
      if (var3 != null) {
         var3.func_192544_b(var2);
         if (var3.func_192545_a()) {
            this.field_192243_b.remove(var1);
            I[71 ^ 79].length();
            I[59 ^ 50].length();
         }
      }

   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<UsedEnderEyeTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      UsedEnderEyeTrigger.Listeners var3 = (UsedEnderEyeTrigger.Listeners)this.field_192243_b.get(var1);
      if (var3 == null) {
         I[13 ^ 9].length();
         I[192 ^ 197].length();
         var3 = new UsedEnderEyeTrigger.Listeners(var1);
         this.field_192243_b.put(var1, var3);
         I[170 ^ 172].length();
         I[124 ^ 123].length();
      }

      var3.func_192546_a(var2);
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192243_b.remove(var1);
      I[155 ^ 145].length();
      I[186 ^ 177].length();
   }

   public UsedEnderEyeTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[161 ^ 173];
      String var10001 = I[201 ^ 196];
      String var10002 = I[27 ^ 21];
      var10001 = I[68 ^ 75];
      MinMaxBounds var3 = MinMaxBounds.func_192515_a(var1.get(I[175 ^ 191]));
      I[106 ^ 123].length();
      I[34 ^ 48].length();
      return new UsedEnderEyeTrigger.Instance(var3);
   }

   private static void I() {
      I = new String[190 ^ 167];
      I["".length()] = I("漾扐", "JtQCk");
      I[" ".length()] = I("橩漙", "uUYSn");
      I["  ".length()] = I("殎战", "OrlFZ");
      I["   ".length()] = I("充挦", "cmgBP");
      I[73 ^ 77] = I("慞汲梢侗", "qQDre");
      I[86 ^ 83] = I("梚敹榞昆口", "qVCPL");
      I[26 ^ 28] = I("暛偠揤儡", "CLTRV");
      I[133 ^ 130] = I("嵕", "JfAtr");
      I[179 ^ 187] = I("栟槜寕", "AxIMM");
      I[91 ^ 82] = I("昫", "julSa");
      I[203 ^ 193] = I("朦漟暞撉", "sbdJe");
      I[21 ^ 30] = I("喇瀴勶", "NCztp");
      I[203 ^ 199] = I("坊厏", "uXwoL");
      I[110 ^ 99] = I("屜更", "GhpUV");
      I[120 ^ 118] = I("慽沘", "CKHAD");
      I[64 ^ 79] = I("幆歮", "iSFDN");
      I[17 ^ 1] = I("\u0011\b\u001e= \u001b\u0002\b", "uamIA");
      I[69 ^ 84] = I("抎炀岥暚", "PCULo");
      I[31 ^ 13] = I("杓楣", "abLjZ");
      I[2 ^ 17] = I("憪灞", "UImDp");
      I[13 ^ 25] = I("渑妋樠愄", "aMyKx");
      I[39 ^ 50] = I("噉彛壦", "nEMOd");
      I[108 ^ 122] = I("歆氤", "ZEFXh");
      I[153 ^ 142] = I("傃", "fPRrD");
      I[178 ^ 170] = I("\u001f\u001d\u0011%\u0006\u000f\u0000\u0010$+5\u000b\r$", "jntAY");
   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_192547_a;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<UsedEnderEyeTrigger.Instance>> field_192548_b = Sets.newHashSet();

      public Listeners(PlayerAdvancements var1) {
         this.field_192547_a = var1;
      }

      public void func_192546_a(ICriterionTrigger.Listener<UsedEnderEyeTrigger.Instance> var1) {
         this.field_192548_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      public boolean func_192545_a() {
         return this.field_192548_b.isEmpty();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 == 4);

         throw null;
      }

      public void func_192544_b(ICriterionTrigger.Listener<UsedEnderEyeTrigger.Instance> var1) {
         this.field_192548_b.remove(var1);
         I["  ".length()].length();
         I["   ".length()].length();
      }

      public void func_192543_a(double var1) {
         ArrayList var3 = null;
         Iterator var4 = this.field_192548_b.iterator();

         ICriterionTrigger.Listener var5;
         while(var4.hasNext()) {
            var5 = (ICriterionTrigger.Listener)var4.next();
            if (((UsedEnderEyeTrigger.Instance)var5.func_192158_a()).func_192288_a(var1)) {
               if (var3 == null) {
                  var3 = Lists.newArrayList();
               }

               var3.add(var5);
               I[136 ^ 140].length();
            }

            "".length();
            if (4 < 2) {
               throw null;
            }
         }

         if (var3 != null) {
            var4 = var3.iterator();

            while(var4.hasNext()) {
               var5 = (ICriterionTrigger.Listener)var4.next();
               var5.func_192159_a(this.field_192547_a);
               "".length();
               if (1 == 3) {
                  throw null;
               }
            }
         }

      }

      static {
         I();
      }

      private static void I() {
         I = new String[141 ^ 136];
         I["".length()] = I("嫐撅槉", "PzjBB");
         I[" ".length()] = I("搴炥挩", "EZNpP");
         I["  ".length()] = I("尹厺", "yWIlJ");
         I["   ".length()] = I("湸尫専攢", "FFYwP");
         I[105 ^ 109] = I("嬧", "goDXX");
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final MinMaxBounds field_192289_a;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 < 3);

         throw null;
      }

      public Instance(MinMaxBounds var1) {
         super(UsedEnderEyeTrigger.field_192242_a);
         this.field_192289_a = var1;
      }

      public boolean func_192288_a(double var1) {
         return this.field_192289_a.func_192513_a(var1);
      }
   }
}

package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketCreativeInventoryAction implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int slotId;
   // $FF: synthetic field
   private ItemStack stack;

   public CPacketCreativeInventoryAction(int var1, ItemStack var2) {
      this.stack = ItemStack.field_190927_a;
      this.slotId = var1;
      this.stack = var2.copy();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.slotId = var1.readShort();
      this.stack = var1.readItemStackFromBuffer();
   }

   public int getSlotId() {
      return this.slotId;
   }

   public ItemStack getStack() {
      return this.stack;
   }

   private static void I() {
      I = new String[105 ^ 108];
      I["".length()] = I("捂帷属僯", "bQDnL");
      I[" ".length()] = I("刵", "qKSVz");
      I["  ".length()] = I("帊敶", "GvJJa");
      I["   ".length()] = I("湰刣摑", "WUliM");
      I[116 ^ 112] = I("悍挥", "dhfSF");
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeShort(this.slotId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeItemStackToBuffer(this.stack);
      I["   ".length()].length();
      I[140 ^ 136].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 2);

      throw null;
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processCreativeInventoryAction(this);
   }

   public CPacketCreativeInventoryAction() {
      this.stack = ItemStack.field_190927_a;
   }
}

package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketCloseWindow implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int windowId;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 >= -1);

      throw null;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processCloseWindow(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.windowId = var1.readByte();
   }

   public CPacketCloseWindow(int var1) {
      this.windowId = var1;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.windowId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      I[186 ^ 190].length();
   }

   public CPacketCloseWindow() {
   }

   static {
      I();
   }

   private static void I() {
      I = new String[39 ^ 34];
      I["".length()] = I("搋", "llGEf");
      I[" ".length()] = I("幚張", "FkVXd");
      I["  ".length()] = I("旡手", "NZKOl");
      I["   ".length()] = I("曒囚咽今", "AtaLt");
      I[58 ^ 62] = I("势咜慧俘", "PrzZo");
   }
}

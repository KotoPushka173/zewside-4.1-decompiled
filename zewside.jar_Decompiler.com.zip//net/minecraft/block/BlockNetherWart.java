package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockNetherWart extends BlockBush {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyInteger AGE;
   // $FF: synthetic field
   private static final AxisAlignedBB[] NETHER_WART_AABB;

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      int var5 = (Integer)var3.getValue(AGE);
      if (var5 < "   ".length() && var4.nextInt(50 ^ 56) == 0) {
         var3 = var3.withProperty(AGE, var5 + " ".length());
         var1.setBlockState(var2, var3, "  ".length());
         I["".length()].length();
         I[" ".length()].length();
      }

      super.updateTick(var1, var2, var3, var4);
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(AGE);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(AGE, var1);
   }

   protected boolean canSustainBush(IBlockState var1) {
      int var10000;
      if (var1.getBlock() == Blocks.SOUL_SAND) {
         var10000 = " ".length();
         "".length();
         if (3 < -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      String var10000 = I["  ".length()];
      String var10001 = I["   ".length()];
      String var10002 = I[186 ^ 190];
      var10001 = I[130 ^ 135];
      if (!var1.isRemote) {
         int var6 = " ".length();
         if ((Integer)var3.getValue(AGE) >= "   ".length()) {
            var6 = "  ".length() + var1.rand.nextInt("   ".length());
            if (var5 > 0) {
               var6 += var1.rand.nextInt(var5 + " ".length());
            }
         }

         int var7 = "".length();

         while(var7 < var6) {
            I[194 ^ 196].length();
            I[21 ^ 18].length();
            I[17 ^ 25].length();
            spawnAsEntity(var1, var2, new ItemStack(Items.NETHER_WART));
            ++var7;
            "".length();
            if (false) {
               throw null;
            }
         }
      }

   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NETHER_WART_AABB[(Integer)var1.getValue(AGE)];
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   static {
      I();
      AGE = PropertyInteger.create(I[119 ^ 107], "".length(), "   ".length());
      AxisAlignedBB[] var10000 = new AxisAlignedBB[191 ^ 187];
      var10000["".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.3125D, 1.0D);
      var10000[" ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
      var10000["  ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.6875D, 1.0D);
      var10000["   ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.875D, 1.0D);
      NETHER_WART_AABB = var10000;
   }

   public boolean canBlockStay(World var1, BlockPos var2, IBlockState var3) {
      return this.canSustainBush(var1.getBlockState(var2.down()));
   }

   protected BlockNetherWart() {
      super(Material.PLANTS, MapColor.RED);
      this.setDefaultState(this.blockState.getBaseState().withProperty(AGE, "".length()));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab((CreativeTabs)null);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[204 ^ 194];
      String var10001 = I[200 ^ 199];
      String var10002 = I[95 ^ 79];
      var10001 = I[3 ^ 18];
      var10000 = I[42 ^ 56];
      var10001 = I[130 ^ 145];
      var10002 = I[81 ^ 69];
      var10001 = I[187 ^ 174];
      I[60 ^ 42].length();
      I[71 ^ 80].length();
      I[11 ^ 19].length();
      I[188 ^ 165].length();
      I[143 ^ 149].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[68 ^ 95].length();
      var10003["".length()] = AGE;
      return new BlockStateContainer(this, var10003);
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[175 ^ 166];
      String var10001 = I[4 ^ 14];
      String var10002 = I[163 ^ 168];
      var10001 = I[64 ^ 76];
      I[39 ^ 42].length();
      return new ItemStack(Items.NETHER_WART);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.field_190931_a;
   }

   private static void I() {
      I = new String[128 ^ 157];
      I["".length()] = I("殅柷巡", "innix");
      I[" ".length()] = I("傍椭", "CNqvg");
      I["  ".length()] = I("坁惡", "dhbTK");
      I["   ".length()] = I("凟栩", "VLcyV");
      I[28 ^ 24] = I("岰擪", "jGQsL");
      I[109 ^ 104] = I("妋塝", "VRdRt");
      I[181 ^ 179] = I("咘即悜", "GzqHo");
      I[112 ^ 119] = I("塩宀", "pNGwD");
      I[187 ^ 179] = I("忆卝偐", "tieFf");
      I[13 ^ 4] = I("楿擐", "qTUPR");
      I[157 ^ 151] = I("朓奮", "eyFtI");
      I[132 ^ 143] = I("嶵泎", "JRriG");
      I[205 ^ 193] = I("墮儙", "UOQVO");
      I[16 ^ 29] = I("劆", "aJyUR");
      I[191 ^ 177] = I("噢奵", "yeEOF");
      I[109 ^ 98] = I("墁瀏", "KBySy");
      I[38 ^ 54] = I("慾旒", "pwxOs");
      I[70 ^ 87] = I("攎擓", "QrsOt");
      I[158 ^ 140] = I("歨仲", "ARmxy");
      I[125 ^ 110] = I("堉嗯", "JSCrK");
      I[64 ^ 84] = I("烋檯", "hucZX");
      I[102 ^ 115] = I("厝款", "bCVfx");
      I[58 ^ 44] = I("檳啃", "QkMyD");
      I[209 ^ 198] = I("堎乃媤", "ouxKL");
      I[178 ^ 170] = I("煠岋沚", "hmFQf");
      I[181 ^ 172] = I("唥射", "dgLmK");
      I[117 ^ 111] = I("摠揚", "Cjdyh");
      I[89 ^ 66] = I("岁枮弱", "usJdl");
      I[13 ^ 17] = I("\u0012\b\u0016", "sosbN");
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import javax.annotation.Nullable;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.ResourceLocation;

public class SPacketSelectAdvancementsTab implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   @Nullable
   private ResourceLocation field_194155_a;

   private static void I() {
      I = new String[162 ^ 167];
      I["".length()] = I("刚撗", "eONIP");
      I[" ".length()] = I("侺", "zJEZi");
      I["  ".length()] = I("幻博", "vtxHl");
      I["   ".length()] = I("抾", "iSveJ");
      I[57 ^ 61] = I("櫛棧", "laogL");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      if (var1.readBoolean()) {
         this.field_194155_a = var1.func_192575_l();
      }

   }

   public SPacketSelectAdvancementsTab(@Nullable ResourceLocation var1) {
      this.field_194155_a = var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 4);

      throw null;
   }

   @Nullable
   public ResourceLocation func_194154_a() {
      return this.field_194155_a;
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.func_194022_a(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      int var10001;
      if (this.field_194155_a != null) {
         var10001 = " ".length();
         "".length();
         if (-1 >= 2) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      var1.writeBoolean((boolean)var10001);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      if (this.field_194155_a != null) {
         var1.func_192572_a(this.field_194155_a);
         I["   ".length()].length();
         I[134 ^ 130].length();
      }

   }

   public SPacketSelectAdvancementsTab() {
   }
}

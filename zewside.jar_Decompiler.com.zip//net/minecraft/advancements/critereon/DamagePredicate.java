package net.minecraft.advancements.critereon;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraft.util.JsonUtils;

public class DamagePredicate {
   // $FF: synthetic field
   private final DamageSourcePredicate field_192371_f;
   // $FF: synthetic field
   public static DamagePredicate field_192366_a;
   // $FF: synthetic field
   private final MinMaxBounds field_192368_c;
   // $FF: synthetic field
   private final Boolean field_192370_e;
   // $FF: synthetic field
   private final EntityPredicate field_192369_d;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final MinMaxBounds field_192367_b;

   public DamagePredicate() {
      this.field_192367_b = MinMaxBounds.field_192516_a;
      this.field_192368_c = MinMaxBounds.field_192516_a;
      this.field_192369_d = EntityPredicate.field_192483_a;
      this.field_192370_e = null;
      this.field_192371_f = DamageSourcePredicate.field_192449_a;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != 4);

      throw null;
   }

   static {
      I();
      field_192366_a = new DamagePredicate();
   }

   public boolean func_192365_a(EntityPlayerMP var1, DamageSource var2, float var3, float var4, boolean var5) {
      if (this == field_192366_a) {
         return (boolean)" ".length();
      } else if (!this.field_192367_b.func_192514_a(var3)) {
         return (boolean)"".length();
      } else if (!this.field_192368_c.func_192514_a(var4)) {
         return (boolean)"".length();
      } else if (!this.field_192369_d.func_192482_a(var1, var2.getEntity())) {
         return (boolean)"".length();
      } else {
         return (boolean)(this.field_192370_e != null && this.field_192370_e != var5 ? "".length() : this.field_192371_f.func_193418_a(var1, var2));
      }
   }

   public DamagePredicate(MinMaxBounds var1, MinMaxBounds var2, EntityPredicate var3, @Nullable Boolean var4, DamageSourcePredicate var5) {
      this.field_192367_b = var1;
      this.field_192368_c = var2;
      this.field_192369_d = var3;
      this.field_192370_e = var4;
      this.field_192371_f = var5;
   }

   public static DamagePredicate func_192364_a(@Nullable JsonElement var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = JsonUtils.getJsonObject(var0, I[155 ^ 159]);
         MinMaxBounds var2 = MinMaxBounds.func_192515_a(var1.get(I[108 ^ 105]));
         MinMaxBounds var3 = MinMaxBounds.func_192515_a(var1.get(I[46 ^ 40]));
         Boolean var7;
         if (var1.has(I[169 ^ 174])) {
            var7 = JsonUtils.getBoolean(var1, I[19 ^ 27]);
            "".length();
            if (3 != 3) {
               throw null;
            }
         } else {
            var7 = null;
         }

         Boolean var4 = var7;
         EntityPredicate var5 = EntityPredicate.func_192481_a(var1.get(I[11 ^ 2]));
         DamageSourcePredicate var6 = DamageSourcePredicate.func_192447_a(var1.get(I[111 ^ 101]));
         I[128 ^ 139].length();
         I[75 ^ 71].length();
         I[150 ^ 155].length();
         return new DamagePredicate(var2, var3, var5, var4, var6);
      } else {
         return field_192366_a;
      }
   }

   private static void I() {
      I = new String[190 ^ 176];
      I["".length()] = I("樲渊", "nwEBP");
      I[" ".length()] = I("埡毵", "OROWO");
      I["  ".length()] = I("泙噒", "YNXBw");
      I["   ".length()] = I("佄匜", "aehyE");
      I[20 ^ 16] = I("\u0007\"\n%\u0012\u0006", "cCgDu");
      I[89 ^ 92] = I("(\r 6>", "LhAZJ");
      I[142 ^ 136] = I("\u00180\u000f\r;", "lQdhU");
      I[194 ^ 197] = I("\u0018*'\u0004\u000e\u001f\"", "zFHge");
      I[185 ^ 177] = I("6\u0002%5\u00031\n", "TnJVh");
      I[207 ^ 198] = I("\u0007#\u00148\u0002\u0011\u0013\u0004$\u0015\u001d8\u0018", "tLaJa");
      I[30 ^ 20] = I("$\u001b\u0005\u001d", "PbuxM");
      I[123 ^ 112] = I("烠淭棓侼拇", "Dcohw");
      I[128 ^ 140] = I("挘傗", "yehym");
      I[93 ^ 80] = I("棙尟浟", "fGElY");
   }
}

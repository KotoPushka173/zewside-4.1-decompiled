package net.minecraft.stats;

import java.util.BitSet;
import javax.annotation.Nullable;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;

public class RecipeBook {
   // $FF: synthetic field
   protected final BitSet field_194077_a = new BitSet();
   // $FF: synthetic field
   protected boolean field_192819_c;
   // $FF: synthetic field
   protected boolean field_192818_b;
   // $FF: synthetic field
   protected final BitSet field_194078_b = new BitSet();

   public void func_193831_b(IRecipe var1) {
      int var2 = func_194075_d(var1);
      this.field_194077_a.clear(var2);
      this.field_194078_b.clear(var2);
   }

   public void func_193825_e(IRecipe var1) {
      this.field_194078_b.set(func_194075_d(var1));
   }

   public boolean func_192812_b() {
      return this.field_192818_b;
   }

   protected static int func_194075_d(@Nullable IRecipe var0) {
      return CraftingManager.field_193380_a.getIDForObject(var0);
   }

   public boolean func_194076_e(IRecipe var1) {
      return this.field_194078_b.get(func_194075_d(var1));
   }

   public void func_194074_f(IRecipe var1) {
      this.field_194078_b.clear(func_194075_d(var1));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public boolean func_192815_c() {
      return this.field_192819_c;
   }

   public void func_192810_b(boolean var1) {
      this.field_192819_c = var1;
   }

   public void func_192813_a(boolean var1) {
      this.field_192818_b = var1;
   }

   public void func_193824_a(RecipeBook var1) {
      this.field_194077_a.clear();
      this.field_194078_b.clear();
      this.field_194077_a.or(var1.field_194077_a);
      this.field_194078_b.or(var1.field_194078_b);
   }

   public boolean func_193830_f(@Nullable IRecipe var1) {
      return this.field_194077_a.get(func_194075_d(var1));
   }

   public void func_194073_a(IRecipe var1) {
      if (!var1.func_192399_d()) {
         this.field_194077_a.set(func_194075_d(var1));
      }

   }
}

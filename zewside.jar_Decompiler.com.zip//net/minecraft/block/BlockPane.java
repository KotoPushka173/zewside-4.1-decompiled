package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockPane extends Block {
   // $FF: synthetic field
   public static final PropertyBool EAST;
   // $FF: synthetic field
   public static final PropertyBool NORTH;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final boolean canDrop;
   // $FF: synthetic field
   public static final PropertyBool WEST;
   // $FF: synthetic field
   public static final PropertyBool SOUTH;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] AABB_BY_INDEX;

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      var1 = this.getActualState(var1, var2, var3);
      return AABB_BY_INDEX[getBoundingBoxIndex(var1)];
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 != EnumFacing.UP && var4 != EnumFacing.DOWN) {
         var10000 = BlockFaceShape.MIDDLE_POLE_THIN;
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.CENTER_SMALL;
      }

      return var10000;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(NORTH));
      case 2:
         return var1.withProperty(EAST, var1.getValue(WEST)).withProperty(WEST, var1.getValue(EAST));
      default:
         return super.withMirror(var1, var2);
      }
   }

   private static void I() {
      I = new String[181 ^ 156];
      I["".length()] = I("嬌咨", "JLEsD");
      I[" ".length()] = I("澛庿", "ZYXCl");
      I["  ".length()] = I("傁慝", "PzdCc");
      I["   ".length()] = I("敭浶", "mrUTi");
      I[93 ^ 89] = I("煯湤", "VGalj");
      I[63 ^ 58] = I("掲旤", "vYfxz");
      I[154 ^ 156] = I("漦樇", "IjvmE");
      I[130 ^ 133] = I("堒没", "VVJXZ");
      I[141 ^ 133] = I("檟唃", "LMuhh");
      I[85 ^ 92] = I("埉枽", "xTZzw");
      I[61 ^ 55] = I("婞奪", "ooUCc");
      I[16 ^ 27] = I("困栌", "kxPfT");
      I[136 ^ 132] = I("傗揂", "QasVG");
      I[29 ^ 16] = I("湴榡", "PLpLg");
      I[63 ^ 49] = I("瀷徲", "lTSvt");
      I[160 ^ 175] = I("毰標", "lZlZS");
      I[181 ^ 165] = I("李傗", "bgyQQ");
      I[22 ^ 7] = I("恻壪", "WVWWh");
      I[66 ^ 80] = I("旉斳", "niuLs");
      I[143 ^ 156] = I("傫丁", "KLbxa");
      I[158 ^ 138] = I("刲", "fHLGm");
      I[0 ^ 21] = I("恌寥棵歡", "dsRSJ");
      I[163 ^ 181] = I("橥崬嶧", "FQNBK");
      I[211 ^ 196] = I("惩塻挏", "TaIOy");
      I[130 ^ 154] = I("仇執埲欓濃", "PEaFH");
      I[132 ^ 157] = I("洒昔墖武", "jqGsq");
      I[75 ^ 81] = I("幪底慉", "aLnhQ");
      I[220 ^ 199] = I("沗", "tpbQS");
      I[221 ^ 193] = I("敓堷枌叨", "jNkMK");
      I[101 ^ 120] = I("樅壶敜", "yyTij");
      I[159 ^ 129] = I("攔孔滷", "fhQKD");
      I[177 ^ 174] = I("漷渿樷桀橘", "GtNvi");
      I[176 ^ 144] = I("庌橙", "OvTnj");
      I[13 ^ 44] = I("厇毯加応", "aSEld");
      I[185 ^ 155] = I("敀姳煘杽枽", "nURmW");
      I[30 ^ 61] = I("媧旃款", "WixAh");
      I[22 ^ 50] = I("愍俁掼炜", "iTDzF");
      I[68 ^ 97] = I("\u0016\u000e% .", "xaWTF");
      I[66 ^ 100] = I("\f.=\u0002", "iONvj");
      I[57 ^ 30] = I("*,!\u0015>", "YCTaV");
      I[173 ^ 133] = I("61\u0005\u0017", "ATvcW");
   }

   public int getMetaFromState(IBlockState var1) {
      return "".length();
   }

   private static int getBoundingBoxIndex(IBlockState var0) {
      int var1 = "".length();
      if ((Boolean)var0.getValue(NORTH)) {
         var1 |= getBoundingBoxIndex(EnumFacing.NORTH);
      }

      if ((Boolean)var0.getValue(EAST)) {
         var1 |= getBoundingBoxIndex(EnumFacing.EAST);
      }

      if ((Boolean)var0.getValue(SOUTH)) {
         var1 |= getBoundingBoxIndex(EnumFacing.SOUTH);
      }

      if ((Boolean)var0.getValue(WEST)) {
         var1 |= getBoundingBoxIndex(EnumFacing.WEST);
      }

      return var1;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(EAST, var1.getValue(WEST)).withProperty(SOUTH, var1.getValue(NORTH)).withProperty(WEST, var1.getValue(EAST));
      case 2:
         return var1.withProperty(NORTH, var1.getValue(EAST)).withProperty(EAST, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(WEST)).withProperty(WEST, var1.getValue(NORTH));
      case 3:
         return var1.withProperty(NORTH, var1.getValue(WEST)).withProperty(EAST, var1.getValue(NORTH)).withProperty(SOUTH, var1.getValue(EAST)).withProperty(WEST, var1.getValue(SOUTH));
      default:
         return var1;
      }
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if (var2.getBlockState(var3.offset(var4)).getBlock() == this) {
         var10000 = "".length();
         "".length();
         if (3 < 1) {
            throw null;
         }
      } else {
         var10000 = super.shouldSideBeRendered(var1, var2, var3, var4);
      }

      return (boolean)var10000;
   }

   static {
      I();
      NORTH = PropertyBool.create(I[23 ^ 50]);
      EAST = PropertyBool.create(I[100 ^ 66]);
      SOUTH = PropertyBool.create(I[188 ^ 155]);
      WEST = PropertyBool.create(I[164 ^ 140]);
      AxisAlignedBB[] var10000 = new AxisAlignedBB[65 ^ 81];
      var10000["".length()] = new AxisAlignedBB(0.4375D, 0.0D, 0.4375D, 0.5625D, 1.0D, 0.5625D);
      var10000[" ".length()] = new AxisAlignedBB(0.4375D, 0.0D, 0.4375D, 0.5625D, 1.0D, 1.0D);
      var10000["  ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.4375D, 0.5625D, 1.0D, 0.5625D);
      var10000["   ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.4375D, 0.5625D, 1.0D, 1.0D);
      var10000[69 ^ 65] = new AxisAlignedBB(0.4375D, 0.0D, 0.0D, 0.5625D, 1.0D, 0.5625D);
      var10000[8 ^ 13] = new AxisAlignedBB(0.4375D, 0.0D, 0.0D, 0.5625D, 1.0D, 1.0D);
      var10000[150 ^ 144] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.5625D, 1.0D, 0.5625D);
      var10000[79 ^ 72] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.5625D, 1.0D, 1.0D);
      var10000[127 ^ 119] = new AxisAlignedBB(0.4375D, 0.0D, 0.4375D, 1.0D, 1.0D, 0.5625D);
      var10000[181 ^ 188] = new AxisAlignedBB(0.4375D, 0.0D, 0.4375D, 1.0D, 1.0D, 1.0D);
      var10000[21 ^ 31] = new AxisAlignedBB(0.0D, 0.0D, 0.4375D, 1.0D, 1.0D, 0.5625D);
      var10000[39 ^ 44] = new AxisAlignedBB(0.0D, 0.0D, 0.4375D, 1.0D, 1.0D, 1.0D);
      var10000[59 ^ 55] = new AxisAlignedBB(0.4375D, 0.0D, 0.0D, 1.0D, 1.0D, 0.5625D);
      var10000[202 ^ 199] = new AxisAlignedBB(0.4375D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      var10000[80 ^ 94] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.5625D);
      var10000[39 ^ 40] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      AABB_BY_INDEX = var10000;
   }

   protected static boolean func_193394_e(Block var0) {
      int var10000;
      if (!(var0 instanceof BlockShulkerBox) && !(var0 instanceof BlockLeaves) && var0 != Blocks.BEACON && var0 != Blocks.CAULDRON && var0 != Blocks.GLOWSTONE && var0 != Blocks.ICE && var0 != Blocks.SEA_LANTERN && var0 != Blocks.PISTON && var0 != Blocks.STICKY_PISTON && var0 != Blocks.PISTON_HEAD && var0 != Blocks.MELON_BLOCK && var0 != Blocks.PUMPKIN && var0 != Blocks.LIT_PUMPKIN && var0 != Blocks.BARRIER) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      Item var10000;
      if (!this.canDrop) {
         var10000 = Items.field_190931_a;
         "".length();
         if (3 == 4) {
            throw null;
         }
      } else {
         var10000 = super.getItemDropped(var1, var2, var3);
      }

      return var10000;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[172 ^ 168];
      var10001 = I[147 ^ 150];
      var10002 = I[110 ^ 104];
      var10001 = I[67 ^ 68];
      var10000 = I[178 ^ 186];
      var10001 = I[37 ^ 44];
      var10002 = I[98 ^ 104];
      var10001 = I[174 ^ 165];
      var10000 = I[52 ^ 56];
      var10001 = I[0 ^ 13];
      var10002 = I[128 ^ 142];
      var10001 = I[107 ^ 100];
      var10000 = I[211 ^ 195];
      var10001 = I[137 ^ 152];
      var10002 = I[108 ^ 126];
      var10001 = I[25 ^ 10];
      I[183 ^ 163].length();
      I[212 ^ 193].length();
      IProperty[] var10003 = new IProperty[71 ^ 67];
      I[78 ^ 88].length();
      I[127 ^ 104].length();
      I[222 ^ 198].length();
      I[97 ^ 120].length();
      I[124 ^ 102].length();
      var10003["".length()] = NORTH;
      I[125 ^ 102].length();
      I[81 ^ 77].length();
      I[117 ^ 104].length();
      I[165 ^ 187].length();
      var10003[" ".length()] = EAST;
      I[179 ^ 172].length();
      I[152 ^ 184].length();
      I[31 ^ 62].length();
      var10003["  ".length()] = WEST;
      I[228 ^ 198].length();
      I[146 ^ 177].length();
      I[183 ^ 147].length();
      var10003["   ".length()] = SOUTH;
      return new BlockStateContainer(this, var10003);
   }

   protected BlockPane(Material var1, boolean var2) {
      super(var1);
      this.setDefaultState(this.blockState.getBaseState().withProperty(NORTH, Boolean.valueOf((boolean)"".length())).withProperty(EAST, Boolean.valueOf((boolean)"".length())).withProperty(SOUTH, Boolean.valueOf((boolean)"".length())).withProperty(WEST, Boolean.valueOf((boolean)"".length())));
      this.canDrop = var2;
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   protected boolean canSilkHarvest() {
      return (boolean)" ".length();
   }

   private static int getBoundingBoxIndex(EnumFacing var0) {
      return " ".length() << var0.getHorizontalIndex();
   }

   public final boolean func_193393_b(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      Block var5 = var2.getBlock();
      BlockFaceShape var6 = var2.func_193401_d(var1, var3, var4);
      int var10000;
      if ((func_193394_e(var5) || var6 != BlockFaceShape.SOLID) && var6 != BlockFaceShape.MIDDLE_POLE_THIN) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (4 < 4) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT_MIPPED;
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return var1.withProperty(NORTH, this.func_193393_b(var2, var2.getBlockState(var3.north()), var3.north(), EnumFacing.SOUTH)).withProperty(SOUTH, this.func_193393_b(var2, var2.getBlockState(var3.south()), var3.south(), EnumFacing.NORTH)).withProperty(WEST, this.func_193393_b(var2, var2.getBlockState(var3.west()), var3.west(), EnumFacing.EAST)).withProperty(EAST, this.func_193393_b(var2, var2.getBlockState(var3.east()), var3.east(), EnumFacing.WEST));
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      if (!var7) {
         var1 = this.getActualState(var1, var2, var3);
      }

      addCollisionBoxToList(var3, var4, var5, AABB_BY_INDEX["".length()]);
      if ((Boolean)var1.getValue(NORTH)) {
         addCollisionBoxToList(var3, var4, var5, AABB_BY_INDEX[getBoundingBoxIndex(EnumFacing.NORTH)]);
      }

      if ((Boolean)var1.getValue(SOUTH)) {
         addCollisionBoxToList(var3, var4, var5, AABB_BY_INDEX[getBoundingBoxIndex(EnumFacing.SOUTH)]);
      }

      if ((Boolean)var1.getValue(EAST)) {
         addCollisionBoxToList(var3, var4, var5, AABB_BY_INDEX[getBoundingBoxIndex(EnumFacing.EAST)]);
      }

      if ((Boolean)var1.getValue(WEST)) {
         addCollisionBoxToList(var3, var4, var5, AABB_BY_INDEX[getBoundingBoxIndex(EnumFacing.WEST)]);
      }

   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }
}

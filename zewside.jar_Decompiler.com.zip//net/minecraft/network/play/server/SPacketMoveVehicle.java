package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketMoveVehicle implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private float pitch;
   // $FF: synthetic field
   private double x;
   // $FF: synthetic field
   private float yaw;
   // $FF: synthetic field
   private double z;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private double y;

   public double getY() {
      return this.y;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   public SPacketMoveVehicle() {
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleMoveVehicle(this);
   }

   public double getZ() {
      return this.z;
   }

   public SPacketMoveVehicle(Entity var1) {
      this.x = var1.posX;
      this.y = var1.posY;
      this.z = var1.posZ;
      this.yaw = var1.rotationYaw;
      this.pitch = var1.rotationPitch;
   }

   static {
      I();
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }

   public double getX() {
      return this.x;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeDouble(this.x);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeDouble(this.y);
      I[194 ^ 198].length();
      I[70 ^ 67].length();
      var1.writeDouble(this.z);
      I[146 ^ 148].length();
      I[151 ^ 144].length();
      I[150 ^ 158].length();
      I[166 ^ 175].length();
      var1.writeFloat(this.yaw);
      I[135 ^ 141].length();
      var1.writeFloat(this.pitch);
      I[101 ^ 110].length();
      I[25 ^ 21].length();
   }

   private static void I() {
      I = new String[149 ^ 152];
      I["".length()] = I("岓渾壟啃殚", "qQXvL");
      I[" ".length()] = I("楌帧", "nNfvj");
      I["  ".length()] = I("儼彠徼榩借", "uWzcW");
      I["   ".length()] = I("喵日杓揳", "nxGvu");
      I[57 ^ 61] = I("尝吱惶", "JuOCo");
      I[37 ^ 32] = I("挤敄海倣匓", "AWkfl");
      I[109 ^ 107] = I("嘾搫栕挷必", "RioDl");
      I[27 ^ 28] = I("濦侎姉婤", "OpGfV");
      I[20 ^ 28] = I("凼涵", "GaasK");
      I[138 ^ 131] = I("汞擛屪槊惙", "fiitF");
      I[30 ^ 20] = I("伵此曓嵫奐", "JoYKc");
      I[4 ^ 15] = I("偡滳抵攗叚", "Sytjc");
      I[153 ^ 149] = I("壉栤僉梇数", "HAaFl");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.x = var1.readDouble();
      this.y = var1.readDouble();
      this.z = var1.readDouble();
      this.yaw = var1.readFloat();
      this.pitch = var1.readFloat();
   }
}

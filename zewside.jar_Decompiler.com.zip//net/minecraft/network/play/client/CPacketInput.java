package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketInput implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private float strafeSpeed;
   // $FF: synthetic field
   private float field_192621_b;
   // $FF: synthetic field
   private boolean sneaking;
   // $FF: synthetic field
   private boolean jumping;

   public boolean isSneaking() {
      return this.sneaking;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 0);

      throw null;
   }

   public CPacketInput() {
   }

   public boolean isJumping() {
      return this.jumping;
   }

   private static void I() {
      I = new String[106 ^ 108];
      I["".length()] = I("漒湻", "nznEh");
      I[" ".length()] = I("囿嵻似夘", "GIgWo");
      I["  ".length()] = I("擻澞", "ibiZE");
      I["   ".length()] = I("泉唂", "CoNOo");
      I[183 ^ 179] = I("歕侚", "eYeLG");
      I[27 ^ 30] = I("尛", "Bkfzr");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.strafeSpeed = var1.readFloat();
      this.field_192621_b = var1.readFloat();
      byte var2 = var1.readByte();
      int var10001;
      if ((var2 & " ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (4 < 3) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.jumping = (boolean)var10001;
      if ((var2 & "  ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (0 <= -1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.sneaking = (boolean)var10001;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processInput(this);
   }

   public CPacketInput(float var1, float var2, boolean var3, boolean var4) {
      this.strafeSpeed = var1;
      this.field_192621_b = var2;
      this.jumping = var3;
      this.sneaking = var4;
   }

   static {
      I();
   }

   public float getStrafeSpeed() {
      return this.strafeSpeed;
   }

   public float func_192620_b() {
      return this.field_192621_b;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeFloat(this.strafeSpeed);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeFloat(this.field_192621_b);
      I["  ".length()].length();
      I["   ".length()].length();
      I[130 ^ 134].length();
      int var2 = "".length();
      if (this.jumping) {
         var2 = (byte)(var2 | " ".length());
      }

      if (this.sneaking) {
         var2 = (byte)(var2 | "  ".length());
      }

      var1.writeByte(var2);
      I[33 ^ 36].length();
   }
}

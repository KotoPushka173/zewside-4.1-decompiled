package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;

public class EntityHurtPlayerTrigger implements ICriterionTrigger<EntityHurtPlayerTrigger.Instance> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, EntityHurtPlayerTrigger.Listeners> field_192202_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final ResourceLocation field_192201_a;

   private static void I() {
      I = new String[47 ^ 56];
      I["".length()] = I("侤侶", "AywCi");
      I[" ".length()] = I("炢槗", "mSQWQ");
      I["  ".length()] = I("攊廸", "WJWDj");
      I["   ".length()] = I("姍梳", "mVEFl");
      I[116 ^ 112] = I("检匩汏", "Leoez");
      I[14 ^ 11] = I("冗夈懹峆潖", "jhEne");
      I[74 ^ 76] = I("咏", "ZeDRZ");
      I[40 ^ 47] = I("姛旣敼", "eCRwe");
      I[94 ^ 86] = I("囎廳搰愪", "xkdTq");
      I[35 ^ 42] = I("灈伕忣堤", "DlSYi");
      I[24 ^ 18] = I("匡乖叿炳撜", "dzdCR");
      I[38 ^ 45] = I("斓", "xKGvy");
      I[16 ^ 28] = I("敾字", "jlHCP");
      I[135 ^ 138] = I("佊杮", "LFmDe");
      I[130 ^ 140] = I("墍濩", "lDfuA");
      I[87 ^ 88] = I("嬝凁", "qmyfK");
      I[45 ^ 61] = I("撃妬", "GOhqb");
      I[6 ^ 23] = I("桶压", "SrAyH");
      I[21 ^ 7] = I("=\u001b$'/<", "YzIFH");
      I[213 ^ 198] = I("氟淅", "Cdtfi");
      I[212 ^ 192] = I("搛幌惸佭漭", "HelCC");
      I[87 ^ 66] = I("兜塞斧", "gyaxk");
      I[142 ^ 152] = I("\u001c\n\u001b=3\u0000;\u0007!5\r;\u001f8&\u0000\u0001\u001d", "ydoTG");
   }

   public EntityHurtPlayerTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[152 ^ 150];
      String var10001 = I[45 ^ 34];
      String var10002 = I[94 ^ 78];
      var10001 = I[106 ^ 123];
      DamagePredicate var3 = DamagePredicate.func_192364_a(var1.get(I[166 ^ 180]));
      I[35 ^ 48].length();
      I[162 ^ 182].length();
      I[177 ^ 164].length();
      return new EntityHurtPlayerTrigger.Instance(var3);
   }

   static {
      I();
      field_192201_a = new ResourceLocation(I[69 ^ 83]);
   }

   public void func_192200_a(EntityPlayerMP var1, DamageSource var2, float var3, float var4, boolean var5) {
      EntityHurtPlayerTrigger.Listeners var6 = (EntityHurtPlayerTrigger.Listeners)this.field_192202_b.get(var1.func_192039_O());
      if (var6 != null) {
         var6.func_192478_a(var1, var2, var3, var4, var5);
      }

   }

   public ResourceLocation func_192163_a() {
      return field_192201_a;
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192202_b.remove(var1);
      I[72 ^ 69].length();
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<EntityHurtPlayerTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      EntityHurtPlayerTrigger.Listeners var3 = (EntityHurtPlayerTrigger.Listeners)this.field_192202_b.get(var1);
      if (var3 == null) {
         I[181 ^ 177].length();
         I[125 ^ 120].length();
         I[119 ^ 113].length();
         var3 = new EntityHurtPlayerTrigger.Listeners(var1);
         this.field_192202_b.put(var1, var3);
         I[61 ^ 58].length();
         I[114 ^ 122].length();
         I[148 ^ 157].length();
      }

      var3.func_192477_a(var2);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 2);

      throw null;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<EntityHurtPlayerTrigger.Instance> var2) {
      EntityHurtPlayerTrigger.Listeners var3 = (EntityHurtPlayerTrigger.Listeners)this.field_192202_b.get(var1);
      if (var3 != null) {
         var3.func_192475_b(var2);
         if (var3.func_192476_a()) {
            this.field_192202_b.remove(var1);
            I[123 ^ 113].length();
            I[6 ^ 13].length();
            I[44 ^ 32].length();
         }
      }

   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_192479_a;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<EntityHurtPlayerTrigger.Instance>> field_192480_b = Sets.newHashSet();
      // $FF: synthetic field
      private static final String[] I;

      public Listeners(PlayerAdvancements var1) {
         this.field_192479_a = var1;
      }

      static {
         I();
      }

      public void func_192478_a(EntityPlayerMP var1, DamageSource var2, float var3, float var4, boolean var5) {
         ArrayList var6 = null;
         Iterator var7 = this.field_192480_b.iterator();

         ICriterionTrigger.Listener var8;
         while(var7.hasNext()) {
            var8 = (ICriterionTrigger.Listener)var7.next();
            if (((EntityHurtPlayerTrigger.Instance)var8.func_192158_a()).func_192263_a(var1, var2, var3, var4, var5)) {
               if (var6 == null) {
                  var6 = Lists.newArrayList();
               }

               var6.add(var8);
               I[149 ^ 145].length();
               I[186 ^ 191].length();
            }

            "".length();
            if (4 <= 0) {
               throw null;
            }
         }

         if (var6 != null) {
            var7 = var6.iterator();

            while(var7.hasNext()) {
               var8 = (ICriterionTrigger.Listener)var7.next();
               var8.func_192159_a(this.field_192479_a);
               "".length();
               if (1 <= 0) {
                  throw null;
               }
            }
         }

      }

      private static void I() {
         I = new String[65 ^ 71];
         I["".length()] = I("侯", "tlGpp");
         I[" ".length()] = I("淳瀺斘屲敺", "syGAW");
         I["  ".length()] = I("堟旵栀氡岻", "mwSfh");
         I["   ".length()] = I("汯枕嬛", "mYmis");
         I[24 ^ 28] = I("滷嶩憐橶", "szZaq");
         I[13 ^ 8] = I("挖拋抜", "cRUvI");
      }

      public void func_192475_b(ICriterionTrigger.Listener<EntityHurtPlayerTrigger.Instance> var1) {
         this.field_192480_b.remove(var1);
         I["   ".length()].length();
      }

      public void func_192477_a(ICriterionTrigger.Listener<EntityHurtPlayerTrigger.Instance> var1) {
         this.field_192480_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }

      public boolean func_192476_a() {
         return this.field_192480_b.isEmpty();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= -1);

         throw null;
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final DamagePredicate field_192264_a;

      public Instance(DamagePredicate var1) {
         super(EntityHurtPlayerTrigger.field_192201_a);
         this.field_192264_a = var1;
      }

      public boolean func_192263_a(EntityPlayerMP var1, DamageSource var2, float var3, float var4, boolean var5) {
         return this.field_192264_a.func_192365_a(var1, var2, var3, var4, var5);
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 == 3);

         throw null;
      }
   }
}

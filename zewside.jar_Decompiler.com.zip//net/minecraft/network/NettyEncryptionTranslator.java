package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import javax.crypto.Cipher;
import javax.crypto.ShortBufferException;

public class NettyEncryptionTranslator {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private byte[] inputBuffer = new byte["".length()];
   // $FF: synthetic field
   private byte[] outputBuffer = new byte["".length()];
   // $FF: synthetic field
   private final Cipher cipher;

   private static void I() {
      I = new String[102 ^ 111];
      I["".length()] = I("墍椫渔柪庅", "tKHhb");
      I[" ".length()] = I("图撲捍廅", "CdNvh");
      I["  ".length()] = I("惄斯", "qjgXp");
      I["   ".length()] = I("滹冝氩", "GvSJA");
      I[26 ^ 30] = I("曥煠", "PxGOA");
      I[70 ^ 67] = I("寱凡宿兿", "cgHXT");
      I[46 ^ 40] = I("嚭泷御昝桥", "LCKss");
      I[92 ^ 91] = I("帆", "KEQpy");
      I[158 ^ 150] = I("歞梯劀姂弃", "XeZaY");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 >= -1);

      throw null;
   }

   private byte[] bufToBytes(ByteBuf var1) {
      int var2 = var1.readableBytes();
      if (this.inputBuffer.length < var2) {
         this.inputBuffer = new byte[var2];
      }

      var1.readBytes(this.inputBuffer, "".length(), var2);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      return this.inputBuffer;
   }

   protected NettyEncryptionTranslator(Cipher var1) {
      this.cipher = var1;
   }

   protected ByteBuf decipher(ChannelHandlerContext var1, ByteBuf var2) throws ShortBufferException {
      int var3 = var2.readableBytes();
      byte[] var4 = this.bufToBytes(var2);
      ByteBuf var5 = var1.alloc().heapBuffer(this.cipher.getOutputSize(var3));
      var5.writerIndex(this.cipher.update(var4, "".length(), var3, var5.array(), var5.arrayOffset()));
      I["   ".length()].length();
      I[35 ^ 39].length();
      return var5;
   }

   protected void cipher(ByteBuf var1, ByteBuf var2) throws ShortBufferException {
      int var3 = var1.readableBytes();
      byte[] var4 = this.bufToBytes(var1);
      int var5 = this.cipher.getOutputSize(var3);
      if (this.outputBuffer.length < var5) {
         this.outputBuffer = new byte[var5];
      }

      var2.writeBytes(this.outputBuffer, "".length(), this.cipher.update(var4, "".length(), var3, this.outputBuffer));
      I[5 ^ 0].length();
      I[103 ^ 97].length();
      I[42 ^ 45].length();
      I[10 ^ 2].length();
   }

   static {
      I();
   }
}

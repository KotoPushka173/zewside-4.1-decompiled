package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;

public class SummonedEntityTrigger implements ICriterionTrigger<SummonedEntityTrigger.Instance> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, SummonedEntityTrigger.Listeners> field_192233_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final ResourceLocation field_192232_a;

   public void func_192229_a(EntityPlayerMP var1, Entity var2) {
      SummonedEntityTrigger.Listeners var3 = (SummonedEntityTrigger.Listeners)this.field_192233_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_192533_a(var1, var2);
      }

   }

   public ResourceLocation func_192163_a() {
      return field_192232_a;
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<SummonedEntityTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      SummonedEntityTrigger.Listeners var3 = (SummonedEntityTrigger.Listeners)this.field_192233_b.get(var1);
      if (var3 == null) {
         I[193 ^ 197].length();
         I[192 ^ 197].length();
         I[191 ^ 185].length();
         var3 = new SummonedEntityTrigger.Listeners(var1);
         this.field_192233_b.put(var1, var3);
         I[63 ^ 56].length();
         I[163 ^ 171].length();
      }

      var3.func_192534_a(var2);
   }

   private static void I() {
      I = new String[10 ^ 18];
      I["".length()] = I("棗倸", "oWrYj");
      I[" ".length()] = I("植塩", "AyCUW");
      I["  ".length()] = I("啙浢", "dMuXR");
      I["   ".length()] = I("枴惨", "wazGP");
      I[78 ^ 74] = I("忳", "BJlnt");
      I[63 ^ 58] = I("僟泴昿", "pQghn");
      I[65 ^ 71] = I("劔歯", "dlxEE");
      I[40 ^ 47] = I("唌噞愌", "itRDY");
      I[19 ^ 27] = I("卌囷旘唷凟", "mldgz");
      I[134 ^ 143] = I("汓啬媌昏", "geoTu");
      I[112 ^ 122] = I("侴喧叢", "BwMQc");
      I[170 ^ 161] = I("坉攒哫", "nADCn");
      I[78 ^ 66] = I("啜", "kcBui");
      I[11 ^ 6] = I("匛厇河", "RXmLn");
      I[26 ^ 20] = I("則檱", "mjefC");
      I[51 ^ 60] = I("啌傺", "ldnPz");
      I[211 ^ 195] = I("平姶", "yBMyC");
      I[22 ^ 7] = I("栀仭", "DMeuv");
      I[182 ^ 164] = I("枯滮", "dTTZm");
      I[153 ^ 138] = I("\u000e\u0014\u000417\u0012", "kzpXC");
      I[116 ^ 96] = I("渝憁墥", "mqvfj");
      I[25 ^ 12] = I("濅傡椶揆嫲", "CDaFn");
      I[84 ^ 66] = I("娾慾", "GArNr");
      I[34 ^ 53] = I("\u00174\u001e99\n$\u0017\u000b3\n5\u001a /", "dAsTV");
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<SummonedEntityTrigger.Instance> var2) {
      SummonedEntityTrigger.Listeners var3 = (SummonedEntityTrigger.Listeners)this.field_192233_b.get(var1);
      if (var3 != null) {
         var3.func_192531_b(var2);
         if (var3.func_192532_a()) {
            this.field_192233_b.remove(var1);
            I[90 ^ 83].length();
            I[149 ^ 159].length();
            I[114 ^ 121].length();
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192233_b.remove(var1);
      I[89 ^ 85].length();
      I[3 ^ 14].length();
      I[124 ^ 114].length();
   }

   public SummonedEntityTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[7 ^ 8];
      String var10001 = I[64 ^ 80];
      String var10002 = I[123 ^ 106];
      var10001 = I[61 ^ 47];
      EntityPredicate var3 = EntityPredicate.func_192481_a(var1.get(I[10 ^ 25]));
      I[128 ^ 148].length();
      I[162 ^ 183].length();
      I[151 ^ 129].length();
      return new SummonedEntityTrigger.Instance(var3);
   }

   static {
      I();
      field_192232_a = new ResourceLocation(I[214 ^ 193]);
   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<SummonedEntityTrigger.Instance>> field_192536_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_192535_a;
      // $FF: synthetic field
      private static final String[] I;

      public void func_192531_b(ICriterionTrigger.Listener<SummonedEntityTrigger.Instance> var1) {
         this.field_192536_b.remove(var1);
         I["   ".length()].length();
         I[13 ^ 9].length();
         I[120 ^ 125].length();
         I[168 ^ 174].length();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 >= 0);

         throw null;
      }

      private static void I() {
         I = new String[166 ^ 175];
         I["".length()] = I("廈", "PXnLy");
         I[" ".length()] = I("激潕垻嵁波", "xxnsf");
         I["  ".length()] = I("涐幌僮为涋", "JrLRl");
         I["   ".length()] = I("壇", "VwOiF");
         I[196 ^ 192] = I("圉庁潟兤", "qafSs");
         I[131 ^ 134] = I("劧曺枡圈", "BlWBQ");
         I[96 ^ 102] = I("岂乌俱", "IvCLB");
         I[57 ^ 62] = I("涫岡汢", "ikeeN");
         I[200 ^ 192] = I("挛喳劸櫚墢", "QGcJx");
      }

      public void func_192533_a(EntityPlayerMP var1, Entity var2) {
         ArrayList var3 = null;
         Iterator var4 = this.field_192536_b.iterator();

         ICriterionTrigger.Listener var5;
         while(var4.hasNext()) {
            var5 = (ICriterionTrigger.Listener)var4.next();
            if (((SummonedEntityTrigger.Instance)var5.func_192158_a()).func_192283_a(var1, var2)) {
               if (var3 == null) {
                  var3 = Lists.newArrayList();
               }

               var3.add(var5);
               I[119 ^ 112].length();
               I[94 ^ 86].length();
            }

            "".length();
            if (3 == 4) {
               throw null;
            }
         }

         if (var3 != null) {
            var4 = var3.iterator();

            while(var4.hasNext()) {
               var5 = (ICriterionTrigger.Listener)var4.next();
               var5.func_192159_a(this.field_192535_a);
               "".length();
               if (3 < 2) {
                  throw null;
               }
            }
         }

      }

      public void func_192534_a(ICriterionTrigger.Listener<SummonedEntityTrigger.Instance> var1) {
         this.field_192536_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }

      static {
         I();
      }

      public boolean func_192532_a() {
         return this.field_192536_b.isEmpty();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192535_a = var1;
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final EntityPredicate field_192284_a;

      public Instance(EntityPredicate var1) {
         super(SummonedEntityTrigger.field_192232_a);
         this.field_192284_a = var1;
      }

      public boolean func_192283_a(EntityPlayerMP var1, Entity var2) {
         return this.field_192284_a.func_192482_a(var1, var2);
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > 2);

         throw null;
      }
   }
}

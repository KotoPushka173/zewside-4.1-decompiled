package net.minecraft.network.datasync;

import java.io.IOException;
import net.minecraft.network.PacketBuffer;

public interface DataSerializer<T> {
   T read(PacketBuffer var1) throws IOException;

   void write(PacketBuffer var1, T var2);

   T func_192717_a(T var1);

   DataParameter<T> createKey(int var1);
}

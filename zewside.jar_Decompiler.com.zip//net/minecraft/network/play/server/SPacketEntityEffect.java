package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class SPacketEntityEffect implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private byte flags;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private byte effectId;
   // $FF: synthetic field
   private int duration;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private byte amplifier;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeByte(this.effectId);
      I["   ".length()].length();
      I[188 ^ 184].length();
      I[146 ^ 151].length();
      var1.writeByte(this.amplifier);
      I[50 ^ 52].length();
      I[129 ^ 134].length();
      I[169 ^ 161].length();
      I[34 ^ 43].length();
      var1.writeVarIntToBuffer(this.duration);
      I[202 ^ 192].length();
      I[189 ^ 182].length();
      I[186 ^ 182].length();
      var1.writeByte(this.flags);
      I[51 ^ 62].length();
      I[137 ^ 135].length();
      I[33 ^ 46].length();
      I[125 ^ 109].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= -1);

      throw null;
   }

   public byte getAmplifier() {
      return this.amplifier;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.effectId = var1.readByte();
      this.amplifier = var1.readByte();
      this.duration = var1.readVarIntFromBuffer();
      this.flags = var1.readByte();
   }

   public boolean isMaxDuration() {
      int var10000;
      if (this.duration == 3535 + 24754 - 20163 + 24641) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public boolean doesShowParticles() {
      int var10000;
      if ((this.flags & "  ".length()) == "  ".length()) {
         var10000 = " ".length();
         "".length();
         if (1 < -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityEffect(this);
   }

   public int getEntityId() {
      return this.entityId;
   }

   public int getDuration() {
      return this.duration;
   }

   public boolean getIsAmbient() {
      int var10000;
      if ((this.flags & " ".length()) == " ".length()) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public SPacketEntityEffect() {
   }

   public SPacketEntityEffect(int var1, PotionEffect var2) {
      this.entityId = var1;
      this.effectId = (byte)(Potion.getIdFromPotion(var2.getPotion()) & 190 + 75 - 242 + 232);
      this.amplifier = (byte)(var2.getAmplifier() & 102 + 3 - -42 + 108);
      if (var2.getDuration() > 1679 + 13843 - -15350 + 1895) {
         this.duration = 9189 + 21380 - 2708 + 4906;
         "".length();
         if (2 >= 3) {
            throw null;
         }
      } else {
         this.duration = var2.getDuration();
      }

      this.flags = (byte)"".length();
      if (var2.getIsAmbient()) {
         this.flags = (byte)(this.flags | " ".length());
      }

      if (var2.doesShowParticles()) {
         this.flags = (byte)(this.flags | "  ".length());
      }

   }

   private static void I() {
      I = new String[88 ^ 73];
      I["".length()] = I("姖擄後", "fpenv");
      I[" ".length()] = I("寄嘕", "FEDwd");
      I["  ".length()] = I("墆", "uuGPF");
      I["   ".length()] = I("妥宸汚渿愅", "TLLnO");
      I[155 ^ 159] = I("掺垮楇敊叻", "vteIV");
      I[1 ^ 4] = I("嫻怅娷乀柒", "zqdmE");
      I[116 ^ 114] = I("弃屿", "hhAHB");
      I[126 ^ 121] = I("圊曳", "vaCVh");
      I[166 ^ 174] = I("勗櫽", "vnAmg");
      I[137 ^ 128] = I("減嚛", "cTJkz");
      I[74 ^ 64] = I("嫅攝槷嫊廎", "aeLRX");
      I[124 ^ 119] = I("峇瀆巯", "TrnWR");
      I[182 ^ 186] = I("恪", "nwVXJ");
      I[156 ^ 145] = I("杨乼據广", "OInQN");
      I[78 ^ 64] = I("栭展枩倠檱", "SgHWQ");
      I[61 ^ 50] = I("灹桍乛椶嵇", "HCoFK");
      I[30 ^ 14] = I("枞", "OqDsE");
   }

   public byte getEffectId() {
      return this.effectId;
   }
}

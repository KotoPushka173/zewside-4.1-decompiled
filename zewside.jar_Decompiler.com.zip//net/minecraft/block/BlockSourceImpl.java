package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.dispenser.IBlockSource;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockSourceImpl implements IBlockSource {
   // $FF: synthetic field
   private final World worldObj;
   // $FF: synthetic field
   private final BlockPos pos;

   public double getZ() {
      return (double)this.pos.getZ() + 0.5D;
   }

   public BlockPos getBlockPos() {
      return this.pos;
   }

   public double getY() {
      return (double)this.pos.getY() + 0.5D;
   }

   public double getX() {
      return (double)this.pos.getX() + 0.5D;
   }

   public World getWorld() {
      return this.worldObj;
   }

   public <T extends TileEntity> T getBlockTileEntity() {
      return this.worldObj.getTileEntity(this.pos);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 3);

      throw null;
   }

   public BlockSourceImpl(World var1, BlockPos var2) {
      this.worldObj = var1;
      this.pos = var2;
   }

   public IBlockState getBlockState() {
      return this.worldObj.getBlockState(this.pos);
   }
}

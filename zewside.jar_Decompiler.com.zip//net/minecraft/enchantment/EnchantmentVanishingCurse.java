package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentVanishingCurse extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= -1);

      throw null;
   }

   public int getMaxEnchantability(int var1) {
      return 120 ^ 74;
   }

   public boolean isTreasureEnchantment() {
      return (boolean)" ".length();
   }

   public boolean func_190936_d() {
      return (boolean)" ".length();
   }

   public int getMaxLevel() {
      return " ".length();
   }

   public EnchantmentVanishingCurse(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.ALL, var2);
      this.setName(I["".length()]);
   }

   static {
      I();
   }

   public int getMinEnchantability(int var1) {
      return 188 ^ 165;
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("\u0011\u000b(%\u0012\u000f\u0003(+>\u0004\u001f4?\u0004", "gjFLa");
   }
}

package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

public class BlockBone extends BlockRotatedPillar {
   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 > 0);

      throw null;
   }

   public BlockBone() {
      super(Material.ROCK, MapColor.SAND);
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
      this.setHardness(2.0F);
      this.setSoundType(SoundType.STONE);
   }
}

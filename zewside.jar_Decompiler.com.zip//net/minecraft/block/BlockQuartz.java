package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockQuartz extends Block {
   // $FF: synthetic field
   public static final PropertyEnum<BlockQuartz.EnumType> VARIANT;
   // $FF: synthetic field
   private static final String[] I;

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      if (var7 == BlockQuartz.EnumType.LINES_Y.getMetadata()) {
         switch(null.$SwitchMap$net$minecraft$util$EnumFacing$Axis[var3.getAxis().ordinal()]) {
         case 1:
            return this.getDefaultState().withProperty(VARIANT, BlockQuartz.EnumType.LINES_Z);
         case 2:
            return this.getDefaultState().withProperty(VARIANT, BlockQuartz.EnumType.LINES_X);
         case 3:
            return this.getDefaultState().withProperty(VARIANT, BlockQuartz.EnumType.LINES_Y);
         }
      }

      IBlockState var10000;
      if (var7 == BlockQuartz.EnumType.CHISELED.getMetadata()) {
         var10000 = this.getDefaultState().withProperty(VARIANT, BlockQuartz.EnumType.CHISELED);
         "".length();
         if (1 >= 2) {
            throw null;
         }
      } else {
         var10000 = this.getDefaultState().withProperty(VARIANT, BlockQuartz.EnumType.DEFAULT);
      }

      return var10000;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 1);

      throw null;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockQuartz.EnumType.byMetadata(var1));
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.QUARTZ;
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[83 ^ 125], BlockQuartz.EnumType.class);
   }

   public BlockQuartz() {
      super(Material.ROCK);
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockQuartz.EnumType.DEFAULT));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[41 ^ 13];
      String var10001 = I[29 ^ 56];
      String var10002 = I[83 ^ 117];
      var10001 = I[92 ^ 123];
      var10000 = I[184 ^ 144];
      var10001 = I[156 ^ 181];
      var10002 = I[185 ^ 147];
      var10001 = I[29 ^ 54];
      I[30 ^ 50].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[152 ^ 181].length();
      var10003["".length()] = VARIANT;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockQuartz$EnumType[((BlockQuartz.EnumType)var1.getValue(VARIANT)).ordinal()]) {
         case 1:
            return var1.withProperty(VARIANT, BlockQuartz.EnumType.LINES_Z);
         case 2:
            return var1.withProperty(VARIANT, BlockQuartz.EnumType.LINES_X);
         default:
            return var1;
         }
      default:
         return var1;
      }
   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      BlockQuartz.EnumType var2 = (BlockQuartz.EnumType)var1.getValue(VARIANT);
      ItemStack var3;
      if (var2 != BlockQuartz.EnumType.LINES_X && var2 != BlockQuartz.EnumType.LINES_Z) {
         var3 = super.getSilkTouchDrop(var1);
         "".length();
         if (3 < -1) {
            throw null;
         }
      } else {
         I[122 ^ 126].length();
         I[20 ^ 17].length();
         I[12 ^ 10].length();
         var3 = new ItemStack(Item.getItemFromBlock(this), " ".length(), BlockQuartz.EnumType.LINES_Y.getMetadata());
      }

      return var3;
   }

   public int damageDropped(IBlockState var1) {
      BlockQuartz.EnumType var2 = (BlockQuartz.EnumType)var1.getValue(VARIANT);
      int var10000;
      if (var2 != BlockQuartz.EnumType.LINES_X && var2 != BlockQuartz.EnumType.LINES_Z) {
         var10000 = var2.getMetadata();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = BlockQuartz.EnumType.LINES_Y.getMetadata();
      }

      return var10000;
   }

   private static void I() {
      I = new String[82 ^ 125];
      I["".length()] = I("憪斁", "qyUIj");
      I[" ".length()] = I("溺冒", "NpWIa");
      I["  ".length()] = I("冗撮", "xXRFQ");
      I["   ".length()] = I("哫敧", "LzRne");
      I[20 ^ 16] = I("烘炳", "vRMSL");
      I[121 ^ 124] = I("彆惴徛", "hKIUV");
      I[63 ^ 57] = I("儐宽歪嚺", "xSDCq");
      I[105 ^ 110] = I("戒揚", "OSJfl");
      I[171 ^ 163] = I("嫃晴", "qSyLY");
      I[72 ^ 65] = I("啶湾", "tLuZh");
      I[207 ^ 197] = I("懑掚", "nCTBx");
      I[100 ^ 111] = I("床墧", "jNZkr");
      I[4 ^ 8] = I("乁桉", "yqTzv");
      I[94 ^ 83] = I("悖侳", "GaxTQ");
      I[160 ^ 174] = I("傈伝", "YAViP");
      I[141 ^ 130] = I("灦据", "EGeUi");
      I[64 ^ 80] = I("灚戆", "ounwm");
      I[96 ^ 113] = I("昙方", "gsGpO");
      I[214 ^ 196] = I("洵妱", "bgZLs");
      I[25 ^ 10] = I("崵妋慣欵", "kqBXg");
      I[72 ^ 92] = I("悇怏湌", "SeOts");
      I[163 ^ 182] = I("毉氠毮", "udrWf");
      I[16 ^ 6] = I("悽儸懹潖", "SlQcr");
      I[55 ^ 32] = I("樫氻", "xecVF");
      I[18 ^ 10] = I("嫂", "UbvdJ");
      I[2 ^ 27] = I("媿惊瀯", "SoRFM");
      I[63 ^ 37] = I("搥澞庐", "GEjRw");
      I[53 ^ 46] = I("传壘唒", "TEbzD");
      I[33 ^ 61] = I("傾沂孫官涿", "itVqO");
      I[178 ^ 175] = I("恋媸", "AeVtW");
      I[30 ^ 0] = I("恳兕尿廥", "wrBZP");
      I[27 ^ 4] = I("撫嘐抗嵩", "CdoHy");
      I[107 ^ 75] = I("杕", "vlXIS");
      I[11 ^ 42] = I("昇", "DOCoA");
      I[62 ^ 28] = I("捝挶", "LVMEd");
      I[226 ^ 193] = I("匛涆滩炫樤", "QNpBf");
      I[180 ^ 144] = I("嬦朦", "hiOkh");
      I[122 ^ 95] = I("攻巰", "KEibN");
      I[227 ^ 197] = I("吵垌", "FIkeZ");
      I[6 ^ 33] = I("椿廏", "VPVIN");
      I[58 ^ 18] = I("庎撏", "kqaVu");
      I[22 ^ 63] = I("棔嗱", "kWBGz");
      I[148 ^ 190] = I("楬曲", "UnYry");
      I[30 ^ 53] = I("喠啽", "fDBKi");
      I[70 ^ 106] = I("杆炲", "xFyNJ");
      I[79 ^ 98] = I("比妹怔", "yBeCr");
      I[167 ^ 137] = I("\u000f*\n,\u0007\u0017?", "yKxEf");
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[17 ^ 22];
      String var10001 = I[9 ^ 1];
      String var10002 = I[130 ^ 139];
      var10001 = I[95 ^ 85];
      var10000 = I[134 ^ 141];
      var10001 = I[72 ^ 68];
      var10002 = I[19 ^ 30];
      var10001 = I[49 ^ 63];
      var10000 = I[135 ^ 136];
      var10001 = I[73 ^ 89];
      var10002 = I[154 ^ 139];
      var10001 = I[74 ^ 88];
      I[82 ^ 65].length();
      I[104 ^ 124].length();
      I[180 ^ 161].length();
      var2.add(new ItemStack(this, " ".length(), BlockQuartz.EnumType.DEFAULT.getMetadata()));
      I[119 ^ 97].length();
      I[128 ^ 151].length();
      I[44 ^ 52].length();
      I[156 ^ 133].length();
      var2.add(new ItemStack(this, " ".length(), BlockQuartz.EnumType.CHISELED.getMetadata()));
      I[161 ^ 187].length();
      I[40 ^ 51].length();
      I[91 ^ 71].length();
      I[18 ^ 15].length();
      I[14 ^ 16].length();
      I[169 ^ 182].length();
      I[23 ^ 55].length();
      I[176 ^ 145].length();
      var2.add(new ItemStack(this, " ".length(), BlockQuartz.EnumType.LINES_Y.getMetadata()));
      I[59 ^ 25].length();
      I[19 ^ 48].length();
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockQuartz.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      CHISELED;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      LINES_Y,
      // $FF: synthetic field
      LINES_X;

      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      private final String serializedName;
      // $FF: synthetic field
      LINES_Z,
      // $FF: synthetic field
      DEFAULT;

      public int getMetadata() {
         return this.meta;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 == -1);

         throw null;
      }

      public static BlockQuartz.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      static {
         I();
         DEFAULT = new BlockQuartz.EnumType(I["".length()], "".length(), "".length(), I[" ".length()], I["  ".length()]);
         CHISELED = new BlockQuartz.EnumType(I["   ".length()], " ".length(), " ".length(), I[67 ^ 71], I[153 ^ 156]);
         LINES_Y = new BlockQuartz.EnumType(I[157 ^ 155], "  ".length(), "  ".length(), I[162 ^ 165], I[30 ^ 22]);
         LINES_X = new BlockQuartz.EnumType(I[178 ^ 187], "   ".length(), "   ".length(), I[15 ^ 5], I[98 ^ 105]);
         LINES_Z = new BlockQuartz.EnumType(I[5 ^ 9], 48 ^ 52, 151 ^ 147, I[99 ^ 110], I[135 ^ 137]);
         BlockQuartz.EnumType[] var10000 = new BlockQuartz.EnumType[170 ^ 175];
         var10000["".length()] = DEFAULT;
         var10000[" ".length()] = CHISELED;
         var10000["  ".length()] = LINES_Y;
         var10000["   ".length()] = LINES_X;
         var10000[95 ^ 91] = LINES_Z;
         BlockQuartz.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockQuartz.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(0 < 2);

         throw null;
      }

      private EnumType(int var3, String var4, String var5) {
         this.meta = var3;
         this.serializedName = var4;
         this.unlocalizedName = var5;
      }

      public String toString() {
         return this.unlocalizedName;
      }

      private static void I() {
         I = new String[159 ^ 144];
         I["".length()] = I("!6.6!)'", "eshwt");
         I[" ".length()] = I("\u001c\u0004\u0001\u0016?\u0014\u0015", "xagwJ");
         I["  ".length()] = I("7\u0001,\u000b#?\u0010", "SdJjV");
         I["   ".length()] = I("38#\"3<5.", "ppjqv");
         I[81 ^ 85] = I(" \u001f,\u00015/\u0012!", "CwErP");
         I[111 ^ 106] = I("%\u00041)7*\t<", "FlXZR");
         I[37 ^ 35] = I("!0\u0005\u001562 ", "myKPe");
         I[90 ^ 93] = I("5\u0000\u001f\r\u0011\u0006\u0010", "Yiqhb");
         I[135 ^ 143] = I(">1>';", "RXPBH");
         I[101 ^ 108] = I(";&?6%(7", "woqsv");
         I[84 ^ 94] = I("$\u0005,\u0006\u0015\u0017\u0014", "HlBcf");
         I[162 ^ 169] = I("\n'\u001c\u0002\u0010", "fNrgc");
         I[47 ^ 35] = I("\u0016\u0004\r\u0006\u0000\u0005\u0017", "ZMCCS");
         I[82 ^ 95] = I("\r\u000e;!$>\u001d", "agUDW");
         I[140 ^ 130] = I("5,**'", "YEDOT");
      }

      public String getName() {
         return this.serializedName;
      }
   }
}

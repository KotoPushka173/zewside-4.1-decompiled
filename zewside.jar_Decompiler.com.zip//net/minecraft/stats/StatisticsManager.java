package net.minecraft.stats;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.TupleIntJsonSerializable;

public class StatisticsManager {
   // $FF: synthetic field
   protected final Map<StatBase, TupleIntJsonSerializable> statsData = Maps.newConcurrentMap();
   // $FF: synthetic field
   private static final String[] I;

   public void increaseStat(EntityPlayer var1, StatBase var2, int var3) {
      this.unlockAchievement(var1, var2, this.readStat(var2) + var3);
   }

   public int readStat(StatBase var1) {
      TupleIntJsonSerializable var2 = (TupleIntJsonSerializable)this.statsData.get(var1);
      int var10000;
      if (var2 == null) {
         var10000 = "".length();
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         var10000 = var2.getIntegerValue();
      }

      return var10000;
   }

   public void unlockAchievement(EntityPlayer var1, StatBase var2, int var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      TupleIntJsonSerializable var4 = (TupleIntJsonSerializable)this.statsData.get(var2);
      if (var4 == null) {
         I[118 ^ 114].length();
         I[123 ^ 126].length();
         I[58 ^ 60].length();
         var4 = new TupleIntJsonSerializable();
         this.statsData.put(var2, var4);
         I[84 ^ 83].length();
         I[205 ^ 197].length();
         I[183 ^ 190].length();
      }

      var4.setIntegerValue(var3);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   private static void I() {
      I = new String[64 ^ 74];
      I["".length()] = I("崋恃", "tNEDz");
      I[" ".length()] = I("帏搶", "LGOGN");
      I["  ".length()] = I("搃亡", "mbwdv");
      I["   ".length()] = I("况堮", "uNgJt");
      I[85 ^ 81] = I("妔柺伋媄懄", "flFFu");
      I[51 ^ 54] = I("惻啰攸溫湢", "pOTDP");
      I[12 ^ 10] = I("懱楔垼", "ZORwh");
      I[38 ^ 33] = I("岷嬇揹朢", "BMxPe");
      I[176 ^ 184] = I("枹洧傝暞察", "KnMwl");
      I[127 ^ 118] = I("朌扃乆", "cJyYg");
   }

   static {
      I();
   }
}

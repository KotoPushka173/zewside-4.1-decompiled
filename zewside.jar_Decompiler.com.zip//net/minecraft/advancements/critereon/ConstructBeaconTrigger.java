package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.util.ResourceLocation;

public class ConstructBeaconTrigger implements ICriterionTrigger<ConstructBeaconTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_192181_a;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, ConstructBeaconTrigger.Listeners> field_192182_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<ConstructBeaconTrigger.Instance> var2) {
      ConstructBeaconTrigger.Listeners var3 = (ConstructBeaconTrigger.Listeners)this.field_192182_b.get(var1);
      if (var3 != null) {
         var3.func_192353_b(var2);
         if (var3.func_192354_a()) {
            this.field_192182_b.remove(var1);
            I[96 ^ 105].length();
            I[73 ^ 67].length();
            I[155 ^ 144].length();
         }
      }

   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<ConstructBeaconTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      ConstructBeaconTrigger.Listeners var3 = (ConstructBeaconTrigger.Listeners)this.field_192182_b.get(var1);
      if (var3 == null) {
         I[163 ^ 167].length();
         I[102 ^ 99].length();
         var3 = new ConstructBeaconTrigger.Listeners(var1);
         this.field_192182_b.put(var1, var3);
         I[115 ^ 117].length();
         I[169 ^ 174].length();
         I[125 ^ 117].length();
      }

      var3.func_192355_a(var2);
   }

   public ResourceLocation func_192163_a() {
      return field_192181_a;
   }

   static {
      I();
      field_192181_a = new ResourceLocation(I[64 ^ 87]);
   }

   public void func_192180_a(EntityPlayerMP var1, TileEntityBeacon var2) {
      ConstructBeaconTrigger.Listeners var3 = (ConstructBeaconTrigger.Listeners)this.field_192182_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_192352_a(var2);
      }

   }

   private static void I() {
      I = new String[75 ^ 83];
      I["".length()] = I("戒櫌", "enohk");
      I[" ".length()] = I("帞晗", "cHbnS");
      I["  ".length()] = I("煝圫", "dianQ");
      I["   ".length()] = I("涠昇", "vSNdW");
      I[32 ^ 36] = I("姗挂慥涗", "HhjWn");
      I[105 ^ 108] = I("壠噠嫪暹咍", "hJPlx");
      I[195 ^ 197] = I("揬惀匙他柛", "mazru");
      I[62 ^ 57] = I("汾孝橆倪", "NhguB");
      I[100 ^ 108] = I("嗽健洑渒案", "ZzJqG");
      I[15 ^ 6] = I("壽奶", "Vqbhv");
      I[54 ^ 60] = I("娇", "VwQRZ");
      I[152 ^ 147] = I("困搋剹擾", "FQvUI");
      I[25 ^ 21] = I("彐沝椋抮", "byrKF");
      I[13 ^ 0] = I("晠", "oiKjJ");
      I[121 ^ 119] = I("垶宴坤嵢慔", "cHhvk");
      I[130 ^ 141] = I("浙梅佷动", "RmZLc");
      I[169 ^ 185] = I("濠彧", "rgGFh");
      I[177 ^ 160] = I("偞根", "qvLwJ");
      I[175 ^ 189] = I("斋榯", "YRchh");
      I[123 ^ 104] = I("吟客", "RkiUJ");
      I[77 ^ 89] = I("\u00153/3\r", "yVYVa");
      I[114 ^ 103] = I("挮", "MiKbp");
      I[152 ^ 142] = I("喡", "Dakke");
      I[81 ^ 70] = I("\u0002.\u000b$\u0005\u00134\u0006#.\u0003$\u00044\u001e\u000f", "aAeWq");
   }

   public ConstructBeaconTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[98 ^ 114];
      String var10001 = I[115 ^ 98];
      String var10002 = I[16 ^ 2];
      var10001 = I[13 ^ 30];
      MinMaxBounds var3 = MinMaxBounds.func_192515_a(var1.get(I[7 ^ 19]));
      I[97 ^ 116].length();
      I[34 ^ 52].length();
      return new ConstructBeaconTrigger.Instance(var3);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 1);

      throw null;
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192182_b.remove(var1);
      I[146 ^ 158].length();
      I[148 ^ 153].length();
      I[29 ^ 19].length();
      I[205 ^ 194].length();
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final MinMaxBounds field_192253_a;

      public boolean func_192252_a(TileEntityBeacon var1) {
         return this.field_192253_a.func_192514_a((float)var1.func_191979_s());
      }

      public Instance(MinMaxBounds var1) {
         super(ConstructBeaconTrigger.field_192181_a);
         this.field_192253_a = var1;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 == -1);

         throw null;
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_192356_a;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<ConstructBeaconTrigger.Instance>> field_192357_b = Sets.newHashSet();

      public boolean func_192354_a() {
         return this.field_192357_b.isEmpty();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(true);

         throw null;
      }

      static {
         I();
      }

      public void func_192352_a(TileEntityBeacon var1) {
         ArrayList var2 = null;
         Iterator var3 = this.field_192357_b.iterator();

         ICriterionTrigger.Listener var4;
         while(var3.hasNext()) {
            var4 = (ICriterionTrigger.Listener)var3.next();
            if (((ConstructBeaconTrigger.Instance)var4.func_192158_a()).func_192252_a(var1)) {
               if (var2 == null) {
                  var2 = Lists.newArrayList();
               }

               var2.add(var4);
               I[81 ^ 84].length();
            }

            "".length();
            if (4 == 2) {
               throw null;
            }
         }

         if (var2 != null) {
            var3 = var2.iterator();

            while(var3.hasNext()) {
               var4 = (ICriterionTrigger.Listener)var3.next();
               var4.func_192159_a(this.field_192356_a);
               "".length();
               if (4 != 4) {
                  throw null;
               }
            }
         }

      }

      private static void I() {
         I = new String[93 ^ 91];
         I["".length()] = I("哰汆乱仑", "TGAjw");
         I[" ".length()] = I("淂涇戽", "JITnb");
         I["  ".length()] = I("烒橞嗋偰旺", "nGhaW");
         I["   ".length()] = I("杦渾", "Lsxiz");
         I[100 ^ 96] = I("媐団寗", "PshWS");
         I[154 ^ 159] = I("檒嫎滑漏", "puzKO");
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192356_a = var1;
      }

      public void func_192355_a(ICriterionTrigger.Listener<ConstructBeaconTrigger.Instance> var1) {
         this.field_192357_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }

      public void func_192353_b(ICriterionTrigger.Listener<ConstructBeaconTrigger.Instance> var1) {
         this.field_192357_b.remove(var1);
         I[167 ^ 163].length();
      }
   }
}

package net.minecraft.block;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockWall extends Block {
   // $FF: synthetic field
   public static final PropertyBool UP;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] CLIP_AABB_BY_INDEX;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] AABB_BY_INDEX;
   // $FF: synthetic field
   public static final PropertyBool NORTH;
   // $FF: synthetic field
   public static final PropertyEnum<BlockWall.EnumType> VARIANT;
   // $FF: synthetic field
   public static final PropertyBool SOUTH;
   // $FF: synthetic field
   public static final PropertyBool WEST;
   // $FF: synthetic field
   public static final PropertyBool EAST;

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected static boolean func_194143_e(Block var0) {
      int var10000;
      if (!Block.func_193382_c(var0) && var0 != Blocks.BARRIER && var0 != Blocks.MELON_BLOCK && var0 != Blocks.PUMPKIN && var0 != Blocks.LIT_PUMPKIN) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockWall.EnumType.byMetadata(var1));
   }

   private static void I() {
      I = new String[64 ^ 11];
      I["".length()] = I("佯奊", "IhmRK");
      I[" ".length()] = I("寥泏", "uGsFu");
      I["  ".length()] = I("慓搐", "wcHtU");
      I["   ".length()] = I("妓怏", "AMSWO");
      I[100 ^ 96] = I("卞憁", "NpNvE");
      I[81 ^ 84] = I("h", "FGkgw");
      I[198 ^ 192] = I("\\9\u0016\u001f5", "rWwrP");
      I[70 ^ 65] = I("櫎因", "mvhkz");
      I[110 ^ 102] = I("曮找", "ZRRAJ");
      I[44 ^ 37] = I("呐塿", "cajKZ");
      I[84 ^ 94] = I("呿僳", "hEdXL");
      I[27 ^ 16] = I("喐湕婒", "MuBEB");
      I[181 ^ 185] = I("惈曪椷桷", "LOAvL");
      I[84 ^ 89] = I("去择嚋沍囎", "kLlGD");
      I[28 ^ 18] = I("你", "jKeHF");
      I[94 ^ 81] = I("巧掽", "QCiWX");
      I[18 ^ 2] = I("棲浼攠椝峏", "nkhGN");
      I[212 ^ 197] = I("叧佋嚠槜嫍", "NzGgi");
      I[140 ^ 158] = I("瀭暎尒", "PkskA");
      I[147 ^ 128] = I("喂忦姙募", "eaaQE");
      I[49 ^ 37] = I("斓啽", "UvyhZ");
      I[110 ^ 123] = I("垈僰", "vEwDH");
      I[131 ^ 149] = I("傑剷", "gPRXh");
      I[190 ^ 169] = I("擈娐", "Gqkzq");
      I[84 ^ 76] = I("彴圧", "cXDqC");
      I[29 ^ 4] = I("实枅", "pkExm");
      I[24 ^ 2] = I("扌昕", "kxFly");
      I[40 ^ 51] = I("匟哾", "rYijo");
      I[105 ^ 117] = I("允奂", "DHPXO");
      I[61 ^ 32] = I("勼岾", "ZKDzG");
      I[38 ^ 56] = I("偪備", "MPDxd");
      I[107 ^ 116] = I("呙噅", "hNKMY");
      I[108 ^ 76] = I("仮幂", "XYqGn");
      I[4 ^ 37] = I("惂恡", "hzkrQ");
      I[137 ^ 171] = I("滍嬏", "IwGGk");
      I[42 ^ 9] = I("帜忚", "wQfmM");
      I[111 ^ 75] = I("墆炚", "whlGh");
      I[175 ^ 138] = I("炐拭", "UDfuV");
      I[69 ^ 99] = I("可昃", "XLKoB");
      I[7 ^ 32] = I("榎歕", "ecolG");
      I[141 ^ 165] = I("櫒憼", "cthUV");
      I[150 ^ 191] = I("桔嶩", "Vjqsl");
      I[90 ^ 112] = I("曈樼", "uPaBM");
      I[111 ^ 68] = I("旆佸", "jVDvv");
      I[142 ^ 162] = I("攀卒", "gByxN");
      I[46 ^ 3] = I("坳寖", "ZcgYl");
      I[95 ^ 113] = I("涧溉", "nGewM");
      I[187 ^ 148] = I("捧桾", "IvPzU");
      I[108 ^ 92] = I("樫屯堵侂傳", "WfDzs");
      I[0 ^ 49] = I("欩", "gONNI");
      I[101 ^ 87] = I("掉滌懎墯嘁", "YQDGN");
      I[186 ^ 137] = I("淇氞", "MnAEy");
      I[13 ^ 57] = I("帱咸", "GcxaR");
      I[132 ^ 177] = I("彸汇伽撥奺", "iPMtV");
      I[56 ^ 14] = I("坹嫤揔液", "NTmtE");
      I[126 ^ 73] = I("柔摨弖巒渒", "TzQfQ");
      I[153 ^ 161] = I("恇嘴", "kVaso");
      I[183 ^ 142] = I("協", "cnjGF");
      I[158 ^ 164] = I("曻崸拱套", "ObKRB");
      I[102 ^ 93] = I("濯", "mgbRY");
      I[99 ^ 95] = I("厖宼楐", "OxpSY");
      I[252 ^ 193] = I("偐塮嫄", "WhVuc");
      I[140 ^ 178] = I("倪掣奟", "GJVjt");
      I[44 ^ 19] = I("楀", "OiwxM");
      I[93 ^ 29] = I("崟濰両", "gQjrF");
      I[208 ^ 145] = I("椙嫮", "ZBdpr");
      I[66 ^ 0] = I("橗呕", "XAHRi");
      I[82 ^ 17] = I("博坟炇弬", "KYrqc");
      I[212 ^ 144] = I("撑勉姧喫", "mBMjm");
      I[241 ^ 180] = I("/\u0000", "ZpNed");
      I[58 ^ 124] = I(")\u0019!6'", "GvSBO");
      I[208 ^ 151] = I("6&#&", "SGPRA");
      I[218 ^ 146] = I("\n\u001e\u0017.\u000e", "yqbZf");
      I[206 ^ 135] = I("\u000f3\u00067", "xVuCg");
      I[224 ^ 170] = I("2\u0012\u001a;\u0002*\u0007", "DshRc");
   }

   private static int getAABBIndex(IBlockState var0) {
      int var1 = "".length();
      if ((Boolean)var0.getValue(NORTH)) {
         var1 |= " ".length() << EnumFacing.NORTH.getHorizontalIndex();
      }

      if ((Boolean)var0.getValue(EAST)) {
         var1 |= " ".length() << EnumFacing.EAST.getHorizontalIndex();
      }

      if ((Boolean)var0.getValue(SOUTH)) {
         var1 |= " ".length() << EnumFacing.SOUTH.getHorizontalIndex();
      }

      if ((Boolean)var0.getValue(WEST)) {
         var1 |= " ".length() << EnumFacing.WEST.getHorizontalIndex();
      }

      return var1;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[93 ^ 73];
      String var10001 = I[32 ^ 53];
      String var10002 = I[113 ^ 103];
      var10001 = I[121 ^ 110];
      var10000 = I[179 ^ 171];
      var10001 = I[147 ^ 138];
      var10002 = I[118 ^ 108];
      var10001 = I[20 ^ 15];
      var10000 = I[76 ^ 80];
      var10001 = I[143 ^ 146];
      var10002 = I[48 ^ 46];
      var10001 = I[150 ^ 137];
      var10000 = I[188 ^ 156];
      var10001 = I[53 ^ 20];
      var10002 = I[32 ^ 2];
      var10001 = I[89 ^ 122];
      var10000 = I[0 ^ 36];
      var10001 = I[227 ^ 198];
      var10002 = I[226 ^ 196];
      var10001 = I[29 ^ 58];
      var10000 = I[178 ^ 154];
      var10001 = I[232 ^ 193];
      var10002 = I[63 ^ 21];
      var10001 = I[56 ^ 19];
      var10000 = I[30 ^ 50];
      var10001 = I[108 ^ 65];
      var10002 = I[30 ^ 48];
      var10001 = I[118 ^ 89];
      I[136 ^ 184].length();
      I[125 ^ 76].length();
      I[163 ^ 145].length();
      I[98 ^ 81].length();
      IProperty[] var10003 = new IProperty[93 ^ 91];
      I[49 ^ 5].length();
      I[151 ^ 162].length();
      var10003["".length()] = UP;
      I[131 ^ 181].length();
      I[29 ^ 42].length();
      I[32 ^ 24].length();
      var10003[" ".length()] = NORTH;
      I[85 ^ 108].length();
      I[127 ^ 69].length();
      I[33 ^ 26].length();
      I[97 ^ 93].length();
      var10003["  ".length()] = EAST;
      I[59 ^ 6].length();
      I[4 ^ 58].length();
      I[22 ^ 41].length();
      var10003["   ".length()] = WEST;
      I[194 ^ 130].length();
      I[100 ^ 37].length();
      I[25 ^ 91].length();
      I[113 ^ 50].length();
      var10003[108 ^ 104] = SOUTH;
      I[109 ^ 41].length();
      var10003[46 ^ 43] = VARIANT;
      return new BlockStateContainer(this, var10003);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private boolean canConnectTo(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
      IBlockState var4 = var1.getBlockState(var2);
      Block var5 = var4.getBlock();
      BlockFaceShape var6 = var4.func_193401_d(var1, var2, var3);
      int var10000;
      if (var6 != BlockFaceShape.MIDDLE_POLE_THICK && (var6 != BlockFaceShape.MIDDLE_POLE || !(var5 instanceof BlockFenceGate))) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (0 >= 2) {
            throw null;
         }
      }

      int var7 = var10000;
      if ((func_194143_e(var5) || var6 != BlockFaceShape.SOLID) && var7 == 0) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (4 != 4) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      if (!var7) {
         var1 = this.getActualState(var1, var2, var3);
      }

      addCollisionBoxToList(var3, var4, var5, CLIP_AABB_BY_INDEX[getAABBIndex(var1)]);
   }

   static {
      I();
      UP = PropertyBool.create(I[24 ^ 93]);
      NORTH = PropertyBool.create(I[86 ^ 16]);
      EAST = PropertyBool.create(I[40 ^ 111]);
      SOUTH = PropertyBool.create(I[242 ^ 186]);
      WEST = PropertyBool.create(I[211 ^ 154]);
      VARIANT = PropertyEnum.create(I[52 ^ 126], BlockWall.EnumType.class);
      AxisAlignedBB[] var10000 = new AxisAlignedBB[0 ^ 16];
      var10000["".length()] = new AxisAlignedBB(0.25D, 0.0D, 0.25D, 0.75D, 1.0D, 0.75D);
      var10000[" ".length()] = new AxisAlignedBB(0.25D, 0.0D, 0.25D, 0.75D, 1.0D, 1.0D);
      var10000["  ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.25D, 0.75D, 1.0D, 0.75D);
      var10000["   ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.25D, 0.75D, 1.0D, 1.0D);
      var10000[115 ^ 119] = new AxisAlignedBB(0.25D, 0.0D, 0.0D, 0.75D, 1.0D, 0.75D);
      var10000[15 ^ 10] = new AxisAlignedBB(0.3125D, 0.0D, 0.0D, 0.6875D, 0.875D, 1.0D);
      var10000[37 ^ 35] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.75D, 1.0D, 0.75D);
      var10000[138 ^ 141] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.75D, 1.0D, 1.0D);
      var10000[143 ^ 135] = new AxisAlignedBB(0.25D, 0.0D, 0.25D, 1.0D, 1.0D, 0.75D);
      var10000[163 ^ 170] = new AxisAlignedBB(0.25D, 0.0D, 0.25D, 1.0D, 1.0D, 1.0D);
      var10000[67 ^ 73] = new AxisAlignedBB(0.0D, 0.0D, 0.3125D, 1.0D, 0.875D, 0.6875D);
      var10000[142 ^ 133] = new AxisAlignedBB(0.0D, 0.0D, 0.25D, 1.0D, 1.0D, 1.0D);
      var10000[83 ^ 95] = new AxisAlignedBB(0.25D, 0.0D, 0.0D, 1.0D, 1.0D, 0.75D);
      var10000[32 ^ 45] = new AxisAlignedBB(0.25D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      var10000[78 ^ 64] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.75D);
      var10000[10 ^ 5] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      AABB_BY_INDEX = var10000;
      var10000 = new AxisAlignedBB[134 ^ 150];
      var10000["".length()] = AABB_BY_INDEX["".length()].setMaxY(1.5D);
      var10000[" ".length()] = AABB_BY_INDEX[" ".length()].setMaxY(1.5D);
      var10000["  ".length()] = AABB_BY_INDEX["  ".length()].setMaxY(1.5D);
      var10000["   ".length()] = AABB_BY_INDEX["   ".length()].setMaxY(1.5D);
      var10000[153 ^ 157] = AABB_BY_INDEX[66 ^ 70].setMaxY(1.5D);
      var10000[46 ^ 43] = AABB_BY_INDEX[67 ^ 70].setMaxY(1.5D);
      var10000[168 ^ 174] = AABB_BY_INDEX[188 ^ 186].setMaxY(1.5D);
      var10000[127 ^ 120] = AABB_BY_INDEX[86 ^ 81].setMaxY(1.5D);
      var10000[39 ^ 47] = AABB_BY_INDEX[57 ^ 49].setMaxY(1.5D);
      var10000[150 ^ 159] = AABB_BY_INDEX[174 ^ 167].setMaxY(1.5D);
      var10000[116 ^ 126] = AABB_BY_INDEX[40 ^ 34].setMaxY(1.5D);
      var10000[182 ^ 189] = AABB_BY_INDEX[85 ^ 94].setMaxY(1.5D);
      var10000[34 ^ 46] = AABB_BY_INDEX[24 ^ 20].setMaxY(1.5D);
      var10000[2 ^ 15] = AABB_BY_INDEX[30 ^ 19].setMaxY(1.5D);
      var10000[158 ^ 144] = AABB_BY_INDEX[105 ^ 103].setMaxY(1.5D);
      var10000[100 ^ 107] = AABB_BY_INDEX[11 ^ 4].setMaxY(1.5D);
      CLIP_AABB_BY_INDEX = var10000;
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockWall.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      var1 = this.getActualState(var1, var2, var3);
      return CLIP_AABB_BY_INDEX[getAABBIndex(var1)];
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[100 ^ 99];
      String var10001 = I[113 ^ 121];
      String var10002 = I[10 ^ 3];
      var10001 = I[57 ^ 51];
      BlockWall.EnumType[] var3 = BlockWall.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockWall.EnumType var6 = var3[var5];
         I[94 ^ 85].length();
         I[38 ^ 42].length();
         I[165 ^ 168].length();
         I[156 ^ 146].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[170 ^ 165].length();
         I[100 ^ 116].length();
         I[159 ^ 142].length();
         I[112 ^ 98].length();
         I[127 ^ 108].length();
         ++var5;
         "".length();
      } while(3 > -1);

      throw null;
   }

   public String getLocalizedName() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[13 ^ 9].length();
      return I18n.translateToLocal(this.getUnlocalizedName() + I[61 ^ 56] + BlockWall.EnumType.NORMAL.getUnlocalizedName() + I[75 ^ 77]);
   }

   public BlockWall(Block var1) {
      super(var1.blockMaterial);
      this.setDefaultState(this.blockState.getBaseState().withProperty(UP, Boolean.valueOf((boolean)"".length())).withProperty(NORTH, Boolean.valueOf((boolean)"".length())).withProperty(EAST, Boolean.valueOf((boolean)"".length())).withProperty(SOUTH, Boolean.valueOf((boolean)"".length())).withProperty(WEST, Boolean.valueOf((boolean)"".length())).withProperty(VARIANT, BlockWall.EnumType.NORMAL));
      this.setHardness(var1.blockHardness);
      this.setResistance(var1.blockResistance / 3.0F);
      this.setSoundType(var1.blockSoundType);
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      return (boolean)"".length();
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      var1 = this.getActualState(var1, var2, var3);
      return AABB_BY_INDEX[getAABBIndex(var1)];
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockWall.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = super.shouldSideBeRendered(var1, var2, var3, var4);
         "".length();
         if (3 < -1) {
            throw null;
         }
      } else {
         var10000 = " ".length();
      }

      return (boolean)var10000;
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      boolean var4 = this.canConnectTo(var2, var3.north(), EnumFacing.SOUTH);
      boolean var5 = this.canConnectTo(var2, var3.east(), EnumFacing.WEST);
      boolean var6 = this.canConnectTo(var2, var3.south(), EnumFacing.NORTH);
      boolean var7 = this.canConnectTo(var2, var3.west(), EnumFacing.EAST);
      int var10000;
      if ((!var4 || var5 || !var6 || var7) && (var4 || !var5 || var6 || !var7)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (0 >= 2) {
            throw null;
         }
      }

      int var8 = var10000;
      PropertyBool var10001 = UP;
      int var10002;
      if (var8 != 0 && var2.isAirBlock(var3.up())) {
         var10002 = "".length();
      } else {
         var10002 = " ".length();
         "".length();
         if (0 >= 3) {
            throw null;
         }
      }

      return var1.withProperty(var10001, Boolean.valueOf((boolean)var10002)).withProperty(NORTH, var4).withProperty(EAST, var5).withProperty(SOUTH, var6).withProperty(WEST, var7);
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 != EnumFacing.UP && var4 != EnumFacing.DOWN) {
         var10000 = BlockFaceShape.MIDDLE_POLE_THICK;
         "".length();
         if (2 < -1) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.CENTER_BIG;
      }

      return var10000;
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      MOSSY;

      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      NORMAL;

      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final String name;

      public String getName() {
         return this.name;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      private static void I() {
         I = new String[46 ^ 40];
         I["".length()] = I("\n7<\u000b\u0002\b", "DxnFC");
         I[" ".length()] = I("\u0010\u0005&\u00125\u0016\u00190\u001f7\u0016", "sjDpY");
         I["  ".length()] = I("\u001d5\u001f>\u000f\u001f", "sZmSn");
         I["   ".length()] = I(".\u001f1\u0010\f", "cPbCU");
         I[2 ^ 6] = I(".\u0000%&6\u001c\f97-/\n%! -\n", "CoVUO");
         I[78 ^ 75] = I("\n\u0000*\u00152", "goYfK");
      }

      static {
         I();
         NORMAL = new BlockWall.EnumType(I["".length()], "".length(), "".length(), I[" ".length()], I["  ".length()]);
         MOSSY = new BlockWall.EnumType(I["   ".length()], " ".length(), " ".length(), I[82 ^ 86], I[14 ^ 11]);
         BlockWall.EnumType[] var10000 = new BlockWall.EnumType["  ".length()];
         var10000["".length()] = NORMAL;
         var10000[" ".length()] = MOSSY;
         BlockWall.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockWall.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(-1 == -1);

         throw null;
      }

      private EnumType(int var3, String var4, String var5) {
         this.meta = var3;
         this.name = var4;
         this.unlocalizedName = var5;
      }

      public int getMetadata() {
         return this.meta;
      }

      public static BlockWall.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 < 0);

         throw null;
      }

      public String toString() {
         return this.name;
      }
   }
}

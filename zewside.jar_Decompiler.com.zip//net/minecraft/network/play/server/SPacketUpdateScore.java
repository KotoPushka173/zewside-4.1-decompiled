package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;

public class SPacketUpdateScore implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private String objective;
   // $FF: synthetic field
   private int value;
   // $FF: synthetic field
   private String name;
   // $FF: synthetic field
   private SPacketUpdateScore.Action action;

   public SPacketUpdateScore(Score var1) {
      this.name = I["  ".length()];
      this.objective = I["   ".length()];
      this.name = var1.getPlayerName();
      this.objective = var1.getObjective().getName();
      this.value = var1.getScorePoints();
      this.action = SPacketUpdateScore.Action.CHANGE;
   }

   public String getPlayerName() {
      return this.name;
   }

   public int getScoreValue() {
      return this.value;
   }

   public SPacketUpdateScore.Action getScoreAction() {
      return this.action;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.name = var1.readStringFromBuffer(106 ^ 66);
      this.action = (SPacketUpdateScore.Action)var1.readEnumValue(SPacketUpdateScore.Action.class);
      this.objective = var1.readStringFromBuffer(126 ^ 110);
      if (this.action != SPacketUpdateScore.Action.REMOVE) {
         this.value = var1.readVarIntFromBuffer();
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   public SPacketUpdateScore(String var1, ScoreObjective var2) {
      this.name = I[129 ^ 134];
      this.objective = I[78 ^ 70];
      this.name = var1;
      this.objective = var2.getName();
      this.value = "".length();
      this.action = SPacketUpdateScore.Action.REMOVE;
   }

   public String getObjectiveName() {
      return this.objective;
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.name);
      I[156 ^ 149].length();
      I[187 ^ 177].length();
      I[101 ^ 110].length();
      I[121 ^ 117].length();
      I[49 ^ 60].length();
      var1.writeEnumValue(this.action);
      I[49 ^ 63].length();
      I[55 ^ 56].length();
      I[128 ^ 144].length();
      var1.writeString(this.objective);
      I[55 ^ 38].length();
      if (this.action != SPacketUpdateScore.Action.REMOVE) {
         var1.writeVarIntToBuffer(this.value);
         I[54 ^ 36].length();
         I[144 ^ 131].length();
      }

   }

   public SPacketUpdateScore(String var1) {
      this.name = I[155 ^ 159];
      this.objective = I[167 ^ 162];
      this.name = var1;
      this.objective = I[83 ^ 85];
      this.value = "".length();
      this.action = SPacketUpdateScore.Action.REMOVE;
   }

   public SPacketUpdateScore() {
      this.name = I["".length()];
      this.objective = I[" ".length()];
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleUpdateScore(this);
   }

   private static void I() {
      I = new String[74 ^ 94];
      I["".length()] = I("", "ebJrj");
      I[" ".length()] = I("", "LORfN");
      I["  ".length()] = I("", "JKEcW");
      I["   ".length()] = I("", "yubVt");
      I[165 ^ 161] = I("", "fCHDG");
      I[53 ^ 48] = I("", "PRIZb");
      I[85 ^ 83] = I("", "PuGHG");
      I[189 ^ 186] = I("", "UMEQZ");
      I[165 ^ 173] = I("", "wbxaS");
      I[81 ^ 88] = I("溣庾傁戻", "yvZmN");
      I[3 ^ 9] = I("兼柄次埖", "Xhzsv");
      I[31 ^ 20] = I("垑傄栍撂氚", "fOTBG");
      I[108 ^ 96] = I("啇滯徦姓", "WQifB");
      I[146 ^ 159] = I("棗忬", "wxbIN");
      I[186 ^ 180] = I("喛弱濂懊庑", "vDXkC");
      I[122 ^ 117] = I("墐架", "vToiP");
      I[103 ^ 119] = I("唃吶捓", "FLUmP");
      I[49 ^ 32] = I("憹创擣庞徱", "lDUbm");
      I[121 ^ 107] = I("挫岑歆幇扸", "RnkwK");
      I[4 ^ 23] = I("嫧", "qCzlr");
   }

   public static enum Action {
      // $FF: synthetic field
      CHANGE,
      // $FF: synthetic field
      REMOVE;

      // $FF: synthetic field
      private static final String[] I;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 >= 4);

         throw null;
      }

      static {
         I();
         CHANGE = new SPacketUpdateScore.Action(I["".length()], "".length());
         REMOVE = new SPacketUpdateScore.Action(I[" ".length()], " ".length());
         SPacketUpdateScore.Action[] var10000 = new SPacketUpdateScore.Action["  ".length()];
         var10000["".length()] = CHANGE;
         var10000[" ".length()] = REMOVE;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I("\u001b\u001a\t\u0014\u001d\u001d", "XRHZZ");
         I[" ".length()] = I("5\b<\u0003:\"", "gMqLl");
      }
   }
}

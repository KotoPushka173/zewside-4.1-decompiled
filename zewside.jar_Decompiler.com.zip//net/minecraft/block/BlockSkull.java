package net.minecraft.block;

import com.google.common.base.Predicate;
import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockMaterialMatcher;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.block.state.pattern.BlockStateMatcher;
import net.minecraft.block.state.pattern.FactoryBlockPattern;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockSkull extends BlockContainer {
   // $FF: synthetic field
   protected static final AxisAlignedBB SOUTH_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool NODROP;
   // $FF: synthetic field
   protected static final AxisAlignedBB DEFAULT_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB EAST_AABB;
   // $FF: synthetic field
   private BlockPattern witherBasePattern;
   // $FF: synthetic field
   private static final Predicate<BlockWorldState> IS_WITHER_SKELETON;
   // $FF: synthetic field
   protected static final AxisAlignedBB NORTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB WEST_AABB;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   private BlockPattern witherPattern;

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.SKULL;
   }

   private static void I() {
      I = new String[223 ^ 172];
      I["".length()] = I("%\u0006\u001d\u0010^\"\u0004\u0004\u0019\u001c\u007f\u001c\u001a\u0010\u001c4\u001b\u001e\u001b^?\u000e\u001c\u0010", "Qoqup");
      I[" ".length()] = I("婰暞", "IQaTg");
      I["  ".length()] = I("灅偷", "lWYMP");
      I["   ".length()] = I("姈嶽", "DnBDk");
      I[126 ^ 122] = I("佢尟", "xoopK");
      I[79 ^ 74] = I("椔埍堅弐", "UpecT");
      I[141 ^ 139] = I("勇滟惞涞囘", "foPzZ");
      I[128 ^ 135] = I("侦慃", "qOIsd");
      I[94 ^ 86] = I("刯枎", "xeNCA");
      I[112 ^ 121] = I("攧匄", "khSJF");
      I[207 ^ 197] = I("佸倸", "HMfQu");
      I[24 ^ 19] = I("氵", "ETETc");
      I[2 ^ 14] = I("噃", "rZtvq");
      I[16 ^ 29] = I("崀呇拕徛忉", "dMBSP");
      I[82 ^ 92] = I("左姟", "rEGZE");
      I[5 ^ 10] = I("唨匵", "OAKTO");
      I[58 ^ 42] = I("囎嗉", "iSiGq");
      I[165 ^ 180] = I("澅桲", "jAgse");
      I[14 ^ 28] = I("仨澶", "MnRbh");
      I[167 ^ 180] = I("儁娤", "cNDJy");
      I[103 ^ 115] = I("墹凣", "lOuPI");
      I[11 ^ 30] = I("亨橘", "IFqpF");
      I[57 ^ 47] = I("女桻壩楃", "eReRl");
      I[37 ^ 50] = I("圎帖严炚", "BDMQB");
      I[22 ^ 14] = I("徺嗈", "gzRwt");
      I[59 ^ 34] = I("吼", "EAvWE");
      I[70 ^ 92] = I("撲炞峦捁", "uHAdR");
      I[219 ^ 192] = I("摻凜庩冊凶", "AXUki");
      I[54 ^ 42] = I("桎冗懘", "NpNxY");
      I[160 ^ 189] = I("嶹乮", "CKYUf");
      I[134 ^ 152] = I("嫎渪敿", "agYTi");
      I[39 ^ 56] = I("\u001e#\u001a>\u0018\u0002?\u00017\u0006", "MHoRt");
      I[48 ^ 16] = I("櫗圳", "DNEmK");
      I[67 ^ 98] = I("俶仐", "BeNRA");
      I[85 ^ 119] = I("孑彥", "UdqCV");
      I[24 ^ 59] = I("棹伛", "ZJoWw");
      I[27 ^ 63] = I("湾嚡殸毡", "XMFwQ");
      I[96 ^ 69] = I("夑哅朦忲沚", "JLwjf");
      I[9 ^ 47] = I("瀊漽", "kQMZn");
      I[228 ^ 195] = I("櫦呕", "Yjwvt");
      I[33 ^ 9] = I("抂咴妊僯捫", "bNXVH");
      I[75 ^ 98] = I("淊厪沎儔", "MNigA");
      I[32 ^ 10] = I("榴媣既昆気", "BBrWF");
      I[46 ^ 5] = I("傮毸", "xPlgL");
      I[186 ^ 150] = I("斫夈", "qJiLf");
      I[94 ^ 115] = I("匳浸吋昃", "BTMXj");
      I[160 ^ 142] = I("僝忉心姼夦", "kskqr");
      I[125 ^ 82] = I("垣橳劕", "oLjRX");
      I[163 ^ 147] = I("依倇揃", "SFzTs");
      I[159 ^ 174] = I("典抵", "rjUGJ");
      I[144 ^ 162] = I("冎嚼", "JsSiK");
      I[15 ^ 60] = I("昞敒", "LFIUI");
      I[26 ^ 46] = I("墨忧", "yLAvW");
      I[56 ^ 13] = I("嵓児", "kZDVb");
      I[185 ^ 143] = I("火媨", "aEDME");
      I[58 ^ 13] = I("嶨囝", "Nemar");
      I[248 ^ 192] = I("捺卮", "EyyiV");
      I[55 ^ 14] = I("榩崩", "uVKdL");
      I[138 ^ 176] = I("抍忦", "iCIKb");
      I[105 ^ 82] = I("涬撀", "lmjxV");
      I[91 ^ 103] = I("妞圗", "CMEVu");
      I[174 ^ 147] = I("先暪夕榦", "QsQmj");
      I[126 ^ 64] = I("徨孱槞暨傺", "mIOre");
      I[152 ^ 167] = I("刘塿嶢婶炮", "Oydan");
      I[39 ^ 103] = I("拥", "luszy");
      I[61 ^ 124] = I("嚁嬪太傥", "uSewa");
      I[109 ^ 47] = I("撦毯焔", "nwTCt");
      I[214 ^ 149] = I("圯儜", "nMxqk");
      I[113 ^ 53] = I("傑儖", "qaErY");
      I[61 ^ 120] = I("暗偟", "RXEdf");
      I[214 ^ 144] = I("樥喪", "tWSkU");
      I[81 ^ 22] = I("巧歒", "DytUL");
      I[88 ^ 16] = I("婶偞", "nBLyx");
      I[42 ^ 99] = I("嘛烀", "BXVxt");
      I[64 ^ 10] = I("哵囃", "EhArg");
      I[10 ^ 65] = I("楞圌", "uyTjH");
      I[24 ^ 84] = I("揵惎", "OYDYc");
      I[252 ^ 177] = I("沅僦", "hVWCw");
      I[47 ^ 97] = I("喀当", "GuQpZ");
      I[206 ^ 129] = I("湉橗", "Qadmn");
      I[124 ^ 44] = I("旼懶俻叩烦", "JyYiH");
      I[216 ^ 137] = I("住園", "esLzO");
      I[66 ^ 16] = I("WKb", "wkBET");
      I[123 ^ 40] = I("欤", "juWqj");
      I[215 ^ 131] = I("帓唅傤暁", "xgPJS");
      I[121 ^ 44] = I("劼", "etOwO");
      I[240 ^ 166] = I("KWg", "htDgw");
      I[15 ^ 88] = I("屴怚僆榗", "dPrjR");
      I[216 ^ 128] = I("唊廢泔氩", "oZAAj");
      I[12 ^ 85] = I("濴厎峯側借", "kKuRf");
      I[152 ^ 194] = I("7Q&", "IrXMP");
      I[121 ^ 34] = I("檕嬡", "kiTrv");
      I[231 ^ 187] = I("姛炧", "eBwkv");
      I[46 ^ 115] = I("堵毀", "omEoS");
      I[205 ^ 147] = I("榮奇", "qJUWQ");
      I[119 ^ 40] = I("奚凳", "oSqfa");
      I[192 ^ 160] = I("潘冕", "MTISg");
      I[232 ^ 137] = I("屹坘", "THJcd");
      I[83 ^ 49] = I("朴嬭", "eUBAo");
      I[23 ^ 116] = I("姶掲", "vzJrI");
      I[19 ^ 119] = I("冄徉", "ezTqV");
      I[115 ^ 22] = I("潡沊", "RsjUr");
      I[124 ^ 26] = I("岵湫", "GZdno");
      I[235 ^ 140] = I("此弒", "kVLKy");
      I[30 ^ 118] = I("斯奮槭", "ELYhP");
      I[113 ^ 24] = I("暦灯", "AIfBU");
      I[200 ^ 162] = I("(1\u0019", "voGWl");
      I[22 ^ 125] = I("嘓媜昸堺", "cwTsw");
      I[48 ^ 92] = I("jwb", "ITAOd");
      I[241 ^ 156] = I("亅添以", "OhFMK");
      I[124 ^ 18] = I("拆拤澅棇婤", "QCZmn");
      I[235 ^ 132] = I("溡", "mBpBK");
      I[202 ^ 186] = I("撆戌娤冘", "Rhmmz");
      I[233 ^ 152] = I("?a6", "ABHkf");
      I[217 ^ 171] = I("; #\"&%", "UOGPI");
   }

   public boolean canDispenserPlace(World var1, BlockPos var2, ItemStack var3) {
      if (var3.getMetadata() == " ".length() && var2.getY() >= "  ".length() && var1.getDifficulty() != EnumDifficulty.PEACEFUL && !var1.isRemote) {
         int var10000;
         if (this.getWitherBasePattern().match(var1, var2) != null) {
            var10000 = " ".length();
            "".length();
            if (3 < -1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      } else {
         return (boolean)"".length();
      }
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[123 ^ 74];
      String var10001 = I[111 ^ 93];
      String var10002 = I[187 ^ 136];
      var10001 = I[66 ^ 118];
      var10000 = I[132 ^ 177];
      var10001 = I[14 ^ 56];
      var10002 = I[161 ^ 150];
      var10001 = I[133 ^ 189];
      var10000 = I[179 ^ 138];
      var10001 = I[145 ^ 171];
      var10002 = I[1 ^ 58];
      var10001 = I[167 ^ 155];
      I[132 ^ 185].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[73 ^ 119].length();
      I[122 ^ 69].length();
      I[51 ^ 115].length();
      var10003["".length()] = FACING;
      I[135 ^ 198].length();
      I[14 ^ 76].length();
      var10003[" ".length()] = NODROP;
      return new BlockStateContainer(this, var10003);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
      default:
         return DEFAULT_AABB;
      case 2:
         return NORTH_AABB;
      case 3:
         return SOUTH_AABB;
      case 4:
         return WEST_AABB;
      case 5:
         return EAST_AABB;
      }
   }

   public String getLocalizedName() {
      return I18n.translateToLocal(I["".length()]);
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, EnumFacing.getFront(var1 & (127 ^ 120)));
      PropertyBool var10001 = NODROP;
      int var10002;
      if ((var1 & (40 ^ 32)) > 0) {
         var10002 = " ".length();
         "".length();
         if (2 <= -1) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   static {
      I();
      FACING = BlockDirectional.FACING;
      NODROP = PropertyBool.create(I[60 ^ 78]);
      IS_WITHER_SKELETON = new Predicate<BlockWorldState>() {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 == 2);

            throw null;
         }

         public boolean apply(@Nullable BlockWorldState var1) {
            int var10000;
            if (var1.getBlockState() != null && var1.getBlockState().getBlock() == Blocks.SKULL && var1.getTileEntity() instanceof TileEntitySkull && ((TileEntitySkull)var1.getTileEntity()).getSkullType() == " ".length()) {
               var10000 = " ".length();
               "".length();
               if (0 >= 4) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      };
      DEFAULT_AABB = new AxisAlignedBB(0.25D, 0.0D, 0.25D, 0.75D, 0.5D, 0.75D);
      NORTH_AABB = new AxisAlignedBB(0.25D, 0.25D, 0.5D, 0.75D, 0.75D, 1.0D);
      SOUTH_AABB = new AxisAlignedBB(0.25D, 0.25D, 0.0D, 0.75D, 0.75D, 0.5D);
      WEST_AABB = new AxisAlignedBB(0.5D, 0.25D, 0.25D, 1.0D, 0.75D, 0.75D);
      EAST_AABB = new AxisAlignedBB(0.0D, 0.25D, 0.25D, 0.5D, 0.75D, 0.75D);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockPattern getWitherBasePattern() {
      String var10000 = I[84 ^ 23];
      String var10001 = I[119 ^ 51];
      String var10002 = I[5 ^ 64];
      var10001 = I[234 ^ 172];
      var10000 = I[70 ^ 1];
      var10001 = I[97 ^ 41];
      var10002 = I[12 ^ 69];
      var10001 = I[44 ^ 102];
      var10000 = I[224 ^ 171];
      var10001 = I[50 ^ 126];
      var10002 = I[253 ^ 176];
      var10001 = I[97 ^ 47];
      if (this.witherBasePattern == null) {
         FactoryBlockPattern var1 = FactoryBlockPattern.start();
         String[] var2 = new String["   ".length()];
         I[83 ^ 28].length();
         I[195 ^ 147].length();
         I[249 ^ 168].length();
         var2["".length()] = I[216 ^ 138];
         I[247 ^ 164].length();
         I[212 ^ 128].length();
         I[68 ^ 17].length();
         var2[" ".length()] = I[30 ^ 72];
         I[112 ^ 39].length();
         I[244 ^ 172].length();
         I[27 ^ 66].length();
         var2["  ".length()] = I[201 ^ 147];
         this.witherBasePattern = var1.aisle(var2).where((char)('K' ^ 'h'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.SOUL_SAND))).where((char)('h' ^ '\u0016'), BlockWorldState.hasState(BlockMaterialMatcher.forMaterial(Material.AIR))).build();
      }

      return this.witherBasePattern;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[14 ^ 10];
      I[122 ^ 127].length();
      I[163 ^ 165].length();
      return new TileEntitySkull();
   }

   public boolean func_190946_v(IBlockState var1) {
      return (boolean)" ".length();
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getIndex();
      if ((Boolean)var1.getValue(NODROP)) {
         var2 |= 120 ^ 112;
      }

      return var2;
   }

   protected BlockSkull() {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(NODROP, Boolean.valueOf((boolean)"".length())));
   }

   public void checkWitherSpawn(World var1, BlockPos var2, TileEntitySkull var3) {
      String var10000 = I[147 ^ 179];
      String var10001 = I[14 ^ 47];
      String var10002 = I[148 ^ 182];
      var10001 = I[25 ^ 58];
      if (var3.getSkullType() == " ".length() && var2.getY() >= "  ".length() && var1.getDifficulty() != EnumDifficulty.PEACEFUL && !var1.isRemote) {
         BlockPattern var4 = this.getWitherPattern();
         BlockPattern.PatternHelper var5 = var4.match(var1, var2);
         if (var5 != null) {
            int var6 = "".length();

            while(var6 < "   ".length()) {
               BlockWorldState var7 = var5.translateOffset(var6, "".length(), "".length());
               var1.setBlockState(var7.getPos(), var7.getBlockState().withProperty(NODROP, Boolean.valueOf((boolean)" ".length())), "  ".length());
               I[175 ^ 139].length();
               I[82 ^ 119].length();
               I[94 ^ 120].length();
               ++var6;
               "".length();
               if (-1 >= 0) {
                  throw null;
               }
            }

            var6 = "".length();

            while(var6 < var4.getPalmLength()) {
               int var13 = "".length();

               while(var13 < var4.getThumbLength()) {
                  BlockWorldState var8 = var5.translateOffset(var6, var13, "".length());
                  var1.setBlockState(var8.getPos(), Blocks.AIR.getDefaultState(), "  ".length());
                  I[171 ^ 140].length();
                  I[178 ^ 154].length();
                  I[86 ^ 127].length();
                  ++var13;
                  "".length();
                  if (-1 != -1) {
                     throw null;
                  }
               }

               ++var6;
               "".length();
               if (0 >= 2) {
                  throw null;
               }
            }

            BlockPos var12 = var5.translateOffset(" ".length(), "".length(), "".length()).getPos();
            I[180 ^ 158].length();
            EntityWither var14 = new EntityWither(var1);
            BlockPos var15 = var5.translateOffset(" ".length(), "  ".length(), "".length()).getPos();
            double var18 = (double)var15.getX() + 0.5D;
            double var20 = (double)var15.getY() + 0.55D;
            double var10003 = (double)var15.getZ() + 0.5D;
            float var10004;
            if (var5.getForwards().getAxis() == EnumFacing.Axis.X) {
               var10004 = 0.0F;
               "".length();
               if (1 >= 2) {
                  throw null;
               }
            } else {
               var10004 = 90.0F;
            }

            var14.setLocationAndAngles(var18, var20, var10003, var10004, 0.0F);
            float var19;
            if (var5.getForwards().getAxis() == EnumFacing.Axis.X) {
               var19 = 0.0F;
               "".length();
               if (-1 != -1) {
                  throw null;
               }
            } else {
               var19 = 90.0F;
            }

            var14.renderYawOffset = var19;
            var14.ignite();
            Iterator var9 = var1.getEntitiesWithinAABB(EntityPlayerMP.class, var14.getEntityBoundingBox().expandXyz(50.0D)).iterator();

            while(var9.hasNext()) {
               EntityPlayerMP var10 = (EntityPlayerMP)var9.next();
               CriteriaTriggers.field_192133_m.func_192229_a(var10, var14);
               "".length();
               if (4 < 0) {
                  throw null;
               }
            }

            var1.spawnEntityInWorld(var14);
            I[23 ^ 60].length();
            I[178 ^ 158].length();
            I[175 ^ 130].length();
            int var16 = "".length();

            while(var16 < (45 ^ 85)) {
               EnumParticleTypes var21 = EnumParticleTypes.SNOWBALL;
               var20 = (double)var12.getX() + var1.rand.nextDouble();
               int var22 = var12.getY();
               int var23 = "  ".length();
               I[150 ^ 184].length();
               I[26 ^ 53].length();
               I[93 ^ 109].length();
               var1.spawnParticle(var21, var20, (double)(var22 - var23) + var1.rand.nextDouble() * 3.9D, (double)var12.getZ() + var1.rand.nextDouble(), 0.0D, 0.0D, 0.0D);
               ++var16;
               "".length();
               if (false) {
                  throw null;
               }
            }

            var16 = "".length();

            while(var16 < var4.getPalmLength()) {
               int var17 = "".length();

               while(var17 < var4.getThumbLength()) {
                  BlockWorldState var11 = var5.translateOffset(var16, var17, "".length());
                  var1.notifyNeighborsRespectDebug(var11.getPos(), Blocks.AIR, (boolean)"".length());
                  ++var17;
                  "".length();
                  if (1 >= 4) {
                     throw null;
                  }
               }

               ++var16;
               "".length();
               if (4 != 4) {
                  throw null;
               }
            }
         }
      }

   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[58 ^ 52];
      String var10001 = I[27 ^ 20];
      String var10002 = I[93 ^ 77];
      var10001 = I[33 ^ 48];
      var10000 = I[38 ^ 52];
      var10001 = I[82 ^ 65];
      var10002 = I[175 ^ 187];
      var10001 = I[17 ^ 4];
      if (!var1.isRemote) {
         if (!(Boolean)var3.getValue(NODROP)) {
            TileEntity var4 = var1.getTileEntity(var2);
            if (var4 instanceof TileEntitySkull) {
               TileEntitySkull var5 = (TileEntitySkull)var4;
               ItemStack var6 = this.getItem(var1, var2, var3);
               if (var5.getSkullType() == "   ".length() && var5.getPlayerProfile() != null) {
                  I[183 ^ 161].length();
                  I[103 ^ 112].length();
                  var6.setTagCompound(new NBTTagCompound());
                  I[175 ^ 183].length();
                  I[50 ^ 43].length();
                  I[24 ^ 2].length();
                  I[179 ^ 168].length();
                  I[129 ^ 157].length();
                  NBTTagCompound var7 = new NBTTagCompound();
                  NBTUtil.writeGameProfile(var7, var5.getPlayerProfile());
                  I[10 ^ 23].length();
                  I[33 ^ 63].length();
                  var6.getTagCompound().setTag(I[179 ^ 172], var7);
               }

               spawnAsEntity(var1, var2, var6);
            }
         }

         super.breakBlock(var1, var2, var3);
      }

   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
   }

   public void onBlockHarvested(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      if (var4.capabilities.isCreativeMode) {
         var3 = var3.withProperty(NODROP, Boolean.valueOf((boolean)" ".length()));
         var1.setBlockState(var2, var3, 12 ^ 8);
         I[116 ^ 120].length();
         I[127 ^ 114].length();
      }

      super.onBlockHarvested(var1, var2, var3, var4);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 0);

      throw null;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[18 ^ 21];
      String var10001 = I[122 ^ 114];
      String var10002 = I[51 ^ 58];
      var10001 = I[44 ^ 38];
      int var4 = "".length();
      TileEntity var5 = var1.getTileEntity(var2);
      if (var5 instanceof TileEntitySkull) {
         var4 = ((TileEntitySkull)var5).getSkullType();
      }

      I[131 ^ 136].length();
      return new ItemStack(Items.SKULL, " ".length(), var4);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   protected BlockPattern getWitherPattern() {
      String var10000 = I[209 ^ 138];
      String var10001 = I[64 ^ 28];
      String var10002 = I[242 ^ 175];
      var10001 = I[247 ^ 169];
      var10000 = I[8 ^ 87];
      var10001 = I[236 ^ 140];
      var10002 = I[48 ^ 81];
      var10001 = I[69 ^ 39];
      var10000 = I[247 ^ 148];
      var10001 = I[124 ^ 24];
      var10002 = I[119 ^ 18];
      var10001 = I[66 ^ 36];
      if (this.witherPattern == null) {
         FactoryBlockPattern var1 = FactoryBlockPattern.start();
         String[] var2 = new String["   ".length()];
         I[40 ^ 79].length();
         I[29 ^ 117].length();
         I[219 ^ 178].length();
         var2["".length()] = I[233 ^ 131];
         I[119 ^ 28].length();
         var2[" ".length()] = I[207 ^ 163];
         I[52 ^ 89].length();
         I[25 ^ 119].length();
         I[62 ^ 81].length();
         I[55 ^ 71].length();
         var2["  ".length()] = I[217 ^ 168];
         this.witherPattern = var1.aisle(var2).where((char)('d' ^ 'G'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.SOUL_SAND))).where((char)('n' ^ '0'), IS_WITHER_SKELETON).where((char)('æ' ^ '\u0098'), BlockWorldState.hasState(BlockMaterialMatcher.forMaterial(Material.AIR))).build();
      }

      return this.witherPattern;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, var8.getHorizontalFacing()).withProperty(NODROP, Boolean.valueOf((boolean)"".length()));
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }
}

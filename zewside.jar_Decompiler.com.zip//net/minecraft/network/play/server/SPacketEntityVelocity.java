package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketEntityVelocity implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int motionZ;
   // $FF: synthetic field
   private int motionX;
   // $FF: synthetic field
   private int entityID;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int motionY;

   public SPacketEntityVelocity(Entity var1) {
      this(var1.getEntityId(), var1.motionX, var1.motionY, var1.motionZ);
   }

   public SPacketEntityVelocity(int var1, double var2, double var4, double var6) {
      this.entityID = var1;
      double var8 = 3.9D;
      if (var2 < -3.9D) {
         var2 = -3.9D;
      }

      if (var4 < -3.9D) {
         var4 = -3.9D;
      }

      if (var6 < -3.9D) {
         var6 = -3.9D;
      }

      if (var2 > 3.9D) {
         var2 = 3.9D;
      }

      if (var4 > 3.9D) {
         var4 = 3.9D;
      }

      if (var6 > 3.9D) {
         var6 = 3.9D;
      }

      this.motionX = (int)(var2 * 8000.0D);
      this.motionY = (int)(var4 * 8000.0D);
      this.motionZ = (int)(var6 * 8000.0D);
   }

   public SPacketEntityVelocity() {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityVelocity(this);
   }

   public int getEntityID() {
      return this.entityID;
   }

   public int getMotionX() {
      return this.motionX;
   }

   static {
      I();
   }

   public int getMotionZ() {
      return this.motionZ;
   }

   private static void I() {
      I = new String[77 ^ 68];
      I["".length()] = I("亩嫽", "lCgPn");
      I[" ".length()] = I("偀", "DQLPe");
      I["  ".length()] = I("湣儊嶿", "hPEpV");
      I["   ".length()] = I("寣戡浉攲沲", "PNqyW");
      I[169 ^ 173] = I("嘼倔", "etanZ");
      I[17 ^ 20] = I("炉旨", "lERwT");
      I[31 ^ 25] = I("澾圠濬", "gIzYE");
      I[20 ^ 19] = I("栦曷坝", "bfYHr");
      I[175 ^ 167] = I("嫔怯灯", "Qnacw");
   }

   public int getMotionY() {
      return this.motionY;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityID);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeShort(this.motionX);
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeShort(this.motionY);
      I[181 ^ 177].length();
      I[68 ^ 65].length();
      var1.writeShort(this.motionZ);
      I[142 ^ 136].length();
      I[97 ^ 102].length();
      I[35 ^ 43].length();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityID = var1.readVarIntFromBuffer();
      this.motionX = var1.readShort();
      this.motionY = var1.readShort();
      this.motionZ = var1.readShort();
   }
}

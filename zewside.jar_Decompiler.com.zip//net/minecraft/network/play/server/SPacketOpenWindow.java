package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.text.ITextComponent;

public class SPacketOpenWindow implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int slotCount;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private ITextComponent windowTitle;
   // $FF: synthetic field
   private String inventoryType;
   // $FF: synthetic field
   private int windowId;

   public int getEntityId() {
      return this.entityId;
   }

   public ITextComponent getWindowTitle() {
      return this.windowTitle;
   }

   public boolean hasSlots() {
      int var10000;
      if (this.slotCount > 0) {
         var10000 = " ".length();
         "".length();
         if (3 < -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.windowId = var1.readUnsignedByte();
      this.inventoryType = var1.readStringFromBuffer(35 ^ 3);
      this.windowTitle = var1.readTextComponent();
      this.slotCount = var1.readUnsignedByte();
      if (this.inventoryType.equals(I["".length()])) {
         this.entityId = var1.readInt();
      }

   }

   public SPacketOpenWindow(int var1, String var2, ITextComponent var3, int var4, int var5) {
      this(var1, var2, var3, var4);
      this.entityId = var5;
   }

   public SPacketOpenWindow(int var1, String var2, ITextComponent var3) {
      this(var1, var2, var3, "".length());
   }

   public int getWindowId() {
      return this.windowId;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.windowId);
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeString(this.inventoryType);
      I[184 ^ 188].length();
      I[188 ^ 185].length();
      I[124 ^ 122].length();
      var1.writeTextComponent(this.windowTitle);
      I[165 ^ 162].length();
      I[156 ^ 148].length();
      I[32 ^ 41].length();
      var1.writeByte(this.slotCount);
      I[204 ^ 198].length();
      I[85 ^ 94].length();
      I[21 ^ 25].length();
      if (this.inventoryType.equals(I[162 ^ 175])) {
         var1.writeInt(this.entityId);
         I[146 ^ 156].length();
         I[187 ^ 180].length();
         I[93 ^ 77].length();
      }

   }

   public SPacketOpenWindow(int var1, String var2, ITextComponent var3, int var4) {
      this.windowId = var1;
      this.inventoryType = var2;
      this.windowTitle = var3;
      this.slotCount = var4;
   }

   private static void I() {
      I = new String[65 ^ 80];
      I["".length()] = I("\u000b\u000213\u00187$*(\u001f+", "NlEZl");
      I[" ".length()] = I("撒冼", "QznaJ");
      I["  ".length()] = I("亭厛埇泸櫀", "MYqFx");
      I["   ".length()] = I("廠", "zLNyv");
      I[40 ^ 44] = I("丨哛柲", "mdhxK");
      I[57 ^ 60] = I("洀垓塟围末", "yyULd");
      I[23 ^ 17] = I("弯殷", "BfZwN");
      I[185 ^ 190] = I("拯峼氨棢", "CIqPH");
      I[70 ^ 78] = I("梳嶜烒噢", "LbgQm");
      I[136 ^ 129] = I("刋漭", "KAJpS");
      I[68 ^ 78] = I("欗娥乆宻", "onaIz");
      I[13 ^ 6] = I("垑凑旲樏岳", "AGPtX");
      I[170 ^ 166] = I("桌漕憎弡潱", "JjRhh");
      I[153 ^ 148] = I("6,\u0001.8\n\n\u001a5?\u0016", "sBuGL");
      I[29 ^ 19] = I("擌", "gSUHo");
      I[0 ^ 15] = I("扉定厣", "UIuVU");
      I[147 ^ 131] = I("嵰嬿幑", "ELrQG");
   }

   static {
      I();
   }

   public String getGuiId() {
      return this.inventoryType;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 0);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleOpenWindow(this);
   }

   public int getSlotCount() {
      return this.slotCount;
   }

   public SPacketOpenWindow() {
   }
}

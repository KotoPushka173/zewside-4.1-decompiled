package net.minecraft.block.properties;

import javax.annotation.ParametersAreNonnullByDefault;
import mcp.MethodsReturnNonnullByDefault;

// $FF: synthetic class
@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
interface package-info {
}

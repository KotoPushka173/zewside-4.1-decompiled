package net.minecraft.block.state.pattern;

import com.google.common.base.MoreObjects;
import com.google.common.base.Predicate;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LoadingCache;
import java.util.Iterator;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;

public class BlockPattern {
   // $FF: synthetic field
   private final int fingerLength;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final int palmLength;
   // $FF: synthetic field
   private final Predicate<BlockWorldState>[][][] blockMatches;
   // $FF: synthetic field
   private final int thumbLength;

   @Nullable
   private BlockPattern.PatternHelper checkPatternAt(BlockPos var1, EnumFacing var2, EnumFacing var3, LoadingCache<BlockPos, BlockWorldState> var4) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      int var5 = "".length();

      do {
         if (var5 >= this.palmLength) {
            I[146 ^ 150].length();
            I[109 ^ 104].length();
            return new BlockPattern.PatternHelper(var1, var2, var3, var4, this.palmLength, this.thumbLength, this.fingerLength);
         }

         int var6 = "".length();

         while(var6 < this.thumbLength) {
            int var7 = "".length();

            while(var7 < this.fingerLength) {
               if (!this.blockMatches[var7][var6][var5].apply(var4.getUnchecked(translateOffset(var1, var2, var3, var5, var6, var7)))) {
                  return null;
               }

               ++var7;
               "".length();
               if (3 < 1) {
                  throw null;
               }
            }

            ++var6;
            "".length();
            if (4 == -1) {
               throw null;
            }
         }

         ++var5;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public static LoadingCache<BlockPos, BlockWorldState> createLoadingCache(World var0, boolean var1) {
      String var10000 = I[14 ^ 7];
      String var10001 = I[49 ^ 59];
      String var10002 = I[140 ^ 135];
      var10001 = I[51 ^ 63];
      CacheBuilder var2 = CacheBuilder.newBuilder();
      I[39 ^ 42].length();
      I[20 ^ 26].length();
      return var2.build(new BlockPattern.CacheLoader(var0, var1));
   }

   public int getFingerLength() {
      return this.fingerLength;
   }

   @Nullable
   public BlockPattern.PatternHelper match(World var1, BlockPos var2) {
      LoadingCache var3 = createLoadingCache(var1, (boolean)"".length());
      int var4 = Math.max(Math.max(this.palmLength, this.thumbLength), this.fingerLength);
      int var10003 = " ".length();
      I[29 ^ 27].length();
      int var10002 = var4 - var10003;
      int var10004 = " ".length();
      I[42 ^ 45].length();
      var10003 = var4 - var10004;
      int var10005 = " ".length();
      I[74 ^ 66].length();
      Iterator var5 = BlockPos.getAllInBox(var2, var2.add(var10002, var10003, var4 - var10005)).iterator();

      do {
         if (!var5.hasNext()) {
            return null;
         }

         BlockPos var6 = (BlockPos)var5.next();
         EnumFacing[] var7 = EnumFacing.values();
         int var8 = var7.length;
         int var9 = "".length();

         while(var9 < var8) {
            EnumFacing var10 = var7[var9];
            EnumFacing[] var11 = EnumFacing.values();
            int var12 = var11.length;
            int var13 = "".length();

            while(var13 < var12) {
               EnumFacing var14 = var11[var13];
               if (var14 != var10 && var14 != var10.getOpposite()) {
                  BlockPattern.PatternHelper var15 = this.checkPatternAt(var6, var10, var14, var3);
                  if (var15 != null) {
                     return var15;
                  }
               }

               ++var13;
               "".length();
               if (3 != 3) {
                  throw null;
               }
            }

            ++var9;
            "".length();
            if (-1 == 0) {
               throw null;
            }
         }

         "".length();
      } while(0 < 1);

      throw null;
   }

   public int getPalmLength() {
      return this.palmLength;
   }

   protected static BlockPos translateOffset(BlockPos var0, EnumFacing var1, EnumFacing var2, int var3, int var4, int var5) {
      String var10000 = I[172 ^ 163];
      String var10001 = I[140 ^ 156];
      String var10002 = I[184 ^ 169];
      var10001 = I[39 ^ 53];
      var10000 = I[191 ^ 172];
      var10001 = I[102 ^ 114];
      var10002 = I[111 ^ 122];
      var10001 = I[116 ^ 98];
      var10000 = I[68 ^ 83];
      var10001 = I[114 ^ 106];
      var10002 = I[141 ^ 148];
      var10001 = I[135 ^ 157];
      if (var1 != var2 && var1 != var2.getOpposite()) {
         I[54 ^ 45].length();
         I[137 ^ 149].length();
         I[172 ^ 177].length();
         I[94 ^ 64].length();
         Vec3i var6 = new Vec3i(var1.getFrontOffsetX(), var1.getFrontOffsetY(), var1.getFrontOffsetZ());
         I[66 ^ 93].length();
         I[11 ^ 43].length();
         Vec3i var7 = new Vec3i(var2.getFrontOffsetX(), var2.getFrontOffsetY(), var2.getFrontOffsetZ());
         Vec3i var8 = var6.crossProduct(var7);
         return var0.add(var7.getX() * -var4 + var8.getX() * var3 + var6.getX() * var5, var7.getY() * -var4 + var8.getY() * var3 + var6.getY() * var5, var7.getZ() * -var4 + var8.getZ() * var3 + var6.getZ() * var5);
      } else {
         I[102 ^ 71].length();
         I[94 ^ 124].length();
         I[224 ^ 195].length();
         I[55 ^ 19].length();
         IllegalArgumentException var9 = new IllegalArgumentException(I[89 ^ 124]);
         I[186 ^ 156].length();
         I[95 ^ 120].length();
         I[65 ^ 105].length();
         I[101 ^ 76].length();
         I[10 ^ 32].length();
         throw var9;
      }
   }

   public BlockPattern(Predicate<BlockWorldState>[][][] var1) {
      this.blockMatches = var1;
      this.fingerLength = var1.length;
      if (this.fingerLength > 0) {
         this.thumbLength = var1["".length()].length;
         if (this.thumbLength > 0) {
            this.palmLength = var1["".length()]["".length()].length;
            "".length();
            if (3 != 3) {
               throw null;
            }
         } else {
            this.palmLength = "".length();
            "".length();
            if (0 >= 4) {
               throw null;
            }
         }
      } else {
         this.thumbLength = "".length();
         this.palmLength = "".length();
      }

   }

   public int getThumbLength() {
      return this.thumbLength;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 3);

      throw null;
   }

   private static void I() {
      I = new String[86 ^ 125];
      I["".length()] = I("栔曛", "yoLOz");
      I[" ".length()] = I("慺嗔", "mbZXO");
      I["  ".length()] = I("溚垐", "UvsvL");
      I["   ".length()] = I("僜匦", "PJzlH");
      I[9 ^ 13] = I("烸", "DWuJd");
      I[164 ^ 161] = I("丢愋", "AdSYG");
      I[57 ^ 63] = I("们淀忯溺喠", "RJdtd");
      I[176 ^ 183] = I("付坊巫嚜", "SbDoJ");
      I[88 ^ 80] = I("淟唷孚対填", "nWPTP");
      I[44 ^ 37] = I("嫓搞", "XdATI");
      I[31 ^ 21] = I("延劃", "SeWHp");
      I[106 ^ 97] = I("持峭", "tcPfc");
      I[38 ^ 42] = I("咘刼", "GwFlI");
      I[59 ^ 54] = I("水剷", "DpNHY");
      I[90 ^ 84] = I("决拔", "JfHxW");
      I[40 ^ 39] = I("峔不", "HSUcH");
      I[215 ^ 199] = I("杛係", "XobWX");
      I[87 ^ 70] = I("厈杯", "hxxGi");
      I[181 ^ 167] = I("块椸", "cnYgv");
      I[169 ^ 186] = I("扼抒", "dySgr");
      I[156 ^ 136] = I("僓叿", "vUSqv");
      I[211 ^ 198] = I("垡梦", "dVHPF");
      I[172 ^ 186] = I("灺媋", "ihkXd");
      I[43 ^ 60] = I("噴格", "jPYHd");
      I[21 ^ 13] = I("央哘", "itxtx");
      I[46 ^ 55] = I("戳掲", "LPFTe");
      I[79 ^ 85] = I("槮档", "aFHXd");
      I[137 ^ 146] = I("曂撛屯噑", "LcXzk");
      I[60 ^ 32] = I("峥", "VWxNL");
      I[96 ^ 125] = I("儝", "hUqhE");
      I[129 ^ 159] = I("榇橼沖", "lctEl");
      I[102 ^ 121] = I("之墼撴传桒", "xooCP");
      I[180 ^ 148] = I("厾僮", "ZDHNf");
      I[40 ^ 9] = I("崾洡兙", "OACyo");
      I[85 ^ 119] = I("搱怲怸偤", "xcbMR");
      I[141 ^ 174] = I("橈咘墊呓氺", "AAKQK");
      I[177 ^ 149] = I("棪炗", "EPxnH");
      I[228 ^ 193] = I("\u0006\u000f\u0000)9&\u0005V.:=\u0016\u0017:1<APh ?A\u0015'8-\b\u0018)!&\u000e\u0018", "OavHU");
      I[80 ^ 118] = I("測洜溢徴岁", "nlpwO");
      I[24 ^ 63] = I("廹枺", "dTAiS");
      I[50 ^ 26] = I("傫垌屝壼", "winBr");
      I[127 ^ 86] = I("壻坈瀈", "iESip");
      I[75 ^ 97] = I("楍仓淅", "cGSqX");
   }

   static {
      I();
   }

   public static class PatternHelper {
      // $FF: synthetic field
      private final EnumFacing forwards;
      // $FF: synthetic field
      private final BlockPos frontTopLeft;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final EnumFacing up;
      // $FF: synthetic field
      private final int depth;
      // $FF: synthetic field
      private final int height;
      // $FF: synthetic field
      private final int width;
      // $FF: synthetic field
      private final LoadingCache<BlockPos, BlockWorldState> lcache;

      public String toString() {
         return MoreObjects.toStringHelper(this).add(I["".length()], this.up).add(I[" ".length()], this.forwards).add(I["  ".length()], this.frontTopLeft).toString();
      }

      public int getHeight() {
         return this.height;
      }

      public int getWidth() {
         return this.width;
      }

      public BlockPos getFrontTopLeft() {
         return this.frontTopLeft;
      }

      public EnumFacing getUp() {
         return this.up;
      }

      private static void I() {
         I = new String["   ".length()];
         I["".length()] = I("\u00072", "rBcib");
         I[" ".length()] = I("\u0012\u000e%&\u000b\u0006\u0005$", "taWQj");
         I["  ".length()] = I("1\u0011\u0001\u001d\u0002\u0003\f\u001e?\u00131\u0017", "Wcnsv");
      }

      static {
         I();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 == 2);

         throw null;
      }

      public BlockWorldState translateOffset(int var1, int var2, int var3) {
         return (BlockWorldState)this.lcache.getUnchecked(BlockPattern.translateOffset(this.frontTopLeft, this.getForwards(), this.getUp(), var1, var2, var3));
      }

      public PatternHelper(BlockPos var1, EnumFacing var2, EnumFacing var3, LoadingCache<BlockPos, BlockWorldState> var4, int var5, int var6, int var7) {
         this.frontTopLeft = var1;
         this.forwards = var2;
         this.up = var3;
         this.lcache = var4;
         this.width = var5;
         this.height = var6;
         this.depth = var7;
      }

      public EnumFacing getForwards() {
         return this.forwards;
      }
   }

   static class CacheLoader extends com.google.common.cache.CacheLoader<BlockPos, BlockWorldState> {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final World world;
      // $FF: synthetic field
      private final boolean forceLoad;

      public CacheLoader(World var1, boolean var2) {
         this.world = var1;
         this.forceLoad = var2;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= 0);

         throw null;
      }

      static {
         I();
      }

      private static void I() {
         I = new String[158 ^ 152];
         I["".length()] = I("央欖", "ZGgDR");
         I[" ".length()] = I("氆楉", "irqTK");
         I["  ".length()] = I("冝泣", "ryUkW");
         I["   ".length()] = I("寶槌", "RMhKM");
         I[46 ^ 42] = I("炜挾嵃囅亟", "cToOs");
         I[23 ^ 18] = I("崬", "TMltJ");
      }

      public BlockWorldState load(BlockPos var1) throws Exception {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         I[23 ^ 19].length();
         I[158 ^ 155].length();
         return new BlockWorldState(this.world, var1, this.forceLoad);
      }
   }
}

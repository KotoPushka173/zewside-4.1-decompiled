package net.minecraft.advancements.critereon;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.util.JsonUtils;

public class MinMaxBounds {
   // $FF: synthetic field
   public static final MinMaxBounds field_192516_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Float field_192518_c;
   // $FF: synthetic field
   private final Float field_192517_b;

   private static void I() {
      I = new String[38 ^ 52];
      I["".length()] = I("厤卾", "LJeKH");
      I[" ".length()] = I("案汆", "qDuDm");
      I["  ".length()] = I("栈叭", "BTZhY");
      I["   ".length()] = I("掹渂", "ccDAz");
      I[88 ^ 92] = I("嫈嶋", "ApcLG");
      I[3 ^ 6] = I("匢椳", "WJhwe");
      I[170 ^ 172] = I("斅敊", "lqlwh");
      I[35 ^ 36] = I("氶婒", "McHcw");
      I[122 ^ 114] = I("\f\t\u000413", "zhhDV");
      I[104 ^ 97] = I("搛廝唅倏哼", "LYlVl");
      I[183 ^ 189] = I("潻此徕", "qmOqE");
      I[11 ^ 0] = I("炛", "NjBrj");
      I[79 ^ 67] = I("!\u0006\t \"", "WgeUG");
      I[171 ^ 166] = I("*\u001f$", "GvJDY");
      I[72 ^ 70] = I("%*\u0001", "HCoxV");
      I[62 ^ 49] = I(" \u00177", "MvOfv");
      I[124 ^ 108] = I("\u000f\n3", "bkKqP");
      I[55 ^ 38] = I("拘屈", "tzAbT");
   }

   public boolean func_192514_a(float var1) {
      if (this.field_192517_b != null && this.field_192517_b > var1) {
         return (boolean)"".length();
      } else {
         int var10000;
         if (this.field_192518_c != null && !(this.field_192518_c >= var1)) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (3 < 3) {
               throw null;
            }
         }

         return (boolean)var10000;
      }
   }

   public MinMaxBounds(@Nullable Float var1, @Nullable Float var2) {
      this.field_192517_b = var1;
      this.field_192518_c = var2;
   }

   public static MinMaxBounds func_192515_a(@Nullable JsonElement var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[35 ^ 39];
      var10001 = I[173 ^ 168];
      var10002 = I[73 ^ 79];
      var10001 = I[24 ^ 31];
      if (var0 != null && !var0.isJsonNull()) {
         if (JsonUtils.isNumber(var0)) {
            float var4 = JsonUtils.getFloat(var0, I[58 ^ 50]);
            I[14 ^ 7].length();
            I[170 ^ 160].length();
            I[51 ^ 56].length();
            return new MinMaxBounds(var4, var4);
         } else {
            JsonObject var1 = JsonUtils.getJsonObject(var0, I[173 ^ 161]);
            Float var5;
            if (var1.has(I[87 ^ 90])) {
               var5 = JsonUtils.getFloat(var1, I[30 ^ 16]);
               "".length();
               if (3 <= 1) {
                  throw null;
               }
            } else {
               var5 = null;
            }

            Float var2 = var5;
            if (var1.has(I[93 ^ 82])) {
               var5 = JsonUtils.getFloat(var1, I[156 ^ 140]);
               "".length();
               if (3 == 4) {
                  throw null;
               }
            } else {
               var5 = null;
            }

            Float var3 = var5;
            I[110 ^ 127].length();
            return new MinMaxBounds(var2, var3);
         }
      } else {
         return field_192516_a;
      }
   }

   static {
      I();
      field_192516_a = new MinMaxBounds((Float)null, (Float)null);
   }

   public boolean func_192513_a(double var1) {
      if (this.field_192517_b != null && (double)(this.field_192517_b * this.field_192517_b) > var1) {
         return (boolean)"".length();
      } else {
         int var10000;
         if (this.field_192518_c != null && !((double)(this.field_192518_c * this.field_192518_c) >= var1)) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (-1 != -1) {
               throw null;
            }
         }

         return (boolean)var10000;
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }
}

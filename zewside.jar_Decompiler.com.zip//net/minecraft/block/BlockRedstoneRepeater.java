package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockRedstoneRepeater extends BlockRedstoneDiode {
   // $FF: synthetic field
   public static final PropertyInteger DELAY;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool LOCKED;

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
      int var10001 = (Integer)var1.getValue(DELAY);
      int var10002 = " ".length();
      I[158 ^ 140].length();
      I[99 ^ 112].length();
      var2 |= var10001 - var10002 << "  ".length();
      return var2;
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      super.breakBlock(var1, var2, var3);
      this.notifyNeighbors(var1, var2, var3);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.byHorizontalIndex(var1)).withProperty(LOCKED, Boolean.valueOf((boolean)"".length())).withProperty(DELAY, " ".length() + (var1 >> "  ".length()));
   }

   private static void I() {
      I = new String[188 ^ 143];
      I["".length()] = I("01\r;d=,\u00072/w+\t;/", "YEhVJ");
      I[" ".length()] = I("湦嗺櫓", "FCFTB");
      I["  ".length()] = I("榆啳", "tCEET");
      I["   ".length()] = I("宜嘺", "fABGn");
      I[46 ^ 42] = I("囧壔", "Veyvr");
      I[113 ^ 116] = I("櫙佱", "XlHyH");
      I[127 ^ 121] = I("快孼", "hPpjE");
      I[119 ^ 112] = I("庁殽憱崞", "hRamQ");
      I[30 ^ 22] = I("橠彾湬剴忹", "bKUJL");
      I[0 ^ 9] = I("唊椵洵怚挭", "kUKuy");
      I[45 ^ 39] = I("嘚唥厅", "CMzCK");
      I[34 ^ 41] = I("撙嗲娱淖", "lWQbP");
      I[122 ^ 118] = I("勤", "hLAVV");
      I[151 ^ 154] = I("沁價棆峐嫾", "cmvBL");
      I[162 ^ 172] = I("崯", "PGmfa");
      I[93 ^ 82] = I("桺栿櫩屠", "jkMLs");
      I[182 ^ 166] = I("朔圇", "ohWhX");
      I[144 ^ 129] = I("丟擋歪滅柵", "QYIWX");
      I[93 ^ 79] = I("夹奛", "uAglX");
      I[55 ^ 36] = I("帶噀佭", "IqRVg");
      I[55 ^ 35] = I("伙嚗", "mDkTk");
      I[35 ^ 54] = I("哚毻", "gHvGB");
      I[188 ^ 170] = I("冂偪", "sWCpm");
      I[35 ^ 52] = I("溼杤", "KGIFU");
      I[138 ^ 146] = I("例勂", "TjzWL");
      I[58 ^ 35] = I("杷戂", "NTSeF");
      I[7 ^ 29] = I("囹棻", "HXAjG");
      I[119 ^ 108] = I("勍栵", "GGxEg");
      I[121 ^ 101] = I("侬晖", "CaOoJ");
      I[144 ^ 141] = I("梛严", "ezkzB");
      I[6 ^ 24] = I("氷丁", "ewmmx");
      I[190 ^ 161] = I("媀摍", "FdcGB");
      I[75 ^ 107] = I("摙媆", "IQkku");
      I[231 ^ 198] = I("杧東", "WaZeO");
      I[122 ^ 88] = I("杭煣", "gLLIn");
      I[188 ^ 159] = I("塨弒", "qXkAi");
      I[47 ^ 11] = I("濑恏偵", "PrFxK");
      I[173 ^ 136] = I("暐帏壤幌彄", "zFSnW");
      I[187 ^ 157] = I("吧寔仱朞", "BCoCH");
      I[183 ^ 144] = I("再圏歟众晳", "kNBqe");
      I[133 ^ 173] = I("呺婋棶", "mgsWX");
      I[61 ^ 20] = I("丗亍嵎掶", "SKPOT");
      I[180 ^ 158] = I("湻實埴", "ycuIT");
      I[16 ^ 59] = I("廯婥扬", "raSNU");
      I[57 ^ 21] = I("梘櫀", "ZKMRO");
      I[116 ^ 89] = I("坃仔慠", "LkGpn");
      I[151 ^ 185] = I("末炚棺嬜", "LuVBr");
      I[102 ^ 73] = I("妋枠", "QYJOd");
      I[100 ^ 84] = I("搉仈扜", "ozYmI");
      I[121 ^ 72] = I("\u0018\b\u0002\u0004-\u0010", "tgaoH");
      I[89 ^ 107] = I("\u000f-\u0015\u00121", "kHysH");
   }

   protected BlockRedstoneRepeater(boolean var1) {
      super(var1);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(DELAY, " ".length()).withProperty(LOCKED, Boolean.valueOf((boolean)"".length())));
   }

   protected IBlockState getUnpoweredState(IBlockState var1) {
      Integer var2 = (Integer)var1.getValue(DELAY);
      Boolean var3 = (Boolean)var1.getValue(LOCKED);
      EnumFacing var4 = (EnumFacing)var1.getValue(FACING);
      return Blocks.UNPOWERED_REPEATER.getDefaultState().withProperty(FACING, var4).withProperty(DELAY, var2).withProperty(LOCKED, var3);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.REPEATER;
   }

   protected boolean isAlternateInput(IBlockState var1) {
      return isDiode(var1);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (!var4.capabilities.allowEdit) {
         return (boolean)"".length();
      } else {
         var1.setBlockState(var2, var3.cycleProperty(DELAY), "   ".length());
         I[" ".length()].length();
         I["  ".length()].length();
         return (boolean)" ".length();
      }
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return var1.withProperty(LOCKED, this.isLocked(var2, var3, var1));
   }

   static {
      I();
      LOCKED = PropertyBool.create(I[90 ^ 107]);
      DELAY = PropertyInteger.create(I[5 ^ 55], " ".length(), 126 ^ 122);
   }

   public String getLocalizedName() {
      return I18n.translateToLocal(I["".length()]);
   }

   protected IBlockState getPoweredState(IBlockState var1) {
      Integer var2 = (Integer)var1.getValue(DELAY);
      Boolean var3 = (Boolean)var1.getValue(LOCKED);
      EnumFacing var4 = (EnumFacing)var1.getValue(FACING);
      return Blocks.POWERED_REPEATER.getDefaultState().withProperty(FACING, var4).withProperty(DELAY, var2).withProperty(LOCKED, var3);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 2);

      throw null;
   }

   protected int getDelay(IBlockState var1) {
      return (Integer)var1.getValue(DELAY) * "  ".length();
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      if (this.isRepeaterPowered) {
         EnumFacing var5 = (EnumFacing)var1.getValue(FACING);
         double var10000 = (double)((float)var3.getX() + 0.5F);
         float var10001 = var4.nextFloat();
         I[156 ^ 149].length();
         I[188 ^ 182].length();
         I[167 ^ 172].length();
         I[143 ^ 131].length();
         double var6 = var10000 + (double)(var10001 - 0.5F) * 0.2D;
         var10000 = (double)((float)var3.getY() + 0.4F);
         var10001 = var4.nextFloat();
         I[184 ^ 181].length();
         double var8 = var10000 + (double)(var10001 - 0.5F) * 0.2D;
         var10000 = (double)((float)var3.getZ() + 0.5F);
         var10001 = var4.nextFloat();
         I[148 ^ 154].length();
         double var10 = var10000 + (double)(var10001 - 0.5F) * 0.2D;
         float var12 = -5.0F;
         if (var4.nextBoolean()) {
            int var17 = (Integer)var1.getValue(DELAY) * "  ".length();
            int var18 = " ".length();
            I[64 ^ 79].length();
            I[87 ^ 71].length();
            I[104 ^ 121].length();
            var12 = (float)(var17 - var18);
         }

         var12 /= 16.0F;
         double var13 = (double)(var12 * (float)var5.getFrontOffsetX());
         double var15 = (double)(var12 * (float)var5.getFrontOffsetZ());
         var2.spawnParticle(EnumParticleTypes.REDSTONE, var6 + var13, var8, var10 + var15, 0.0D, 0.0D, 0.0D);
      }

   }

   public boolean isLocked(IBlockAccess var1, BlockPos var2, IBlockState var3) {
      int var10000;
      if (this.getPowerOnSides(var1, var2, var3) > 0) {
         var10000 = " ".length();
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["   ".length()];
      String var10001 = I[50 ^ 54];
      String var10002 = I[152 ^ 157];
      var10001 = I[137 ^ 143];
      I[140 ^ 139].length();
      I[174 ^ 166].length();
      return new ItemStack(Items.REPEATER);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[9 ^ 29];
      String var10001 = I[107 ^ 126];
      String var10002 = I[15 ^ 25];
      var10001 = I[147 ^ 132];
      var10000 = I[85 ^ 77];
      var10001 = I[99 ^ 122];
      var10002 = I[57 ^ 35];
      var10001 = I[154 ^ 129];
      var10000 = I[105 ^ 117];
      var10001 = I[93 ^ 64];
      var10002 = I[104 ^ 118];
      var10001 = I[189 ^ 162];
      var10000 = I[178 ^ 146];
      var10001 = I[30 ^ 63];
      var10002 = I[130 ^ 160];
      var10001 = I[49 ^ 18];
      I[88 ^ 124].length();
      I[26 ^ 63].length();
      I[173 ^ 139].length();
      I[155 ^ 188].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[71 ^ 111].length();
      I[142 ^ 167].length();
      I[189 ^ 151].length();
      I[14 ^ 37].length();
      var10003["".length()] = FACING;
      I[233 ^ 197].length();
      I[72 ^ 101].length();
      I[174 ^ 128].length();
      I[8 ^ 39].length();
      var10003[" ".length()] = DELAY;
      I[81 ^ 97].length();
      var10003["  ".length()] = LOCKED;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }
}

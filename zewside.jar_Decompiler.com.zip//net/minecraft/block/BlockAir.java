package net.minecraft.block;

import java.util.IdentityHashMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockAir extends Block {
   // $FF: synthetic field
   private static Map mapOriginalOpacity;
   // $FF: synthetic field
   private static final String[] I;

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != 3);

      throw null;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
   }

   protected BlockAir() {
      super(Material.AIR);
   }

   static {
      I();
      mapOriginalOpacity = new IdentityHashMap();
   }

   public boolean isReplaceable(IBlockAccess var1, BlockPos var2) {
      return (boolean)" ".length();
   }

   public boolean canCollideCheck(IBlockState var1, boolean var2) {
      return (boolean)"".length();
   }

   public static void restoreLightOpacity(Block var0) {
      if (mapOriginalOpacity.containsKey(var0)) {
         int var1 = (Integer)mapOriginalOpacity.get(var0);
         setLightOpacity(var0, var1);
      }

   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("半潍殮侜", "JSjmR");
      I[" ".length()] = I("寞唿", "ebBRx");
      I["  ".length()] = I("捱朅椾彉嶞", "TKwrI");
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public static void setLightOpacity(Block var0, int var1) {
      if (!mapOriginalOpacity.containsKey(var0)) {
         mapOriginalOpacity.put(var0, var0.lightOpacity);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }

      var0.lightOpacity = var1;
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.INVISIBLE;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }
}

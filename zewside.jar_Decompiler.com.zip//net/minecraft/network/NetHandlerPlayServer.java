package net.minecraft.network;

import com.google.common.collect.Lists;
import com.google.common.primitives.Doubles;
import com.google.common.primitives.Floats;
import com.google.common.util.concurrent.Futures;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.BlockCommandBlock;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IJumpingMount;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityMinecartCommandBlock;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerBeacon;
import net.minecraft.inventory.ContainerMerchant;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemWritableBook;
import net.minecraft.item.ItemWrittenBook;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.client.CPacketClientSettings;
import net.minecraft.network.play.client.CPacketClientStatus;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketConfirmTransaction;
import net.minecraft.network.play.client.CPacketCreativeInventoryAction;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.network.play.client.CPacketEnchantItem;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketInput;
import net.minecraft.network.play.client.CPacketKeepAlive;
import net.minecraft.network.play.client.CPacketPlaceRecipe;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerAbilities;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketRecipeInfo;
import net.minecraft.network.play.client.CPacketResourcePackStatus;
import net.minecraft.network.play.client.CPacketSeenAdvancements;
import net.minecraft.network.play.client.CPacketSpectate;
import net.minecraft.network.play.client.CPacketSteerBoat;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.network.play.client.CPacketUpdateSign;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketVehicleMove;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketConfirmTransaction;
import net.minecraft.network.play.server.SPacketDisconnect;
import net.minecraft.network.play.server.SPacketHeldItemChange;
import net.minecraft.network.play.server.SPacketKeepAlive;
import net.minecraft.network.play.server.SPacketMoveVehicle;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketRespawn;
import net.minecraft.network.play.server.SPacketSetSlot;
import net.minecraft.network.play.server.SPacketTabComplete;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.CommandBlockBaseLogic;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityCommandBlock;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.tileentity.TileEntityStructure;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ITickable;
import net.minecraft.util.IntHashMap;
import net.minecraft.util.Mirror;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Rotation;
import net.minecraft.util.ServerRecipeBookHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.DimensionType;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class NetHandlerPlayServer implements INetHandlerPlayServer, ITickable {
   // $FF: synthetic field
   private double lastGoodY;
   // $FF: synthetic field
   private double lowestRiddenX1;
   // $FF: synthetic field
   private double firstGoodX;
   // $FF: synthetic field
   private double lowestRiddenZ1;
   // $FF: synthetic field
   private Entity lowestRiddenEnt;
   // $FF: synthetic field
   private final IntHashMap<Short> pendingTransactions = new IntHashMap();
   // $FF: synthetic field
   private long field_194404_h;
   // $FF: synthetic field
   private int movePacketCounter;
   // $FF: synthetic field
   private ServerRecipeBookHelper field_194309_H = new ServerRecipeBookHelper();
   // $FF: synthetic field
   private int chatSpamThresholdCount;
   // $FF: synthetic field
   private int lastPositionUpdate;
   // $FF: synthetic field
   private long field_194402_f;
   // $FF: synthetic field
   private int vehicleFloatingTickCount;
   // $FF: synthetic field
   private double lastGoodX;
   // $FF: synthetic field
   private final MinecraftServer serverController;
   // $FF: synthetic field
   private int lastMovePacketCounter;
   // $FF: synthetic field
   private int networkTickCount;
   // $FF: synthetic field
   private double lowestRiddenY;
   // $FF: synthetic field
   private Vec3d targetPos;
   // $FF: synthetic field
   private double firstGoodY;
   // $FF: synthetic field
   public EntityPlayerMP playerEntity;
   // $FF: synthetic field
   private boolean vehicleFloating;
   // $FF: synthetic field
   private double lowestRiddenX;
   // $FF: synthetic field
   private boolean field_194403_g;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final Logger LOGGER;
   // $FF: synthetic field
   private int floatingTickCount;
   // $FF: synthetic field
   private int teleportId;
   // $FF: synthetic field
   private double lowestRiddenZ;
   // $FF: synthetic field
   public final NetworkManager netManager;
   // $FF: synthetic field
   private double lastGoodZ;
   // $FF: synthetic field
   private double firstGoodZ;
   // $FF: synthetic field
   private boolean floating;
   // $FF: synthetic field
   private int itemDropThreshold;
   // $FF: synthetic field
   private double lowestRiddenY1;

   public void processVehicleMove(CPacketVehicleMove var1) {
      String var10000 = I[207 ^ 169];
      String var10001 = I[84 ^ 51];
      String var10002 = I[201 ^ 161];
      var10001 = I[125 ^ 20];
      var10000 = I[226 ^ 136];
      var10001 = I[117 ^ 30];
      var10002 = I[195 ^ 175];
      var10001 = I[230 ^ 139];
      var10000 = I[215 ^ 185];
      var10001 = I[21 ^ 122];
      var10002 = I[230 ^ 150];
      var10001 = I[215 ^ 166];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      if (isMoveVehiclePacketInvalid(var1)) {
         I[88 ^ 42].length();
         this.func_194028_b(new TextComponentTranslation(I[29 ^ 110], new Object["".length()]));
         "".length();
         if (3 <= 1) {
            throw null;
         }
      } else {
         Entity var2 = this.playerEntity.getLowestRidingEntity();
         if (var2 != this.playerEntity && var2.getControllingPassenger() == this.playerEntity && var2 == this.lowestRiddenEnt) {
            WorldServer var3 = this.playerEntity.getServerWorld();
            double var4 = var2.posX;
            double var6 = var2.posY;
            double var8 = var2.posZ;
            double var10 = var1.getX();
            double var12 = var1.getY();
            double var14 = var1.getZ();
            float var16 = var1.getYaw();
            float var17 = var1.getPitch();
            double var36 = this.lowestRiddenX;
            I[198 ^ 178].length();
            I[112 ^ 5].length();
            double var18 = var10 - var36;
            var36 = this.lowestRiddenY;
            I[182 ^ 192].length();
            I[15 ^ 120].length();
            I[108 ^ 20].length();
            double var20 = var12 - var36;
            var36 = this.lowestRiddenZ;
            I[86 ^ 47].length();
            I[32 ^ 90].length();
            I[88 ^ 35].length();
            double var22 = var14 - var36;
            double var24 = var2.motionX * var2.motionX + var2.motionY * var2.motionY + var2.motionZ * var2.motionZ;
            double var26 = var18 * var18 + var20 * var20 + var22 * var22;
            I[252 ^ 128].length();
            I[9 ^ 116].length();
            I[89 ^ 39].length();
            NetworkManager var35;
            if (var26 - var24 > 100.0D && (!this.serverController.isSinglePlayer() || !this.serverController.getServerOwner().equals(var2.getName()))) {
               LOGGER.warn(I[107 + 77 - 125 + 68], var2.getName(), this.playerEntity.getName(), var18, var20, var22);
               var35 = this.netManager;
               I[101 + 23 - 41 + 45].length();
               I[38 + 97 - 18 + 12].length();
               var35.sendPacket(new SPacketMoveVehicle(var2));
               return;
            }

            boolean var28 = var3.getCollisionBoxes(var2, var2.getEntityBoundingBox().contract(0.0625D)).isEmpty();
            var36 = this.lowestRiddenX1;
            I[102 + 67 - 69 + 30].length();
            I[93 + 29 - -5 + 4].length();
            I[103 + 61 - 34 + 2].length();
            I[61 + 82 - 59 + 49].length();
            var18 = var10 - var36;
            var36 = this.lowestRiddenY1;
            I[38 + 105 - 140 + 131].length();
            I[114 + 106 - 154 + 69].length();
            double var33 = var12 - var36;
            I[116 + 77 - 182 + 125].length();
            var20 = var33 - 1.0E-6D;
            var36 = this.lowestRiddenZ1;
            I[28 + 58 - 81 + 132].length();
            I[40 + 94 - 106 + 110].length();
            var22 = var14 - var36;
            var2.moveEntity(MoverType.PLAYER, var18, var20, var22);
            double var29 = var20;
            var36 = var2.posX;
            I[43 + 43 - -37 + 16].length();
            var18 = var10 - var36;
            var36 = var2.posY;
            I[15 + 96 - 15 + 44].length();
            I[20 + 18 - 8 + 111].length();
            I[48 + 25 - -23 + 46].length();
            I[140 + 128 - 226 + 101].length();
            var20 = var12 - var36;
            if (var20 > -0.5D || var20 < 0.5D) {
               var20 = 0.0D;
            }

            var36 = var2.posZ;
            I[48 + 21 - 7 + 82].length();
            I[67 + 33 - -35 + 10].length();
            I[10 + 139 - 136 + 133].length();
            var22 = var14 - var36;
            var26 = var18 * var18 + var20 * var20 + var22 * var22;
            int var31 = "".length();
            if (var26 > 0.0625D) {
               var31 = " ".length();
               LOGGER.warn(I[128 + 95 - 77 + 1], var2.getName());
            }

            var2.setPositionAndRotation(var10, var12, var14, var16, var17);
            boolean var32 = var3.getCollisionBoxes(var2, var2.getEntityBoundingBox().contract(0.0625D)).isEmpty();
            if (var28 && (var31 != 0 || !var32)) {
               var2.setPositionAndRotation(var4, var6, var8, var16, var17);
               var35 = this.netManager;
               I[3 + 39 - -77 + 29].length();
               I[111 + 34 - 42 + 46].length();
               var35.sendPacket(new SPacketMoveVehicle(var2));
               return;
            }

            this.serverController.getPlayerList().serverUpdateMovingPlayer(this.playerEntity);
            EntityPlayerMP var34 = this.playerEntity;
            var36 = this.playerEntity.posX;
            I[78 + 42 - 99 + 129].length();
            I[47 + 82 - 118 + 140].length();
            var36 -= var4;
            double var37 = this.playerEntity.posY;
            I[71 + 42 - 41 + 80].length();
            I[87 + 142 - 162 + 86].length();
            var37 -= var6;
            double var10003 = this.playerEntity.posZ;
            I[87 + 124 - 200 + 143].length();
            I[101 + 6 - 5 + 53].length();
            I[8 + 90 - -56 + 2].length();
            var34.addMovementStat(var36, var37, var10003 - var8);
            int var38;
            if (var29 >= -0.03125D && !this.serverController.isFlightAllowed() && !var3.checkBlockCollision(var2.getEntityBoundingBox().expandXyz(0.0625D).addCoord(0.0D, -0.55D, 0.0D))) {
               var38 = " ".length();
               "".length();
               if (3 < -1) {
                  throw null;
               }
            } else {
               var38 = "".length();
            }

            this.vehicleFloating = (boolean)var38;
            this.lowestRiddenX1 = var2.posX;
            this.lowestRiddenY1 = var2.posY;
            this.lowestRiddenZ1 = var2.posZ;
         }
      }

   }

   static {
      I();
      LOGGER = LogManager.getLogger();
   }

   public void processUseEntity(CPacketUseEntity var1) {
      String var10000 = I[105 + 285 - 139 + 209];
      String var10001 = I[194 + 150 - 192 + 309];
      String var10002 = I[218 + 431 - 370 + 183];
      var10001 = I[200 + 278 - 152 + 137];
      var10000 = I[179 + 21 - -93 + 171];
      var10001 = I[277 + 188 - 127 + 127];
      var10002 = I[55 + 57 - -333 + 21];
      var10001 = I[57 + 49 - -118 + 243];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      WorldServer var2 = this.serverController.getWorld(this.playerEntity.dimension);
      Entity var3 = var1.getEntityFromWorld(var2);
      this.playerEntity.markPlayerActive();
      if (var3 != null) {
         boolean var4 = this.playerEntity.canEntityBeSeen(var3);
         double var5 = 36.0D;
         if (!var4) {
            var5 = 9.0D;
         }

         if (this.playerEntity.getDistanceSqToEntity(var3) < var5) {
            EnumHand var7;
            if (var1.getAction() == CPacketUseEntity.Action.INTERACT) {
               var7 = var1.getHand();
               this.playerEntity.func_190775_a(var3, var7);
               I[464 + 121 - 508 + 391].length();
               I[6 + 219 - -67 + 177].length();
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            } else if (var1.getAction() == CPacketUseEntity.Action.INTERACT_AT) {
               var7 = var1.getHand();
               var3.applyPlayerInteraction(this.playerEntity, var1.getHitVec(), var7);
               I[412 + 349 - 619 + 328].length();
               I[28 + 143 - -271 + 29].length();
               I[213 + 191 - 224 + 292].length();
               I[469 + 412 - 793 + 385].length();
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            } else if (var1.getAction() == CPacketUseEntity.Action.ATTACK) {
               if (var3 instanceof EntityItem || var3 instanceof EntityXPOrb || var3 instanceof EntityArrow || var3 == this.playerEntity) {
                  I[170 + 326 - 464 + 442].length();
                  I[377 + 225 - 410 + 283].length();
                  I[211 + 209 - 66 + 122].length();
                  I[149 + 326 - 345 + 347].length();
                  this.func_194028_b(new TextComponentTranslation(I[297 + 390 - 435 + 226], new Object["".length()]));
                  MinecraftServer var8 = this.serverController;
                  I[329 + 336 - 645 + 459].length();
                  I[35 + 231 - 57 + 271].length();
                  I[347 + 163 - 54 + 25].length();
                  var8.logWarning(I[34 + 119 - -240 + 89] + this.playerEntity.getName() + I[44 + 74 - -153 + 212]);
                  return;
               }

               this.playerEntity.attackTargetEntityWithCurrentItem(var3);
            }
         }
      }

   }

   private static boolean isMovePlayerPacketInvalid(CPacketPlayer var0) {
      if (Doubles.isFinite(var0.getX(0.0D)) && Doubles.isFinite(var0.getY(0.0D)) && Doubles.isFinite(var0.getZ(0.0D)) && Floats.isFinite(var0.getPitch(0.0F)) && Floats.isFinite(var0.getYaw(0.0F))) {
         int var10000;
         if (!(Math.abs(var0.getX(0.0D)) > 3.0E7D) && !(Math.abs(var0.getY(0.0D)) > 3.0E7D) && !(Math.abs(var0.getZ(0.0D)) > 3.0E7D)) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (2 == 0) {
               throw null;
            }
         }

         return (boolean)var10000;
      } else {
         return (boolean)" ".length();
      }
   }

   public void func_191984_a(CPacketRecipeInfo var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      if (var1.func_194156_a() == CPacketRecipeInfo.Purpose.SHOWN) {
         this.playerEntity.func_192037_E().func_194074_f(var1.func_193648_b());
         "".length();
         if (4 == 1) {
            throw null;
         }
      } else if (var1.func_194156_a() == CPacketRecipeInfo.Purpose.SETTINGS) {
         this.playerEntity.func_192037_E().func_192813_a(var1.func_192624_c());
         this.playerEntity.func_192037_E().func_192810_b(var1.func_192625_d());
      }

   }

   public NetHandlerPlayServer(MinecraftServer var1, NetworkManager var2, EntityPlayerMP var3) {
      this.serverController = var1;
      this.netManager = var2;
      var2.setNetHandler(this);
      this.playerEntity = var3;
      var3.connection = this;
   }

   public void processPlayerDigging(CPacketPlayerDigging var1) {
      String var10000 = I[95 + 12 - -52 + 99];
      String var10001 = I[44 + 21 - -187 + 7];
      String var10002 = I[205 + 153 - 295 + 197];
      var10001 = I[154 + 238 - 380 + 249];
      var10000 = I[34 + 76 - -90 + 62];
      var10001 = I[124 + 207 - 312 + 244];
      var10002 = I[214 + 27 - 58 + 81];
      var10001 = I[230 + 77 - 231 + 189];
      var10000 = I[146 + 74 - 103 + 149];
      var10001 = I[258 + 204 - 282 + 87];
      var10002 = I[266 + 141 - 330 + 191];
      var10001 = I[11 + 224 - 27 + 61];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      WorldServer var2 = this.serverController.getWorld(this.playerEntity.dimension);
      BlockPos var3 = var1.getPosition();
      this.playerEntity.markPlayerActive();
      switch(null.$SwitchMap$net$minecraft$network$play$client$CPacketPlayerDigging$Action[var1.getAction().ordinal()]) {
      case 1:
         if (!this.playerEntity.isSpectator()) {
            ItemStack var12 = this.playerEntity.getHeldItem(EnumHand.OFF_HAND);
            this.playerEntity.setHeldItem(EnumHand.OFF_HAND, this.playerEntity.getHeldItem(EnumHand.MAIN_HAND));
            this.playerEntity.setHeldItem(EnumHand.MAIN_HAND, var12);
         }

         return;
      case 2:
         if (!this.playerEntity.isSpectator()) {
            this.playerEntity.dropItem((boolean)"".length());
            I[245 + 226 - 339 + 138].length();
            I[82 + 52 - 24 + 161].length();
            I[259 + 139 - 248 + 122].length();
            I[97 + 235 - 222 + 163].length();
         }

         return;
      case 3:
         if (!this.playerEntity.isSpectator()) {
            this.playerEntity.dropItem((boolean)" ".length());
            I[118 + 87 - -66 + 3].length();
            I[213 + 232 - 317 + 147].length();
            I[16 + 13 - -78 + 169].length();
         }

         return;
      case 4:
         this.playerEntity.stopActiveHand();
         return;
      case 5:
      case 6:
      case 7:
         double var13 = this.playerEntity.posX;
         double var16 = (double)var3.getX() + 0.5D;
         I[212 + 26 - 44 + 83].length();
         I[165 + 189 - 107 + 31].length();
         I[58 + 198 - 42 + 65].length();
         I[85 + 177 - 50 + 68].length();
         double var4 = var13 - var16;
         var13 = this.playerEntity.posY;
         var16 = (double)var3.getY() + 0.5D;
         I[145 + 22 - -89 + 25].length();
         I[136 + 182 - 289 + 253].length();
         I[25 + 142 - 9 + 125].length();
         double var6 = var13 - var16 + 1.5D;
         var13 = this.playerEntity.posZ;
         var16 = (double)var3.getZ() + 0.5D;
         I[49 + 0 - -73 + 162].length();
         I[122 + 32 - 82 + 213].length();
         double var8 = var13 - var16;
         double var10 = var4 * var4 + var6 * var6 + var8 * var8;
         if (var10 > 36.0D) {
            return;
         } else if (var3.getY() >= this.serverController.getBuildLimit()) {
            return;
         } else {
            NetHandlerPlayServer var14;
            if (var1.getAction() == CPacketPlayerDigging.Action.START_DESTROY_BLOCK) {
               if (!this.serverController.isBlockProtected(var2, var3, this.playerEntity) && var2.getWorldBorder().contains(var3)) {
                  this.playerEntity.interactionManager.onBlockClicked(var3, var1.getFacing());
                  "".length();
                  if (2 != 2) {
                     throw null;
                  }
               } else {
                  var14 = this.playerEntity.connection;
                  I[258 + 52 - 184 + 160].length();
                  I[9 + 24 - -140 + 114].length();
                  I[56 + 37 - -171 + 24].length();
                  var14.sendPacket(new SPacketBlockChange(var2, var3));
                  "".length();
                  if (3 == 2) {
                     throw null;
                  }
               }
            } else {
               if (var1.getAction() == CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                  this.playerEntity.interactionManager.blockRemoving(var3);
                  "".length();
                  if (-1 != -1) {
                     throw null;
                  }
               } else if (var1.getAction() == CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK) {
                  this.playerEntity.interactionManager.cancelDestroyingBlock();
               }

               if (var2.getBlockState(var3).getMaterial() != Material.AIR) {
                  var14 = this.playerEntity.connection;
                  I[273 + 97 - 299 + 218].length();
                  I[116 + 169 - 151 + 156].length();
                  I[56 + 36 - 58 + 257].length();
                  var14.sendPacket(new SPacketBlockChange(var2, var3));
               }
            }

            return;
         }
      default:
         I[90 + 27 - 113 + 288].length();
         I[77 + 28 - -39 + 149].length();
         IllegalArgumentException var15 = new IllegalArgumentException(I[212 + 287 - 388 + 183]);
         I[229 + 141 - 340 + 265].length();
         I[220 + 209 - 172 + 39].length();
         I[53 + 36 - -87 + 121].length();
         I[132 + 154 - 283 + 295].length();
         throw var15;
      }
   }

   public void processInput(CPacketInput var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.setEntityActionState(var1.getStrafeSpeed(), var1.func_192620_b(), var1.isJumping(), var1.isSneaking());
   }

   public void processUpdateSign(CPacketUpdateSign var1) {
      String var10000 = I[210 + 337 - 123 + 114];
      String var10001 = I[276 + 385 - 134 + 12];
      String var10002 = I[111 + 251 - 4 + 182];
      var10001 = I[422 + 110 - 331 + 340];
      var10000 = I[450 + 457 - 548 + 183];
      var10001 = I[205 + 365 - 558 + 531];
      var10002 = I[92 + 327 - -4 + 121];
      var10001 = I[496 + 2 - -47 + 0];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.markPlayerActive();
      WorldServer var2 = this.serverController.getWorld(this.playerEntity.dimension);
      BlockPos var3 = var1.getPosition();
      if (var2.isBlockLoaded(var3)) {
         IBlockState var4 = var2.getBlockState(var3);
         TileEntity var5 = var2.getTileEntity(var3);
         if (!(var5 instanceof TileEntitySign)) {
            return;
         }

         TileEntitySign var6 = (TileEntitySign)var5;
         if (!var6.getIsEditable() || var6.getPlayer() != this.playerEntity) {
            MinecraftServer var10 = this.serverController;
            I[137 + 160 - 81 + 330].length();
            I[146 + 108 - 74 + 367].length();
            I[531 + 364 - 580 + 233].length();
            I[538 + 232 - 690 + 469].length();
            var10.logWarning(I[331 + 140 - 162 + 241] + this.playerEntity.getName() + I[50 + 104 - -97 + 300]);
            return;
         }

         String[] var7 = var1.getLines();
         int var8 = "".length();

         while(var8 < var7.length) {
            ITextComponent[] var9 = var6.signText;
            I[325 + 40 - 97 + 284].length();
            I[271 + 139 - 395 + 538].length();
            I[218 + 292 - 194 + 238].length();
            I[17 + 537 - 244 + 245].length();
            var9[var8] = new TextComponentString(TextFormatting.getTextWithoutFormattingCodes(var7[var8]));
            ++var8;
            "".length();
            if (false) {
               throw null;
            }
         }

         var6.markDirty();
         var2.notifyBlockUpdate(var3, var4, var4, "   ".length());
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != -1);

      throw null;
   }

   public void processPlayerBlockPlacement(CPacketPlayerTryUseItem var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      WorldServer var2 = this.serverController.getWorld(this.playerEntity.dimension);
      EnumHand var3 = var1.getHand();
      ItemStack var4 = this.playerEntity.getHeldItem(var3);
      this.playerEntity.markPlayerActive();
      if (!var4.isEmpty()) {
         this.playerEntity.interactionManager.processRightClick(this.playerEntity, var2, var4, var3);
         I[28 + 309 - 254 + 252].length();
         I[264 + 167 - 336 + 241].length();
         I[308 + 201 - 385 + 213].length();
      }

   }

   public void handleResourcePackStatus(CPacketResourcePackStatus var1) {
   }

   public void processClickWindow(CPacketClickWindow var1) {
      String var10000 = I[442 + 371 - 600 + 273];
      String var10001 = I[172 + 189 - 64 + 190];
      String var10002 = I[206 + 47 - 20 + 255];
      var10001 = I[131 + 126 - -144 + 88];
      var10000 = I[290 + 250 - 284 + 234];
      var10001 = I[221 + 374 - 312 + 208];
      var10002 = I[193 + 363 - 305 + 241];
      var10001 = I[141 + 428 - 151 + 75];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.markPlayerActive();
      if (this.playerEntity.openContainer.windowId == var1.getWindowId() && this.playerEntity.openContainer.getCanCraft(this.playerEntity)) {
         if (this.playerEntity.isSpectator()) {
            NonNullList var2 = NonNullList.func_191196_a();
            int var3 = "".length();

            while(var3 < this.playerEntity.openContainer.inventorySlots.size()) {
               var2.add(((Slot)this.playerEntity.openContainer.inventorySlots.get(var3)).getStack());
               I[58 + 34 - -218 + 184].length();
               I[299 + 306 - 450 + 340].length();
               I[457 + 226 - 647 + 460].length();
               ++var3;
               "".length();
               if (4 <= 1) {
                  throw null;
               }
            }

            this.playerEntity.updateCraftingInventory(this.playerEntity.openContainer, var2);
            "".length();
            if (0 >= 4) {
               throw null;
            }
         } else {
            ItemStack var7 = this.playerEntity.openContainer.slotClick(var1.getSlotId(), var1.getUsedButton(), var1.getClickType(), this.playerEntity);
            NetHandlerPlayServer var9;
            if (ItemStack.areItemStacksEqual(var1.getClickedItem(), var7)) {
               var9 = this.playerEntity.connection;
               I[330 + 279 - 478 + 366].length();
               I[162 + 235 - 60 + 161].length();
               I[4 + 315 - 234 + 414].length();
               I[146 + 284 - 349 + 419].length();
               var9.sendPacket(new SPacketConfirmTransaction(var1.getWindowId(), var1.getActionNumber(), (boolean)" ".length()));
               this.playerEntity.isChangingQuantityOnly = (boolean)" ".length();
               this.playerEntity.openContainer.detectAndSendChanges();
               this.playerEntity.updateHeldItem();
               this.playerEntity.isChangingQuantityOnly = (boolean)"".length();
               "".length();
               if (4 < 0) {
                  throw null;
               }
            } else {
               this.pendingTransactions.addKey(this.playerEntity.openContainer.windowId, var1.getActionNumber());
               var9 = this.playerEntity.connection;
               I[466 + 300 - 483 + 218].length();
               I[182 + 218 - -13 + 89].length();
               I[147 + 437 - 155 + 74].length();
               var9.sendPacket(new SPacketConfirmTransaction(var1.getWindowId(), var1.getActionNumber(), (boolean)"".length()));
               this.playerEntity.openContainer.setCanCraft(this.playerEntity, (boolean)"".length());
               NonNullList var8 = NonNullList.func_191196_a();
               int var4 = "".length();

               while(var4 < this.playerEntity.openContainer.inventorySlots.size()) {
                  ItemStack var5 = ((Slot)this.playerEntity.openContainer.inventorySlots.get(var4)).getStack();
                  ItemStack var10;
                  if (var5.isEmpty()) {
                     var10 = ItemStack.field_190927_a;
                     "".length();
                     if (1 == -1) {
                        throw null;
                     }
                  } else {
                     var10 = var5;
                  }

                  ItemStack var6 = var10;
                  var8.add(var6);
                  I[74 + 151 - -169 + 110].length();
                  I[60 + 300 - 285 + 430].length();
                  ++var4;
                  "".length();
                  if (3 < 0) {
                     throw null;
                  }
               }

               this.playerEntity.updateCraftingInventory(this.playerEntity.openContainer, var8);
            }
         }
      }

   }

   public void func_194028_b(final ITextComponent var1) {
      String var10000 = I[16 ^ 64];
      String var10001 = I[203 ^ 154];
      String var10002 = I[192 ^ 146];
      var10001 = I[228 ^ 183];
      var10000 = I[0 ^ 84];
      var10001 = I[151 ^ 194];
      var10002 = I[40 ^ 126];
      var10001 = I[113 ^ 38];
      var10000 = I[41 ^ 113];
      var10001 = I[54 ^ 111];
      var10002 = I[26 ^ 64];
      var10001 = I[74 ^ 17];
      NetworkManager var2 = this.netManager;
      I[52 ^ 104].length();
      I[114 ^ 47].length();
      I[114 ^ 44].length();
      SPacketDisconnect var4 = new SPacketDisconnect(var1);
      I[221 ^ 130].length();
      I[10 ^ 106].length();
      var2.sendPacket(var4, new GenericFutureListener<Future<? super Void>>() {
         public void operationComplete(Future<? super Void> var1x) throws Exception {
            NetHandlerPlayServer.this.netManager.closeChannel(var1);
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(1 < 4);

            throw null;
         }
      });
      this.netManager.disableAutoRead();
      MinecraftServer var3 = this.serverController;
      I[20 ^ 117].length();
      Futures.getUnchecked(var3.addScheduledTask(new Runnable() {
         public void run() {
            NetHandlerPlayServer.this.netManager.checkDisconnected();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 == 4);

            throw null;
         }
      }));
      I[161 ^ 195].length();
      I[12 ^ 111].length();
      I[60 ^ 88].length();
      I[122 ^ 31].length();
   }

   public void processSteerBoat(CPacketSteerBoat var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      Entity var2 = this.playerEntity.getRidingEntity();
      if (var2 instanceof EntityBoat) {
         ((EntityBoat)var2).setPaddleState(var1.getLeft(), var1.getRight());
      }

   }

   public void setPlayerLocation(double var1, double var3, double var5, float var7, float var8, Set<SPacketPlayerPosLook.EnumFlags> var9) {
      String var10000 = I[183 + 36 - 197 + 214];
      String var10001 = I[37 + 0 - -104 + 96];
      String var10002 = I[207 + 207 - 295 + 119];
      var10001 = I[23 + 228 - 109 + 97];
      var10000 = I[183 + 154 - 289 + 192];
      var10001 = I[190 + 133 - 91 + 9];
      var10002 = I[80 + 158 - 14 + 18];
      var10001 = I[202 + 130 - 254 + 165];
      var10000 = I[134 + 90 - 112 + 132];
      var10001 = I[187 + 58 - 49 + 49];
      var10002 = I[21 + 222 - 159 + 162];
      var10001 = I[94 + 14 - -49 + 90];
      double var18;
      if (var9.contains(SPacketPlayerPosLook.EnumFlags.X)) {
         var18 = this.playerEntity.posX;
         "".length();
         if (4 <= 1) {
            throw null;
         }
      } else {
         var18 = 0.0D;
      }

      double var10 = var18;
      if (var9.contains(SPacketPlayerPosLook.EnumFlags.Y)) {
         var18 = this.playerEntity.posY;
         "".length();
         if (3 < 3) {
            throw null;
         }
      } else {
         var18 = 0.0D;
      }

      double var12 = var18;
      if (var9.contains(SPacketPlayerPosLook.EnumFlags.Z)) {
         var18 = this.playerEntity.posZ;
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      } else {
         var18 = 0.0D;
      }

      double var14 = var18;
      I[232 + 104 - 206 + 118].length();
      I[221 + 238 - 263 + 53].length();
      this.targetPos = new Vec3d(var1 + var10, var3 + var12, var5 + var14);
      float var16 = var7;
      float var17 = var8;
      if (var9.contains(SPacketPlayerPosLook.EnumFlags.Y_ROT)) {
         var16 = var7 + this.playerEntity.rotationYaw;
      }

      if (var9.contains(SPacketPlayerPosLook.EnumFlags.X_ROT)) {
         var17 = var8 + this.playerEntity.rotationPitch;
      }

      I[195 + 42 - 127 + 140].length();
      I[36 + 9 - -70 + 136].length();
      I[213 + 119 - 222 + 142].length();
      I[96 + 67 - -25 + 65].length();
      I[61 + 224 - 38 + 7].length();
      if ((this.teleportId += " ".length()) == 359877894 + 236017123 - -1013287613 + 538301017) {
         this.teleportId = "".length();
      }

      this.lastPositionUpdate = this.networkTickCount;
      this.playerEntity.setPositionAndRotation(this.targetPos.x, this.targetPos.y, this.targetPos.z, var16, var17);
      NetHandlerPlayServer var19 = this.playerEntity.connection;
      I[242 + 34 - 102 + 81].length();
      I[58 + 125 - 146 + 219].length();
      I[255 + 214 - 254 + 42].length();
      var19.sendPacket(new SPacketPlayerPosLook(var1, var3, var5, var7, var8, var9, this.teleportId));
   }

   private static boolean isMoveVehiclePacketInvalid(CPacketVehicleMove var0) {
      int var10000;
      if (Doubles.isFinite(var0.getX()) && Doubles.isFinite(var0.getY()) && Doubles.isFinite(var0.getZ()) && Floats.isFinite(var0.getPitch()) && Floats.isFinite(var0.getYaw())) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (2 == 1) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public void handleAnimation(CPacketAnimation var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.markPlayerActive();
      this.playerEntity.swingArm(var1.getHand());
   }

   private void handleSlashCommand(String var1) {
      this.serverController.getCommandManager().executeCommand(this.playerEntity, var1);
      I[340 + 229 - 503 + 379].length();
   }

   public void sendPacket(final Packet<?> var1) {
      String var10000 = I[26 + 262 - 248 + 324];
      String var10001 = I[363 + 255 - 397 + 144];
      String var10002 = I[303 + 212 - 333 + 184];
      var10001 = I[92 + 100 - -52 + 123];
      var10000 = I[344 + 301 - 430 + 153];
      var10001 = I[191 + 279 - 202 + 101];
      var10002 = I[349 + 323 - 615 + 313];
      var10001 = I[3 + 149 - -4 + 215];
      if (var1 instanceof SPacketChat) {
         SPacketChat var2 = (SPacketChat)var1;
         EntityPlayer.EnumChatVisibility var3 = this.playerEntity.getChatVisibility();
         if (var3 == EntityPlayer.EnumChatVisibility.HIDDEN && var2.func_192590_c() != ChatType.GAME_INFO) {
            return;
         }

         if (var3 == EntityPlayer.EnumChatVisibility.SYSTEM && !var2.isSystem()) {
            return;
         }
      }

      try {
         this.netManager.sendPacket(var1);
      } catch (Throwable var5) {
         CrashReport var6 = CrashReport.makeCrashReport(var5, I[77 + 23 - -92 + 180]);
         CrashReportCategory var4 = var6.makeCategory(I[109 + 31 - -54 + 179]);
         var10001 = I[369 + 253 - 252 + 4];
         I[349 + 41 - 306 + 291].length();
         I[14 + 333 - 79 + 108].length();
         I[320 + 358 - 629 + 328].length();
         I[96 + 287 - 276 + 271].length();
         var4.setDetail(var10001, new ICrashReportDetail<String>() {
            public String call() throws Exception {
               return var1.getClass().getCanonicalName();
            }

            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(0 != -1);

               throw null;
            }
         });
         I[147 + 329 - 255 + 158].length();
         I[242 + 369 - 387 + 156].length();
         ReportedException var7 = new ReportedException(var6);
         I[232 + 252 - 357 + 254].length();
         I[109 + 87 - -186 + 0].length();
         throw var7;
      }

      "".length();
      if (3 != 3) {
         throw null;
      }
   }

   public void processEnchantItem(CPacketEnchantItem var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.markPlayerActive();
      if (this.playerEntity.openContainer.windowId == var1.getWindowId() && this.playerEntity.openContainer.getCanCraft(this.playerEntity) && !this.playerEntity.isSpectator()) {
         this.playerEntity.openContainer.enchantItem(this.playerEntity, var1.getButton());
         I[399 + 394 - 791 + 504].length();
         I[210 + 234 - -21 + 42].length();
         I[204 + 23 - 51 + 332].length();
         this.playerEntity.openContainer.detectAndSendChanges();
      }

   }

   public void onDisconnect(ITextComponent var1) {
      String var10000 = I[298 + 142 - 216 + 123];
      String var10001 = I[249 + 334 - 541 + 306];
      String var10002 = I[335 + 53 - 262 + 223];
      var10001 = I[260 + 132 - 90 + 48];
      var10000 = I[148 + 314 - 127 + 16];
      var10001 = I[316 + 341 - 491 + 186];
      var10002 = I[112 + 175 - 145 + 211];
      var10001 = I[258 + 11 - 79 + 164];
      LOGGER.info(I[255 + 246 - 426 + 280], this.playerEntity.getName(), var1.getUnformattedText());
      this.serverController.refreshStatusNextTick();
      I[269 + 60 - 170 + 197].length();
      var10002 = I[353 + 203 - 322 + 123];
      Object[] var10003 = new Object[" ".length()];
      I[260 + 282 - 338 + 154].length();
      I[191 + 205 - 43 + 6].length();
      var10003["".length()] = this.playerEntity.getDisplayName();
      TextComponentTranslation var2 = new TextComponentTranslation(var10002, var10003);
      var2.getStyle().setColor(TextFormatting.YELLOW);
      I[157 + 205 - 273 + 271].length();
      I[113 + 243 - 23 + 28].length();
      I[73 + 90 - 40 + 239].length();
      this.serverController.getPlayerList().sendChatMsg(var2);
      this.playerEntity.mountEntityAndWakeUp();
      this.serverController.getPlayerList().playerLoggedOut(this.playerEntity);
      if (this.serverController.isSinglePlayer() && this.playerEntity.getName().equals(this.serverController.getServerOwner())) {
         LOGGER.info(I[111 + 46 - 27 + 233]);
         this.serverController.initiateShutdown();
      }

   }

   public void processConfirmTeleport(CPacketConfirmTeleport var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      if (var1.getTeleportId() == this.teleportId) {
         this.playerEntity.setPositionAndRotation(this.targetPos.x, this.targetPos.y, this.targetPos.z, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
         if (this.playerEntity.isInvulnerableDimensionChange()) {
            this.lastGoodX = this.targetPos.x;
            this.lastGoodY = this.targetPos.y;
            this.lastGoodZ = this.targetPos.z;
            this.playerEntity.clearInvulnerableDimensionChange();
         }

         this.targetPos = null;
      }

   }

   private static void I() {
      I = new String[593 + 6 - 153 + 413];
      I["".length()] = I("旽侇", "QckWo");
      I[" ".length()] = I("嫘奕", "wmNMk");
      I["  ".length()] = I("栛漇", "NjhIf");
      I["   ".length()] = I("僽斳", "JDLwy");
      I[188 ^ 184] = I("嫦嬓", "zCLyr");
      I[198 ^ 195] = I("栫涃", "wJPoD");
      I[3 ^ 5] = I("堉满", "MGwuH");
      I[177 ^ 182] = I("嶊會", "fLyqz");
      I[99 ^ 107] = I("仸型", "gYeXa");
      I[123 ^ 114] = I("浳淭", "tvJQl");
      I[84 ^ 94] = I("戗怸", "eoLOS");
      I[55 ^ 60] = I("桼泴", "ieYDG");
      I[122 ^ 118] = I("斅漹", "wumcD");
      I[31 ^ 18] = I("庹僺", "QwgoY");
      I[27 ^ 21] = I("吿崎", "CaQUi");
      I[180 ^ 187] = I("湺樂", "xiWlT");
      I[167 ^ 183] = I("慅澳", "uUItq");
      I[137 ^ 152] = I("圃嬌", "vwREC");
      I[44 ^ 62] = I("宥呣", "RcVPo");
      I[114 ^ 97] = I("匎墎", "TJZnt");
      I[29 ^ 9] = I("儶攕", "DOOyw");
      I[153 ^ 140] = I("婴倨", "NkUAQ");
      I[19 ^ 5] = I("樷岬", "zbqAR");
      I[160 ^ 183] = I("僕灥", "AWiYP");
      I[8 ^ 16] = I("伜渹", "IyxlT");
      I[37 ^ 60] = I("勶嵝", "HYhXx");
      I[77 ^ 87] = I("娪潞", "ITIjn");
      I[78 ^ 85] = I("愽冹", "LBpNB");
      I[142 ^ 146] = I("戮榰", "mjzJy");
      I[177 ^ 172] = I("桃傠", "BKixv");
      I[12 ^ 18] = I("漨梴", "SEWId");
      I[131 ^ 156] = I("懸協", "yZiAD");
      I[113 ^ 81] = I("汁怕", "EIyKH");
      I[122 ^ 91] = I("烺体", "cTdiq");
      I[52 ^ 22] = I("煾専", "tfbvX");
      I[188 ^ 159] = I("楸杀", "tFUqC");
      I[186 ^ 158] = I("暇棹", "JVGEz");
      I[24 ^ 61] = I("氈崟", "JVnlw");
      I[165 ^ 131] = I("唤治", "jiUHm");
      I[48 ^ 23] = I("漄洆", "JEFMw");
      I[47 ^ 7] = I("摯", "PjbvC");
      I[112 ^ 89] = I("正怓娝恆", "YhPFj");
      I[19 ^ 57] = I("捗劃", "XdEJo");
      I[233 ^ 194] = I("媝炋彗凸", "DGXSv");
      I[189 ^ 145] = I("椟", "pwVxA");
      I[59 ^ 22] = I("\u000f5m/&\u0007h&1$\u001f-)x!\u001b:m>+\u001b)91)\u0013h97(T$\"6 U", "tHMXG");
      I[232 ^ 198] = I("嘂", "FNNtc");
      I[96 ^ 79] = I("仦", "QZhwz");
      I[57 ^ 9] = I(".3\u0015\u001a\u001f3*\u0018\u0017\u00131h\u001d\u0007\u0005 )\u0017\u0000\u0013 2W\b\u001a:/\u0017\t", "CFynv");
      I[30 ^ 47] = I("桌", "ABlop");
      I[51 ^ 1] = I("契梷", "sGbTW");
      I[162 ^ 145] = I("吶", "bgyTE");
      I[31 ^ 43] = I("*5I\u0002\u0006\"h\u0002\u001c\u0004:-\rU\u0001>:I\u0013\u000b>)\u001d\u001c\t6h\bU\u00114 \u0000\u0016\u000b4h\u001d\u001a\bq$\u0006\u001b\u0000p", "QHiug");
      I[170 ^ 159] = I("懜慰", "TwbuX");
      I[96 ^ 86] = I("摇瀀前惩垫", "YlETO");
      I[177 ^ 134] = I("榲暮扡", "CmwjP");
      I[70 ^ 126] = I("(\u0016\u0006#35\u000f\u000b.?7M\u000e>)&\f\u00049?&\u0017D16<\n\u00040", "EcjWZ");
      I[58 ^ 3] = I("\u00136\u0004\u0011\u0019\u0014:\u0017\u0004", "xSaaX");
      I[41 ^ 19] = I("宒", "zVmzT");
      I[9 ^ 50] = I("\u0003\u001c)\u0011?\t\u001b?\u0011$I\u00013\u001f5\b\u0000.", "guZrP");
      I[35 ^ 31] = I("另昪婘漣暮", "mCuFM");
      I[254 ^ 195] = I("掛炝", "HRJyF");
      I[49 ^ 15] = I("叀湗啋", "kbeuC");
      I[66 ^ 125] = I("卝忍洡氱尿", "YgGCo");
      I[1 ^ 65] = I("冲", "IrCaf");
      I[196 ^ 133] = I("倛", "rorar");
      I[248 ^ 186] = I("曶梼", "sRpKI");
      I[126 ^ 61] = I("摯杚倶奨", "TysIC");
      I[35 ^ 103] = I("演", "QFPSH");
      I[107 ^ 46] = I("汈埖", "amqAh");
      I[246 ^ 176] = I("幔梜煻枝", "cHqOi");
      I[206 ^ 137] = I("榐椮椨喜", "ItbCc");
      I[232 ^ 160] = I("埧濮嶱朞泇", "dqjdr");
      I[68 ^ 13] = I("潝", "OEEAG");
      I[205 ^ 135] = I("堘俜戹", "StjqI");
      I[239 ^ 164] = I("呻弼乼槸介", "cqIOM");
      I[141 ^ 193] = I("憻", "FYSyr");
      I[226 ^ 175] = I("动姴怃怘", "RgWtu");
      I[201 ^ 135] = I("懲块汍暯傜", "MhZJS");
      I[237 ^ 162] = I("\u0018\u001a\u0016\u0018\b\u0005\u0003\u001b\u0015\u0004\u0007A\u001e\u0005\u0012\u0016\u0000\u0014\u0002\u0004\u0016\u001bT\u0005\u0005\u0019\u0006\u0014\u000b", "uozla");
      I[88 ^ 8] = I("口挃", "paJve");
      I[97 ^ 48] = I("澻洟", "FnmkM");
      I[243 ^ 161] = I("怲湃", "jdXRj");
      I[193 ^ 146] = I("姣沔", "kPCnN");
      I[112 ^ 36] = I("倍涾", "IWpbd");
      I[249 ^ 172] = I("惊悥", "gXAoN");
      I[102 ^ 48] = I("灘涮", "DSSfO");
      I[239 ^ 184] = I("欆枀", "YVyBa");
      I[34 ^ 122] = I("冹撔", "crhCu");
      I[83 ^ 10] = I("坂宥", "Fznrn");
      I[22 ^ 76] = I("涗剣", "MwkZL");
      I[125 ^ 38] = I("懲炅", "DqHKY");
      I[255 ^ 163] = I("圞唨", "zkOgR");
      I[215 ^ 138] = I("淂", "FgHLQ");
      I[152 ^ 198] = I("愎", "YeWcI");
      I[65 ^ 30] = I("塸垤岋烎", "bVTuS");
      I[121 ^ 25] = I("斀塝檞", "eczwK");
      I[82 ^ 51] = I("斠昵夫", "oJfHf");
      I[252 ^ 158] = I("晊敥", "oOAIW");
      I[116 ^ 23] = I("庪丒氾", "FSgds");
      I[60 ^ 88] = I("恤哾奡易", "WdaAD");
      I[30 ^ 123] = I("灃檠幽公", "YrqSB");
      I[78 ^ 40] = I("栵嚖", "AJtTL");
      I[54 ^ 81] = I("懠奁", "ISnYN");
      I[1 ^ 105] = I("佻滊", "BLllZ");
      I[53 ^ 92] = I("哿旃", "oQLrh");
      I[71 ^ 45] = I("呜堚", "Kwcvu");
      I[229 ^ 142] = I("弒濃", "Frtni");
      I[94 ^ 50] = I("婨專", "jNqYj");
      I[66 ^ 47] = I("泖塈", "iCNIB");
      I[3 ^ 109] = I("樀唡", "qzvvh");
      I[47 ^ 64] = I("佄所", "CoBKn");
      I[249 ^ 137] = I("浲哸", "LPyrj");
      I[33 ^ 80] = I("倓撐", "PkyYN");
      I[240 ^ 130] = I("侰", "fJOwv");
      I[90 ^ 41] = I(">8%.\u0013#!(#\u001f!c-3\t0\"'4\u001f09g3\u0014%,%3\u001e\f;,2\u00130!,\u0005\u0017<;,7\u001f=9", "SMIZz");
      I[27 ^ 111] = I("乻桑妤", "XQdTV");
      I[211 ^ 166] = I("夊査", "sHsjb");
      I[49 ^ 71] = I("媟", "aqbOm");
      I[116 ^ 3] = I("漳湃", "IFdgJ");
      I[25 ^ 97] = I("瀫扆慀", "QIEHV");
      I[220 ^ 165] = I("椄沛", "eStpe");
      I[114 ^ 8] = I("弎", "XlZen");
      I[103 ^ 28] = I("匓庽擷柤", "rINoP");
      I[198 ^ 186] = I("姂満冑岤厅", "EGPud");
      I[247 ^ 138] = I("仵殪", "jSEXQ");
      I[221 ^ 163] = I("殟完忓", "uALcC");
      I[33 + 89 - 120 + 125] = I(")3cz37&*1)7n,4e)3jr(=8&6e&!,r4'' 9)+oc)8~5>~>/", "RNCRE");
      I[34 + 78 - 56 + 72] = I("棬", "ZmSXR");
      I[91 + 5 - 4 + 37] = I("欘徥櫒力毜", "kuhfW");
      I[53 + 29 - 68 + 116] = I("瀿扲渢橶", "YhApp");
      I[84 + 60 - 67 + 54] = I("孙匙束娎", "FRZpm");
      I[87 + 60 - 127 + 112] = I("抍埂", "VdHCM");
      I[93 + 28 - 84 + 96] = I("匓斗毕嬅注", "bAHaS");
      I[104 + 84 - 56 + 2] = I("会", "UHFui");
      I[39 + 98 - 119 + 117] = I("嶭敱梬", "iKNtz");
      I[65 + 0 - 41 + 112] = I("侪", "zvWXP");
      I[85 + 112 - 68 + 8] = I("仜剘傘漷", "ZwFlc");
      I[109 + 27 - 89 + 91] = I("乌", "wnrsJ");
      I[58 + 72 - 61 + 70] = I("擡淈炲", "urwzQ");
      I[82 + 42 - 69 + 85] = I("愲毒姬搬嫻", "EkFOU");
      I[31 + 6 - -49 + 55] = I("摫侹烔", "WtaRr");
      I[72 + 44 - 91 + 117] = I("侑", "BnbJb");
      I[91 + 10 - 7 + 49] = I("娓煶摖", "QZyAc");
      I[29 + 93 - -20 + 2] = I("儲剹", "sgLiF");
      I[9 + 137 - 114 + 113] = I("侜干", "ZyCBn");
      I[35 + 37 - -14 + 60] = I("佈弋嵋屿僬", "nkbNh");
      I[115 + 99 - 186 + 119] = I("\u000b1a; \u0006)%v8\u0002#/1#\tm", "pLAVO");
      I[13 + 99 - 74 + 110] = I("洫傗杛懊", "zQcYb");
      I[28 + 72 - -8 + 41] = I("垓懌", "jqeas");
      I[16 + 36 - -54 + 44] = I("暠潣挊", "Ggfep");
      I[78 + 146 - 179 + 106] = I("氲", "AOwRl");
      I[125 + 70 - 173 + 130] = I("岭殘悈", "ttQAT");
      I[146 + 39 - 137 + 105] = I("枯榐奆", "xZMsu");
      I[149 + 147 - 192 + 50] = I("彝嶎嗋揧", "yKCBw");
      I[21 + 128 - 108 + 114] = I("梵", "BMpFh");
      I[125 + 135 - 242 + 138] = I("抔澃", "eblTU");
      I[51 + 100 - 31 + 37] = I("照暈", "tftYQ");
      I[142 + 106 - 145 + 55] = I("栩匲", "OenRJ");
      I[145 + 104 - 246 + 156] = I("来梦", "UYDwg");
      I[120 + 36 - 57 + 61] = I("倓劊", "aLKHf");
      I[50 + 122 - 164 + 153] = I("壜愕", "mHIJo");
      I[44 + 106 - -2 + 10] = I("抏抰", "SWoqp");
      I[92 + 14 - 53 + 110] = I("櫹氭", "rTNxn");
      I[62 + 96 - 63 + 69] = I("丕擎", "FjpDY");
      I[152 + 152 - 229 + 90] = I("倽墾", "LyPaI");
      I[130 + 1 - -25 + 10] = I("娋漁", "Cbyzv");
      I[108 + 67 - 162 + 154] = I("劔澂", "VmLLw");
      I[23 + 9 - 19 + 155] = I("枆妵", "PTJYK");
      I[102 + 144 - 201 + 124] = I("屜怍", "ayebj");
      I[17 + 99 - -24 + 30] = I("廮棠", "WVzXj");
      I[125 + 155 - 257 + 148] = I("侄暭", "PAzNK");
      I[38 + 122 - 144 + 156] = I("欞元", "kojSm");
      I[8 + 164 - 133 + 134] = I("柟沢淮", "jBDvD");
      I[111 + 160 - 132 + 35] = I("巌樋", "fVZyv");
      I[22 + 60 - 7 + 100] = I("\u000e\u0018<%\u001b\u0013\u00011(\u0017\u0011C48\u0001\u0000\u0002>?\u0017\u0000\u0019~8\u001c\u0015\f<8\u0016<\u001d<0\u000b\u0006\u001f\u000f<\u001d\u0015\b=4\u001c\u0017", "cmPQr");
      I[164 + 83 - 78 + 7] = I("橾", "Etfpw");
      I[22 + 135 - 25 + 45] = I("曨斒吟慒", "gmuOy");
      I[68 + 36 - -17 + 57] = I("仫", "YIgLH");
      I[1 + 155 - 20 + 43] = I("慲", "NyKGS");
      I[164 + 30 - 112 + 98] = I("憌娽", "avzSQ");
      I[162 + 37 - 145 + 127] = I("墔", "VQKmh");
      I[166 + 64 - 166 + 118] = I("溜嬅", "zpTOA");
      I[125 + 110 - 158 + 106] = I("丬炋兏", "DyAEf");
      I[132 + 160 - 192 + 84] = I("事懘峴", "SHXmE");
      I[5 + 88 - 84 + 176] = I("嫯戨", "pqEpM");
      I[107 + 139 - 183 + 123] = I("煷員容櫎嗗", "QVaXg");
      I[12 + 168 - 115 + 122] = I("岝", "tWhAx");
      I[170 + 73 - 196 + 141] = I("姞", "MvIWz");
      I[85 + 187 - 106 + 23] = I("椪", "rYwXx");
      I[95 + 112 - 190 + 173] = I("吖崤嫱囇尠", "QkwHU");
      I[138 + 144 - 105 + 14] = I("\u001d'n\u0001*F)+\u0006=\u000f4)H4\t,+H)\u00079%\r-\u0015z:\u00076F<<\r(\u0013? \u001c5\u001fzf\u0013$F*/\u000b2\u0003.=H*\u000f4-\ry\n;=\u001cy\u00123-\u0003p", "fZNhY");
      I[77 + 89 - 63 + 89] = I("(*\t7, &?:781\u001b\u001b!:&\u00173 8\u0000\u00123-'", "LCzVN");
      I[108 + 64 - 25 + 46] = I("夫", "bYluN");
      I[141 + 148 - 219 + 124] = I("洺拪叡瀀", "SFFzl");
      I[35 + 157 - 129 + 132] = I("-<Y(> $\u001de%9.Y4$?\"\u0012)(wa\u00028}-<U>,", "VAyEQ");
      I[164 + 188 - 275 + 119] = I("栍崾", "EESgV");
      I[48 + 119 - 67 + 97] = I("侎寤欅夏學", "ItkLI");
      I[179 + 20 - 138 + 137] = I("单斲毼妵刖", "HXFPc");
      I[161 + 80 - 148 + 106] = I("坿吣慈", "BuexG");
      I[49 + 81 - 25 + 95] = I("溢冬壥", "plXna");
      I[29 + 37 - 46 + 181] = I("滅唲嫈噎撥", "TYmfC");
      I[22 + 113 - 70 + 137] = I("寱據搵娣", "LGZBC");
      I[29 + 103 - 40 + 111] = I("梙僦庁亖峏", "TxISk");
      I[12 + 48 - 31 + 175] = I("屴摩儦", "WyYSe");
      I[0 + 11 - -104 + 90] = I("杆", "bfuIZ");
      I[28 + 117 - -17 + 44] = I("杳", "tIByG");
      I[157 + 52 - 26 + 24] = I("傟毄搛俽", "TtcIx");
      I[146 + 86 - 102 + 78] = I("剟嫽", "XvHba");
      I[31 + 68 - 40 + 150] = I("妑", "AtVya");
      I[103 + 95 - 132 + 144] = I("永", "ksmLU");
      I[15 + 24 - -172 + 0] = I("厎", "NGmQA");
      I[120 + 111 - 125 + 106] = I("嗽渋宭埦", "QQWfq");
      I[28 + 58 - -82 + 45] = I("橃洧厁宷", "aAYbB");
      I[84 + 67 - -21 + 42] = I("9/j\u001d\u000247.P\u001a0=$\u0017\u0001;s", "BRJpm");
      I[91 + 208 - 238 + 154] = I("岱悓模", "OislK");
      I[116 + 118 - 134 + 116] = I("倁", "rzTbj");
      I[35 + 99 - 52 + 135] = I("悃嬍朝湄", "LDJKd");
      I[155 + 154 - 96 + 5] = I("偼嘀櫫僠瀖", "aOfbD");
      I[94 + 138 - 32 + 19] = I("廿昈氐漶梤", "fDcNP");
      I[91 + 160 - 38 + 7] = I("坢寉侖堰儷", "rYjEs");
      I[98 + 188 - 261 + 196] = I("洃烫", "FYXbi");
      I[82 + 0 - 72 + 212] = I("暠哗挪潳", "wqxtr");
      I[26 + 94 - 58 + 161] = I("徐太屗桱寃", "OZVBI");
      I[143 + 138 - 279 + 222] = I("焵", "qDykv");
      I[84 + 54 - -7 + 80] = I("灝滏桼尒枬", "aVsMx");
      I[75 + 80 - 95 + 166] = I("怼掷卵", "ALHPf");
      I[27 + 136 - 153 + 217] = I("槧", "xVWyw");
      I[53 + 201 - 26 + 0] = I("帣杺冐", "gOdBq");
      I[170 + 23 - 166 + 202] = I("瀞洭嫫倢抁", "yjFUa");
      I[136 + 58 - 154 + 190] = I("灇搣", "bIAQo");
      I[170 + 170 - 192 + 83] = I("堇哶儔", "DFAae");
      I[179 + 157 - 213 + 109] = I("渥懮", "uvCNa");
      I[144 + 152 - 242 + 179] = I("媑", "THMjQ");
      I[146 + 127 - 116 + 77] = I("槣令搲", "wasYA");
      I[131 + 130 - 90 + 64] = I("底凚昱妮", "vqusz");
      I[147 + 122 - 139 + 106] = I("尺枺", "HKrjv");
      I[208 + 132 - 316 + 213] = I("椫喈", "grXhr");
      I[73 + 124 - 189 + 230] = I("僵揺", "IVMYL");
      I[40 + 182 - 162 + 179] = I("刯妲", "gHPFB");
      I[35 + 212 - 186 + 179] = I("奞回", "OcKIB");
      I[171 + 107 - 143 + 106] = I("夝嗸", "QBwLv");
      I[170 + 130 - 296 + 238] = I("憞桖", "mYscX");
      I[137 + 150 - 105 + 61] = I("濽朗", "XQskP");
      I[49 + 133 - 68 + 130] = I("叶匠", "fkdFq");
      I[129 + 176 - 210 + 150] = I("栽瀐", "zCdsJ");
      I[221 + 50 - 53 + 28] = I("埡凢", "Aojlr");
      I[238 + 149 - 304 + 164] = I("湢嫞", "YRBwB");
      I[131 + 94 - 213 + 236] = I("惱", "QDgBF");
      I[248 + 128 - 128 + 1] = I("櫏梯榈朞", "OeCtD");
      I[23 + 151 - -22 + 54] = I("殍壷搋", "WDeuv");
      I[121 + 213 - 321 + 238] = I("瀵崕丣", "nRJhj");
      I[108 + 151 - 210 + 203] = I("潭", "DbUhB");
      I[235 + 208 - 262 + 72] = I("停梫敆", "TouVE");
      I[39 + 213 - 215 + 217] = I("悧儙怘", "uMqtL");
      I[190 + 125 - 203 + 143] = I("宐", "uoqYK");
      I[167 + 233 - 387 + 243] = I("幆揪寱昻", "BFWQg");
      I[57 + 252 - 60 + 8] = I("東嬼栾哄", "Mdppc");
      I[196 + 19 - -41 + 2] = I("沄媵", "BTWid");
      I[124 + 234 - 289 + 190] = I("淂偂", "YRDAf");
      I[0 + 157 - 15 + 118] = I("埻摱", "BtBWn");
      I[220 + 213 - 371 + 199] = I("灑宏", "yWuLd");
      I[137 + 163 - 142 + 104] = I("攒伕", "tldHg");
      I[81 + 115 - -65 + 2] = I("嵞侞", "awVEU");
      I[121 + 105 - -19 + 19] = I("妸喤", "YDxYr");
      I[3 + 119 - -8 + 135] = I("哆亿", "mrtKD");
      I[57 + 77 - 98 + 230] = I("槧樉", "ISBUz");
      I[200 + 259 - 230 + 38] = I("晗很", "PDYXW");
      I[140 + 226 - 349 + 251] = I("潼擇", "HPmpg");
      I[121 + 33 - 75 + 190] = I("殿泉", "gwMxq");
      I[32 + 268 - 164 + 134] = I("少", "CQJqv");
      I[151 + 265 - 172 + 27] = I("撓噫夗啠", "HLLvN");
      I[83 + 25 - 31 + 195] = I("杧咱忥囐", "AlAEF");
      I[2 + 184 - -59 + 28] = I("桳厽媗", "oPExh");
      I[134 + 116 - 95 + 119] = I("棱枭", "jpILZ");
      I[144 + 80 - 60 + 111] = I("灹敁壨", "RfARf");
      I[157 + 50 - 128 + 197] = I("媚剒", "JPgeF");
      I[62 + 46 - -58 + 111] = I("忹媥匵", "ifAiY");
      I[172 + 47 - 190 + 249] = I("互初峽潀意", "EOQRw");
      I[152 + 151 - 150 + 126] = I("幸卑呸抱", "VxPRr");
      I[227 + 148 - 289 + 194] = I("坤偗", "JRFAq");
      I[261 + 161 - 282 + 141] = I("侏憍桲浺", "vwYVo");
      I[188 + 76 - 87 + 105] = I("滤圙攀奏仹", "siSkb");
      I[77 + 202 - 17 + 21] = I("喭咱濎宕徯", "YOefK");
      I[108 + 7 - 30 + 199] = I("檶勨烆", "MzVhp");
      I[53 + 153 - 51 + 130] = I("吷欖", "xrUxv");
      I[22 + 19 - -86 + 159] = I("漕拇", "xpfCD");
      I[65 + 237 - 18 + 3] = I("丱嗭涹淞嚶", "OpxGs");
      I[138 + 242 - 364 + 272] = I("仝歟", "CuMSh");
      I[196 + 173 - 285 + 205] = I("染互", "oWfzi");
      I[22 + 273 - 185 + 180] = I("勒喅濘", "JhRCU");
      I[147 + 247 - 345 + 242] = I("朻占妎总嘠", "GnvmB");
      I[150 + 205 - 165 + 102] = I("朮", "ZEczF");
      I[150 + 13 - -4 + 126] = I("凋倳好榡", "KSwFa");
      I[163 + 229 - 334 + 236] = I(";?\u0004\u0006?\u001b5R\u0017?\u0013(\u0017\u0015s\u00132\u0006\u000e<\u001c", "rQrgS");
      I[50 + 259 - 248 + 234] = I("扣", "aGwNo");
      I[247 + 47 - 122 + 124] = I("媝濬唬伇媱", "dOZiE");
      I[72 + 201 - 72 + 96] = I("夊潜唓呅", "VVhLO");
      I[215 + 92 - 220 + 211] = I("剳淮清", "QVkMY");
      I[122 + 29 - 142 + 290] = I("披桫", "zEYNV");
      I[34 + 250 - 152 + 168] = I("做姓", "FljgX");
      I[259 + 253 - 233 + 22] = I("僾倖", "SODpQ");
      I[288 + 110 - 156 + 60] = I("劉挂", "UxXrp");
      I[99 + 44 - 65 + 225] = I("炡崌", "ljSen");
      I[110 + 112 - 214 + 296] = I("強斗", "NXCcs");
      I[246 + 243 - 268 + 84] = I("檹朗", "dbWOk");
      I[36 + 171 - -36 + 63] = I("婢滘", "hOncz");
      I[116 + 168 - 183 + 206] = I("忿垚", "rDSLI");
      I[255 + 280 - 380 + 153] = I("暵彈", "ygfMm");
      I[56 + 109 - 4 + 148] = I("孇幜", "IfhAn");
      I[227 + 236 - 218 + 65] = I("亵役", "UyAFk");
      I[155 + 54 - -20 + 82] = I("塝吓", "JXVEF");
      I[290 + 243 - 518 + 297] = I("圩槈", "KXyaS");
      I[66 + 58 - 23 + 212] = I("媕湏", "JFXKu");
      I[35 + 141 - 172 + 310] = I("姇崋", "qOZoH");
      I[99 + 191 - 115 + 140] = I("婻弑", "fxqbH");
      I[203 + 141 - 305 + 277] = I("擩楫", "lpIrM");
      I[187 + 185 - 277 + 222] = I("曥濷", "YJUCK");
      I[80 + 150 - 229 + 317] = I("溊朶", "PGFIY");
      I[162 + 302 - 240 + 95] = I("溔愆俀挼", "eBNTH");
      I[219 + 97 - 209 + 213] = I("摢抢尭丅澽", "AlPku");
      I[24 + 261 - 229 + 265] = I("掅橬", "fCUMb");
      I[52 + 146 - 18 + 142] = I("湘", "WuEMB");
      I[122 + 107 - 152 + 246] = I("*\u0001<\u0001,f\u0000:\u0002\u0000!\u0013=", "HtUmH");
      I[234 + 21 - 98 + 167] = I("愪偍嵡契", "OEQPe");
      I[201 + 318 - 389 + 195] = I("嵟柿仱汅屡", "baahw");
      I[219 + 149 - 247 + 205] = I("攪卾傮", "wvWgK");
      I[277 + 212 - 182 + 20] = I("婷嘟樑昺涪", "LEiqB");
      I[305 + 277 - 274 + 20] = I("展", "ERkKa");
      I[73 + 179 - 107 + 184] = I("坵庢厺", "gvgsF");
      I[278 + 207 - 245 + 90] = I("扶洈彷", "zXZND");
      I[22 + 40 - -52 + 217] = I("沙", "ihFFx");
      I[129 + 184 - 167 + 186] = I("忭", "CFwvf");
      I[1 + 89 - -197 + 46] = I("彚", "RubpN");
      I[203 + 128 - 154 + 157] = I("摝", "qIoDl");
      I[313 + 161 - 193 + 54] = I("味槆梌", "pAoGU");
      I[304 + 181 - 469 + 320] = I("唝勻炽嬤洩", "lEfLI");
      I[41 + 206 - -40 + 50] = I("佻巴塙檰攲", "bJxfd");
      I[3 + 207 - -66 + 62] = I("檚侸", "IHBaX");
      I[221 + 86 - 167 + 199] = I("呤幹", "XEOzv");
      I[77 + 77 - 58 + 244] = I("刋壁", "vIenp");
      I[255 + 24 - 140 + 202] = I("妤咏", "SooYC");
      I[53 + 23 - -207 + 59] = I("构毧", "utDIn");
      I[14 + 259 - 251 + 321] = I("暠乑恘愓", "gbfAn");
      I[195 + 311 - 312 + 150] = I("凢歹姃冂", "AjExQ");
      I[120 + 217 - 77 + 85] = I("伄怜溳添峦", "thXIv");
      I[338 + 14 - 238 + 232] = I("枔", "zzAWG");
      I[47 + 93 - 36 + 243] = I("嵳攡", "cmQaq");
      I[154 + 319 - 255 + 130] = I("煔灉", "fALlG");
      I[126 + 211 - 292 + 304] = I("俜峃", "ajNxZ");
      I[132 + 232 - 112 + 98] = I("彤乧", "uHmzx");
      I[249 + 220 - 418 + 300] = I("奛搱", "zMnTn");
      I[233 + 156 - 184 + 147] = I("捐仃", "zqkxO");
      I[261 + 131 - 351 + 312] = I("烂家", "wjKvP");
      I[347 + 30 - 167 + 144] = I("栽徠", "zBNHm");
      I[144 + 58 - -106 + 47] = I(",\u0017a/6$\u001ea 69\u0004$ ->\u0005/yy,\u0017", "WjACY");
      I[173 + 128 - 240 + 295] = I("棾垧偻徱", "Mlirn");
      I[271 + 39 - 255 + 302] = I("&2)-\u000b;+$ \u00079i55\u00032\"7w\u000e.!1", "KGEYb");
      I[255 + 282 - 427 + 248] = I("垉斉唯", "vbqlC");
      I[187 + 292 - 247 + 127] = I("吀", "OuCDc");
      I[19 + 23 - -54 + 264] = I("殒庚佹棥", "lDSJN");
      I[82 + 196 - -11 + 72] = I("勖", "mxuFQ");
      I[36 + 64 - -6 + 256] = I("挬亿埬", "dRXKs");
      I[286 + 34 - -36 + 7] = I("\u00108+\u001b\u001f*\"#K\u001c*\"#\u0007\n3 %\u0012\n1l7\u000e\u001d5)6K\u000e0l4\u0007\u000e:)6K\u0003,+#\u000e\u000bc#1\u001f", "CLDko");
      I[327 + 109 - 189 + 117] = I("攣濫", "uTLvV");
      I[347 + 271 - 274 + 21] = I("尕屍", "jbQUY");
      I[32 + 27 - -42 + 265] = I("濾氞", "Asbew");
      I[199 + 216 - 81 + 33] = I("惺唖", "rhuWs");
      I[149 + 85 - 65 + 199] = I("暖军", "siAVV");
      I[268 + 170 - 238 + 169] = I("淫搰", "hozFK");
      I[40 + 208 - 126 + 248] = I("呍憜", "TZRpm");
      I[227 + 286 - 509 + 367] = I("枯悏", "XCYNj");
      I[95 + 43 - 101 + 335] = I(" &\u0006\u001c.\u001d$H\b&\u0010(\r\f", "sChxG");
      I[327 + 184 - 309 + 171] = I("9\u0016\u0002\u0018\u000e\u001dW\u0003\u0016\u0002\u0007\u0010A\u0000\u000e\u0007\u0003", "iwask");
      I[67 + 296 - 253 + 264] = I("'\u000f\u0007*\u0014\u0003N\u0007-\u0010\u0004\u001d", "wndAq");
      I[148 + 13 - -62 + 152] = I("彍婰形仩", "fcGHo");
      I[305 + 173 - 321 + 219] = I("嵦煴", "tnisM");
      I[314 + 209 - 257 + 111] = I("儌", "WgUbJ");
      I[367 + 4 - 295 + 302] = I("奇憓懨", "kauni");
      I[192 + 40 - -134 + 13] = I("妬沮", "PRKbz");
      I[333 + 306 - 444 + 185] = I("瀖岜", "BCPJX");
      I[373 + 258 - 584 + 334] = I("巅棐呤俣奟", "kQMul");
      I[168 + 222 - 140 + 132] = I("暎垑媜", "DEcDi");
      I[21 + 69 - -139 + 154] = I("\"\rU&#0\u0015\u0011r%6P\u00067%y\u0011\u001br87\u0006\u0014>8=P\u00163#+\u0019\u00106q0\u0004\u0010?", "YpuRQ");
      I[352 + 63 - 212 + 181] = I("沗巴", "MteWq");
      I[325 + 17 - 196 + 239] = I("渉歾", "MvltO");
      I[119 + 232 - 283 + 318] = I("娏涎", "JWOQM");
      I[13 + 283 - 216 + 307] = I("煩少", "drxOM");
      I[146 + 52 - 42 + 232] = I("勗樨", "ItmXR");
      I[208 + 247 - 118 + 52] = I("浽氎", "RrKyB");
      I[240 + 105 - 117 + 162] = I("浾凵", "ywAYw");
      I[263 + 245 - 367 + 250] = I("楬圤", "WYpEV");
      I[242 + 184 - 181 + 147] = I("沆溳", "QPaqB");
      I[229 + 29 - 88 + 223] = I("伓崝", "UhaMf");
      I[114 + 71 - 157 + 366] = I("嫨廜", "PiDUP");
      I[347 + 346 - 543 + 245] = I("櫢炠", "tdBMB");
      I[310 + 281 - 324 + 129] = I("剮烏", "AClkD");
      I[378 + 11 - 98 + 106] = I("占壨", "zVbbO");
      I[178 + 54 - 67 + 233] = I("墙倥", "iyxkd");
      I[49 + 222 - -111 + 17] = I("斂湂", "nbAcW");
      I[73 + 91 - -165 + 71] = I("槶摾", "nzouF");
      I[86 + 259 - 241 + 297] = I("撾浅", "giOzc");
      I[119 + 157 - 205 + 331] = I("梋氷", "aCkGA");
      I[193 + 56 - 182 + 336] = I("楍噀", "UGFzo");
      I[107 + 295 - 239 + 241] = I("所仹", "tWXst");
      I[198 + 264 - 403 + 346] = I("兰刻", "dPyMl");
      I[273 + 329 - 462 + 266] = I("刬戼", "oQOQJ");
      I[226 + 23 - -83 + 75] = I("旯悑", "JDGni");
      I[162 + 88 - 113 + 271] = I("挗啢", "bZFIQ");
      I[107 + 237 - 135 + 200] = I("乴戰", "BaVsy");
      I[173 + 392 - 309 + 154] = I("伜区", "rSITx");
      I[345 + 322 - 582 + 326] = I("斤嚧", "DCDPz");
      I[315 + 182 - 449 + 364] = I("怮扄", "wvBcU");
      I[64 + 312 - 77 + 114] = I("嘈枣", "aVfJx");
      I[23 + 407 - 303 + 287] = I("尦截", "jVWkA");
      I[40 + 197 - -92 + 86] = I("勖淕", "hZbrl");
      I[332 + 103 - 26 + 7] = I("悋", "BOJwO");
      I[33 + 258 - -103 + 23] = I("噸吙勇", "nLngN");
      I[122 + 10 - -200 + 86] = I("\u0016>\u000b\rj\u00167\u0004\u0017+\u0001\u0005\u000f\u0017 ", "uVjyD");
      I[290 + 392 - 660 + 397] = I("兓媮洶", "OmitP");
      I[190 + 288 - 373 + 315] = I("滺", "Ozgbn");
      I[174 + 377 - 298 + 168] = I("栤侚檩", "RwlXL");
      I[304 + 264 - 168 + 22] = I("恽強尤炯", "HKCWU");
      I[3 + 274 - -56 + 90] = I("她刂", "TZmRU");
      I[296 + 188 - 381 + 321] = I("榭梁均岱徵", "ibklB");
      I[183 + 60 - 214 + 396] = I("弐渂毎崅嚐", "tCJzf");
      I[176 + 130 - 152 + 272] = I("圅桤檔暌", "BaAaA");
      I[57 + 343 - 227 + 254] = I("\u0006%:\";\u001b<7/7\u0019~2?!\b?887\b$x?>\u0007517>43>7 \n3\"3 \u0018", "kPVVR");
      I[314 + 108 - 203 + 209] = I("C", "lXyGS");
      I[115 + 154 - 174 + 334] = I("壀楬嬄卨摚", "pFvKC");
      I[263 + 419 - 392 + 140] = I("抓", "TKMdg");
      I[315 + 328 - 525 + 313] = I("乄億任市橙", "yOVmb");
      I[72 + 164 - -70 + 126] = I("扗僖壼氘", "sxcTy");
      I[33 + 307 - -10 + 83] = I("3#$\u0010~$25\u0001~$.=\u0010", "PKEdP");
      I[136 + 55 - 68 + 311] = I("哾", "usJhB");
      I[371 + 426 - 670 + 308] = I("堛櫆嬭彥", "KunLr");
      I[10 + 357 - 135 + 204] = I("昳姽基", "lRWNT");
      I[108 + 375 - 438 + 392] = I("帮橈", "IbpdW");
      I[135 + 422 - 270 + 151] = I("瀄昄嵸刕堆", "wTXYz");
      I[209 + 130 - -95 + 5] = I("旯崳嚽", "TjWmP");
      I[265 + 340 - 584 + 419] = I("煅伥搿堍丐", "lTYrS");
      I[436 + 165 - 283 + 123] = I("峄", "OuTZA");
      I[416 + 331 - 707 + 402] = I("夓投", "wrCdY");
      I[291 + 366 - 501 + 287] = I("投仰垥", "tOXFF");
      I[88 + 427 - 400 + 329] = I("5\u000e\u0015\u000b??\t\u0003\u000b$\u007f\u0014\u0016\t=", "QgfhP");
      I[132 + 417 - 200 + 96] = I("守帑泄巻", "Fxpha");
      I[317 + 198 - 219 + 150] = I("兖偆", "AlcmC");
      I[85 + 48 - 83 + 397] = I("杝寑", "CzJDL");
      I[377 + 176 - 126 + 21] = I("濅怂", "sNisR");
      I[348 + 418 - 360 + 43] = I("剐浔", "sjeBa");
      I[378 + 294 - 670 + 448] = I("嗃怕", "Wjyar");
      I[294 + 69 - 43 + 131] = I("岯烰", "hhOre");
      I[416 + 399 - 451 + 88] = I("洟檞", "qtwyh");
      I[329 + 315 - 467 + 276] = I("灗殻", "DKMSg");
      I[255 + 174 - 14 + 39] = I("儻傜炏徏", "nECpt");
      I[82 + 401 - 82 + 54] = I("姐溻擊唭営", "yCOON");
      I[314 + 176 - 232 + 198] = I("斎廉橰亂愿", "dxtCa");
      I[153 + 402 - 180 + 82] = I("$'\f,\u0019\u0004-Z.\u0019\u0004,\u00149U\u000e&\u0017 \u0014\u0003-[", "mIzMu");
      I[18 + 15 - -71 + 354] = I("滲匧澆揔孕", "dxbZj");
      I[11 + 10 - -32 + 406] = I("渕撫", "WZKFy");
      I[408 + 442 - 736 + 346] = I("毥楣", "tJygH");
      I[7 + 176 - 108 + 386] = I("津先", "RSQJl");
      I[191 + 229 - -3 + 39] = I("俖欬", "hIelG");
      I[413 + 387 - 469 + 132] = I("夿偮", "DNiqI");
      I[446 + 235 - 544 + 327] = I("历叞", "pSXXI");
      I[459 + 452 - 587 + 141] = I("淵媙", "vLZTD");
      I[155 + 217 - -40 + 54] = I("漉幄", "CXxJZ");
      I[6 + 266 - -123 + 72] = I("伒僣", "VMDlr");
      I[202 + 237 - 121 + 150] = I("庠殛", "RHkwK");
      I[383 + 395 - 654 + 345] = I("忒欎廀晫丵", "dXVDr");
      I[466 + 119 - 285 + 170] = I("儙渑屲", "ZKvoc");
      I[332 + 300 - 215 + 54] = I("喅倌彘", "fROaQ");
      I[41 + 358 - 307 + 380] = I("昂", "vvDje");
      I[356 + 316 - 517 + 318] = I("槕扎烱毼拝", "IaWId");
      I[234 + 335 - 261 + 166] = I("岥斵楥擌", "qiMZn");
      I[271 + 387 - 571 + 388] = I("揝妗嵅棠婻", "FwiOl");
      I[258 + 417 - 332 + 133] = I("劧吲嬥浖扁", "sgWem");
      I[212 + 406 - 569 + 428] = I("愧仢拡婼沮", "PZWmo");
      I[131 + 301 - 51 + 97] = I("\u0007\u0001\u00012\u0005\u001a\u0018\f?\t\u0018Z\t/\u001f\t\u001b\u0003(\t\t\u0000C/\u0002\u001c\u0015\u0001/\b5\u0011\u00032\u0005\u001e\r2'\u0018\u001e\u0015\u000e-\t\u000e", "jtmFl");
      I[456 + 293 - 463 + 193] = I("扌昱暍", "QIZfy");
      I[371 + 276 - 339 + 172] = I("巨", "oOEqs");
      I[447 + 462 - 757 + 329] = I("徵", "TXItS");
      I[234 + 135 - 95 + 208] = I("\"  \u000f-\u0000l", "rLAvH");
      I[300 + 469 - 667 + 381] = I("C\u00126\u0011\n\u0007F0\u0017O\u0002\u00120\u0019\f\bF%\u0016O\n\b2\u0019\u0003\n\u0002d\u001d\u0001\u0017\u000f0\u0001", "cfDxo");
      I[57 + 167 - -221 + 39] = I("\u0011\u0016\u0004\u0013\u0016\u0003\u0012\u000e\u0002\u0011%\u0003\u000f\u0015\u0010\u0003\u0012\u00043\n\u0017\b\n\u0003", "bfapb");
      I[267 + 76 - 218 + 360] = I("\u0002\u001b\u001e\u0005*", "dzrvO");
      I[355 + 130 - 169 + 170] = I("槐侨", "Gbvbn");
      I[327 + 49 - 340 + 451] = I("儷柘", "GKZin");
      I[428 + 367 - 602 + 295] = I("慿倽", "LzkuX");
      I[355 + 260 - 507 + 381] = I("忉扙", "ieoNp");
      I[17 + 113 - 18 + 378] = I("旽涁", "doIsf");
      I[402 + 380 - 555 + 264] = I("屔千", "NvMzD");
      I[371 + 99 - 466 + 488] = I("僊俩", "PNpQZ");
      I[89 + 399 - 77 + 82] = I("媦枦", "OBnzm");
      I[23 + 263 - -31 + 177] = I("倒曭撹岓厌", "mnBEv");
      I[363 + 319 - 221 + 34] = I("烸剰敕榷", "eZuSu");
      I[327 + 236 - 161 + 94] = I("宣斲", "NYFKh");
      I[110 + 46 - -262 + 79] = I("屏", "nbnJh");
      I[134 + 439 - 243 + 168] = I("暻擒", "mxILb");
      I[338 + 383 - 313 + 91] = I("峌憪桛図妗", "FnxYI");
      I[159 + 231 - -66 + 44] = I("煀戜服", "JTiFo");
      I[86 + 389 - 391 + 417] = I("朚恢儤彸", "yAcqv");
      I[11 + 500 - 355 + 346] = I("洮屋浾棠檯", "rvmMI");
      I[47 + 89 - -147 + 220] = I("排憑儦", "vNYkw");
      I[464 + 338 - 425 + 127] = I("庝峐", "msrcq");
      I[191 + 16 - 138 + 436] = I("氏", "fgFwI");
      I[334 + 409 - 391 + 154] = I("扤墆冕幭棓", "pGJsW");
      I[473 + 331 - 652 + 355] = I("巯溏儿湹", "DbfVY");
      I[178 + 8 - -266 + 56] = I("幞挽濔", "qcGpM");
      I[436 + 349 - 470 + 194] = I("溙囌", "pkfmy");
      I[424 + 285 - 691 + 492] = I("幘嗄", "oxoVs");
      I[246 + 393 - 139 + 11] = I("嚻檁", "aAvVS");
      I[170 + 355 - 256 + 243] = I("榬氘", "xJncb");
      I[368 + 504 - 668 + 309] = I("屠婂", "RDGjm");
      I[241 + 57 - 148 + 364] = I("湘昨", "kxwXZ");
      I[212 + 153 - 226 + 376] = I("潭定", "xwgip");
      I[61 + 178 - -86 + 191] = I("濉七", "uWKsO");
      I[88 + 407 - 353 + 375] = I("瀿崏", "pGXAh");
      I[154 + 466 - 407 + 305] = I("旼暶", "QrlGD");
      I[366 + 430 - 458 + 181] = I("楨兔", "DaWrH");
      I[499 + 446 - 712 + 287] = I("洁廐", "PQNoa");
      I[517 + 120 - 605 + 489] = I("+\u0005\u001c\u001b.,\u0007\u0007\u00111\u0010=\u0012\u001f", "iisxE");
      I[462 + 125 - 427 + 362] = I("\u0004#$* \u0003!? ??\u001b*.", "FOKIK");
      I[324 + 299 - 421 + 321] = I(" ", "XxXsw");
      I[64 + 99 - -182 + 179] = I("\n", "sSLsg");
      I[48 + 50 - -164 + 263] = I("\u000b", "qBeIC");
      I[438 + 77 - 464 + 475] = I("佰底求擀戣", "Ekbay");
      I[381 + 186 - 409 + 369] = I("!", "YGCjc");
      I[223 + 452 - 467 + 320] = I("\n", "spbFT");
      I[142 + 265 - -30 + 92] = I("#", "YcwvP");
      I[352 + 176 - 376 + 378] = I("妡", "TQlSF");
      I[364 + 284 - 286 + 169] = I("\b", "pLOwi");
      I[312 + 223 - 501 + 498] = I("\u001a", "cWQnY");
      I[189 + 279 - 287 + 352] = I("<", "FUmNe");
      I[486 + 415 - 871 + 504] = I("\t\u0016&.:\u000e\u0014=$%2.(*", "KzIMQ");
      I[26 + 304 - 253 + 458] = I("屒瀨号俨不", "PDpgV");
      I[65 + 402 - 402 + 471] = I("墕", "EyHUg");
      I[168 + 226 - 316 + 459] = I("掐憰", "suWJI");
      I[479 + 358 - 369 + 70] = I("坭娉", "JrNih");
      I[505 + 344 - 372 + 62] = I("濲敥", "PNYaR");
      I[102 + 243 - 327 + 522] = I("欀判", "bUOnR");
      I[366 + 405 - 575 + 345] = I("愁丣", "Uyrnp");
      I[478 + 447 - 495 + 112] = I("潆建", "XAXCI");
      I[36 + 48 - -442 + 17] = I("六勻", "wHCWb");
      I[191 + 163 - 229 + 419] = I("櫗帥", "bGAoZ");
      I[217 + 483 - 363 + 208] = I("團漥", "muXvE");
      I[19 + 304 - 181 + 404] = I("潃咨潫乪啌", "emEWo");
      I[348 + 256 - 280 + 223] = I("滽澰多夅", "Vchre");
      I[387 + 361 - 566 + 366] = I("夜歗", "fCzLY");
      I[488 + 302 - 450 + 209] = I("悽果", "BBHTi");
      I[224 + 321 - 152 + 157] = I("<=\u0006\n\u0016\u001eq", "lQgss");
      I[538 + 144 - 224 + 93] = I("X\u0007\u00016\u0018X\u0019\u0006,\t\u001cM\u0000*L\u001b\u0005\u0015+\u000b\u001dM\u001a*\u0002U\b\u0010,\u0018\u0019\u000f\u0018 L\u000b\u0004\u0013+", "xmtEl");
      I[217 + 0 - -197 + 138] = I("丄梠恗", "VkhQw");
      I[253 + 144 - 269 + 425] = I("扛", "VieEf");
      I[397 + 286 - 385 + 256] = I("唄攫弥", "criFu");
      I[502 + 322 - 754 + 485] = I("櫏桊", "tUPmd");
      I[351 + 121 - 126 + 210] = I("沺枹", "oxcxM");
      I[266 + 356 - 362 + 297] = I("濚剪", "QWDSM");
      I[231 + 500 - 459 + 286] = I("娄廭", "pTPEL");
      I[194 + 285 - 97 + 177] = I("佀漀", "Ivhpd");
      I[339 + 302 - 89 + 8] = I("墒", "yzsDG");
      I[396 + 96 - 306 + 375] = I("\u0010!!0\u0002\u001a&70\u0019Z<;>\b\u001b=&", "tHRSm");
      I[59 + 245 - 293 + 551] = I("決汷", "dvKap");
      I[479 + 523 - 723 + 284] = I("扸浟", "uUsCa");
      I[34 + 473 - 47 + 104] = I("尹栒", "rLvPG");
      I[390 + 389 - 774 + 560] = I("嫇泍", "wTFld");
      I[490 + 510 - 601 + 167] = I("摎江吀叧", "iZZAE");
      I[461 + 150 - 153 + 109] = I("乬橐淌", "BiwKx");
      I[152 + 37 - 158 + 537] = I("嫫瀱嬑槤幰", "HEEpg");
      I[69 + 533 - 86 + 53] = I("垏冔榎号凯", "LqHbH");
      I[247 + 340 - 133 + 116] = I("澯", "vZyeg");
      I[486 + 392 - 452 + 145] = I("侹汾", "AZkmI");
      I[174 + 384 - 252 + 266] = I("峙塩撱愧圯", "SrYsp");
      I[352 + 32 - -154 + 35] = I("寎岍", "WfyBY");
      I[480 + 443 - 554 + 205] = I("涖濍", "TsadL");
      I[493 + 301 - 263 + 44] = I("坬搢", "mMWKQ");
      I[232 + 197 - 327 + 474] = I("檩吗", "GeexL");
      I[537 + 133 - 309 + 216] = I("嵮宯", "laKtJ");
      I[464 + 344 - 379 + 149] = I("廦勤", "nYplz");
      I[157 + 21 - 0 + 401] = I("侊曢", "szaPm");
      I[323 + 308 - 581 + 530] = I("懏嬯", "dyDqH");
      I[571 + 419 - 632 + 223] = I("奚柤", "XUvsg");
      I[90 + 86 - 19 + 425] = I("懳惆", "JRMDb");
      I[549 + 193 - 565 + 406] = I("夳渌", "tOPIk");
      I[123 + 257 - -167 + 37] = I("圏吥", "ZunuI");
      I[147 + 480 - 545 + 503] = I("岚噚", "cHXLe");
      I[470 + 412 - 740 + 444] = I("刲擌", "GIcCw");
      I[414 + 156 - 29 + 46] = I("寱丘", "HzMtT");
      I[207 + 247 - 333 + 467] = I("慣唌", "SFjmq");
      I[581 + 471 - 871 + 408] = I("晟据", "UdWrh");
      I[94 + 69 - 4 + 431] = I("宪巕", "CkCMe");
      I[14 + 140 - -133 + 304] = I("僒嵩", "GpgpI");
      I[221 + 390 - 405 + 386] = I("帺引", "HRkcD");
      I[260 + 335 - 454 + 452] = I("匠徐", "DcGxz");
      I[222 + 344 - 151 + 179] = I("吒咪", "KPgdl");
      I[411 + 176 - 389 + 397] = I("楻俇", "kqMNL");
      I[208 + 460 - 349 + 277] = I("流兄", "lLtFW");
      I[176 + 235 - 2 + 188] = I("涀嫒", "hQjqc");
      I[425 + 211 - 430 + 392] = I("敿偶", "bnFEr");
      I[37 + 340 - 43 + 265] = I("挏欋", "jPWWx");
      I[521 + 212 - 308 + 175] = I("堫唗", "RAZuM");
      I[580 + 531 - 725 + 215] = I("惕墉", "XBJHA");
      I[140 + 55 - -383 + 24] = I("檀敐", "bpOdD");
      I[242 + 324 - 169 + 206] = I("怨歶", "nAzIl");
      I[117 + 465 - 423 + 445] = I("埘杽", "BNHrl");
      I[351 + 495 - 372 + 131] = I("机愐", "ZRdmr");
      I[440 + 220 - 422 + 368] = I("崲妗", "GvcwQ");
      I[512 + 532 - 993 + 556] = I("懾樮", "RgAJm");
      I[558 + 19 - 427 + 458] = I("卭涊", "KXurg");
      I[204 + 464 - 255 + 196] = I("勍泭", "iWKtG");
      I[416 + 122 - 77 + 149] = I("樞侔", "DlfHn");
      I[114 + 66 - 27 + 458] = I("勛择", "mSTiZ");
      I[30 + 227 - 80 + 435] = I("椴剮", "xSYcO");
      I[161 + 431 - 295 + 316] = I("昰摤", "qfXRI");
      I[145 + 604 - 531 + 396] = I("楕俴", "grdBf");
      I[125 + 68 - 10 + 432] = I("湋撍", "KVAUS");
      I[438 + 510 - 711 + 379] = I("払懝", "ssofw");
      I[130 + 272 - 140 + 355] = I("吋帹", "yRPQK");
      I[447 + 33 - 261 + 399] = I("儇婶", "Xbnvx");
      I[549 + 177 - 320 + 213] = I("厏侑", "ctKEd");
      I[396 + 255 - 631 + 600] = I("弌呷", "DbCpk");
      I[266 + 359 - 113 + 109] = I("擣浓", "yaxvt");
      I[233 + 344 - 500 + 545] = I("柇严", "vryXs");
      I[564 + 75 - 74 + 58] = I("巁桄", "iYiYy");
      I[394 + 137 - -66 + 27] = I("槷嚸", "YekcO");
      I[262 + 475 - 578 + 466] = I("嗮僈", "dPXcY");
      I[321 + 251 - 197 + 251] = I("柷幰", "ljyAz");
      I[332 + 188 - 514 + 621] = I("拦澶", "Oujed");
      I[471 + 146 - 523 + 534] = I("壟塰", "DWmRR");
      I[6 + 506 - 407 + 524] = I("愐旐", "GzTby");
      I[136 + 341 - 251 + 404] = I("凖哺", "FnJQh");
      I[483 + 23 - 52 + 177] = I("崱敂", "kZqoZ");
      I[488 + 421 - 692 + 415] = I("啃撵", "UVegZ");
      I[484 + 368 - 500 + 281] = I("忛厜", "FMMvv");
      I[73 + 219 - -324 + 18] = I("戍恻", "ImSWK");
      I[602 + 5 - 170 + 198] = I("拎换", "UcxIJ");
      I[372 + 60 - 75 + 279] = I("婞才", "coWWX");
      I[234 + 554 - 193 + 42] = I("噼囍", "HRWkc");
      I[586 + 441 - 989 + 600] = I("僓氜", "TKrwY");
      I[468 + 152 - 54 + 73] = I("吰瀛", "cOMfJ");
      I[638 + 170 - 550 + 382] = I("忞嘼", "sujfK");
      I[142 + 245 - -1 + 253] = I("気政", "TlAsN");
      I[570 + 172 - 593 + 493] = I("嘢必", "dxZmd");
      I[299 + 83 - 310 + 571] = I("唙但", "nfbBj");
      I[568 + 250 - 661 + 487] = I("唚戡", "izAeh");
      I[626 + 44 - 584 + 559] = I("岑壁", "pjgIe");
      I[91 + 327 - -24 + 204] = I("涣淘", "SLQMx");
      I[625 + 230 - 525 + 317] = I("濑欈", "AoHNJ");
      I[588 + 386 - 430 + 104] = I("榳橷", "Adfyt");
      I[595 + 272 - 251 + 33] = I("憸呚", "EYapR");
      I[301 + 105 - 272 + 516] = I("勥匆", "FmlhX");
      I[213 + 551 - 301 + 188] = I("喠啀", "BwdPc");
      I[439 + 246 - 527 + 494] = I("掉尓", "yeHYI");
      I[346 + 306 - 521 + 522] = I("攟怂", "KveXf");
      I[57 + 652 - 408 + 353] = I("向墶", "cHVFZ");
      I[6 + 439 - 63 + 273] = I("塞抛", "xLAZj");
      I[294 + 595 - 263 + 30] = I("喐彳", "HooIP");
      I[512 + 184 - 303 + 264] = I("憻棨", "QALHH");
      I[528 + 648 - 1031 + 513] = I("剗屿", "vjWqE");
      I[318 + 583 - 898 + 656] = I("伀梭", "SrnYR");
      I[238 + 389 - 298 + 331] = I("俩浒", "JWQuJ");
      I[57 + 582 - 384 + 406] = I("暙嘹", "yRVZc");
      I[532 + 47 - 0 + 83] = I("嗂嶪", "TyQgf");
      I[540 + 11 - 88 + 200] = I("槎娧", "EtmHR");
      I[473 + 43 - 193 + 341] = I("擁堾", "vjwVu");
      I[379 + 619 - 707 + 374] = I("炘噠", "sJztc");
      I[476 + 398 - 433 + 225] = I("岙唅", "egJak");
      I[171 + 224 - -261 + 11] = I("濨叛", "Hjebv");
      I[666 + 483 - 865 + 384] = I("墵屋", "RdfPZ");
      I[512 + 499 - 799 + 457] = I("晕伓", "udDrY");
      I[324 + 628 - 636 + 354] = I("冚叠", "tRCBS");
      I[151 + 574 - 555 + 501] = I("漵柱", "nrpwh");
      I[34 + 69 - -470 + 99] = I("很散", "LDuEz");
      I[183 + 77 - -207 + 206] = I("栾抑", "NIsBk");
      I[445 + 292 - 734 + 671] = I("峘崔", "RGULb");
      I[473 + 642 - 776 + 336] = I("恬灕", "GQwPp");
      I[580 + 453 - 897 + 540] = I("契婛", "dJpEw");
      I[187 + 421 - 445 + 514] = I("浪亮", "egVpl");
      I[0 + 87 - -247 + 344] = I("媶搦", "eWgWv");
      I[251 + 65 - -325 + 38] = I("壊冻", "ceEJO");
      I[643 + 457 - 1004 + 584] = I("删扼", "bBJXa");
      I[526 + 116 - 244 + 283] = I("啹导", "KMzgs");
      I[293 + 559 - 435 + 265] = I("垧暲", "pVvor");
      I[348 + 605 - 383 + 113] = I("孮沁", "uQZfC");
      I[120 + 77 - -463 + 24] = I("姮坑", "ZbIMs");
      I[226 + 428 - 580 + 611] = I("偧煁", "gPkTH");
      I[229 + 490 - 461 + 428] = I("澘惮", "NRBCQ");
      I[188 + 181 - -178 + 140] = I("擀滺", "qDFDK");
      I[318 + 47 - -316 + 7] = I("烀栝", "Kqynl");
      I[628 + 104 - 83 + 40] = I("波懵", "YbYqq");
      I[324 + 145 - 236 + 457] = I("壘唥", "GXYgt");
      I[425 + 671 - 879 + 474] = I("挪沉", "GgyrS");
      I[554 + 670 - 672 + 140] = I("檣卖", "DSiCk");
      I[174 + 468 - 160 + 211] = I("忪涞", "ARObR");
      I[17 + 171 - -77 + 429] = I("墣暳", "nLxEQ");
      I[335 + 370 - 124 + 114] = I("僮溓", "kzexI");
      I[328 + 187 - 94 + 275] = I("吻沆", "HSGbh");
      I[421 + 564 - 794 + 506] = I("尜卬", "tMvEe");
      I[652 + 421 - 541 + 166] = I("上扟", "KDIIr");
      I[457 + 10 - -63 + 169] = I("僫尟", "rUzBT");
      I[448 + 139 - 239 + 352] = I("垍柠", "mWMjy");
      I[577 + 18 - 281 + 387] = I("墕傫", "YMAda");
      I[518 + 248 - 674 + 610] = I("张忻", "djaDb");
      I[339 + 516 - 224 + 72] = I("婏夦", "vPrEN");
      I[39 + 32 - -213 + 420] = I("堺丂", "Pummb");
      I[555 + 375 - 841 + 616] = I("庱佽", "TsybN");
      I[505 + 585 - 428 + 44] = I("儝咐", "TaAAm");
      I[350 + 93 - -248 + 16] = I("坴再", "QcpRC");
      I[114 + 524 - 209 + 279] = I("墹搒", "eDQaT");
      I[223 + 58 - -372 + 56] = I("咵卶", "oBCyp");
      I[18 + 563 - 381 + 510] = I("匉摈", "OTxCM");
      I[607 + 498 - 843 + 449] = I("愥墈", "coZRp");
      I[253 + 616 - 493 + 336] = I("孜栈", "HgBLI");
      I[166 + 652 - 581 + 476] = I("屸快", "vxTTE");
      I[205 + 160 - 106 + 455] = I("攘击", "xqsLF");
      I[466 + 570 - 638 + 317] = I("婅値", "nPyzl");
      I[438 + 590 - 656 + 344] = I("敐楤", "hWnBC");
      I[231 + 333 - 46 + 199] = I("\u0000\u000b\u000b(,)!\u0003", "MHwji");
      I[89 + 284 - 241 + 586] = I("娛栌樣嘇叔", "ShYzZ");
      I[39 + 16 - -127 + 537] = I("噑渦", "domqp");
      I[204 + 569 - 103 + 50] = I("咐庠揅格呉", "kMZVB");
      I[189 + 204 - 83 + 411] = I("\u0018+\u0005\t48!S\n7>.S\u001c96d", "QEshX");
      I[517 + 623 - 646 + 228] = I("携應", "JnWtY");
      I[206 + 340 - 327 + 504] = I("倎圜坉傳", "nTegs");
      I[314 + 690 - 452 + 172] = I("慚摡岁搬", "oAMrV");
      I[212 + 528 - 170 + 155] = I("占", "eHJGS");
      I[437 + 364 - 746 + 671] = I("8$\u0016\u0015\u0000", "HEqps");
      I[488 + 663 - 794 + 370] = I("4\u0014\u0011\r\t", "Duvhz");
      I[369 + 576 - 880 + 663] = I("6\u001a\r\u0014\u000e\u001bR\fX\u0002\u0014\u001b\u001c\u0014\u000fU\u0017\u0017\u0017\u0001U\u001c\u0016\u001e\u0005", "uuxxj");
      I[150 + 388 - 346 + 537] = I("+9\u0004\u001b\u0017\u000f\u001d\u0016", "fzxYD");
      I[650 + 413 - 550 + 217] = I("佳弹湃凶", "jgXJF");
      I[170 + 150 - -411 + 0] = I("炶木炠嘜", "deuhG");
      I[138 + 432 - 472 + 634] = I("怡岺傤捗廦", "Izqxu");
      I[225 + 217 - -82 + 209] = I("'\f\u0000%<\u0007\u0006V&?\u0001\tV01\tC", "nbvDP");
      I[60 + 292 - -26 + 356] = I("暔冧株瀭椤", "YeNzN");
      I[473 + 95 - 283 + 450] = I("桳攖岷勼", "TeoyS");
      I[346 + 504 - 447 + 333] = I("弍厌慂", "QwThr");
      I[251 + 348 - 296 + 434] = I("毮", "GTlwe");
      I[261 + 225 - 236 + 488] = I("卄潁咔敼怦", "BFAZm");
      I[704 + 530 - 994 + 499] = I("古", "xPWKy");
      I[39 + 719 - 106 + 88] = I("榣岧孥撐潱", "VCJTb");
      I[603 + 471 - 763 + 430] = I("杒毬刣", "yOYBn");
      I[361 + 561 - 505 + 325] = I("\u00128\u0016\u0012\u0017\u0001", "sMbzx");
      I[404 + 518 - 212 + 33] = I("嗁倁炼", "bWXFi");
      I[680 + 155 - 462 + 371] = I("\r&<\")", "yOHNL");
      I[692 + 11 - 66 + 108] = I("煙厪弋", "PjmxP");
      I[267 + 363 - 545 + 661] = I("漨栨帄", "YPSqt");
      I[64 + 154 - 73 + 602] = I("-&\u0003\u001a4", "YOwvQ");
      I[13 + 406 - 51 + 380] = I("2\u0005%\u0014\u000b", "BdBqx");
      I[696 + 418 - 493 + 128] = I("榰", "GZhSI");
      I[639 + 613 - 818 + 316] = I("欵", "LfFKA");
      I[292 + 435 - 641 + 665] = I("灳忭楄沨", "fFipq");
      I[158 + 445 - 247 + 396] = I("滯欸椕傕増", "VBiLm");
      I[85 + 520 - 98 + 246] = I("氢潳烀", "cCspM");
      I[350 + 410 - 450 + 444] = I("樢厑漀", "lkinC");
      I[126 + 201 - 210 + 638] = I("\u00178)6\u0005", "gYNSv");
      I[71 + 323 - 187 + 549] = I("/\f7\u0001!\u0002D6M6\u0005\u0004,M'\u0003\f)", "lcBmE");
      I[199 + 235 - -210 + 113] = I("?\u000e\r%\u0017!(\u001d", "rMqqe");
      I[179 + 754 - 842 + 667] = I("\r?-\u0000\u000f w,L\u0018+<=\u000f\u001fn$*\r\u000f+", "NPXlk");
      I[28 + 440 - -242 + 49] = I("59\u001b\u000e7\u000e9\n+", "xzgOS");
      I[424 + 143 - 83 + 276] = I("毤丮敫", "dDAsg");
      I[238 + 246 - -164 + 113] = I("仴", "zVapW");
      I[720 + 754 - 1435 + 723] = I("槢义", "JmFRH");
      I[211 + 504 - 106 + 154] = I("栳", "dbAfP");
      I[711 + 726 - 1276 + 603] = I(".\u001e\u001e#%+\u001fF\u0000%;?\u0006\u000f(#\u001f\f", "OzhnJ");
      I[285 + 677 - 577 + 380] = I("棇", "pRmIm");
      I[747 + 689 - 849 + 179] = I("亀", "cgpnz");
      I[203 + 478 - 674 + 760] = I("伡塙丶憼", "vjdYl");
      I[5 + 520 - 375 + 618] = I("\f\u000e\u0013\u0002+\t\u000fK!+\u0019+\t#+\u001a\u000f\u0001", "mjeOD");
      I[257 + 556 - 98 + 54] = I("憹呶櫲毾", "pqKjZ");
      I[321 + 85 - 252 + 616] = I("檧渃储弱灆", "AdBVr");
      I[38 + 537 - 115 + 311] = I("炖伎灮斞泜", "cJrKO");
      I[531 + 521 - 603 + 323] = I("敛毦枓你命", "plABq");
      I[715 + 86 - 215 + 187] = I("呇晑", "uLSur");
      I[731 + 759 - 1260 + 544] = I("施潵檫帧徱", "dHeLg");
      I[291 + 241 - 95 + 338] = I("\u0004,7\u000f*\u0001-o1 \u0011\u000b./(\u0004&%l6\u0010+\"'6\u0016", "eHABE");
      I[686 + 429 - 688 + 349] = I("毼晨", "Ejspu");
      I[66 + 441 - -187 + 83] = I("劉", "TmoLj");
      I[36 + 746 - 529 + 525] = I("偞岲嫵嶧尡", "nflOe");
      I[267 + 560 - 741 + 693] = I("4\u0016-\u001f%\u0019^,S2\u0012\rx\u0010.\u001a\u00149\u001d%W\u001b4\u001c\"\u001c", "wyXsA");
      I[299 + 17 - -3 + 461] = I("\t\u0013/-20?\u0010\u0001#", "DPSlG");
      I[527 + 86 - 206 + 374] = I("溕创汝斅", "PMndQ");
      I[775 + 14 - 531 + 524] = I("厱", "YDUYS");
      I[134 + 182 - -440 + 27] = I("6\u001e5\u000283\u001fm!8#?-.5;\u001f'", "WzCOW");
      I[782 + 697 - 695 + 0] = I("照", "qPHQO");
      I[185 + 63 - -270 + 267] = I("侊噎拮廊沗", "FTvgz");
      I[483 + 189 - 262 + 376] = I("漍", "lJBGq");
      I[129 + 354 - 415 + 719] = I("搱椗", "jxlSQ");
      I[717 + 558 - 1220 + 733] = I("仲斧", "ZTDud");
      I[458 + 223 - 663 + 771] = I("%!\u001a\u001e$  B=$0\u0004\u0000?$3 \b", "DElSK");
      I[126 + 760 - 226 + 130] = I("咂倲", "jlqRj");
      I[542 + 726 - 506 + 29] = I("凟槄捖", "vKGlp");
      I[273 + 179 - 267 + 607] = I("榏点烆", "FITTX");
      I[365 + 82 - -208 + 138] = I("僡櫫曍", "kixbX");
      I[718 + 779 - 757 + 54] = I("攽婇殬摧抇", "FKLeW");
      I[261 + 426 - 163 + 271] = I("嶼", "HnNnW");
      I[227 + 505 - 483 + 547] = I("庢", "djtjg");
      I[493 + 569 - 391 + 126] = I("彰愃寓", "oLsaV");
      I[118 + 695 - 259 + 244] = I("壆", "uGoZS");
      I[579 + 588 - 809 + 441] = I("朮偨橨烊劗", "vmocz");
      I[54 + 333 - -342 + 71] = I("3-!>?6,y\u00005&\n8\u001e=3'3]#'*4\u0016#!", "RIWsP");
      I[528 + 729 - 1003 + 547] = I("毭桸", "RllZI");
      I[433 + 267 - -93 + 9] = I("悯", "SYKpl");
      I[395 + 614 - 249 + 43] = I("5\u0019\u001e\u0019\u000b\u0018Q\u001fU\u001c\u0013\u0002K\u0016\u0000\u001b\u001b\n\u001b\u000bV\u0014\u0007\u001a\f\u001d", "vvkuo");
      I[765 + 168 - 860 + 731] = I("4;\b'\u0014\u0018\u001b\u001b\u000b", "yxteq");
      I[607 + 536 - 550 + 212] = I("柟", "ntMDA");
      I[791 + 29 - 420 + 406] = I("&\u001a>*>\u000bR?f)\u0000\u0001k$?\u0004\u0016$(", "euKFZ");
      I[145 + 273 - -100 + 289] = I(";(\u0017>\u001f\u0013\u0006%\u0016\u0006\u0013", "vkkwk");
      I[21 + 554 - 177 + 410] = I("", "fHTju");
      I[602 + 438 - 255 + 24] = I("7\t\u000b\u00177\b?\u00140", "zJwDC");
      I[758 + 337 - 349 + 64] = I("嚴佘", "tzrzu");
      I[512 + 93 - 348 + 554] = I("悰兦有滨漙", "xOPxI");
      I[13 + 83 - -149 + 567] = I("惶", "AyGon");
      I[163 + 160 - -394 + 96] = I("崲", "lZaEj");
      I[53 + 781 - 521 + 501] = I("孍", "sQhOf");
      I[639 + 481 - 839 + 534] = I("抭喌", "BOmXA");
      I[714 + 710 - 1418 + 810] = I("恛塱喲", "VtIAz");
      I[666 + 90 - 632 + 693] = I("\t\u0018: \n\u000e\u0019:06\u0018\u0000'6\u0002T\u001f)#\f%\u001f=6\n\u001f\u001f;", "zlHUi");
      I[612 + 304 - 226 + 128] = I("椑掿", "efevS");
      I[635 + 54 - -72 + 58] = I("恛樰嚙匛峇", "qTQPq");
      I[751 + 503 - 558 + 124] = I("勌", "JdANh");
      I[646 + 537 - 617 + 255] = I("卯", "lJXYC");
      I[682 + 119 - 487 + 508] = I("岨匔", "yOwRi");
      I[323 + 367 - 59 + 192] = I("\"\r(1\u0005%\f(!93\u00155'\r\u007f\n;2\u0003\u000e\u001f;-\n$\u000b?", "QyZDf");
      I[24 + 464 - -150 + 186] = I("囨", "FwfOl");
      I[718 + 151 - 478 + 434] = I("每橄幡涁", "TJBzu");
      I[730 + 527 - 1095 + 664] = I("#\u0011<\u0017\u0010$\u0010<\u0007,2\t!\u0001\u0018~\t!\u0003\u0017\u000f\u000b!\u0016,6\n;\f\u0017", "PeNbs");
      I[224 + 802 - 228 + 29] = I("幍娲", "XwdKP");
      I[599 + 681 - 730 + 278] = I("愜尨樆", "tmqWV");
      I[213 + 527 - 37 + 126] = I("埳", "bsyyM");
      I[11 + 328 - -199 + 292] = I("丛劁抱拦", "ezEDt");
      I[212 + 788 - 556 + 387] = I("慊氬況", "wlNPP");
      I[567 + 578 - 618 + 305] = I("<97\u0017 ;87\u0007\u001c-!*\u0001(a!*\u0003'\u0010>0\u0001 *>6", "OMEbC");
      I[341 + 751 - 817 + 558] = I("湙悧傗佹", "BMSwp");
      I[78 + 205 - 98 + 649] = I("凇够庍汽", "GBIgf");
      I[357 + 784 - 966 + 660] = I("堆灣亿懐挣", "wvSxK");
      I[434 + 706 - 314 + 10] = I("儌梷櫇唕", "OBcXm");
      I[194 + 581 - 754 + 816] = I("渲恓刬梊囪", "JYmSC");
      I[62 + 266 - -450 + 60] = I("\u000b\u0018\u0015?\u0011\f\u0019\u0015/-\u001a\u0000\b)\u0019V\u0000\b+\u0016'\u001c\u0015/\u0002\u0019\u001e\u0002", "xlgJr");
      I[204 + 706 - 397 + 326] = I("峁棲敧柃", "gRqAS");
      I[616 + 398 - 853 + 679] = I("核梪曤嗎", "oyZQn");
      I[610 + 689 - 1006 + 548] = I("椎", "aSsHi");
      I[355 + 526 - 313 + 274] = I("\u001e\u00195\u0006.\u0019\u00185\u0016\u0012\u000f\u0001(\u0010&C\u001e.\t(2\u001e2\u0010.\b\u001e4", "mmGsM");
      I[454 + 595 - 982 + 776] = I("桶布", "pexbo");
      I[250 + 619 - 366 + 341] = I("娲僛勭梾", "PfxAO");
      I[455 + 730 - 946 + 606] = I("仑屋寻煨", "RTqOU");
      I[785 + 115 - 699 + 645] = I("\u001b$\u0002\u001c$\u001c%\u0002\f\u0018\n<\u001f\n,F#\u0019\u0013\"76\u0011\u0000+\u001d\"\u0015", "hPpiG");
      I[236 + 460 - 613 + 764] = I("\u0019='\b/4u&D8?&r\u0017?('1\u0010>(7r\u0006'519", "ZRRdK");
      I[556 + 450 - 405 + 247] = I("\u00141\u0012&/:\u0019'\u0002#4", "YrnvF");
      I[549 + 131 - 35 + 204] = I("厢椃", "xuacD");
      I[349 + 385 - 580 + 696] = I("塿", "HxWZV");
      I[754 + 134 - 98 + 61] = I("烲伮揫", "aTsld");
      I[209 + 42 - -377 + 224] = I("替喥廔", "pBtlm");
      I[572 + 429 - 702 + 554] = I("塘暦尔帻岇", "jxvVZ");
      I[778 + 136 - 580 + 520] = I("幬崼", "WyiiI");
      I[812 + 9 - 174 + 208] = I("因敒", "UcYSm");
      I[433 + 451 - 415 + 387] = I("囗咷塭潸", "BAAFG");
      I[140 + 139 - -162 + 416] = I("兓帉灦弶", "HcRXb");
      I[87 + 289 - -359 + 123] = I("\u0015>\u0018\t\u00158v\u0019E\u0001?2\u0006E\u0018\"4\u0000", "VQmeq");
   }

   private long currentTimeMillis() {
      return System.nanoTime() / 1000000L;
   }

   public void func_194308_a(CPacketPlaceRecipe var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.markPlayerActive();
      if (!this.playerEntity.isSpectator() && this.playerEntity.openContainer.windowId == var1.func_194318_a() && this.playerEntity.openContainer.getCanCraft(this.playerEntity)) {
         this.field_194309_H.func_194327_a(this.playerEntity, var1.func_194317_b(), var1.func_194319_c());
      }

   }

   public void handleSpectate(CPacketSpectate var1) {
      String var10000 = I[113 + 258 - 43 + 10];
      String var10001 = I[75 + 131 - 45 + 178];
      String var10002 = I[223 + 199 - 107 + 25];
      var10001 = I[309 + 41 - 327 + 318];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      if (this.playerEntity.isSpectator()) {
         Entity var2 = null;
         WorldServer[] var3 = this.serverController.worldServers;
         int var4 = var3.length;
         int var5 = "".length();

         while(var5 < var4) {
            WorldServer var6 = var3[var5];
            if (var6 != null) {
               var2 = var1.getEntity(var6);
               if (var2 != null) {
                  "".length();
                  if (4 <= 3) {
                     throw null;
                  }
                  break;
               }
            }

            ++var5;
            "".length();
            if (2 >= 4) {
               throw null;
            }
         }

         if (var2 != null) {
            this.playerEntity.setSpectatingEntity(this.playerEntity);
            this.playerEntity.dismountRidingEntity();
            if (var2.world == this.playerEntity.world) {
               this.playerEntity.setPositionAndUpdate(var2.posX, var2.posY, var2.posZ);
               "".length();
               if (3 <= -1) {
                  throw null;
               }
            } else {
               WorldServer var7 = this.playerEntity.getServerWorld();
               WorldServer var8 = (WorldServer)var2.world;
               this.playerEntity.dimension = var2.dimension;
               I[3 + 295 - -15 + 29].length();
               I[226 + 31 - 94 + 180].length();
               this.sendPacket(new SPacketRespawn(this.playerEntity.dimension, var7.getDifficulty(), var7.getWorldInfo().getTerrainType(), this.playerEntity.interactionManager.getGameType()));
               this.serverController.getPlayerList().updatePermissionLevel(this.playerEntity);
               var7.removeEntityDangerously(this.playerEntity);
               this.playerEntity.isDead = (boolean)"".length();
               this.playerEntity.setLocationAndAngles(var2.posX, var2.posY, var2.posZ, var2.rotationYaw, var2.rotationPitch);
               if (this.playerEntity.isEntityAlive()) {
                  var7.updateEntityWithOptionalForce(this.playerEntity, (boolean)"".length());
                  var8.spawnEntityInWorld(this.playerEntity);
                  I[197 + 129 - 148 + 166].length();
                  I[233 + 342 - 464 + 234].length();
                  I[265 + 343 - 336 + 74].length();
                  var8.updateEntityWithOptionalForce(this.playerEntity, (boolean)"".length());
               }

               this.playerEntity.setWorld(var8);
               this.serverController.getPlayerList().preparePlayer(this.playerEntity, var7);
               this.playerEntity.setPositionAndUpdate(var2.posX, var2.posY, var2.posZ);
               this.playerEntity.interactionManager.setWorld(var8);
               this.serverController.getPlayerList().updateTimeAndWeatherForPlayer(this.playerEntity, var8);
               this.serverController.getPlayerList().syncPlayerInventory(this.playerEntity);
            }
         }
      }

   }

   private void captureCurrentPosition() {
      this.firstGoodX = this.playerEntity.posX;
      this.firstGoodY = this.playerEntity.posY;
      this.firstGoodZ = this.playerEntity.posZ;
      this.lastGoodX = this.playerEntity.posX;
      this.lastGoodY = this.playerEntity.posY;
      this.lastGoodZ = this.playerEntity.posZ;
   }

   public void processKeepAlive(CPacketKeepAlive var1) {
      String var10000 = I[204 + 359 - 317 + 310];
      String var10001 = I[83 + 182 - 217 + 509];
      String var10002 = I[343 + 360 - 532 + 387];
      var10001 = I[21 + 507 - 292 + 323];
      if (this.field_194403_g && var1.getKey() == this.field_194404_h) {
         int var2 = (int)(this.currentTimeMillis() - this.field_194402_f);
         this.playerEntity.ping = (this.playerEntity.ping * "   ".length() + var2) / (60 ^ 56);
         this.field_194403_g = (boolean)"".length();
         "".length();
         if (3 == 1) {
            throw null;
         }
      } else if (!this.playerEntity.getName().equals(this.serverController.getServerOwner())) {
         I[488 + 559 - 665 + 178].length();
         this.func_194028_b(new TextComponentTranslation(I[93 + 400 - 350 + 418], new Object["".length()]));
      }

   }

   public void processHeldItemChange(CPacketHeldItemChange var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      if (var1.getSlotId() >= 0 && var1.getSlotId() < InventoryPlayer.getHotbarSize()) {
         this.playerEntity.inventory.currentItem = var1.getSlotId();
         this.playerEntity.markPlayerActive();
         "".length();
         if (2 == 4) {
            throw null;
         }
      } else {
         LOGGER.warn(I[31 + 30 - -40 + 282], this.playerEntity.getName());
      }

   }

   public void processChatMessage(CPacketChatMessage var1) {
      String var10000 = I[68 + 91 - 144 + 369];
      String var10001 = I[38 + 15 - -179 + 153];
      String var10002 = I[4 + 9 - -6 + 367];
      var10001 = I[71 + 31 - -132 + 153];
      var10000 = I[154 + 116 - 58 + 176];
      var10001 = I[125 + 34 - 82 + 312];
      var10002 = I[250 + 255 - 403 + 288];
      var10001 = I[269 + 13 - 27 + 136];
      var10000 = I[208 + 27 - 133 + 290];
      var10001 = I[372 + 321 - 593 + 293];
      var10002 = I[137 + 8 - -41 + 208];
      var10001 = I[248 + 298 - 379 + 228];
      var10000 = I[304 + 115 - 62 + 39];
      var10001 = I[224 + 21 - 74 + 226];
      var10002 = I[205 + 114 - 208 + 287];
      var10001 = I[11 + 199 - 157 + 346];
      var10000 = I[27 + 313 - 333 + 393];
      var10001 = I[260 + 136 - 77 + 82];
      var10002 = I[241 + 189 - 108 + 80];
      var10001 = I[45 + 383 - 84 + 59];
      var10000 = I[148 + 297 - 303 + 262];
      var10001 = I[346 + 26 - 220 + 253];
      var10002 = I[200 + 215 - 132 + 123];
      var10001 = I[355 + 70 - 369 + 351];
      var10000 = I[390 + 220 - 336 + 134];
      var10001 = I[390 + 113 - 409 + 315];
      var10002 = I[83 + 290 - 204 + 241];
      var10001 = I[374 + 0 - 165 + 202];
      var10000 = I[315 + 24 - 106 + 179];
      var10001 = I[342 + 95 - 355 + 331];
      var10002 = I[361 + 14 - 204 + 243];
      var10001 = I[346 + 212 - 412 + 269];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      if (this.playerEntity.getChatVisibility() == EntityPlayer.EnumChatVisibility.HIDDEN) {
         I[53 + 260 - 224 + 327].length();
         I[354 + 231 - 500 + 332].length();
         TextComponentTranslation var2 = new TextComponentTranslation(I[53 + 258 - 274 + 381], new Object["".length()]);
         var2.getStyle().setColor(TextFormatting.RED);
         I[235 + 318 - 495 + 361].length();
         I[142 + 135 - -8 + 135].length();
         I[90 + 166 - 196 + 361].length();
         I[236 + 341 - 571 + 416].length();
         this.sendPacket(new SPacketChat(var2));
         "".length();
         if (2 == 0) {
            throw null;
         }
      } else {
         this.playerEntity.markPlayerActive();
         String var4 = var1.getMessage();
         var4 = StringUtils.normalizeSpace(var4);
         int var3 = "".length();

         while(var3 < var4.length()) {
            if (!ChatAllowedCharacters.isAllowedCharacter(var4.charAt(var3))) {
               I[244 + 11 - 159 + 327].length();
               I[24 + 380 - 386 + 406].length();
               I[270 + 375 - 521 + 301].length();
               I[111 + 289 - 8 + 34].length();
               this.func_194028_b(new TextComponentTranslation(I[376 + 191 - 520 + 380], new Object["".length()]));
               return;
            }

            ++var3;
            "".length();
            if (4 < 4) {
               throw null;
            }
         }

         if (var4.startsWith(I[271 + 271 - 115 + 1])) {
            this.handleSlashCommand(var4);
            "".length();
            if (1 >= 2) {
               throw null;
            }
         } else {
            I[427 + 147 - 569 + 424].length();
            I[0 + 138 - 19 + 311].length();
            I[288 + 173 - 54 + 24].length();
            I[397 + 311 - 482 + 206].length();
            var10002 = I[237 + 281 - 389 + 304];
            Object[] var10003 = new Object["  ".length()];
            I[74 + 25 - 55 + 390].length();
            I[273 + 405 - 587 + 344].length();
            I[200 + 428 - 577 + 385].length();
            var10003["".length()] = this.playerEntity.getDisplayName();
            I[226 + 209 - 254 + 256].length();
            I[351 + 5 - 97 + 179].length();
            I[88 + 379 - 85 + 57].length();
            var10003[" ".length()] = var4;
            TextComponentTranslation var5 = new TextComponentTranslation(var10002, var10003);
            this.serverController.getPlayerList().sendChatMsgImpl(var5, (boolean)"".length());
         }

         I[136 + 13 - -44 + 247].length();
         I[409 + 236 - 424 + 220].length();
         this.chatSpamThresholdCount += 191 ^ 171;
         if (this.chatSpamThresholdCount > 193 + 119 - 286 + 174 && !this.serverController.getPlayerList().canSendCommands(this.playerEntity.getGameProfile())) {
            I[35 + 128 - 12 + 291].length();
            I[186 + 249 - 218 + 226].length();
            this.func_194028_b(new TextComponentTranslation(I[216 + 281 - 270 + 217], new Object["".length()]));
         }
      }

   }

   public void processCreativeInventoryAction(CPacketCreativeInventoryAction var1) {
      String var10000 = I[431 + 367 - 739 + 450];
      String var10001 = I[374 + 149 - 494 + 481];
      String var10002 = I[346 + 468 - 506 + 203];
      var10001 = I[42 + 123 - -148 + 199];
      var10000 = I[144 + 250 - -32 + 87];
      var10001 = I[188 + 411 - 136 + 51];
      var10002 = I[125 + 132 - -200 + 58];
      var10001 = I[210 + 228 - 324 + 402];
      var10000 = I[157 + 188 - 157 + 329];
      var10001 = I[350 + 445 - 285 + 8];
      var10002 = I[453 + 431 - 510 + 145];
      var10001 = I[115 + 187 - 259 + 477];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      if (this.playerEntity.interactionManager.isCreative()) {
         int var11;
         if (var1.getSlotId() < 0) {
            var11 = " ".length();
            "".length();
            if (-1 >= 1) {
               throw null;
            }
         } else {
            var11 = "".length();
         }

         int var2 = var11;
         ItemStack var3 = var1.getStack();
         if (!var3.isEmpty() && var3.hasTagCompound() && var3.getTagCompound().hasKey(I[17 + 306 - 286 + 484], 67 ^ 73)) {
            NBTTagCompound var4 = var3.getTagCompound().getCompoundTag(I[466 + 431 - 707 + 332]);
            if (var4.hasKey(I[357 + 406 - 686 + 446]) && var4.hasKey(I[329 + 409 - 518 + 304]) && var4.hasKey(I[519 + 85 - 372 + 293])) {
               I[244 + 178 - 114 + 218].length();
               BlockPos var5 = new BlockPos(var4.getInteger(I[497 + 204 - 349 + 175]), var4.getInteger(I[184 + 231 - 343 + 456]), var4.getInteger(I[290 + 75 - -131 + 33]));
               TileEntity var6 = this.playerEntity.world.getTileEntity(var5);
               if (var6 != null) {
                  I[106 + 151 - 80 + 353].length();
                  NBTTagCompound var7 = var6.writeToNBT(new NBTTagCompound());
                  var7.removeTag(I[530 + 500 - 656 + 157]);
                  var7.removeTag(I[7 + 521 - 384 + 388]);
                  var7.removeTag(I[369 + 216 - 331 + 279]);
                  var3.setTagInfo(I[24 + 482 - -16 + 12], var7);
               }
            }
         }

         if (var1.getSlotId() >= " ".length() && var1.getSlotId() <= (117 ^ 88)) {
            var11 = " ".length();
            "".length();
            if (4 < 0) {
               throw null;
            }
         } else {
            var11 = "".length();
         }

         int var8 = var11;
         if (!var3.isEmpty() && (var3.getMetadata() < 0 || var3.func_190916_E() > (34 ^ 98) || var3.isEmpty())) {
            var11 = "".length();
         } else {
            var11 = " ".length();
            "".length();
            if (3 < 1) {
               throw null;
            }
         }

         int var9 = var11;
         if (var8 != 0 && var9 != 0) {
            if (var3.isEmpty()) {
               this.playerEntity.inventoryContainer.putStackInSlot(var1.getSlotId(), ItemStack.field_190927_a);
               "".length();
               if (1 <= 0) {
                  throw null;
               }
            } else {
               this.playerEntity.inventoryContainer.putStackInSlot(var1.getSlotId(), var3);
            }

            this.playerEntity.inventoryContainer.setCanCraft(this.playerEntity, (boolean)" ".length());
            "".length();
            if (3 >= 4) {
               throw null;
            }
         } else if (var2 != 0 && var9 != 0 && this.itemDropThreshold < 154 + 87 - 205 + 164) {
            I[286 + 162 - 380 + 467].length();
            I[383 + 494 - 640 + 299].length();
            I[256 + 300 - 475 + 456].length();
            this.itemDropThreshold += 100 ^ 112;
            EntityItem var10 = this.playerEntity.dropItem(var3, (boolean)" ".length());
            if (var10 != null) {
               var10.setAgeToCreativeDespawnTime();
            }
         }
      }

   }

   public void processCustomPayload(CPacketCustomPayload var1) {
      String var10000 = I[253 + 501 - 602 + 421];
      String var10001 = I[553 + 46 - 175 + 150];
      String var10002 = I[73 + 467 - 92 + 127];
      var10001 = I[405 + 8 - 182 + 345];
      var10000 = I[507 + 115 - 45 + 0];
      var10001 = I[491 + 416 - 898 + 569];
      var10002 = I[242 + 108 - -213 + 16];
      var10001 = I[537 + 490 - 827 + 380];
      var10000 = I[405 + 460 - 391 + 107];
      var10001 = I[366 + 253 - 37 + 0];
      var10002 = I[283 + 190 - 334 + 444];
      var10001 = I[509 + 251 - 230 + 54];
      var10000 = I[451 + 282 - 597 + 449];
      var10001 = I[385 + 577 - 762 + 386];
      var10002 = I[202 + 466 - 422 + 341];
      var10001 = I[570 + 64 - 370 + 324];
      var10000 = I[395 + 18 - 195 + 371];
      var10001 = I[27 + 80 - -220 + 263];
      var10002 = I[309 + 234 - 173 + 221];
      var10001 = I[220 + 103 - 243 + 512];
      var10000 = I[512 + 552 - 531 + 60];
      var10001 = I[342 + 183 - -4 + 65];
      var10002 = I[72 + 395 - 211 + 339];
      var10001 = I[540 + 225 - 439 + 270];
      var10000 = I[173 + 114 - 85 + 395];
      var10001 = I[585 + 517 - 551 + 47];
      var10002 = I[255 + 237 - -34 + 73];
      var10001 = I[583 + 104 - 683 + 596];
      var10000 = I[69 + 548 - 378 + 362];
      var10001 = I[519 + 517 - 735 + 301];
      var10002 = I[257 + 115 - 9 + 240];
      var10001 = I[139 + 333 - 308 + 440];
      var10000 = I[301 + 354 - 474 + 424];
      var10001 = I[139 + 331 - 458 + 594];
      var10002 = I[416 + 439 - 344 + 96];
      var10001 = I[433 + 273 - 678 + 580];
      var10000 = I[99 + 63 - -337 + 110];
      var10001 = I[469 + 272 - 704 + 573];
      var10002 = I[306 + 327 - 389 + 367];
      var10001 = I[258 + 583 - 730 + 501];
      var10000 = I[290 + 3 - 276 + 596];
      var10001 = I[236 + 345 - 151 + 184];
      var10002 = I[29 + 181 - -39 + 366];
      var10001 = I[555 + 532 - 497 + 26];
      var10000 = I[70 + 207 - 208 + 548];
      var10001 = I[112 + 42 - -142 + 322];
      var10002 = I[96 + 473 - 473 + 523];
      var10001 = I[512 + 112 - 181 + 177];
      var10000 = I[149 + 370 - 232 + 334];
      var10001 = I[42 + 160 - -36 + 384];
      var10002 = I[383 + 484 - 682 + 438];
      var10001 = I[405 + 393 - 577 + 403];
      var10000 = I[461 + 34 - 69 + 199];
      var10001 = I[483 + 390 - 529 + 282];
      var10002 = I[564 + 84 - 299 + 278];
      var10001 = I[580 + 225 - 325 + 148];
      var10000 = I[460 + 476 - 342 + 35];
      var10001 = I[302 + 364 - 62 + 26];
      var10002 = I[222 + 281 - 362 + 490];
      var10001 = I[435 + 4 - 213 + 406];
      var10000 = I[38 + 366 - -40 + 189];
      var10001 = I[248 + 431 - 574 + 529];
      var10002 = I[311 + 601 - 753 + 476];
      var10001 = I[261 + 196 - 240 + 419];
      var10000 = I[318 + 430 - 548 + 437];
      var10001 = I[484 + 14 - 130 + 270];
      var10002 = I[610 + 542 - 615 + 102];
      var10001 = I[489 + 242 - 342 + 251];
      var10000 = I[457 + 4 - 258 + 438];
      var10001 = I[61 + 294 - 149 + 436];
      var10002 = I[597 + 177 - 262 + 131];
      var10001 = I[227 + 518 - 109 + 8];
      var10000 = I[351 + 313 - 357 + 338];
      var10001 = I[516 + 196 - 536 + 470];
      var10002 = I[607 + 587 - 1082 + 535];
      var10001 = I[511 + 427 - 319 + 29];
      var10000 = I[37 + 260 - 18 + 370];
      var10001 = I[632 + 629 - 1164 + 553];
      var10002 = I[36 + 459 - -2 + 154];
      var10001 = I[541 + 593 - 895 + 413];
      var10000 = I[27 + 575 - 195 + 246];
      var10001 = I[521 + 245 - 414 + 302];
      var10002 = I[618 + 552 - 687 + 172];
      var10001 = I[607 + 224 - 632 + 457];
      var10000 = I[222 + 21 - -160 + 254];
      var10001 = I[421 + 421 - 291 + 107];
      var10002 = I[578 + 584 - 984 + 481];
      var10001 = I[22 + 22 - 22 + 638];
      var10000 = I[593 + 93 - 90 + 65];
      var10001 = I[80 + 518 - 474 + 538];
      var10002 = I[54 + 433 - -103 + 73];
      var10001 = I[274 + 4 - -309 + 77];
      var10000 = I[67 + 171 - -84 + 343];
      var10001 = I[629 + 527 - 1000 + 510];
      var10002 = I[528 + 594 - 764 + 309];
      var10001 = I[141 + 274 - -116 + 137];
      var10000 = I[587 + 593 - 974 + 463];
      var10001 = I[657 + 587 - 970 + 396];
      var10002 = I[140 + 249 - 285 + 567];
      var10001 = I[616 + 422 - 408 + 42];
      var10000 = I[623 + 366 - 822 + 506];
      var10001 = I[437 + 659 - 560 + 138];
      var10002 = I[502 + 50 - 503 + 626];
      var10001 = I[165 + 36 - -119 + 356];
      var10000 = I[213 + 379 - 249 + 334];
      var10001 = I[516 + 363 - 437 + 236];
      var10002 = I[171 + 496 - 110 + 122];
      var10001 = I[453 + 572 - 428 + 83];
      var10000 = I[653 + 13 - 307 + 322];
      var10001 = I[80 + 323 - 0 + 279];
      var10002 = I[558 + 503 - 549 + 171];
      var10001 = I[130 + 616 - 637 + 575];
      var10000 = I[420 + 378 - 662 + 549];
      var10001 = I[542 + 646 - 827 + 325];
      var10002 = I[72 + 308 - 128 + 435];
      var10001 = I[661 + 184 - 202 + 45];
      var10000 = I[288 + 514 - 395 + 282];
      var10001 = I[413 + 399 - 550 + 428];
      var10002 = I[660 + 63 - 447 + 415];
      var10001 = I[498 + 136 - -11 + 47];
      var10000 = I[569 + 557 - 1030 + 597];
      var10001 = I[548 + 660 - 1080 + 566];
      var10002 = I[577 + 553 - 836 + 401];
      var10001 = I[570 + 261 - 348 + 213];
      var10000 = I[491 + 20 - -93 + 93];
      var10001 = I[442 + 203 - 377 + 430];
      var10002 = I[566 + 151 - 307 + 289];
      var10001 = I[278 + 428 - 619 + 613];
      var10000 = I[136 + 1 - -422 + 142];
      var10001 = I[76 + 134 - -94 + 398];
      var10002 = I[675 + 316 - 582 + 294];
      var10001 = I[601 + 553 - 1087 + 637];
      var10000 = I[107 + 334 - -159 + 105];
      var10001 = I[74 + 673 - 379 + 338];
      var10002 = I[544 + 271 - 245 + 137];
      var10001 = I[551 + 697 - 1226 + 686];
      var10000 = I[460 + 656 - 1035 + 628];
      var10001 = I[346 + 309 - 325 + 380];
      var10002 = I[507 + 130 - 338 + 412];
      var10001 = I[105 + 331 - 20 + 296];
      var10000 = I[673 + 69 - 426 + 397];
      var10001 = I[233 + 303 - -144 + 34];
      var10002 = I[492 + 400 - 582 + 405];
      var10001 = I[286 + 312 - -105 + 13];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      String var2 = var1.getChannelName();
      PacketBuffer var27;
      ItemStack var39;
      ItemStack var44;
      IOException var63;
      if (I[666 + 564 - 1025 + 512].equals(var2)) {
         var27 = var1.getBufferData();

         label285: {
            try {
               var39 = var27.readItemStackFromBuffer();
               if (var39.isEmpty()) {
                  return;
               }

               if (!ItemWritableBook.isNBTValid(var39.getTagCompound())) {
                  I[3 + 332 - 284 + 667].length();
                  I[303 + 124 - 188 + 480].length();
                  I[196 + 61 - -5 + 458].length();
                  var63 = new IOException(I[94 + 583 - 453 + 497]);
                  I[482 + 652 - 866 + 454].length();
                  I[430 + 260 - -6 + 27].length();
                  I[237 + 42 - -29 + 416].length();
                  I[121 + 131 - -231 + 242].length();
                  throw var63;
               }

               var44 = this.playerEntity.getHeldItemMainhand();
               if (var44.isEmpty()) {
                  return;
               }

               if (var39.getItem() == Items.WRITABLE_BOOK && var39.getItem() == var44.getItem()) {
                  var44.setTagInfo(I[350 + 347 - 4 + 33], var39.getTagCompound().getTagList(I[348 + 537 - 264 + 106], 189 ^ 181));
               }
            } catch (Exception var23) {
               LOGGER.error(I[594 + 10 - 159 + 283], var23);
               break label285;
            }

            "".length();
            if (0 == 4) {
               throw null;
            }
         }

         "".length();
         if (-1 == 2) {
            throw null;
         }
      } else {
         String var9;
         if (I[3 + 674 - 557 + 609].equals(var2)) {
            var27 = var1.getBufferData();

            label306: {
               try {
                  var39 = var27.readItemStackFromBuffer();
                  if (var39.isEmpty()) {
                     return;
                  }

                  if (!ItemWrittenBook.validBookTagContents(var39.getTagCompound())) {
                     I[211 + 377 - 71 + 213].length();
                     I[583 + 69 - -3 + 76].length();
                     I[26 + 88 - 69 + 687].length();
                     var63 = new IOException(I[707 + 544 - 860 + 342]);
                     I[566 + 351 - 243 + 60].length();
                     I[646 + 149 - 379 + 319].length();
                     I[663 + 32 - 639 + 680].length();
                     I[406 + 421 - 386 + 296].length();
                     I[112 + 218 - -407 + 1].length();
                     throw var63;
                  }

                  var44 = this.playerEntity.getHeldItemMainhand();
                  if (var44.isEmpty()) {
                     return;
                  }

                  if (var39.getItem() == Items.WRITABLE_BOOK && var44.getItem() == Items.WRITABLE_BOOK) {
                     I[571 + 625 - 641 + 184].length();
                     I[568 + 341 - 389 + 220].length();
                     I[93 + 691 - 571 + 528].length();
                     ItemStack var45 = new ItemStack(Items.WRITTEN_BOOK);
                     var10001 = I[18 + 715 - 570 + 579];
                     I[236 + 347 - 562 + 722].length();
                     var45.setTagInfo(var10001, new NBTTagString(this.playerEntity.getName()));
                     var10001 = I[269 + 512 - 78 + 41];
                     I[354 + 371 - -2 + 18].length();
                     I[518 + 376 - 372 + 224].length();
                     var45.setTagInfo(var10001, new NBTTagString(var39.getTagCompound().getString(I[229 + 515 - 6 + 9])));
                     NBTTagList var47 = var39.getTagCompound().getTagList(I[350 + 495 - 228 + 131], 98 ^ 106);
                     int var50 = "".length();

                     while(true) {
                        if (var50 >= var47.tagCount()) {
                           var45.setTagInfo(I[23 + 717 - 685 + 700], var47);
                           this.playerEntity.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, var45);
                           break;
                        }

                        var9 = var47.getStringTagAt(var50);
                        I[744 + 480 - 575 + 100].length();
                        I[678 + 643 - 656 + 85].length();
                        I[112 + 174 - -378 + 87].length();
                        TextComponentString var53 = new TextComponentString(var9);
                        var9 = ITextComponent.Serializer.componentToJson(var53);
                        I[110 + 332 - 349 + 659].length();
                        I[92 + 93 - -181 + 387].length();
                        I[506 + 180 - 466 + 534].length();
                        var47.set(var50, new NBTTagString(var9));
                        ++var50;
                        "".length();
                        if (3 == 1) {
                           throw null;
                        }
                     }
                  }
               } catch (Exception var24) {
                  LOGGER.error(I[633 + 207 - 493 + 409], var24);
                  break label306;
               }

               "".length();
               if (false) {
                  throw null;
               }
            }

            "".length();
            if (2 < -1) {
               throw null;
            }
         } else if (I[200 + 62 - -147 + 348].equals(var2)) {
            try {
               int var30 = var1.getBufferData().readInt();
               Container var36 = this.playerEntity.openContainer;
               if (var36 instanceof ContainerMerchant) {
                  ((ContainerMerchant)var36).setCurrentRecipeIndex(var30);
               }
            } catch (Exception var25) {
               LOGGER.error(I[37 + 307 - 93 + 507], var25);
               "".length();
               if (1 != 2) {
                  return;
               }

               throw null;
            }

            "".length();
            if (-1 >= 4) {
               throw null;
            }
         } else {
            TileEntity var6;
            String var10003;
            Object[] var10004;
            EntityPlayerMP var60;
            if (I[434 + 643 - 741 + 423].equals(var2)) {
               if (!this.serverController.isCommandBlockEnabled()) {
                  var60 = this.playerEntity;
                  I[560 + 11 - 14 + 203].length();
                  I[271 + 542 - 739 + 687].length();
                  I[582 + 247 - 280 + 213].length();
                  I[345 + 393 - 272 + 297].length();
                  var60.addChatMessage(new TextComponentTranslation(I[705 + 120 - 268 + 207], new Object["".length()]));
                  return;
               }

               if (!this.playerEntity.canUseCommandBlock()) {
                  var60 = this.playerEntity;
                  I[38 + 245 - -450 + 32].length();
                  I[302 + 693 - 514 + 285].length();
                  I[75 + 460 - 531 + 763].length();
                  var60.addChatMessage(new TextComponentTranslation(I[320 + 391 - 516 + 573], new Object["".length()]));
                  return;
               }

               var27 = var1.getBufferData();

               label227: {
                  try {
                     byte var34 = var27.readByte();
                     CommandBlockBaseLogic var37 = null;
                     if (var34 == 0) {
                        World var62 = this.playerEntity.world;
                        I[433 + 435 - 104 + 5].length();
                        I[555 + 133 - 200 + 282].length();
                        var6 = var62.getTileEntity(new BlockPos(var27.readInt(), var27.readInt(), var27.readInt()));
                        if (var6 instanceof TileEntityCommandBlock) {
                           var37 = ((TileEntityCommandBlock)var6).getCommandBlockLogic();
                        }

                        "".length();
                        if (4 == 1) {
                           throw null;
                        }
                     } else if (var34 == " ".length()) {
                        Entity var41 = this.playerEntity.world.getEntityByID(var27.readInt());
                        if (var41 instanceof EntityMinecartCommandBlock) {
                           var37 = ((EntityMinecartCommandBlock)var41).getCommandBlockLogic();
                        }
                     }

                     String var43 = var27.readStringFromBuffer(var27.readableBytes());
                     boolean var46 = var27.readBoolean();
                     if (var37 != null) {
                        var37.setCommand(var43);
                        var37.setTrackOutput(var46);
                        if (!var46) {
                           var37.setLastOutput((ITextComponent)null);
                        }

                        var37.updateCommand();
                        var60 = this.playerEntity;
                        I[257 + 732 - 245 + 27].length();
                        I[253 + 327 - 401 + 593].length();
                        I[45 + 428 - 378 + 678].length();
                        I[455 + 440 - 414 + 293].length();
                        var10003 = I[463 + 19 - -169 + 124];
                        var10004 = new Object[" ".length()];
                        I[679 + 183 - 154 + 68].length();
                        I[37 + 467 - 380 + 653].length();
                        I[158 + 425 - 403 + 598].length();
                        var10004["".length()] = var43;
                        var60.addChatMessage(new TextComponentTranslation(var10003, var10004));
                     }
                  } catch (Exception var19) {
                     LOGGER.error(I[106 + 517 - -91 + 65], var19);
                     break label227;
                  }

                  "".length();
                  if (1 >= 2) {
                     throw null;
                  }
               }

               "".length();
               if (4 < 1) {
                  throw null;
               }
            } else if (I[122 + 336 - 120 + 442].equals(var2)) {
               if (!this.serverController.isCommandBlockEnabled()) {
                  var60 = this.playerEntity;
                  I[339 + 658 - 300 + 84].length();
                  I[284 + 289 - 231 + 440].length();
                  var60.addChatMessage(new TextComponentTranslation(I[158 + 188 - -405 + 32], new Object["".length()]));
                  return;
               }

               if (!this.playerEntity.canUseCommandBlock()) {
                  var60 = this.playerEntity;
                  I[115 + 746 - 474 + 397].length();
                  I[634 + 528 - 556 + 179].length();
                  I[608 + 31 - 262 + 409].length();
                  I[431 + 597 - 511 + 270].length();
                  I[285 + 459 - 251 + 295].length();
                  var60.addChatMessage(new TextComponentTranslation(I[437 + 668 - 925 + 609], new Object["".length()]));
                  return;
               }

               var27 = var1.getBufferData();

               label239: {
                  try {
                     CommandBlockBaseLogic var32 = null;
                     TileEntityCommandBlock var33 = null;
                     I[21 + 340 - -217 + 212].length();
                     I[742 + 435 - 692 + 306].length();
                     I[195 + 687 - 775 + 685].length();
                     BlockPos var38 = new BlockPos(var27.readInt(), var27.readInt(), var27.readInt());
                     TileEntity var42 = this.playerEntity.world.getTileEntity(var38);
                     if (var42 instanceof TileEntityCommandBlock) {
                        var33 = (TileEntityCommandBlock)var42;
                        var32 = var33.getCommandBlockLogic();
                     }

                     String var49 = var27.readStringFromBuffer(var27.readableBytes());
                     boolean var51 = var27.readBoolean();
                     TileEntityCommandBlock.Mode var52 = TileEntityCommandBlock.Mode.valueOf(var27.readStringFromBuffer(188 ^ 172));
                     boolean var54 = var27.readBoolean();
                     boolean var55 = var27.readBoolean();
                     if (var32 != null) {
                        EnumFacing var56 = (EnumFacing)this.playerEntity.world.getBlockState(var38).getValue(BlockCommandBlock.FACING);
                        switch(null.$SwitchMap$net$minecraft$tileentity$TileEntityCommandBlock$Mode[var52.ordinal()]) {
                        case 1:
                           IBlockState var57 = Blocks.CHAIN_COMMAND_BLOCK.getDefaultState();
                           this.playerEntity.world.setBlockState(var38, var57.withProperty(BlockCommandBlock.FACING, var56).withProperty(BlockCommandBlock.CONDITIONAL, var54), "  ".length());
                           I[653 + 180 - 748 + 708].length();
                           I[417 + 190 - 379 + 566].length();
                           "".length();
                           if (4 == 0) {
                              throw null;
                           }
                           break;
                        case 2:
                           IBlockState var58 = Blocks.REPEATING_COMMAND_BLOCK.getDefaultState();
                           this.playerEntity.world.setBlockState(var38, var58.withProperty(BlockCommandBlock.FACING, var56).withProperty(BlockCommandBlock.CONDITIONAL, var54), "  ".length());
                           I[3 + 76 - 67 + 783].length();
                           "".length();
                           if (1 == 4) {
                              throw null;
                           }
                           break;
                        case 3:
                           IBlockState var59 = Blocks.COMMAND_BLOCK.getDefaultState();
                           this.playerEntity.world.setBlockState(var38, var59.withProperty(BlockCommandBlock.FACING, var56).withProperty(BlockCommandBlock.CONDITIONAL, var54), "  ".length());
                           I[464 + 328 - 48 + 52].length();
                           I[486 + 184 - 210 + 337].length();
                        }

                        var42.validate();
                        this.playerEntity.world.setTileEntity(var38, var42);
                        var32.setCommand(var49);
                        var32.setTrackOutput(var51);
                        if (!var51) {
                           var32.setLastOutput((ITextComponent)null);
                        }

                        var33.setAuto(var55);
                        var32.updateCommand();
                        if (!net.minecraft.util.StringUtils.isNullOrEmpty(var49)) {
                           var60 = this.playerEntity;
                           I[517 + 631 - 752 + 402].length();
                           I[304 + 89 - -79 + 327].length();
                           var10003 = I[354 + 445 - 440 + 441];
                           var10004 = new Object[" ".length()];
                           I[336 + 736 - 474 + 203].length();
                           I[48 + 430 - -246 + 78].length();
                           var10004["".length()] = var49;
                           var60.addChatMessage(new TextComponentTranslation(var10003, var10004));
                        }
                     }
                  } catch (Exception var20) {
                     LOGGER.error(I[317 + 154 - 112 + 444], var20);
                     break label239;
                  }

                  "".length();
                  if (0 < -1) {
                     throw null;
                  }
               }

               "".length();
               if (3 < -1) {
                  throw null;
               }
            } else {
               int var29;
               if (I[17 + 173 - 30 + 644].equals(var2)) {
                  if (this.playerEntity.openContainer instanceof ContainerBeacon) {
                     try {
                        var27 = var1.getBufferData();
                        var29 = var27.readInt();
                        int var31 = var27.readInt();
                        ContainerBeacon var35 = (ContainerBeacon)this.playerEntity.openContainer;
                        Slot var40 = var35.getSlot("".length());
                        if (var40.getHasStack()) {
                           var40.decrStackSize(" ".length());
                           I[438 + 503 - 851 + 715].length();
                           IInventory var48 = var35.getTileEntity();
                           var48.setField(" ".length(), var29);
                           var48.setField("  ".length(), var31);
                           var48.markDirty();
                        }
                     } catch (Exception var26) {
                        LOGGER.error(I[662 + 778 - 1104 + 470], var26);
                        "".length();
                        if (3 < -1) {
                           throw null;
                        }

                        return;
                     }

                     "".length();
                     if (1 >= 2) {
                        throw null;
                     }
                  }
               } else if (I[65 + 696 - 399 + 445].equals(var2)) {
                  if (this.playerEntity.openContainer instanceof ContainerRepair) {
                     ContainerRepair var3 = (ContainerRepair)this.playerEntity.openContainer;
                     if (var1.getBufferData() != null && var1.getBufferData().readableBytes() >= " ".length()) {
                        String var4 = ChatAllowedCharacters.filterAllowedCharacters(var1.getBufferData().readStringFromBuffer(13038 + 24091 - '腍' + 28739));
                        if (var4.length() <= (160 ^ 131)) {
                           var3.updateItemName(var4);
                        }

                        "".length();
                        if (4 < 2) {
                           throw null;
                        }
                     } else {
                        var3.updateItemName(I[378 + 189 - 429 + 670]);
                     }

                     "".length();
                     if (3 < 2) {
                        throw null;
                     }
                  }
               } else if (I[469 + 196 - 262 + 406].equals(var2)) {
                  if (!this.playerEntity.canUseCommandBlock()) {
                     return;
                  }

                  var27 = var1.getBufferData();

                  label256: {
                     try {
                        I[336 + 712 - 261 + 23].length();
                        I[693 + 767 - 1085 + 436].length();
                        BlockPos var28 = new BlockPos(var27.readInt(), var27.readInt(), var27.readInt());
                        IBlockState var5 = this.playerEntity.world.getBlockState(var28);
                        var6 = this.playerEntity.world.getTileEntity(var28);
                        if (var6 instanceof TileEntityStructure) {
                           TileEntityStructure var7 = (TileEntityStructure)var6;
                           byte var8 = var27.readByte();
                           var9 = var27.readStringFromBuffer(100 ^ 68);
                           var7.setMode(TileEntityStructure.Mode.valueOf(var9));
                           var7.setName(var27.readStringFromBuffer(15 ^ 79));
                           int var10 = MathHelper.clamp(var27.readInt(), -(156 ^ 188), 10 ^ 42);
                           int var11 = MathHelper.clamp(var27.readInt(), -(64 ^ 96), 190 ^ 158);
                           int var12 = MathHelper.clamp(var27.readInt(), -(44 ^ 12), 231 ^ 199);
                           I[264 + 324 - 140 + 364].length();
                           var7.setPosition(new BlockPos(var10, var11, var12));
                           int var13 = MathHelper.clamp(var27.readInt(), "".length(), 39 ^ 7);
                           int var14 = MathHelper.clamp(var27.readInt(), "".length(), 78 ^ 110);
                           int var15 = MathHelper.clamp(var27.readInt(), "".length(), 28 ^ 60);
                           I[319 + 238 - -181 + 75].length();
                           I[322 + 611 - 221 + 102].length();
                           var7.setSize(new BlockPos(var13, var14, var15));
                           String var16 = var27.readStringFromBuffer(167 ^ 135);
                           var7.setMirror(Mirror.valueOf(var16));
                           String var17 = var27.readStringFromBuffer(88 ^ 120);
                           var7.setRotation(Rotation.valueOf(var17));
                           var7.setMetadata(var27.readStringFromBuffer(24 + 22 - -54 + 28));
                           var7.setIgnoresEntities(var27.readBoolean());
                           var7.setShowAir(var27.readBoolean());
                           var7.setShowBoundingBox(var27.readBoolean());
                           var7.setIntegrity(MathHelper.clamp(var27.readFloat(), 0.0F, 1.0F));
                           var7.setSeed(var27.readVarLong());
                           String var18 = var7.getName();
                           if (var8 == "  ".length()) {
                              if (var7.save()) {
                                 var60 = this.playerEntity;
                                 I[168 + 583 - 458 + 522].length();
                                 I[684 + 733 - 1227 + 626].length();
                                 var10003 = I[394 + 590 - 535 + 368];
                                 var10004 = new Object[" ".length()];
                                 I[91 + 747 - 768 + 748].length();
                                 I[41 + 801 - 837 + 814].length();
                                 var10004["".length()] = var18;
                                 var60.addChatComponentMessage(new TextComponentTranslation(var10003, var10004), (boolean)"".length());
                                 "".length();
                                 if (-1 != -1) {
                                    throw null;
                                 }
                              } else {
                                 var60 = this.playerEntity;
                                 I[202 + 157 - 121 + 582].length();
                                 I[163 + 114 - -544 + 0].length();
                                 I[87 + 788 - 459 + 406].length();
                                 var10003 = I[100 + 136 - 233 + 820];
                                 var10004 = new Object[" ".length()];
                                 I[607 + 369 - 493 + 341].length();
                                 var10004["".length()] = var18;
                                 var60.addChatComponentMessage(new TextComponentTranslation(var10003, var10004), (boolean)"".length());
                                 "".length();
                                 if (0 >= 2) {
                                    throw null;
                                 }
                              }
                           } else if (var8 == "   ".length()) {
                              if (!var7.isStructureLoadable()) {
                                 var60 = this.playerEntity;
                                 I[205 + 112 - -429 + 79].length();
                                 var10003 = I[753 + 490 - 491 + 74];
                                 var10004 = new Object[" ".length()];
                                 I[48 + 272 - -134 + 373].length();
                                 I[322 + 325 - 620 + 801].length();
                                 I[401 + 797 - 988 + 619].length();
                                 var10004["".length()] = var18;
                                 var60.addChatComponentMessage(new TextComponentTranslation(var10003, var10004), (boolean)"".length());
                                 "".length();
                                 if (4 <= -1) {
                                    throw null;
                                 }
                              } else if (var7.load()) {
                                 var60 = this.playerEntity;
                                 I[194 + 688 - 559 + 507].length();
                                 I[108 + 1 - -216 + 506].length();
                                 var10003 = I[415 + 778 - 943 + 582];
                                 var10004 = new Object[" ".length()];
                                 I[460 + 445 - 366 + 294].length();
                                 I[239 + 28 - -369 + 198].length();
                                 var10004["".length()] = var18;
                                 var60.addChatComponentMessage(new TextComponentTranslation(var10003, var10004), (boolean)"".length());
                                 "".length();
                                 if (4 != 4) {
                                    throw null;
                                 }
                              } else {
                                 var60 = this.playerEntity;
                                 I[257 + 543 - 659 + 694].length();
                                 I[501 + 502 - 450 + 283].length();
                                 I[303 + 595 - 780 + 719].length();
                                 var10003 = I[670 + 234 - 897 + 831];
                                 var10004 = new Object[" ".length()];
                                 I[608 + 21 - 361 + 571].length();
                                 var10004["".length()] = var18;
                                 var60.addChatComponentMessage(new TextComponentTranslation(var10003, var10004), (boolean)"".length());
                                 "".length();
                                 if (1 <= 0) {
                                    throw null;
                                 }
                              }
                           } else if (var8 == (190 ^ 186)) {
                              if (var7.detectSize()) {
                                 var60 = this.playerEntity;
                                 I[808 + 46 - 691 + 677].length();
                                 I[795 + 540 - 965 + 471].length();
                                 var10003 = I[775 + 601 - 879 + 345];
                                 var10004 = new Object[" ".length()];
                                 I[515 + 281 - 530 + 577].length();
                                 I[73 + 842 - 530 + 459].length();
                                 var10004["".length()] = var18;
                                 var60.addChatComponentMessage(new TextComponentTranslation(var10003, var10004), (boolean)"".length());
                                 "".length();
                                 if (false) {
                                    throw null;
                                 }
                              } else {
                                 var60 = this.playerEntity;
                                 I[222 + 641 - 335 + 317].length();
                                 var60.addChatComponentMessage(new TextComponentTranslation(I[147 + 774 - 841 + 766], new Object["".length()]), (boolean)"".length());
                              }
                           }

                           var7.markDirty();
                           this.playerEntity.world.notifyBlockUpdate(var28, var5, var5, "   ".length());
                        }
                     } catch (Exception var21) {
                        LOGGER.error(I[134 + 181 - -72 + 460], var21);
                        break label256;
                     }

                     "".length();
                     if (3 < -1) {
                        throw null;
                     }
                  }

                  "".length();
                  if (4 < 2) {
                     throw null;
                  }
               } else if (I[735 + 15 - -50 + 48].equals(var2)) {
                  var27 = var1.getBufferData();

                  try {
                     var29 = var27.readVarIntFromBuffer();
                     this.playerEntity.inventory.pickItem(var29);
                     NetHandlerPlayServer var61 = this.playerEntity.connection;
                     I[766 + 255 - 544 + 372].length();
                     I[72 + 461 - 326 + 643].length();
                     I[467 + 264 - 618 + 738].length();
                     var61.sendPacket(new SPacketSetSlot(-"  ".length(), this.playerEntity.inventory.currentItem, this.playerEntity.inventory.getStackInSlot(this.playerEntity.inventory.currentItem)));
                     var61 = this.playerEntity.connection;
                     I[840 + 810 - 1602 + 804].length();
                     I[217 + 408 - -145 + 83].length();
                     var61.sendPacket(new SPacketSetSlot(-"  ".length(), var29, this.playerEntity.inventory.getStackInSlot(var29)));
                     var61 = this.playerEntity.connection;
                     I[808 + 482 - 996 + 560].length();
                     I[258 + 492 - 377 + 482].length();
                     I[340 + 600 - 737 + 653].length();
                     I[490 + 266 - 267 + 368].length();
                     var61.sendPacket(new SPacketHeldItemChange(this.playerEntity.inventory.currentItem));
                  } catch (Exception var22) {
                     LOGGER.error(I[72 + 185 - -140 + 461], var22);
                     return;
                  }

                  "".length();
                  if (1 >= 4) {
                     throw null;
                  }
               }
            }
         }
      }

   }

   public void processCloseWindow(CPacketCloseWindow var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.closeContainer();
   }

   public void processClientSettings(CPacketClientSettings var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.handleClientSettings(var1);
   }

   public void processEntityAction(CPacketEntityAction var1) {
      String var10000 = I[162 + 436 - 524 + 372];
      String var10001 = I[151 + 46 - 87 + 337];
      String var10002 = I[408 + 347 - 581 + 274];
      var10001 = I[300 + 242 - 249 + 156];
      var10000 = I[37 + 388 - 394 + 419];
      var10001 = I[249 + 268 - 89 + 23];
      var10002 = I[163 + 383 - 113 + 19];
      var10001 = I[261 + 69 - -29 + 94];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.markPlayerActive();
      IJumpingMount var4;
      switch(null.$SwitchMap$net$minecraft$network$play$client$CPacketEntityAction$Action[var1.getAction().ordinal()]) {
      case 1:
         this.playerEntity.setSneaking((boolean)" ".length());
         "".length();
         if (2 >= 4) {
            throw null;
         }
         break;
      case 2:
         this.playerEntity.setSneaking((boolean)"".length());
         "".length();
         if (1 < -1) {
            throw null;
         }
         break;
      case 3:
         this.playerEntity.setSprinting((boolean)" ".length());
         "".length();
         if (4 < 0) {
            throw null;
         }
         break;
      case 4:
         this.playerEntity.setSprinting((boolean)"".length());
         "".length();
         if (2 == 0) {
            throw null;
         }
         break;
      case 5:
         if (this.playerEntity.isPlayerSleeping()) {
            this.playerEntity.wakeUpPlayer((boolean)"".length(), (boolean)" ".length(), (boolean)" ".length());
            I[323 + 190 - 278 + 219].length();
            this.targetPos = new Vec3d(this.playerEntity.posX, this.playerEntity.posY, this.playerEntity.posZ);
            "".length();
            if (-1 == 1) {
               throw null;
            }
         }
         break;
      case 6:
         if (this.playerEntity.getRidingEntity() instanceof IJumpingMount) {
            var4 = (IJumpingMount)this.playerEntity.getRidingEntity();
            int var3 = var1.getAuxData();
            if (var4.canJump() && var3 > 0) {
               var4.handleStartJump(var3);
            }

            "".length();
            if (4 != 4) {
               throw null;
            }
         }
         break;
      case 7:
         if (this.playerEntity.getRidingEntity() instanceof IJumpingMount) {
            var4 = (IJumpingMount)this.playerEntity.getRidingEntity();
            var4.handleStopJump();
            "".length();
            if (1 < -1) {
               throw null;
            }
         }
         break;
      case 8:
         if (this.playerEntity.getRidingEntity() instanceof AbstractHorse) {
            ((AbstractHorse)this.playerEntity.getRidingEntity()).openGUI(this.playerEntity);
            "".length();
            if (3 >= 4) {
               throw null;
            }
         }
         break;
      case 9:
         if (!this.playerEntity.onGround && this.playerEntity.motionY < 0.0D && !this.playerEntity.isElytraFlying() && !this.playerEntity.isInWater()) {
            ItemStack var2 = this.playerEntity.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
            if (var2.getItem() == Items.ELYTRA && ItemElytra.isBroken(var2)) {
               this.playerEntity.setElytraFlying();
            }

            "".length();
            if (0 == 3) {
               throw null;
            }
         } else {
            this.playerEntity.clearElytraFlying();
            "".length();
            if (3 <= 1) {
               throw null;
            }
         }
         break;
      default:
         I[134 + 299 - 219 + 241].length();
         I[334 + 243 - 296 + 175].length();
         IllegalArgumentException var5 = new IllegalArgumentException(I[97 + 182 - 2 + 180]);
         I[424 + 34 - 105 + 105].length();
         I[189 + 62 - 192 + 400].length();
         throw var5;
      }

   }

   public void processPlayer(CPacketPlayer var1) {
      String var10000 = I[121 + 23 - 100 + 113];
      String var10001 = I[90 + 96 - 135 + 107];
      String var10002 = I[28 + 77 - -36 + 18];
      var10001 = I[121 + 132 - 223 + 130];
      var10000 = I[133 + 22 - -1 + 5];
      var10001 = I[124 + 104 - 90 + 24];
      var10002 = I[35 + 150 - 63 + 41];
      var10001 = I[132 + 117 - 237 + 152];
      var10000 = I[46 + 113 - 34 + 40];
      var10001 = I[143 + 79 - 177 + 121];
      var10002 = I[147 + 154 - 135 + 1];
      var10001 = I[87 + 63 - -16 + 2];
      var10000 = I[67 + 111 - 113 + 104];
      var10001 = I[69 + 75 - -26 + 0];
      var10002 = I[107 + 47 - 90 + 107];
      var10001 = I[69 + 50 - 32 + 85];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      if (isMovePlayerPacketInvalid(var1)) {
         I[167 + 70 - 122 + 58].length();
         I[113 + 164 - 228 + 125].length();
         this.func_194028_b(new TextComponentTranslation(I[34 + 43 - -72 + 26], new Object["".length()]));
         "".length();
         if (1 < 0) {
            throw null;
         }
      } else {
         WorldServer var2 = this.serverController.getWorld(this.playerEntity.dimension);
         if (!this.playerEntity.playerConqueredTheEnd) {
            if (this.networkTickCount == 0) {
               this.captureCurrentPosition();
            }

            int var36;
            int var42;
            if (this.targetPos != null) {
               var36 = this.networkTickCount;
               var42 = this.lastPositionUpdate;
               I[31 + 87 - 45 + 103].length();
               if (var36 - var42 > (130 ^ 150)) {
                  this.lastPositionUpdate = this.networkTickCount;
                  this.setPlayerLocation(this.targetPos.x, this.targetPos.y, this.targetPos.z, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
                  "".length();
                  if (false) {
                     throw null;
                  }
               }
            } else {
               this.lastPositionUpdate = this.networkTickCount;
               if (this.playerEntity.isRiding()) {
                  this.playerEntity.setPositionAndRotation(this.playerEntity.posX, this.playerEntity.posY, this.playerEntity.posZ, var1.getYaw(this.playerEntity.rotationYaw), var1.getPitch(this.playerEntity.rotationPitch));
                  this.serverController.getPlayerList().serverUpdateMovingPlayer(this.playerEntity);
                  "".length();
                  if (1 <= 0) {
                     throw null;
                  }
               } else {
                  double var3 = this.playerEntity.posX;
                  double var5 = this.playerEntity.posY;
                  double var7 = this.playerEntity.posZ;
                  double var9 = this.playerEntity.posY;
                  double var11 = var1.getX(this.playerEntity.posX);
                  double var13 = var1.getY(this.playerEntity.posY);
                  double var15 = var1.getZ(this.playerEntity.posZ);
                  float var17 = var1.getYaw(this.playerEntity.rotationYaw);
                  float var18 = var1.getPitch(this.playerEntity.rotationPitch);
                  double var40 = this.firstGoodX;
                  I[128 + 144 - 138 + 43].length();
                  I[50 + 70 - -54 + 4].length();
                  double var19 = var11 - var40;
                  var40 = this.firstGoodY;
                  I[76 + 151 - 158 + 110].length();
                  I[52 + 55 - -67 + 6].length();
                  I[25 + 57 - 17 + 116].length();
                  I[77 + 181 - 96 + 20].length();
                  double var21 = var13 - var40;
                  var40 = this.firstGoodZ;
                  I[94 + 5 - 83 + 167].length();
                  I[172 + 63 - 54 + 3].length();
                  I[166 + 184 - 182 + 17].length();
                  I[111 + 43 - 6 + 38].length();
                  double var23 = var15 - var40;
                  double var25 = this.playerEntity.motionX * this.playerEntity.motionX + this.playerEntity.motionY * this.playerEntity.motionY + this.playerEntity.motionZ * this.playerEntity.motionZ;
                  double var27 = var19 * var19 + var21 * var21 + var23 * var23;
                  if (this.playerEntity.isPlayerSleeping()) {
                     if (var27 > 1.0D) {
                        this.setPlayerLocation(this.playerEntity.posX, this.playerEntity.posY, this.playerEntity.posZ, var1.getYaw(this.playerEntity.rotationYaw), var1.getPitch(this.playerEntity.rotationPitch));
                        "".length();
                        if (4 < -1) {
                           throw null;
                        }
                     }
                  } else {
                     I[177 + 69 - 241 + 182].length();
                     this.movePacketCounter += " ".length();
                     var36 = this.movePacketCounter;
                     var42 = this.lastMovePacketCounter;
                     I[183 + 177 - 346 + 174].length();
                     I[170 + 78 - 60 + 1].length();
                     I[22 + 130 - 127 + 165].length();
                     int var29 = var36 - var42;
                     if (var29 > (126 ^ 123)) {
                        LOGGER.debug(I[74 + 95 - 18 + 40], this.playerEntity.getName(), var29);
                        var29 = " ".length();
                     }

                     if (!this.playerEntity.isInvulnerableDimensionChange() && (!this.playerEntity.getServerWorld().getGameRules().getBoolean(I[53 + 160 - 78 + 57]) || !this.playerEntity.isElytraFlying())) {
                        float var37;
                        if (this.playerEntity.isElytraFlying()) {
                           var37 = 300.0F;
                           "".length();
                           if (-1 >= 3) {
                              throw null;
                           }
                        } else {
                           var37 = 100.0F;
                        }

                        float var30 = var37;
                        I[122 + 136 - 187 + 122].length();
                        I[177 + 65 - 233 + 185].length();
                        if (var27 - var25 > (double)(var30 * (float)var29) && (!this.serverController.isSinglePlayer() || !this.serverController.getServerOwner().equals(this.playerEntity.getName()))) {
                           LOGGER.warn(I[101 + 3 - -10 + 81], this.playerEntity.getName(), var19, var21, var23);
                           this.setPlayerLocation(this.playerEntity.posX, this.playerEntity.posY, this.playerEntity.posZ, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
                           return;
                        }
                     }

                     boolean var35 = var2.getCollisionBoxes(this.playerEntity, this.playerEntity.getEntityBoundingBox().contract(0.0625D)).isEmpty();
                     var40 = this.lastGoodX;
                     I[56 + 102 - 20 + 58].length();
                     I[76 + 46 - -33 + 42].length();
                     I[163 + 65 - 217 + 187].length();
                     var19 = var11 - var40;
                     var40 = this.lastGoodY;
                     I[126 + 40 - -12 + 21].length();
                     I[19 + 122 - -38 + 21].length();
                     I[127 + 78 - 203 + 199].length();
                     I[181 + 10 - 189 + 200].length();
                     var21 = var13 - var40;
                     var40 = this.lastGoodZ;
                     I[189 + 170 - 217 + 61].length();
                     I[50 + 33 - -94 + 27].length();
                     I[168 + 85 - 202 + 154].length();
                     I[148 + 35 - 68 + 91].length();
                     var23 = var15 - var40;
                     if (this.playerEntity.onGround && !var1.isOnGround() && var21 > 0.0D) {
                        this.playerEntity.jump();
                     }

                     this.playerEntity.moveEntity(MoverType.PLAYER, var19, var21, var23);
                     this.playerEntity.onGround = var1.isOnGround();
                     double var31 = var21;
                     var40 = this.playerEntity.posX;
                     I[166 + 83 - 43 + 1].length();
                     I[175 + 154 - 289 + 168].length();
                     var19 = var11 - var40;
                     var40 = this.playerEntity.posY;
                     I[173 + 91 - 63 + 8].length();
                     var21 = var13 - var40;
                     if (var21 > -0.5D || var21 < 0.5D) {
                        var21 = 0.0D;
                     }

                     var40 = this.playerEntity.posZ;
                     I[197 + 58 - 251 + 206].length();
                     I[38 + 71 - -12 + 90].length();
                     I[203 + 85 - 222 + 146].length();
                     I[115 + 2 - -18 + 78].length();
                     var23 = var15 - var40;
                     var27 = var19 * var19 + var21 * var21 + var23 * var23;
                     int var33 = "".length();
                     if (!this.playerEntity.isInvulnerableDimensionChange() && var27 > 0.0625D && !this.playerEntity.isPlayerSleeping() && !this.playerEntity.interactionManager.isCreative() && this.playerEntity.interactionManager.getGameType() != GameType.SPECTATOR) {
                        var33 = " ".length();
                        LOGGER.warn(I[5 + 7 - -184 + 18], this.playerEntity.getName());
                     }

                     this.playerEntity.setPositionAndRotation(var11, var13, var15, var17, var18);
                     EntityPlayerMP var38 = this.playerEntity;
                     var40 = this.playerEntity.posX;
                     I[140 + 78 - 28 + 25].length();
                     I[105 + 2 - 76 + 185].length();
                     I[94 + 96 - 125 + 152].length();
                     I[124 + 64 - -28 + 2].length();
                     var40 -= var3;
                     double var39 = this.playerEntity.posY;
                     I[168 + 172 - 151 + 30].length();
                     I[63 + 15 - 73 + 215].length();
                     I[197 + 34 - 24 + 14].length();
                     var39 -= var5;
                     double var10003 = this.playerEntity.posZ;
                     I[150 + 119 - 115 + 68].length();
                     I[170 + 62 - 164 + 155].length();
                     var38.addMovementStat(var40, var39, var10003 - var7);
                     if (!this.playerEntity.noClip && !this.playerEntity.isPlayerSleeping()) {
                        boolean var34 = var2.getCollisionBoxes(this.playerEntity, this.playerEntity.getEntityBoundingBox().contract(0.0625D)).isEmpty();
                        if (var35 && (var33 != 0 || !var34)) {
                           this.setPlayerLocation(var3, var5, var7, var17, var18);
                           return;
                        }
                     }

                     if (var31 >= -0.03125D) {
                        var42 = " ".length();
                        "".length();
                        if (4 == 0) {
                           throw null;
                        }
                     } else {
                        var42 = "".length();
                     }

                     this.floating = (boolean)var42;
                     I[89 + 72 - 22 + 85].length();
                     I[73 + 18 - 20 + 154].length();
                     I[211 + 51 - 141 + 105].length();
                     I[69 + 145 - 114 + 127].length();
                     byte var43 = this.floating;
                     int var41;
                     if (!this.serverController.isFlightAllowed() && !this.playerEntity.capabilities.allowFlying) {
                        var41 = " ".length();
                        "".length();
                        if (3 != 3) {
                           throw null;
                        }
                     } else {
                        var41 = "".length();
                     }

                     this.floating = (boolean)(var43 & var41);
                     I[180 + 194 - 154 + 8].length();
                     I[214 + 149 - 288 + 154].length();
                     I[30 + 211 - 180 + 169].length();
                     var43 = this.floating;
                     if (!this.playerEntity.isPotionActive(MobEffects.LEVITATION) && !this.playerEntity.isElytraFlying() && !var2.checkBlockCollision(this.playerEntity.getEntityBoundingBox().expandXyz(0.0625D).addCoord(0.0D, -0.55D, 0.0D))) {
                        var41 = " ".length();
                        "".length();
                        if (3 == 2) {
                           throw null;
                        }
                     } else {
                        var41 = "".length();
                     }

                     this.floating = (boolean)(var43 & var41);
                     this.playerEntity.onGround = var1.isOnGround();
                     this.serverController.getPlayerList().serverUpdateMovingPlayer(this.playerEntity);
                     var38 = this.playerEntity;
                     var40 = this.playerEntity.posY;
                     I[199 + 182 - 275 + 125].length();
                     I[132 + 171 - 110 + 39].length();
                     I[209 + 128 - 262 + 158].length();
                     I[37 + 67 - 86 + 216].length();
                     I[209 + 108 - 111 + 29].length();
                     var38.handleFalling(var40 - var9, var1.isOnGround());
                     this.lastGoodX = this.playerEntity.posX;
                     this.lastGoodY = this.playerEntity.posY;
                     this.lastGoodZ = this.playerEntity.posZ;
                  }
               }
            }
         }
      }

   }

   public void func_194027_a(CPacketSeenAdvancements var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      if (var1.func_194162_b() == CPacketSeenAdvancements.Action.OPENED_TAB) {
         ResourceLocation var2 = var1.func_194165_c();
         Advancement var3 = this.serverController.func_191949_aK().func_192778_a(var2);
         if (var3 != null) {
            this.playerEntity.func_192039_O().func_194220_a(var3);
         }
      }

   }

   public void processClientStatus(CPacketClientStatus var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      this.playerEntity.markPlayerActive();
      CPacketClientStatus.State var2 = var1.getStatus();
      switch(null.$SwitchMap$net$minecraft$network$play$client$CPacketClientStatus$State[var2.ordinal()]) {
      case 1:
         if (this.playerEntity.playerConqueredTheEnd) {
            this.playerEntity.playerConqueredTheEnd = (boolean)"".length();
            this.playerEntity = this.serverController.getPlayerList().recreatePlayerEntity(this.playerEntity, "".length(), (boolean)" ".length());
            CriteriaTriggers.field_193134_u.func_193143_a(this.playerEntity, DimensionType.THE_END, DimensionType.OVERWORLD);
            "".length();
            if (1 >= 4) {
               throw null;
            }
         } else {
            if (this.playerEntity.getHealth() > 0.0F) {
               return;
            }

            this.playerEntity = this.serverController.getPlayerList().recreatePlayerEntity(this.playerEntity, "".length(), (boolean)"".length());
            if (this.serverController.isHardcore()) {
               this.playerEntity.setGameType(GameType.SPECTATOR);
               this.playerEntity.getServerWorld().getGameRules().setOrCreateGameRule(I[267 + 229 - 474 + 462], I[126 + 9 - -163 + 187]);
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            }
         }
         break;
      case 2:
         this.playerEntity.getStatFile().sendStats(this.playerEntity);
      }

   }

   public void setPlayerLocation(double var1, double var3, double var5, float var7, float var8) {
      this.setPlayerLocation(var1, var3, var5, var7, var8, Collections.emptySet());
   }

   public void processRightClickBlock(CPacketPlayerTryUseItemOnBlock var1) {
      String var10000 = I[79 + 225 - 210 + 205];
      String var10001 = I[91 + 153 - 60 + 116];
      String var10002 = I[47 + 253 - 143 + 144];
      var10001 = I[148 + 232 - 291 + 213];
      var10000 = I[277 + 277 - 402 + 151];
      var10001 = I[96 + 58 - -33 + 117];
      var10002 = I[278 + 185 - 275 + 117];
      var10001 = I[239 + 35 - 190 + 222];
      var10000 = I[230 + 172 - 348 + 253];
      var10001 = I[121 + 100 - 169 + 256];
      var10002 = I[2 + 184 - 180 + 303];
      var10001 = I[284 + 39 - 295 + 282];
      var10000 = I[204 + 173 - 129 + 63];
      var10001 = I[158 + 183 - 124 + 95];
      var10002 = I[115 + 23 - 2 + 177];
      var10001 = I[69 + 115 - 21 + 151];
      var10000 = I[104 + 58 - 124 + 277];
      var10001 = I[107 + 211 - 92 + 90];
      var10002 = I[316 + 47 - 161 + 115];
      var10001 = I[279 + 162 - 162 + 39];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      WorldServer var2 = this.serverController.getWorld(this.playerEntity.dimension);
      EnumHand var3 = var1.getHand();
      ItemStack var4 = this.playerEntity.getHeldItem(var3);
      BlockPos var5 = var1.getPos();
      EnumFacing var6 = var1.getDirection();
      this.playerEntity.markPlayerActive();
      int var8 = var5.getY();
      int var11 = this.serverController.getBuildLimit();
      int var10 = " ".length();
      I[189 + 236 - 221 + 115].length();
      NetHandlerPlayServer var9;
      if (var8 >= var11 - var10 && (var6 == EnumFacing.UP || var5.getY() >= this.serverController.getBuildLimit())) {
         I[67 + 293 - 226 + 187].length();
         I[74 + 74 - 95 + 269].length();
         var10002 = I[246 + 68 - 73 + 82];
         Object[] var10003 = new Object[" ".length()];
         I[54 + 44 - -92 + 134].length();
         var10003["".length()] = this.serverController.getBuildLimit();
         TextComponentTranslation var7 = new TextComponentTranslation(var10002, var10003);
         var7.getStyle().setColor(TextFormatting.RED);
         I[38 + 285 - 95 + 97].length();
         I[81 + 180 - 195 + 260].length();
         I[305 + 191 - 440 + 271].length();
         var9 = this.playerEntity.connection;
         I[283 + 150 - 244 + 139].length();
         I[195 + 229 - 194 + 99].length();
         var9.sendPacket(new SPacketChat(var7, ChatType.GAME_INFO));
      } else if (this.targetPos == null && this.playerEntity.getDistanceSq((double)var5.getX() + 0.5D, (double)var5.getY() + 0.5D, (double)var5.getZ() + 0.5D) < 64.0D && !this.serverController.isBlockProtected(var2, var5, this.playerEntity) && var2.getWorldBorder().contains(var5)) {
         this.playerEntity.interactionManager.processRightClickBlock(this.playerEntity, var2, var4, var3, var5, var6, var1.getFacingX(), var1.getFacingY(), var1.getFacingZ());
         I[114 + 279 - 127 + 54].length();
         "".length();
         if (4 < 3) {
            throw null;
         }
      }

      var9 = this.playerEntity.connection;
      I[10 + 113 - -48 + 159].length();
      I[16 + 30 - -79 + 206].length();
      var9.sendPacket(new SPacketBlockChange(var2, var5));
      var9 = this.playerEntity.connection;
      I[317 + 14 - 84 + 85].length();
      I[64 + 191 - 66 + 144].length();
      I[185 + 158 - 21 + 12].length();
      var9.sendPacket(new SPacketBlockChange(var2, var5.offset(var6)));
   }

   public void update() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[50 ^ 54];
      var10001 = I[128 ^ 133];
      var10002 = I[188 ^ 186];
      var10001 = I[152 ^ 159];
      var10000 = I[163 ^ 171];
      var10001 = I[130 ^ 139];
      var10002 = I[123 ^ 113];
      var10001 = I[31 ^ 20];
      var10000 = I[2 ^ 14];
      var10001 = I[84 ^ 89];
      var10002 = I[108 ^ 98];
      var10001 = I[161 ^ 174];
      var10000 = I[133 ^ 149];
      var10001 = I[66 ^ 83];
      var10002 = I[66 ^ 80];
      var10001 = I[178 ^ 161];
      var10000 = I[81 ^ 69];
      var10001 = I[46 ^ 59];
      var10002 = I[94 ^ 72];
      var10001 = I[67 ^ 84];
      var10000 = I[85 ^ 77];
      var10001 = I[34 ^ 59];
      var10002 = I[101 ^ 127];
      var10001 = I[23 ^ 12];
      var10000 = I[160 ^ 188];
      var10001 = I[139 ^ 150];
      var10002 = I[105 ^ 119];
      var10001 = I[130 ^ 157];
      var10000 = I[87 ^ 119];
      var10001 = I[181 ^ 148];
      var10002 = I[124 ^ 94];
      var10001 = I[49 ^ 18];
      var10000 = I[76 ^ 104];
      var10001 = I[89 ^ 124];
      var10002 = I[82 ^ 116];
      var10001 = I[154 ^ 189];
      this.captureCurrentPosition();
      this.playerEntity.onUpdateEntity();
      this.playerEntity.setPositionAndRotation(this.firstGoodX, this.firstGoodY, this.firstGoodZ, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
      I[53 ^ 29].length();
      I[173 ^ 132].length();
      this.networkTickCount += " ".length();
      this.lastMovePacketCounter = this.movePacketCounter;
      if (this.floating) {
         I[124 ^ 86].length();
         I[0 ^ 43].length();
         I[32 ^ 12].length();
         if ((this.floatingTickCount += " ".length()) > (251 ^ 171)) {
            LOGGER.warn(I[113 ^ 92], this.playerEntity.getName());
            I[153 ^ 183].length();
            I[86 ^ 121].length();
            this.func_194028_b(new TextComponentTranslation(I[144 ^ 160], new Object["".length()]));
            return;
         }
      } else {
         this.floating = (boolean)"".length();
         this.floatingTickCount = "".length();
      }

      this.lowestRiddenEnt = this.playerEntity.getLowestRidingEntity();
      if (this.lowestRiddenEnt != this.playerEntity && this.lowestRiddenEnt.getControllingPassenger() == this.playerEntity) {
         this.lowestRiddenX = this.lowestRiddenEnt.posX;
         this.lowestRiddenY = this.lowestRiddenEnt.posY;
         this.lowestRiddenZ = this.lowestRiddenEnt.posZ;
         this.lowestRiddenX1 = this.lowestRiddenEnt.posX;
         this.lowestRiddenY1 = this.lowestRiddenEnt.posY;
         this.lowestRiddenZ1 = this.lowestRiddenEnt.posZ;
         if (this.vehicleFloating && this.playerEntity.getLowestRidingEntity().getControllingPassenger() == this.playerEntity) {
            I[130 ^ 179].length();
            I[92 ^ 110].length();
            I[63 ^ 12].length();
            if ((this.vehicleFloatingTickCount += " ".length()) > (52 ^ 100)) {
               LOGGER.warn(I[91 ^ 111], this.playerEntity.getName());
               I[135 ^ 178].length();
               I[52 ^ 2].length();
               I[157 ^ 170].length();
               this.func_194028_b(new TextComponentTranslation(I[177 ^ 137], new Object["".length()]));
               return;
            }
         } else {
            this.vehicleFloating = (boolean)"".length();
            this.vehicleFloatingTickCount = "".length();
            "".length();
            if (2 == 0) {
               throw null;
            }
         }
      } else {
         this.lowestRiddenEnt = null;
         this.vehicleFloating = (boolean)"".length();
         this.vehicleFloatingTickCount = "".length();
      }

      this.serverController.theProfiler.startSection(I[249 ^ 192]);
      long var1 = this.currentTimeMillis();
      if (var1 - this.field_194402_f >= 15000L) {
         if (this.field_194403_g) {
            I[84 ^ 110].length();
            this.func_194028_b(new TextComponentTranslation(I[133 ^ 190], new Object["".length()]));
            "".length();
            if (2 <= 1) {
               throw null;
            }
         } else {
            this.field_194403_g = (boolean)" ".length();
            this.field_194402_f = var1;
            this.field_194404_h = var1;
            I[37 ^ 25].length();
            I[96 ^ 93].length();
            I[77 ^ 115].length();
            this.sendPacket(new SPacketKeepAlive(this.field_194404_h));
         }
      }

      this.serverController.theProfiler.endSection();
      int var3;
      int var4;
      if (this.chatSpamThresholdCount > 0) {
         I[180 ^ 139].length();
         I[41 ^ 105].length();
         var4 = this.chatSpamThresholdCount;
         var3 = " ".length();
         I[108 ^ 45].length();
         I[66 ^ 0].length();
         I[76 ^ 15].length();
         this.chatSpamThresholdCount = var4 - var3;
      }

      if (this.itemDropThreshold > 0) {
         I[105 ^ 45].length();
         I[89 ^ 28].length();
         I[31 ^ 89].length();
         var4 = this.itemDropThreshold;
         var3 = " ".length();
         I[30 ^ 89].length();
         I[82 ^ 26].length();
         I[60 ^ 117].length();
         I[229 ^ 175].length();
         this.itemDropThreshold = var4 - var3;
      }

      if (this.playerEntity.getLastActiveTime() > 0L && this.serverController.getMaxPlayerIdleMinutes() > 0 && MinecraftServer.getCurrentTimeMillis() - this.playerEntity.getLastActiveTime() > (long)(this.serverController.getMaxPlayerIdleMinutes() * (171 + 74 - -476 + 279) * (111 ^ 83))) {
         I[121 ^ 50].length();
         I[109 ^ 33].length();
         I[93 ^ 16].length();
         I[250 ^ 180].length();
         this.func_194028_b(new TextComponentTranslation(I[69 ^ 10], new Object["".length()]));
      }

   }

   public void processConfirmTransaction(CPacketConfirmTransaction var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      Short var2 = (Short)this.pendingTransactions.lookup(this.playerEntity.openContainer.windowId);
      if (var2 != null && var1.getUid() == var2 && this.playerEntity.openContainer.windowId == var1.getWindowId() && !this.playerEntity.openContainer.getCanCraft(this.playerEntity) && !this.playerEntity.isSpectator()) {
         this.playerEntity.openContainer.setCanCraft(this.playerEntity, (boolean)" ".length());
      }

   }

   public void processPlayerAbilities(CPacketPlayerAbilities var1) {
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      PlayerCapabilities var10000 = this.playerEntity.capabilities;
      int var10001;
      if (var1.isFlying() && this.playerEntity.capabilities.allowFlying) {
         var10001 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      var10000.isFlying = (boolean)var10001;
   }

   public void processTabComplete(CPacketTabComplete var1) {
      String var10000 = I[561 + 420 - 451 + 32];
      String var10001 = I[406 + 360 - 377 + 174];
      String var10002 = I[319 + 561 - 659 + 343];
      var10001 = I[108 + 542 - 481 + 396];
      PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerWorld());
      ArrayList var2 = Lists.newArrayList();
      Iterator var3 = this.serverController.getTabCompletions(this.playerEntity, var1.getMessage(), var1.getTargetBlock(), var1.hasTargetBlock()).iterator();

      do {
         if (!var3.hasNext()) {
            NetHandlerPlayServer var5 = this.playerEntity.connection;
            I[189 + 243 - 358 + 495].length();
            I[272 + 13 - 112 + 397].length();
            I[9 + 523 - 51 + 90].length();
            I[58 + 530 - 235 + 219].length();
            var5.sendPacket(new SPacketTabComplete((String[])((String[])var2.toArray(new String[var2.size()]))));
            return;
         }

         String var4 = (String)var3.next();
         var2.add(var4);
         I[521 + 195 - 701 + 551].length();
         I[320 + 79 - 50 + 218].length();
         I[67 + 331 - 297 + 467].length();
         "".length();
      } while(4 >= 4);

      throw null;
   }

   public NetworkManager getNetworkManager() {
      return this.netManager;
   }
}

package net.minecraft.advancements;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import net.minecraft.util.ResourceLocation;

public interface ICriterionTrigger<T extends ICriterionInstance> {
   void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<T> var2);

   ResourceLocation func_192163_a();

   void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<T> var2);

   T func_192166_a(JsonObject var1, JsonDeserializationContext var2);

   void func_192167_a(PlayerAdvancements var1);

   public static class Listener<T extends ICriterionInstance> {
      // $FF: synthetic field
      private final String field_192162_c;
      // $FF: synthetic field
      private final T field_192160_a;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Advancement field_192161_b;

      public Listener(T var1, Advancement var2, String var3) {
         this.field_192160_a = var1;
         this.field_192161_b = var2;
         this.field_192162_c = var3;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 >= 0);

         throw null;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I("别", "Nficw");
         I[" ".length()] = I("嚭宣厤枲", "tfHhP");
      }

      public boolean equals(Object var1) {
         if (this == var1) {
            return (boolean)" ".length();
         } else if (var1 != null && this.getClass() == var1.getClass()) {
            ICriterionTrigger.Listener var2 = (ICriterionTrigger.Listener)var1;
            if (!this.field_192160_a.equals(var2.field_192160_a)) {
               return (boolean)"".length();
            } else {
               int var10000;
               if (!this.field_192161_b.equals(var2.field_192161_b)) {
                  var10000 = "".length();
                  "".length();
                  if (-1 >= 4) {
                     throw null;
                  }
               } else {
                  var10000 = this.field_192162_c.equals(var2.field_192162_c);
               }

               return (boolean)var10000;
            }
         } else {
            return (boolean)"".length();
         }
      }

      static {
         I();
      }

      public void func_192159_a(PlayerAdvancements var1) {
         var1.func_192750_a(this.field_192161_b, this.field_192162_c);
         I["".length()].length();
         I[" ".length()].length();
      }

      public int hashCode() {
         int var1 = this.field_192160_a.hashCode();
         var1 = (137 ^ 150) * var1 + this.field_192161_b.hashCode();
         var1 = (107 ^ 116) * var1 + this.field_192162_c.hashCode();
         return var1;
      }

      public T func_192158_a() {
         return this.field_192160_a;
      }
   }
}

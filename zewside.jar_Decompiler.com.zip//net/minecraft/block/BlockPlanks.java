package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockPlanks extends Block {
   // $FF: synthetic field
   public static final PropertyEnum<BlockPlanks.EnumType> VARIANT;
   // $FF: synthetic field
   private static final String[] I;

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMapColor();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[167 ^ 175];
      String var10001 = I[145 ^ 152];
      String var10002 = I[171 ^ 161];
      var10001 = I[0 ^ 11];
      var10000 = I[66 ^ 78];
      var10001 = I[17 ^ 28];
      var10002 = I[123 ^ 117];
      var10001 = I[51 ^ 60];
      I[67 ^ 83].length();
      I[60 ^ 45].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[66 ^ 80].length();
      I[184 ^ 171].length();
      var10003["".length()] = VARIANT;
      return new BlockStateContainer(this, var10003);
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[109 ^ 121], BlockPlanks.EnumType.class);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockPlanks.EnumType.byMetadata(var1));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      BlockPlanks.EnumType[] var3 = BlockPlanks.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockPlanks.EnumType var6 = var3[var5];
         I[196 ^ 192].length();
         I[55 ^ 50].length();
         I[126 ^ 120].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[8 ^ 15].length();
         ++var5;
         "".length();
      } while(3 > -1);

      throw null;
   }

   private static void I() {
      I = new String[89 ^ 76];
      I["".length()] = I("垮寊", "FFRqU");
      I[" ".length()] = I("凒恚", "DaYrS");
      I["  ".length()] = I("梤搽", "gJcir");
      I["   ".length()] = I("樭尨", "TmYFF");
      I[94 ^ 90] = I("悺煶", "FfyiL");
      I[109 ^ 104] = I("堷樏", "psZTI");
      I[161 ^ 167] = I("剖恛揙榝涮", "wEEgl");
      I[175 ^ 168] = I("冘", "DQGCu");
      I[130 ^ 138] = I("湺嶈", "nDUTL");
      I[164 ^ 173] = I("噑千", "oiDJJ");
      I[47 ^ 37] = I("壻憕", "UHNcc");
      I[75 ^ 64] = I("咭棪", "jczDi");
      I[130 ^ 142] = I("搤濰", "XGZWd");
      I[13 ^ 0] = I("濒愈", "YMvNq");
      I[83 ^ 93] = I("歌抻", "zPmLE");
      I[92 ^ 83] = I("嗱沴", "OXTWn");
      I[17 ^ 1] = I("滔潾呰抯", "DadvE");
      I[145 ^ 128] = I("椏渋", "zsoMm");
      I[214 ^ 196] = I("懜樐", "pzWrh");
      I[16 ^ 3] = I("春婼归柨滛", "spjTE");
      I[110 ^ 122] = I("\u0014\f\b\u001c3\f\u0019", "bmzuR");
   }

   public BlockPlanks() {
      super(Material.WOOD);
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockPlanks.EnumType.OAK));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      private final MapColor mapColor;
      // $FF: synthetic field
      DARK_OAK;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      BIRCH,
      // $FF: synthetic field
      OAK;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      SPRUCE,
      // $FF: synthetic field
      ACACIA;

      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      JUNGLE;

      // $FF: synthetic field
      private final String unlocalizedName;

      public String getName() {
         return this.name;
      }

      private static void I() {
         I = new String[32 ^ 45];
         I["".length()] = I("\u0005.'", "Jolng");
         I[" ".length()] = I("*5?", "ETTgy");
         I["  ".length()] = I(":\b%\u0012 ,", "iXwGc");
         I["   ".length()] = I("\u001931&\u0007\u000f", "jCCSd");
         I[109 ^ 105] = I("3;<\u00132", "qrnPz");
         I[101 ^ 96] = I("\u0012&!\u0002\u001f", "pOSaw");
         I[23 ^ 17] = I("2\u001b:?\u0005=", "xNtxI");
         I[187 ^ 188] = I("&\u0019\u0003\u001f.)", "LlmxB");
         I[124 ^ 116] = I("550\u000585", "tvqFq");
         I[62 ^ 55] = I("\u00044\u0010/&\u0004", "eWqLO");
         I[181 ^ 191] = I("\u001e\u0002#\u001e&\u0015\u0002:", "ZCqUy");
         I[182 ^ 189] = I("\u0014\b\u0004',\u001f\b\u001d", "pivLs");
         I[28 ^ 16] = I(";:7\u001b588", "YSPDZ");
      }

      public String toString() {
         return this.name;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      public MapColor getMapColor() {
         return this.mapColor;
      }

      static {
         I();
         OAK = new BlockPlanks.EnumType(I["".length()], "".length(), "".length(), I[" ".length()], MapColor.WOOD);
         SPRUCE = new BlockPlanks.EnumType(I["  ".length()], " ".length(), " ".length(), I["   ".length()], MapColor.OBSIDIAN);
         BIRCH = new BlockPlanks.EnumType(I[94 ^ 90], "  ".length(), "  ".length(), I[160 ^ 165], MapColor.SAND);
         JUNGLE = new BlockPlanks.EnumType(I[108 ^ 106], "   ".length(), "   ".length(), I[85 ^ 82], MapColor.DIRT);
         ACACIA = new BlockPlanks.EnumType(I[58 ^ 50], 158 ^ 154, 107 ^ 111, I[171 ^ 162], MapColor.ADOBE);
         DARK_OAK = new BlockPlanks.EnumType(I[28 ^ 22], 142 ^ 139, 33 ^ 36, I[86 ^ 93], I[92 ^ 80], MapColor.BROWN);
         BlockPlanks.EnumType[] var10000 = new BlockPlanks.EnumType[60 ^ 58];
         var10000["".length()] = OAK;
         var10000[" ".length()] = SPRUCE;
         var10000["  ".length()] = BIRCH;
         var10000["   ".length()] = JUNGLE;
         var10000[49 ^ 53] = ACACIA;
         var10000[185 ^ 188] = DARK_OAK;
         BlockPlanks.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockPlanks.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(2 != 1);

         throw null;
      }

      private EnumType(int var3, String var4, MapColor var5) {
         this(var3, var4, var4, var5);
      }

      public int getMetadata() {
         return this.meta;
      }

      public static BlockPlanks.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      private EnumType(int var3, String var4, String var5, MapColor var6) {
         this.meta = var3;
         this.name = var4;
         this.unlocalizedName = var5;
         this.mapColor = var6;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 > 0);

         throw null;
      }
   }
}

package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockBush extends Block {
   // $FF: synthetic field
   protected static final AxisAlignedBB BUSH_AABB;
   // $FF: synthetic field
   private static final String[] I;

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      this.checkAndDropBlock(var1, var2, var3);
   }

   protected BlockBush(Material var1) {
      this(var1, var1.getMaterialMapColor());
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public boolean canBlockStay(World var1, BlockPos var2, IBlockState var3) {
      return this.canSustainBush(var1.getBlockState(var2.down()));
   }

   protected void checkAndDropBlock(World var1, BlockPos var2, IBlockState var3) {
      if (!this.canBlockStay(var1, var2, var3)) {
         this.dropBlockAsItem(var1, var2, var3, "".length());
         var1.setBlockState(var2, Blocks.AIR.getDefaultState(), "   ".length());
         I["".length()].length();
         I[" ".length()].length();
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 4);

      throw null;
   }

   protected boolean canSustainBush(IBlockState var1) {
      int var10000;
      if (var1.getBlock() != Blocks.GRASS && var1.getBlock() != Blocks.DIRT && var1.getBlock() != Blocks.FARMLAND) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (4 <= -1) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      super.neighborChanged(var1, var2, var3, var4, var5);
      this.checkAndDropBlock(var2, var3, var1);
   }

   static {
      I();
      BUSH_AABB = new AxisAlignedBB(0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.699999988079071D, 0.6000000238418579D, 0.699999988079071D);
   }

   protected BlockBush(Material var1, MapColor var2) {
      super(var1, var2);
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (super.canPlaceBlockAt(var1, var2) && this.canSustainBush(var1.getBlockState(var2.down()))) {
         var10000 = " ".length();
         "".length();
         if (0 == 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   protected BlockBush() {
      this(Material.PLANTS);
   }

   private static void I() {
      I = new String["  ".length()];
      I["".length()] = I("淠崭", "iMObX");
      I[" ".length()] = I("挣嘕寀巕奲", "XWZYs");
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return BUSH_AABB;
   }
}

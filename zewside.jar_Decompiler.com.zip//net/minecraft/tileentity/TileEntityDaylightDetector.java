package net.minecraft.tileentity;

import net.minecraft.block.BlockDaylightDetector;
import net.minecraft.util.ITickable;

public class TileEntityDaylightDetector extends TileEntity implements ITickable {
   public void update() {
      if (this.world != null && !this.world.isRemote && this.world.getTotalWorldTime() % 20L == 0L) {
         this.blockType = this.getBlockType();
         if (this.blockType instanceof BlockDaylightDetector) {
            ((BlockDaylightDetector)this.blockType).updatePower(this.world, this.pos);
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 1);

      throw null;
   }
}

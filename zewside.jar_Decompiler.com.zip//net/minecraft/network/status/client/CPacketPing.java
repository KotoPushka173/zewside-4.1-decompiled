package net.minecraft.network.status.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.status.INetHandlerStatusServer;

public class CPacketPing implements Packet<INetHandlerStatusServer> {
   // $FF: synthetic field
   private long clientTime;
   // $FF: synthetic field
   private static final String[] I;

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.clientTime = var1.readLong();
   }

   static {
      I();
   }

   public CPacketPing(long var1) {
      this.clientTime = var1;
   }

   public long getClientTime() {
      return this.clientTime;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeLong(this.clientTime);
      I["".length()].length();
      I[" ".length()].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != 4);

      throw null;
   }

   private static void I() {
      I = new String["  ".length()];
      I["".length()] = I("洋徾", "ZIhHK");
      I[" ".length()] = I("气咨沯晀", "ZegUm");
   }

   public void processPacket(INetHandlerStatusServer var1) {
      var1.processPing(this);
   }

   public CPacketPing() {
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketUpdateHealth implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private float saturationLevel;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int foodLevel;
   // $FF: synthetic field
   private float health;

   public SPacketUpdateHealth(float var1, int var2, float var3) {
      this.health = var1;
      this.foodLevel = var2;
      this.saturationLevel = var3;
   }

   public SPacketUpdateHealth() {
   }

   private static void I() {
      I = new String[137 ^ 132];
      I["".length()] = I("梐", "zHftQ");
      I[" ".length()] = I("忂", "YKCFs");
      I["  ".length()] = I("掇", "eEgDk");
      I["   ".length()] = I("惓", "rkMtM");
      I[101 ^ 97] = I("浝咑", "hwQfL");
      I[137 ^ 140] = I("懤嚣", "lirIn");
      I[160 ^ 166] = I("愣佈", "YedyJ");
      I[55 ^ 48] = I("榓", "UQFba");
      I[26 ^ 18] = I("屄媟", "jLLYl");
      I[33 ^ 40] = I("单欄嫪堝", "RdCWg");
      I[142 ^ 132] = I("抇惈杳", "eEmJd");
      I[189 ^ 182] = I("儦攸", "hXfCD");
      I[182 ^ 186] = I("倘愢丧仔", "jniuQ");
   }

   public float getHealth() {
      return this.health;
   }

   public float getSaturationLevel() {
      return this.saturationLevel;
   }

   public int getFoodLevel() {
      return this.foodLevel;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.health = var1.readFloat();
      this.foodLevel = var1.readVarIntFromBuffer();
      this.saturationLevel = var1.readFloat();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != 2);

      throw null;
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleUpdateHealth(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeFloat(this.health);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeVarIntToBuffer(this.foodLevel);
      I[56 ^ 60].length();
      I[130 ^ 135].length();
      I[15 ^ 9].length();
      I[104 ^ 111].length();
      I[38 ^ 46].length();
      var1.writeFloat(this.saturationLevel);
      I[156 ^ 149].length();
      I[165 ^ 175].length();
      I[107 ^ 96].length();
      I[22 ^ 26].length();
   }
}

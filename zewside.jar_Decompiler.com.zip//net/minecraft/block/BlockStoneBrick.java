package net.minecraft.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;

public class BlockStoneBrick extends Block {
   // $FF: synthetic field
   public static final int CRACKED_META;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockStoneBrick.EnumType> VARIANT;
   // $FF: synthetic field
   public static final int DEFAULT_META;
   // $FF: synthetic field
   public static final int CHISELED_META;
   // $FF: synthetic field
   public static final int MOSSY_META;

   private static void I() {
      I = new String[68 ^ 82];
      I["".length()] = I("潲媟", "FZxJR");
      I[" ".length()] = I("径囹", "nkbMo");
      I["  ".length()] = I("戄烎", "NBvgX");
      I["   ".length()] = I("擑嚀", "UBroU");
      I[114 ^ 118] = I("孹亝嘠", "aXvZk");
      I[43 ^ 46] = I("桳瀠", "ovsPJ");
      I[151 ^ 145] = I("俉侣", "uWpVU");
      I[56 ^ 63] = I("姱汼", "VfDYW");
      I[10 ^ 2] = I("瀒墪", "uSFKh");
      I[44 ^ 37] = I("同史", "ijtrM");
      I[4 ^ 14] = I("檍怎", "pUboQ");
      I[61 ^ 54] = I("夼媬", "zRFiw");
      I[8 ^ 4] = I("焹憟", "xKnHC");
      I[27 ^ 22] = I("坿濙", "lZnUV");
      I[24 ^ 22] = I("兇悷", "GuXZk");
      I[19 ^ 28] = I("壠亩摻毿", "hAvvb");
      I[209 ^ 193] = I("抦", "evncu");
      I[65 ^ 80] = I("昍沞侩", "tcWDG");
      I[143 ^ 157] = I("暍煘", "ZQFsG");
      I[128 ^ 147] = I("崤喴", "gbgXT");
      I[131 ^ 151] = I("毼", "Qevev");
      I[122 ^ 111] = I("\u0019\u00147.(\u0001\u0001", "ouEGI");
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[168 ^ 189], BlockStoneBrick.EnumType.class);
      DEFAULT_META = BlockStoneBrick.EnumType.DEFAULT.getMetadata();
      MOSSY_META = BlockStoneBrick.EnumType.MOSSY.getMetadata();
      CRACKED_META = BlockStoneBrick.EnumType.CRACKED.getMetadata();
      CHISELED_META = BlockStoneBrick.EnumType.CHISELED.getMetadata();
   }

   public BlockStoneBrick() {
      super(Material.ROCK);
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockStoneBrick.EnumType.DEFAULT));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      BlockStoneBrick.EnumType[] var3 = BlockStoneBrick.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockStoneBrick.EnumType var6 = var3[var5];
         I[111 ^ 107].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[146 ^ 151].length();
         ++var5;
         "".length();
      } while(0 < 1);

      throw null;
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockStoneBrick.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockStoneBrick.EnumType.byMetadata(var1));
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[113 ^ 119];
      String var10001 = I[4 ^ 3];
      String var10002 = I[153 ^ 145];
      var10001 = I[97 ^ 104];
      var10000 = I[7 ^ 13];
      var10001 = I[17 ^ 26];
      var10002 = I[121 ^ 117];
      var10001 = I[55 ^ 58];
      I[185 ^ 183].length();
      I[204 ^ 195].length();
      I[94 ^ 78].length();
      I[168 ^ 185].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[35 ^ 49].length();
      I[85 ^ 70].length();
      I[145 ^ 133].length();
      var10003["".length()] = VARIANT;
      return new BlockStateContainer(this, var10003);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 0);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockStoneBrick.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      DEFAULT,
      // $FF: synthetic field
      CRACKED;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      MOSSY,
      // $FF: synthetic field
      CHISELED;

      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private final int meta;

      private static void I() {
         I = new String[93 ^ 81];
         I["".length()] = I("\u001d\u000f\u0007,;\u0015\u001e", "YJAmn");
         I[" ".length()] = I("\u001a;\u001e-$\u000b=\u0018 *", "iOqCA");
         I["  ".length()] = I("%&3\u000b!-7", "ACUjT");
         I["   ".length()] = I("\u001a\u000e\u0012\u0000\u0010", "WAASI");
         I[12 ^ 8] = I("?6\u0000)6\r*\u00075!7;\u00013,9", "RYsZO");
         I[4 ^ 1] = I("\u0007 \n:>", "jOyIG");
         I[162 ^ 164] = I("\u0001883\f\u0007.", "BjypG");
         I[67 ^ 68] = I("\u0017\u0013#0,\u0011\u0005\u001d 3\u001b\u000f'15\u001d\u0002)", "taBSG");
         I[117 ^ 125] = I("\u00138-\"\u0006\u0015.", "pJLAm");
         I[49 ^ 56] = I("\u0002\u0011\u001a\n\u0001\r\u001c\u0017", "AYSYD");
         I[29 ^ 23] = I("-\u001e-\u00172\"\u0013 ;$:\u0019*\u00015<\u001f'\u000f", "NvDdW");
         I[61 ^ 54] = I("\u0007\u000f\u00010\u0011\b\u0002\f", "dghCt");
      }

      public static BlockStoneBrick.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 != -1);

         throw null;
      }

      public String getName() {
         return this.name;
      }

      public int getMetadata() {
         return this.meta;
      }

      public String toString() {
         return this.name;
      }

      static {
         I();
         DEFAULT = new BlockStoneBrick.EnumType(I["".length()], "".length(), "".length(), I[" ".length()], I["  ".length()]);
         MOSSY = new BlockStoneBrick.EnumType(I["   ".length()], " ".length(), " ".length(), I[166 ^ 162], I[0 ^ 5]);
         CRACKED = new BlockStoneBrick.EnumType(I[52 ^ 50], "  ".length(), "  ".length(), I[55 ^ 48], I[52 ^ 60]);
         CHISELED = new BlockStoneBrick.EnumType(I[10 ^ 3], "   ".length(), "   ".length(), I[33 ^ 43], I[105 ^ 98]);
         BlockStoneBrick.EnumType[] var10000 = new BlockStoneBrick.EnumType[48 ^ 52];
         var10000["".length()] = DEFAULT;
         var10000[" ".length()] = MOSSY;
         var10000["  ".length()] = CRACKED;
         var10000["   ".length()] = CHISELED;
         BlockStoneBrick.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockStoneBrick.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(3 >= 2);

         throw null;
      }

      private EnumType(int var3, String var4, String var5) {
         this.meta = var3;
         this.name = var4;
         this.unlocalizedName = var5;
      }
   }
}

package net.minecraft.stats;

import net.minecraft.util.text.ITextComponent;

public class StatBasic extends StatBase {
   // $FF: synthetic field
   private static final String[] I;

   public StatBasic(String var1, ITextComponent var2) {
      super(var1, var2);
   }

   public StatBase registerStat() {
      super.registerStat();
      I["".length()].length();
      StatList.BASIC_STATS.add(this);
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      I[116 ^ 112].length();
      return this;
   }

   static {
      I();
   }

   public StatBasic(String var1, ITextComponent var2, IStatType var3) {
      super(var1, var2, var3);
   }

   private static void I() {
      I = new String[66 ^ 71];
      I["".length()] = I("潸侃梽桧卛", "KmwKK");
      I[" ".length()] = I("巹呒", "vrlho");
      I["  ".length()] = I("夋挲楕彸淥", "KUEzQ");
      I["   ".length()] = I("朜殧床枵", "Gpuce");
      I[24 ^ 28] = I("寻櫉佘", "rZXRN");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }
}

package net.minecraft.block;

import com.google.common.util.concurrent.ListeningExecutorService;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.HttpUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;

public class BlockBeacon extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;

   public static void updateColorAsync(final World var0, final BlockPos var1) {
      String var10000 = I[196 ^ 195];
      String var10001 = I[100 ^ 108];
      String var10002 = I[69 ^ 76];
      var10001 = I[189 ^ 183];
      ListeningExecutorService var2 = HttpUtil.DOWNLOADER_EXECUTOR;
      I[7 ^ 12].length();
      I[28 ^ 16].length();
      I[169 ^ 164].length();
      var2.submit(new Runnable() {
         // $FF: synthetic field
         private static final String[] I;

         private static void I() {
            I = new String[57 ^ 47];
            I["".length()] = I("搻属", "JsYeq");
            I[" ".length()] = I("喝恤", "xkfbw");
            I["  ".length()] = I("嬤呸", "nEgkd");
            I["   ".length()] = I("樰汆", "YHNxg");
            I[77 ^ 73] = I("煔掗", "bvcNF");
            I[22 ^ 19] = I("歳執", "gUUyN");
            I[100 ^ 98] = I("協乥", "EIRxy");
            I[100 ^ 99] = I("峳慻", "bVakb");
            I[33 ^ 41] = I("坿", "qEuos");
            I[150 ^ 159] = I("檷奉", "LowQo");
            I[184 ^ 178] = I("勈孔", "ESfNf");
            I[23 ^ 28] = I("悝湰崿均嗒", "UuMQj");
            I[171 ^ 167] = I("沸", "QgzRQ");
            I[131 ^ 142] = I("灺兆", "PPfry");
            I[141 ^ 131] = I("槽榋圝烳", "XdehI");
            I[130 ^ 141] = I("墟", "PVCoa");
            I[59 ^ 43] = I("僨", "iuYtp");
            I[1 ^ 16] = I("湪", "JvOuc");
            I[37 ^ 55] = I("哥煄", "GQlAE");
            I[43 ^ 56] = I("晻烮录", "yvqTW");
            I[170 ^ 190] = I("墟", "tpylG");
            I[117 ^ 96] = I("歗傰姘恕", "gGPHp");
         }

         static {
            I();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 == -1);

            throw null;
         }

         public void run() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[170 ^ 174];
            var10001 = I[56 ^ 61];
            var10002 = I[141 ^ 139];
            var10001 = I[188 ^ 187];
            Chunk var1x = var0.getChunk(var1);
            int var5 = var1.getY();
            int var7 = " ".length();
            I[140 ^ 132].length();
            I[63 ^ 54].length();
            I[75 ^ 65].length();
            I[202 ^ 193].length();
            int var2 = var5 - var7;

            while(var2 >= 0) {
               I[83 ^ 95].length();
               I[5 ^ 8].length();
               I[87 ^ 89].length();
               I[1 ^ 14].length();
               final BlockPos var3 = new BlockPos(var1.getX(), var2, var1.getZ());
               if (!var1x.canSeeSky(var3)) {
                  "".length();
                  if (2 < 2) {
                     throw null;
                  }
                  break;
               }

               IBlockState var4 = var0.getBlockState(var3);
               if (var4.getBlock() == Blocks.BEACON) {
                  WorldServer var6 = (WorldServer)var0;
                  I[187 ^ 171].length();
                  I[19 ^ 2].length();
                  I[116 ^ 102].length();
                  I[173 ^ 190].length();
                  var6.addScheduledTask(new Runnable() {
                     public void run() {
                        TileEntity var1x = var0.getTileEntity(var3);
                        if (var1x instanceof TileEntityBeacon) {
                           ((TileEntityBeacon)var1x).updateBeacon();
                           var0.addBlockEvent(var3, Blocks.BEACON, " ".length(), "".length());
                        }

                     }

                     private static String I(String s, String s1) {
                        StringBuilder sb = new StringBuilder();
                        char[] key = s1.toCharArray();
                        int i = "".length();
                        char[] var5 = s.toCharArray();
                        int var6 = var5.length;
                        int var7 = "".length();

                        do {
                           if (var7 >= var6) {
                              return sb.toString();
                           }

                           char c = var5[var7];
                           sb.append((char)(c ^ key[i % key.length]));
                           ++i;
                           ++var7;
                           "".length();
                        } while(3 == 3);

                        throw null;
                     }
                  });
                  I[9 ^ 29].length();
                  I[135 ^ 146].length();
               }

               --var2;
               "".length();
               if (false) {
                  throw null;
               }
            }

         }
      });
      I[200 ^ 198].length();
      I[200 ^ 199].length();
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      super.onBlockPlacedBy(var1, var2, var3, var4, var5);
      if (var5.hasDisplayName()) {
         TileEntity var6 = var1.getTileEntity(var2);
         if (var6 instanceof TileEntityBeacon) {
            ((TileEntityBeacon)var6).setName(var5.getDisplayName());
         }
      }

   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   static {
      I();
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[118 ^ 114].length();
      I[15 ^ 10].length();
      I[127 ^ 121].length();
      return new TileEntityBeacon();
   }

   private static void I() {
      I = new String[175 ^ 191];
      I["".length()] = I("嶧宝", "xsIqL");
      I[" ".length()] = I("战帩", "KRYvC");
      I["  ".length()] = I("涙撢", "Ifbgv");
      I["   ".length()] = I("晡埭", "cObKC");
      I[197 ^ 193] = I("婈啣", "cnine");
      I[49 ^ 52] = I("再戣婕棐", "KKuiU");
      I[142 ^ 136] = I("婳壊佁摤揯", "GpmAY");
      I[151 ^ 144] = I("惐拗", "ZNYgg");
      I[20 ^ 28] = I("晝憉", "uEBTu");
      I[98 ^ 107] = I("尫汖", "orimp");
      I[54 ^ 60] = I("戫港", "YytqR");
      I[1 ^ 10] = I("涔浽", "VwYuB");
      I[113 ^ 125] = I("榉毅", "gDybG");
      I[101 ^ 104] = I("浌榬", "oSuSx");
      I[205 ^ 195] = I("漌决撑喁", "Fxxnl");
      I[128 ^ 143] = I("弉汨", "mMUdm");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 >= 0);

      throw null;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      TileEntity var6 = var2.getTileEntity(var3);
      if (var6 instanceof TileEntityBeacon) {
         ((TileEntityBeacon)var6).updateBeacon();
         var2.addBlockEvent(var3, this, " ".length(), "".length());
      }

   }

   public BlockBeacon() {
      super(Material.GLASS, MapColor.DIAMOND);
      this.setHardness(3.0F);
      this.setCreativeTab(CreativeTabs.MISC);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         TileEntity var10 = var1.getTileEntity(var2);
         if (var10 instanceof TileEntityBeacon) {
            var4.displayGUIChest((TileEntityBeacon)var10);
            var4.addStat(StatList.BEACON_INTERACTION);
         }

         return (boolean)" ".length();
      }
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }
}

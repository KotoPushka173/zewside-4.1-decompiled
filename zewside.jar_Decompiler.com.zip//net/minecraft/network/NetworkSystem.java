package net.minecraft.network;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.epoll.Epoll;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollServerSocketChannel;
import io.netty.channel.local.LocalAddress;
import io.netty.channel.local.LocalEventLoopGroup;
import io.netty.channel.local.LocalServerChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.network.NetHandlerHandshakeMemory;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.network.play.server.SPacketDisconnect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.NetHandlerHandshakeTCP;
import net.minecraft.util.LazyLoadBase;
import net.minecraft.util.ReportedException;
import net.minecraft.util.text.TextComponentString;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class NetworkSystem {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final MinecraftServer mcServer;
   // $FF: synthetic field
   public static final LazyLoadBase<LocalEventLoopGroup> SERVER_LOCAL_EVENTLOOP;
   // $FF: synthetic field
   public static final LazyLoadBase<EpollEventLoopGroup> SERVER_EPOLL_EVENTLOOP;
   // $FF: synthetic field
   private final List<ChannelFuture> endpoints = Collections.synchronizedList(Lists.newArrayList());
   // $FF: synthetic field
   private final List<NetworkManager> networkManagers = Collections.synchronizedList(Lists.newArrayList());
   // $FF: synthetic field
   public volatile boolean isAlive;
   // $FF: synthetic field
   private static final Logger LOGGER;
   // $FF: synthetic field
   public static final LazyLoadBase<NioEventLoopGroup> SERVER_NIO_EVENTLOOP;

   public MinecraftServer getServer() {
      return this.mcServer;
   }

   public SocketAddress addLocalEndpoint() {
      String var10000 = I[21 ^ 12];
      String var10001 = I[71 ^ 93];
      String var10002 = I[22 ^ 13];
      var10001 = I[9 ^ 21];
      var10000 = I[44 ^ 49];
      var10001 = I[39 ^ 57];
      var10002 = I[164 ^ 187];
      var10001 = I[3 ^ 35];
      var10000 = I[148 ^ 181];
      var10001 = I[111 ^ 77];
      var10002 = I[88 ^ 123];
      var10001 = I[26 ^ 62];
      List var5 = this.endpoints;
      I[142 ^ 171].length();
      I[1 ^ 39].length();
      I[125 ^ 90].length();
      ChannelFuture var1;
      synchronized(var5) {
         I[176 ^ 152].length();
         I[186 ^ 147].length();
         I[187 ^ 145].length();
         ServerBootstrap var6 = (ServerBootstrap)(new ServerBootstrap()).channel(LocalServerChannel.class);
         I[106 ^ 65].length();
         I[170 ^ 134].length();
         I[30 ^ 51].length();
         I[158 ^ 176].length();
         I[238 ^ 193].length();
         var1 = ((ServerBootstrap)var6.childHandler(new ChannelInitializer<Channel>() {
            // $FF: synthetic field
            private static final String[] I;

            protected void initChannel(Channel var1) throws Exception {
               String var10000 = I["".length()];
               String var10001 = I[" ".length()];
               String var10002 = I["  ".length()];
               var10001 = I["   ".length()];
               var10000 = I[111 ^ 107];
               var10001 = I[114 ^ 119];
               var10002 = I[170 ^ 172];
               var10001 = I[199 ^ 192];
               I[168 ^ 160].length();
               I[7 ^ 14].length();
               NetworkManager var2 = new NetworkManager(EnumPacketDirection.SERVERBOUND);
               I[204 ^ 198].length();
               I[112 ^ 123].length();
               I[42 ^ 38].length();
               var2.setNetHandler(new NetHandlerHandshakeMemory(NetworkSystem.this.mcServer, var2));
               NetworkSystem.this.networkManagers.add(var2);
               I[101 ^ 104].length();
               var1.pipeline().addLast(I[36 ^ 42], var2);
               I[87 ^ 88].length();
               I[115 ^ 99].length();
               I[166 ^ 183].length();
            }

            static {
               I();
            }

            private static void I() {
               I = new String[122 ^ 104];
               I["".length()] = I("暹潏", "VlGeo");
               I[" ".length()] = I("渣弳", "LfvPF");
               I["  ".length()] = I("恙巇", "ORVqg");
               I["   ".length()] = I("澿慑", "ENrRz");
               I[193 ^ 197] = I("桦啻", "Jspsa");
               I[183 ^ 178] = I("岳歯", "XRLGU");
               I[32 ^ 38] = I("勻枡", "UDdZK");
               I[21 ^ 18] = I("勣崴", "TukIk");
               I[23 ^ 31] = I("泷揨哉淵橖", "SbDYr");
               I[3 ^ 10] = I("垨揉捳峾斤", "okbzb");
               I[180 ^ 190] = I("奢水儻", "ZSPqF");
               I[55 ^ 60] = I("喂帉", "nTMCT");
               I[50 ^ 62] = I("孀呴溬满", "khEHt");
               I[6 ^ 11] = I("斟", "yfpVE");
               I[144 ^ 158] = I("\u0011\b-2\u001c\u00156&8\u0017\u0005\u0005++", "aiNYy");
               I[1 ^ 14] = I("咜", "aGOxM");
               I[118 ^ 102] = I("懐", "liENH");
               I[29 ^ 12] = I("岫煙汷歚堗", "tNkdh");
            }

            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(3 >= 1);

               throw null;
            }
         }).group((EventLoopGroup)SERVER_NIO_EVENTLOOP.getValue()).localAddress(LocalAddress.ANY)).bind().syncUninterruptibly();
         this.endpoints.add(var1);
         I[70 ^ 118].length();
         I[240 ^ 193].length();
      }

      "".length();
      if (2 >= 4) {
         throw null;
      } else {
         return var1.channel().localAddress();
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   static {
      I();
      LOGGER = LogManager.getLogger();
      SERVER_NIO_EVENTLOOP = new LazyLoadBase<NioEventLoopGroup>() {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static void I() {
            I = new String[102 ^ 107];
            I["".length()] = I("婞煚", "xXXNB");
            I[" ".length()] = I("澴媄", "skSVZ");
            I["  ".length()] = I("濎噃", "GFfxk");
            I["   ".length()] = I("敪夎", "FizzR");
            I[10 ^ 14] = I("槩攣", "KFJYa");
            I[161 ^ 164] = I("咬嫍", "bVVaI");
            I[189 ^ 187] = I("亏宥", "SXtgW");
            I[82 ^ 85] = I("卹瀉", "sFzvM");
            I[170 ^ 162] = I("怃", "UZlNP");
            I[14 ^ 7] = I("債沍杞唺", "XjVjF");
            I[206 ^ 196] = I("斏咋嫔撏", "YtDCa");
            I[79 ^ 68] = I("拺僩滙応", "VJuRA");
            I[20 ^ 24] = I("\u0004*,'\u001bj\u001c=!\u0014/=x\u001a-jl}7", "JOXSb");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 > 1);

            throw null;
         }

         protected NioEventLoopGroup load() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[75 ^ 79];
            var10001 = I[32 ^ 37];
            var10002 = I[47 ^ 41];
            var10001 = I[180 ^ 179];
            I[134 ^ 142].length();
            int var1 = "".length();
            I[157 ^ 148].length();
            I[91 ^ 81].length();
            I[50 ^ 57].length();
            return new NioEventLoopGroup(var1, (new ThreadFactoryBuilder()).setNameFormat(I[76 ^ 64]).setDaemon((boolean)" ".length()).build());
         }
      };
      SERVER_EPOLL_EVENTLOOP = new LazyLoadBase<EpollEventLoopGroup>() {
         // $FF: synthetic field
         private static final String[] I;

         protected EpollEventLoopGroup load() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[163 ^ 167];
            var10001 = I[5 ^ 0];
            var10002 = I[36 ^ 34];
            var10001 = I[36 ^ 35];
            I[117 ^ 125].length();
            I[122 ^ 115].length();
            int var1 = "".length();
            I[57 ^ 51].length();
            return new EpollEventLoopGroup(var1, (new ThreadFactoryBuilder()).setNameFormat(I[73 ^ 66]).setDaemon((boolean)" ".length()).build());
         }

         private static void I() {
            I = new String[205 ^ 193];
            I["".length()] = I("憁揜", "rYZqc");
            I[" ".length()] = I("撞捹", "VQUJd");
            I["  ".length()] = I("嚞囁", "vFwbE");
            I["   ".length()] = I("別勮", "jbHhO");
            I[4 ^ 0] = I("捌峊", "lyBBR");
            I[27 ^ 30] = I("憷忶", "ksEYb");
            I[196 ^ 194] = I("檶泆", "qvcSM");
            I[20 ^ 19] = I("弃宠", "tcoyZ");
            I[135 ^ 143] = I("暟汃佖攫栰", "LfIlk");
            I[58 ^ 51] = I("柘恗氢", "eUlgP");
            I[189 ^ 183] = I("丨嗹志墀涕", "yjHhC");
            I[14 ^ 5] = I("\u0017\u001d\u0011\u0013\ny=\u0015\b\u001f5X6\u0002\u0001/\u001d\u0017G:\u0016XFB\u0017", "Yxegs");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 >= 1);

            throw null;
         }

         static {
            I();
         }
      };
      SERVER_LOCAL_EVENTLOOP = new LazyLoadBase<LocalEventLoopGroup>() {
         // $FF: synthetic field
         private static final String[] I;

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 != 0);

            throw null;
         }

         static {
            I();
         }

         protected LocalEventLoopGroup load() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[82 ^ 86];
            var10001 = I[148 ^ 145];
            var10002 = I[86 ^ 80];
            var10001 = I[132 ^ 131];
            I[156 ^ 148].length();
            I[25 ^ 16].length();
            I[11 ^ 1].length();
            int var1 = "".length();
            I[116 ^ 127].length();
            I[77 ^ 65].length();
            return new LocalEventLoopGroup(var1, (new ThreadFactoryBuilder()).setNameFormat(I[3 ^ 14]).setDaemon((boolean)" ".length()).build());
         }

         private static void I() {
            I = new String[137 ^ 135];
            I["".length()] = I("涎搕", "aVOOs");
            I[" ".length()] = I("奒洢", "wnIoF");
            I["  ".length()] = I("岢昝", "XneDy");
            I["   ".length()] = I("嘕啣", "mZIMt");
            I[13 ^ 9] = I("揲拂", "cRjxu");
            I[41 ^ 44] = I("楊堰", "qJWQJ");
            I[101 ^ 99] = I("梓杆", "cWeCn");
            I[48 ^ 55] = I("媐梢", "ZcAUu");
            I[179 ^ 187] = I("咱", "NGcCV");
            I[145 ^ 152] = I("弮", "hXXnj");
            I[2 ^ 8] = I("扯", "gwNLF");
            I[168 ^ 163] = I("沮怇娠炅樲", "YQVdA");
            I[70 ^ 74] = I("慰帅", "dvfHe");
            I[169 ^ 164] = I("-5\f\u000e\nC\u001c\u0017\u0019\u0012\u000fp+\u001f\u0001\u00155\nZ:,p[_\u0017", "cPxzs");
         }
      };
   }

   public NetworkSystem(MinecraftServer var1) {
      this.mcServer = var1;
      this.isAlive = (boolean)" ".length();
   }

   private static void I() {
      I = new String[242 ^ 155];
      I["".length()] = I("朐榰", "MWkDZ");
      I[" ".length()] = I("嚷傧", "lRhvk");
      I["  ".length()] = I("寰橋", "JBRrM");
      I["   ".length()] = I("溓唸", "gXUiI");
      I[46 ^ 42] = I("濦楡", "uPChD");
      I[18 ^ 23] = I("煴汨", "ezcsO");
      I[165 ^ 163] = I("沑浌", "AeslO");
      I[125 ^ 122] = I("僡泶", "GuFVd");
      I[108 ^ 100] = I("悹拵", "izwbk");
      I[190 ^ 183] = I("峙漬", "ZdjeW");
      I[171 ^ 161] = I("僵僕", "lfIAM");
      I[92 ^ 87] = I("槨姷", "GrsGf");
      I[185 ^ 181] = I("孩愸", "fGnGC");
      I[23 ^ 26] = I("::=\u001c\u0004O,$\u001d\u000f\u0003i7\u001a\u0002\u0001'1\u001eC\u001b0$\u0017", "oITrc");
      I[21 ^ 27] = I("7;%\u001b\bB,)\u0013\u000e\u0017$8U\f\n)\"\u001b\n\u000eh8\f\u001f\u0007", "bHLuo");
      I[157 ^ 146] = I("惥帎敿櫾為", "vYBOs");
      I[215 ^ 199] = I("澾汿憺岔", "MnvKd");
      I[108 ^ 125] = I("妊剗", "nzdzG");
      I[126 ^ 108] = I("摣响殚", "sxmKb");
      I[154 ^ 137] = I("杸攐", "KSTPI");
      I[161 ^ 181] = I("嬯", "tAceA");
      I[54 ^ 35] = I("撥", "XdWSp");
      I[169 ^ 191] = I("圲擑拕墓炬", "bJedH");
      I[59 ^ 44] = I("丗欝媠堡枢", "nkJHZ");
      I[153 ^ 129] = I("抓倝", "tKGMs");
      I[181 ^ 172] = I("商傗", "wJzst");
      I[140 ^ 150] = I("崰啶", "NjLts");
      I[84 ^ 79] = I("凋峓", "XLAoO");
      I[151 ^ 139] = I("擥惟", "ZHvrd");
      I[183 ^ 170] = I("丨溅", "pxIal");
      I[218 ^ 196] = I("徿弮", "EInBH");
      I[155 ^ 132] = I("擰冧", "HtfVZ");
      I[20 ^ 52] = I("炣岰", "IAoON");
      I[97 ^ 64] = I("媂峾", "Fmlmm");
      I[92 ^ 126] = I("憤帨", "cwKHf");
      I[73 ^ 106] = I("攏掬", "IrSlv");
      I[69 ^ 97] = I("埭挍", "eLxea");
      I[26 ^ 63] = I("孖澫渆", "LuWCQ");
      I[125 ^ 91] = I("掄", "yjJuW");
      I[65 ^ 102] = I("伂年桺協慚", "LAKPw");
      I[66 ^ 106] = I("廉儑", "HghJI");
      I[86 ^ 127] = I("摝", "bzwJS");
      I[183 ^ 157] = I("旿樨", "HStfa");
      I[87 ^ 124] = I("浺", "YPzBZ");
      I[30 ^ 50] = I("柎潩", "ypVFR");
      I[171 ^ 134] = I("懂岆亄", "MRMXb");
      I[166 ^ 136] = I("栦嗿嵈帙嶻", "iSzQL");
      I[125 ^ 82] = I("憫慥", "DDZHW");
      I[185 ^ 137] = I("嚾掵勶", "vXwri");
      I[153 ^ 168] = I("崘壵溶攔", "Kdiwv");
      I[245 ^ 199] = I("享", "QwKBi");
      I[154 ^ 169] = I("慜瀧沉柀桚", "gyVMX");
      I[64 ^ 116] = I("帨彁垢喔坡", "vBFwG");
      I[134 ^ 179] = I("假咬", "waEYc");
      I[8 ^ 62] = I("侀懚婥", "iTpKy");
      I[126 ^ 73] = I("奛幝噶", "ctPwL");
      I[174 ^ 150] = I(",4\u001c! \u0017/\u001807\u0001z\u001f,;\t)\u001cd1\t5\u001b-<\u0002z\u000b,3\u000b4\r(", "eZhDR");
      I[76 ^ 117] = I("恅濑", "EoUGH");
      I[179 ^ 137] = I("檠堼", "MTPaB");
      I[27 ^ 32] = I("炴彯", "pAhOm");
      I[180 ^ 136] = I("嫪梲", "KJUSH");
      I[105 ^ 84] = I("漒丯", "zLzPD");
      I[170 ^ 148] = I("檻兀", "sndmp");
      I[168 ^ 151] = I("枣啜", "uTnks");
      I[45 ^ 109] = I("汪噦", "LYfzn");
      I[91 ^ 26] = I("捥圿", "YRrFv");
      I[22 ^ 84] = I("榡歠", "cfOCf");
      I[41 ^ 106] = I("娣沞", "wduau");
      I[20 ^ 80] = I("峞溲", "XowDg");
      I[57 ^ 124] = I("偨显", "RxplQ");
      I[196 ^ 130] = I("峩垈", "WcCBv");
      I[118 ^ 49] = I("廞恪", "ZUXvC");
      I[142 ^ 198] = I("崦勦", "RGTdz");
      I[236 ^ 165] = I("挓橀", "xVlWK");
      I[34 ^ 104] = I("板潌", "rstIp");
      I[252 ^ 183] = I("婓殞", "TNYsk");
      I[124 ^ 48] = I("幢寵", "CRxeP");
      I[206 ^ 131] = I("滚叕", "CqMNt");
      I[250 ^ 180] = I("弄擠", "EnEJP");
      I[137 ^ 198] = I("圞楝", "yiBWI");
      I[217 ^ 137] = I("尌奲", "EYmdO");
      I[223 ^ 142] = I("浓公", "GTCTh");
      I[40 ^ 122] = I("\u0017='\u0006>-3d\u00002.;6\u0014w ;*\u00032  -\u00029", "CTDmW");
      I[70 ^ 21] = I("\u001c\u0010\u001a\u0006\u000f&\u001eY\u000e\t&\u0017\u001c\u000e\u0012!\u0016\u0017", "Hyymf");
      I[34 ^ 118] = I("\u001b\u0000\u001d\u001e\t;\u001b\u001a\u001f\u0002", "Xospl");
      I[245 ^ 160] = I("恮瀈啌夯泶", "BEpNf");
      I[147 ^ 197] = I("杧吃梡団溿", "sVJUY");
      I[79 ^ 24] = I("沍哇刌擧濊", "Ahrtx");
      I[51 ^ 107] = I("汴澆敤幏弨", "xlPmD");
      I[31 ^ 70] = I("师", "KttHD");
      I[204 ^ 150] = I("俨戸橵曂櫙", "CYVHO");
      I[217 ^ 130] = I("\"\u0010\u0010/'\u0000Q\r,b\f\u0010\u0017'.\u0001Q\t\"!\u000f\u0014\rc$\u000b\u0003Y8?", "dqyCB");
      I[38 ^ 122] = I("佪憝", "LylRP");
      I[100 ^ 57] = I("噂溲廵導", "arzXS");
      I[67 ^ 29] = I("妔娷澇", "QrZAL");
      I[53 ^ 106] = I("<6\u0007\u0001\u0015\u001b9\u001fD\u0014\u0010*\u0005\u0001\u0015U=\u0001\u0016\b\u0007", "uXsdg");
      I[102 ^ 6] = I("嶧浖僟寻", "GXCef");
      I[88 ^ 57] = I("浆挱化尅洵", "nXjls");
      I[110 ^ 12] = I("冾", "xsxuB");
      I[228 ^ 135] = I("勈垼斢", "XEWVx");
      I[210 ^ 182] = I("占庋", "fPsZF");
      I[162 ^ 199] = I("揂旟", "SSBCf");
      I[18 ^ 116] = I("潅孎娃", "nfDjD");
      I[31 ^ 120] = I("媋壾煴殕", "VGOiW");
      I[245 ^ 157] = I("匍攘", "jOxxS");
   }

   public void addLanEndpoint(InetAddress var1, int var2) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[80 ^ 84];
      var10001 = I[126 ^ 123];
      var10002 = I[76 ^ 74];
      var10001 = I[83 ^ 84];
      var10000 = I[34 ^ 42];
      var10001 = I[40 ^ 33];
      var10002 = I[36 ^ 46];
      var10001 = I[24 ^ 19];
      List var8 = this.endpoints;
      I[109 ^ 97].length();
      synchronized(var8) {
         Class var4;
         LazyLoadBase var5;
         if (Epoll.isAvailable() && this.mcServer.shouldUseNativeTransport()) {
            var4 = EpollServerSocketChannel.class;
            var5 = SERVER_EPOLL_EVENTLOOP;
            LOGGER.info(I[133 ^ 136]);
            "".length();
            if (2 <= -1) {
               throw null;
            }
         } else {
            var4 = NioServerSocketChannel.class;
            var5 = SERVER_NIO_EVENTLOOP;
            LOGGER.info(I[117 ^ 123]);
         }

         var8 = this.endpoints;
         I[116 ^ 123].length();
         I[167 ^ 183].length();
         I[6 ^ 23].length();
         I[175 ^ 189].length();
         ServerBootstrap var9 = (ServerBootstrap)(new ServerBootstrap()).channel(var4);
         I[51 ^ 32].length();
         var8.add(((ServerBootstrap)var9.childHandler(new ChannelInitializer<Channel>() {
            // $FF: synthetic field
            private static final String[] I;

            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(true);

               throw null;
            }

            static {
               I();
            }

            private static void I() {
               I = new String[59 ^ 120];
               I["".length()] = I("攌傄", "QpWHm");
               I[" ".length()] = I("伩曺", "OJxyh");
               I["  ".length()] = I("泡幜", "QpQKq");
               I["   ".length()] = I("卆朌", "XfZjP");
               I[6 ^ 2] = I("巏墈", "SKHIg");
               I[31 ^ 26] = I("堋洓", "Zogox");
               I[142 ^ 136] = I("傋啽", "NiQZi");
               I[146 ^ 149] = I("晗匸", "toRBU");
               I[202 ^ 194] = I("殊搵", "AruYv");
               I[30 ^ 23] = I("傂博", "NACWp");
               I[188 ^ 182] = I("戾並", "JsYEg");
               I[185 ^ 178] = I("潮员", "MsLZa");
               I[23 ^ 27] = I("匘灏", "OseCP");
               I[145 ^ 156] = I("忶搭", "QapxX");
               I[58 ^ 52] = I("墇敹", "USimx");
               I[43 ^ 36] = I("捯掲", "GAlVl");
               I[122 ^ 106] = I("廋斨", "ekIIX");
               I[145 ^ 128] = I("滗欱", "XKwuP");
               I[125 ^ 111] = I("憩吘", "apdhJ");
               I[72 ^ 91] = I("搑榝", "kGuFn");
               I[172 ^ 184] = I("潪温", "bxhWV");
               I[95 ^ 74] = I("戡濮", "HtPSJ");
               I[132 ^ 146] = I("梃偣", "mLkZV");
               I[58 ^ 45] = I("冋瀞", "VKoHs");
               I[6 ^ 30] = I("摔儳", "CYyBJ");
               I[18 ^ 11] = I("术墛", "JdjsK");
               I[40 ^ 50] = I("勋淔", "tmEBY");
               I[181 ^ 174] = I("僄滤", "YwtZj");
               I[67 ^ 95] = I("侊偓", "ypqhc");
               I[40 ^ 53] = I("崾堞", "xctRx");
               I[141 ^ 147] = I("杛妥", "eNWKR");
               I[42 ^ 53] = I("勳圶", "dqSKQ");
               I[99 ^ 67] = I("墌岺告拢埉", "KMYky");
               I[179 ^ 146] = I("潄崄", "sCQce");
               I[54 ^ 20] = I(" ?7'\u0016!\"", "TVZBy");
               I[45 ^ 14] = I("炇埈殅埧湡", "VNjBI");
               I[25 ^ 61] = I("\u0014(\f\f\t\u0001\u0012\u001a\u0018\u000f\n4", "xMkmj");
               I[95 ^ 122] = I("奛標俖曟侟", "PCDlV");
               I[152 ^ 190] = I("桞寨滌倈媻", "BBIVk");
               I[152 ^ 191] = I("'\u001a\u000e\", \u000f\u0010", "TjbKX");
               I[90 ^ 114] = I("俞溼垨嗼啅", "pKduk");
               I[149 ^ 188] = I("敩槃潀", "kNloZ");
               I[104 ^ 66] = I("\u0017\u0012.;<\u0016\u0005", "swMTX");
               I[17 ^ 58] = I("帺媳", "HkIvp");
               I[21 ^ 57] = I("姶枹僌侇", "UfpYJ");
               I[37 ^ 8] = I("*\u00004304\u001641", "ZrQCU");
               I[129 ^ 175] = I("梧容", "FEzCB");
               I[169 ^ 134] = I("\f\u0006\"7%\f\u001a", "ihAXA");
               I[26 ^ 42] = I("卍洔", "pDsbw");
               I[14 ^ 63] = I("惿槗", "Ubdzr");
               I[241 ^ 195] = I("洰悶噗椿", "mIxGP");
               I[25 ^ 42] = I("妡椥", "lKTyT");
               I[19 ^ 39] = I("惬凙堢屆戊", "TJiDx");
               I[37 ^ 16] = I("嚃涺渽溉晿", "FBtSU");
               I[175 ^ 153] = I("栉", "tLnGH");
               I[144 ^ 167] = I("屧囮咶摋姒", "qLROX");
               I[143 ^ 183] = I("厉恳懥", "lQArj");
               I[81 ^ 104] = I("刭滻摢品愰", "Pemjw");
               I[171 ^ 145] = I("开吶檤摢哽", "hHLVy");
               I[154 ^ 161] = I("敦", "BAAqz");
               I[253 ^ 193] = I("7 \n*\u000e3\u001e\u0001 \u0005#-\f3", "GAiAk");
               I[120 ^ 69] = I("傉", "OQhXc");
               I[35 ^ 29] = I("劰廎烀", "bpWSl");
               I[157 ^ 162] = I("殽垔忚勂俊", "oeDKd");
               I[230 ^ 166] = I("傧欸懸滛", "LPEdE");
               I[134 ^ 199] = I("寎旸塞栮", "TAgjf");
               I[221 ^ 159] = I("泏晪厃喕", "wTJkH");
            }

            protected void initChannel(Channel var1) throws Exception {
               String var10000 = I["".length()];
               String var10001 = I[" ".length()];
               String var10002 = I["  ".length()];
               var10001 = I["   ".length()];
               var10000 = I[7 ^ 3];
               var10001 = I[100 ^ 97];
               var10002 = I[160 ^ 166];
               var10001 = I[141 ^ 138];
               var10000 = I[170 ^ 162];
               var10001 = I[15 ^ 6];
               var10002 = I[146 ^ 152];
               var10001 = I[151 ^ 156];
               var10000 = I[164 ^ 168];
               var10001 = I[3 ^ 14];
               var10002 = I[191 ^ 177];
               var10001 = I[201 ^ 198];
               var10000 = I[153 ^ 137];
               var10001 = I[190 ^ 175];
               var10002 = I[134 ^ 148];
               var10001 = I[27 ^ 8];
               var10000 = I[94 ^ 74];
               var10001 = I[69 ^ 80];
               var10002 = I[62 ^ 40];
               var10001 = I[161 ^ 182];
               var10000 = I[95 ^ 71];
               var10001 = I[148 ^ 141];
               var10002 = I[118 ^ 108];
               var10001 = I[128 ^ 155];
               var10000 = I[62 ^ 34];
               var10001 = I[44 ^ 49];
               var10002 = I[8 ^ 22];
               var10001 = I[169 ^ 182];

               label15: {
                  try {
                     var1.config().setOption(ChannelOption.TCP_NODELAY, Boolean.valueOf((boolean)" ".length()));
                     I[34 ^ 2].length();
                     I[154 ^ 187].length();
                  } catch (ChannelException var3) {
                     break label15;
                  }

                  "".length();
                  if (false) {
                     throw null;
                  }
               }

               ChannelPipeline var4 = var1.pipeline();
               var10001 = I[42 ^ 8];
               I[12 ^ 47].length();
               var4 = var4.addLast(var10001, new ReadTimeoutHandler(16 ^ 14));
               var10001 = I[78 ^ 106];
               I[90 ^ 127].length();
               I[21 ^ 51].length();
               var4 = var4.addLast(var10001, new LegacyPingHandler(NetworkSystem.this));
               var10001 = I[19 ^ 52];
               I[2 ^ 42].length();
               I[168 ^ 129].length();
               var4 = var4.addLast(var10001, new NettyVarint21FrameDecoder());
               var10001 = I[176 ^ 154];
               I[184 ^ 147].length();
               I[180 ^ 152].length();
               var4 = var4.addLast(var10001, new NettyPacketDecoder(EnumPacketDirection.SERVERBOUND));
               var10001 = I[134 ^ 171];
               I[44 ^ 2].length();
               var4 = var4.addLast(var10001, new NettyVarint21FrameEncoder());
               var10001 = I[118 ^ 89];
               I[130 ^ 178].length();
               I[164 ^ 149].length();
               I[119 ^ 69].length();
               I[145 ^ 162].length();
               var4.addLast(var10001, new NettyPacketEncoder(EnumPacketDirection.CLIENTBOUND));
               I[75 ^ 127].length();
               I[22 ^ 35].length();
               I[115 ^ 69].length();
               I[25 ^ 46].length();
               I[118 ^ 78].length();
               I[81 ^ 104].length();
               NetworkManager var2 = new NetworkManager(EnumPacketDirection.SERVERBOUND);
               NetworkSystem.this.networkManagers.add(var2);
               I[165 ^ 159].length();
               I[86 ^ 109].length();
               var1.pipeline().addLast(I[23 ^ 43], var2);
               I[148 ^ 169].length();
               I[83 ^ 109].length();
               I[182 ^ 137].length();
               I[124 ^ 60].length();
               I[2 ^ 67].length();
               I[28 ^ 94].length();
               var2.setNetHandler(new NetHandlerHandshakeTCP(NetworkSystem.this.mcServer, var2));
            }
         }).group((EventLoopGroup)var5.getValue()).localAddress(var1, var2)).bind().syncUninterruptibly());
         I[183 ^ 163].length();
         I[172 ^ 185].length();
      }

      "".length();
      if (1 <= -1) {
         throw null;
      }
   }

   public void networkTick() {
      String var10000 = I[123 ^ 66];
      String var10001 = I[128 ^ 186];
      String var10002 = I[255 ^ 196];
      var10001 = I[182 ^ 138];
      var10000 = I[5 ^ 56];
      var10001 = I[185 ^ 135];
      var10002 = I[68 ^ 123];
      var10001 = I[83 ^ 19];
      var10000 = I[12 ^ 77];
      var10001 = I[60 ^ 126];
      var10002 = I[54 ^ 117];
      var10001 = I[205 ^ 137];
      var10000 = I[252 ^ 185];
      var10001 = I[43 ^ 109];
      var10002 = I[227 ^ 164];
      var10001 = I[56 ^ 112];
      var10000 = I[34 ^ 107];
      var10001 = I[3 ^ 73];
      var10002 = I[5 ^ 78];
      var10001 = I[233 ^ 165];
      var10000 = I[222 ^ 147];
      var10001 = I[209 ^ 159];
      var10002 = I[30 ^ 81];
      var10001 = I[8 ^ 88];
      List var11 = this.networkManagers;
      I[220 ^ 141].length();
      synchronized(var11) {
         Iterator var2 = this.networkManagers.iterator();

         while(var2.hasNext()) {
            final NetworkManager var3 = (NetworkManager)var2.next();
            if (!var3.hasNoChannel()) {
               if (var3.isChannelOpen()) {
                  label42: {
                     try {
                        var3.processReceivedPackets();
                     } catch (Exception var8) {
                        if (var3.isLocalChannel()) {
                           CrashReport var10 = CrashReport.makeCrashReport(var8, I[245 ^ 167]);
                           CrashReportCategory var6 = var10.makeCategory(I[201 ^ 154]);
                           var10001 = I[30 ^ 74];
                           I[17 ^ 68].length();
                           var6.setDetail(var10001, new ICrashReportDetail<String>() {
                              public String call() throws Exception {
                                 return var3.toString();
                              }

                              private static String I(String s, String s1) {
                                 StringBuilder sb = new StringBuilder();
                                 char[] key = s1.toCharArray();
                                 int i = "".length();
                                 char[] var5 = s.toCharArray();
                                 int var6 = var5.length;
                                 int var7 = "".length();

                                 do {
                                    if (var7 >= var6) {
                                       return sb.toString();
                                    }

                                    char c = var5[var7];
                                    sb.append((char)(c ^ key[i % key.length]));
                                    ++i;
                                    ++var7;
                                    "".length();
                                 } while(3 > 2);

                                 throw null;
                              }
                           });
                           I[198 ^ 144].length();
                           I[78 ^ 25].length();
                           I[246 ^ 174].length();
                           I[249 ^ 160].length();
                           ReportedException var12 = new ReportedException(var10);
                           I[204 ^ 150].length();
                           throw var12;
                        }

                        LOGGER.warn(I[70 ^ 29], var3.getRemoteAddress(), var8);
                        I[120 ^ 36].length();
                        I[56 ^ 101].length();
                        I[198 ^ 152].length();
                        final TextComponentString var5 = new TextComponentString(I[231 ^ 184]);
                        I[240 ^ 144].length();
                        I[251 ^ 154].length();
                        I[36 ^ 70].length();
                        SPacketDisconnect var13 = new SPacketDisconnect(var5);
                        I[13 ^ 110].length();
                        I[14 ^ 106].length();
                        I[70 ^ 35].length();
                        I[54 ^ 80].length();
                        var3.sendPacket(var13, new GenericFutureListener<Future<? super Void>>() {
                           public void operationComplete(Future<? super Void> var1) throws Exception {
                              var3.closeChannel(var5);
                           }

                           private static String I(String s, String s1) {
                              StringBuilder sb = new StringBuilder();
                              char[] key = s1.toCharArray();
                              int i = "".length();
                              char[] var5x = s.toCharArray();
                              int var6 = var5x.length;
                              int var7 = "".length();

                              do {
                                 if (var7 >= var6) {
                                    return sb.toString();
                                 }

                                 char c = var5x[var7];
                                 sb.append((char)(c ^ key[i % key.length]));
                                 ++i;
                                 ++var7;
                                 "".length();
                              } while(2 == 2);

                              throw null;
                           }
                        });
                        var3.disableAutoRead();
                        "".length();
                        if (2 == -1) {
                           throw null;
                        }
                        break label42;
                     }

                     "".length();
                     if (4 <= 3) {
                        throw null;
                     }
                  }
               } else {
                  var2.remove();
                  var3.checkDisconnected();
               }
            }

            "".length();
            if (false) {
               throw null;
            }
         }
      }

      "".length();
      if (3 < 0) {
         throw null;
      }
   }

   public void terminateEndpoints() {
      this.isAlive = (boolean)"".length();
      Iterator var1 = this.endpoints.iterator();

      while(var1.hasNext()) {
         ChannelFuture var2 = (ChannelFuture)var1.next();

         label23: {
            try {
               var2.channel().close().sync();
               I[135 ^ 178].length();
               I[174 ^ 152].length();
               I[30 ^ 41].length();
            } catch (InterruptedException var4) {
               LOGGER.error(I[16 ^ 40]);
               break label23;
            }

            "".length();
            if (4 < 4) {
               throw null;
            }
         }

         "".length();
         if (4 <= -1) {
            throw null;
         }
      }

   }
}

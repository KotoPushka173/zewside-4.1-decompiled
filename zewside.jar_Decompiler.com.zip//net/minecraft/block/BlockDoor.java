package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockDoor extends Block {
   // $FF: synthetic field
   protected static final AxisAlignedBB NORTH_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockDoor.EnumHingePosition> HINGE;
   // $FF: synthetic field
   protected static final AxisAlignedBB SOUTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB EAST_AABB;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   protected static final AxisAlignedBB WEST_AABB;
   // $FF: synthetic field
   public static final PropertyEnum<BlockDoor.EnumDoorHalf> HALF;
   // $FF: synthetic field
   public static final PropertyBool OPEN;
   // $FF: synthetic field
   public static final PropertyBool POWERED;

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      IBlockState var10000;
      if (var2 == Mirror.NONE) {
         var10000 = var1;
         "".length();
         if (2 <= 0) {
            throw null;
         }
      } else {
         var10000 = var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING))).cycleProperty(HINGE);
      }

      return var10000;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      IBlockState var10000;
      if (var1.getValue(HALF) != BlockDoor.EnumDoorHalf.LOWER) {
         var10000 = var1;
         "".length();
         if (2 == 3) {
            throw null;
         }
      } else {
         var10000 = var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
      }

      return var10000;
   }

   private int getCloseSound() {
      int var10000;
      if (this.blockMaterial == Material.IRON) {
         var10000 = 778 + 762 - 731 + 202;
         "".length();
         if (2 == 1) {
            throw null;
         }
      } else {
         var10000 = 451 + 439 - 432 + 554;
      }

      return var10000;
   }

   public String getLocalizedName() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[122 ^ 126].length();
      I[138 ^ 143].length();
      I[140 ^ 138].length();
      return I18n.translateToLocal((this.getUnlocalizedName() + I[188 ^ 187]).replaceAll(I[59 ^ 51], I[172 ^ 165]));
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      Item var10000;
      if (var1.getValue(HALF) == BlockDoor.EnumDoorHalf.UPPER) {
         var10000 = Items.field_190931_a;
         "".length();
         if (3 <= 0) {
            throw null;
         }
      } else {
         var10000 = this.getItem();
      }

      return var10000;
   }

   public static int combineMetadata(IBlockAccess var0, BlockPos var1) {
      IBlockState var2 = var0.getBlockState(var1);
      int var3 = var2.getBlock().getMetaFromState(var2);
      boolean var4 = isTop(var3);
      IBlockState var5 = var0.getBlockState(var1.down());
      int var6 = var5.getBlock().getMetaFromState(var5);
      int var10000;
      if (var4) {
         var10000 = var6;
         "".length();
         if (4 < 1) {
            throw null;
         }
      } else {
         var10000 = var3;
      }

      int var7 = var10000;
      IBlockState var8 = var0.getBlockState(var1.up());
      int var9 = var8.getBlock().getMetaFromState(var8);
      if (var4) {
         var10000 = var3;
         "".length();
         if (0 == 2) {
            throw null;
         }
      } else {
         var10000 = var9;
      }

      int var10 = var10000;
      if ((var10 & " ".length()) != 0) {
         var10000 = " ".length();
         "".length();
         if (-1 != -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var11 = var10000;
      if ((var10 & "  ".length()) != 0) {
         var10000 = " ".length();
         "".length();
         if (3 < 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var12 = var10000;
      var10000 = removeHalfBit(var7);
      int var10001;
      if (var4) {
         var10001 = 127 ^ 119;
         "".length();
         if (0 == 2) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      var10000 |= var10001;
      if (var11 != 0) {
         var10001 = 131 ^ 147;
         "".length();
         if (-1 >= 3) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      var10000 |= var10001;
      if (var12 != 0) {
         var10001 = 16 ^ 48;
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      return var10000 | var10001;
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      OPEN = PropertyBool.create(I[104 ^ 61]);
      HINGE = PropertyEnum.create(I[52 ^ 98], BlockDoor.EnumHingePosition.class);
      POWERED = PropertyBool.create(I[238 ^ 185]);
      HALF = PropertyEnum.create(I[36 ^ 124], BlockDoor.EnumDoorHalf.class);
      SOUTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.1875D);
      NORTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.8125D, 1.0D, 1.0D, 1.0D);
      WEST_AABB = new AxisAlignedBB(0.8125D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      EAST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.1875D, 1.0D, 1.0D);
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      return isOpen(combineMetadata(var1, var2));
   }

   protected static int removeHalfBit(int var0) {
      return var0 & (178 ^ 181);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      var1 = var1.getActualState(var2, var3);
      EnumFacing var4 = (EnumFacing)var1.getValue(FACING);
      int var10000;
      if (!(Boolean)var1.getValue(OPEN)) {
         var10000 = " ".length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var5 = var10000;
      if (var1.getValue(HINGE) == BlockDoor.EnumHingePosition.RIGHT) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var6 = var10000;
      AxisAlignedBB var7;
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var4.ordinal()]) {
      case 1:
      default:
         if (var5 != 0) {
            var7 = EAST_AABB;
            "".length();
            if (3 <= -1) {
               throw null;
            }
         } else if (var6 != 0) {
            var7 = NORTH_AABB;
            "".length();
            if (4 != 4) {
               throw null;
            }
         } else {
            var7 = SOUTH_AABB;
         }

         return var7;
      case 2:
         if (var5 != 0) {
            var7 = SOUTH_AABB;
            "".length();
            if (2 < 1) {
               throw null;
            }
         } else if (var6 != 0) {
            var7 = EAST_AABB;
            "".length();
            if (4 < 0) {
               throw null;
            }
         } else {
            var7 = WEST_AABB;
         }

         return var7;
      case 3:
         if (var5 != 0) {
            var7 = WEST_AABB;
            "".length();
            if (1 <= 0) {
               throw null;
            }
         } else if (var6 != 0) {
            var7 = SOUTH_AABB;
            "".length();
            if (2 <= 1) {
               throw null;
            }
         } else {
            var7 = NORTH_AABB;
         }

         return var7;
      case 4:
         if (var5 != 0) {
            var7 = NORTH_AABB;
            "".length();
            if (0 >= 3) {
               throw null;
            }
         } else if (var6 != 0) {
            var7 = WEST_AABB;
            "".length();
            if (2 < 2) {
               throw null;
            }
         } else {
            var7 = EAST_AABB;
         }

         return var7;
      }
   }

   private static void I() {
      I = new String[33 ^ 120];
      I["".length()] = I("暭漲", "mTjoC");
      I[" ".length()] = I("墆曣", "mINBf");
      I["  ".length()] = I("準烘", "fOWRT");
      I["   ".length()] = I("汕丹", "FmPIb");
      I[101 ^ 97] = I("桵榪杻", "cHKcv");
      I[138 ^ 143] = I("幂囪", "TOwxi");
      I[32 ^ 38] = I("沁峻嚁囍峒", "iOiJV");
      I[89 ^ 94] = I("F8\u0010#&", "hVqNC");
      I[203 ^ 195] = I(",\u000b\r(", "XbaMG");
      I[56 ^ 49] = I("?\u001f!\u0018", "VkDuv");
      I[39 ^ 45] = I("灳戃朤戦匑", "goYJk");
      I[168 ^ 163] = I("嫗", "IvxlQ");
      I[87 ^ 91] = I("噐炕洌坌", "JQnIy");
      I[24 ^ 21] = I("嚘怎欲攔厰", "fMEMG");
      I[154 ^ 148] = I("烡氧揓怩", "duycy");
      I[139 ^ 132] = I("朙慾挺湔", "vPpRG");
      I[65 ^ 81] = I("栓", "Akjfy");
      I[58 ^ 43] = I("屠峺擅渼", "sTyjR");
      I[99 ^ 113] = I("淙宻", "MyPRt");
      I[7 ^ 20] = I("尌帴娓扣棝", "tOtge");
      I[90 ^ 78] = I("淖旜漞", "tWkab");
      I[111 ^ 122] = I("厥", "JoZnP");
      I[129 ^ 151] = I("搒泘", "qNYbN");
      I[186 ^ 173] = I("夯杼戎", "dMawM");
      I[84 ^ 76] = I("欘枲掘拻履", "yEeBf");
      I[25 ^ 0] = I("岯庳", "UTvEK");
      I[144 ^ 138] = I("嚹拌尸幖惏", "YSGqn");
      I[92 ^ 71] = I("弨", "xSqMv");
      I[152 ^ 132] = I("撗丽歪", "UukEz");
      I[72 ^ 85] = I("嬧櫙", "XxVQx");
      I[152 ^ 134] = I("垌毇忊伜孎", "yQBZN");
      I[126 ^ 97] = I("尉揨", "zZDmY");
      I[97 ^ 65] = I("噄恏", "KvCeu");
      I[44 ^ 13] = I("堹帚", "babSh");
      I[162 ^ 128] = I("壻戧", "Gxgxn");
      I[74 ^ 105] = I("娍", "gtVll");
      I[142 ^ 170] = I("墤帷怗", "NHRxo");
      I[29 ^ 56] = I("哯", "FfSVp");
      I[128 ^ 166] = I("壑嶜凂擀", "IcIfR");
      I[150 ^ 177] = I("幥澓杭偼摫", "IsTTQ");
      I[62 ^ 22] = I("匬壂", "AXCml");
      I[185 ^ 144] = I("恟五", "eBUOx");
      I[160 ^ 138] = I("溲彋汪攡", "IeDOO");
      I[162 ^ 137] = I("汤夺嬱撵养", "AKcCX");
      I[11 ^ 39] = I("淎撞寝唣氧", "Xacxw");
      I[19 ^ 62] = I("亲毾", "TUJDD");
      I[175 ^ 129] = I("柯殌", "EZkOw");
      I[45 ^ 2] = I("呑朾", "kmcwI");
      I[144 ^ 160] = I("洤朇", "RWdwa");
      I[163 ^ 146] = I("媤炼", "Uowgg");
      I[137 ^ 187] = I("嬙妓", "IGAdL");
      I[181 ^ 134] = I("寙洕", "lkeRJ");
      I[31 ^ 43] = I("惇湢", "gLdZV");
      I[128 ^ 181] = I("曨幙", "yoRTP");
      I[21 ^ 35] = I("兛曬", "ggnIS");
      I[245 ^ 194] = I("坍库", "DScot");
      I[19 ^ 43] = I("櫲屎", "WsDmn");
      I[13 ^ 52] = I("懷栲", "EgLAV");
      I[31 ^ 37] = I("嘴亥", "evkXd");
      I[31 ^ 36] = I("槟嘺", "skKGm");
      I[252 ^ 192] = I("儚暢", "BXYBX");
      I[185 ^ 132] = I("河嵓", "YdzUe");
      I[89 ^ 103] = I("旍倫", "VfjOh");
      I[104 ^ 87] = I("叅椝", "xkKAX");
      I[17 ^ 81] = I("慱擠", "SjAFg");
      I[61 ^ 124] = I("炗灌", "wontj");
      I[210 ^ 144] = I("夦威", "VzmTk");
      I[131 ^ 192] = I("忬摿", "mSSDn");
      I[224 ^ 164] = I("擤唔", "Wtsvs");
      I[70 ^ 3] = I("丛", "rXBTX");
      I[24 ^ 94] = I("殄栽人溝妿", "ySkdk");
      I[202 ^ 141] = I("弭佻寱傲澵", "tKIHA");
      I[89 ^ 17] = I("塄慙悺彏檄", "rJTnk");
      I[246 ^ 191] = I("棲", "xAbEx");
      I[14 ^ 68] = I("湕檷倡側嚟", "EICzY");
      I[66 ^ 9] = I("奲", "cUiVD");
      I[25 ^ 85] = I("濳样", "ELaby");
      I[194 ^ 143] = I("夡澂", "ewUck");
      I[73 ^ 7] = I("淐", "pizWS");
      I[25 ^ 86] = I("嶧", "fVEaV");
      I[97 ^ 49] = I("搠", "JxQyH");
      I[95 ^ 14] = I("忤瀾埱", "fReJP");
      I[72 ^ 26] = I("歽憘幔帆尀", "PKLWZ");
      I[68 ^ 23] = I("掟嶷桻", "GublW");
      I[14 ^ 90] = I("勃搣濳", "dYeiw");
      I[121 ^ 44] = I("\u001f\u0017=\b", "pgXfU");
      I[70 ^ 16] = I("\u001e\b?\u0001=", "vaQfX");
      I[230 ^ 177] = I("9-9 =,&", "IBNEO");
      I[236 ^ 180] = I("\u0000\u000f\u000b\r", "hngkB");
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      if (var1.getValue(HALF) == BlockDoor.EnumDoorHalf.UPPER) {
         var2 |= 144 ^ 152;
         if (var1.getValue(HINGE) == BlockDoor.EnumHingePosition.RIGHT) {
            var2 |= " ".length();
         }

         if ((Boolean)var1.getValue(POWERED)) {
            var2 |= "  ".length();
            "".length();
            if (4 <= 1) {
               throw null;
            }
         }
      } else {
         var2 |= ((EnumFacing)var1.getValue(FACING)).rotateY().getHorizontalIndex();
         if ((Boolean)var1.getValue(OPEN)) {
            var2 |= 49 ^ 53;
         }
      }

      return var2;
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      if (var2.getY() >= 101 + 137 - 60 + 77) {
         return (boolean)"".length();
      } else {
         int var10000;
         if (var1.getBlockState(var2.down()).isFullyOpaque() && super.canPlaceBlockAt(var1, var2) && super.canPlaceBlockAt(var1, var2.up())) {
            var10000 = " ".length();
            "".length();
            if (-1 == 3) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[149 ^ 138];
      String var10001 = I[52 ^ 20];
      String var10002 = I[173 ^ 140];
      var10001 = I[164 ^ 134];
      I[155 ^ 184].length();
      I[111 ^ 75].length();
      I[11 ^ 46].length();
      return new ItemStack(this.getItem());
   }

   public EnumPushReaction getMobilityFlag(IBlockState var1) {
      return EnumPushReaction.DESTROY;
   }

   public void toggleDoor(World var1, BlockPos var2, boolean var3) {
      IBlockState var4 = var1.getBlockState(var2);
      if (var4.getBlock() == this) {
         BlockPos var10000;
         if (var4.getValue(HALF) == BlockDoor.EnumDoorHalf.LOWER) {
            var10000 = var2;
            "".length();
            if (1 < -1) {
               throw null;
            }
         } else {
            var10000 = var2.down();
         }

         BlockPos var5 = var10000;
         IBlockState var7;
         if (var2 == var5) {
            var7 = var4;
            "".length();
            if (3 < 0) {
               throw null;
            }
         } else {
            var7 = var1.getBlockState(var5);
         }

         IBlockState var6 = var7;
         if (var6.getBlock() == this && (Boolean)var6.getValue(OPEN) != var3) {
            var1.setBlockState(var5, var6.withProperty(OPEN, var3), 100 ^ 110);
            I[97 ^ 109].length();
            I[47 ^ 34].length();
            I[110 ^ 96].length();
            var1.markBlockRangeForRenderUpdate(var5, var2);
            EntityPlayer var10001 = (EntityPlayer)null;
            int var10002;
            if (var3) {
               var10002 = this.getOpenSound();
               "".length();
               if (0 == 3) {
                  throw null;
               }
            } else {
               var10002 = this.getCloseSound();
            }

            var1.playEvent(var10001, var10002, var2, "".length());
         }
      }

   }

   public static EnumFacing getFacing(IBlockAccess var0, BlockPos var1) {
      return getFacing(combineMetadata(var0, var1));
   }

   protected static boolean isOpen(int var0) {
      int var10000;
      if ((var0 & (124 ^ 120)) != 0) {
         var10000 = " ".length();
         "".length();
         if (3 == 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   protected static boolean isTop(int var0) {
      int var10000;
      if ((var0 & (115 ^ 123)) != 0) {
         var10000 = " ".length();
         "".length();
         if (1 <= -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000;
      PropertyBool var2;
      int var3;
      if ((var1 & (156 ^ 148)) > 0) {
         var10000 = this.getDefaultState().withProperty(HALF, BlockDoor.EnumDoorHalf.UPPER);
         PropertyEnum var10001 = HINGE;
         BlockDoor.EnumHingePosition var10002;
         if ((var1 & " ".length()) > 0) {
            var10002 = BlockDoor.EnumHingePosition.RIGHT;
            "".length();
            if (4 == 3) {
               throw null;
            }
         } else {
            var10002 = BlockDoor.EnumHingePosition.LEFT;
         }

         var10000 = var10000.withProperty(var10001, var10002);
         var2 = POWERED;
         if ((var1 & "  ".length()) > 0) {
            var3 = " ".length();
            "".length();
            if (0 >= 2) {
               throw null;
            }
         } else {
            var3 = "".length();
         }

         var10000 = var10000.withProperty(var2, Boolean.valueOf((boolean)var3));
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = this.getDefaultState().withProperty(HALF, BlockDoor.EnumDoorHalf.LOWER).withProperty(FACING, EnumFacing.byHorizontalIndex(var1 & "   ".length()).rotateYCCW());
         var2 = OPEN;
         if ((var1 & (146 ^ 150)) > 0) {
            var3 = " ".length();
            "".length();
            if (-1 >= 1) {
               throw null;
            }
         } else {
            var3 = "".length();
         }

         var10000 = var10000.withProperty(var2, Boolean.valueOf((boolean)var3));
      }

      return var10000;
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      if (var1.getBlock() == Blocks.IRON_DOOR) {
         return MapColor.IRON;
      } else if (var1.getBlock() == Blocks.OAK_DOOR) {
         return BlockPlanks.EnumType.OAK.getMapColor();
      } else if (var1.getBlock() == Blocks.SPRUCE_DOOR) {
         return BlockPlanks.EnumType.SPRUCE.getMapColor();
      } else if (var1.getBlock() == Blocks.BIRCH_DOOR) {
         return BlockPlanks.EnumType.BIRCH.getMapColor();
      } else if (var1.getBlock() == Blocks.JUNGLE_DOOR) {
         return BlockPlanks.EnumType.JUNGLE.getMapColor();
      } else if (var1.getBlock() == Blocks.ACACIA_DOOR) {
         return BlockPlanks.EnumType.ACACIA.getMapColor();
      } else {
         MapColor var10000;
         if (var1.getBlock() == Blocks.DARK_OAK_DOOR) {
            var10000 = BlockPlanks.EnumType.DARK_OAK.getMapColor();
            "".length();
            if (2 >= 3) {
               throw null;
            }
         } else {
            var10000 = super.getMapColor(var1, var2, var3);
         }

         return var10000;
      }
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[234 ^ 199];
      String var10001 = I[96 ^ 78];
      String var10002 = I[149 ^ 186];
      var10001 = I[113 ^ 65];
      var10000 = I[62 ^ 15];
      var10001 = I[74 ^ 120];
      var10002 = I[247 ^ 196];
      var10001 = I[130 ^ 182];
      var10000 = I[14 ^ 59];
      var10001 = I[10 ^ 60];
      var10002 = I[190 ^ 137];
      var10001 = I[126 ^ 70];
      var10000 = I[100 ^ 93];
      var10001 = I[20 ^ 46];
      var10002 = I[35 ^ 24];
      var10001 = I[120 ^ 68];
      var10000 = I[1 ^ 60];
      var10001 = I[132 ^ 186];
      var10002 = I[152 ^ 167];
      var10001 = I[214 ^ 150];
      var10000 = I[46 ^ 111];
      var10001 = I[250 ^ 184];
      var10002 = I[192 ^ 131];
      var10001 = I[48 ^ 116];
      I[243 ^ 182].length();
      I[61 ^ 123].length();
      I[32 ^ 103].length();
      IProperty[] var10003 = new IProperty[114 ^ 119];
      I[93 ^ 21].length();
      var10003["".length()] = HALF;
      I[201 ^ 128].length();
      I[68 ^ 14].length();
      I[12 ^ 71].length();
      I[122 ^ 54].length();
      var10003[" ".length()] = FACING;
      I[127 ^ 50].length();
      I[208 ^ 158].length();
      I[226 ^ 173].length();
      var10003["  ".length()] = OPEN;
      I[210 ^ 130].length();
      I[219 ^ 138].length();
      I[25 ^ 75].length();
      var10003["   ".length()] = HINGE;
      I[12 ^ 95].length();
      I[15 ^ 91].length();
      var10003[87 ^ 83] = POWERED;
      return new BlockStateContainer(this, var10003);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (var1.getValue(HALF) == BlockDoor.EnumDoorHalf.UPPER) {
         BlockPos var6 = var3.down();
         IBlockState var7 = var2.getBlockState(var6);
         if (var7.getBlock() != this) {
            var2.setBlockToAir(var3);
            I[79 ^ 64].length();
            I[121 ^ 105].length();
            "".length();
            if (0 < 0) {
               throw null;
            }
         } else if (var4 != this) {
            var7.neighborChanged(var2, var6, var4, var5);
         }

         "".length();
         if (0 < -1) {
            throw null;
         }
      } else {
         int var10 = "".length();
         BlockPos var11 = var3.up();
         IBlockState var8 = var2.getBlockState(var11);
         if (var8.getBlock() != this) {
            var2.setBlockToAir(var3);
            I[209 ^ 192].length();
            I[32 ^ 50].length();
            var10 = " ".length();
         }

         if (!var2.getBlockState(var3.down()).isFullyOpaque()) {
            var2.setBlockToAir(var3);
            I[186 ^ 169].length();
            I[3 ^ 23].length();
            I[130 ^ 151].length();
            var10 = " ".length();
            if (var8.getBlock() == this) {
               var2.setBlockToAir(var11);
               I[113 ^ 103].length();
               I[4 ^ 19].length();
               I[181 ^ 173].length();
            }
         }

         if (var10 != 0) {
            if (!var2.isRemote) {
               this.dropBlockAsItem(var2, var3, var1, "".length());
               "".length();
               if (2 < 2) {
                  throw null;
               }
            }
         } else {
            int var10000;
            if (!var2.isBlockPowered(var3) && !var2.isBlockPowered(var11)) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (0 == 3) {
                  throw null;
               }
            }

            int var9 = var10000;
            if (var4 != this && (var9 != 0 || var4.getDefaultState().canProvidePower()) && var9 != (Boolean)var8.getValue(POWERED)) {
               var2.setBlockState(var11, var8.withProperty(POWERED, Boolean.valueOf((boolean)var9)), "  ".length());
               I[111 ^ 118].length();
               I[157 ^ 135].length();
               if (var9 != (Boolean)var1.getValue(OPEN)) {
                  var2.setBlockState(var3, var1.withProperty(OPEN, Boolean.valueOf((boolean)var9)), "  ".length());
                  I[218 ^ 193].length();
                  I[183 ^ 171].length();
                  I[150 ^ 139].length();
                  I[159 ^ 129].length();
                  var2.markBlockRangeForRenderUpdate(var3, var3);
                  EntityPlayer var10001 = (EntityPlayer)null;
                  int var10002;
                  if (var9 != 0) {
                     var10002 = this.getOpenSound();
                     "".length();
                     if (1 <= 0) {
                        throw null;
                     }
                  } else {
                     var10002 = this.getCloseSound();
                  }

                  var2.playEvent(var10001, var10002, var3, "".length());
               }
            }
         }
      }

   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (this.blockMaterial == Material.IRON) {
         return (boolean)"".length();
      } else {
         BlockPos var10000;
         if (var3.getValue(HALF) == BlockDoor.EnumDoorHalf.LOWER) {
            var10000 = var2;
            "".length();
            if (2 != 2) {
               throw null;
            }
         } else {
            var10000 = var2.down();
         }

         BlockPos var10 = var10000;
         IBlockState var12;
         if (var2.equals(var10)) {
            var12 = var3;
            "".length();
            if (4 <= 0) {
               throw null;
            }
         } else {
            var12 = var1.getBlockState(var10);
         }

         IBlockState var11 = var12;
         if (var11.getBlock() != this) {
            return (boolean)"".length();
         } else {
            var3 = var11.cycleProperty(OPEN);
            var1.setBlockState(var10, var3, 12 ^ 6);
            I[2 ^ 8].length();
            I[171 ^ 160].length();
            var1.markBlockRangeForRenderUpdate(var10, var2);
            int var10002;
            if ((Boolean)var3.getValue(OPEN)) {
               var10002 = this.getOpenSound();
               "".length();
               if (1 < 0) {
                  throw null;
               }
            } else {
               var10002 = this.getCloseSound();
            }

            var1.playEvent(var4, var10002, var2, "".length());
            return (boolean)" ".length();
         }
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 2);

      throw null;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockDoor(Material var1) {
      super(var1);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(OPEN, Boolean.valueOf((boolean)"".length())).withProperty(HINGE, BlockDoor.EnumHingePosition.LEFT).withProperty(POWERED, Boolean.valueOf((boolean)"".length())).withProperty(HALF, BlockDoor.EnumDoorHalf.LOWER));
   }

   private Item getItem() {
      if (this == Blocks.IRON_DOOR) {
         return Items.IRON_DOOR;
      } else if (this == Blocks.SPRUCE_DOOR) {
         return Items.SPRUCE_DOOR;
      } else if (this == Blocks.BIRCH_DOOR) {
         return Items.BIRCH_DOOR;
      } else if (this == Blocks.JUNGLE_DOOR) {
         return Items.JUNGLE_DOOR;
      } else if (this == Blocks.ACACIA_DOOR) {
         return Items.ACACIA_DOOR;
      } else {
         Item var10000;
         if (this == Blocks.DARK_OAK_DOOR) {
            var10000 = Items.DARK_OAK_DOOR;
            "".length();
            if (2 <= 1) {
               throw null;
            }
         } else {
            var10000 = Items.OAK_DOOR;
         }

         return var10000;
      }
   }

   public static boolean isOpen(IBlockAccess var0, BlockPos var1) {
      return isOpen(combineMetadata(var0, var1));
   }

   public void onBlockHarvested(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      BlockPos var5 = var2.down();
      BlockPos var6 = var2.up();
      if (var4.capabilities.isCreativeMode && var3.getValue(HALF) == BlockDoor.EnumDoorHalf.UPPER && var1.getBlockState(var5).getBlock() == this) {
         var1.setBlockToAir(var5);
         I[126 ^ 88].length();
         I[174 ^ 137].length();
      }

      if (var3.getValue(HALF) == BlockDoor.EnumDoorHalf.LOWER && var1.getBlockState(var6).getBlock() == this) {
         if (var4.capabilities.isCreativeMode) {
            var1.setBlockToAir(var2);
            I[21 ^ 61].length();
            I[17 ^ 56].length();
         }

         var1.setBlockToAir(var6);
         I[141 ^ 167].length();
         I[180 ^ 159].length();
         I[59 ^ 23].length();
      }

   }

   public static EnumFacing getFacing(int var0) {
      return EnumFacing.byHorizontalIndex(var0 & "   ".length()).rotateYCCW();
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      IBlockState var4;
      if (var1.getValue(HALF) == BlockDoor.EnumDoorHalf.LOWER) {
         var4 = var2.getBlockState(var3.up());
         if (var4.getBlock() == this) {
            var1 = var1.withProperty(HINGE, var4.getValue(HINGE)).withProperty(POWERED, var4.getValue(POWERED));
         }

         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var4 = var2.getBlockState(var3.down());
         if (var4.getBlock() == this) {
            var1 = var1.withProperty(FACING, var4.getValue(FACING)).withProperty(OPEN, var4.getValue(OPEN));
         }
      }

      return var1;
   }

   private int getOpenSound() {
      int var10000;
      if (this.blockMaterial == Material.IRON) {
         var10000 = 375 + 457 - 295 + 468;
         "".length();
         if (-1 >= 2) {
            throw null;
         }
      } else {
         var10000 = 136 + 689 - 75 + 256;
      }

      return var10000;
   }

   public static enum EnumDoorHalf implements IStringSerializable {
      // $FF: synthetic field
      LOWER,
      // $FF: synthetic field
      UPPER;

      // $FF: synthetic field
      private static final String[] I;

      public String toString() {
         return this.getName();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 >= 0);

         throw null;
      }

      static {
         I();
         UPPER = new BlockDoor.EnumDoorHalf(I["  ".length()], "".length());
         LOWER = new BlockDoor.EnumDoorHalf(I["   ".length()], " ".length());
         BlockDoor.EnumDoorHalf[] var10000 = new BlockDoor.EnumDoorHalf["  ".length()];
         var10000["".length()] = UPPER;
         var10000[" ".length()] = LOWER;
      }

      public String getName() {
         String var10000;
         if (this == UPPER) {
            var10000 = I["".length()];
            "".length();
            if (-1 != -1) {
               throw null;
            }
         } else {
            var10000 = I[" ".length()];
         }

         return var10000;
      }

      private static void I() {
         I = new String[105 ^ 109];
         I["".length()] = I("\u0019';\"<", "lWKGN");
         I[" ".length()] = I("=\r\u001c$\u000b", "QbkAy");
         I["  ".length()] = I("6\"\u0001!\u0006", "crQdT");
         I["   ".length()] = I("\u0003\f\u0016\u000b ", "OCANr");
      }
   }

   public static enum EnumHingePosition implements IStringSerializable {
      // $FF: synthetic field
      RIGHT;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      LEFT;

      private static void I() {
         I = new String[163 ^ 167];
         I["".length()] = I("\u001f\u001f\n\u0013", "szlgp");
         I[" ".length()] = I("\u001c<6!\u0001", "nUQIu");
         I["  ".length()] = I("\n=\u0002\u001d", "FxDIK");
         I["   ".length()] = I("\u0006\u0013\u000f\f9", "TZHDm");
      }

      public String toString() {
         return this.getName();
      }

      static {
         I();
         LEFT = new BlockDoor.EnumHingePosition(I["  ".length()], "".length());
         RIGHT = new BlockDoor.EnumHingePosition(I["   ".length()], " ".length());
         BlockDoor.EnumHingePosition[] var10000 = new BlockDoor.EnumHingePosition["  ".length()];
         var10000["".length()] = LEFT;
         var10000[" ".length()] = RIGHT;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 < 1);

         throw null;
      }

      public String getName() {
         String var10000;
         if (this == LEFT) {
            var10000 = I["".length()];
            "".length();
            if (3 <= 0) {
               throw null;
            }
         } else {
            var10000 = I[" ".length()];
         }

         return var10000;
      }
   }
}

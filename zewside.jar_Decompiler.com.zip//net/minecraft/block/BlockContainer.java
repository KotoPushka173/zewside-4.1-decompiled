package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorldNameable;
import net.minecraft.world.World;

public abstract class BlockContainer extends Block implements ITileEntityProvider {
   // $FF: synthetic field
   private static final String[] I;

   private static void I() {
      I = new String[47 ^ 34];
      I["".length()] = I("嘸楿", "XpVqo");
      I[" ".length()] = I("慺庀", "kBMXe");
      I["  ".length()] = I("亹崮", "wnPAt");
      I["   ".length()] = I("樴揚", "BKhdp");
      I[187 ^ 191] = I("攓", "sWEJc");
      I[181 ^ 176] = I("愘剮", "zcOxu");
      I[148 ^ 146] = I("困尸潦掩", "gQfup");
      I[41 ^ 46] = I("憃堶", "dmDiv");
      I[0 ^ 8] = I("潐檖匈临", "epFnm");
      I[139 ^ 130] = I("嚄刖啼昦妋", "TfeKj");
      I[206 ^ 196] = I("傢忲", "NOwju");
      I[65 ^ 74] = I("彑殆", "QeCkC");
      I[132 ^ 136] = I("喛楸惩", "yGfAY");
   }

   public boolean eventReceived(IBlockState var1, World var2, BlockPos var3, int var4, int var5) {
      super.eventReceived(var1, var2, var3, var4, var5);
      I[169 ^ 160].length();
      I[207 ^ 197].length();
      I[13 ^ 6].length();
      I[1 ^ 13].length();
      TileEntity var6 = var2.getTileEntity(var3);
      int var10000;
      if (var6 == null) {
         var10000 = "".length();
         "".length();
         if (4 == -1) {
            throw null;
         }
      } else {
         var10000 = var6.receiveClientEvent(var4, var5);
      }

      return (boolean)var10000;
   }

   protected BlockContainer(Material var1) {
      this(var1, var1.getMaterialMapColor());
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 4);

      throw null;
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (var5 instanceof IWorldNameable && ((IWorldNameable)var5).hasCustomName()) {
         var2.addStat(StatList.getBlockStats(this));
         var2.addExhaustion(0.005F);
         if (var1.isRemote) {
            return;
         }

         int var7 = EnchantmentHelper.getEnchantmentLevel(Enchantments.FORTUNE, var6);
         Item var8 = this.getItemDropped(var4, var1.rand, var7);
         if (var8 == Items.field_190931_a) {
            return;
         }

         I[6 ^ 2].length();
         I[86 ^ 83].length();
         ItemStack var9 = new ItemStack(var8, this.quantityDropped(var1.rand));
         var9.setStackDisplayName(((IWorldNameable)var5).getName());
         I[173 ^ 171].length();
         I[174 ^ 169].length();
         I[55 ^ 63].length();
         spawnAsEntity(var1, var3, var9);
         "".length();
         if (4 < -1) {
            throw null;
         }
      } else {
         super.harvestBlock(var1, var2, var3, var4, (TileEntity)null, var6);
      }

   }

   protected BlockContainer(Material var1, MapColor var2) {
      super(var1, var2);
      this.isBlockContainer = (boolean)" ".length();
   }

   protected boolean hasInvalidNeighbor(World var1, BlockPos var2) {
      int var10000;
      if (!this.isInvalidNeighbor(var1, var2, EnumFacing.NORTH) && !this.isInvalidNeighbor(var1, var2, EnumFacing.SOUTH) && !this.isInvalidNeighbor(var1, var2, EnumFacing.WEST) && !this.isInvalidNeighbor(var1, var2, EnumFacing.EAST)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (4 <= 2) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.INVISIBLE;
   }

   static {
      I();
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      super.breakBlock(var1, var2, var3);
      var1.removeTileEntity(var2);
   }

   protected boolean isInvalidNeighbor(World var1, BlockPos var2, EnumFacing var3) {
      int var10000;
      if (var1.getBlockState(var2.offset(var3)).getMaterial() == Material.CACTUS) {
         var10000 = " ".length();
         "".length();
         if (3 < 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }
}

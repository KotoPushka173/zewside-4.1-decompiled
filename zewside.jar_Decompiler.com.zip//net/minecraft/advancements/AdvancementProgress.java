package net.minecraft.advancements;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.JsonUtils;

public class AdvancementProgress implements Comparable<AdvancementProgress> {
   // $FF: synthetic field
   private final Map<String, CriterionProgress> field_192110_a = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private String[][] field_192111_b = new String["".length()][];

   public float func_192103_c() {
      if (this.field_192110_a.isEmpty()) {
         return 0.0F;
      } else {
         float var1 = (float)this.field_192111_b.length;
         float var2 = (float)this.func_194032_h();
         return var2 / var1;
      }
   }

   private static void I() {
      I = new String[115 ^ 67];
      I["".length()] = I("揵掕", "sPZaL");
      I[" ".length()] = I("煥漤", "Nqcsq");
      I["  ".length()] = I("汗忡", "dcKic");
      I["   ".length()] = I("嘎娾", "YJlnE");
      I[148 ^ 144] = I("婝泦噗枵勰", "TNdqX");
      I[131 ^ 134] = I("炾恆憫侒", "YBfNI");
      I[76 ^ 74] = I("斍據嫏捗嶆", "vWodf");
      I[105 ^ 110] = I("洧嬣抮欗", "fpHhK");
      I[146 ^ 154] = I("嵮", "QAoJI");
      I[49 ^ 56] = I("朾棧会", "dJEBN");
      I[207 ^ 197] = I("恐佁", "jUBfg");
      I[92 ^ 87] = I("嘬廃", "QcKSW");
      I[69 ^ 73] = I("澘妥", "gDYpB");
      I[19 ^ 30] = I("垹炡", "XKzMS");
      I[59 ^ 53] = I("煲娑嶿匑俾", "lprwk");
      I[146 ^ 157] = I("烁忄", "edIHC");
      I[89 ^ 73] = I("\u0018<\u001e\r\":=\u0005\t\"-\b\u001a\u0003++=\u001b\u001f7:*\u0001\u0018)+1\tQ", "YXhlL");
      I[109 ^ 124] = I("Yz!\" \u00003!\"<\u00104'4l", "uZSGQ");
      I[116 ^ 102] = I("柣偤壅榈清", "PyELt");
      I[150 ^ 133] = I("岟姾侁懀", "gjitW");
      I[8 ^ 28] = I("查奓", "pVplU");
      I[186 ^ 175] = I("劶", "ZybNv");
      I[78 ^ 88] = I("剽", "znSvq");
      I[13 ^ 26] = I("撵徃嵍垔", "Hnqha");
      I[219 ^ 195] = I("梡", "zxfkB");
      I[41 ^ 48] = I("壣", "liXaR");
      I[147 ^ 137] = I("湕乘", "RvPna");
      I[188 ^ 167] = I("嬊寫", "unclb");
      I[74 ^ 86] = I("匛悵", "vFBiH");
      I[24 ^ 5] = I("炔奶", "iBtwP");
      I[90 ^ 68] = I("汙启濵", "MZBSG");
      I[95 ^ 64] = I("屫擳佌橥尤", "nKJGm");
      I[136 ^ 168] = I("棘搘廮敱匒", "jBInb");
      I[48 ^ 17] = I("攏抖", "AMtwL");
      I[150 ^ 180] = I("掷忦槏", "yXAUJ");
      I[132 ^ 167] = I("囵浏", "XfICI");
      I[156 ^ 184] = I("清滏", "IgGoK");
      I[185 ^ 156] = I("棪濦", "KFoXr");
      I[49 ^ 23] = I("戨溘", "GqsFs");
      I[101 ^ 66] = I("上", "KQHvt");
      I[13 ^ 37] = I("昝朢於", "XBnez");
      I[132 ^ 173] = I("^", "qLmKE");
      I[59 ^ 17] = I("枟寫封安", "uscDv");
      I[130 ^ 169] = I("亄涶湄", "mcmOT");
      I[142 ^ 162] = I("命", "RbemW");
      I[14 ^ 35] = I("暢烬灂嗇", "isEnu");
      I[61 ^ 19] = I("劃檴嗵擪", "buAQe");
      I[2 ^ 45] = I("暇", "Whoyz");
   }

   public String toString() {
      String var10000 = I[190 ^ 180];
      String var10001 = I[122 ^ 113];
      String var10002 = I[135 ^ 139];
      var10001 = I[79 ^ 66];
      I[159 ^ 145].length();
      I[100 ^ 107].length();
      return I[25 ^ 9] + this.field_192110_a + I[178 ^ 163] + Arrays.deepToString(this.field_192111_b) + ('O' ^ '2');
   }

   public boolean func_192108_b() {
      Iterator var1 = this.field_192110_a.values().iterator();

      do {
         if (!var1.hasNext()) {
            return (boolean)"".length();
         }

         CriterionProgress var2 = (CriterionProgress)var1.next();
         if (var2.func_192151_a()) {
            return (boolean)" ".length();
         }

         "".length();
      } while(4 >= 3);

      throw null;
   }

   public boolean func_192105_a() {
      if (this.field_192111_b.length == 0) {
         return (boolean)"".length();
      } else {
         String[][] var1 = this.field_192111_b;
         int var2 = var1.length;
         int var3 = "".length();

         do {
            if (var3 >= var2) {
               return (boolean)" ".length();
            }

            String[] var4 = var1[var3];
            int var5 = "".length();
            String[] var6 = var4;
            int var7 = var4.length;
            int var8 = "".length();

            while(var8 < var7) {
               String var9 = var6[var8];
               CriterionProgress var10 = this.func_192106_c(var9);
               if (var10 != null && var10.func_192151_a()) {
                  var5 = " ".length();
                  "".length();
                  if (3 < 3) {
                     throw null;
                  }
                  break;
               }

               ++var8;
               "".length();
               if (1 < 1) {
                  throw null;
               }
            }

            if (var5 == 0) {
               return (boolean)"".length();
            }

            ++var3;
            "".length();
         } while(1 != -1);

         throw null;
      }
   }

   @Nullable
   public Date func_193128_g() {
      Date var1 = null;
      Iterator var2 = this.field_192110_a.values().iterator();

      do {
         if (!var2.hasNext()) {
            return var1;
         }

         CriterionProgress var3 = (CriterionProgress)var2.next();
         if (var3.func_192151_a() && (var1 == null || var3.func_193140_d().before(var1))) {
            var1 = var3.func_193140_d();
         }

         "".length();
      } while(3 >= 1);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 3);

      throw null;
   }

   private int func_194032_h() {
      int var1 = "".length();
      String[][] var2 = this.field_192111_b;
      int var3 = var2.length;
      int var4 = "".length();

      do {
         if (var4 >= var3) {
            return var1;
         }

         String[] var5 = var2[var4];
         int var6 = "".length();
         String[] var7 = var5;
         int var8 = var5.length;
         int var9 = "".length();

         while(var9 < var8) {
            String var10 = var7[var9];
            CriterionProgress var11 = this.func_192106_c(var10);
            if (var11 != null && var11.func_192151_a()) {
               var6 = " ".length();
               "".length();
               if (-1 != -1) {
                  throw null;
               }
               break;
            }

            ++var9;
            "".length();
            if (-1 >= 1) {
               throw null;
            }
         }

         if (var6 != 0) {
            ++var1;
         }

         ++var4;
         "".length();
      } while(0 > -1);

      throw null;
   }

   public static AdvancementProgress func_192100_b(PacketBuffer var0) {
      String var10000 = I[217 ^ 195];
      String var10001 = I[82 ^ 73];
      String var10002 = I[177 ^ 173];
      var10001 = I[64 ^ 93];
      I[36 ^ 58].length();
      I[37 ^ 58].length();
      AdvancementProgress var1 = new AdvancementProgress();
      int var2 = var0.readVarIntFromBuffer();
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            return var1;
         }

         var1.field_192110_a.put(var0.readStringFromBuffer(10764 + 13070 - 22918 + 31851), CriterionProgress.func_192149_a(var0, var1));
         I[172 ^ 140].length();
         I[34 ^ 3].length();
         I[157 ^ 191].length();
         ++var3;
         "".length();
      } while(2 != 0);

      throw null;
   }

   static {
      I();
   }

   @Nullable
   public CriterionProgress func_192106_c(String var1) {
      return (CriterionProgress)this.field_192110_a.get(var1);
   }

   public Iterable<String> func_192107_d() {
      ArrayList var1 = Lists.newArrayList();
      Iterator var2 = this.field_192110_a.entrySet().iterator();

      do {
         if (!var2.hasNext()) {
            return var1;
         }

         Entry var3 = (Entry)var2.next();
         if (!((CriterionProgress)var3.getValue()).func_192151_a()) {
            var1.add(var3.getKey());
            I[52 ^ 30].length();
            I[93 ^ 118].length();
            I[83 ^ 127].length();
            I[121 ^ 84].length();
         }

         "".length();
      } while(-1 == -1);

      throw null;
   }

   public Iterable<String> func_192102_e() {
      ArrayList var1 = Lists.newArrayList();
      Iterator var2 = this.field_192110_a.entrySet().iterator();

      do {
         if (!var2.hasNext()) {
            return var1;
         }

         Entry var3 = (Entry)var2.next();
         if (((CriterionProgress)var3.getValue()).func_192151_a()) {
            var1.add(var3.getKey());
            I[141 ^ 163].length();
            I[56 ^ 23].length();
         }

         "".length();
      } while(2 > 0);

      throw null;
   }

   public void func_192104_a(PacketBuffer var1) {
      var1.writeVarIntToBuffer(this.field_192110_a.size());
      I[74 ^ 88].length();
      I[152 ^ 139].length();
      I[77 ^ 89].length();
      I[134 ^ 147].length();
      I[107 ^ 125].length();
      Iterator var2 = this.field_192110_a.entrySet().iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         Entry var3 = (Entry)var2.next();
         var1.writeString((String)var3.getKey());
         I[168 ^ 191].length();
         I[182 ^ 174].length();
         I[187 ^ 162].length();
         ((CriterionProgress)var3.getValue()).func_192150_a(var1);
         "".length();
      } while(0 != 3);

      throw null;
   }

   public boolean func_192109_a(String var1) {
      CriterionProgress var2 = (CriterionProgress)this.field_192110_a.get(var1);
      if (var2 != null && !var2.func_192151_a()) {
         var2.func_192153_b();
         return (boolean)" ".length();
      } else {
         return (boolean)"".length();
      }
   }

   public void func_192099_a(Map<String, Criterion> var1, String[][] var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      Set var3 = var1.keySet();
      Iterator var4 = this.field_192110_a.entrySet().iterator();

      do {
         if (!var4.hasNext()) {
            Iterator var7 = var3.iterator();

            do {
               if (!var7.hasNext()) {
                  this.field_192111_b = var2;
                  return;
               }

               String var6 = (String)var7.next();
               if (!this.field_192110_a.containsKey(var6)) {
                  Map var8 = this.field_192110_a;
                  I[32 ^ 36].length();
                  I[149 ^ 144].length();
                  I[118 ^ 112].length();
                  I[102 ^ 97].length();
                  var8.put(var6, new CriterionProgress(this));
                  I[186 ^ 178].length();
                  I[39 ^ 46].length();
               }

               "".length();
            } while(4 > 1);

            throw null;
         }

         Entry var5 = (Entry)var4.next();
         if (!var3.contains(var5.getKey())) {
            var4.remove();
         }

         "".length();
      } while(0 != -1);

      throw null;
   }

   public boolean func_192101_b(String var1) {
      CriterionProgress var2 = (CriterionProgress)this.field_192110_a.get(var1);
      if (var2 != null && var2.func_192151_a()) {
         var2.func_192154_c();
         return (boolean)" ".length();
      } else {
         return (boolean)"".length();
      }
   }

   @Nullable
   public String func_193126_d() {
      String var10000 = I[53 ^ 22];
      String var10001 = I[37 ^ 1];
      String var10002 = I[135 ^ 162];
      var10001 = I[18 ^ 52];
      if (this.field_192110_a.isEmpty()) {
         return null;
      } else {
         int var1 = this.field_192111_b.length;
         if (var1 <= " ".length()) {
            return null;
         } else {
            int var2 = this.func_194032_h();
            I[66 ^ 101].length();
            I[28 ^ 52].length();
            return var2 + I[15 ^ 38] + var1;
         }
      }
   }

   public int compareTo(AdvancementProgress var1) {
      Date var2 = this.func_193128_g();
      Date var3 = var1.func_193128_g();
      if (var2 == null && var3 != null) {
         return " ".length();
      } else if (var2 != null && var3 == null) {
         return -" ".length();
      } else {
         int var10000;
         if (var2 == null && var3 == null) {
            var10000 = "".length();
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10000 = var2.compareTo(var3);
         }

         return var10000;
      }
   }

   public static class Serializer implements JsonDeserializer<AdvancementProgress>, JsonSerializer<AdvancementProgress> {
      // $FF: synthetic field
      private static final String[] I;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 < 3);

         throw null;
      }

      public JsonElement serialize(AdvancementProgress var1, Type var2, JsonSerializationContext var3) {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         var10000 = I[4 ^ 0];
         var10001 = I[150 ^ 147];
         var10002 = I[33 ^ 39];
         var10001 = I[191 ^ 184];
         I[151 ^ 159].length();
         I[27 ^ 18].length();
         I[168 ^ 162].length();
         I[24 ^ 19].length();
         JsonObject var4 = new JsonObject();
         I[98 ^ 110].length();
         I[134 ^ 139].length();
         JsonObject var5 = new JsonObject();
         Iterator var6 = var1.field_192110_a.entrySet().iterator();

         do {
            if (!var6.hasNext()) {
               if (!var5.entrySet().isEmpty()) {
                  var4.add(I[127 ^ 113], var5);
               }

               var4.addProperty(I[63 ^ 48], var1.func_192105_a());
               return var4;
            }

            Entry var7 = (Entry)var6.next();
            CriterionProgress var8 = (CriterionProgress)var7.getValue();
            if (var8.func_192151_a()) {
               var5.add((String)var7.getKey(), var8.func_192148_e());
            }

            "".length();
         } while(2 == 2);

         throw null;
      }

      public AdvancementProgress deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         String var10000 = I[187 ^ 171];
         String var10001 = I[132 ^ 149];
         String var10002 = I[152 ^ 138];
         var10001 = I[210 ^ 193];
         var10000 = I[176 ^ 164];
         var10001 = I[56 ^ 45];
         var10002 = I[86 ^ 64];
         var10001 = I[70 ^ 81];
         JsonObject var4 = JsonUtils.getJsonObject(var1, I[20 ^ 12]);
         var10001 = I[136 ^ 145];
         I[107 ^ 113].length();
         I[26 ^ 1].length();
         I[123 ^ 103].length();
         I[12 ^ 17].length();
         I[136 ^ 150].length();
         JsonObject var5 = JsonUtils.getJsonObject(var4, var10001, new JsonObject());
         I[7 ^ 24].length();
         I[37 ^ 5].length();
         AdvancementProgress var6 = new AdvancementProgress();
         Iterator var7 = var5.entrySet().iterator();

         do {
            if (!var7.hasNext()) {
               return var6;
            }

            Entry var8 = (Entry)var7.next();
            String var9 = (String)var8.getKey();
            var6.field_192110_a.put(var9, CriterionProgress.func_192152_a(var6, JsonUtils.getString((JsonElement)var8.getValue(), var9)));
            I[83 ^ 114].length();
            I[229 ^ 199].length();
            I[124 ^ 95].length();
            "".length();
         } while(true);

         throw null;
      }

      static {
         I();
      }

      private static void I() {
         I = new String[35 ^ 7];
         I["".length()] = I("氉嬤", "KqsCx");
         I[" ".length()] = I("嗈噲", "lOBlM");
         I["  ".length()] = I("匬屿", "vTybr");
         I["   ".length()] = I("卞濵", "uGJQw");
         I[1 ^ 5] = I("洺呣", "iDxkm");
         I[140 ^ 137] = I("挭崨", "fpkwZ");
         I[100 ^ 98] = I("湚奔", "pGNcO");
         I[123 ^ 124] = I("挩烆", "xcGOd");
         I[132 ^ 140] = I("枍仵", "kRFgl");
         I[127 ^ 118] = I("侾江扬埠", "MvbmP");
         I[168 ^ 162] = I("偵", "VwuDC");
         I[102 ^ 109] = I("嫌灼唠劄", "Rppxi");
         I[65 ^ 77] = I("炃埚漄俜撲", "qoplj");
         I[179 ^ 190] = I("中崪漈恤濔", "zYDJZ");
         I[89 ^ 87] = I("\u000b\u0011\u000f\"\u0011\u001a\n\u0007", "hcfVt");
         I[26 ^ 21] = I("1(\u000f\u001d", "UGaxM");
         I[191 ^ 175] = I("暳卅", "vUKEd");
         I[110 ^ 127] = I("巆嚟", "plXxX");
         I[105 ^ 123] = I("愾倬", "SBEXU");
         I[20 ^ 7] = I("昷左", "xQvUG");
         I[84 ^ 64] = I("戮堢", "zpkZt");
         I[186 ^ 175] = I("名洍", "OTOKf");
         I[60 ^ 42] = I("櫭擻", "bJRPZ");
         I[92 ^ 75] = I("儅劦", "YDgtp");
         I[129 ^ 153] = I("\u001b\b9\u0002\u000b\u0019\t\"\u0006\u000b\u000e", "zlOce");
         I[72 ^ 81] = I("\r9\u0013%\u000f\u001c\"\u001b", "nKzQj");
         I[23 ^ 13] = I("滽婇塠梉墝", "FoHOf");
         I[42 ^ 49] = I("娙庎橚", "tsSDw");
         I[21 ^ 9] = I("湼佡暶", "XmVRz");
         I[217 ^ 196] = I("滙愐哐", "uMstB");
         I[72 ^ 86] = I("泤垡奓帟徕", "rrTOb");
         I[150 ^ 137] = I("圑櫇堾", "hRqnP");
         I[118 ^ 86] = I("宨涷嫟", "OMTkE");
         I[77 ^ 108] = I("刴喘瀟妬亖", "hdwSz");
         I[148 ^ 182] = I("堟", "NFokh");
         I[47 ^ 12] = I("偝柺佹", "lrLmQ");
      }
   }
}

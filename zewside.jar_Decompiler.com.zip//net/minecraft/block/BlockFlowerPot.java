package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityFlowerPot;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.ChunkCache;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;

public class BlockFlowerPot extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB FLOWER_POT_AABB;
   // $FF: synthetic field
   public static final PropertyInteger LEGACY_DATA;
   // $FF: synthetic field
   public static final PropertyEnum<BlockFlowerPot.EnumFlowerType> CONTENTS;

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      BlockFlowerPot.EnumFlowerType var4 = BlockFlowerPot.EnumFlowerType.EMPTY;
      TileEntity var10000;
      if (var2 instanceof ChunkCache) {
         var10000 = ((ChunkCache)var2).getTileEntity(var3, Chunk.EnumCreateEntityType.CHECK);
         "".length();
         if (3 < 2) {
            throw null;
         }
      } else {
         var10000 = var2.getTileEntity(var3);
      }

      TileEntity var5 = var10000;
      if (var5 instanceof TileEntityFlowerPot) {
         TileEntityFlowerPot var6 = (TileEntityFlowerPot)var5;
         Item var7 = var6.getFlowerPotItem();
         if (var7 instanceof ItemBlock) {
            int var8 = var6.getFlowerPotData();
            Block var9 = Block.getBlockFromItem(var7);
            if (var9 == Blocks.SAPLING) {
               switch(null.$SwitchMap$net$minecraft$block$BlockPlanks$EnumType[BlockPlanks.EnumType.byMetadata(var8).ordinal()]) {
               case 1:
                  var4 = BlockFlowerPot.EnumFlowerType.OAK_SAPLING;
                  "".length();
                  if (3 < 3) {
                     throw null;
                  }
                  break;
               case 2:
                  var4 = BlockFlowerPot.EnumFlowerType.SPRUCE_SAPLING;
                  "".length();
                  if (0 == 2) {
                     throw null;
                  }
                  break;
               case 3:
                  var4 = BlockFlowerPot.EnumFlowerType.BIRCH_SAPLING;
                  "".length();
                  if (2 <= -1) {
                     throw null;
                  }
                  break;
               case 4:
                  var4 = BlockFlowerPot.EnumFlowerType.JUNGLE_SAPLING;
                  "".length();
                  if (1 >= 2) {
                     throw null;
                  }
                  break;
               case 5:
                  var4 = BlockFlowerPot.EnumFlowerType.ACACIA_SAPLING;
                  "".length();
                  if (4 <= 2) {
                     throw null;
                  }
                  break;
               case 6:
                  var4 = BlockFlowerPot.EnumFlowerType.DARK_OAK_SAPLING;
                  "".length();
                  if (false) {
                     throw null;
                  }
                  break;
               default:
                  var4 = BlockFlowerPot.EnumFlowerType.EMPTY;
                  "".length();
                  if (2 < 0) {
                     throw null;
                  }
               }
            } else if (var9 == Blocks.TALLGRASS) {
               switch(var8) {
               case 0:
                  var4 = BlockFlowerPot.EnumFlowerType.DEAD_BUSH;
                  "".length();
                  if (2 >= 3) {
                     throw null;
                  }
                  break;
               case 2:
                  var4 = BlockFlowerPot.EnumFlowerType.FERN;
                  "".length();
                  if (0 == -1) {
                     throw null;
                  }
                  break;
               default:
                  var4 = BlockFlowerPot.EnumFlowerType.EMPTY;
                  "".length();
                  if (3 == 0) {
                     throw null;
                  }
               }
            } else if (var9 == Blocks.YELLOW_FLOWER) {
               var4 = BlockFlowerPot.EnumFlowerType.DANDELION;
               "".length();
               if (2 == -1) {
                  throw null;
               }
            } else if (var9 == Blocks.RED_FLOWER) {
               switch(null.$SwitchMap$net$minecraft$block$BlockFlower$EnumFlowerType[BlockFlower.EnumFlowerType.getType(BlockFlower.EnumFlowerColor.RED, var8).ordinal()]) {
               case 1:
                  var4 = BlockFlowerPot.EnumFlowerType.POPPY;
                  "".length();
                  if (4 == 3) {
                     throw null;
                  }
                  break;
               case 2:
                  var4 = BlockFlowerPot.EnumFlowerType.BLUE_ORCHID;
                  "".length();
                  if (-1 < -1) {
                     throw null;
                  }
                  break;
               case 3:
                  var4 = BlockFlowerPot.EnumFlowerType.ALLIUM;
                  "".length();
                  if (3 < 3) {
                     throw null;
                  }
                  break;
               case 4:
                  var4 = BlockFlowerPot.EnumFlowerType.HOUSTONIA;
                  "".length();
                  if (4 <= 0) {
                     throw null;
                  }
                  break;
               case 5:
                  var4 = BlockFlowerPot.EnumFlowerType.RED_TULIP;
                  "".length();
                  if (4 <= 3) {
                     throw null;
                  }
                  break;
               case 6:
                  var4 = BlockFlowerPot.EnumFlowerType.ORANGE_TULIP;
                  "".length();
                  if (3 == 4) {
                     throw null;
                  }
                  break;
               case 7:
                  var4 = BlockFlowerPot.EnumFlowerType.WHITE_TULIP;
                  "".length();
                  if (4 < 3) {
                     throw null;
                  }
                  break;
               case 8:
                  var4 = BlockFlowerPot.EnumFlowerType.PINK_TULIP;
                  "".length();
                  if (-1 < -1) {
                     throw null;
                  }
                  break;
               case 9:
                  var4 = BlockFlowerPot.EnumFlowerType.OXEYE_DAISY;
                  "".length();
                  if (3 <= 0) {
                     throw null;
                  }
                  break;
               default:
                  var4 = BlockFlowerPot.EnumFlowerType.EMPTY;
                  "".length();
                  if (4 < 0) {
                     throw null;
                  }
               }
            } else if (var9 == Blocks.RED_MUSHROOM) {
               var4 = BlockFlowerPot.EnumFlowerType.MUSHROOM_RED;
               "".length();
               if (2 == -1) {
                  throw null;
               }
            } else if (var9 == Blocks.BROWN_MUSHROOM) {
               var4 = BlockFlowerPot.EnumFlowerType.MUSHROOM_BROWN;
               "".length();
               if (4 != 4) {
                  throw null;
               }
            } else if (var9 == Blocks.DEADBUSH) {
               var4 = BlockFlowerPot.EnumFlowerType.DEAD_BUSH;
               "".length();
               if (2 >= 4) {
                  throw null;
               }
            } else if (var9 == Blocks.CACTUS) {
               var4 = BlockFlowerPot.EnumFlowerType.CACTUS;
            }
         }
      }

      return var1.withProperty(CONTENTS, var4);
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[68 ^ 84];
      String var10001 = I[35 ^ 50];
      String var10002 = I[187 ^ 169];
      var10001 = I[96 ^ 115];
      Object var3 = null;
      int var4 = "".length();
      switch(var2) {
      case 1:
         var3 = Blocks.RED_FLOWER;
         var4 = BlockFlower.EnumFlowerType.POPPY.getMeta();
         "".length();
         if (4 <= -1) {
            throw null;
         }
         break;
      case 2:
         var3 = Blocks.YELLOW_FLOWER;
         "".length();
         if (2 <= 1) {
            throw null;
         }
         break;
      case 3:
         var3 = Blocks.SAPLING;
         var4 = BlockPlanks.EnumType.OAK.getMetadata();
         "".length();
         if (3 < 2) {
            throw null;
         }
         break;
      case 4:
         var3 = Blocks.SAPLING;
         var4 = BlockPlanks.EnumType.SPRUCE.getMetadata();
         "".length();
         if (3 < 3) {
            throw null;
         }
         break;
      case 5:
         var3 = Blocks.SAPLING;
         var4 = BlockPlanks.EnumType.BIRCH.getMetadata();
         "".length();
         if (0 >= 1) {
            throw null;
         }
         break;
      case 6:
         var3 = Blocks.SAPLING;
         var4 = BlockPlanks.EnumType.JUNGLE.getMetadata();
         "".length();
         if (2 <= 0) {
            throw null;
         }
         break;
      case 7:
         var3 = Blocks.RED_MUSHROOM;
         "".length();
         if (3 == 0) {
            throw null;
         }
         break;
      case 8:
         var3 = Blocks.BROWN_MUSHROOM;
         "".length();
         if (2 < 2) {
            throw null;
         }
         break;
      case 9:
         var3 = Blocks.CACTUS;
         "".length();
         if (0 >= 4) {
            throw null;
         }
         break;
      case 10:
         var3 = Blocks.DEADBUSH;
         "".length();
         if (3 <= -1) {
            throw null;
         }
         break;
      case 11:
         var3 = Blocks.TALLGRASS;
         var4 = BlockTallGrass.EnumType.FERN.getMeta();
         "".length();
         if (4 == 0) {
            throw null;
         }
         break;
      case 12:
         var3 = Blocks.SAPLING;
         var4 = BlockPlanks.EnumType.ACACIA.getMetadata();
         "".length();
         if (2 <= 1) {
            throw null;
         }
         break;
      case 13:
         var3 = Blocks.SAPLING;
         var4 = BlockPlanks.EnumType.DARK_OAK.getMetadata();
      }

      I[179 ^ 167].length();
      I[82 ^ 71].length();
      I[7 ^ 17].length();
      return new TileEntityFlowerPot(Item.getItemFromBlock((Block)var3), var4);
   }

   static {
      I();
      LEGACY_DATA = PropertyInteger.create(I[13 ^ 36], "".length(), 161 ^ 174);
      CONTENTS = PropertyEnum.create(I[51 ^ 25], BlockFlowerPot.EnumFlowerType.class);
      FLOWER_POT_AABB = new AxisAlignedBB(0.3125D, 0.0D, 0.3125D, 0.6875D, 0.375D, 0.6875D);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   @Nullable
   private TileEntityFlowerPot getTileEntity(World var1, BlockPos var2) {
      TileEntity var3 = var1.getTileEntity(var2);
      TileEntityFlowerPot var10000;
      if (var3 instanceof TileEntityFlowerPot) {
         var10000 = (TileEntityFlowerPot)var3;
         "".length();
         if (1 < 1) {
            throw null;
         }
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public void onBlockHarvested(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      super.onBlockHarvested(var1, var2, var3, var4);
      if (var4.capabilities.isCreativeMode) {
         TileEntityFlowerPot var5 = this.getTileEntity(var1, var2);
         if (var5 != null) {
            var5.func_190614_a(ItemStack.field_190927_a);
         }
      }

   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["   ".length()];
      String var10001 = I[49 ^ 53];
      String var10002 = I[45 ^ 40];
      var10001 = I[124 ^ 122];
      TileEntityFlowerPot var4 = this.getTileEntity(var1, var2);
      if (var4 != null) {
         ItemStack var5 = var4.getFlowerItemStack();
         if (!var5.isEmpty()) {
            return var5;
         }
      }

      I[17 ^ 22].length();
      I[13 ^ 5].length();
      return new ItemStack(Items.FLOWER_POT);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.FLOWER_POT;
   }

   private boolean func_190951_a(ItemStack var1) {
      Block var2 = Block.getBlockFromItem(var1.getItem());
      if (var2 != Blocks.YELLOW_FLOWER && var2 != Blocks.RED_FLOWER && var2 != Blocks.CACTUS && var2 != Blocks.BROWN_MUSHROOM && var2 != Blocks.RED_MUSHROOM && var2 != Blocks.SAPLING && var2 != Blocks.DEADBUSH) {
         int var3 = var1.getMetadata();
         int var10000;
         if (var2 == Blocks.TALLGRASS && var3 == BlockTallGrass.EnumType.FERN.getMeta()) {
            var10000 = " ".length();
            "".length();
            if (-1 >= 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      } else {
         return (boolean)" ".length();
      }
   }

   private static void I() {
      I = new String[33 ^ 10];
      I["".length()] = I("\u0007\u0007\u001f#F\b\u001f\u00159\r\u001c#\u0015:F\u0000\u0012\u0017+", "nszNh");
      I[" ".length()] = I("灩凨妾", "hpSbo");
      I["  ".length()] = I("嬂晢懃憦", "NKshe");
      I["   ".length()] = I("旛妵", "XHZyc");
      I[158 ^ 154] = I("奀孼", "YknCG");
      I[121 ^ 124] = I("汬叼", "croTc");
      I[175 ^ 169] = I("堞烖", "JyjZd");
      I[125 ^ 122] = I("廷", "IbYDY");
      I[2 ^ 10] = I("亗", "lfFqI");
      I[121 ^ 112] = I("柪歒垆", "yfplr");
      I[174 ^ 164] = I("噙尨欀", "UAZBH");
      I[70 ^ 77] = I("擡叜", "DjVLv");
      I[43 ^ 39] = I("哂氬", "mLNgc");
      I[150 ^ 155] = I("伏嬩", "bTSTW");
      I[128 ^ 142] = I("愝劖", "fMFDy");
      I[142 ^ 129] = I("孋岆俸", "uvEfd");
      I[87 ^ 71] = I("債橄", "yKzJh");
      I[90 ^ 75] = I("晐剏", "MOWrV");
      I[106 ^ 120] = I("慵媉", "WwSEl");
      I[30 ^ 13] = I("冨媭", "qKexP");
      I[83 ^ 71] = I("入瀝槂", "Yvvsf");
      I[5 ^ 16] = I("焉嗂煶寚", "JwZkO");
      I[14 ^ 24] = I("愙", "YuyUh");
      I[62 ^ 41] = I("嬋叡", "uAYYw");
      I[45 ^ 53] = I("儉泓", "MZojW");
      I[2 ^ 27] = I("櫍昃", "XYkRU");
      I[93 ^ 71] = I("毢枬", "YKDKI");
      I[24 ^ 3] = I("彻湔", "STIDk");
      I[8 ^ 20] = I("椨喇", "EfySx");
      I[170 ^ 183] = I("嚗橙", "FuYTt");
      I[128 ^ 158] = I("夹濷", "pKsAp");
      I[57 ^ 38] = I("嬉忇", "fucbz");
      I[176 ^ 144] = I("毹妺", "aLnjr");
      I[134 ^ 167] = I("煠扥", "hFMVQ");
      I[124 ^ 94] = I("汤涯", "EyuFn");
      I[46 ^ 13] = I("朏", "QHvcP");
      I[2 ^ 38] = I("戎婸泑堺", "WONTZ");
      I[90 ^ 127] = I("椮", "ymZjL");
      I[21 ^ 51] = I("榤柦敇", "SqvHG");
      I[121 ^ 94] = I("沺懄汬框听", "shSwk");
      I[55 ^ 31] = I("嬋枩", "ZqGBz");
      I[190 ^ 151] = I("\u0001'!(\u0007\u0014\u001d\"(\u0010\f", "mBFId");
      I[78 ^ 100] = I("\u000b(/&!\u000632", "hGARD");
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (super.canPlaceBlockAt(var1, var2) && var1.getBlockState(var2.down()).isFullyOpaque()) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(LEGACY_DATA);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public String getLocalizedName() {
      return I18n.translateToLocal(I["".length()]);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.getBlockState(var3.down()).isFullyOpaque()) {
         this.dropBlockAsItem(var2, var3, var1, "".length());
         var2.setBlockToAir(var3);
         I[161 ^ 168].length();
         I[47 ^ 37].length();
      }

   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[46 ^ 37];
      String var10001 = I[103 ^ 107];
      String var10002 = I[137 ^ 132];
      var10001 = I[115 ^ 125];
      TileEntityFlowerPot var4 = this.getTileEntity(var1, var2);
      if (var4 != null && var4.getFlowerPotItem() != null) {
         I[124 ^ 115].length();
         spawnAsEntity(var1, var2, new ItemStack(var4.getFlowerPotItem(), " ".length(), var4.getFlowerPotData()));
      }

      super.breakBlock(var1, var2, var3);
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public BlockFlowerPot() {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(CONTENTS, BlockFlowerPot.EnumFlowerType.EMPTY).withProperty(LEGACY_DATA, "".length()));
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[67 ^ 84];
      String var10001 = I[57 ^ 33];
      String var10002 = I[4 ^ 29];
      var10001 = I[88 ^ 66];
      var10000 = I[97 ^ 122];
      var10001 = I[60 ^ 32];
      var10002 = I[40 ^ 53];
      var10001 = I[21 ^ 11];
      var10000 = I[120 ^ 103];
      var10001 = I[13 ^ 45];
      var10002 = I[84 ^ 117];
      var10001 = I[31 ^ 61];
      I[158 ^ 189].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[71 ^ 99].length();
      I[8 ^ 45].length();
      var10003["".length()] = CONTENTS;
      I[169 ^ 143].length();
      I[117 ^ 82].length();
      I[36 ^ 12].length();
      var10003[" ".length()] = LEGACY_DATA;
      return new BlockStateContainer(this, var10003);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return FLOWER_POT_AABB;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      ItemStack var10 = var4.getHeldItem(var5);
      TileEntityFlowerPot var11 = this.getTileEntity(var1, var2);
      if (var11 == null) {
         return (boolean)"".length();
      } else {
         ItemStack var12 = var11.getFlowerItemStack();
         if (var12.isEmpty()) {
            if (!this.func_190951_a(var10)) {
               return (boolean)"".length();
            }

            var11.func_190614_a(var10);
            var4.addStat(StatList.FLOWER_POTTED);
            if (!var4.capabilities.isCreativeMode) {
               var10.func_190918_g(" ".length());
               "".length();
               if (4 <= 3) {
                  throw null;
               }
            }
         } else {
            if (var10.isEmpty()) {
               var4.setHeldItem(var5, var12);
               "".length();
               if (2 < -1) {
                  throw null;
               }
            } else if (!var4.func_191521_c(var12)) {
               var4.dropItem(var12, (boolean)"".length());
               I[" ".length()].length();
               I["  ".length()].length();
            }

            var11.func_190614_a(ItemStack.field_190927_a);
         }

         var11.markDirty();
         var1.notifyBlockUpdate(var2, var3, var3, "   ".length());
         return (boolean)" ".length();
      }
   }

   public static enum EnumFlowerType implements IStringSerializable {
      // $FF: synthetic field
      ACACIA_SAPLING,
      // $FF: synthetic field
      ALLIUM,
      // $FF: synthetic field
      ORANGE_TULIP,
      // $FF: synthetic field
      MUSHROOM_RED,
      // $FF: synthetic field
      DANDELION,
      // $FF: synthetic field
      JUNGLE_SAPLING,
      // $FF: synthetic field
      DARK_OAK_SAPLING,
      // $FF: synthetic field
      CACTUS,
      // $FF: synthetic field
      PINK_TULIP,
      // $FF: synthetic field
      POPPY,
      // $FF: synthetic field
      BIRCH_SAPLING,
      // $FF: synthetic field
      DEAD_BUSH,
      // $FF: synthetic field
      SPRUCE_SAPLING,
      // $FF: synthetic field
      EMPTY,
      // $FF: synthetic field
      RED_TULIP,
      // $FF: synthetic field
      BLUE_ORCHID,
      // $FF: synthetic field
      OAK_SAPLING,
      // $FF: synthetic field
      MUSHROOM_BROWN,
      // $FF: synthetic field
      WHITE_TULIP;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      OXEYE_DAISY,
      // $FF: synthetic field
      FERN,
      // $FF: synthetic field
      HOUSTONIA;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 < 4);

         throw null;
      }

      static {
         I();
         EMPTY = new BlockFlowerPot.EnumFlowerType(I["".length()], "".length(), I[" ".length()]);
         POPPY = new BlockFlowerPot.EnumFlowerType(I["  ".length()], " ".length(), I["   ".length()]);
         BLUE_ORCHID = new BlockFlowerPot.EnumFlowerType(I[181 ^ 177], "  ".length(), I[15 ^ 10]);
         ALLIUM = new BlockFlowerPot.EnumFlowerType(I[101 ^ 99], "   ".length(), I[194 ^ 197]);
         HOUSTONIA = new BlockFlowerPot.EnumFlowerType(I[158 ^ 150], 96 ^ 100, I[205 ^ 196]);
         RED_TULIP = new BlockFlowerPot.EnumFlowerType(I[162 ^ 168], 151 ^ 146, I[71 ^ 76]);
         ORANGE_TULIP = new BlockFlowerPot.EnumFlowerType(I[136 ^ 132], 96 ^ 102, I[17 ^ 28]);
         WHITE_TULIP = new BlockFlowerPot.EnumFlowerType(I[4 ^ 10], 90 ^ 93, I[203 ^ 196]);
         PINK_TULIP = new BlockFlowerPot.EnumFlowerType(I[156 ^ 140], 123 ^ 115, I[131 ^ 146]);
         OXEYE_DAISY = new BlockFlowerPot.EnumFlowerType(I[191 ^ 173], 52 ^ 61, I[89 ^ 74]);
         DANDELION = new BlockFlowerPot.EnumFlowerType(I[105 ^ 125], 155 ^ 145, I[209 ^ 196]);
         OAK_SAPLING = new BlockFlowerPot.EnumFlowerType(I[22 ^ 0], 101 ^ 110, I[101 ^ 114]);
         SPRUCE_SAPLING = new BlockFlowerPot.EnumFlowerType(I[8 ^ 16], 11 ^ 7, I[151 ^ 142]);
         BIRCH_SAPLING = new BlockFlowerPot.EnumFlowerType(I[177 ^ 171], 132 ^ 137, I[50 ^ 41]);
         JUNGLE_SAPLING = new BlockFlowerPot.EnumFlowerType(I[126 ^ 98], 160 ^ 174, I[219 ^ 198]);
         ACACIA_SAPLING = new BlockFlowerPot.EnumFlowerType(I[49 ^ 47], 117 ^ 122, I[103 ^ 120]);
         DARK_OAK_SAPLING = new BlockFlowerPot.EnumFlowerType(I[38 ^ 6], 105 ^ 121, I[97 ^ 64]);
         MUSHROOM_RED = new BlockFlowerPot.EnumFlowerType(I[24 ^ 58], 153 ^ 136, I[89 ^ 122]);
         MUSHROOM_BROWN = new BlockFlowerPot.EnumFlowerType(I[106 ^ 78], 213 ^ 199, I[67 ^ 102]);
         DEAD_BUSH = new BlockFlowerPot.EnumFlowerType(I[138 ^ 172], 26 ^ 9, I[18 ^ 53]);
         FERN = new BlockFlowerPot.EnumFlowerType(I[180 ^ 156], 11 ^ 31, I[155 ^ 178]);
         CACTUS = new BlockFlowerPot.EnumFlowerType(I[136 ^ 162], 10 ^ 31, I[234 ^ 193]);
         BlockFlowerPot.EnumFlowerType[] var10000 = new BlockFlowerPot.EnumFlowerType[141 ^ 155];
         var10000["".length()] = EMPTY;
         var10000[" ".length()] = POPPY;
         var10000["  ".length()] = BLUE_ORCHID;
         var10000["   ".length()] = ALLIUM;
         var10000[153 ^ 157] = HOUSTONIA;
         var10000[53 ^ 48] = RED_TULIP;
         var10000[133 ^ 131] = ORANGE_TULIP;
         var10000[104 ^ 111] = WHITE_TULIP;
         var10000[45 ^ 37] = PINK_TULIP;
         var10000[62 ^ 55] = OXEYE_DAISY;
         var10000[18 ^ 24] = DANDELION;
         var10000[114 ^ 121] = OAK_SAPLING;
         var10000[62 ^ 50] = SPRUCE_SAPLING;
         var10000[168 ^ 165] = BIRCH_SAPLING;
         var10000[21 ^ 27] = JUNGLE_SAPLING;
         var10000[145 ^ 158] = ACACIA_SAPLING;
         var10000[190 ^ 174] = DARK_OAK_SAPLING;
         var10000[147 ^ 130] = MUSHROOM_RED;
         var10000[70 ^ 84] = MUSHROOM_BROWN;
         var10000[164 ^ 183] = DEAD_BUSH;
         var10000[148 ^ 128] = FERN;
         var10000[33 ^ 52] = CACTUS;
      }

      public String toString() {
         return this.name;
      }

      private static void I() {
         I = new String[154 ^ 182];
         I["".length()] = I("..(\u0011\u000b", "kcxER");
         I[" ".length()] = I("\u0016\u000e\"\u0011\u0001", "scRex");
         I["  ".length()] = I("'\u0003\u0000\u0003/", "wLPSv");
         I["   ".length()] = I("&77\u0011", "TXDtO");
         I[43 ^ 47] = I("\u0013+> \u001b\u001e5(-\r\u0015", "QgkeD");
         I[96 ^ 101] = I("#;\u0006!\u0015.%\u0010,#%", "AWsDJ");
         I[199 ^ 193] = I("1\u0004\u000f\u001b\u0014=", "pHCRA");
         I[143 ^ 136] = I("\u0017*4=#\u001b", "vFXTV");
         I[123 ^ 115] = I("\u0019+\u0004\u0003,\u001e*\u0018\u0011", "QdQPx");
         I[82 ^ 91] = I("\u0011\u001b:\u0001!\u0016\u001a&\u0013", "ytOrU");
         I[30 ^ 20] = I(":\u0011#0;=\u0018.?", "hTgoo");
         I[109 ^ 102] = I("\u0018'\t,=\u001f.\u0004\u0003", "jBmsI");
         I[11 ^ 7] = I("\"1-?\t(<8$\u0002$3", "mclqN");
         I[30 ^ 19] = I("\u0001\u00139>\u000f\u000b>,%\u0004\u0007\u0011", "naXPh");
         I[205 ^ 195] = I(";\t(\u0007\u000f3\u00154\u001f\u0003<", "lAaSJ");
         I[52 ^ 59] = I("\"8\f\u0017\b\n$\u0010\u000f\u0004%", "UPecm");
         I[101 ^ 117] = I("\u001c:$>\u0018\u0018&&<\u0017", "LsjuG");
         I[171 ^ 186] = I("\b: \f\u000f\f&\"\u000e ", "xSNgP");
         I[27 ^ 9] = I("\u000e\t/\u001e\u000b\u001e\u0015+\u000e\u001d\u0018", "AQjGN");
         I[30 ^ 13] = I(".\u0002\f\u000e<\u001e\u001e\b\u001e*8", "AziwY");
         I[52 ^ 32] = I("\u0015/$%7\u001d'%/", "Qnjar");
         I[129 ^ 148] = I("\u0000\u0014\u0018\u0013&\b\u001c\u0019\u0019", "duvwC");
         I[97 ^ 119] = I("\u000e\n\u001a96\u0000\u001b\u001d/+\u0006", "AKQfe");
         I[154 ^ 141] = I("9\n\f\u0010\u00177\u001b\u000b&\n1", "VkgOd");
         I[127 ^ 103] = I("\u001a\u0011\u0003\u0014\b\f\u001e\u0002\u0000\u001b\u0005\b\u001f\u0006", "IAQAK");
         I[191 ^ 166] = I("447%%\"\u001b616+-+7", "GDEPF");
         I[172 ^ 182] = I("'\u0007:1\u001f:\u001d)\"\u001b,\u0000/", "eNhrW");
         I[89 ^ 66] = I("\u0005%(\f\u001f8?;\u001f\u001b\u000e\"=", "gLZow");
         I[145 ^ 141] = I(";;*\u000f\u0019417\t\u0005='*\u000f", "qndHU");
         I[162 ^ 191] = I("3=:+\u000e<\u0017'-\u00125!:+", "YHTLb");
         I[46 ^ 48] = I("\u0004\u0010\u00077\u0003\u0004\f\u00155\u001a\t\u001a\b3", "ESFtJ");
         I[70 ^ 89] = I("1\r8\f>11*\u000e'<\u00077\b", "PnYoW");
         I[52 ^ 20] = I("\n%($\u001b\u0001%10\u0017\u000f46&\n\t", "NdzoD");
         I[96 ^ 65] = I("\u0016\u0002\u0006\u0012=\u001d\u0002\u001f&\u0011\u0013\u0013\u0018\u0010\f\u0015", "rctyb");
         I[150 ^ 180] = I("/\u0019=*8-\u0003#=8'\b", "bLnbj");
         I[128 ^ 163] = I("\u001e\u00197\f>\u001c\u0003);>\u0016\b", "slDdL");
         I[142 ^ 170] = I("?\u001c</1=\u0006\"8! \u00068)", "rIogc");
         I[47 ^ 10] = I("\"\u001c\u001a\u0005\u001d \u0006\u00042\r=\u0006\u001e\u0003", "Oiimo");
         I[150 ^ 176] = I("/\u0001 =\u001b)\u001121", "kDayD");
         I[12 ^ 43] = I("\u0013\u001d\"4+\u0015\r08", "wxCPt");
         I[92 ^ 116] = I(">3\u0019!", "xvKow");
         I[43 ^ 2] = I("\r\u0000\u0003!", "keqOS");
         I[90 ^ 112] = I("\t\u0019!-,\u0019", "JXbyy");
         I[185 ^ 146] = I("2, \u001b&\"", "QMCoS");
      }

      public String getName() {
         return this.name;
      }

      private EnumFlowerType(String var3) {
         this.name = var3;
      }
   }
}

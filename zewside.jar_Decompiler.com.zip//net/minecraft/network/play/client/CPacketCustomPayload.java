package net.minecraft.network.play.client;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketCustomPayload implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private PacketBuffer data;
   // $FF: synthetic field
   private String channel;
   // $FF: synthetic field
   private static final String[] I;

   public CPacketCustomPayload(String var1, PacketBuffer var2) {
      this.channel = var1;
      this.data = var2;
      if (var2.writerIndex() > 20787 + 24037 - 32359 + 20302) {
         throw new IllegalArgumentException(I["".length()]);
      }
   }

   public String getChannelName() {
      return this.channel;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processCustomPayload(this);
      if (this.data != null) {
         this.data.release();
         I[219 ^ 194].length();
      }

   }

   private static void I() {
      I = new String[151 ^ 141];
      I["".length()] = I("8\u000b5\u0019-\t\u000el\u0018#\u0011J\"\u001a6H\b)U.\t\u0018+\u00100H\u001e$\u0014,HY~Bt_J.\f6\r\u0019", "hjLuB");
      I[" ".length()] = I("氹岞", "RfxWE");
      I["  ".length()] = I("歄溬", "zEtOV");
      I["   ".length()] = I("擷捀", "VjOcw");
      I[161 ^ 165] = I("榁幰", "WpQNs");
      I[148 ^ 145] = I("坪捲", "jcGRs");
      I[170 ^ 172] = I("擕拝", "KMVZe");
      I[176 ^ 183] = I("嘓憽", "JXFzB");
      I[122 ^ 114] = I("炀抒", "FwrTh");
      I[52 ^ 61] = I("烆屃愲", "TioVX");
      I[106 ^ 96] = I("惬洰滠桍", "XKrpr");
      I[10 ^ 1] = I("卉", "aTPPo");
      I[80 ^ 92] = I("乯拮", "PckUe");
      I[127 ^ 114] = I("侴枉多", "emHAV");
      I[144 ^ 158] = I("%\u0015\b\u001c\u001e\u0014\u0010Q\u001d\u0010\fT\u001f\u001f\u0005U\u0016\u0014P\u001d\u0014\u0006\u0016\u0015\u0003U\u0000\u0019\u0011\u001fUGCGGBT\u0013\t\u0005\u0010\u0007", "utqpq");
      I[123 ^ 116] = I("减瀾", "VRJnP");
      I[94 ^ 78] = I("伱戀哹儵侤", "uGtoe");
      I[78 ^ 95] = I("僺炛削", "OENnG");
      I[54 ^ 36] = I("歺径洽照", "uDjoO");
      I[111 ^ 124] = I("奙暝呗", "nzvPj");
      I[135 ^ 147] = I("囇應灈源", "dFVXd");
      I[211 ^ 198] = I("杰兯", "LibGz");
      I[183 ^ 161] = I("殬宏機", "ReFPa");
      I[13 ^ 26] = I("枓", "gZyGd");
      I[105 ^ 113] = I("学", "GccRd");
      I[157 ^ 132] = I("壪屺沓橩滕", "TVshc");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   public CPacketCustomPayload() {
   }

   static {
      I();
   }

   public PacketBuffer getBufferData() {
      return this.data;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[111 ^ 107];
      var10000 = I[144 ^ 149];
      var10001 = I[35 ^ 37];
      var10002 = I[110 ^ 105];
      var10001 = I[125 ^ 117];
      this.channel = var1.readStringFromBuffer(68 ^ 80);
      int var2 = var1.readableBytes();
      if (var2 >= 0 && var2 <= 13914 + 22546 - 20473 + 16780) {
         I[114 ^ 123].length();
         I[8 ^ 2].length();
         I[144 ^ 155].length();
         this.data = new PacketBuffer(var1.readBytes(var2));
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         I[75 ^ 71].length();
         I[44 ^ 33].length();
         IOException var3 = new IOException(I[68 ^ 74]);
         I[65 ^ 78].length();
         I[119 ^ 103].length();
         I[13 ^ 28].length();
         throw var3;
      }
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.channel);
      I[2 ^ 16].length();
      I[78 ^ 93].length();
      I[10 ^ 30].length();
      var1.writeBytes((ByteBuf)this.data);
      I[162 ^ 183].length();
      I[103 ^ 113].length();
      I[48 ^ 39].length();
      I[160 ^ 184].length();
   }
}

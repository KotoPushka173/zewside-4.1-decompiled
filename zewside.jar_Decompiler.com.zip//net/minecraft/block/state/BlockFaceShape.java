package net.minecraft.block.state;

public enum BlockFaceShape {
   // $FF: synthetic field
   BOWL,
   // $FF: synthetic field
   CENTER_BIG,
   // $FF: synthetic field
   SOLID,
   // $FF: synthetic field
   CENTER,
   // $FF: synthetic field
   MIDDLE_POLE_THIN;

   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   CENTER_SMALL,
   // $FF: synthetic field
   UNDEFINED,
   // $FF: synthetic field
   MIDDLE_POLE,
   // $FF: synthetic field
   MIDDLE_POLE_THICK;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != 2);

      throw null;
   }

   private static void I() {
      I = new String[188 ^ 181];
      I["".length()] = I("6%>\u0005\u0000", "ejrLD");
      I[" ".length()] = I("(\u000155", "jNbyL");
      I["  ".length()] = I("*\u0014\u0019 \u0004;\u000e\u00049\u0000%\u001d", "iQWtA");
      I["   ".length()] = I(">9\u00073'6/\u00138'6/\u0017?\"=", "spCwk");
      I[129 ^ 133] = I("4\b\u0003!\u0017%", "wMMuR");
      I[86 ^ 83] = I("\t +74\u00016?<4\u0001", "Diosx");
      I[150 ^ 144] = I("\u0015\u0000%\u0019\r\u0004\u001a)\u0004\u000f", "VEkMH");
      I[21 ^ 18] = I("\u00171\u001c-\u001d\u001f'\b&\u001d\u001f'\f!\u0018\u00193", "ZxXiQ");
      I[109 ^ 101] = I("\r\t\n\u0000(\u0011\t\u000b\u0001", "XGNEn");
   }

   static {
      I();
      SOLID = new BlockFaceShape(I["".length()], "".length());
      BOWL = new BlockFaceShape(I[" ".length()], " ".length());
      CENTER_SMALL = new BlockFaceShape(I["  ".length()], "  ".length());
      MIDDLE_POLE_THIN = new BlockFaceShape(I["   ".length()], "   ".length());
      CENTER = new BlockFaceShape(I[177 ^ 181], 198 ^ 194);
      MIDDLE_POLE = new BlockFaceShape(I[30 ^ 27], 42 ^ 47);
      CENTER_BIG = new BlockFaceShape(I[142 ^ 136], 157 ^ 155);
      MIDDLE_POLE_THICK = new BlockFaceShape(I[73 ^ 78], 89 ^ 94);
      UNDEFINED = new BlockFaceShape(I[4 ^ 12], 148 ^ 156);
      BlockFaceShape[] var10000 = new BlockFaceShape[172 ^ 165];
      var10000["".length()] = SOLID;
      var10000[" ".length()] = BOWL;
      var10000["  ".length()] = CENTER_SMALL;
      var10000["   ".length()] = MIDDLE_POLE_THIN;
      var10000[88 ^ 92] = CENTER;
      var10000[141 ^ 136] = MIDDLE_POLE;
      var10000[195 ^ 197] = CENTER_BIG;
      var10000[190 ^ 185] = MIDDLE_POLE_THICK;
      var10000[51 ^ 59] = UNDEFINED;
   }
}

package net.minecraft.scoreboard;

public class ScoreCriteria implements IScoreCriteria {
   // $FF: synthetic field
   private final String dummyName;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 0);

      throw null;
   }

   public ScoreCriteria(String var1) {
      this.dummyName = var1;
      IScoreCriteria.INSTANCES.put(var1, this);
   }

   public String getName() {
      return this.dummyName;
   }

   public boolean isReadOnly() {
      return (boolean)"".length();
   }

   public IScoreCriteria.EnumRenderType getRenderType() {
      return IScoreCriteria.EnumRenderType.INTEGER;
   }
}

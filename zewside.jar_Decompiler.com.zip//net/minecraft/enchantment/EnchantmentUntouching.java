package net.minecraft.enchantment;

import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentUntouching extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public int getMinEnchantability(int var1) {
      return 108 ^ 99;
   }

   public int getMaxLevel() {
      return " ".length();
   }

   protected EnchantmentUntouching(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.DIGGER, var2);
      this.setName(I["".length()]);
   }

   public int getMaxEnchantability(int var1) {
      return super.getMinEnchantability(var1) + (26 ^ 40);
   }

   public boolean canApplyTogether(Enchantment var1) {
      int var10000;
      if (super.canApplyTogether(var1) && var1 != Enchantments.FORTUNE) {
         var10000 = " ".length();
         "".length();
         if (0 == 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I(":\u001e' \u001b,\u0018:!\t", "OpSOn");
   }
}

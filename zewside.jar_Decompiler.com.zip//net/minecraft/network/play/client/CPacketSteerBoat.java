package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketSteerBoat implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private boolean left;
   // $FF: synthetic field
   private boolean right;
   // $FF: synthetic field
   private static final String[] I;

   public CPacketSteerBoat() {
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processSteerBoat(this);
   }

   static {
      I();
   }

   private static void I() {
      I = new String[187 ^ 188];
      I["".length()] = I("方嫸", "xcCqn");
      I[" ".length()] = I("濕僗杹截巠", "gbZYL");
      I["  ".length()] = I("楰嫭", "styOW");
      I["   ".length()] = I("桦孺勎", "jyzfY");
      I[109 ^ 105] = I("垍歂帞", "qMCkY");
      I[8 ^ 13] = I("滽市卑", "CbQHK");
      I[166 ^ 160] = I("恟哎婃欏", "ICYzs");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 0);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.left = var1.readBoolean();
      this.right = var1.readBoolean();
   }

   public boolean getRight() {
      return this.right;
   }

   public CPacketSteerBoat(boolean var1, boolean var2) {
      this.left = var1;
      this.right = var2;
   }

   public boolean getLeft() {
      return this.left;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeBoolean(this.left);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeBoolean(this.right);
      I["   ".length()].length();
      I[104 ^ 108].length();
      I[70 ^ 67].length();
      I[153 ^ 159].length();
   }
}

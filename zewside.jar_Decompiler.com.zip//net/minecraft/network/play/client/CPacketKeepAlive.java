package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketKeepAlive implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private long key;
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public CPacketKeepAlive(long var1) {
      this.key = var1;
   }

   public CPacketKeepAlive() {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != -1);

      throw null;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processKeepAlive(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeLong(this.key);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }

   public long getKey() {
      return this.key;
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("瀓榕唤桯垯", "wWqcZ");
      I[" ".length()] = I("宥副姝枡掂", "QMThO");
      I["  ".length()] = I("橯", "IrAcA");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.key = var1.readLong();
   }
}

package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockDoublePlant extends BlockBush implements IGrowable {
   // $FF: synthetic field
   public static final PropertyEnum<EnumFacing> FACING;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockDoublePlant.EnumPlantType> VARIANT;
   // $FF: synthetic field
   public static final PropertyEnum<BlockDoublePlant.EnumBlockHalf> HALF;

   public Block.EnumOffsetType getOffsetType() {
      return Block.EnumOffsetType.XZ;
   }

   public int damageDropped(IBlockState var1) {
      int var10000;
      if (var1.getValue(HALF) != BlockDoublePlant.EnumBlockHalf.UPPER && var1.getValue(VARIANT) != BlockDoublePlant.EnumPlantType.GRASS) {
         var10000 = ((BlockDoublePlant.EnumPlantType)var1.getValue(VARIANT)).getMeta();
         "".length();
         if (2 <= -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      var1.setBlockState(var2.up(), this.getDefaultState().withProperty(HALF, BlockDoublePlant.EnumBlockHalf.UPPER), "  ".length());
      I[10 ^ 0].length();
      I[157 ^ 150].length();
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      if (var1.getValue(HALF) == BlockDoublePlant.EnumBlockHalf.UPPER) {
         IBlockState var4 = var2.getBlockState(var3.down());
         if (var4.getBlock() == this) {
            var1 = var1.withProperty(VARIANT, var4.getValue(VARIANT));
         }
      }

      return var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 4);

      throw null;
   }

   private boolean onHarvest(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      String var10000 = I[112 ^ 81];
      String var10001 = I[182 ^ 148];
      String var10002 = I[119 ^ 84];
      var10001 = I[77 ^ 105];
      BlockDoublePlant.EnumPlantType var5 = (BlockDoublePlant.EnumPlantType)var3.getValue(VARIANT);
      if (var5 != BlockDoublePlant.EnumPlantType.FERN && var5 != BlockDoublePlant.EnumPlantType.GRASS) {
         return (boolean)"".length();
      } else {
         var4.addStat(StatList.getBlockStats(this));
         BlockTallGrass.EnumType var7;
         if (var5 == BlockDoublePlant.EnumPlantType.GRASS) {
            var7 = BlockTallGrass.EnumType.GRASS;
            "".length();
            if (1 == 4) {
               throw null;
            }
         } else {
            var7 = BlockTallGrass.EnumType.FERN;
         }

         int var6 = var7.getMeta();
         I[134 ^ 163].length();
         I[186 ^ 156].length();
         I[110 ^ 73].length();
         I[108 ^ 68].length();
         spawnAsEntity(var1, var2, new ItemStack(Blocks.TALLGRASS, "  ".length(), var6));
         return (boolean)" ".length();
      }
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      if (var1.isRemote || var6.getItem() != Items.SHEARS || var4.getValue(HALF) != BlockDoublePlant.EnumBlockHalf.LOWER || !this.onHarvest(var1, var3, var4, var2)) {
         super.harvestBlock(var1, var2, var3, var4, var5, var6);
      }

   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[33 ^ 120], BlockDoublePlant.EnumPlantType.class);
      HALF = PropertyEnum.create(I[244 ^ 174], BlockDoublePlant.EnumBlockHalf.class);
      FACING = BlockHorizontal.FACING;
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[48 ^ 25];
      String var10001 = I[117 ^ 95];
      String var10002 = I[11 ^ 32];
      var10001 = I[35 ^ 15];
      BlockDoublePlant.EnumPlantType[] var3 = BlockDoublePlant.EnumPlantType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockDoublePlant.EnumPlantType var6 = var3[var5];
         I[174 ^ 131].length();
         I[44 ^ 2].length();
         I[37 ^ 10].length();
         I[150 ^ 166].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMeta()));
         I[12 ^ 61].length();
         I[159 ^ 173].length();
         I[125 ^ 78].length();
         I[60 ^ 8].length();
         ++var5;
         "".length();
      } while(0 < 1);

      throw null;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[7 ^ 56];
      String var10001 = I[197 ^ 133];
      String var10002 = I[43 ^ 106];
      var10001 = I[66 ^ 0];
      var10000 = I[9 ^ 74];
      var10001 = I[10 ^ 78];
      var10002 = I[232 ^ 173];
      var10001 = I[205 ^ 139];
      var10000 = I[16 ^ 87];
      var10001 = I[73 ^ 1];
      var10002 = I[96 ^ 41];
      var10001 = I[120 ^ 50];
      var10000 = I[119 ^ 60];
      var10001 = I[233 ^ 165];
      var10002 = I[209 ^ 156];
      var10001 = I[17 ^ 95];
      I[52 ^ 123].length();
      I[61 ^ 109].length();
      I[62 ^ 111].length();
      I[252 ^ 174].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[44 ^ 127].length();
      I[205 ^ 153].length();
      var10003["".length()] = HALF;
      I[26 ^ 79].length();
      var10003[" ".length()] = VARIANT;
      I[84 ^ 2].length();
      I[122 ^ 45].length();
      I[2 ^ 90].length();
      var10003["  ".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   private static void I() {
      I = new String[237 ^ 182];
      I["".length()] = I("\u0000\u0017\u00131:\u0001(\n28\u0010", "dxfSV");
      I[" ".length()] = I("揦拔", "xHrhv");
      I["  ".length()] = I("涛嵽曻", "kuTpz");
      I["   ".length()] = I("婷楰", "KPSEw");
      I[198 ^ 194] = I("曤", "qmMud");
      I[37 ^ 32] = I("怘", "prMcI");
      I[188 ^ 186] = I("乨帏暎歛俴", "OuPxj");
      I[14 ^ 9] = I("壌撻", "xKNhd");
      I[38 ^ 46] = I("哺炨炋嗾", "JXsfi");
      I[16 ^ 25] = I("旫炽快字且", "Pqxvw");
      I[93 ^ 87] = I("撙涽櫬", "YjBgc");
      I[206 ^ 197] = I("峦湡", "FwaPP");
      I[6 ^ 10] = I("抁拂噽櫭氝", "maYge");
      I[141 ^ 128] = I("咧仄揔咵", "yPwVZ");
      I[111 ^ 97] = I("搇峮嘵枚", "BpHuZ");
      I[139 ^ 132] = I("暢棐", "JEmgX");
      I[215 ^ 199] = I("埈櫚樛宥减", "XhGPh");
      I[154 ^ 139] = I("徜墛氦塋亶", "jZcjY");
      I[146 ^ 128] = I("幖匞焈擁惵", "DBNHb");
      I[88 ^ 75] = I("懚慴", "DTRdP");
      I[71 ^ 83] = I("橐樐圤帋沼", "SojLY");
      I[5 ^ 16] = I("壧娜", "TpASV");
      I[173 ^ 187] = I("棓傄弄棈倍", "REDWY");
      I[72 ^ 95] = I("完楢毢昐枾", "Khchb");
      I[29 ^ 5] = I("唃坝嫇涩洞", "TREmT");
      I[153 ^ 128] = I("伷和匨", "fnLWR");
      I[48 ^ 42] = I("渇柈津", "sVegr");
      I[50 ^ 41] = I("奶傕帨", "opajs");
      I[183 ^ 171] = I("懱慭刳咥怦", "PydAi");
      I[15 ^ 18] = I("敺焨渣既媭", "aiZCT");
      I[8 ^ 22] = I("娗戬喨櫁嚉", "Nudgs");
      I[189 ^ 162] = I("欭柞丿壖夼", "BVubV");
      I[106 ^ 74] = I("拁偶澗棸嚨", "EqJQV");
      I[29 ^ 60] = I("炃毃", "rwHYk");
      I[69 ^ 103] = I("楍暌", "rooMb");
      I[161 ^ 130] = I("悓庢", "YKOKP");
      I[173 ^ 137] = I("唵歬", "rkJhD");
      I[177 ^ 148] = I("楂惲", "yJzdL");
      I[135 ^ 161] = I("戚嵅", "tHTFr");
      I[174 ^ 137] = I("勁妉傃嫦嬝", "RWnjQ");
      I[10 ^ 34] = I("廋梢", "XkaNJ");
      I[45 ^ 4] = I("塰栚", "ONaat");
      I[62 ^ 20] = I("嬝唦", "qahfw");
      I[43 ^ 0] = I("捍冽", "NPFTU");
      I[147 ^ 191] = I("元炐", "jQjTk");
      I[81 ^ 124] = I("弯榤溊", "lGHWu");
      I[57 ^ 23] = I("求", "cTQTb");
      I[61 ^ 18] = I("思勺梪", "SxiNA");
      I[85 ^ 101] = I("堾業吰", "WjFTQ");
      I[75 ^ 122] = I("婗檹悂", "bzsTE");
      I[51 ^ 1] = I("瀋泰", "sfCbW");
      I[110 ^ 93] = I("仸兮噑枽圈", "IAzWU");
      I[27 ^ 47] = I("召", "IBrMR");
      I[57 ^ 12] = I("抆庝", "AOMwi");
      I[165 ^ 147] = I("姑嚴", "XFuxc");
      I[18 ^ 37] = I("搜媓", "FXSTA");
      I[138 ^ 178] = I("椿仨", "lkqdb");
      I[71 ^ 126] = I("泳哘", "daZZu");
      I[87 ^ 109] = I("天弹", "XwNAn");
      I[252 ^ 199] = I("濃寮", "noogP");
      I[12 ^ 48] = I("次榮", "vTFJa");
      I[170 ^ 151] = I("摂娥", "KpVCP");
      I[181 ^ 139] = I("康卓卟慦", "VYjww");
      I[77 ^ 114] = I("仔晟", "BdSaJ");
      I[68 ^ 4] = I("濵俥", "ZmeBs");
      I[103 ^ 38] = I("姺桡", "rGxDd");
      I[214 ^ 148] = I("娊伡", "IuZFp");
      I[122 ^ 57] = I("娦权", "wOnCL");
      I[229 ^ 161] = I("佰淒", "SVYgn");
      I[87 ^ 18] = I("毛滌", "NrNNW");
      I[238 ^ 168] = I("孋娡", "jRCIa");
      I[129 ^ 198] = I("墳榃", "VKGyI");
      I[206 ^ 134] = I("涢倁", "geuuj");
      I[79 ^ 6] = I("剘泵", "YEWaz");
      I[89 ^ 19] = I("奅投", "XaXtH");
      I[27 ^ 80] = I("匼汍", "gQilC");
      I[126 ^ 50] = I("氀涶", "OJVuG");
      I[86 ^ 27] = I("奣妽", "vkxyh");
      I[39 ^ 105] = I("方垵", "PGhRK");
      I[106 ^ 37] = I("淹橢椛户槩", "TdsOv");
      I[232 ^ 184] = I("摒烬僕攗", "evWPI");
      I[1 ^ 80] = I("瀙", "MFAZM");
      I[218 ^ 136] = I("僁弎垻", "IrxTM");
      I[232 ^ 187] = I("孙", "VzEqc");
      I[19 ^ 71] = I("壏宙冡榑", "dArmR");
      I[64 ^ 21] = I("凤泱拝", "SJxel");
      I[123 ^ 45] = I("漝", "PoaRd");
      I[238 ^ 185] = I("伽炟彳愭倂", "qdYTB");
      I[97 ^ 57] = I("光哇惀", "UxUuB");
      I[12 ^ 85] = I("\u0019\u0016\u0019\u0013\"\u0001\u0003", "owkzC");
      I[238 ^ 180] = I("#\u0013+*", "KrGLh");
   }

   private BlockDoublePlant.EnumPlantType getType(IBlockAccess var1, BlockPos var2, IBlockState var3) {
      if (var3.getBlock() == this) {
         var3 = var3.getActualState(var1, var2);
         return (BlockDoublePlant.EnumPlantType)var3.getValue(VARIANT);
      } else {
         return BlockDoublePlant.EnumPlantType.FERN;
      }
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000;
      if ((var1 & (88 ^ 80)) > 0) {
         var10000 = this.getDefaultState().withProperty(HALF, BlockDoublePlant.EnumBlockHalf.UPPER);
         "".length();
         if (0 >= 4) {
            throw null;
         }
      } else {
         var10000 = this.getDefaultState().withProperty(HALF, BlockDoublePlant.EnumBlockHalf.LOWER).withProperty(VARIANT, BlockDoublePlant.EnumPlantType.byMetadata(var1 & (67 ^ 68)));
      }

      return var10000;
   }

   public void placeAt(World var1, BlockPos var2, BlockDoublePlant.EnumPlantType var3, int var4) {
      var1.setBlockState(var2, this.getDefaultState().withProperty(HALF, BlockDoublePlant.EnumBlockHalf.LOWER).withProperty(VARIANT, var3), var4);
      I[30 ^ 27].length();
      I[80 ^ 86].length();
      I[50 ^ 53].length();
      var1.setBlockState(var2.up(), this.getDefaultState().withProperty(HALF, BlockDoublePlant.EnumBlockHalf.UPPER), var4);
      I[28 ^ 20].length();
      I[150 ^ 159].length();
   }

   public BlockDoublePlant() {
      super(Material.VINE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockDoublePlant.EnumPlantType.SUNFLOWER).withProperty(HALF, BlockDoublePlant.EnumBlockHalf.LOWER).withProperty(FACING, EnumFacing.NORTH));
      this.setHardness(0.0F);
      this.setSoundType(SoundType.PLANT);
      this.setUnlocalizedName(I["".length()]);
   }

   public void onBlockHarvested(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      if (var3.getValue(HALF) == BlockDoublePlant.EnumBlockHalf.UPPER) {
         if (var1.getBlockState(var2.down()).getBlock() == this) {
            if (var4.capabilities.isCreativeMode) {
               var1.setBlockToAir(var2.down());
               I[182 ^ 186].length();
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            } else {
               IBlockState var5 = var1.getBlockState(var2.down());
               BlockDoublePlant.EnumPlantType var6 = (BlockDoublePlant.EnumPlantType)var5.getValue(VARIANT);
               if (var6 != BlockDoublePlant.EnumPlantType.FERN && var6 != BlockDoublePlant.EnumPlantType.GRASS) {
                  var1.destroyBlock(var2.down(), (boolean)" ".length());
                  I[34 ^ 47].length();
                  I[31 ^ 17].length();
                  I[201 ^ 198].length();
                  "".length();
                  if (-1 >= 3) {
                     throw null;
                  }
               } else if (var1.isRemote) {
                  var1.setBlockToAir(var2.down());
                  I[176 ^ 160].length();
                  I[97 ^ 112].length();
                  I[155 ^ 137].length();
                  "".length();
                  if (4 == 0) {
                     throw null;
                  }
               } else if (!var4.getHeldItemMainhand().isEmpty() && var4.getHeldItemMainhand().getItem() == Items.SHEARS) {
                  this.onHarvest(var1, var2, var5, var4);
                  I[86 ^ 69].length();
                  I[209 ^ 197].length();
                  I[51 ^ 38].length();
                  var1.setBlockToAir(var2.down());
                  I[103 ^ 113].length();
                  I[182 ^ 161].length();
                  I[142 ^ 150].length();
                  I[80 ^ 73].length();
                  "".length();
                  if (0 >= 2) {
                     throw null;
                  }
               } else {
                  var1.destroyBlock(var2.down(), (boolean)" ".length());
                  I[166 ^ 188].length();
                  I[9 ^ 18].length();
               }

               "".length();
               if (0 >= 2) {
                  throw null;
               }
            }
         }
      } else if (var1.getBlockState(var2.up()).getBlock() == this) {
         var1.setBlockState(var2.up(), Blocks.AIR.getDefaultState(), "  ".length());
         I[55 ^ 43].length();
         I[94 ^ 67].length();
         I[150 ^ 136].length();
         I[152 ^ 135].length();
         I[178 ^ 146].length();
      }

      super.onBlockHarvested(var1, var2, var3, var4);
   }

   public boolean canBlockStay(World var1, BlockPos var2, IBlockState var3) {
      int var10000;
      if (var3.getValue(HALF) == BlockDoublePlant.EnumBlockHalf.UPPER) {
         if (var1.getBlockState(var2.down()).getBlock() == this) {
            var10000 = " ".length();
            "".length();
            if (-1 >= 1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      } else {
         IBlockState var4 = var1.getBlockState(var2.up());
         if (var4.getBlock() == this && super.canBlockStay(var1, var2, var4)) {
            var10000 = " ".length();
            "".length();
            if (1 >= 3) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public boolean isReplaceable(IBlockAccess var1, BlockPos var2) {
      IBlockState var3 = var1.getBlockState(var2);
      if (var3.getBlock() != this) {
         return (boolean)" ".length();
      } else {
         BlockDoublePlant.EnumPlantType var4 = (BlockDoublePlant.EnumPlantType)var3.getActualState(var1, var2).getValue(VARIANT);
         int var10000;
         if (var4 != BlockDoublePlant.EnumPlantType.FERN && var4 != BlockDoublePlant.EnumPlantType.GRASS) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (2 >= 4) {
               throw null;
            }
         }

         return (boolean)var10000;
      }
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return FULL_BLOCK_AABB;
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (super.canPlaceBlockAt(var1, var2) && var1.isAirBlock(var2.up())) {
         var10000 = " ".length();
         "".length();
         if (0 == 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public boolean canGrow(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      BlockDoublePlant.EnumPlantType var5 = this.getType(var1, var2, var3);
      int var10000;
      if (var5 != BlockDoublePlant.EnumPlantType.GRASS && var5 != BlockDoublePlant.EnumPlantType.FERN) {
         var10000 = " ".length();
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   protected void checkAndDropBlock(World var1, BlockPos var2, IBlockState var3) {
      if (!this.canBlockStay(var1, var2, var3)) {
         int var10000;
         if (var3.getValue(HALF) == BlockDoublePlant.EnumBlockHalf.UPPER) {
            var10000 = " ".length();
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         int var4 = var10000;
         BlockPos var9;
         if (var4 != 0) {
            var9 = var2;
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var9 = var2.up();
         }

         BlockPos var5 = var9;
         if (var4 != 0) {
            var9 = var2.down();
            "".length();
            if (0 < 0) {
               throw null;
            }
         } else {
            var9 = var2;
         }

         BlockPos var6 = var9;
         Object var10;
         if (var4 != 0) {
            var10 = this;
            "".length();
            if (-1 >= 2) {
               throw null;
            }
         } else {
            var10 = var1.getBlockState(var5).getBlock();
         }

         Object var7 = var10;
         if (var4 != 0) {
            var10 = var1.getBlockState(var6).getBlock();
            "".length();
            if (4 <= 2) {
               throw null;
            }
         } else {
            var10 = this;
         }

         Object var8 = var10;
         if (var7 == this) {
            var1.setBlockState(var5, Blocks.AIR.getDefaultState(), "  ".length());
            I[" ".length()].length();
            I["  ".length()].length();
         }

         if (var8 == this) {
            var1.setBlockState(var6, Blocks.AIR.getDefaultState(), "   ".length());
            I["   ".length()].length();
            I[130 ^ 134].length();
            if (var4 == 0) {
               this.dropBlockAsItem(var1, var6, var3, "".length());
            }
         }
      }

   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[51 ^ 6];
      String var10001 = I[5 ^ 51];
      String var10002 = I[128 ^ 183];
      var10001 = I[177 ^ 137];
      I[93 ^ 100].length();
      return new ItemStack(this, " ".length(), this.getType(var1, var2, var3).getMeta());
   }

   public int getMetaFromState(IBlockState var1) {
      int var10000;
      if (var1.getValue(HALF) == BlockDoublePlant.EnumBlockHalf.UPPER) {
         var10000 = 38 ^ 46 | ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
         "".length();
         if (3 <= 0) {
            throw null;
         }
      } else {
         var10000 = ((BlockDoublePlant.EnumPlantType)var1.getValue(VARIANT)).getMeta();
      }

      return var10000;
   }

   public boolean canUseBonemeal(World var1, Random var2, BlockPos var3, IBlockState var4) {
      return (boolean)" ".length();
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      if (var1.getValue(HALF) == BlockDoublePlant.EnumBlockHalf.UPPER) {
         return Items.field_190931_a;
      } else {
         BlockDoublePlant.EnumPlantType var4 = (BlockDoublePlant.EnumPlantType)var1.getValue(VARIANT);
         if (var4 == BlockDoublePlant.EnumPlantType.FERN) {
            return Items.field_190931_a;
         } else if (var4 == BlockDoublePlant.EnumPlantType.GRASS) {
            Item var10000;
            if (var2.nextInt(60 ^ 52) == 0) {
               var10000 = Items.WHEAT_SEEDS;
               "".length();
               if (3 < 2) {
                  throw null;
               }
            } else {
               var10000 = Items.field_190931_a;
            }

            return var10000;
         } else {
            return super.getItemDropped(var1, var2, var3);
         }
      }
   }

   public void grow(World var1, Random var2, BlockPos var3, IBlockState var4) {
      String var10000 = I[165 ^ 159];
      String var10001 = I[50 ^ 9];
      String var10002 = I[90 ^ 102];
      var10001 = I[11 ^ 54];
      I[39 ^ 25].length();
      spawnAsEntity(var1, var3, new ItemStack(this, " ".length(), this.getType(var1, var3, var4).getMeta()));
   }

   public static enum EnumBlockHalf implements IStringSerializable {
      // $FF: synthetic field
      UPPER,
      // $FF: synthetic field
      LOWER;

      // $FF: synthetic field
      private static final String[] I;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 == -1);

         throw null;
      }

      private static void I() {
         I = new String[51 ^ 55];
         I["".length()] = I("\u001d4\u0014\u00033", "hDdfA");
         I[" ".length()] = I("4\u001b\u001b5\b", "XtlPz");
         I["  ".length()] = I("\u0016\u0011\u001e\"\u0019", "CANgK");
         I["   ".length()] = I("-9\u00037\u001d", "avTrO");
      }

      public String getName() {
         String var10000;
         if (this == UPPER) {
            var10000 = I["".length()];
            "".length();
            if (0 >= 3) {
               throw null;
            }
         } else {
            var10000 = I[" ".length()];
         }

         return var10000;
      }

      public String toString() {
         return this.getName();
      }

      static {
         I();
         UPPER = new BlockDoublePlant.EnumBlockHalf(I["  ".length()], "".length());
         LOWER = new BlockDoublePlant.EnumBlockHalf(I["   ".length()], " ".length());
         BlockDoublePlant.EnumBlockHalf[] var10000 = new BlockDoublePlant.EnumBlockHalf["  ".length()];
         var10000["".length()] = UPPER;
         var10000[" ".length()] = LOWER;
      }
   }

   public static enum EnumPlantType implements IStringSerializable {
      // $FF: synthetic field
      SYRINGA;

      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      ROSE;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      GRASS,
      // $FF: synthetic field
      PAEONIA,
      // $FF: synthetic field
      FERN,
      // $FF: synthetic field
      SUNFLOWER;

      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      private final String name;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 >= -1);

         throw null;
      }

      public String getName() {
         return this.name;
      }

      public String toString() {
         return this.name;
      }

      private EnumPlantType(int var3, String var4) {
         this(var3, var4, var4);
      }

      static {
         I();
         SUNFLOWER = new BlockDoublePlant.EnumPlantType(I["".length()], "".length(), "".length(), I[" ".length()]);
         SYRINGA = new BlockDoublePlant.EnumPlantType(I["  ".length()], " ".length(), " ".length(), I["   ".length()]);
         GRASS = new BlockDoublePlant.EnumPlantType(I[39 ^ 35], "  ".length(), "  ".length(), I[148 ^ 145], I[139 ^ 141]);
         FERN = new BlockDoublePlant.EnumPlantType(I[55 ^ 48], "   ".length(), "   ".length(), I[176 ^ 184], I[92 ^ 85]);
         ROSE = new BlockDoublePlant.EnumPlantType(I[89 ^ 83], 173 ^ 169, 57 ^ 61, I[32 ^ 43], I[39 ^ 43]);
         PAEONIA = new BlockDoublePlant.EnumPlantType(I[26 ^ 23], 50 ^ 55, 104 ^ 109, I[76 ^ 66]);
         BlockDoublePlant.EnumPlantType[] var10000 = new BlockDoublePlant.EnumPlantType[176 ^ 182];
         var10000["".length()] = SUNFLOWER;
         var10000[" ".length()] = SYRINGA;
         var10000["  ".length()] = GRASS;
         var10000["   ".length()] = FERN;
         var10000[134 ^ 130] = ROSE;
         var10000[170 ^ 175] = PAEONIA;
         BlockDoublePlant.EnumPlantType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockDoublePlant.EnumPlantType var3 = var0[var2];
            META_LOOKUP[var3.getMeta()] = var3;
            ++var2;
            "".length();
         } while(true);

         throw null;
      }

      private EnumPlantType(int var3, String var4, String var5) {
         this.meta = var3;
         this.name = var4;
         this.unlocalizedName = var5;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      public int getMeta() {
         return this.meta;
      }

      private static void I() {
         I = new String[96 ^ 111];
         I["".length()] = I("$\u0014'>\u001f8\u0016,*", "wAixS");
         I[" ".length()] = I("\u001e\u001b\u001d\u000e;\u0002\u0019\u0016\u001a", "mnshW");
         I["  ".length()] = I("6+\u001f9\u001a\"3", "erMpT");
         I["   ".length()] = I("21\u0014%<&)", "AHfLR");
         I[30 ^ 26] = I("0\u001f\u000e%?", "wMOvl");
         I[45 ^ 40] = I("\u0007\u001d\u0013\u0001'\u0006-\u0001\u0011*\u0010\u0001", "crfcK");
         I[155 ^ 157] = I("\f\u0010\u0005\u00005", "kbdsF");
         I[187 ^ 188] = I("\u0005\u0016=\u001b", "CSoUB");
         I[32 ^ 40] = I("2:\u00030\r3\n\u00107\u00138", "VUvRa");
         I[69 ^ 76] = I("\t\u0017=#", "orOMk");
         I[97 ^ 107] = I("&\u001f%\u0010", "tPvUv");
         I[9 ^ 2] = I("\u0014;=4<\u0015\u000b:9#\u0015", "pTHVP");
         I[172 ^ 160] = I("\u001d%\n\b", "oJymi");
         I[24 ^ 21] = I("\u0013\u0015\u0003\r\u0003\n\u0015", "CTFBM");
         I[11 ^ 5] = I("\u001d/\u001c\u0007\f\u0004/", "mNyhb");
      }

      public static BlockDoublePlant.EnumPlantType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }
   }
}

package net.minecraft.block;

import com.google.common.base.MoreObjects;
import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockTripWireHook extends Block {
   // $FF: synthetic field
   public static final PropertyBool ATTACHED;
   // $FF: synthetic field
   public static final PropertyBool POWERED;
   // $FF: synthetic field
   protected static final AxisAlignedBB HOOK_SOUTH_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB HOOK_NORTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB HOOK_WEST_AABB;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   protected static final AxisAlignedBB HOOK_EAST_AABB;

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean canPlaceBlockOnSide(World var1, BlockPos var2, EnumFacing var3) {
      EnumFacing var4 = var3.getOpposite();
      BlockPos var5 = var2.offset(var4);
      IBlockState var6 = var1.getBlockState(var5);
      boolean var7 = func_193382_c(var6.getBlock());
      int var10000;
      if (!var7 && var3.getAxis().isHorizontal() && var6.func_193401_d(var1, var5, var3) == BlockFaceShape.SOLID && !var6.canProvidePower()) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[62 ^ 48];
      String var10001 = I[147 ^ 156];
      String var10002 = I[95 ^ 79];
      var10001 = I[126 ^ 111];
      var10000 = I[184 ^ 170];
      var10001 = I[181 ^ 166];
      var10002 = I[87 ^ 67];
      var10001 = I[145 ^ 132];
      var10000 = I[161 ^ 183];
      var10001 = I[184 ^ 175];
      var10002 = I[53 ^ 45];
      var10001 = I[216 ^ 193];
      var10000 = I[186 ^ 160];
      var10001 = I[17 ^ 10];
      var10002 = I[173 ^ 177];
      var10001 = I[151 ^ 138];
      I[84 ^ 74].length();
      I[1 ^ 30].length();
      I[186 ^ 154].length();
      I[174 ^ 143].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[47 ^ 13].length();
      I[108 ^ 79].length();
      var10003["".length()] = FACING;
      I[229 ^ 193].length();
      I[117 ^ 80].length();
      var10003[" ".length()] = POWERED;
      I[188 ^ 154].length();
      I[110 ^ 73].length();
      I[31 ^ 55].length();
      var10003["  ".length()] = ATTACHED;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, EnumFacing.byHorizontalIndex(var1 & "   ".length()));
      PropertyBool var10001 = POWERED;
      int var10002;
      if ((var1 & (69 ^ 77)) > 0) {
         var10002 = " ".length();
         "".length();
         if (-1 == 4) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = ATTACHED;
      if ((var1 & (90 ^ 94)) > 0) {
         var10002 = " ".length();
         "".length();
         if (4 < -1) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   private static void I() {
      I = new String[64 ^ 107];
      I["".length()] = I("寳剩嚬勛", "YFuvw");
      I[" ".length()] = I("仪兙憗扯洤", "KgsNB");
      I["  ".length()] = I("枊宋姞剟", "NMTbk");
      I["   ".length()] = I("敇庇杓", "aWAiu");
      I[195 ^ 199] = I("氋氣岓椒位", "NKvok");
      I[114 ^ 119] = I("彰壜殻儁", "lDNOd");
      I[42 ^ 44] = I("刀厭榹梭", "KZCQh");
      I[153 ^ 158] = I("摸庪曘椳割", "GqjBu");
      I[84 ^ 92] = I("朂傻映勌匭", "nDRKM");
      I[118 ^ 127] = I("槛澹烫嚹", "ljheQ");
      I[108 ^ 102] = I("悵啇戹张瀔", "wEhTR");
      I[130 ^ 137] = I("枪婽侰僭函", "OHnrP");
      I[118 ^ 122] = I("凝介", "GGfhQ");
      I[149 ^ 152] = I("揥丈丞", "OMgtN");
      I[173 ^ 163] = I("渻壞", "xkyWe");
      I[61 ^ 50] = I("母徙", "ewKHE");
      I[169 ^ 185] = I("棬媭", "DNAtz");
      I[98 ^ 115] = I("烰擨", "IJlqg");
      I[166 ^ 180] = I("崳怼", "ddOsL");
      I[88 ^ 75] = I("毬湷", "Qmfpb");
      I[80 ^ 68] = I("塧杛", "oVRLF");
      I[98 ^ 119] = I("濘毸", "WHslK");
      I[167 ^ 177] = I("櫨涋", "MRHQQ");
      I[0 ^ 23] = I("槳搋", "HMEjH");
      I[88 ^ 64] = I("倆澈", "szadZ");
      I[50 ^ 43] = I("浼棫", "fijAg");
      I[27 ^ 1] = I("悞憪", "ePwPx");
      I[187 ^ 160] = I("垭塗", "tKqUZ");
      I[4 ^ 24] = I("堣呫", "fpSmo");
      I[71 ^ 90] = I("些宻", "IqwbJ");
      I[16 ^ 14] = I("櫹掮勷卨", "uLIkJ");
      I[57 ^ 38] = I("峞", "lTnIB");
      I[37 ^ 5] = I("劫", "ycCuY");
      I[3 ^ 34] = I("炄嫺", "EJkUS");
      I[157 ^ 191] = I("曎氁殆", "uVTjI");
      I[54 ^ 21] = I("澢炼丶兙嵤", "tcVmc");
      I[86 ^ 114] = I("俯剄廉巺", "pubGk");
      I[52 ^ 17] = I("怂摟榌濭埞", "EKRCT");
      I[185 ^ 159] = I("垀劦孤易", "IuZkh");
      I[99 ^ 68] = I("朎抳", "uMOpj");
      I[69 ^ 109] = I("塳兿灪", "vPTMg");
      I[21 ^ 60] = I("\u001e?1'7\u000b4", "nPFBE");
      I[88 ^ 114] = I("*2?\f ##/", "KFKmC");
   }

   private void notifyNeighbors(World var1, BlockPos var2, EnumFacing var3) {
      var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
      var1.notifyNeighborsOfStateChange(var2.offset(var3.getOpposite()), this, (boolean)"".length());
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (var4 != this && this.checkForDrop(var2, var3, var1)) {
         EnumFacing var6 = (EnumFacing)var1.getValue(FACING);
         if (!this.canPlaceBlockOnSide(var2, var3, var6)) {
            this.dropBlockAsItem(var2, var3, var1, "".length());
            var2.setBlockToAir(var3);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            I["   ".length()].length();
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   public BlockTripWireHook() {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(POWERED, Boolean.valueOf((boolean)"".length())).withProperty(ATTACHED, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.REDSTONE);
      this.setTickRandomly((boolean)" ".length());
   }

   public void calculateState(World var1, BlockPos var2, IBlockState var3, boolean var4, boolean var5, int var6, @Nullable IBlockState var7) {
      EnumFacing var8 = (EnumFacing)var3.getValue(FACING);
      byte var9 = (Boolean)var3.getValue(ATTACHED);
      boolean var10 = (Boolean)var3.getValue(POWERED);
      int var10000;
      if (!var4) {
         var10000 = " ".length();
         "".length();
         if (4 == -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var11 = var10000;
      int var12 = "".length();
      int var13 = "".length();
      IBlockState[] var14 = new IBlockState[48 ^ 26];
      int var15 = " ".length();

      BlockPos var16;
      int var10001;
      while(var15 < (23 ^ 61)) {
         var16 = var2.offset(var8, var15);
         IBlockState var17 = var1.getBlockState(var16);
         if (var17.getBlock() == Blocks.TRIPWIRE_HOOK) {
            if (var17.getValue(FACING) == var8.getOpposite()) {
               var13 = var15;
               "".length();
               if (3 < -1) {
                  throw null;
               }
            }
            break;
         }

         if (var17.getBlock() != Blocks.TRIPWIRE && var15 != var6) {
            var14[var15] = null;
            var11 = "".length();
            "".length();
            if (-1 >= 1) {
               throw null;
            }
         } else {
            if (var15 == var6) {
               var17 = (IBlockState)MoreObjects.firstNonNull(var7, var17);
            }

            if (!(Boolean)var17.getValue(BlockTripWire.DISARMED)) {
               var10000 = " ".length();
               "".length();
               if (4 < 4) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            int var18 = var10000;
            boolean var19 = (Boolean)var17.getValue(BlockTripWire.POWERED);
            if (var18 != 0 && var19) {
               var10001 = " ".length();
               "".length();
               if (false) {
                  throw null;
               }
            } else {
               var10001 = "".length();
            }

            var12 |= var10001;
            var14[var15] = var17;
            if (var15 == var6) {
               var1.scheduleUpdate(var2, this, this.tickRate(var1));
               var11 &= var18;
            }
         }

         ++var15;
         "".length();
         if (4 <= -1) {
            throw null;
         }
      }

      if (var13 > " ".length()) {
         var10001 = " ".length();
         "".length();
         if (3 <= 1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      var11 &= var10001;
      var12 &= var11;
      IBlockState var20 = this.getDefaultState().withProperty(ATTACHED, Boolean.valueOf((boolean)var11)).withProperty(POWERED, Boolean.valueOf((boolean)var12));
      if (var13 > 0) {
         var16 = var2.offset(var8, var13);
         EnumFacing var22 = var8.getOpposite();
         var1.setBlockState(var16, var20.withProperty(FACING, var22), "   ".length());
         I[29 ^ 25].length();
         I[107 ^ 110].length();
         this.notifyNeighbors(var1, var16, var22);
         this.playSound(var1, var16, (boolean)var11, (boolean)var12, (boolean)var9, var10);
      }

      this.playSound(var1, var2, (boolean)var11, (boolean)var12, (boolean)var9, var10);
      if (!var4) {
         var1.setBlockState(var2, var20.withProperty(FACING, var8), "   ".length());
         I[122 ^ 124].length();
         I[48 ^ 55].length();
         if (var5) {
            this.notifyNeighbors(var1, var2, var8);
         }
      }

      if (var9 != var11) {
         int var21 = " ".length();

         while(var21 < var13) {
            BlockPos var23 = var2.offset(var8, var21);
            IBlockState var24 = var14[var21];
            if (var24 != null && var1.getBlockState(var23).getMaterial() != Material.AIR) {
               var1.setBlockState(var23, var24.withProperty(ATTACHED, Boolean.valueOf((boolean)var11)), "   ".length());
               I[112 ^ 120].length();
               I[36 ^ 45].length();
            }

            ++var21;
            "".length();
            if (4 < 1) {
               throw null;
            }
         }
      }

   }

   public void randomTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT_MIPPED;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      this.calculateState(var1, var2, var3, (boolean)"".length(), (boolean)" ".length(), -" ".length(), (IBlockState)null);
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      boolean var4 = (Boolean)var3.getValue(ATTACHED);
      boolean var5 = (Boolean)var3.getValue(POWERED);
      if (var4 || var5) {
         this.calculateState(var1, var2, var3, (boolean)" ".length(), (boolean)"".length(), -" ".length(), (IBlockState)null);
      }

      if (var5) {
         var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
         var1.notifyNeighborsOfStateChange(var2.offset(((EnumFacing)var3.getValue(FACING)).getOpposite()), this, (boolean)"".length());
      }

      super.breakBlock(var1, var2, var3);
   }

   private boolean checkForDrop(World var1, BlockPos var2, IBlockState var3) {
      if (!this.canPlaceBlockAt(var1, var2)) {
         this.dropBlockAsItem(var1, var2, var3, "".length());
         var1.setBlockToAir(var2);
         I[21 ^ 31].length();
         I[47 ^ 36].length();
         I[114 ^ 126].length();
         I[31 ^ 18].length();
         return (boolean)"".length();
      } else {
         return (boolean)" ".length();
      }
   }

   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (!(Boolean)var1.getValue(POWERED)) {
         return "".length();
      } else {
         int var10000;
         if (var1.getValue(FACING) == var4) {
            var10000 = 54 ^ 57;
            "".length();
            if (2 < 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return var10000;
      }
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public boolean canProvidePower(IBlockState var1) {
      return (boolean)" ".length();
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      IBlockState var9 = this.getDefaultState().withProperty(POWERED, Boolean.valueOf((boolean)"".length())).withProperty(ATTACHED, Boolean.valueOf((boolean)"".length()));
      if (var3.getAxis().isHorizontal()) {
         var9 = var9.withProperty(FACING, var3);
      }

      return var9;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      Iterator var3 = EnumFacing.Plane.HORIZONTAL.iterator();

      do {
         if (!var3.hasNext()) {
            return (boolean)"".length();
         }

         EnumFacing var4 = (EnumFacing)var3.next();
         if (this.canPlaceBlockOnSide(var1, var2, var4)) {
            return (boolean)" ".length();
         }

         "".length();
      } while(3 > 1);

      throw null;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
      default:
         return HOOK_EAST_AABB;
      case 2:
         return HOOK_WEST_AABB;
      case 3:
         return HOOK_SOUTH_AABB;
      case 4:
         return HOOK_NORTH_AABB;
      }
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      this.calculateState(var1, var2, var3, (boolean)"".length(), (boolean)"".length(), -" ".length(), (IBlockState)null);
   }

   private void playSound(World var1, BlockPos var2, boolean var3, boolean var4, boolean var5, boolean var6) {
      if (var4 && !var6) {
         var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_TRIPWIRE_CLICK_ON, SoundCategory.BLOCKS, 0.4F, 0.6F);
         "".length();
         if (0 == 4) {
            throw null;
         }
      } else if (!var4 && var6) {
         var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_TRIPWIRE_CLICK_OFF, SoundCategory.BLOCKS, 0.4F, 0.5F);
         "".length();
         if (3 >= 4) {
            throw null;
         }
      } else if (var3 && !var5) {
         var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_TRIPWIRE_ATTACH, SoundCategory.BLOCKS, 0.4F, 0.7F);
         "".length();
         if (0 >= 4) {
            throw null;
         }
      } else if (!var3 && var5) {
         var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_TRIPWIRE_DETACH, SoundCategory.BLOCKS, 0.4F, 1.2F / (var1.rand.nextFloat() * 0.2F + 0.9F));
      }

   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
      if ((Boolean)var1.getValue(POWERED)) {
         var2 |= 74 ^ 66;
      }

      if ((Boolean)var1.getValue(ATTACHED)) {
         var2 |= 149 ^ 145;
      }

      return var2;
   }

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if ((Boolean)var1.getValue(POWERED)) {
         var10000 = 107 ^ 100;
         "".length();
         if (-1 >= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      POWERED = PropertyBool.create(I[60 ^ 21]);
      ATTACHED = PropertyBool.create(I[148 ^ 190]);
      HOOK_NORTH_AABB = new AxisAlignedBB(0.3125D, 0.0D, 0.625D, 0.6875D, 0.625D, 1.0D);
      HOOK_SOUTH_AABB = new AxisAlignedBB(0.3125D, 0.0D, 0.0D, 0.6875D, 0.625D, 0.375D);
      HOOK_WEST_AABB = new AxisAlignedBB(0.625D, 0.0D, 0.3125D, 1.0D, 0.625D, 0.6875D);
      HOOK_EAST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.3125D, 0.375D, 0.625D, 0.6875D);
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }
}

package net.minecraft.block;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockChorusPlant extends Block {
   // $FF: synthetic field
   public static final PropertyBool SOUTH;
   // $FF: synthetic field
   public static final PropertyBool WEST;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool DOWN;
   // $FF: synthetic field
   public static final PropertyBool EAST;
   // $FF: synthetic field
   public static final PropertyBool NORTH;
   // $FF: synthetic field
   public static final PropertyBool UP;

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      String var10000 = I[134 ^ 128];
      String var10001 = I[61 ^ 58];
      String var10002 = I[3 ^ 11];
      var10001 = I[120 ^ 113];
      var10000 = I[74 ^ 64];
      var10001 = I[158 ^ 149];
      var10002 = I[126 ^ 114];
      var10001 = I[136 ^ 133];
      var10000 = I[183 ^ 185];
      var10001 = I[53 ^ 58];
      var10002 = I[21 ^ 5];
      var10001 = I[102 ^ 119];
      var10000 = I[20 ^ 6];
      var10001 = I[34 ^ 49];
      var10002 = I[8 ^ 28];
      var10001 = I[144 ^ 133];
      var10000 = I[170 ^ 188];
      var10001 = I[81 ^ 70];
      var10002 = I[174 ^ 182];
      var10001 = I[169 ^ 176];
      var10000 = I[135 ^ 157];
      var10001 = I[131 ^ 152];
      var10002 = I[73 ^ 85];
      var10001 = I[157 ^ 128];
      var10000 = I[154 ^ 132];
      var10001 = I[118 ^ 105];
      var10002 = I[80 ^ 112];
      var10001 = I[16 ^ 49];
      if (!var7) {
         var1 = var1.getActualState(var2, var3);
      }

      float var8 = 0.1875F;
      float var9 = 0.8125F;
      I[118 ^ 84].length();
      I[33 ^ 2].length();
      I[37 ^ 1].length();
      addCollisionBoxToList(var3, var4, var5, new AxisAlignedBB(0.1875D, 0.1875D, 0.1875D, 0.8125D, 0.8125D, 0.8125D));
      if ((Boolean)var1.getValue(WEST)) {
         I[95 ^ 122].length();
         I[231 ^ 193].length();
         addCollisionBoxToList(var3, var4, var5, new AxisAlignedBB(0.0D, 0.1875D, 0.1875D, 0.1875D, 0.8125D, 0.8125D));
      }

      if ((Boolean)var1.getValue(EAST)) {
         I[0 ^ 39].length();
         I[135 ^ 175].length();
         addCollisionBoxToList(var3, var4, var5, new AxisAlignedBB(0.8125D, 0.1875D, 0.1875D, 1.0D, 0.8125D, 0.8125D));
      }

      if ((Boolean)var1.getValue(UP)) {
         I[28 ^ 53].length();
         I[173 ^ 135].length();
         I[145 ^ 186].length();
         addCollisionBoxToList(var3, var4, var5, new AxisAlignedBB(0.1875D, 0.8125D, 0.1875D, 0.8125D, 1.0D, 0.8125D));
      }

      if ((Boolean)var1.getValue(DOWN)) {
         I[3 ^ 47].length();
         addCollisionBoxToList(var3, var4, var5, new AxisAlignedBB(0.1875D, 0.0D, 0.1875D, 0.8125D, 0.1875D, 0.8125D));
      }

      if ((Boolean)var1.getValue(NORTH)) {
         I[13 ^ 32].length();
         I[71 ^ 105].length();
         I[136 ^ 167].length();
         addCollisionBoxToList(var3, var4, var5, new AxisAlignedBB(0.1875D, 0.1875D, 0.0D, 0.8125D, 0.8125D, 0.1875D));
      }

      if ((Boolean)var1.getValue(SOUTH)) {
         I[107 ^ 91].length();
         I[41 ^ 24].length();
         I[104 ^ 90].length();
         addCollisionBoxToList(var3, var4, var5, new AxisAlignedBB(0.1875D, 0.1875D, 0.8125D, 0.8125D, 0.8125D, 1.0D));
      }

   }

   public int quantityDropped(Random var1) {
      return var1.nextInt("  ".length());
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!this.canSurviveAt(var1, var2)) {
         var1.destroyBlock(var2, (boolean)" ".length());
         I[152 ^ 171].length();
         I[8 ^ 60].length();
         I[41 ^ 28].length();
      }

   }

   static {
      I();
      NORTH = PropertyBool.create(I[122 ^ 28]);
      EAST = PropertyBool.create(I[17 ^ 118]);
      SOUTH = PropertyBool.create(I[220 ^ 180]);
      WEST = PropertyBool.create(I[69 ^ 44]);
      UP = PropertyBool.create(I[75 ^ 33]);
      DOWN = PropertyBool.create(I[252 ^ 151]);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!this.canSurviveAt(var2, var3)) {
         var2.scheduleUpdate(var3, this, " ".length());
      }

   }

   protected BlockChorusPlant() {
      super(Material.PLANTS, MapColor.PURPLE);
      this.setCreativeTab(CreativeTabs.DECORATIONS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(NORTH, Boolean.valueOf((boolean)"".length())).withProperty(EAST, Boolean.valueOf((boolean)"".length())).withProperty(SOUTH, Boolean.valueOf((boolean)"".length())).withProperty(WEST, Boolean.valueOf((boolean)"".length())).withProperty(UP, Boolean.valueOf((boolean)"".length())).withProperty(DOWN, Boolean.valueOf((boolean)"".length())));
   }

   public boolean canSurviveAt(World var1, BlockPos var2) {
      boolean var3 = var1.isAirBlock(var2.up());
      boolean var4 = var1.isAirBlock(var2.down());
      Iterator var5 = EnumFacing.Plane.HORIZONTAL.iterator();

      do {
         if (!var5.hasNext()) {
            Block var10 = var1.getBlockState(var2.down()).getBlock();
            int var10000;
            if (var10 != this && var10 != Blocks.END_STONE) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (1 <= -1) {
                  throw null;
               }
            }

            return (boolean)var10000;
         }

         EnumFacing var6 = (EnumFacing)var5.next();
         BlockPos var7 = var2.offset(var6);
         Block var8 = var1.getBlockState(var7).getBlock();
         if (var8 == this) {
            if (!var3 && !var4) {
               return (boolean)"".length();
            }

            Block var9 = var1.getBlockState(var7.down()).getBlock();
            if (var9 == this || var9 == Blocks.END_STONE) {
               return (boolean)" ".length();
            }
         }

         "".length();
      } while(0 < 2);

      throw null;
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (super.canPlaceBlockAt(var1, var2)) {
         var10000 = this.canSurviveAt(var1, var2);
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private static void I() {
      I = new String[61 ^ 81];
      I["".length()] = I("嗑峷", "VLdqG");
      I[" ".length()] = I("桹慆", "pNwhQ");
      I["  ".length()] = I("守厘", "EyQbV");
      I["   ".length()] = I("嬿坆", "bcGza");
      I[192 ^ 196] = I("溬勌橺掛", "maUqb");
      I[97 ^ 100] = I("塃壷", "KuhOz");
      I[82 ^ 84] = I("喩嫨", "JKTrf");
      I[167 ^ 160] = I("沗云", "GCEsH");
      I[156 ^ 148] = I("涟炞", "dLeof");
      I[187 ^ 178] = I("憱枑", "dktmu");
      I[45 ^ 39] = I("棠掇", "qvlJj");
      I[115 ^ 120] = I("乙汪", "gPobQ");
      I[123 ^ 119] = I("噰尽", "agcMU");
      I[87 ^ 90] = I("昼柬", "rPJni");
      I[139 ^ 133] = I("殬勑", "fUNyP");
      I[148 ^ 155] = I("姚庇", "Wtyab");
      I[139 ^ 155] = I("响哼", "lmhIl");
      I[159 ^ 142] = I("樸杀", "gkGcM");
      I[129 ^ 147] = I("帼沒", "RtSYe");
      I[135 ^ 148] = I("揿傪", "omhNZ");
      I[67 ^ 87] = I("澯导", "ZMvdQ");
      I[16 ^ 5] = I("唼寗", "BHygl");
      I[0 ^ 22] = I("嶟懿", "CtYcA");
      I[117 ^ 98] = I("户或", "pddQC");
      I[180 ^ 172] = I("憴敐", "KPAfF");
      I[126 ^ 103] = I("嶕嚔", "eAlev");
      I[53 ^ 47] = I("厅劙", "egkBk");
      I[34 ^ 57] = I("僚庳", "cqcTy");
      I[115 ^ 111] = I("怚惀", "JIXjj");
      I[42 ^ 55] = I("挼优", "TrWHQ");
      I[155 ^ 133] = I("柚倊", "nqtbl");
      I[62 ^ 33] = I("奯婿", "WkPOI");
      I[20 ^ 52] = I("嘺俾", "hIqZD");
      I[31 ^ 62] = I("慣欂", "WKHYH");
      I[86 ^ 116] = I("婇滶", "qaPPe");
      I[78 ^ 109] = I("婖嗸樷煦", "QeGDI");
      I[66 ^ 102] = I("噪曐姐棣", "MpRHV");
      I[28 ^ 57] = I("杌淆炿怅栅", "ynCvO");
      I[165 ^ 131] = I("潚泊囧", "YtCfz");
      I[92 ^ 123] = I("晤只扸", "cinpn");
      I[139 ^ 163] = I("咝煎", "Eqcwf");
      I[104 ^ 65] = I("恾厸", "wcumf");
      I[233 ^ 195] = I("栓煉巔潤", "Amoam");
      I[104 ^ 67] = I("呐", "tvyTA");
      I[105 ^ 69] = I("渟憺", "BEBgF");
      I[46 ^ 3] = I("三灩涳戝喲", "mnufb");
      I[90 ^ 116] = I("堷揅慐浬", "RvMBO");
      I[114 ^ 93] = I("涕崟抸娉", "iVkXr");
      I[171 ^ 155] = I("捷宙", "VpJYC");
      I[85 ^ 100] = I("渕", "iqHJZ");
      I[112 ^ 66] = I("岴俓圸", "MXnMz");
      I[120 ^ 75] = I("渢煛幌", "cOcSe");
      I[34 ^ 22] = I("学唪", "gXOSW");
      I[166 ^ 147] = I("昷哭", "AHvMR");
      I[90 ^ 108] = I("姤妼", "IAVDm");
      I[95 ^ 104] = I("扎幋", "nfjIr");
      I[111 ^ 87] = I("扤每", "FWODd");
      I[130 ^ 187] = I("沆柳", "zUCNs");
      I[119 ^ 77] = I("厉傤", "zwpag");
      I[22 ^ 45] = I("摁呵", "DwbMs");
      I[50 ^ 14] = I("橗嗄", "ljvkZ");
      I[166 ^ 155] = I("桶愪", "Hkyml");
      I[69 ^ 123] = I("寶欳", "yHWgu");
      I[113 ^ 78] = I("尿搨", "dWRKq");
      I[13 ^ 77] = I("撓気", "zAadQ");
      I[202 ^ 139] = I("儚灊", "xSzZK");
      I[39 ^ 101] = I("妉氚", "ovclY");
      I[126 ^ 61] = I("娸偝", "ttgiF");
      I[103 ^ 35] = I("濉娬", "sFyYY");
      I[112 ^ 53] = I("撚塼", "dDsTJ");
      I[28 ^ 90] = I("炅樟", "DQiLM");
      I[101 ^ 34] = I("搖崠", "Xvryu");
      I[84 ^ 28] = I("乬何", "GVTGo");
      I[87 ^ 30] = I("椔歡", "oPhxW");
      I[230 ^ 172] = I("東婸", "UUBqS");
      I[238 ^ 165] = I("栟勀", "ZoEKM");
      I[209 ^ 157] = I("亟濂", "YPVHM");
      I[237 ^ 160] = I("炦源", "FwsWN");
      I[106 ^ 36] = I("涁滙", "CbZpS");
      I[85 ^ 26] = I("噿恷", "ECrnt");
      I[70 ^ 22] = I("愔枭", "dJbIl");
      I[196 ^ 149] = I("侼嵥", "ScgEI");
      I[253 ^ 175] = I("久丅渿", "edckK");
      I[51 ^ 96] = I("呖叝", "pwiHk");
      I[53 ^ 97] = I("櫽帕壼", "rCHkA");
      I[151 ^ 194] = I("晙嶀溮溾怮", "Uxehn");
      I[227 ^ 181] = I("朄汪煯柒壦", "ioahW");
      I[105 ^ 62] = I("渥歋", "MLuZH");
      I[238 ^ 182] = I("夅", "eTsYg");
      I[252 ^ 165] = I("昻淈", "YjQia");
      I[120 ^ 34] = I("櫲榶峗", "QVcrx");
      I[97 ^ 58] = I("園嶁斈冺", "jFjSf");
      I[93 ^ 1] = I("垙掝嘪歘", "DDDUm");
      I[56 ^ 101] = I("叒悔朧搛", "Fukcs");
      I[72 ^ 22] = I("坩", "GrxoD");
      I[223 ^ 128] = I("儃", "IMmoF");
      I[115 ^ 19] = I("憷俞亜料卫", "elvRh");
      I[60 ^ 93] = I("昁栣", "DYBuO");
      I[165 ^ 199] = I("怊婽氩", "rfGEJ");
      I[160 ^ 195] = I("嚇哻楽滧", "PLjOF");
      I[240 ^ 148] = I("嘧歶", "DYRQZ");
      I[89 ^ 60] = I("替", "fTxXG");
      I[200 ^ 174] = I(" ;+\u0001\u0010", "NTYux");
      I[108 ^ 11] = I("\u000f\u000e'\u0013", "joTgi");
      I[203 ^ 163] = I("480\r\u001d", "GWEyu");
      I[213 ^ 188] = I("9#\u0012=", "NFaIe");
      I[245 ^ 159] = I("\f\u0005", "yudBz");
      I[40 ^ 67] = I("/\u0006\"\u001a", "KiUtj");
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[78 ^ 120];
      String var10001 = I[101 ^ 82];
      String var10002 = I[116 ^ 76];
      var10001 = I[44 ^ 21];
      var10000 = I[76 ^ 118];
      var10001 = I[63 ^ 4];
      var10002 = I[40 ^ 20];
      var10001 = I[77 ^ 112];
      var10000 = I[14 ^ 48];
      var10001 = I[172 ^ 147];
      var10002 = I[108 ^ 44];
      var10001 = I[205 ^ 140];
      var10000 = I[115 ^ 49];
      var10001 = I[104 ^ 43];
      var10002 = I[133 ^ 193];
      var10001 = I[130 ^ 199];
      var10000 = I[31 ^ 89];
      var10001 = I[89 ^ 30];
      var10002 = I[96 ^ 40];
      var10001 = I[113 ^ 56];
      var10000 = I[121 ^ 51];
      var10001 = I[200 ^ 131];
      var10002 = I[45 ^ 97];
      var10001 = I[205 ^ 128];
      var10000 = I[212 ^ 154];
      var10001 = I[205 ^ 130];
      var10002 = I[23 ^ 71];
      var10001 = I[50 ^ 99];
      I[97 ^ 51].length();
      I[212 ^ 135].length();
      I[55 ^ 99].length();
      IProperty[] var10003 = new IProperty[2 ^ 4];
      I[192 ^ 149].length();
      I[95 ^ 9].length();
      I[207 ^ 152].length();
      var10003["".length()] = NORTH;
      I[34 ^ 122].length();
      I[244 ^ 173].length();
      I[252 ^ 166].length();
      I[49 ^ 106].length();
      var10003[" ".length()] = EAST;
      I[105 ^ 53].length();
      I[115 ^ 46].length();
      var10003["  ".length()] = SOUTH;
      I[75 ^ 21].length();
      I[79 ^ 16].length();
      var10003["   ".length()] = WEST;
      I[76 ^ 44].length();
      I[15 ^ 110].length();
      I[85 ^ 55].length();
      var10003[68 ^ 64] = UP;
      I[124 ^ 31].length();
      I[248 ^ 156].length();
      I[39 ^ 66].length();
      var10003[4 ^ 1] = DOWN;
      return new BlockStateContainer(this, var10003);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var1 = var1.getActualState(var2, var3);
      float var4 = 0.1875F;
      float var11;
      if ((Boolean)var1.getValue(WEST)) {
         var11 = 0.0F;
         "".length();
         if (-1 >= 1) {
            throw null;
         }
      } else {
         var11 = 0.1875F;
      }

      float var5 = var11;
      if ((Boolean)var1.getValue(DOWN)) {
         var11 = 0.0F;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var11 = 0.1875F;
      }

      float var6 = var11;
      if ((Boolean)var1.getValue(NORTH)) {
         var11 = 0.0F;
         "".length();
         if (0 == 4) {
            throw null;
         }
      } else {
         var11 = 0.1875F;
      }

      float var7 = var11;
      if ((Boolean)var1.getValue(EAST)) {
         var11 = 1.0F;
         "".length();
         if (2 == 0) {
            throw null;
         }
      } else {
         var11 = 0.8125F;
      }

      float var8 = var11;
      if ((Boolean)var1.getValue(UP)) {
         var11 = 1.0F;
         "".length();
         if (1 == 4) {
            throw null;
         }
      } else {
         var11 = 0.8125F;
      }

      float var9 = var11;
      if ((Boolean)var1.getValue(SOUTH)) {
         var11 = 1.0F;
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var11 = 0.8125F;
      }

      float var10 = var11;
      I[146 ^ 150].length();
      I[137 ^ 140].length();
      return new AxisAlignedBB((double)var5, (double)var6, (double)var7, (double)var8, (double)var9, (double)var10);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      Block var5 = var2.getBlockState(var3.offset(var4)).getBlock();
      int var10000;
      if (var5 != this && var5 != Blocks.CHORUS_FLOWER && (var4 != EnumFacing.DOWN || var5 != Blocks.END_STONE)) {
         var10000 = " ".length();
         "".length();
         if (0 == -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 3);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      return "".length();
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.CHORUS_FRUIT;
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      return (boolean)"".length();
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      Block var4 = var2.getBlockState(var3.down()).getBlock();
      Block var5 = var2.getBlockState(var3.up()).getBlock();
      Block var6 = var2.getBlockState(var3.north()).getBlock();
      Block var7 = var2.getBlockState(var3.east()).getBlock();
      Block var8 = var2.getBlockState(var3.south()).getBlock();
      Block var9 = var2.getBlockState(var3.west()).getBlock();
      PropertyBool var10001 = DOWN;
      int var10002;
      if (var4 != this && var4 != Blocks.CHORUS_FLOWER && var4 != Blocks.END_STONE) {
         var10002 = "".length();
      } else {
         var10002 = " ".length();
         "".length();
         if (1 == 3) {
            throw null;
         }
      }

      IBlockState var10000 = var1.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = UP;
      if (var5 != this && var5 != Blocks.CHORUS_FLOWER) {
         var10002 = "".length();
      } else {
         var10002 = " ".length();
         "".length();
         if (2 == 3) {
            throw null;
         }
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = NORTH;
      if (var6 != this && var6 != Blocks.CHORUS_FLOWER) {
         var10002 = "".length();
      } else {
         var10002 = " ".length();
         "".length();
         if (4 < 0) {
            throw null;
         }
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = EAST;
      if (var7 != this && var7 != Blocks.CHORUS_FLOWER) {
         var10002 = "".length();
      } else {
         var10002 = " ".length();
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = SOUTH;
      if (var8 != this && var8 != Blocks.CHORUS_FLOWER) {
         var10002 = "".length();
      } else {
         var10002 = " ".length();
         "".length();
         if (2 == -1) {
            throw null;
         }
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = WEST;
      if (var9 != this && var9 != Blocks.CHORUS_FLOWER) {
         var10002 = "".length();
      } else {
         var10002 = " ".length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }
}

package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;

public class PlayerHurtEntityTrigger implements ICriterionTrigger<PlayerHurtEntityTrigger.Instance> {
   // $FF: synthetic field
   private final Map<PlayerAdvancements, PlayerHurtEntityTrigger.Listeners> field_192223_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final ResourceLocation field_192222_a;

   public ResourceLocation func_192163_a() {
      return field_192222_a;
   }

   static {
      I();
      field_192222_a = new ResourceLocation(I[29 ^ 5]);
   }

   public PlayerHurtEntityTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[170 ^ 186];
      String var10001 = I[28 ^ 13];
      String var10002 = I[22 ^ 4];
      var10001 = I[12 ^ 31];
      DamagePredicate var3 = DamagePredicate.func_192364_a(var1.get(I[118 ^ 98]));
      EntityPredicate var4 = EntityPredicate.func_192481_a(var1.get(I[71 ^ 82]));
      I[61 ^ 43].length();
      I[20 ^ 3].length();
      return new PlayerHurtEntityTrigger.Instance(var3, var4);
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192223_b.remove(var1);
      I[104 ^ 99].length();
      I[179 ^ 191].length();
      I[22 ^ 27].length();
      I[98 ^ 108].length();
      I[144 ^ 159].length();
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<PlayerHurtEntityTrigger.Instance> var2) {
      PlayerHurtEntityTrigger.Listeners var3 = (PlayerHurtEntityTrigger.Listeners)this.field_192223_b.get(var1);
      if (var3 != null) {
         var3.func_192519_b(var2);
         if (var3.func_192520_a()) {
            this.field_192223_b.remove(var1);
            I[119 ^ 126].length();
            I[160 ^ 170].length();
         }
      }

   }

   public void func_192220_a(EntityPlayerMP var1, Entity var2, DamageSource var3, float var4, float var5, boolean var6) {
      PlayerHurtEntityTrigger.Listeners var7 = (PlayerHurtEntityTrigger.Listeners)this.field_192223_b.get(var1.func_192039_O());
      if (var7 != null) {
         var7.func_192521_a(var1, var2, var3, var4, var5, var6);
      }

   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<PlayerHurtEntityTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      PlayerHurtEntityTrigger.Listeners var3 = (PlayerHurtEntityTrigger.Listeners)this.field_192223_b.get(var1);
      if (var3 == null) {
         I[176 ^ 180].length();
         I[25 ^ 28].length();
         var3 = new PlayerHurtEntityTrigger.Listeners(var1);
         this.field_192223_b.put(var1, var3);
         I[114 ^ 116].length();
         I[133 ^ 130].length();
         I[169 ^ 161].length();
      }

      var3.func_192522_a(var2);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   private static void I() {
      I = new String[76 ^ 85];
      I["".length()] = I("堠樓", "BvtpS");
      I[" ".length()] = I("嫩滃", "ExCZr");
      I["  ".length()] = I("媨倃", "FaAIz");
      I["   ".length()] = I("巤昵", "yMcJq");
      I[28 ^ 24] = I("烻", "KNGfi");
      I[141 ^ 136] = I("嶽", "ZMawC");
      I[53 ^ 51] = I("渟冣埣", "EbhPh");
      I[73 ^ 78] = I("欍峂乵", "aOGUW");
      I[141 ^ 133] = I("壇", "VuZod");
      I[71 ^ 78] = I("摓佊嗑拎", "UQPwJ");
      I[149 ^ 159] = I("廅槳啍", "nakyo");
      I[44 ^ 39] = I("伖", "NigLG");
      I[179 ^ 191] = I("改渼仭囍", "fKcgm");
      I[45 ^ 32] = I("匙楫滇咚", "enXbm");
      I[107 ^ 101] = I("唪尭叉忸", "VPilA");
      I[200 ^ 199] = I("冸巘伝", "SUNwK");
      I[191 ^ 175] = I("椩徠", "fGRPF");
      I[132 ^ 149] = I("揣噗", "NFvyz");
      I[94 ^ 76] = I("媫搰", "WvqWV");
      I[215 ^ 196] = I("憗峙", "mrLum");
      I[214 ^ 194] = I("2\u0004\n.!3", "VegOF");
      I[110 ^ 123] = I("\u0003\u001b5 .\u001f", "fuAIZ");
      I[132 ^ 146] = I("帹比", "ATgID");
      I[102 ^ 113] = I("付", "FVTvU");
      I[25 ^ 1] = I("\"\"-\u000f& \u0011$\u00031&\u0011)\u00187;:5", "RNLvC");
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final EntityPredicate field_192280_b;
      // $FF: synthetic field
      private final DamagePredicate field_192279_a;

      public boolean func_192278_a(EntityPlayerMP var1, Entity var2, DamageSource var3, float var4, float var5, boolean var6) {
         return (boolean)(!this.field_192279_a.func_192365_a(var1, var3, var4, var5, var6) ? "".length() : this.field_192280_b.func_192482_a(var1, var2));
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 < 3);

         throw null;
      }

      public Instance(DamagePredicate var1, EntityPredicate var2) {
         super(PlayerHurtEntityTrigger.field_192222_a);
         this.field_192279_a = var1;
         this.field_192280_b = var2;
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<PlayerHurtEntityTrigger.Instance>> field_192524_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_192523_a;
      // $FF: synthetic field
      private static final String[] I;

      public void func_192521_a(EntityPlayerMP var1, Entity var2, DamageSource var3, float var4, float var5, boolean var6) {
         ArrayList var7 = null;
         Iterator var8 = this.field_192524_b.iterator();

         ICriterionTrigger.Listener var9;
         while(var8.hasNext()) {
            var9 = (ICriterionTrigger.Listener)var8.next();
            if (((PlayerHurtEntityTrigger.Instance)var9.func_192158_a()).func_192278_a(var1, var2, var3, var4, var5, var6)) {
               if (var7 == null) {
                  var7 = Lists.newArrayList();
               }

               var7.add(var9);
               I[128 ^ 134].length();
            }

            "".length();
            if (4 != 4) {
               throw null;
            }
         }

         if (var7 != null) {
            var8 = var7.iterator();

            while(var8.hasNext()) {
               var9 = (ICriterionTrigger.Listener)var8.next();
               var9.func_192159_a(this.field_192523_a);
               "".length();
               if (4 != 4) {
                  throw null;
               }
            }
         }

      }

      static {
         I();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192523_a = var1;
      }

      public boolean func_192520_a() {
         return this.field_192524_b.isEmpty();
      }

      private static void I() {
         I = new String[76 ^ 75];
         I["".length()] = I("儗嘢巗", "jPnlv");
         I[" ".length()] = I("乄旋炛怈瀘", "ugqVR");
         I["  ".length()] = I("梱勫年坙", "BoXHx");
         I["   ".length()] = I("咘志暟匁俙", "fhjnh");
         I[154 ^ 158] = I("心", "MOdkT");
         I[53 ^ 48] = I("弅椄", "JXynX");
         I[167 ^ 161] = I("嵶", "ubOom");
      }

      public void func_192522_a(ICriterionTrigger.Listener<PlayerHurtEntityTrigger.Instance> var1) {
         this.field_192524_b.add(var1);
         I["".length()].length();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 >= -1);

         throw null;
      }

      public void func_192519_b(ICriterionTrigger.Listener<PlayerHurtEntityTrigger.Instance> var1) {
         this.field_192524_b.remove(var1);
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
         I[4 ^ 0].length();
         I[4 ^ 1].length();
      }
   }
}

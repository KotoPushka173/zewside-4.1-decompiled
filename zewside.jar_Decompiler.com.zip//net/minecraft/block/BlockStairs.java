package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockStairs extends Block {
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_SLAB_BOTTOM;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_QTR_BOT_NORTH;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_QTR_TOP_EAST;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_QTR_TOP_WEST;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_QTR_TOP_SOUTH;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_OCT_BOT_NE;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_QTR_BOT_SOUTH;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_OCT_TOP_NE;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_SLAB_TOP;
   // $FF: synthetic field
   private final IBlockState modelState;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_OCT_BOT_SW;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_QTR_BOT_EAST;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_QTR_BOT_WEST;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_OCT_BOT_SE;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_OCT_TOP_SE;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_OCT_TOP_SW;
   // $FF: synthetic field
   public static final PropertyEnum<BlockStairs.EnumShape> SHAPE;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_OCT_BOT_NW;
   // $FF: synthetic field
   private final Block modelBlock;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_OCT_TOP_NW;
   // $FF: synthetic field
   public static final PropertyEnum<BlockStairs.EnumHalf> HALF;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_QTR_TOP_NORTH;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 1);

      throw null;
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      this.modelState.neighborChanged(var1, var2, Blocks.AIR, var2);
      this.modelBlock.onBlockAdded(var1, var2, this.modelState);
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      this.modelBlock.updateTick(var1, var2, var3, var4);
   }

   public void onBlockClicked(World var1, BlockPos var2, EntityPlayer var3) {
      this.modelBlock.onBlockClicked(var1, var2, var3);
   }

   public void onBlockDestroyedByExplosion(World var1, BlockPos var2, Explosion var3) {
      this.modelBlock.onBlockDestroyedByExplosion(var1, var2, var3);
   }

   public Vec3d modifyAcceleration(World var1, BlockPos var2, Entity var3, Vec3d var4) {
      return this.modelBlock.modifyAcceleration(var1, var2, var3, var4);
   }

   private static AxisAlignedBB getCollQuarterBlock(IBlockState var0) {
      int var10000;
      if (var0.getValue(HALF) == BlockStairs.EnumHalf.TOP) {
         var10000 = " ".length();
         "".length();
         if (4 <= -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var1 = var10000;
      AxisAlignedBB var2;
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var0.getValue(FACING)).ordinal()]) {
      case 1:
      default:
         if (var1 != 0) {
            var2 = AABB_QTR_BOT_NORTH;
            "".length();
            if (0 <= -1) {
               throw null;
            }
         } else {
            var2 = AABB_QTR_TOP_NORTH;
         }

         return var2;
      case 2:
         if (var1 != 0) {
            var2 = AABB_QTR_BOT_SOUTH;
            "".length();
            if (0 == -1) {
               throw null;
            }
         } else {
            var2 = AABB_QTR_TOP_SOUTH;
         }

         return var2;
      case 3:
         if (var1 != 0) {
            var2 = AABB_QTR_BOT_WEST;
            "".length();
            if (1 == 2) {
               throw null;
            }
         } else {
            var2 = AABB_QTR_TOP_WEST;
         }

         return var2;
      case 4:
         if (var1 != 0) {
            var2 = AABB_QTR_BOT_EAST;
            "".length();
            if (-1 >= 4) {
               throw null;
            }
         } else {
            var2 = AABB_QTR_TOP_EAST;
         }

         return var2;
      }
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      IBlockState var9 = super.getStateForPlacement(var1, var2, var3, var4, var5, var6, var7, var8);
      var9 = var9.withProperty(FACING, var8.getHorizontalFacing()).withProperty(SHAPE, BlockStairs.EnumShape.STRAIGHT);
      IBlockState var10000;
      if (var3 != EnumFacing.DOWN && (var3 == EnumFacing.UP || (double)var5 <= 0.5D)) {
         var10000 = var9.withProperty(HALF, BlockStairs.EnumHalf.BOTTOM);
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10000 = var9.withProperty(HALF, BlockStairs.EnumHalf.TOP);
      }

      return var10000;
   }

   protected BlockStairs(IBlockState var1) {
      super(var1.getBlock().blockMaterial);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(HALF, BlockStairs.EnumHalf.BOTTOM).withProperty(SHAPE, BlockStairs.EnumShape.STRAIGHT));
      this.modelBlock = var1.getBlock();
      this.modelState = var1;
      this.setHardness(this.modelBlock.blockHardness);
      this.setResistance(this.modelBlock.blockResistance / 3.0F);
      this.setSoundType(this.modelBlock.blockSoundType);
      this.setLightOpacity(109 + 208 - 306 + 244);
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      return this.modelBlock.canPlaceBlockAt(var1, var2);
   }

   private static AxisAlignedBB getCollEighthBlock(IBlockState var0) {
      EnumFacing var1 = (EnumFacing)var0.getValue(FACING);
      EnumFacing var2;
      switch(null.$SwitchMap$net$minecraft$block$BlockStairs$EnumShape[((BlockStairs.EnumShape)var0.getValue(SHAPE)).ordinal()]) {
      case 1:
      default:
         var2 = var1;
         "".length();
         if (false) {
            throw null;
         }
         break;
      case 2:
         var2 = var1.rotateY();
         "".length();
         if (3 <= 2) {
            throw null;
         }
         break;
      case 3:
         var2 = var1.getOpposite();
         "".length();
         if (false) {
            throw null;
         }
         break;
      case 4:
         var2 = var1.rotateYCCW();
      }

      int var10000;
      if (var0.getValue(HALF) == BlockStairs.EnumHalf.TOP) {
         var10000 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var3 = var10000;
      AxisAlignedBB var4;
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var2.ordinal()]) {
      case 1:
      default:
         if (var3 != 0) {
            var4 = AABB_OCT_BOT_NW;
            "".length();
            if (-1 < -1) {
               throw null;
            }
         } else {
            var4 = AABB_OCT_TOP_NW;
         }

         return var4;
      case 2:
         if (var3 != 0) {
            var4 = AABB_OCT_BOT_SE;
            "".length();
            if (0 >= 2) {
               throw null;
            }
         } else {
            var4 = AABB_OCT_TOP_SE;
         }

         return var4;
      case 3:
         if (var3 != 0) {
            var4 = AABB_OCT_BOT_SW;
            "".length();
            if (4 < 3) {
               throw null;
            }
         } else {
            var4 = AABB_OCT_TOP_SW;
         }

         return var4;
      case 4:
         if (var3 != 0) {
            var4 = AABB_OCT_BOT_NE;
            "".length();
            if (2 < -1) {
               throw null;
            }
         } else {
            var4 = AABB_OCT_TOP_NE;
         }

         return var4;
      }
   }

   public boolean canCollideCheck(IBlockState var1, boolean var2) {
      return this.modelBlock.canCollideCheck(var1, var2);
   }

   public int tickRate(World var1) {
      return this.modelBlock.tickRate(var1);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      var2 = this.getActualState(var2, var1, var3);
      BlockFaceShape var10000;
      if (var4.getAxis() == EnumFacing.Axis.Y) {
         int var7;
         if (var4 == EnumFacing.UP) {
            var7 = " ".length();
            "".length();
            if (4 <= 3) {
               throw null;
            }
         } else {
            var7 = "".length();
         }

         int var10001;
         if (var2.getValue(HALF) == BlockStairs.EnumHalf.TOP) {
            var10001 = " ".length();
            "".length();
            if (1 == 2) {
               throw null;
            }
         } else {
            var10001 = "".length();
         }

         if (var7 == var10001) {
            var10000 = BlockFaceShape.SOLID;
            "".length();
            if (2 <= 1) {
               throw null;
            }
         } else {
            var10000 = BlockFaceShape.UNDEFINED;
         }

         return var10000;
      } else {
         BlockStairs.EnumShape var5 = (BlockStairs.EnumShape)var2.getValue(SHAPE);
         if (var5 != BlockStairs.EnumShape.OUTER_LEFT && var5 != BlockStairs.EnumShape.OUTER_RIGHT) {
            EnumFacing var6 = (EnumFacing)var2.getValue(FACING);
            switch(null.$SwitchMap$net$minecraft$block$BlockStairs$EnumShape[var5.ordinal()]) {
            case 3:
               if (var6 != var4 && var6 != var4.rotateYCCW()) {
                  var10000 = BlockFaceShape.UNDEFINED;
                  "".length();
                  if (4 <= -1) {
                     throw null;
                  }
               } else {
                  var10000 = BlockFaceShape.SOLID;
               }

               return var10000;
            case 4:
               if (var6 != var4 && var6 != var4.rotateY()) {
                  var10000 = BlockFaceShape.UNDEFINED;
                  "".length();
                  if (-1 >= 0) {
                     throw null;
                  }
               } else {
                  var10000 = BlockFaceShape.SOLID;
               }

               return var10000;
            case 5:
               if (var6 == var4) {
                  var10000 = BlockFaceShape.SOLID;
                  "".length();
                  if (false) {
                     throw null;
                  }
               } else {
                  var10000 = BlockFaceShape.UNDEFINED;
               }

               return var10000;
            default:
               return BlockFaceShape.UNDEFINED;
            }
         } else {
            return BlockFaceShape.UNDEFINED;
         }
      }
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[179 ^ 190];
      String var10001 = I[41 ^ 39];
      String var10002 = I[44 ^ 35];
      var10001 = I[12 ^ 28];
      var10000 = I[3 ^ 18];
      var10001 = I[28 ^ 14];
      var10002 = I[65 ^ 82];
      var10001 = I[115 ^ 103];
      var10000 = I[173 ^ 184];
      var10001 = I[129 ^ 151];
      var10002 = I[80 ^ 71];
      var10001 = I[38 ^ 62];
      var10000 = I[75 ^ 82];
      var10001 = I[24 ^ 2];
      var10002 = I[87 ^ 76];
      var10001 = I[16 ^ 12];
      I[63 ^ 34].length();
      I[116 ^ 106].length();
      I[169 ^ 182].length();
      I[108 ^ 76].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[81 ^ 112].length();
      I[183 ^ 149].length();
      I[75 ^ 104].length();
      var10003["".length()] = FACING;
      I[153 ^ 189].length();
      I[11 ^ 46].length();
      I[97 ^ 71].length();
      var10003[" ".length()] = HALF;
      I[32 ^ 7].length();
      I[3 ^ 43].length();
      var10003["  ".length()] = SHAPE;
      return new BlockStateContainer(this, var10003);
   }

   public static boolean isBlockStairs(IBlockState var0) {
      return var0.getBlock() instanceof BlockStairs;
   }

   public float getExplosionResistance(Entity var1) {
      return this.modelBlock.getExplosionResistance(var1);
   }

   private static void I() {
      I = new String[177 ^ 154];
      I["".length()] = I("勥", "GioyU");
      I[" ".length()] = I("嶔", "Iyekg");
      I["  ".length()] = I("気", "ivTmQ");
      I["   ".length()] = I("忛", "rRAfq");
      I[171 ^ 175] = I("庌擘孿寅", "jmjJn");
      I[89 ^ 92] = I("櫢氪", "NDYbH");
      I[175 ^ 169] = I("棑噖岶毾", "DvAgq");
      I[110 ^ 105] = I("凟墬", "WCdhO");
      I[182 ^ 190] = I("嫛瀿", "ZiXQG");
      I[109 ^ 100] = I("屣慉", "WGEwH");
      I[109 ^ 103] = I("擅懎柲懏", "ReaLE");
      I[69 ^ 78] = I("咦噺", "ulPBL");
      I[18 ^ 30] = I("櫎亗灪", "QmXUY");
      I[161 ^ 172] = I("國戫", "mwTjv");
      I[64 ^ 78] = I("徂廱", "SZxNv");
      I[139 ^ 132] = I("歙唧", "WpNXG");
      I[21 ^ 5] = I("氶泽", "SLBpJ");
      I[170 ^ 187] = I("椱楅", "PBdMm");
      I[92 ^ 78] = I("炎巉", "bmNVp");
      I[25 ^ 10] = I("崙涘", "wBiIJ");
      I[184 ^ 172] = I("悗护", "tWbpb");
      I[150 ^ 131] = I("揍巍", "XgWSy");
      I[21 ^ 3] = I("夰榐", "GIDQV");
      I[91 ^ 76] = I("椵嗰", "vErBu");
      I[57 ^ 33] = I("棼澙", "HschQ");
      I[60 ^ 37] = I("史呈", "leukF");
      I[164 ^ 190] = I("巙呤", "AcaDD");
      I[172 ^ 183] = I("啚國", "EgojZ");
      I[14 ^ 18] = I("冫樋", "zRfrU");
      I[63 ^ 34] = I("匳偔咦", "OzNfq");
      I[23 ^ 9] = I("坖旁", "QFKfO");
      I[64 ^ 95] = I("炨摲", "cMdsn");
      I[69 ^ 101] = I("哣展啽潩", "ondoc");
      I[182 ^ 151] = I("搊嵙匳", "FPHzG");
      I[2 ^ 32] = I("梪", "MaTnW");
      I[116 ^ 87] = I("徆氊", "flhoN");
      I[25 ^ 61] = I("劅徹卵伱僠", "igXla");
      I[38 ^ 3] = I("坈扭峦", "srokN");
      I[101 ^ 67] = I("漲滭嶇恽凋", "KeWgj");
      I[172 ^ 139] = I("僥搭圡冯", "CxdtB");
      I[190 ^ 150] = I("匷怈扜", "VIDtp");
      I[128 ^ 169] = I("$,\u001e(", "LMrNR");
      I[82 ^ 120] = I("\u0001\u001c;#\u0015", "rtZSp");
   }

   public void onEntityWalk(World var1, BlockPos var2, Entity var3) {
      this.modelBlock.onEntityWalk(var1, var2, var3);
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      EnumFacing var3 = (EnumFacing)var1.getValue(FACING);
      BlockStairs.EnumShape var4 = (BlockStairs.EnumShape)var1.getValue(SHAPE);
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         if (var3.getAxis() == EnumFacing.Axis.Z) {
            switch(null.$SwitchMap$net$minecraft$block$BlockStairs$EnumShape[var4.ordinal()]) {
            case 1:
               return var1.withRotation(Rotation.CLOCKWISE_180).withProperty(SHAPE, BlockStairs.EnumShape.OUTER_RIGHT);
            case 2:
               return var1.withRotation(Rotation.CLOCKWISE_180).withProperty(SHAPE, BlockStairs.EnumShape.OUTER_LEFT);
            case 3:
               return var1.withRotation(Rotation.CLOCKWISE_180).withProperty(SHAPE, BlockStairs.EnumShape.INNER_LEFT);
            case 4:
               return var1.withRotation(Rotation.CLOCKWISE_180).withProperty(SHAPE, BlockStairs.EnumShape.INNER_RIGHT);
            default:
               return var1.withRotation(Rotation.CLOCKWISE_180);
            }
         }
         break;
      case 2:
         if (var3.getAxis() == EnumFacing.Axis.X) {
            switch(null.$SwitchMap$net$minecraft$block$BlockStairs$EnumShape[var4.ordinal()]) {
            case 1:
               return var1.withRotation(Rotation.CLOCKWISE_180).withProperty(SHAPE, BlockStairs.EnumShape.OUTER_RIGHT);
            case 2:
               return var1.withRotation(Rotation.CLOCKWISE_180).withProperty(SHAPE, BlockStairs.EnumShape.OUTER_LEFT);
            case 3:
               return var1.withRotation(Rotation.CLOCKWISE_180).withProperty(SHAPE, BlockStairs.EnumShape.INNER_RIGHT);
            case 4:
               return var1.withRotation(Rotation.CLOCKWISE_180).withProperty(SHAPE, BlockStairs.EnumShape.INNER_LEFT);
            case 5:
               return var1.withRotation(Rotation.CLOCKWISE_180);
            }
         }
      }

      return super.withMirror(var1, var2);
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      this.modelBlock.breakBlock(var1, var2, this.modelState);
   }

   public boolean isFullyOpaque(IBlockState var1) {
      int var10000;
      if (var1.getValue(HALF) == BlockStairs.EnumHalf.TOP) {
         var10000 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public AxisAlignedBB getSelectedBoundingBox(IBlockState var1, World var2, BlockPos var3) {
      return this.modelState.getSelectedBoundingBox(var2, var3);
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      if (var1.getValue(HALF) == BlockStairs.EnumHalf.TOP) {
         var2 |= 44 ^ 40;
      }

      int var10001 = 1 ^ 4;
      int var10002 = ((EnumFacing)var1.getValue(FACING)).getIndex();
      I[39 ^ 43].length();
      var2 |= var10001 - var10002;
      return var2;
   }

   public int getPackedLightmapCoords(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return this.modelState.getPackedLightmapCoords(var2, var3);
   }

   private static BlockStairs.EnumShape getStairsShape(IBlockState var0, IBlockAccess var1, BlockPos var2) {
      EnumFacing var3 = (EnumFacing)var0.getValue(FACING);
      IBlockState var4 = var1.getBlockState(var2.offset(var3));
      if (isBlockStairs(var4) && var0.getValue(HALF) == var4.getValue(HALF)) {
         EnumFacing var5 = (EnumFacing)var4.getValue(FACING);
         if (var5.getAxis() != ((EnumFacing)var0.getValue(FACING)).getAxis() && isDifferentStairs(var0, var1, var2, var5.getOpposite())) {
            if (var5 == var3.rotateYCCW()) {
               return BlockStairs.EnumShape.OUTER_LEFT;
            }

            return BlockStairs.EnumShape.OUTER_RIGHT;
         }
      }

      IBlockState var7 = var1.getBlockState(var2.offset(var3.getOpposite()));
      if (isBlockStairs(var7) && var0.getValue(HALF) == var7.getValue(HALF)) {
         EnumFacing var6 = (EnumFacing)var7.getValue(FACING);
         if (var6.getAxis() != ((EnumFacing)var0.getValue(FACING)).getAxis() && isDifferentStairs(var0, var1, var2, var6)) {
            if (var6 == var3.rotateYCCW()) {
               return BlockStairs.EnumShape.INNER_LEFT;
            }

            return BlockStairs.EnumShape.INNER_RIGHT;
         }
      }

      return BlockStairs.EnumShape.STRAIGHT;
   }

   @Nullable
   public RayTraceResult collisionRayTrace(IBlockState var1, World var2, BlockPos var3, Vec3d var4, Vec3d var5) {
      ArrayList var6 = Lists.newArrayList();
      Iterator var7 = getCollisionBoxList(this.getActualState(var1, var2, var3)).iterator();

      do {
         if (!var7.hasNext()) {
            RayTraceResult var14 = null;
            double var15 = 0.0D;
            Iterator var10 = var6.iterator();

            do {
               if (!var10.hasNext()) {
                  return var14;
               }

               RayTraceResult var11 = (RayTraceResult)var10.next();
               if (var11 != null) {
                  double var12 = var11.hitVec.squareDistanceTo(var5);
                  if (var12 > var15) {
                     var14 = var11;
                     var15 = var12;
                  }
               }

               "".length();
            } while(2 < 3);

            throw null;
         }

         AxisAlignedBB var8 = (AxisAlignedBB)var7.next();
         var6.add(this.rayTrace(var3, var4, var5, var8));
         I[98 ^ 106].length();
         I[124 ^ 117].length();
         "".length();
      } while(2 < 3);

      throw null;
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      HALF = PropertyEnum.create(I[237 ^ 196], BlockStairs.EnumHalf.class);
      SHAPE = PropertyEnum.create(I[10 ^ 32], BlockStairs.EnumShape.class);
      AABB_SLAB_TOP = new AxisAlignedBB(0.0D, 0.5D, 0.0D, 1.0D, 1.0D, 1.0D);
      AABB_QTR_TOP_WEST = new AxisAlignedBB(0.0D, 0.5D, 0.0D, 0.5D, 1.0D, 1.0D);
      AABB_QTR_TOP_EAST = new AxisAlignedBB(0.5D, 0.5D, 0.0D, 1.0D, 1.0D, 1.0D);
      AABB_QTR_TOP_NORTH = new AxisAlignedBB(0.0D, 0.5D, 0.0D, 1.0D, 1.0D, 0.5D);
      AABB_QTR_TOP_SOUTH = new AxisAlignedBB(0.0D, 0.5D, 0.5D, 1.0D, 1.0D, 1.0D);
      AABB_OCT_TOP_NW = new AxisAlignedBB(0.0D, 0.5D, 0.0D, 0.5D, 1.0D, 0.5D);
      AABB_OCT_TOP_NE = new AxisAlignedBB(0.5D, 0.5D, 0.0D, 1.0D, 1.0D, 0.5D);
      AABB_OCT_TOP_SW = new AxisAlignedBB(0.0D, 0.5D, 0.5D, 0.5D, 1.0D, 1.0D);
      AABB_OCT_TOP_SE = new AxisAlignedBB(0.5D, 0.5D, 0.5D, 1.0D, 1.0D, 1.0D);
      AABB_SLAB_BOTTOM = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
      AABB_QTR_BOT_WEST = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.5D, 0.5D, 1.0D);
      AABB_QTR_BOT_EAST = new AxisAlignedBB(0.5D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
      AABB_QTR_BOT_NORTH = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 0.5D);
      AABB_QTR_BOT_SOUTH = new AxisAlignedBB(0.0D, 0.0D, 0.5D, 1.0D, 0.5D, 1.0D);
      AABB_OCT_BOT_NW = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.5D, 0.5D, 0.5D);
      AABB_OCT_BOT_NE = new AxisAlignedBB(0.5D, 0.0D, 0.0D, 1.0D, 0.5D, 0.5D);
      AABB_OCT_BOT_SW = new AxisAlignedBB(0.0D, 0.0D, 0.5D, 0.5D, 0.5D, 1.0D);
      AABB_OCT_BOT_SE = new AxisAlignedBB(0.5D, 0.0D, 0.5D, 1.0D, 0.5D, 1.0D);
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      this.modelBlock.randomDisplayTick(var1, var2, var3, var4);
   }

   public boolean isCollidable() {
      return this.modelBlock.isCollidable();
   }

   private static List<AxisAlignedBB> getCollisionBoxList(IBlockState var0) {
      ArrayList var1 = Lists.newArrayList();
      int var10000;
      if (var0.getValue(HALF) == BlockStairs.EnumHalf.TOP) {
         var10000 = " ".length();
         "".length();
         if (3 < 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var2 = var10000;
      AxisAlignedBB var10001;
      if (var2 != 0) {
         var10001 = AABB_SLAB_TOP;
         "".length();
         if (3 < 1) {
            throw null;
         }
      } else {
         var10001 = AABB_SLAB_BOTTOM;
      }

      var1.add(var10001);
      I["".length()].length();
      BlockStairs.EnumShape var3 = (BlockStairs.EnumShape)var0.getValue(SHAPE);
      if (var3 == BlockStairs.EnumShape.STRAIGHT || var3 == BlockStairs.EnumShape.INNER_LEFT || var3 == BlockStairs.EnumShape.INNER_RIGHT) {
         var1.add(getCollQuarterBlock(var0));
         I[" ".length()].length();
         I["  ".length()].length();
      }

      if (var3 != BlockStairs.EnumShape.STRAIGHT) {
         var1.add(getCollEighthBlock(var0));
         I["   ".length()].length();
         I[81 ^ 85].length();
         I[136 ^ 141].length();
         I[197 ^ 195].length();
         I[13 ^ 10].length();
      }

      return var1;
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      if (!var7) {
         var1 = this.getActualState(var1, var2, var3);
      }

      Iterator var8 = getCollisionBoxList(var1).iterator();

      do {
         if (!var8.hasNext()) {
            return;
         }

         AxisAlignedBB var9 = (AxisAlignedBB)var8.next();
         addCollisionBoxToList(var3, var4, var5, var9);
         "".length();
      } while(2 >= 1);

      throw null;
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return var1.withProperty(SHAPE, getStairsShape(var1, var2, var3));
   }

   public BlockRenderLayer getBlockLayer() {
      return this.modelBlock.getBlockLayer();
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static boolean isDifferentStairs(IBlockState var0, IBlockAccess var1, BlockPos var2, EnumFacing var3) {
      IBlockState var4 = var1.getBlockState(var2.offset(var3));
      int var10000;
      if (isBlockStairs(var4) && var4.getValue(FACING) == var0.getValue(FACING) && var4.getValue(HALF) == var0.getValue(HALF)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (1 == 4) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return this.modelBlock.getMapColor(this.modelState, var2, var3);
   }

   public void onBlockDestroyedByPlayer(World var1, BlockPos var2, IBlockState var3) {
      this.modelBlock.onBlockDestroyedByPlayer(var1, var2, var3);
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState();
      PropertyEnum var10001 = HALF;
      BlockStairs.EnumHalf var10002;
      if ((var1 & (127 ^ 123)) > 0) {
         var10002 = BlockStairs.EnumHalf.TOP;
         "".length();
         if (3 <= -1) {
            throw null;
         }
      } else {
         var10002 = BlockStairs.EnumHalf.BOTTOM;
      }

      IBlockState var2 = var10000.withProperty(var10001, var10002);
      PropertyDirection var3 = FACING;
      int var4 = 85 ^ 80;
      int var10003 = var1 & "   ".length();
      I[4 ^ 14].length();
      I[164 ^ 175].length();
      var2 = var2.withProperty(var3, EnumFacing.getFront(var4 - var10003));
      return var2;
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      return this.modelBlock.onBlockActivated(var1, var2, this.modelState, var4, var5, EnumFacing.DOWN, 0.0F, 0.0F, 0.0F);
   }

   public static enum EnumShape implements IStringSerializable {
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      STRAIGHT,
      // $FF: synthetic field
      INNER_LEFT,
      // $FF: synthetic field
      OUTER_RIGHT;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      OUTER_LEFT,
      // $FF: synthetic field
      INNER_RIGHT;

      private EnumShape(String var3) {
         this.name = var3;
      }

      static {
         I();
         STRAIGHT = new BlockStairs.EnumShape(I["".length()], "".length(), I[" ".length()]);
         INNER_LEFT = new BlockStairs.EnumShape(I["  ".length()], " ".length(), I["   ".length()]);
         INNER_RIGHT = new BlockStairs.EnumShape(I[3 ^ 7], "  ".length(), I[50 ^ 55]);
         OUTER_LEFT = new BlockStairs.EnumShape(I[79 ^ 73], "   ".length(), I[166 ^ 161]);
         OUTER_RIGHT = new BlockStairs.EnumShape(I[86 ^ 94], 46 ^ 42, I[9 ^ 0]);
         BlockStairs.EnumShape[] var10000 = new BlockStairs.EnumShape[187 ^ 190];
         var10000["".length()] = STRAIGHT;
         var10000[" ".length()] = INNER_LEFT;
         var10000["  ".length()] = INNER_RIGHT;
         var10000["   ".length()] = OUTER_LEFT;
         var10000[69 ^ 65] = OUTER_RIGHT;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 > 3);

         throw null;
      }

      private static void I() {
         I = new String[189 ^ 183];
         I["".length()] = I("7?8&\u0000##>", "dkjgI");
         I[" ".length()] = I("\u0015#%8\u001c\u0001?#", "fWWYu");
         I["  ".length()] = I("\"\u0006\t/:4\u0004\u0002,<", "kHGjh");
         I["   ".length()] = I("(\u00036\u00047\u001e\u0001=\u00071", "AmXaE");
         I[15 ^ 11] = I("$\u0017\u00051\u001b2\u000b\u00023\u00019", "mYKtI");
         I[105 ^ 108] = I(":7;\u000f\u001b\f+<\r\u0001'", "SYUji");
         I[107 ^ 109] = I("(1,\u001f\u00138(=\u001c\u0015", "gdxZA");
         I[33 ^ 38] = I("\u000b<0\u0013\u0002;%!\u0010\u0004", "dIDvp");
         I[123 ^ 115] = I("&\u0018\u001a696\u001f\u00074#=", "iMNsk");
         I[33 ^ 40] = I("-&\u0003\b\u001b\u001d!\u001e\n\u00016", "BSwmi");
      }

      public String getName() {
         return this.name;
      }

      public String toString() {
         return this.name;
      }
   }

   public static enum EnumHalf implements IStringSerializable {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      BOTTOM,
      // $FF: synthetic field
      TOP;

      // $FF: synthetic field
      private final String name;

      public String toString() {
         return this.name;
      }

      public String getName() {
         return this.name;
      }

      private EnumHalf(String var3) {
         this.name = var3;
      }

      private static void I() {
         I = new String[180 ^ 176];
         I["".length()] = I("\u0016\u0000\u0017", "BOGtQ");
         I[" ".length()] = I("7\u001a\u0015", "CueWr");
         I["  ".length()] = I("\u0005\u001a\u001e\u0018\u001f\n", "GUJLP");
         I["   ".length()] = I("5\u0007\f\u0019\":", "WhxmM");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > -1);

         throw null;
      }

      static {
         I();
         TOP = new BlockStairs.EnumHalf(I["".length()], "".length(), I[" ".length()]);
         BOTTOM = new BlockStairs.EnumHalf(I["  ".length()], " ".length(), I["   ".length()]);
         BlockStairs.EnumHalf[] var10000 = new BlockStairs.EnumHalf["  ".length()];
         var10000["".length()] = TOP;
         var10000[" ".length()] = BOTTOM;
      }
   }
}

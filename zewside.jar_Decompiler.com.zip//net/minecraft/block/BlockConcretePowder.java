package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockConcretePowder extends BlockFalling {
   // $FF: synthetic field
   public static final PropertyEnum<EnumDyeColor> field_192426_a;
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
      field_192426_a = PropertyEnum.create(I[104 ^ 116], EnumDyeColor.class);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[160 ^ 173];
      String var10001 = I[58 ^ 52];
      String var10002 = I[17 ^ 30];
      var10001 = I[127 ^ 111];
      var10000 = I[101 ^ 116];
      var10001 = I[74 ^ 88];
      var10002 = I[47 ^ 60];
      var10001 = I[183 ^ 163];
      I[169 ^ 188].length();
      I[37 ^ 51].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[52 ^ 35].length();
      I[185 ^ 161].length();
      I[60 ^ 37].length();
      I[64 ^ 90].length();
      I[103 ^ 124].length();
      var10003["".length()] = field_192426_a;
      return new BlockStateContainer(this, var10003);
   }

   protected boolean func_192425_e(World var1, BlockPos var2, IBlockState var3) {
      int var4 = "".length();
      EnumFacing[] var5 = EnumFacing.values();
      int var6 = var5.length;
      int var7 = "".length();

      while(var7 < var6) {
         EnumFacing var8 = var5[var7];
         if (var8 != EnumFacing.DOWN) {
            BlockPos var9 = var2.offset(var8);
            if (var1.getBlockState(var9).getMaterial() == Material.WATER) {
               var4 = " ".length();
               "".length();
               if (1 <= -1) {
                  throw null;
               }
               break;
            }
         }

         ++var7;
         "".length();
         if (4 == 1) {
            throw null;
         }
      }

      if (var4 != 0) {
         var1.setBlockState(var2, Blocks.field_192443_dR.getDefaultState().withProperty(BlockColored.COLOR, var3.getValue(field_192426_a)), "   ".length());
         I["  ".length()].length();
         I["   ".length()].length();
         I[155 ^ 159].length();
      }

      return (boolean)var4;
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (!this.func_192425_e(var1, var2, var3)) {
         super.onBlockAdded(var1, var2, var3);
      }

   }

   public void onEndFalling(World var1, BlockPos var2, IBlockState var3, IBlockState var4) {
      if (var4.getMaterial().isLiquid()) {
         var1.setBlockState(var2, Blocks.field_192443_dR.getDefaultState().withProperty(BlockColored.COLOR, var3.getValue(field_192426_a)), "   ".length());
         I["".length()].length();
         I[" ".length()].length();
      }

   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(field_192426_a, EnumDyeColor.byMetadata(var1));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(field_192426_a)).getMetadata();
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[120 ^ 125];
      String var10001 = I[190 ^ 184];
      String var10002 = I[36 ^ 35];
      var10001 = I[74 ^ 66];
      EnumDyeColor[] var3 = EnumDyeColor.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         EnumDyeColor var6 = var3[var5];
         I[130 ^ 139].length();
         I[69 ^ 79].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[76 ^ 71].length();
         I[9 ^ 5].length();
         ++var5;
         "".length();
      } while(0 < 4);

      throw null;
   }

   private static void I() {
      I = new String[93 ^ 64];
      I["".length()] = I("慤倪", "xWmbV");
      I[" ".length()] = I("埀啢", "WEkqP");
      I["  ".length()] = I("慩歸枡枇圐", "yKeEb");
      I["   ".length()] = I("煵惋毦煌椘", "wAlXi");
      I[23 ^ 19] = I("慡昲匴毚", "ERTuG");
      I[10 ^ 15] = I("旇檤", "Rhpuu");
      I[45 ^ 43] = I("古俚", "jLjGn");
      I[194 ^ 197] = I("悽劳", "UbMul");
      I[110 ^ 102] = I("妺棙", "rHgHp");
      I[174 ^ 167] = I("扔", "qZDGF");
      I[85 ^ 95] = I("勡埴楳嫴", "cXmPw");
      I[154 ^ 145] = I("埈", "djwbW");
      I[110 ^ 98] = I("枱喬", "WuXSK");
      I[140 ^ 129] = I("柦俶", "FFSLI");
      I[94 ^ 80] = I("撪掂", "GyuCn");
      I[155 ^ 148] = I("孯煪", "vLSti");
      I[96 ^ 112] = I("掤勅", "rjAMF");
      I[27 ^ 10] = I("梂梩", "lQBlt");
      I[86 ^ 68] = I("嶁昋", "EynvY");
      I[19 ^ 0] = I("檏伪", "burgm");
      I[172 ^ 184] = I("扊冔", "RRULQ");
      I[13 ^ 24] = I("災", "GnlwY");
      I[187 ^ 173] = I("沁喋抈", "nmseT");
      I[137 ^ 158] = I("找", "fnqjr");
      I[39 ^ 63] = I("喎檜", "wopzJ");
      I[128 ^ 153] = I("峫摩摟傥検", "sdaBL");
      I[84 ^ 78] = I("澛幑倇圭", "gHFHe");
      I[144 ^ 139] = I("君嚙", "EwJWx");
      I[22 ^ 10] = I("6%< (", "UJPOZ");
   }

   public BlockConcretePowder() {
      super(Material.SAND);
      this.setDefaultState(this.blockState.getBaseState().withProperty(field_192426_a, EnumDyeColor.WHITE));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public int damageDropped(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(field_192426_a)).getMetadata();
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.func_193558_a((EnumDyeColor)var1.getValue(field_192426_a));
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!this.func_192425_e(var2, var3, var1)) {
         super.neighborChanged(var1, var2, var3, var4, var5);
      }

   }
}

package net.minecraft.network;

import com.google.common.collect.Queues;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.viaversion.viaversion.connection.UserConnectionImpl;
import com.viaversion.viaversion.protocol.ProtocolPipelineImpl;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoop;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.epoll.Epoll;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollSocketChannel;
import io.netty.channel.local.LocalChannel;
import io.netty.channel.local.LocalEventLoopGroup;
import io.netty.channel.local.LocalServerChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.TimeoutException;
import io.netty.util.AttributeKey;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.util.Queue;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.annotation.Nullable;
import javax.crypto.SecretKey;
import me.zewside.client.event.EventManager;
import me.zewside.client.event.events.impl.packet.EventReceivePacket;
import me.zewside.client.event.events.impl.packet.EventSendPacket;
import net.minecraft.util.CryptManager;
import net.minecraft.util.ITickable;
import net.minecraft.util.LazyLoadBase;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import viamcp.ViaMCP;
import viamcp.handler.MCPDecodeHandler;
import viamcp.handler.MCPEncodeHandler;
import viamcp.utils.NettyUtil;

public class NetworkManager extends SimpleChannelInboundHandler<Packet<?>> {
   // $FF: synthetic field
   public static final AttributeKey<EnumConnectionState> PROTOCOL_ATTRIBUTE_KEY;
   // $FF: synthetic field
   private INetHandler packetListener;
   // $FF: synthetic field
   private SocketAddress socketAddress;
   // $FF: synthetic field
   public static final Marker NETWORK_PACKETS_MARKER;
   // $FF: synthetic field
   public static final Marker NETWORK_MARKER;
   // $FF: synthetic field
   private boolean disconnected;
   // $FF: synthetic field
   private static final Logger LOGGER;
   // $FF: synthetic field
   private boolean isEncrypted;
   // $FF: synthetic field
   public static final LazyLoadBase<NioEventLoopGroup> CLIENT_NIO_EVENTLOOP;
   // $FF: synthetic field
   private ITextComponent terminationReason;
   // $FF: synthetic field
   private final EnumPacketDirection direction;
   // $FF: synthetic field
   public static final LazyLoadBase<LocalEventLoopGroup> CLIENT_LOCAL_EVENTLOOP;
   // $FF: synthetic field
   public static final LazyLoadBase<EpollEventLoopGroup> CLIENT_EPOLL_EVENTLOOP;
   // $FF: synthetic field
   private Channel channel;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Queue<NetworkManager.InboundHandlerTuplePacketListener> outboundPacketsQueue = Queues.newConcurrentLinkedQueue();
   // $FF: synthetic field
   private final ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();

   public void channelActive(ChannelHandlerContext var1) throws Exception {
      super.channelActive(var1);
      this.channel = var1.channel();
      this.socketAddress = this.channel.remoteAddress();

      try {
         this.setConnectionState(EnumConnectionState.HANDSHAKING);
      } catch (Throwable var3) {
         LOGGER.fatal(var3);
         return;
      }

      "".length();
      if (4 != 4) {
         throw null;
      }
   }

   private void dispatchPacket(final Packet<?> var1, @Nullable final GenericFutureListener<? extends Future<? super Void>>[] var2) {
      String var10000 = I[113 ^ 34];
      String var10001 = I[28 ^ 72];
      String var10002 = I[87 ^ 2];
      var10001 = I[32 ^ 118];
      final EnumConnectionState var3 = EnumConnectionState.getFromPacket(var1);
      final EnumConnectionState var4 = (EnumConnectionState)this.channel.attr(PROTOCOL_ATTRIBUTE_KEY).get();
      if (var4 != var3) {
         LOGGER.debug(I[192 ^ 151]);
         this.channel.config().setAutoRead((boolean)"".length());
         I[199 ^ 159].length();
         I[114 ^ 43].length();
         I[96 ^ 58].length();
         I[195 ^ 152].length();
         I[240 ^ 172].length();
      }

      if (this.channel.eventLoop().inEventLoop()) {
         if (var3 != var4) {
            this.setConnectionState(var3);
         }

         ChannelFuture var5 = this.channel.writeAndFlush(var1);
         if (var2 != null) {
            var5.addListeners(var2);
            I[51 ^ 110].length();
            I[33 ^ 127].length();
         }

         var5.addListener(ChannelFutureListener.FIRE_EXCEPTION_ON_FAILURE);
         I[75 ^ 20].length();
         I[104 ^ 8].length();
         I[30 ^ 127].length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         EventLoop var6 = this.channel.eventLoop();
         I[21 ^ 119].length();
         I[30 ^ 125].length();
         var6.execute(new Runnable() {
            // $FF: synthetic field
            private static final String[] I;

            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(4 != 1);

               throw null;
            }

            public void run() {
               if (var3 != var4) {
                  NetworkManager.this.setConnectionState(var3);
               }

               ChannelFuture var1x = NetworkManager.this.channel.writeAndFlush(var1);
               if (var2 != null) {
                  var1x.addListeners(var2);
                  I["".length()].length();
                  I[" ".length()].length();
               }

               var1x.addListener(ChannelFutureListener.FIRE_EXCEPTION_ON_FAILURE);
               I["  ".length()].length();
               I["   ".length()].length();
               I[16 ^ 20].length();
            }

            static {
               I();
            }

            private static void I() {
               I = new String[184 ^ 189];
               I["".length()] = I("弩", "jSIfN");
               I[" ".length()] = I("惜", "HJoVs");
               I["  ".length()] = I("喡嘰佴", "WaRWF");
               I["   ".length()] = I("澶媻幕檎柭", "rKnvB");
               I[23 ^ 19] = I("妰倗椠", "vCKgc");
            }
         });
      }

   }

   public void setNetHandler(INetHandler var1) {
      Validate.notNull(var1, I[73 ^ 100], new Object["".length()]);
      I[170 ^ 132].length();
      I[189 ^ 146].length();
      I[175 ^ 159].length();
      LOGGER.debug(I[153 ^ 168], this, var1);
      this.packetListener = var1;
   }

   public ITextComponent getExitMessage() {
      return this.terminationReason;
   }

   public SocketAddress getRemoteAddress() {
      return this.socketAddress;
   }

   public void processReceivedPackets() {
      this.flushOutboundQueue();
      if (this.packetListener instanceof ITickable) {
         ((ITickable)this.packetListener).update();
      }

      if (this.channel != null) {
         this.channel.flush();
         I[92 ^ 58].length();
         I[223 ^ 184].length();
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public boolean isLocalChannel() {
      int var10000;
      if (!(this.channel instanceof LocalChannel) && !(this.channel instanceof LocalServerChannel)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public void exceptionCaught(ChannelHandlerContext var1, Throwable var2) throws Exception {
      String var10000 = I[97 ^ 109];
      String var10001 = I[18 ^ 31];
      String var10002 = I[179 ^ 189];
      var10001 = I[74 ^ 69];
      var10000 = I[117 ^ 101];
      var10001 = I[127 ^ 110];
      var10002 = I[189 ^ 175];
      var10001 = I[101 ^ 118];
      var10000 = I[145 ^ 133];
      var10001 = I[22 ^ 3];
      var10002 = I[144 ^ 134];
      var10001 = I[141 ^ 154];
      var10000 = I[45 ^ 53];
      var10001 = I[147 ^ 138];
      var10002 = I[91 ^ 65];
      var10001 = I[24 ^ 3];
      TextComponentTranslation var3;
      if (var2 instanceof TimeoutException) {
         I[170 ^ 182].length();
         var3 = new TextComponentTranslation(I[109 ^ 112], new Object["".length()]);
         "".length();
         if (4 <= 2) {
            throw null;
         }
      } else {
         I[150 ^ 136].length();
         var10002 = I[152 ^ 135];
         Object[] var10003 = new Object[" ".length()];
         I[32 ^ 0].length();
         int var10005 = "".length();
         I[159 ^ 190].length();
         I[30 ^ 60].length();
         var10003[var10005] = I[133 ^ 166] + var2;
         var3 = new TextComponentTranslation(var10002, var10003);
      }

      LOGGER.debug(var3.getUnformattedText(), var2);
      this.closeChannel(var3);
   }

   public static NetworkManager provideLocalClient(SocketAddress var0) {
      String var10000 = I[120 + 30 - 35 + 12];
      String var10001 = I[32 + 127 - 95 + 64];
      String var10002 = I[104 + 106 - 115 + 34];
      var10001 = I[28 + 58 - 45 + 89];
      var10000 = I[99 + 123 - 140 + 49];
      var10001 = I[19 + 39 - -59 + 15];
      var10002 = I[49 + 68 - 98 + 114];
      var10001 = I[34 + 99 - 121 + 122];
      var10000 = I[42 + 125 - 100 + 68];
      var10001 = I[79 + 65 - 103 + 95];
      var10002 = I[19 + 31 - -14 + 73];
      var10001 = I[85 + 100 - 154 + 107];
      I[76 + 35 - 107 + 135].length();
      I[123 + 30 - 34 + 21].length();
      final NetworkManager var1 = new NetworkManager(EnumPacketDirection.CLIENTBOUND);
      I[62 + 14 - 41 + 106].length();
      I[121 + 15 - 34 + 40].length();
      I[54 + 71 - 50 + 68].length();
      Bootstrap var2 = (Bootstrap)(new Bootstrap()).group((EventLoopGroup)CLIENT_LOCAL_EVENTLOOP.getValue());
      I[97 + 65 - 93 + 75].length();
      I[141 + 118 - 125 + 11].length();
      I[130 + 88 - 175 + 103].length();
      ((Bootstrap)((Bootstrap)var2.handler(new ChannelInitializer<Channel>() {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static void I() {
            I = new String[116 ^ 113];
            I["".length()] = I("\u0004\"\u0001\u0011\u0014\u0000\u001c\n\u001b\u001f\u0010/\u0007\b", "tCbzq");
            I[" ".length()] = I("扑", "NvASB");
            I["  ".length()] = I("婥嶽姢揸堆", "qZPLT");
            I["   ".length()] = I("渓渇", "rFwXa");
            I[19 ^ 23] = I("巤", "uIqwZ");
         }

         protected void initChannel(Channel var1x) throws Exception {
            var1x.pipeline().addLast(I["".length()], var1);
            I[" ".length()].length();
            I["  ".length()].length();
            I["   ".length()].length();
            I[98 ^ 102].length();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(0 < 2);

            throw null;
         }
      })).channel(LocalChannel.class)).connect(var0).syncUninterruptibly();
      I[129 + 73 - 113 + 58].length();
      I[25 + 46 - -40 + 37].length();
      I[45 + 8 - 16 + 112].length();
      return var1;
   }

   private void flushOutboundQueue() {
      if (this.channel != null && this.channel.isOpen()) {
         this.readWriteLock.readLock().lock();

         try {
            while(!this.outboundPacketsQueue.isEmpty()) {
               NetworkManager.InboundHandlerTuplePacketListener var1 = (NetworkManager.InboundHandlerTuplePacketListener)this.outboundPacketsQueue.poll();
               this.dispatchPacket(var1.packet, var1.futureListeners);
               "".length();
               if (false) {
                  throw null;
               }
            }
         } catch (Throwable var4) {
            this.readWriteLock.readLock().unlock();
            I[214 ^ 178].length();
            I[3 ^ 102].length();
            throw var4;
         }

         this.readWriteLock.readLock().unlock();
         "".length();
         if (0 <= -1) {
            throw null;
         }
      }

   }

   public void enableEncryption(SecretKey var1) {
      String var10000 = I[47 + 22 - -50 + 31];
      String var10001 = I[112 + 112 - 190 + 117];
      String var10002 = I[48 + 74 - 66 + 96];
      var10001 = I[28 + 126 - 150 + 149];
      var10000 = I[0 + 81 - -55 + 18];
      var10001 = I[139 + 58 - 161 + 119];
      var10002 = I[48 + 110 - 34 + 32];
      var10001 = I[110 + 114 - 150 + 83];
      this.isEncrypted = (boolean)" ".length();
      ChannelPipeline var2 = this.channel.pipeline();
      var10001 = I[47 + 102 - 84 + 93];
      var10002 = I[77 + 83 - 104 + 103];
      I[60 + 16 - -78 + 6].length();
      I[36 + 151 - 85 + 59].length();
      var2.addBefore(var10001, var10002, new NettyEncryptingDecoder(CryptManager.createNetCipherInstance("  ".length(), var1)));
      I[94 + 93 - 37 + 12].length();
      I[95 + 93 - 102 + 77].length();
      I[3 + 24 - -37 + 100].length();
      I[152 + 10 - 18 + 21].length();
      var2 = this.channel.pipeline();
      var10001 = I[115 + 16 - 44 + 79];
      var10002 = I[29 + 138 - 58 + 58];
      I[1 + 154 - 33 + 46].length();
      I[99 + 37 - -21 + 12].length();
      var2.addBefore(var10001, var10002, new NettyEncryptingEncoder(CryptManager.createNetCipherInstance(" ".length(), var1)));
      I[155 + 63 - 72 + 24].length();
   }

   public boolean isEncrypted() {
      return this.isEncrypted;
   }

   public void checkDisconnected() {
      String var10000 = I[185 + 195 - 314 + 144];
      String var10001 = I[196 + 20 - 87 + 82];
      String var10002 = I[28 + 82 - -31 + 71];
      var10001 = I[3 + 30 - 31 + 211];
      if (this.channel != null && !this.channel.isOpen()) {
         if (this.disconnected) {
            LOGGER.warn(I[190 + 182 - 247 + 89]);
            "".length();
            if (3 <= 0) {
               throw null;
            }
         } else {
            this.disconnected = (boolean)" ".length();
            if (this.getExitMessage() != null) {
               this.getNetHandler().onDisconnect(this.getExitMessage());
               "".length();
               if (false) {
                  throw null;
               }
            } else if (this.getNetHandler() != null) {
               INetHandler var1 = this.getNetHandler();
               I[183 + 210 - 178 + 0].length();
               I[163 + 153 - 193 + 93].length();
               I[166 + 148 - 109 + 12].length();
               var1.onDisconnect(new TextComponentTranslation(I[150 + 12 - 41 + 97], new Object["".length()]));
            }
         }
      }

   }

   public void disableAutoRead() {
      this.channel.config().setAutoRead((boolean)"".length());
      I[37 + 131 - 90 + 93].length();
      I[95 + 21 - -15 + 41].length();
   }

   public void channelInactive(ChannelHandlerContext var1) throws Exception {
      String var10000 = I[138 ^ 142];
      String var10001 = I[140 ^ 137];
      String var10002 = I[79 ^ 73];
      var10001 = I[14 ^ 9];
      I[94 ^ 86].length();
      I[60 ^ 53].length();
      I[191 ^ 181].length();
      this.closeChannel(new TextComponentTranslation(I[60 ^ 55], new Object["".length()]));
   }

   public boolean isChannelOpen() {
      int var10000;
      if (this.channel != null && this.channel.isOpen()) {
         var10000 = " ".length();
         "".length();
         if (4 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public void setConnectionState(EnumConnectionState var1) {
      this.channel.attr(PROTOCOL_ATTRIBUTE_KEY).set(var1);
      this.channel.config().setAutoRead((boolean)" ".length());
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      LOGGER.debug(I["   ".length()]);
   }

   public void closeChannel(ITextComponent var1) {
      if (this.channel.isOpen()) {
         this.channel.close().awaitUninterruptibly();
         I[98 ^ 10].length();
         this.terminationReason = var1;
      }

   }

   public void sendPacket(Packet<?> var1) {
      String var10000 = I[156 ^ 174];
      String var10001 = I[128 ^ 179];
      String var10002 = I[65 ^ 117];
      var10001 = I[64 ^ 117];
      var10000 = I[47 ^ 25];
      var10001 = I[65 ^ 118];
      var10002 = I[144 ^ 168];
      var10001 = I[96 ^ 89];
      if (this.isChannelOpen()) {
         I[139 ^ 177].length();
         I[94 ^ 101].length();
         I[113 ^ 77].length();
         EventSendPacket var2 = new EventSendPacket(var1);
         EventManager.call(var2);
         I[252 ^ 193].length();
         I[34 ^ 28].length();
         I[161 ^ 158].length();
         if (!var2.isCancelled()) {
            this.flushOutboundQueue();
            this.dispatchPacket(var2.getPacket(), (GenericFutureListener[])null);
         }

         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         this.readWriteLock.writeLock().lock();

         try {
            Queue var6 = this.outboundPacketsQueue;
            I[219 ^ 155].length();
            I[73 ^ 8].length();
            I[76 ^ 14].length();
            var6.add(new NetworkManager.InboundHandlerTuplePacketListener(var1, new GenericFutureListener["".length()]));
            I[119 ^ 52].length();
            I[7 ^ 67].length();
            I[91 ^ 30].length();
         } catch (Throwable var5) {
            this.readWriteLock.writeLock().unlock();
            I[66 ^ 4].length();
            throw var5;
         }

         this.readWriteLock.writeLock().unlock();
         "".length();
         if (2 != 2) {
            throw null;
         }
      }

   }

   public void setCompressionThreshold(int var1) {
      String var10000 = I[85 + 148 - 186 + 126];
      String var10001 = I[97 + 124 - 205 + 158];
      String var10002 = I[72 + 48 - 84 + 139];
      var10001 = I[117 + 112 - 55 + 2];
      var10000 = I[46 + 20 - -45 + 66];
      var10001 = I[119 + 154 - 160 + 65];
      var10002 = I[130 + 34 - -6 + 9];
      var10001 = I[61 + 13 - -38 + 68];
      if (var1 >= 0) {
         ChannelPipeline var2;
         if (this.channel.pipeline().get(I[69 + 110 - 76 + 78]) instanceof NettyCompressionDecoder) {
            ((NettyCompressionDecoder)this.channel.pipeline().get(I[162 + 83 - 88 + 25])).setCompressionThreshold(var1);
            "".length();
            if (-1 >= 1) {
               throw null;
            }
         } else {
            var2 = this.channel.pipeline();
            var10001 = I[7 + 94 - 86 + 168];
            var10002 = I[62 + 86 - 76 + 112];
            I[59 + 32 - -68 + 26].length();
            I[124 + 31 - -24 + 7].length();
            I[19 + 136 - 42 + 74].length();
            NettyUtil.decodeEncodePlacement(var2, var10001, var10002, new NettyCompressionDecoder(var1));
            I[63 + 41 - -53 + 31].length();
            I[81 + 176 - 126 + 58].length();
            I[99 + 164 - 229 + 156].length();
            I[39 + 100 - -50 + 2].length();
         }

         if (this.channel.pipeline().get(I[191 + 64 - 109 + 46]) instanceof NettyCompressionEncoder) {
            ((NettyCompressionEncoder)this.channel.pipeline().get(I[14 + 139 - 57 + 97])).setCompressionThreshold(var1);
            "".length();
            if (3 != 3) {
               throw null;
            }
         } else {
            var2 = this.channel.pipeline();
            var10001 = I[171 + 13 - 166 + 176];
            var10002 = I[113 + 83 - 75 + 74];
            I[35 + 61 - 29 + 129].length();
            I[81 + 129 - 163 + 150].length();
            NettyUtil.decodeEncodePlacement(var2, var10001, var10002, new NettyCompressionEncoder(var1));
            I[5 + 86 - -69 + 38].length();
            I[103 + 69 - 55 + 82].length();
            "".length();
            if (2 <= 0) {
               throw null;
            }
         }
      } else {
         if (this.channel.pipeline().get(I[51 + 60 - 92 + 181]) instanceof NettyCompressionDecoder) {
            this.channel.pipeline().remove(I[29 + 199 - 163 + 136]);
            I[157 + 85 - 141 + 101].length();
            I[44 + 113 - 96 + 142].length();
         }

         if (this.channel.pipeline().get(I[97 + 166 - 252 + 193]) instanceof NettyCompressionEncoder) {
            this.channel.pipeline().remove(I[38 + 70 - -52 + 45]);
            I[97 + 67 - 43 + 85].length();
            I[194 + 75 - 123 + 61].length();
            I[159 + 28 - 83 + 104].length();
            I[66 + 183 - 219 + 179].length();
         }
      }

   }

   public INetHandler getNetHandler() {
      return this.packetListener;
   }

   @SafeVarargs
   public final void sendPacket(Packet<?> var1, GenericFutureListener<? extends Future<? super Void>> var2, GenericFutureListener<? extends Future<? super Void>>... var3) {
      String var10000 = I[21 ^ 82];
      String var10001 = I[97 ^ 41];
      String var10002 = I[125 ^ 52];
      var10001 = I[208 ^ 154];
      if (this.isChannelOpen()) {
         this.flushOutboundQueue();
         this.dispatchPacket(var1, (GenericFutureListener[])ArrayUtils.add(var3, "".length(), var2));
         "".length();
         if (1 >= 3) {
            throw null;
         }
      } else {
         this.readWriteLock.writeLock().lock();

         try {
            Queue var7 = this.outboundPacketsQueue;
            I[113 ^ 58].length();
            I[78 ^ 2].length();
            I[22 ^ 91].length();
            var7.add(new NetworkManager.InboundHandlerTuplePacketListener(var1, (GenericFutureListener[])ArrayUtils.add(var3, "".length(), var2)));
            I[231 ^ 169].length();
            I[68 ^ 11].length();
            I[65 ^ 17].length();
         } catch (Throwable var6) {
            this.readWriteLock.writeLock().unlock();
            I[221 ^ 140].length();
            I[51 ^ 97].length();
            throw var6;
         }

         this.readWriteLock.writeLock().unlock();
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      }

   }

   public static NetworkManager createNetworkManagerAndConnect(InetAddress var0, int var1, boolean var2) {
      String var10000 = I[228 ^ 141];
      String var10001 = I[209 ^ 187];
      String var10002 = I[50 ^ 89];
      var10001 = I[192 ^ 172];
      var10000 = I[237 ^ 128];
      var10001 = I[30 ^ 112];
      var10002 = I[88 ^ 55];
      var10001 = I[22 ^ 102];
      var10000 = I[7 ^ 118];
      var10001 = I[38 ^ 84];
      var10002 = I[93 ^ 46];
      var10001 = I[212 ^ 160];
      I[123 ^ 14].length();
      I[76 ^ 58].length();
      I[67 ^ 52].length();
      final NetworkManager var3 = new NetworkManager(EnumPacketDirection.CLIENTBOUND);
      Class var4;
      LazyLoadBase var5;
      if (Epoll.isAvailable() && var2) {
         var4 = EpollSocketChannel.class;
         var5 = CLIENT_EPOLL_EVENTLOOP;
         "".length();
         if (4 == 2) {
            throw null;
         }
      } else {
         var4 = NioSocketChannel.class;
         var5 = CLIENT_NIO_EVENTLOOP;
      }

      I[223 ^ 167].length();
      Bootstrap var6 = (Bootstrap)(new Bootstrap()).group((EventLoopGroup)var5.getValue());
      I[52 ^ 77].length();
      I[114 ^ 8].length();
      I[104 ^ 19].length();
      ((Bootstrap)((Bootstrap)var6.handler(new ChannelInitializer<Channel>() {
         // $FF: synthetic field
         private static final String[] I;

         protected void initChannel(Channel var1) throws Exception {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[166 ^ 162];
            var10001 = I[64 ^ 69];
            var10002 = I[104 ^ 110];
            var10001 = I[91 ^ 92];
            var10000 = I[152 ^ 144];
            var10001 = I[69 ^ 76];
            var10002 = I[142 ^ 132];
            var10001 = I[55 ^ 60];
            var10000 = I[19 ^ 31];
            var10001 = I[159 ^ 146];
            var10002 = I[112 ^ 126];
            var10001 = I[109 ^ 98];
            var10000 = I[149 ^ 133];
            var10001 = I[104 ^ 121];
            var10002 = I[76 ^ 94];
            var10001 = I[5 ^ 22];
            var10000 = I[69 ^ 81];
            var10001 = I[113 ^ 100];
            var10002 = I[73 ^ 95];
            var10001 = I[177 ^ 166];
            var10000 = I[4 ^ 28];
            var10001 = I[150 ^ 143];
            var10002 = I[173 ^ 183];
            var10001 = I[85 ^ 78];
            var10000 = I[183 ^ 171];
            var10001 = I[168 ^ 181];
            var10002 = I[4 ^ 26];
            var10001 = I[178 ^ 173];
            var10000 = I[20 ^ 52];
            var10001 = I[125 ^ 92];
            var10002 = I[177 ^ 147];
            var10001 = I[96 ^ 67];

            label21: {
               try {
                  var1.config().setOption(ChannelOption.TCP_NODELAY, Boolean.valueOf((boolean)" ".length()));
                  I[71 ^ 99].length();
                  I[73 ^ 108].length();
                  I[24 ^ 62].length();
               } catch (ChannelException var3x) {
                  break label21;
               }

               "".length();
               if (4 < 3) {
                  throw null;
               }
            }

            ChannelPipeline var4 = var1.pipeline();
            var10001 = I[56 ^ 31];
            I[96 ^ 72].length();
            I[60 ^ 21].length();
            I[13 ^ 39].length();
            var4 = var4.addLast(var10001, new ReadTimeoutHandler(19 ^ 13));
            var10001 = I[69 ^ 110];
            I[177 ^ 157].length();
            I[172 ^ 129].length();
            var4 = var4.addLast(var10001, new NettyVarint21FrameDecoder());
            var10001 = I[122 ^ 84];
            I[101 ^ 74].length();
            I[128 ^ 176].length();
            var4 = var4.addLast(var10001, new NettyPacketDecoder(EnumPacketDirection.CLIENTBOUND));
            var10001 = I[141 ^ 188];
            I[188 ^ 142].length();
            I[101 ^ 86].length();
            var4 = var4.addLast(var10001, new NettyVarint21FrameEncoder());
            var10001 = I[158 ^ 170];
            I[147 ^ 166].length();
            I[134 ^ 176].length();
            I[126 ^ 73].length();
            I[152 ^ 160].length();
            var4.addLast(var10001, new NettyPacketEncoder(EnumPacketDirection.SERVERBOUND)).addLast(I[12 ^ 53], var3);
            I[99 ^ 89].length();
            I[134 ^ 189].length();
            I[137 ^ 181].length();
            if (var1 instanceof SocketChannel && ViaMCP.getInstance().getVersion() != 90 + 300 - 55 + 5) {
               I[61 ^ 0].length();
               I[99 ^ 93].length();
               I[25 ^ 38].length();
               UserConnectionImpl var2 = new UserConnectionImpl(var1, (boolean)" ".length());
               I[233 ^ 169].length();
               I[42 ^ 107].length();
               I[27 ^ 89].length();
               new ProtocolPipelineImpl(var2);
               I[17 ^ 82].length();
               var4 = var1.pipeline();
               var10001 = I[68 ^ 0];
               var10002 = I[11 ^ 78];
               I[205 ^ 139].length();
               I[76 ^ 11].length();
               var4 = var4.addBefore(var10001, var10002, new MCPEncodeHandler(var2));
               var10001 = I[16 ^ 88];
               var10002 = I[139 ^ 194];
               I[17 ^ 91].length();
               I[227 ^ 168].length();
               I[8 ^ 68].length();
               var4.addBefore(var10001, var10002, new MCPDecodeHandler(var2));
               I[228 ^ 169].length();
               I[201 ^ 135].length();
               I[236 ^ 163].length();
               I[243 ^ 163].length();
            }

         }

         private static void I() {
            I = new String[83 ^ 2];
            I["".length()] = I("殽庤", "myEAE");
            I[" ".length()] = I("归殰", "XHzrk");
            I["  ".length()] = I("找捅", "gGipH");
            I["   ".length()] = I("懳堃", "YOYrm");
            I[37 ^ 33] = I("潥咊", "QKULx");
            I[40 ^ 45] = I("樆囒", "ExopE");
            I[191 ^ 185] = I("卒娈", "OwMri");
            I[171 ^ 172] = I("梱周", "uxAXk");
            I[132 ^ 140] = I("氯壍", "fbfkD");
            I[2 ^ 11] = I("浢塿", "paSlL");
            I[166 ^ 172] = I("彤椼", "aAEes");
            I[11 ^ 0] = I("殤炩", "JppwO");
            I[23 ^ 27] = I("嗟滜", "OyVUQ");
            I[72 ^ 69] = I("瀇殴", "wykTf");
            I[115 ^ 125] = I("懶忚", "FwkWP");
            I[55 ^ 56] = I("刡勷", "GuaZg");
            I[182 ^ 166] = I("故汤", "QftOa");
            I[102 ^ 119] = I("佌恩", "gVeTc");
            I[211 ^ 193] = I("呀伃", "JhYUQ");
            I[29 ^ 14] = I("撢妣", "ybhyA");
            I[174 ^ 186] = I("刹妼", "XihZM");
            I[180 ^ 161] = I("匇殗", "vzEDY");
            I[2 ^ 20] = I("伈毶", "CnFZf");
            I[170 ^ 189] = I("幎孀", "SVxFD");
            I[91 ^ 67] = I("況朖", "DbRbO");
            I[168 ^ 177] = I("圆哰", "FRLqS");
            I[187 ^ 161] = I("捑昝", "iBVdn");
            I[55 ^ 44] = I("弇净", "VRIHP");
            I[36 ^ 56] = I("巴氃", "sFqTO");
            I[84 ^ 73] = I("檩桦", "GxMvE");
            I[1 ^ 31] = I("漴仆", "VztYb");
            I[182 ^ 169] = I("浺倽", "bRdKL");
            I[116 ^ 84] = I("朰圷", "wPIQo");
            I[179 ^ 146] = I("渙匍", "leZKr");
            I[89 ^ 123] = I("椇嶆", "cevWG");
            I[137 ^ 170] = I("井庤", "spgJS");
            I[152 ^ 188] = I("嘃", "wxdZR");
            I[122 ^ 95] = I("氭溼", "BwSVF");
            I[168 ^ 142] = I("槺愫亲核烊", "sOBEH");
            I[65 ^ 102] = I("<3.(\u001f=.", "HZCMp");
            I[130 ^ 170] = I("抰枴灌", "KKFxE");
            I[38 ^ 15] = I("嚽吹", "yodhl");
            I[46 ^ 4] = I("厪", "vSmih");
            I[9 ^ 34] = I("25\u001f\"\u001a5 \u0001", "AEsKn");
            I[233 ^ 197] = I("湸杅偋潬啾", "SNLrV");
            I[7 ^ 42] = I("嵁怏僊", "NsZUH");
            I[190 ^ 144] = I("0\r\r\u0001 1\u001a", "ThnnD");
            I[143 ^ 160] = I("媿娀愷兮", "QQShD");
            I[75 ^ 123] = I("哷仉楷", "jDiTH");
            I[117 ^ 68] = I("\u00048\t\u001b5\u001a.\t\u0019", "tJlkP");
            I[69 ^ 119] = I("旤", "YKbcP");
            I[121 ^ 74] = I("惁", "PwmtG");
            I[24 ^ 44] = I("\u0011\u001d1*\f\u0011\u0001", "tsREh");
            I[29 ^ 40] = I("屉戔嘟", "VFYzp");
            I[110 ^ 88] = I("彙戾", "NyRIa");
            I[187 ^ 140] = I("放夲旽", "qoWNQ");
            I[44 ^ 20] = I("棚剡晆应姤", "PpfHU");
            I[173 ^ 148] = I("\u001540\t1\u0011\n;\u0003:\u000196\u0010", "eUSbT");
            I[110 ^ 84] = I("傷徥溘淈", "emXqk");
            I[251 ^ 192] = I("媻噷楞", "wSvzE");
            I[152 ^ 164] = I("嘩热嶃嬳暹", "RUoaN");
            I[127 ^ 66] = I("搹槨杯刾", "WflIK");
            I[1 ^ 63] = I("搱煀潽呿拙", "hdwFu");
            I[253 ^ 194] = I("夣憭嫏亍塀", "bbcaQ");
            I[21 ^ 85] = I("怂啫愴定廠", "gMmaC");
            I[47 ^ 110] = I("帗彃", "tNLYf");
            I[1 ^ 67] = I("椄溹柘", "WUxGq");
            I[48 ^ 115] = I("漖杛喣欪", "nZnru");
            I[247 ^ 179] = I("\u0012\r\"7<\u0012\u0011", "wcAXX");
            I[6 ^ 67] = I(" \"\u0005T\u001c8(\u000b\u001d\u001c$", "VKdyy");
            I[232 ^ 174] = I("枡憽", "ZARtJ");
            I[99 ^ 36] = I("岸崃溗噤", "RgcUi");
            I[106 ^ 34] = I(">\u000e-%\u0007?\u0019", "ZkNJc");
            I[88 ^ 17] = I("<>4a'/4:(&8", "JWULC");
            I[18 ^ 88] = I("昄劒扬", "jMYdc");
            I[195 ^ 136] = I("槦文愬惶佲", "TcsxR");
            I[92 ^ 16] = I("姀点", "yboDx");
            I[244 ^ 185] = I("櫲嗊", "SwIHM");
            I[69 ^ 11] = I("徎丢唜櫥妽", "hEDZd");
            I[139 ^ 196] = I("昬岆潭柽仚", "GJFmm");
            I[7 ^ 87] = I("怇昋匧", "yiZEL");
         }

         static {
            I();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 >= -1);

            throw null;
         }
      })).channel(var4)).connect(var0, var1).syncUninterruptibly();
      I[18 ^ 110].length();
      I[33 ^ 92].length();
      I[112 ^ 14].length();
      return var3;
   }

   public NetworkManager(EnumPacketDirection var1) {
      this.direction = var1;
   }

   private static void I() {
      I = new String[31 + 19 - -99 + 73];
      I["".length()] = I("晳唧", "MKaqK");
      I[" ".length()] = I("孯巗告佧昴", "QPAEE");
      I["  ".length()] = I("喩夐欏愵", "xbSBR");
      I["   ".length()] = I("?:9\f4\u001f0x\u000f-\u000e;x\u001c=\u001b0", "zTXnX");
      I[29 ^ 25] = I("弜吞", "vrVba");
      I[153 ^ 156] = I("墶慴", "qLjII");
      I[187 ^ 189] = I("嬴侵", "STHuo");
      I[191 ^ 184] = I("嚻樴", "zXcFf");
      I[186 ^ 178] = I("懇懈", "slUwP");
      I[67 ^ 74] = I("懳彵捦", "grxnr");
      I[152 ^ 146] = I("傾灨", "YAPsZ");
      I[82 ^ 89] = I("&>\u0000\"\u0017,9\u0016\"\fl2\u001d%7$\u0004\u00073\u001d#:", "BWsAx");
      I[21 ^ 25] = I("劍儑", "itahd");
      I[154 ^ 151] = I("掬匢", "QGSuS");
      I[72 ^ 70] = I("儘滃", "NRxxv");
      I[154 ^ 149] = I("杻嵀", "TWzFb");
      I[132 ^ 148] = I("檉澛", "EwHdi");
      I[86 ^ 71] = I("桷殛", "xijwL");
      I[174 ^ 188] = I("巗嶕", "oDEcP");
      I[167 ^ 180] = I("灙洛", "YTcvW");
      I[9 ^ 29] = I("樅烬", "Tkfte");
      I[65 ^ 84] = I("呪峈", "YIGde");
      I[158 ^ 136] = I("峐会", "bMYtE");
      I[212 ^ 195] = I("嵀桒", "CWoDu");
      I[107 ^ 115] = I("沊埁", "hAXDg");
      I[55 ^ 46] = I("挏暿", "YqgNT");
      I[90 ^ 64] = I("槥埁", "xgaBM");
      I[171 ^ 176] = I("栥棒", "fjjKH");
      I[143 ^ 147] = I("枋攓", "XmLRp");
      I[155 ^ 134] = I("(1$\u0002&\"62\u0002=b,>\f,#-#", "LXWaI");
      I[144 ^ 142] = I("曪崊涡怙倣", "FVEvc");
      I[45 ^ 50] = I("\u001e/\u0011\u000e,\u0014(\u0007\u000e7T!\u0007\u0003&\b/\u0001?&\u001b5\r\u0003", "zFbmC");
      I[43 ^ 11] = I("灲圠宨堼", "uIScT");
      I[145 ^ 176] = I("潱嗅坴吀", "JIUmC");
      I[105 ^ 75] = I("悩欏嵖洭", "ofchf");
      I[1 ^ 34] = I("\u00106\u0000\u0012&79\u0018W\u0011!;\u0011\u0007 07\u001aMt", "YXtwT");
      I[19 ^ 55] = I("怴吧", "ygTwK");
      I[150 ^ 179] = I("倶漺", "DVIfU");
      I[88 ^ 126] = I("嶈奼", "DdTYc");
      I[150 ^ 177] = I("嚢懤", "KnAhC");
      I[77 ^ 101] = I("毮曑崍嵜", "pokex");
      I[30 ^ 55] = I("器拼烂佯", "gnfUj");
      I[163 ^ 137] = I("勤徙嗿哇椛", "rHKSl");
      I[67 ^ 104] = I("浮呼亍曘后", "LnIIu");
      I[94 ^ 114] = I("澮唨", "rOJBw");
      I[60 ^ 17] = I("$'\u000b-\u0015 \n\u00015\u00041(\r4", "TFhFp");
      I[98 ^ 76] = I("歩亮椈抎沲", "JfsuA");
      I[9 ^ 38] = I("替", "rArSC");
      I[168 ^ 152] = I("怏淶沤", "CjYPG");
      I[20 ^ 37] = I("+4 Z\u001e\u0011\" \u001f\u001c\u001d#t\u0015\u0014X*)Z\u0006\u0017q/\u0007", "xQTzr");
      I[25 ^ 43] = I("沊歜", "zkPnS");
      I[41 ^ 26] = I("廍崐", "KgQeb");
      I[123 ^ 79] = I("勔嵮", "ZWsDd");
      I[4 ^ 49] = I("懶妵", "fNIKC");
      I[84 ^ 98] = I("冨嘳", "wvlnq");
      I[162 ^ 149] = I("烕淂", "qLdjb");
      I[63 ^ 7] = I("嚨毊", "Rkcrp");
      I[59 ^ 2] = I("淃奎", "GzJsT");
      I[27 ^ 33] = I("卤", "zObKZ");
      I[49 ^ 10] = I("湿", "sSIwn");
      I[44 ^ 16] = I("剷", "MCuoz");
      I[99 ^ 94] = I("摖楌", "rTarG");
      I[109 ^ 83] = I("柋娤淒棿浴", "HLyyI");
      I[185 ^ 134] = I("亢櫭戯太", "fPPSB");
      I[57 ^ 121] = I("溕姎喵", "UdMzz");
      I[12 ^ 77] = I("喧啅", "BAwvh");
      I[42 ^ 104] = I("威對伯录", "XZlFj");
      I[117 ^ 54] = I("崕傝", "YFQZh");
      I[33 ^ 101] = I("潕", "UgrUp");
      I[49 ^ 116] = I("扦暕昧", "djoLF");
      I[45 ^ 107] = I("摰她勦", "qSTal");
      I[102 ^ 33] = I("招匕", "VdXuK");
      I[3 ^ 75] = I("愀氛", "RYTSJ");
      I[254 ^ 183] = I("渊勲", "EvnyB");
      I[63 ^ 117] = I("伦润", "icJzU");
      I[72 ^ 3] = I("扼橇", "JfOdm");
      I[240 ^ 188] = I("漄哦暐", "VWwQm");
      I[142 ^ 195] = I("漴咁", "huWao");
      I[142 ^ 192] = I("按了仑捼", "KHAUQ");
      I[237 ^ 162] = I("楀幕槡", "NQwru");
      I[88 ^ 8] = I("幜梓東", "YDgHe");
      I[20 ^ 69] = I("楃", "zNeEd");
      I[242 ^ 160] = I("烌寓樴泰", "mYXxT");
      I[66 ^ 17] = I("伿堻", "gITCU");
      I[197 ^ 145] = I("澳哲", "sYtqs");
      I[103 ^ 50] = I("坓春", "vpbbT");
      I[221 ^ 139] = I("渋渗", "mYUNs");
      I[240 ^ 167] = I("1\u000b\u0010\u0000\b\u0019\u0007\u0007A\u000b\u0000\u0016\fA\u0018\u0010\u0003\u0007", "ubcaj");
      I[209 ^ 137] = I("庘崢滸匝", "fZFni");
      I[45 ^ 116] = I("巉旱", "iQVmz");
      I[112 ^ 42] = I("奕潥杊屣", "roxvC");
      I[240 ^ 171] = I("柝嗯斔煢楲", "TIRAJ");
      I[52 ^ 104] = I("叒櫥嬌", "MLlFS");
      I[195 ^ 158] = I("咸力柌嶡壖", "gSUFa");
      I[121 ^ 39] = I("撈喝倨", "YdZzU");
      I[241 ^ 174] = I("差", "vPheI");
      I[69 ^ 37] = I("償杫", "ESAuQ");
      I[92 ^ 61] = I("沝", "tJyJz");
      I[4 ^ 102] = I("叆昁咟", "IYFGn");
      I[230 ^ 133] = I("戍", "ehcay");
      I[57 ^ 93] = I("漿悵泔姹嚞", "KNqnq");
      I[238 ^ 139] = I("摃凲", "massq");
      I[215 ^ 177] = I("劲汲奘", "VDmHM");
      I[125 ^ 26] = I("冭什慬旡", "ZxOnb");
      I[58 ^ 82] = I("坱憣楅嫇杴", "LFEjV");
      I[249 ^ 144] = I("淢呎", "eJVmM");
      I[105 ^ 3] = I("婑摜", "UIoRY");
      I[53 ^ 94] = I("姻侶", "ZirqK");
      I[62 ^ 82] = I("徻淣", "bheAL");
      I[98 ^ 15] = I("峮拯", "HMbVf");
      I[0 ^ 110] = I("啩桩", "znhqm");
      I[66 ^ 45] = I("俪樰", "snNig");
      I[49 ^ 65] = I("媘晒", "YZAem");
      I[83 ^ 34] = I("垶瀓", "GTDUx");
      I[5 ^ 119] = I("氡渽", "eQrqo");
      I[77 ^ 62] = I("患晤", "CsVJu");
      I[205 ^ 185] = I("擹巛", "SGSds");
      I[214 ^ 163] = I("沥滖幮尜搷", "WYxSh");
      I[1 ^ 119] = I("峃摢", "SjEap");
      I[242 ^ 133] = I("暣侥槼摏予", "LYtGq");
      I[5 ^ 125] = I("丌", "ghgDN");
      I[192 ^ 185] = I("杇伟揓", "RHyMe");
      I[111 ^ 21] = I("敁嘈嫴", "ZjGAP");
      I[85 ^ 46] = I("咣暹婥灉", "aDvnw");
      I[25 ^ 101] = I("嚢", "XAeQK");
      I[46 ^ 83] = I("昍偸", "LplyI");
      I[209 ^ 175] = I("俔", "yhwvF");
      I[11 + 39 - 34 + 111] = I("军浤", "znGkP");
      I[75 + 36 - 2 + 19] = I("毠庼", "cilGz");
      I[111 + 82 - 65 + 1] = I("帅嘄", "hWpAa");
      I[32 + 121 - 138 + 115] = I("售勞", "LRvUV");
      I[117 + 40 - 145 + 119] = I("傞灵", "dSRqy");
      I[121 + 55 - 63 + 19] = I("汐挚", "YEicq");
      I[43 + 98 - 131 + 123] = I("灧搴", "elIet");
      I[70 + 42 - 101 + 123] = I("复佷", "TBMnx");
      I[20 + 73 - 70 + 112] = I("欌巰", "mzRwq");
      I[0 + 88 - -19 + 29] = I("囎旇", "gdQSr");
      I[119 + 96 - 190 + 112] = I("办烌", "wstLU");
      I[45 + 132 - 153 + 114] = I("侇峽", "GDXhb");
      I[58 + 37 - 32 + 76] = I("槙挳憜", "oSGwR");
      I[134 + 138 - 150 + 18] = I("啓炡樬", "DLSwU");
      I[28 + 59 - 59 + 113] = I("拡増尒怉挽", "IlcFB");
      I[104 + 111 - 138 + 65] = I("减摞匬昝強", "pNiUm");
      I[122 + 89 - 134 + 66] = I("排氺", "BybqB");
      I[116 + 87 - 140 + 81] = I("栋寫壃囜低", "SDjnS");
      I[60 + 74 - 38 + 49] = I("坉止憖", "EMIiY");
      I[102 + 102 - 69 + 11] = I("內宰囔孰", "CHFWs");
      I[24 + 47 - 34 + 110] = I("懹曺昤", "sTrYI");
      I[145 + 42 - 141 + 102] = I("斕", "mbLaQ");
      I[24 + 108 - 83 + 100] = I("抠澵廩欐", "aVLIH");
      I[9 + 68 - -32 + 41] = I("厲沬", "DsyPq");
      I[87 + 149 - 222 + 137] = I("栚幸", "kobZk");
      I[41 + 123 - 51 + 39] = I("澌堉", "UgTqc");
      I[11 + 42 - -71 + 29] = I("昫栿", "TKGuc");
      I[84 + 110 - 171 + 131] = I("嶟撣", "IyQws");
      I[110 + 26 - -19 + 0] = I("因吻", "yXYps");
      I[117 + 121 - 105 + 23] = I("柷湮", "NPAqY");
      I[150 + 1 - 55 + 61] = I("匥晚", "bswLk");
      I[135 + 81 - 80 + 22] = I("\t2=\u0005\u0002\u000e'#", "zBQlv");
      I[5 + 82 - -30 + 42] = I("\u0015\u0012\u000e9\u0014\u0001\u0003", "qwmKm");
      I[125 + 37 - 91 + 89] = I("敳捻勀殝儱", "olkih");
      I[135 + 108 - 202 + 120] = I("澲啣妾浢榅", "lYYWy");
      I[139 + 9 - 127 + 141] = I("朽棫济今", "mghvM");
      I[123 + 72 - 169 + 137] = I("多晆", "bogTs");
      I[127 + 145 - 141 + 33] = I("启俙沛", "mpRxE");
      I[119 + 132 - 249 + 163] = I("喕伻懽", "rNTJU");
      I[51 + 131 - 144 + 128] = I("\u00035\u0010\u001e\u0013\u001d#\u0010\u001c", "sGunv");
      I[128 + 5 - -6 + 28] = I("\u001f\f\"\u000b\u001d\n\u0016", "zbAyd");
      I[1 + 26 - -114 + 27] = I("煟垐烋暆毲", "zavaU");
      I[109 + 22 - 11 + 49] = I("撾廋弥", "qgnBW");
      I[17 + 74 - -10 + 69] = I("擽曁匆帙岁", "PsuTM");
      I[17 + 137 - 103 + 120] = I("堢椣冭彣抍", "GqXPY");
      I[53 + 65 - -27 + 27] = I("扁怞", "gPyYk");
      I[92 + 121 - 85 + 45] = I("怉沥", "cSmMH");
      I[92 + 34 - 62 + 110] = I("淕炜", "OHTry");
      I[83 + 110 - 133 + 115] = I("杫滓", "IjaLr");
      I[134 + 42 - 4 + 4] = I("慁媌", "cnaTF");
      I[123 + 154 - 208 + 108] = I("侄椧", "jDsux");
      I[163 + 167 - 249 + 97] = I("匎喾", "DynYH");
      I[137 + 64 - 120 + 98] = I("嬦嬌", "nNsWH");
      I[119 + 3 - 62 + 120] = I("溗滕", "XkNIV");
      I[173 + 1 - 147 + 154] = I("\n#\u0010*\u001c\u001e4\u00166\u0002", "nFsEq");
      I[135 + 44 - 153 + 156] = I("26\u0017\u0006\u000b&!\u0011\u001a\u0015", "VStif");
      I[111 + 73 - 91 + 90] = I("\u001e'\u00018.\u001f0", "zBbWJ");
      I[1 + 123 - -51 + 9] = I("&\n7\u000342\u001d1\u001f*", "BoTlY");
      I[84 + 60 - -16 + 25] = I("啌炐", "UoXey");
      I[69 + 98 - 106 + 125] = I("戅", "tugNy");
      I[79 + 31 - -23 + 54] = I("姞扁枬", "PjqOa");
      I[1 + 49 - -41 + 97] = I("惛嗈忶", "pSrFk");
      I[180 + 148 - 207 + 68] = I("冲", "RWGhl");
      I[158 + 116 - 222 + 138] = I("樓凗悍渡侑", "OzTBd");
      I[71 + 111 - 172 + 181] = I("晭", "xexzZ");
      I[135 + 16 - -19 + 22] = I("\u0005;,\u0015\u0019\u0003'2", "fTAek");
      I[20 + 33 - -61 + 79] = I("*\u000b?30,\u0017!", "IdRCB");
      I[61 + 192 - 126 + 67] = I("-\t\u000f\u0002\u0007-\u0015", "Hglmc");
      I[109 + 88 - 193 + 191] = I(";\b$\u00198=\u0014:", "XgIiJ");
      I[119 + 118 - 143 + 102] = I("枨嚥代", "Acilc");
      I[83 + 76 - -29 + 9] = I("俁嶍峄囔斯", "nmhdd");
      I[110 + 189 - 155 + 54] = I("搃巆", "kDTaL");
      I[184 + 131 - 241 + 125] = I("哕漁揥洠", "NdPHN");
      I[90 + 95 - -1 + 14] = I("6<\u001b\",\"+\u001d>2", "RYxMA");
      I[71 + 100 - 126 + 156] = I("7\u0015\u0000\u001f<#\u0002\u0006\u0003\"", "SpcpQ");
      I[12 + 160 - -7 + 23] = I("噢", "hnUPr");
      I[120 + 174 - 233 + 142] = I("扨师", "YjfSq");
      I[122 + 24 - 27 + 85] = I("\u0017(\f\u0006\u0011\u00114\u0012", "tGavc");
      I[65 + 52 - 7 + 95] = I("6\u001a\u001d*\u001e0\u0006\u0003", "UupZl");
      I[190 + 112 - 233 + 137] = I("巿", "zjBic");
      I[13 + 16 - -162 + 16] = I("朒", "InexA");
      I[138 + 181 - 261 + 150] = I("枤憴煃", "llNyJ");
      I[27 + 68 - 94 + 208] = I("喗族", "UMulg");
      I[60 + 116 - 57 + 91] = I("嘦殯", "loXKV");
      I[204 + 50 - 210 + 167] = I("伐桁", "ZvQRX");
      I[76 + 55 - 58 + 139] = I("峲愎", "DFqju");
      I[33 + 184 - 25 + 21] = I("樻姩", "DABwK");
      I[96 + 159 - 127 + 86] = I(")\u0017%\u0015\u000e$2\"\u0002\u0001.\u0018%\u0014\u00015\u001f$\u001fJhV(\u0010\u000e-\u0013/Q\u00166\u001f(\u0014", "AvKqb");
      I[142 + 18 - 9 + 64] = I("劅沏儋榕", "UFVlJ");
      I[213 + 27 - 95 + 71] = I("壨", "CHnLZ");
      I[133 + 122 - 220 + 182] = I("刚", "zdkLj");
      I[191 + 121 - 246 + 152] = I("\u00032\u000e\f%\u001e+\u0003\u0001)\u001ci\u0006\u0011?\r(\f\u0016)\r3L\u001f)\u0000\"\u0010\u0011/", "nGbxL");
      I[33 + 26 - -16 + 144] = I("+\t\u0015/\u00187\u0007", "eLAxW");
      I[64 + 63 - -21 + 72] = I("\u001c\u0016&6\u0006\u0000\u0018-1\b\u0011\u001875\u001a", "RSraI");
      I[194 + 98 - 228 + 157] = I(")\u0011\u001e7*:\f\u001d", "YcqCE");
   }

   protected void channelRead0(ChannelHandlerContext var1, Packet<?> var2) throws Exception {
      String var10000 = I[84 ^ 112];
      String var10001 = I[54 ^ 19];
      String var10002 = I[28 ^ 58];
      var10001 = I[164 ^ 131];
      I[238 ^ 198].length();
      EventReceivePacket var3 = new EventReceivePacket(var2);
      EventManager.call(var3);
      I[177 ^ 152].length();
      I[158 ^ 180].length();
      I[155 ^ 176].length();
      I[13 ^ 33].length();
      if (!var3.isCancelled()) {
         if (this.channel.isOpen()) {
            try {
               var2.processPacket(this.packetListener);
            } catch (ThreadQuickExitException var5) {
               return;
            }

            "".length();
            if (2 < -1) {
               throw null;
            }
         }

      }
   }

   static {
      I();
      LOGGER = LogManager.getLogger();
      NETWORK_MARKER = MarkerManager.getMarker(I[175 + 184 - 338 + 198]);
      NETWORK_PACKETS_MARKER = MarkerManager.getMarker(I[52 + 136 - 0 + 32], NETWORK_MARKER);
      PROTOCOL_ATTRIBUTE_KEY = AttributeKey.valueOf(I[143 + 92 - 71 + 57]);
      CLIENT_NIO_EVENTLOOP = new LazyLoadBase<NioEventLoopGroup>() {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static void I() {
            I = new String[64 ^ 77];
            I["".length()] = I("漤乤", "gXLiH");
            I[" ".length()] = I("毈尣", "LgAIq");
            I["  ".length()] = I("抦慄", "Nhwwn");
            I["   ".length()] = I("啚咅", "JAgFT");
            I[160 ^ 164] = I("捯暄", "Ytltc");
            I[84 ^ 81] = I("刐佬", "RYILf");
            I[175 ^ 169] = I("兌帛", "WjALv");
            I[58 ^ 61] = I("烈幌", "TuEtF");
            I[7 ^ 15] = I("昊櫀", "pKFMX");
            I[88 ^ 81] = I("杨噝", "GlleI");
            I[102 ^ 108] = I("噧奇搘滱", "ANHgO");
            I[172 ^ 167] = I("厜佛圑", "ubQAy");
            I[7 ^ 11] = I("<\"\u0013\u001c\u0015R\u0004\u000b\u0001\t\u001c3G!#RdB\f", "rGghl");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(1 != -1);

            throw null;
         }

         protected NioEventLoopGroup load() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[2 ^ 6];
            var10001 = I[112 ^ 117];
            var10002 = I[110 ^ 104];
            var10001 = I[186 ^ 189];
            I[3 ^ 11].length();
            I[106 ^ 99].length();
            int var1 = "".length();
            I[6 ^ 12].length();
            I[42 ^ 33].length();
            return new NioEventLoopGroup(var1, (new ThreadFactoryBuilder()).setNameFormat(I[172 ^ 160]).setDaemon((boolean)" ".length()).build());
         }
      };
      CLIENT_EPOLL_EVENTLOOP = new LazyLoadBase<EpollEventLoopGroup>() {
         // $FF: synthetic field
         private static final String[] I;

         private static void I() {
            I = new String[0 ^ 15];
            I["".length()] = I("孎儈", "Imzns");
            I[" ".length()] = I("昻圪", "PsLxu");
            I["  ".length()] = I("溽恈", "AJXOu");
            I["   ".length()] = I("殹喏", "pokVf");
            I[186 ^ 190] = I("敎形", "VoMqW");
            I[184 ^ 189] = I("楠憡", "BzVci");
            I[30 ^ 24] = I("染檖", "OiXJD");
            I[181 ^ 178] = I("哖初", "NAhyL");
            I[118 ^ 126] = I("憡", "bFiea");
            I[74 ^ 67] = I("溳", "cXSjI");
            I[58 ^ 48] = I("峠殲扊劚", "giRhn");
            I[95 ^ 84] = I("凝噠哊", "JPPTN");
            I[34 ^ 46] = I("栴渲", "RUGqg");
            I[106 ^ 103] = I("挥憝炖併傇", "MHHUf");
            I[87 ^ 89] = I("4\u0000\u0007\u001d+Z \u0003\u0006>\u0016E0\u0005;\u001f\u000b\u0007I\u001b5EPL6", "zesiR");
         }

         protected EpollEventLoopGroup load() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[62 ^ 58];
            var10001 = I[179 ^ 182];
            var10002 = I[134 ^ 128];
            var10001 = I[194 ^ 197];
            I[51 ^ 59].length();
            I[152 ^ 145].length();
            int var1 = "".length();
            I[148 ^ 158].length();
            I[47 ^ 36].length();
            I[75 ^ 71].length();
            I[84 ^ 89].length();
            return new EpollEventLoopGroup(var1, (new ThreadFactoryBuilder()).setNameFormat(I[159 ^ 145]).setDaemon((boolean)" ".length()).build());
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 > 3);

            throw null;
         }

         static {
            I();
         }
      };
      CLIENT_LOCAL_EVENTLOOP = new LazyLoadBase<LocalEventLoopGroup>() {
         // $FF: synthetic field
         private static final String[] I;

         private static void I() {
            I = new String[83 ^ 93];
            I["".length()] = I("姬沷", "iGXsB");
            I[" ".length()] = I("添娙", "GSGtD");
            I["  ".length()] = I("櫖炍", "dOkZD");
            I["   ".length()] = I("徸匤", "WFJVL");
            I[175 ^ 171] = I("戙应", "iWzDf");
            I[120 ^ 125] = I("桒入", "FSGBA");
            I[190 ^ 184] = I("槾嫉", "jJPQv");
            I[21 ^ 18] = I("抪灲", "cLZSF");
            I[154 ^ 146] = I("寰昞", "yjbOO");
            I[96 ^ 105] = I("浺", "AeIZW");
            I[49 ^ 59] = I("残", "Nriid");
            I[84 ^ 95] = I("尡", "bEqNw");
            I[150 ^ 154] = I("尅", "vzZGv");
            I[37 ^ 40] = I("\u001b(\u001e\u000e<u\u0001\u0005\u0019$9m)\u0016,0#\u001eZ\f\u001amI_!", "UMjzE");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(true);

            throw null;
         }

         static {
            I();
         }

         protected LocalEventLoopGroup load() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[76 ^ 72];
            var10001 = I[194 ^ 199];
            var10002 = I[196 ^ 194];
            var10001 = I[148 ^ 147];
            I[106 ^ 98].length();
            I[152 ^ 145].length();
            int var1 = "".length();
            I[132 ^ 142].length();
            I[153 ^ 146].length();
            I[35 ^ 47].length();
            return new LocalEventLoopGroup(var1, (new ThreadFactoryBuilder()).setNameFormat(I[10 ^ 7]).setDaemon((boolean)" ".length()).build());
         }
      };
   }

   public boolean hasNoChannel() {
      int var10000;
      if (this.channel == null) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   static class InboundHandlerTuplePacketListener {
      // $FF: synthetic field
      private final GenericFutureListener<? extends Future<? super Void>>[] futureListeners;
      // $FF: synthetic field
      private final Packet<?> packet;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 != 2);

         throw null;
      }

      public InboundHandlerTuplePacketListener(Packet<?> var1, GenericFutureListener<? extends Future<? super Void>>... var2) {
         this.packet = var1;
         this.futureListeners = var2;
      }
   }
}

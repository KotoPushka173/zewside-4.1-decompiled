package net.minecraft.block;

import com.google.common.base.Predicate;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockHopper extends BlockContainer {
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   protected static final AxisAlignedBB BASE_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB EAST_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB NORTH_AABB;
   // $FF: synthetic field
   public static final PropertyBool ENABLED;
   // $FF: synthetic field
   protected static final AxisAlignedBB WEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB SOUTH_AABB;

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      return Container.calcRedstone(var2.getTileEntity(var3));
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[154 ^ 147];
      String var10001 = I[119 ^ 125];
      String var10002 = I[125 ^ 118];
      var10001 = I[154 ^ 150];
      var10000 = I[117 ^ 120];
      var10001 = I[201 ^ 199];
      var10002 = I[69 ^ 74];
      var10001 = I[124 ^ 108];
      var10000 = I[6 ^ 23];
      var10001 = I[85 ^ 71];
      var10002 = I[213 ^ 198];
      var10001 = I[78 ^ 90];
      I[88 ^ 77].length();
      I[158 ^ 136].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[15 ^ 24].length();
      I[141 ^ 149].length();
      I[11 ^ 18].length();
      var10003["".length()] = FACING;
      I[130 ^ 152].length();
      I[18 ^ 9].length();
      I[85 ^ 73].length();
      var10003[" ".length()] = ENABLED;
      return new BlockStateContainer(this, var10003);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         TileEntity var10 = var1.getTileEntity(var2);
         if (var10 instanceof TileEntityHopper) {
            var4.displayGUIChest((TileEntityHopper)var10);
            var4.addStat(StatList.HOPPER_INSPECTED);
         }

         return (boolean)" ".length();
      }
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 == EnumFacing.UP) {
         var10000 = BlockFaceShape.BOWL;
         "".length();
         if (4 <= 2) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   static {
      I();
      FACING = PropertyDirection.create(I[140 ^ 145], new Predicate<EnumFacing>() {
         public boolean apply(@Nullable EnumFacing var1) {
            int var10000;
            if (var1 != EnumFacing.UP) {
               var10000 = " ".length();
               "".length();
               if (false) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 < 0);

            throw null;
         }
      });
      ENABLED = PropertyBool.create(I[104 ^ 118]);
      BASE_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.625D, 1.0D);
      SOUTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.125D);
      NORTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.875D, 1.0D, 1.0D, 1.0D);
      WEST_AABB = new AxisAlignedBB(0.875D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      EAST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.125D, 1.0D, 1.0D);
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getIndex();
      if (!(Boolean)var1.getValue(ENABLED)) {
         var2 |= 153 ^ 145;
      }

      return var2;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      this.updateState(var2, var3, var1);
   }

   private void updateState(World var1, BlockPos var2, IBlockState var3) {
      int var10000;
      if (!var1.isBlockPowered(var2)) {
         var10000 = " ".length();
         "".length();
         if (3 <= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var4 = var10000;
      if (var4 != (Boolean)var3.getValue(ENABLED)) {
         var1.setBlockState(var2, var3.withProperty(ENABLED, Boolean.valueOf((boolean)var4)), 88 ^ 92);
         I[151 ^ 144].length();
         I[75 ^ 67].length();
      }

   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      addCollisionBoxToList(var3, var4, var5, BASE_AABB);
      addCollisionBoxToList(var3, var4, var5, EAST_AABB);
      addCollisionBoxToList(var3, var4, var5, WEST_AABB);
      addCollisionBoxToList(var3, var4, var5, SOUTH_AABB);
      addCollisionBoxToList(var3, var4, var5, NORTH_AABB);
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return FULL_BLOCK_AABB;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 0);

      throw null;
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public BlockHopper() {
      super(Material.IRON, MapColor.STONE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.DOWN).withProperty(ENABLED, Boolean.valueOf((boolean)" ".length())));
      this.setCreativeTab(CreativeTabs.REDSTONE);
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      this.updateState(var1, var2, var3);
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      EnumFacing var9 = var3.getOpposite();
      if (var9 == EnumFacing.UP) {
         var9 = EnumFacing.DOWN;
      }

      return this.getDefaultState().withProperty(FACING, var9).withProperty(ENABLED, Boolean.valueOf((boolean)" ".length()));
   }

   public static EnumFacing getFacing(int var0) {
      return EnumFacing.getFront(var0 & (40 ^ 47));
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return (boolean)" ".length();
   }

   private static void I() {
      I = new String[0 ^ 31];
      I["".length()] = I("寋柃", "wmnTD");
      I[" ".length()] = I("愥抄", "yCUUS");
      I["  ".length()] = I("嘥沀", "OZGaX");
      I["   ".length()] = I("攠潠", "DIoKz");
      I[96 ^ 100] = I("守厥", "KhpiE");
      I[119 ^ 114] = I("學朝", "wVMtG");
      I[169 ^ 175] = I("港楜椄", "uYssi");
      I[123 ^ 124] = I("櫐", "uNiaQ");
      I[207 ^ 199] = I("嵪晊对", "Dnyvu");
      I[146 ^ 155] = I("刁灒", "jwGWl");
      I[69 ^ 79] = I("噵傚", "pZXsA");
      I[120 ^ 115] = I("忛墶", "fLQQu");
      I[166 ^ 170] = I("幮媗", "STJIl");
      I[128 ^ 141] = I("侏栵", "WKcja");
      I[8 ^ 6] = I("崵垷", "KTkQY");
      I[132 ^ 139] = I("復啅", "CzNmd");
      I[123 ^ 107] = I("渓提", "DUPwK");
      I[59 ^ 42] = I("捂幐", "eFOzf");
      I[162 ^ 176] = I("哤永", "eWqKC");
      I[104 ^ 123] = I("抭毊", "jSLfF");
      I[39 ^ 51] = I("搫樛", "jacmn");
      I[144 ^ 133] = I("潰", "pdovL");
      I[39 ^ 49] = I("偆", "rcqMs");
      I[98 ^ 117] = I("塥", "XCRvS");
      I[165 ^ 189] = I("僮漖上毇", "KcpLE");
      I[51 ^ 42] = I("憈曝戡", "NNwYM");
      I[6 ^ 28] = I("樖崪", "EkDOL");
      I[35 ^ 56] = I("巾浤", "sHwfZ");
      I[103 ^ 123] = I("灋", "gjmfE");
      I[145 ^ 140] = I("\u000f\u000f2!\"\u000e", "inQHL");
      I[80 ^ 78] = I("\u0010* '9\u0010 ", "uDAEU");
   }

   public boolean isFullyOpaque(IBlockState var1) {
      return (boolean)" ".length();
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      TileEntity var4 = var1.getTileEntity(var2);
      if (var4 instanceof TileEntityHopper) {
         InventoryHelper.dropInventoryItems(var1, (BlockPos)var2, (TileEntityHopper)var4);
         var1.updateComparatorOutputLevel(var2, this);
      }

      super.breakBlock(var1, var2, var3);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(FACING, getFacing(var1)).withProperty(ENABLED, isEnabled(var1));
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT_MIPPED;
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      super.onBlockPlacedBy(var1, var2, var3, var4, var5);
      if (var5.hasDisplayName()) {
         TileEntity var6 = var1.getTileEntity(var2);
         if (var6 instanceof TileEntityHopper) {
            ((TileEntityHopper)var6).func_190575_a(var5.getDisplayName());
         }
      }

   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[165 ^ 161].length();
      I[12 ^ 9].length();
      I[61 ^ 59].length();
      return new TileEntityHopper();
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public static boolean isEnabled(int var0) {
      int var10000;
      if ((var0 & (160 ^ 168)) != (107 ^ 99)) {
         var10000 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }
}

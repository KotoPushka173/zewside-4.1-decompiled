package net.minecraft.advancements.critereon;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldServer;
import net.minecraft.world.biome.Biome;

public class LocationPredicate {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static LocationPredicate field_193455_a;
   // $FF: synthetic field
   @Nullable
   private final String field_193460_f;
   // $FF: synthetic field
   @Nullable
   private final DimensionType field_193461_g;
   // $FF: synthetic field
   private final MinMaxBounds field_193458_d;
   // $FF: synthetic field
   private final MinMaxBounds field_193459_e;
   // $FF: synthetic field
   @Nullable
   final Biome field_193456_b;
   // $FF: synthetic field
   private final MinMaxBounds field_193457_c;

   public static LocationPredicate func_193454_a(@Nullable JsonElement var0) {
      String var10000 = I[11 ^ 14];
      String var10001 = I[127 ^ 121];
      String var10002 = I[156 ^ 155];
      var10001 = I[176 ^ 184];
      var10000 = I[180 ^ 189];
      var10001 = I[3 ^ 9];
      var10002 = I[164 ^ 175];
      var10001 = I[66 ^ 78];
      var10000 = I[17 ^ 28];
      var10001 = I[184 ^ 182];
      var10002 = I[96 ^ 111];
      var10001 = I[123 ^ 107];
      var10000 = I[176 ^ 161];
      var10001 = I[140 ^ 158];
      var10002 = I[131 ^ 144];
      var10001 = I[180 ^ 160];
      var10000 = I[40 ^ 61];
      var10001 = I[171 ^ 189];
      var10002 = I[208 ^ 199];
      var10001 = I[83 ^ 75];
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = JsonUtils.getJsonObject(var0, I[112 ^ 105]);
         var10001 = I[53 ^ 47];
         I[25 ^ 2].length();
         I[19 ^ 15].length();
         I[96 ^ 125].length();
         I[29 ^ 3].length();
         JsonObject var2 = JsonUtils.getJsonObject(var1, var10001, new JsonObject());
         MinMaxBounds var3 = MinMaxBounds.func_192515_a(var2.get(I[120 ^ 103]));
         MinMaxBounds var4 = MinMaxBounds.func_192515_a(var2.get(I[53 ^ 21]));
         MinMaxBounds var5 = MinMaxBounds.func_192515_a(var2.get(I[6 ^ 39]));
         DimensionType var10;
         if (var1.has(I[61 ^ 31])) {
            var10 = DimensionType.func_193417_a(JsonUtils.getString(var1, I[131 ^ 160]));
            "".length();
            if (1 < 1) {
               throw null;
            }
         } else {
            var10 = null;
         }

         DimensionType var6 = var10;
         if (var1.has(I[85 ^ 113])) {
            var10000 = JsonUtils.getString(var1, I[20 ^ 49]);
            "".length();
            if (1 == 3) {
               throw null;
            }
         } else {
            var10000 = null;
         }

         String var7 = var10000;
         Biome var8 = null;
         if (var1.has(I[108 ^ 74])) {
            I[79 ^ 104].length();
            I[179 ^ 155].length();
            I[130 ^ 171].length();
            I[232 ^ 194].length();
            ResourceLocation var9 = new ResourceLocation(JsonUtils.getString(var1, I[35 ^ 8]));
            var8 = (Biome)Biome.REGISTRY.getObject(var9);
            if (var8 == null) {
               I[147 ^ 191].length();
               I[66 ^ 111].length();
               I[173 ^ 131].length();
               I[53 ^ 26].length();
               I[12 ^ 60].length();
               I[53 ^ 4].length();
               I[130 ^ 176].length();
               I[44 ^ 31].length();
               JsonSyntaxException var11 = new JsonSyntaxException(I[122 ^ 78] + var9 + I[7 ^ 50]);
               I[103 ^ 81].length();
               I[187 ^ 140].length();
               I[161 ^ 153].length();
               throw var11;
            }
         }

         I[44 ^ 21].length();
         I[43 ^ 17].length();
         return new LocationPredicate(var3, var4, var5, var8, var7, var6);
      } else {
         return field_193455_a;
      }
   }

   public LocationPredicate(MinMaxBounds var1, MinMaxBounds var2, MinMaxBounds var3, @Nullable Biome var4, @Nullable String var5, @Nullable DimensionType var6) {
      this.field_193457_c = var1;
      this.field_193458_d = var2;
      this.field_193459_e = var3;
      this.field_193456_b = var4;
      this.field_193460_f = var5;
      this.field_193461_g = var6;
   }

   public boolean func_193452_a(WorldServer var1, double var2, double var4, double var6) {
      return this.func_193453_a(var1, (float)var2, (float)var4, (float)var6);
   }

   static {
      I();
      field_193455_a = new LocationPredicate(MinMaxBounds.field_192516_a, MinMaxBounds.field_192516_a, MinMaxBounds.field_192516_a, (Biome)null, (String)null, (DimensionType)null);
   }

   public boolean func_193453_a(WorldServer var1, float var2, float var3, float var4) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (!this.field_193457_c.func_192514_a(var2)) {
         return (boolean)"".length();
      } else if (!this.field_193458_d.func_192514_a(var3)) {
         return (boolean)"".length();
      } else if (!this.field_193459_e.func_192514_a(var4)) {
         return (boolean)"".length();
      } else if (this.field_193461_g != null && this.field_193461_g != var1.provider.getDimensionType()) {
         return (boolean)"".length();
      } else {
         I[6 ^ 2].length();
         BlockPos var5 = new BlockPos((double)var2, (double)var3, (double)var4);
         if (this.field_193456_b != null && this.field_193456_b != var1.getBiome(var5)) {
            return (boolean)"".length();
         } else {
            int var6;
            if (this.field_193460_f != null && !var1.getChunkProvider().func_193413_a(var1, this.field_193460_f, var5)) {
               var6 = "".length();
            } else {
               var6 = " ".length();
               "".length();
               if (-1 >= 0) {
                  throw null;
               }
            }

            return (boolean)var6;
         }
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= -1);

      throw null;
   }

   private static void I() {
      I = new String[189 ^ 134];
      I["".length()] = I("洿揬", "ABhEj");
      I[" ".length()] = I("揉兄", "WcquW");
      I["  ".length()] = I("挭戀", "TEcTg");
      I["   ".length()] = I("仩务", "XfZQt");
      I[175 ^ 171] = I("儕", "gmbiG");
      I[1 ^ 4] = I("欿准", "mMUAB");
      I[180 ^ 178] = I("媏彪", "ypSfU");
      I[17 ^ 22] = I("弉侸", "Mczer");
      I[11 ^ 3] = I("掗炑", "aLtzs");
      I[57 ^ 48] = I("啉县", "nhtTk");
      I[149 ^ 159] = I("峌姧", "juWFF");
      I[139 ^ 128] = I("姺毖", "DeGaf");
      I[136 ^ 132] = I("囨儑", "wmGRh");
      I[39 ^ 42] = I("桪撩", "zrSEI");
      I[80 ^ 94] = I("曢啝", "QYJTT");
      I[162 ^ 173] = I("揦嚅", "SKFaB");
      I[8 ^ 24] = I("沉引", "GjHHY");
      I[180 ^ 165] = I("渾寯", "eUehQ");
      I[59 ^ 41] = I("渰浧", "loOKl");
      I[170 ^ 185] = I("串媵", "uBmhn");
      I[167 ^ 179] = I("湙奁", "iapHP");
      I[6 ^ 19] = I("捇溝", "mhhcs");
      I[190 ^ 168] = I("氫恾", "YPCar");
      I[80 ^ 71] = I("崡楺", "smWwx");
      I[94 ^ 70] = I("晙悐", "aWrZd");
      I[21 ^ 12] = I("\"\u001a\n,\u0012'\u001a\u0007", "NuiMf");
      I[22 ^ 12] = I("\u0019\u0002\u0012\u00053\u0000\u0002\u000f", "imalG");
      I[51 ^ 40] = I("懲漮丌托氞", "iwZnv");
      I[159 ^ 131] = I("拒憗前枚", "VNGqh");
      I[29 ^ 0] = I("敦榗", "Oduxd");
      I[108 ^ 114] = I("悰呲", "eqAJb");
      I[189 ^ 162] = I("\u001b", "cKROS");
      I[156 ^ 188] = I("(", "QayXQ");
      I[47 ^ 14] = I("?", "EGaHO");
      I[136 ^ 170] = I("+(\u0000!\u001a<(\u0002*", "OAmDt");
      I[110 ^ 77] = I("\u0003%\u0001\u0002\u0005\u0014%\u0003\t", "gLlgk");
      I[79 ^ 107] = I("\t&\u0014?\u0018\u001d&", "oCuKm");
      I[56 ^ 29] = I("-7;\u0002897", "KRZvM");
      I[141 ^ 171] = I("$&,)\t", "FOCDl");
      I[70 ^ 97] = I("槊旜渁", "TZsmg");
      I[21 ^ 61] = I("亣撕", "RrAFe");
      I[166 ^ 143] = I("嫈摼墨壣", "Ukjet");
      I[174 ^ 132] = I("偶", "YDnpb");
      I[184 ^ 147] = I("\u0006\u0005:(1", "dlUET");
      I[236 ^ 192] = I("毘", "uSOeC");
      I[19 ^ 62] = I("嶇", "yPODR");
      I[188 ^ 146] = I("梄", "heKLe");
      I[121 ^ 86] = I("嬦栰", "hBmoB");
      I[13 ^ 61] = I("妒墑沺博", "gBlKH");
      I[174 ^ 159] = I("嬆呑乧屛", "IxLFH");
      I[115 ^ 65] = I("态", "eSisC");
      I[5 ^ 54] = I("展勽坣樸", "CQLIv");
      I[144 ^ 164] = I("%!><\u0016\u0007!u0\u0010\u001f\"0r^", "pOURy");
      I[134 ^ 179] = I("`", "GRgTF");
      I[119 ^ 65] = I("曝愐新", "oEiML");
      I[159 ^ 168] = I("泩岩拖沺", "OaBBk");
      I[172 ^ 148] = I("倧淪", "JnqvI");
      I[74 ^ 115] = I("撔湔偖", "SISfL");
      I[13 ^ 55] = I("勹僔婞", "YiEUS");
   }
}

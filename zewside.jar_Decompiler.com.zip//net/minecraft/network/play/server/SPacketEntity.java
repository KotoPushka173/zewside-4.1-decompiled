package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.World;

public class SPacketEntity implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   protected byte yaw;
   // $FF: synthetic field
   protected int posX;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected int entityId;
   // $FF: synthetic field
   protected byte pitch;
   // $FF: synthetic field
   protected int posY;
   // $FF: synthetic field
   protected boolean rotating;
   // $FF: synthetic field
   protected int posZ;
   // $FF: synthetic field
   protected boolean onGround;

   private static void I() {
      I = new String[188 ^ 176];
      I["".length()] = I("梞凾巑朜", "zfQmM");
      I[" ".length()] = I("岡倜", "RiCxg");
      I["  ".length()] = I("姺桋摦壍", "ZfHIK");
      I["   ".length()] = I("晟奏崼沦", "VSvjo");
      I[182 ^ 178] = I("灀條", "Fbooi");
      I[164 ^ 161] = I("嫇抒", "lqsOO");
      I[180 ^ 178] = I("御婉", "xCmsE");
      I[36 ^ 35] = I("橦呠", "UJQcZ");
      I[140 ^ 132] = I("伤滭卌尌梃", "ikGzu");
      I[18 ^ 27] = I("彫炪擭嵹", "MatfP");
      I[206 ^ 196] = I("崎來愈扢叀", "pecQb");
      I[64 ^ 75] = I("\b\u001d\u0011:'4,", "MseSS");
   }

   public int getX() {
      return this.posX;
   }

   public Entity getEntity(World var1) {
      return var1.getEntityByID(this.entityId);
   }

   public byte getPitch() {
      return this.pitch;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
   }

   public boolean isRotating() {
      return this.rotating;
   }

   public byte getYaw() {
      return this.yaw;
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 1);

      throw null;
   }

   public int getY() {
      return this.posY;
   }

   public SPacketEntity() {
   }

   public int getZ() {
      return this.posZ;
   }

   public boolean getOnGround() {
      return this.onGround;
   }

   public String toString() {
      String var10000 = I[145 ^ 149];
      String var10001 = I[121 ^ 124];
      String var10002 = I[139 ^ 141];
      var10001 = I[91 ^ 92];
      I[98 ^ 106].length();
      I[79 ^ 70].length();
      I[43 ^ 33].length();
      return I[65 ^ 74] + super.toString();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityMovement(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
   }

   public SPacketEntity(int var1) {
      this.entityId = var1;
   }

   public static class S15PacketEntityRelMove extends SPacketEntity {
      // $FF: synthetic field
      private static final String[] I;

      static {
         I();
      }

      public S15PacketEntityRelMove() {
      }

      public S15PacketEntityRelMove(int var1, long var2, long var4, long var6, boolean var8) {
         super(var1);
         this.posX = (int)var2;
         this.posY = (int)var4;
         this.posZ = (int)var6;
         this.onGround = var8;
      }

      public void writePacketData(PacketBuffer var1) throws IOException {
         super.writePacketData(var1);
         var1.writeShort(this.posX);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         var1.writeShort(this.posY);
         I["   ".length()].length();
         I[12 ^ 8].length();
         var1.writeShort(this.posZ);
         I[85 ^ 80].length();
         I[69 ^ 67].length();
         I[94 ^ 89].length();
         var1.writeBoolean(this.onGround);
         I[108 ^ 100].length();
         I[126 ^ 119].length();
      }

      public void readPacketData(PacketBuffer var1) throws IOException {
         super.readPacketData(var1);
         this.posX = var1.readShort();
         this.posY = var1.readShort();
         this.posZ = var1.readShort();
         this.onGround = var1.readBoolean();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(true);

         throw null;
      }

      private static void I() {
         I = new String[82 ^ 88];
         I["".length()] = I("勽", "UJLWa");
         I[" ".length()] = I("椣", "HtyEf");
         I["  ".length()] = I("淥柤姹", "kNzal");
         I["   ".length()] = I("欬寊", "hXNuC");
         I[16 ^ 20] = I("忚嚩奻", "ArAdk");
         I[64 ^ 69] = I("彞廟憋濽咱", "QaKxI");
         I[102 ^ 96] = I("健寝", "jZspE");
         I[76 ^ 75] = I("溝", "uwrss");
         I[92 ^ 84] = I("偛槟榜嬪庰", "mmQUh");
         I[75 ^ 66] = I("坍旘烓", "IzReq");
      }
   }

   public static class S17PacketEntityLookMove extends SPacketEntity {
      // $FF: synthetic field
      private static final String[] I;

      public S17PacketEntityLookMove(int var1, long var2, long var4, long var6, byte var8, byte var9, boolean var10) {
         super(var1);
         this.posX = (int)var2;
         this.posY = (int)var4;
         this.posZ = (int)var6;
         this.yaw = var8;
         this.pitch = var9;
         this.onGround = var10;
         this.rotating = (boolean)" ".length();
      }

      public S17PacketEntityLookMove() {
         this.rotating = (boolean)" ".length();
      }

      public void writePacketData(PacketBuffer var1) throws IOException {
         super.writePacketData(var1);
         var1.writeShort(this.posX);
         I["".length()].length();
         I[" ".length()].length();
         var1.writeShort(this.posY);
         I["  ".length()].length();
         var1.writeShort(this.posZ);
         I["   ".length()].length();
         I[70 ^ 66].length();
         I[73 ^ 76].length();
         I[165 ^ 163].length();
         var1.writeByte(this.yaw);
         I[77 ^ 74].length();
         var1.writeByte(this.pitch);
         I[90 ^ 82].length();
         I[27 ^ 18].length();
         var1.writeBoolean(this.onGround);
         I[16 ^ 26].length();
         I[129 ^ 138].length();
         I[155 ^ 151].length();
         I[200 ^ 197].length();
      }

      private static void I() {
         I = new String[92 ^ 82];
         I["".length()] = I("凃嫪杯惞冕", "CNXVA");
         I[" ".length()] = I("漈沸", "gUXZz");
         I["  ".length()] = I("暤", "voCDQ");
         I["   ".length()] = I("悐晀", "pkwoe");
         I[53 ^ 49] = I("厨晷潴", "yOuKH");
         I[57 ^ 60] = I("渚姏殈", "vRdOQ");
         I[62 ^ 56] = I("庋咯傠氪俜", "eyivI");
         I[91 ^ 92] = I("椷勳娀儋", "MFnLo");
         I[85 ^ 93] = I("唢夜囲友廇", "tocYj");
         I[73 ^ 64] = I("廝佁懠崷揌", "TPGMO");
         I[46 ^ 36] = I("涓殊崯", "zgxBz");
         I[68 ^ 79] = I("炓枇年唒慀", "oSYIm");
         I[81 ^ 93] = I("柺摋喛侧", "PtyVL");
         I[58 ^ 55] = I("幑愐余柈晧", "iLTbw");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 == 4);

         throw null;
      }

      static {
         I();
      }

      public void readPacketData(PacketBuffer var1) throws IOException {
         super.readPacketData(var1);
         this.posX = var1.readShort();
         this.posY = var1.readShort();
         this.posZ = var1.readShort();
         this.yaw = var1.readByte();
         this.pitch = var1.readByte();
         this.onGround = var1.readBoolean();
      }
   }

   public static class S16PacketEntityLook extends SPacketEntity {
      // $FF: synthetic field
      private static final String[] I;

      public void writePacketData(PacketBuffer var1) throws IOException {
         super.writePacketData(var1);
         var1.writeByte(this.yaw);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
         var1.writeByte(this.pitch);
         I[19 ^ 23].length();
         I[83 ^ 86].length();
         I[150 ^ 144].length();
         I[152 ^ 159].length();
         var1.writeBoolean(this.onGround);
         I[12 ^ 4].length();
         I[5 ^ 12].length();
         I[20 ^ 30].length();
         I[61 ^ 54].length();
      }

      public void readPacketData(PacketBuffer var1) throws IOException {
         super.readPacketData(var1);
         this.yaw = var1.readByte();
         this.pitch = var1.readByte();
         this.onGround = var1.readBoolean();
      }

      public S16PacketEntityLook(int var1, byte var2, byte var3, boolean var4) {
         super(var1);
         this.yaw = var2;
         this.pitch = var3;
         this.rotating = (boolean)" ".length();
         this.onGround = var4;
      }

      static {
         I();
      }

      public S16PacketEntityLook() {
         this.rotating = (boolean)" ".length();
      }

      private static void I() {
         I = new String[205 ^ 193];
         I["".length()] = I("劜儙傶", "Lsldv");
         I[" ".length()] = I("恉圈捩嵑伳", "bedYa");
         I["  ".length()] = I("婗", "qqnTn");
         I["   ".length()] = I("撡", "yhbHy");
         I[99 ^ 103] = I("堍攕氘妅梄", "KwaFI");
         I[30 ^ 27] = I("挩", "CyauX");
         I[140 ^ 138] = I("殭摾", "NfRvH");
         I[22 ^ 17] = I("仕", "WsunJ");
         I[36 ^ 44] = I("崘哀", "Qpzoq");
         I[126 ^ 119] = I("师檍抆", "hcWhE");
         I[79 ^ 69] = I("濧暍劻乏", "dWmsV");
         I[36 ^ 47] = I("寪懍娨剁", "tzicr");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 > -1);

         throw null;
      }
   }
}

package net.minecraft.scoreboard;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.TextFormatting;

public class Scoreboard {
   // $FF: synthetic field
   private static String[] displaySlots;
   // $FF: synthetic field
   private final Map<String, ScoreObjective> scoreObjectives = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<String, Map<ScoreObjective, Score>> entitiesScoreObjectives = Maps.newHashMap();
   // $FF: synthetic field
   private final Map<String, ScorePlayerTeam> teams = Maps.newHashMap();
   // $FF: synthetic field
   private final Map<IScoreCriteria, List<ScoreObjective>> scoreObjectiveCriterias = Maps.newHashMap();
   // $FF: synthetic field
   private final ScoreObjective[] objectiveDisplaySlots = new ScoreObjective[48 ^ 35];
   // $FF: synthetic field
   private final Map<String, ScorePlayerTeam> teamMemberships = Maps.newHashMap();

   public void setObjectiveInDisplaySlot(int var1, ScoreObjective var2) {
      this.objectiveDisplaySlots[var1] = var2;
   }

   public ScoreObjective addScoreObjective(String var1, IScoreCriteria var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[101 ^ 97];
      var10001 = I[127 ^ 122];
      var10002 = I[123 ^ 125];
      var10001 = I[23 ^ 16];
      var10000 = I[28 ^ 20];
      var10001 = I[55 ^ 62];
      var10002 = I[152 ^ 146];
      var10001 = I[140 ^ 135];
      var10000 = I[171 ^ 167];
      var10001 = I[132 ^ 137];
      var10002 = I[201 ^ 199];
      var10001 = I[165 ^ 170];
      var10000 = I[65 ^ 81];
      var10001 = I[27 ^ 10];
      var10002 = I[65 ^ 83];
      var10001 = I[4 ^ 23];
      IllegalArgumentException var5;
      if (var1.length() > (209 ^ 193)) {
         I[143 ^ 155].length();
         I[184 ^ 173].length();
         I[68 ^ 82].length();
         I[86 ^ 65].length();
         I[20 ^ 12].length();
         I[99 ^ 122].length();
         I[6 ^ 28].length();
         var5 = new IllegalArgumentException(I[43 ^ 48] + var1 + I[31 ^ 3]);
         I[144 ^ 141].length();
         I[182 ^ 168].length();
         throw var5;
      } else {
         ScoreObjective var3 = this.getObjective(var1);
         if (var3 != null) {
            I[145 ^ 142].length();
            I[29 ^ 61].length();
            I[144 ^ 177].length();
            I[52 ^ 22].length();
            I[19 ^ 48].length();
            I[10 ^ 46].length();
            I[119 ^ 82].length();
            I[128 ^ 166].length();
            var5 = new IllegalArgumentException(I[20 ^ 51] + var1 + I[105 ^ 65]);
            I[35 ^ 10].length();
            I[136 ^ 162].length();
            I[150 ^ 189].length();
            throw var5;
         } else {
            I[144 ^ 188].length();
            I[66 ^ 111].length();
            var3 = new ScoreObjective(this, var1, var2);
            Object var4 = (List)this.scoreObjectiveCriterias.get(var2);
            if (var4 == null) {
               var4 = Lists.newArrayList();
               this.scoreObjectiveCriterias.put(var2, var4);
               I[166 ^ 136].length();
            }

            ((List)var4).add(var3);
            I[0 ^ 47].length();
            I[92 ^ 108].length();
            I[32 ^ 17].length();
            this.scoreObjectives.put(var1, var3);
            I[241 ^ 195].length();
            I[133 ^ 182].length();
            this.onScoreObjectiveAdded(var3);
            return var3;
         }
      }
   }

   public static int getObjectiveDisplaySlotNumber(String var0) {
      if (I[32 + 203 - 145 + 117].equalsIgnoreCase(var0)) {
         return "".length();
      } else if (I[207 + 183 - 358 + 176].equalsIgnoreCase(var0)) {
         return " ".length();
      } else if (I[104 + 139 - 54 + 20].equalsIgnoreCase(var0)) {
         return "  ".length();
      } else {
         if (var0.startsWith(I[67 + 155 - 86 + 74])) {
            String var1 = var0.substring(I[183 + 85 - 109 + 52].length());
            TextFormatting var2 = TextFormatting.getValueByName(var1);
            if (var2 != null && var2.getColorIndex() >= 0) {
               return var2.getColorIndex() + "   ".length();
            }
         }

         return -" ".length();
      }
   }

   public void removePlayerFromTeam(String var1, ScorePlayerTeam var2) {
      String var10000 = I[103 + 152 - 124 + 40];
      String var10001 = I[66 + 11 - -66 + 29];
      String var10002 = I[118 + 0 - -29 + 26];
      var10001 = I[76 + 101 - 163 + 160];
      var10000 = I[8 + 81 - -77 + 9];
      var10001 = I[171 + 8 - 125 + 122];
      var10002 = I[43 + 24 - -49 + 61];
      var10001 = I[79 + 11 - -36 + 52];
      if (this.getPlayersTeam(var1) != var2) {
         I[109 + 26 - -5 + 39].length();
         I[59 + 17 - 38 + 142].length();
         I[34 + 169 - 46 + 24].length();
         IllegalStateException var3 = new IllegalStateException(I[30 + 2 - 6 + 156] + var2.getRegisteredName() + I[59 + 165 - 166 + 125]);
         I[168 + 144 - 151 + 23].length();
         I[90 + 39 - 113 + 169].length();
         I[32 + 161 - 142 + 135].length();
         throw var3;
      } else {
         this.teamMemberships.remove(var1);
         I[168 + 12 - 63 + 70].length();
         I[156 + 147 - 118 + 3].length();
         I[47 + 37 - -55 + 50].length();
         var2.getMembershipCollection().remove(var1);
         I[104 + 162 - 140 + 64].length();
         I[9 + 47 - -41 + 94].length();
         I[139 + 178 - 156 + 31].length();
      }
   }

   @Nullable
   public ScoreObjective getObjective(String var1) {
      return (ScoreObjective)this.scoreObjectives.get(var1);
   }

   public ScorePlayerTeam getTeam(String var1) {
      return (ScorePlayerTeam)this.teams.get(var1);
   }

   public void removeObjectiveFromEntity(String var1, ScoreObjective var2) {
      Map var3;
      if (var2 == null) {
         var3 = (Map)this.entitiesScoreObjectives.remove(var1);
         if (var3 != null) {
            this.broadcastScoreUpdate(var1);
         }

         "".length();
         if (2 <= -1) {
            throw null;
         }
      } else {
         var3 = (Map)this.entitiesScoreObjectives.get(var1);
         if (var3 != null) {
            Score var4 = (Score)var3.remove(var2);
            if (var3.size() < " ".length()) {
               Map var5 = (Map)this.entitiesScoreObjectives.remove(var1);
               if (var5 != null) {
                  this.broadcastScoreUpdate(var1);
               }

               "".length();
               if (0 >= 1) {
                  throw null;
               }
            } else if (var4 != null) {
               this.broadcastScoreUpdate(var1, var2);
            }
         }
      }

   }

   public void removeObjective(ScoreObjective var1) {
      this.scoreObjectives.remove(var1.getName());
      I[144 ^ 199].length();
      int var2 = "".length();

      do {
         if (var2 >= (80 ^ 67)) {
            List var5 = (List)this.scoreObjectiveCriterias.get(var1.getCriteria());
            if (var5 != null) {
               var5.remove(var1);
               I[80 ^ 8].length();
               I[74 ^ 19].length();
               I[14 ^ 84].length();
               I[108 ^ 55].length();
               I[43 ^ 119].length();
            }

            Iterator var3 = this.entitiesScoreObjectives.values().iterator();

            do {
               if (!var3.hasNext()) {
                  this.onScoreObjectiveRemoved(var1);
                  return;
               }

               Map var4 = (Map)var3.next();
               var4.remove(var1);
               I[237 ^ 176].length();
               I[47 ^ 113].length();
               I[54 ^ 105].length();
               I[118 ^ 22].length();
               "".length();
            } while(2 > 1);

            throw null;
         }

         if (this.getObjectiveInDisplaySlot(var2) == var1) {
            this.setObjectiveInDisplaySlot(var2, (ScoreObjective)null);
         }

         ++var2;
         "".length();
      } while(2 < 4);

      throw null;
   }

   public Collection<ScoreObjective> getObjectivesFromCriteria(IScoreCriteria var1) {
      Collection var2 = (Collection)this.scoreObjectiveCriterias.get(var1);
      ArrayList var10000;
      if (var2 == null) {
         var10000 = Lists.newArrayList();
         "".length();
         if (-1 >= 3) {
            throw null;
         }
      } else {
         var10000 = Lists.newArrayList(var2);
      }

      return var10000;
   }

   public Collection<ScorePlayerTeam> getTeams() {
      return this.teams.values();
   }

   private static void I() {
      I = new String[31 + 101 - 58 + 141];
      I["".length()] = I("濙嵑", "zyEgd");
      I[" ".length()] = I("嗜棹", "HHBeD");
      I["  ".length()] = I("倷搨", "GcMfN");
      I["   ".length()] = I("圽瀳", "HzowR");
      I[98 ^ 102] = I("喹棋", "fVCVp");
      I[73 ^ 76] = I("殧孂", "DGxSf");
      I[107 ^ 109] = I("湨伿", "NWsru");
      I[31 ^ 24] = I("滎宁", "zWJAQ");
      I[2 ^ 10] = I("忉懑", "pNlyE");
      I[116 ^ 125] = I("峮忐", "KkEFp");
      I[40 ^ 34] = I("浲旁", "BVofl");
      I[18 ^ 25] = I("凋慡", "lxYGt");
      I[92 ^ 80] = I("憣哞", "DEmEs");
      I[70 ^ 75] = I("役橪", "WroZQ");
      I[92 ^ 82] = I("勀栫", "PuSPN");
      I[112 ^ 127] = I("噞岘", "GAMoL");
      I[79 ^ 95] = I("夓憓", "CvpTq");
      I[62 ^ 47] = I("佭宊", "QYSdI");
      I[83 ^ 65] = I("桫欛", "ZKuPX");
      I[145 ^ 130] = I("棴倗", "EVwaZ");
      I[209 ^ 197] = I("檗巨汇倕嗘", "qkTou");
      I[184 ^ 173] = I("冯媣傥埄", "dQESP");
      I[143 ^ 153] = I("亠先拸怯幑", "jBESP");
      I[150 ^ 129] = I("娽岁涬伮槌", "trQXJ");
      I[60 ^ 36] = I("嫆敄", "eBkiV");
      I[96 ^ 121] = I("槤", "hVKnF");
      I[9 ^ 19] = I("址清唁", "KcGSs");
      I[127 ^ 100] = I("\u001a>\u000bK\u001c,<\u000b\b\u0007' \u000bK\u001d/;\u000bKT", "NVnks");
      I[43 ^ 55] = I("Eg\u001a\u000bi\u0016(\u001cX%\r)\u0014Y", "bGsxI");
      I[125 ^ 96] = I("炸椽濑", "mdNZw");
      I[71 ^ 89] = I("佈", "cOrJa");
      I[57 ^ 38] = I("嚉氘挕", "vlAzo");
      I[51 ^ 19] = I("京儸居", "TNWgb");
      I[175 ^ 142] = I("汐檍", "RrGCF");
      I[149 ^ 183] = I("杯壗姪孫拣", "GqvGA");
      I[94 ^ 125] = I("楁堩兝櫀", "dlXNl");
      I[39 ^ 3] = I("啧椥", "zQdxB");
      I[186 ^ 159] = I("支妉", "SRMHn");
      I[150 ^ 176] = I("潵屆", "NUZsH");
      I[17 ^ 54] = I("\u000f!o\t&$*,\u0012-8*o\u0011-:'o\u0012,+o!\u0007)+oh", "NOOfD");
      I[131 ^ 171] = I("OQ*;>\r\u0010/.l\r\t\"$8\u001bP", "hqKWL");
      I[61 ^ 20] = I("滑寖楀沟", "VCaod");
      I[39 ^ 13] = I("氝峱唄橞", "oMFWd");
      I[17 ^ 58] = I("枅仜厯僮", "BvZbN");
      I[186 ^ 150] = I("哿梫泛洘樈", "ZzzWk");
      I[144 ^ 189] = I("构擃休桄伆", "pRLTE");
      I[190 ^ 144] = I("奈氧旓", "kknEw");
      I[128 ^ 175] = I("揶檚層婽南", "xZLGr");
      I[147 ^ 163] = I("憮", "osZvy");
      I[4 ^ 53] = I("澄娗嘔", "dkOKa");
      I[29 ^ 47] = I("嗩形刓檇", "RSIfa");
      I[103 ^ 84] = I("毀囂", "MEeDq");
      I[134 ^ 178] = I("楸婡", "LDiwQ");
      I[163 ^ 150] = I("懋卧", "lPSTv");
      I[29 ^ 43] = I("澿啅", "IiqLG");
      I[57 ^ 14] = I("似丌", "wMWXu");
      I[165 ^ 157] = I("散彸", "FBnnJ");
      I[3 ^ 58] = I("姲徵", "cpcSG");
      I[42 ^ 16] = I("嘘喉", "WHEUe");
      I[115 ^ 72] = I("殹佩", "XnDwE");
      I[53 ^ 9] = I("戕从", "DxRot");
      I[158 ^ 163] = I("擒惤", "IJACP");
      I[81 ^ 111] = I("椉涃", "sTtCk");
      I[133 ^ 186] = I("惱呹", "EuVAi");
      I[244 ^ 180] = I("徦橀屴昑吗", "CYrEr");
      I[249 ^ 184] = I("堾嵅唲曃湶", "ubfog");
      I[45 ^ 111] = I("傱", "nlTeM");
      I[251 ^ 184] = I("\u0015,#V)-%?\u0013+a*'\u001b<ac", "ADFvY");
      I[132 ^ 192] = I("fa.\u001eb5.(M../ L", "AAGmB");
      I[89 ^ 28] = I("摆冕撬橋", "waeBu");
      I[109 ^ 43] = I("埏曈棙吘榻", "IPjdj");
      I[210 ^ 149] = I("嗖漀", "Phely");
      I[45 ^ 101] = I("兟", "RpERB");
      I[221 ^ 148] = I("悇师", "FRoUP");
      I[55 ^ 125] = I("楋汽柩楙", "Anmoy");
      I[230 ^ 173] = I("弤", "GCdLg");
      I[218 ^ 150] = I("佰倱嵃", "wMUnK");
      I[192 ^ 141] = I("嚾", "iBnYn");
      I[209 ^ 159] = I("椰企夛暈仕", "RtzuC");
      I[59 ^ 116] = I("曯敵嵦嶉旕", "mDWRZ");
      I[113 ^ 33] = I("咃商夂刺瀾", "dXrJs");
      I[97 ^ 48] = I("壀搹", "bukIU");
      I[24 ^ 74] = I("怾仔", "oWdOQ");
      I[5 ^ 86] = I("懣", "KepUA");
      I[38 ^ 114] = I("瀐", "alGvh");
      I[38 ^ 115] = I("宋吪", "nbRfi");
      I[38 ^ 112] = I("怊夥嬀帵", "aqanO");
      I[35 ^ 116] = I("据梦弩", "WaNlQ");
      I[153 ^ 193] = I("棽嬛", "KEAUW");
      I[15 ^ 86] = I("庘", "JEHwD");
      I[193 ^ 155] = I("尒氚徳楎", "TWRpE");
      I[60 ^ 103] = I("巁憗", "NEARz");
      I[3 ^ 95] = I("椯団墻", "PlnkW");
      I[67 ^ 30] = I("崏檳杫廼灱", "ozakb");
      I[87 ^ 9] = I("僀垰撤具嶈", "zdYXR");
      I[242 ^ 173] = I("啣煇", "ypENT");
      I[16 ^ 112] = I("捏", "jUnan");
      I[224 ^ 129] = I("朝愿", "yHHfZ");
      I[29 ^ 127] = I("朠沵", "NjOtV");
      I[70 ^ 37] = I("孂姥", "jpevq");
      I[46 ^ 74] = I("烥坡", "qlRMQ");
      I[162 ^ 199] = I("恉惔", "fBUdH");
      I[212 ^ 178] = I("庅帄", "yygIg");
      I[247 ^ 144] = I("烀傚", "CWJcc");
      I[221 ^ 181] = I("其呠", "oiaJz");
      I[56 ^ 81] = I("奊涼", "wOGMB");
      I[22 ^ 124] = I("垼戳", "GBkip");
      I[21 ^ 126] = I("啉佮", "VbdhD");
      I[246 ^ 154] = I("墽咗", "yTDru");
      I[173 ^ 192] = I("氢槇", "PZMcJ");
      I[13 ^ 99] = I("瀿愘", "eJLrm");
      I[13 ^ 98] = I("搒忲", "hcCke");
      I[213 ^ 165] = I("嗦乊", "LsrCS");
      I[76 ^ 61] = I("栰淬", "mdDXh");
      I[124 ^ 14] = I("俐堮", "JebTR");
      I[39 ^ 84] = I("勴澜", "TykkT");
      I[107 ^ 31] = I("撃撥", "TTZuR");
      I[100 ^ 17] = I("傞區懞汓", "PvTsa");
      I[7 ^ 113] = I("枦彞漶堼榵", "WLNBj");
      I[94 ^ 41] = I("副彋潫伹柡", "vYmdX");
      I[244 ^ 140] = I("梷恬瀎", "QDsYS");
      I[33 ^ 88] = I("媼侹巎", "cDhMh");
      I[3 ^ 121] = I("\u0018\u00023r\u0001)\u000b;r\u001b-\u00073rR", "LjVRu");
      I[235 ^ 144] = I("hP8\u0016a;\u001f>E- \u001e6D", "OpQeA");
      I[40 ^ 84] = I("斝櫴啳檄杭", "rsVcL");
      I[35 ^ 94] = I("堢氯昞孞", "iafaJ");
      I[39 ^ 89] = I("嶑墈", "AllbA");
      I[115 + 23 - 57 + 46] = I("帰儣楉灦夙", "HuJVC");
      I[104 + 14 - 7 + 17] = I("亙楚", "fUXoJ");
      I[26 + 57 - 74 + 120] = I("儥栧", "GnyUs");
      I[85 + 63 - 58 + 40] = I("柩壓", "nKUpD");
      I[48 + 2 - 43 + 124] = I("8e\f<\u0017\u0014e\u000f0\u0002\u0011e\f1\u0013Y+\u00194\u0013Yb", "yExYv");
      I[124 + 70 - 146 + 84] = I("nx6)6,93<d, >60:y", "IXWED");
      I[124 + 51 - 154 + 112] = I("挡柘", "dPLzH");
      I[10 + 132 - 15 + 7] = I("櫛榔塘", "HWfrf");
      I[8 + 113 - 22 + 36] = I("叻圪夶女唫", "yKDSW");
      I[76 + 77 - 102 + 85] = I("叇漯", "GAlTF");
      I[10 + 73 - 62 + 116] = I("勸椗", "wjddI");
      I[54 + 20 - -1 + 63] = I("妧员唛庨", "JxrBv");
      I[5 + 25 - -89 + 20] = I("姉徖瀉催", "BJNSW");
      I[38 + 15 - 27 + 114] = I("嵎", "soiVJ");
      I[116 + 35 - 44 + 34] = I("婅", "YVGCv");
      I[11 + 122 - 39 + 48] = I("亢嶈檶檻", "zVGQF");
      I[99 + 38 - 126 + 132] = I("泅毠涃", "WRipI");
      I[107 + 34 - 76 + 79] = I("榆擸妤", "xFUzV");
      I[137 + 85 - 138 + 61] = I("沰屳", "aPcke");
      I[96 + 103 - 183 + 130] = I("毶咗忓归", "MJfbR");
      I[89 + 51 - 80 + 87] = I("俦令哷剽", "Stsze");
      I[17 + 53 - -60 + 18] = I("圣廷", "wTpEI");
      I[36 + 49 - 19 + 83] = I("灷捩", "sHPwi");
      I[56 + 148 - 98 + 44] = I("刖呣", "ecRWi");
      I[49 + 132 - 155 + 125] = I("彴懛", "vHrXM");
      I[117 + 3 - 2 + 34] = I("汩椨", "TWDVP");
      I[116 + 102 - 204 + 139] = I("既漺", "hEaWn");
      I[92 + 61 - 74 + 75] = I("妗惎", "yEERH");
      I[110 + 133 - 216 + 128] = I("劼査", "mFgnG");
      I[66 + 59 - 29 + 60] = I("滅", "isRls");
      I[140 + 95 - 169 + 91] = I("昔", "ALXGj");
      I[125 + 123 - 125 + 35] = I("孅劇懤撶", "mCHHp");
      I[7 + 148 - 138 + 142] = I("<\u0003\u0002a9\u0004\n\u001e$;H\u0005\u0006,,HL", "hkgAI");
      I[45 + 2 - -113 + 0] = I("~T.\tT-\u001b(Z\u00186\u001a [", "YtGzt");
      I[132 + 25 - 146 + 150] = I("梧壅惯懿浗", "EshNY");
      I[148 + 84 - 164 + 94] = I("忭憿", "Jvjhq");
      I[66 + 14 - 57 + 140] = I("嚊溳檦嵡", "enXPO");
      I[16 + 151 - 161 + 158] = I("溮", "wjdBz");
      I[65 + 130 - 188 + 158] = I("憎幪如气", "uvhmg");
      I[124 + 112 - 103 + 33] = I("朰", "YpVWL");
      I[79 + 33 - -15 + 40] = I("汈", "vpNNv");
      I[157 + 17 - 26 + 20] = I("夽掋挫偟", "XoQnb");
      I[74 + 59 - 94 + 130] = I("夔搀庶愵", "YRkCD");
      I[106 + 3 - 38 + 99] = I("倈渧查忿", "WIiKK");
      I[90 + 19 - 23 + 85] = I("咩姢", "rcopF");
      I[143 + 58 - 69 + 40] = I("屐兆", "FswhK");
      I[140 + 144 - 203 + 92] = I("揶泒", "WkAbL");
      I[132 + 4 - 20 + 58] = I("尹岋", "YQAAu");
      I[173 + 4 - 25 + 23] = I("涉旉", "liyLD");
      I[68 + 138 - 57 + 27] = I("堰汱", "HIDCF");
      I[108 + 95 - 175 + 149] = I("樼涉", "sXWuf");
      I[60 + 134 - 162 + 146] = I("勰墈", "LNJEM");
      I[34 + 63 - 51 + 133] = I("彦洂", "XeJuv");
      I[50 + 146 - 132 + 116] = I("樗回", "bXgFL");
      I[133 + 91 - 197 + 154] = I("必冶櫣啋", "LRIAu");
      I[118 + 123 - 69 + 10] = I("\u0004;\r/\u0013&w\u0005%V1>\u0018>\u0013&w\u00038V59\u0003\"\u001e1%L\"\u00135:L9\u0004t9\u0003\"V;9L7\u0018-w\u00183\u00179yL\u0015\u0017:9\u0003\"V&2\u00019\u00001w\n$\u00199w\u00183\u00179wK", "TWlVv");
      I[172 + 110 - 135 + 36] = I("pf", "WHyry");
      I[97 + 36 - 1 + 52] = I("啔浧歆慈", "wcsFK");
      I[184 + 51 - 179 + 129] = I("栄厯", "ZRper");
      I[135 + 163 - 230 + 118] = I("戤棾栦濳", "JGhch");
      I[67 + 36 - 76 + 160] = I("拊", "mBrVC");
      I[102 + 114 - 43 + 15] = I("櫧", "RUJWW");
      I[5 + 49 - -111 + 24] = I("灐摬", "UmKyn");
      I[67 + 133 - 145 + 135] = I("巡", "bISnp");
      I[45 + 147 - 66 + 65] = I("浟涆兘偦", "mUSWU");
      I[70 + 32 - 70 + 160] = I("止掩", "FbhDt");
      I[124 + 162 - 248 + 155] = I("掷敩", "uIfBK");
      I[172 + 72 - 109 + 59] = I("巯曻", "gXdVW");
      I[180 + 151 - 299 + 163] = I("悘烍", "GajDN");
      I[122 + 14 - 135 + 195] = I("棭溾", "cnKgd");
      I[36 + 12 - -123 + 26] = I("\u0003\u0004'\u001f", "omTkv");
      I[27 + 164 - 130 + 137] = I("\u0001\u000b5\u0013\u0013\u0013\u0010", "rbQvq");
      I[85 + 147 - 173 + 140] = I("0\u001f\r\u0004\r\u001c\u001b\f\u000e", "Rzakz");
      I[118 + 14 - -9 + 59] = I("昧", "UqoZE");
      I[134 + 25 - 17 + 59] = I("嶬复囌慹劎", "MxojM");
      I[182 + 188 - 181 + 13] = I("兕戌每瀓", "gbfHE");
      I[85 + 78 - 162 + 202] = I("咨埂", "ehXXM");
      I[146 + 62 - 47 + 43] = I("唩埤", "stEQa");
      I[130 + 115 - 215 + 175] = I("果", "ZzofT");
      I[64 + 107 - 9 + 44] = I("1-\b/\f#6B>\u000b#)B", "BDlJn");
      I[106 + 89 - 53 + 65] = I("6\u001f\n?", "ZvyKx");
      I[200 + 59 - 117 + 66] = I("\u0002#\u0006\u0002,\u00108", "qJbgN");
      I[77 + 119 - 101 + 114] = I("\u0014+\u001c\u001f?8/\u001d\u0015", "vNppH");
      I[209 + 146 - 147 + 2] = I("\u0010#&\n!\u00028l\u001b&\u0002'l", "cJBoC");
      I[155 + 161 - 302 + 197] = I("\u0015+\t';\u00070C6<\u0007/C", "fBmBY");
      I[193 + 207 - 287 + 99] = I("梤杩庡溋枝", "NRIyZ");
      I[20 + 10 - -90 + 93] = I("堭冐朐沪", "UWgMG");
      I[201 + 107 - 158 + 64] = I("嵾斞", "hUhrN");
   }

   public void broadcastTeamRemove(ScorePlayerTeam var1) {
   }

   public void onScoreObjectiveRemoved(ScoreObjective var1) {
   }

   @Nullable
   public ScorePlayerTeam getPlayersTeam(String var1) {
      return (ScorePlayerTeam)this.teamMemberships.get(var1);
   }

   public Collection<ScoreObjective> getScoreObjectives() {
      return this.scoreObjectives.values();
   }

   static {
      I();
   }

   public void onScoreObjectiveAdded(ScoreObjective var1) {
   }

   public Collection<Score> getScores() {
      Collection var1 = this.entitiesScoreObjectives.values();
      ArrayList var2 = Lists.newArrayList();
      Iterator var3 = var1.iterator();

      do {
         if (!var3.hasNext()) {
            return var2;
         }

         Map var4 = (Map)var3.next();
         var2.addAll(var4.values());
         I[29 ^ 72].length();
         I[67 ^ 21].length();
         "".length();
      } while(1 < 3);

      throw null;
   }

   public Collection<String> getObjectiveNames() {
      return this.entitiesScoreObjectives.keySet();
   }

   public void removeEntity(Entity var1) {
      if (var1 != null && !(var1 instanceof EntityPlayer) && !var1.isEntityAlive()) {
         String var2 = var1.getCachedUniqueIdString();
         this.removeObjectiveFromEntity(var2, (ScoreObjective)null);
         this.removePlayerFromTeams(var2);
         I[94 + 90 - -7 + 21].length();
         I[58 + 129 - 64 + 90].length();
         I[143 + 15 - 115 + 171].length();
      }

   }

   public Collection<Score> getSortedScores(ScoreObjective var1) {
      ArrayList var2 = Lists.newArrayList();
      Iterator var3 = this.entitiesScoreObjectives.values().iterator();

      do {
         if (!var3.hasNext()) {
            Collections.sort(var2, Score.SCORE_COMPARATOR);
            return var2;
         }

         Map var4 = (Map)var3.next();
         Score var5 = (Score)var4.get(var1);
         if (var5 != null) {
            var2.add(var5);
            I[89 ^ 9].length();
            I[144 ^ 193].length();
            I[6 ^ 84].length();
            I[6 ^ 85].length();
            I[243 ^ 167].length();
         }

         "".length();
      } while(4 >= 4);

      throw null;
   }

   @Nullable
   public ScoreObjective getObjectiveInDisplaySlot(int var1) {
      return this.objectiveDisplaySlots[var1];
   }

   public ScorePlayerTeam createTeam(String var1) {
      String var10000 = I[21 ^ 116];
      String var10001 = I[103 ^ 5];
      String var10002 = I[60 ^ 95];
      var10001 = I[165 ^ 193];
      var10000 = I[161 ^ 196];
      var10001 = I[26 ^ 124];
      var10002 = I[10 ^ 109];
      var10001 = I[226 ^ 138];
      var10000 = I[43 ^ 66];
      var10001 = I[26 ^ 112];
      var10002 = I[87 ^ 60];
      var10001 = I[62 ^ 82];
      var10000 = I[10 ^ 103];
      var10001 = I[195 ^ 173];
      var10002 = I[3 ^ 108];
      var10001 = I[124 ^ 12];
      var10000 = I[100 ^ 21];
      var10001 = I[76 ^ 62];
      var10002 = I[113 ^ 2];
      var10001 = I[27 ^ 111];
      IllegalArgumentException var3;
      if (var1.length() > (74 ^ 90)) {
         I[116 ^ 1].length();
         I[99 ^ 21].length();
         I[246 ^ 129].length();
         I[94 ^ 38].length();
         I[245 ^ 140].length();
         var3 = new IllegalArgumentException(I[80 ^ 42] + var1 + I[240 ^ 139]);
         I[1 ^ 125].length();
         I[102 ^ 27].length();
         throw var3;
      } else {
         ScorePlayerTeam var2 = this.getTeam(var1);
         if (var2 != null) {
            I[6 ^ 120].length();
            I[18 + 69 - -23 + 17].length();
            I[40 + 73 - 62 + 77].length();
            I[88 + 76 - 112 + 77].length();
            I[82 + 72 - 140 + 116].length();
            var3 = new IllegalArgumentException(I[117 + 123 - 169 + 60] + var1 + I[1 + 10 - -39 + 82]);
            I[24 + 98 - -5 + 6].length();
            I[12 + 108 - 9 + 23].length();
            I[55 + 112 - 91 + 59].length();
            I[56 + 124 - 132 + 88].length();
            throw var3;
         } else {
            I[113 + 97 - 75 + 2].length();
            I[124 + 131 - 223 + 106].length();
            I[97 + 66 - 160 + 136].length();
            var2 = new ScorePlayerTeam(this, var1);
            this.teams.put(var1, var2);
            I[54 + 90 - 10 + 6].length();
            I[95 + 102 - 179 + 123].length();
            I[87 + 106 - 132 + 81].length();
            this.broadcastTeamCreated(var2);
            return var2;
         }
      }
   }

   public Collection<String> getTeamNames() {
      return this.teams.keySet();
   }

   public Map<ScoreObjective, Score> getObjectivesForEntity(String var1) {
      Object var2 = (Map)this.entitiesScoreObjectives.get(var1);
      if (var2 == null) {
         var2 = Maps.newHashMap();
      }

      return (Map)var2;
   }

   public void broadcastScoreUpdate(String var1, ScoreObjective var2) {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 0);

      throw null;
   }

   public void broadcastTeamCreated(ScorePlayerTeam var1) {
   }

   public boolean removePlayerFromTeams(String var1) {
      ScorePlayerTeam var2 = this.getPlayersTeam(var1);
      if (var2 != null) {
         this.removePlayerFromTeam(var1, var2);
         return (boolean)" ".length();
      } else {
         return (boolean)"".length();
      }
   }

   public Score getOrCreateScore(String var1, ScoreObjective var2) {
      String var10000 = I[52 ^ 0];
      String var10001 = I[111 ^ 90];
      String var10002 = I[91 ^ 109];
      var10001 = I[126 ^ 73];
      var10000 = I[84 ^ 108];
      var10001 = I[135 ^ 190];
      var10002 = I[1 ^ 59];
      var10001 = I[14 ^ 53];
      var10000 = I[137 ^ 181];
      var10001 = I[12 ^ 49];
      var10002 = I[187 ^ 133];
      var10001 = I[147 ^ 172];
      if (var1.length() > (235 ^ 195)) {
         I[232 ^ 168].length();
         I[9 ^ 72].length();
         I[135 ^ 197].length();
         IllegalArgumentException var5 = new IllegalArgumentException(I[115 ^ 48] + var1 + I[83 ^ 23]);
         I[127 ^ 58].length();
         I[218 ^ 156].length();
         I[59 ^ 124].length();
         throw var5;
      } else {
         Object var3 = (Map)this.entitiesScoreObjectives.get(var1);
         if (var3 == null) {
            var3 = Maps.newHashMap();
            this.entitiesScoreObjectives.put(var1, var3);
            I[194 ^ 138].length();
            I[67 ^ 10].length();
            I[192 ^ 138].length();
            I[88 ^ 19].length();
         }

         Score var4 = (Score)((Map)var3).get(var2);
         if (var4 == null) {
            I[3 ^ 79].length();
            I[140 ^ 193].length();
            var4 = new Score(this, var2, var1);
            ((Map)var3).put(var2, var4);
            I[113 ^ 63].length();
            I[124 ^ 51].length();
         }

         return var4;
      }
   }

   public void onScoreUpdated(Score var1) {
   }

   public boolean addPlayerToTeam(String var1, String var2) {
      String var10000 = I[79 + 1 - 14 + 82];
      String var10001 = I[137 + 128 - 263 + 147];
      String var10002 = I[113 + 98 - 131 + 70];
      var10001 = I[106 + 59 - 156 + 142];
      var10000 = I[136 + 79 - 106 + 43];
      var10001 = I[63 + 123 - 127 + 94];
      var10002 = I[39 + 91 - 19 + 43];
      var10001 = I[2 + 2 - -145 + 6];
      if (var1.length() > (126 ^ 86)) {
         I[128 + 123 - 151 + 56].length();
         I[83 + 122 - 159 + 111].length();
         I[4 + 150 - 57 + 61].length();
         IllegalArgumentException var4 = new IllegalArgumentException(I[142 + 61 - 129 + 85] + var1 + I[12 + 42 - 25 + 131]);
         I[27 + 71 - 56 + 119].length();
         I[24 + 87 - 0 + 51].length();
         I[28 + 39 - -31 + 65].length();
         throw var4;
      } else if (!this.teams.containsKey(var2)) {
         return (boolean)"".length();
      } else {
         ScorePlayerTeam var3 = this.getTeam(var2);
         if (this.getPlayersTeam(var1) != null) {
            this.removePlayerFromTeams(var1);
            I[99 + 123 - 186 + 128].length();
            I[143 + 89 - 229 + 162].length();
         }

         this.teamMemberships.put(var1, var3);
         I[29 + 22 - -9 + 106].length();
         var3.getMembershipCollection().add(var1);
         I[131 + 44 - 9 + 1].length();
         I[72 + 102 - 12 + 6].length();
         I[2 + 87 - -37 + 43].length();
         I[160 + 133 - 156 + 33].length();
         return (boolean)" ".length();
      }
   }

   public static String[] getDisplaySlotStrings() {
      if (displaySlots == null) {
         displaySlots = new String[191 ^ 172];
         int var0 = "".length();

         while(var0 < (136 ^ 155)) {
            displaySlots[var0] = getObjectiveDisplaySlot(var0);
            ++var0;
            "".length();
            if (4 != 4) {
               throw null;
            }
         }
      }

      return displaySlots;
   }

   public void broadcastTeamInfoUpdate(ScorePlayerTeam var1) {
   }

   public void broadcastScoreUpdate(String var1) {
   }

   public static String getObjectiveDisplaySlot(int var0) {
      String var10000 = I[1 + 113 - -44 + 35];
      String var10001 = I[23 + 80 - 63 + 154];
      String var10002 = I[182 + 129 - 156 + 40];
      var10001 = I[100 + 135 - 182 + 143];
      switch(var0) {
      case 0:
         return I[121 + 180 - 260 + 156];
      case 1:
         return I[136 + 57 - 178 + 183];
      case 2:
         return I[185 + 175 - 216 + 55];
      default:
         if (var0 >= "   ".length() && var0 <= (174 ^ 188)) {
            int var2 = "   ".length();
            I[85 + 197 - 133 + 51].length();
            I[173 + 176 - 173 + 25].length();
            I[119 + 87 - 172 + 168].length();
            I[45 + 143 - 80 + 95].length();
            TextFormatting var1 = TextFormatting.fromColorIndex(var0 - var2);
            if (var1 != null && var1 != TextFormatting.RESET) {
               I[184 + 35 - 165 + 150].length();
               I[176 + 180 - 318 + 167].length();
               return I[63 + 43 - -30 + 70] + var1.getFriendlyName();
            }
         }

         return null;
      }
   }

   public boolean entityHasObjective(String var1, ScoreObjective var2) {
      Map var3 = (Map)this.entitiesScoreObjectives.get(var1);
      if (var3 == null) {
         return (boolean)"".length();
      } else {
         Score var4 = (Score)var3.get(var2);
         int var10000;
         if (var4 != null) {
            var10000 = " ".length();
            "".length();
            if (4 == 1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public void removeTeam(ScorePlayerTeam var1) {
      if (var1 != null) {
         this.teams.remove(var1.getRegisteredName());
         I[101 + 75 - 106 + 73].length();
         I[55 + 20 - 46 + 115].length();
         I[123 + 16 - 98 + 104].length();
         Iterator var2 = var1.getMembershipCollection().iterator();

         while(var2.hasNext()) {
            String var3 = (String)var2.next();
            this.teamMemberships.remove(var3);
            I[84 + 58 - 2 + 6].length();
            I[105 + 28 - 132 + 146].length();
            "".length();
            if (1 <= -1) {
               throw null;
            }
         }

         this.broadcastTeamRemove(var1);
      }

   }

   public void onObjectiveDisplayNameChanged(ScoreObjective var1) {
   }
}

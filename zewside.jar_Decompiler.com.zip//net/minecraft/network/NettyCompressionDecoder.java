package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.handler.codec.DecoderException;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public class NettyCompressionDecoder extends ByteToMessageDecoder {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Inflater inflater;
   // $FF: synthetic field
   private int threshold;

   static {
      I();
   }

   public NettyCompressionDecoder(int var1) {
      this.threshold = var1;
      this.inflater = new Inflater();
   }

   private static void I() {
      I = new String[12 ^ 63];
      I["".length()] = I("唄惚", "EYweG");
      I[" ".length()] = I("淕消", "isGDa");
      I["  ".length()] = I("挟彂", "sxObZ");
      I["   ".length()] = I("歡椦", "ZHeBy");
      I[161 ^ 165] = I("瀳榏", "kFWQs");
      I[71 ^ 66] = I("渌兼", "asjPO");
      I[143 ^ 137] = I("匢汪", "douhB");
      I[148 ^ 147] = I("底愖", "NEINw");
      I[173 ^ 165] = I("咮姺", "VvMcH");
      I[11 ^ 2] = I("坞湉", "txSZp");
      I[184 ^ 178] = I("戹桎", "YEBLA");
      I[126 ^ 117] = I("灟囚", "kOAeQ");
      I[116 ^ 120] = I("桊块", "AWbdB");
      I[18 ^ 31] = I("扸泓", "stugX");
      I[166 ^ 168] = I("欖挏", "YDhXx");
      I[54 ^ 57] = I("炤晬", "zHBhU");
      I[12 ^ 28] = I("倃亭", "ONXay");
      I[26 ^ 11] = I("幌桪", "TbDmq");
      I[132 ^ 150] = I("崢堞", "eaRzP");
      I[174 ^ 189] = I("冇尀", "WiFpG");
      I[12 ^ 24] = I("吱嫹晄暚", "euUrs");
      I[161 ^ 180] = I("廷渥堡宐搾", "eeSXO");
      I[54 ^ 32] = I("弍檄抂圧冯", "msItr");
      I[145 ^ 134] = I("彛俥巧漧", "AXCzJ");
      I[33 ^ 57] = I("嵆浑檗", "KOIyk");
      I[118 ^ 111] = I("炎溍檑尤", "StqpJ");
      I[37 ^ 63] = I("梊儺壊庭抨", "XsHKO");
      I[185 ^ 162] = I("榄嬭烏", "EqYvg");
      I[178 ^ 174] = I("拍欮", "epPSN");
      I[180 ^ 169] = I("\u0000\u0011\u000e\u001f\nb\u0013\u0005\u001e\u00030\u0015\u0019\u0000\u0016&P\u001a\u0012\u0010)\u0015\u001eS^b\u0003\u0003\t\u0016b\u001f\fS", "Bpjss");
      I[61 ^ 35] = I("j\u0018\u001aK\n/\u001d\u0006\u001cH9\u0014\u001b\u001d\r8Q\u001d\u0003\u001a/\u0002\u0001\u0004\u0004.Q\u0006\rH", "Jqikh");
      I[150 ^ 137] = I("咀欗咒", "XUOCj");
      I[153 ^ 185] = I("征", "ZaQAG");
      I[52 ^ 21] = I("瀴忝", "WdJTh");
      I[46 ^ 12] = I("偣媱", "bZYuN");
      I[174 ^ 141] = I("流炆儶徬林", "KudXK");
      I[81 ^ 117] = I("哂扢嫀地橴", "aUNVE");
      I[146 ^ 183] = I("呓氯垒库", "mLNeV");
      I[26 ^ 60] = I("塽烺忾", "qXICB");
      I[23 ^ 48] = I("凜喬", "bULjw");
      I[87 ^ 127] = I("7#\u0007>\u0010U!\f?\u0019\u0007'\u0010!\f\u0011b\u00133\n\u001e'\u0017rDU1\n(\fU-\u0005r", "uBcRi");
      I[30 ^ 55] = I("y92B\u00148\"&\u0007\ny$)\u0003\u0016y 3\r\f63.\u000eX419\u000b\u0015,=a\r\u001ey", "YPAbx");
      I[78 ^ 100] = I("寍刭灢擦桮", "nmcbq");
      I[23 ^ 60] = I("栞灯俻", "oeBjx");
      I[94 ^ 114] = I("方嶹", "VwkwE");
      I[55 ^ 26] = I("憻倃尧桄幗", "gQoDl");
      I[156 ^ 178] = I("愑暗瀳", "cQMRR");
      I[186 ^ 149] = I("煞櫼唒儻幊", "tHxmQ");
      I[83 ^ 99] = I("應楫庙對", "PlLuC");
      I[107 ^ 90] = I("潍却", "pFpVu");
      I[142 ^ 188] = I("孓", "KuVGF");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 0);

      throw null;
   }

   public void setCompressionThreshold(int var1) {
      this.threshold = var1;
   }

   protected void decode(ChannelHandlerContext var1, ByteBuf var2, List<Object> var3) throws Exception, DataFormatException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[144 ^ 148];
      var10001 = I[68 ^ 65];
      var10002 = I[19 ^ 21];
      var10001 = I[133 ^ 130];
      var10000 = I[105 ^ 97];
      var10001 = I[114 ^ 123];
      var10002 = I[58 ^ 48];
      var10001 = I[169 ^ 162];
      var10000 = I[51 ^ 63];
      var10001 = I[66 ^ 79];
      var10002 = I[5 ^ 11];
      var10001 = I[97 ^ 110];
      var10000 = I[173 ^ 189];
      var10001 = I[120 ^ 105];
      var10002 = I[135 ^ 149];
      var10001 = I[213 ^ 198];
      if (var2.readableBytes() != 0) {
         I[59 ^ 47].length();
         I[64 ^ 85].length();
         PacketBuffer var4 = new PacketBuffer(var2);
         int var5 = var4.readVarIntFromBuffer();
         if (var5 == 0) {
            var3.add(var4.readBytes(var4.readableBytes()));
            I[133 ^ 147].length();
            I[123 ^ 108].length();
            I[165 ^ 189].length();
            "".length();
            if (4 < 4) {
               throw null;
            }
         } else {
            DecoderException var8;
            if (var5 < this.threshold) {
               I[7 ^ 30].length();
               I[133 ^ 159].length();
               I[25 ^ 2].length();
               I[59 ^ 39].length();
               var8 = new DecoderException(I[137 ^ 148] + var5 + I[139 ^ 149] + this.threshold);
               I[137 ^ 150].length();
               I[83 ^ 115].length();
               throw var8;
            }

            if (var5 > 1841650 + 1149850 - 2472756 + 1578408) {
               I[60 ^ 29].length();
               I[33 ^ 3].length();
               I[24 ^ 59].length();
               I[163 ^ 135].length();
               I[52 ^ 17].length();
               I[24 ^ 62].length();
               I[7 ^ 32].length();
               var8 = new DecoderException(I[66 ^ 106] + var5 + I[177 ^ 152] + (1501101 + 1472518 - 2320230 + 1443763));
               I[167 ^ 141].length();
               I[76 ^ 103].length();
               throw var8;
            }

            byte[] var6 = new byte[var4.readableBytes()];
            var4.readBytes(var6);
            I[18 ^ 62].length();
            I[103 ^ 74].length();
            I[165 ^ 139].length();
            this.inflater.setInput(var6);
            byte[] var7 = new byte[var5];
            this.inflater.inflate(var7);
            I[239 ^ 192].length();
            I[64 ^ 112].length();
            I[165 ^ 148].length();
            var3.add(Unpooled.wrappedBuffer(var7));
            I[31 ^ 45].length();
            this.inflater.reset();
         }
      }

   }
}

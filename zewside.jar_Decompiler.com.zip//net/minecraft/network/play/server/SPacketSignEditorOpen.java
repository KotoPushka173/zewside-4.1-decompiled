package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;

public class SPacketSignEditorOpen implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private BlockPos signPosition;
   // $FF: synthetic field
   private static final String[] I;

   public SPacketSignEditorOpen(BlockPos var1) {
      this.signPosition = var1;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSignEditorOpen(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.signPosition = var1.readBlockPos();
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("歆", "RfZBp");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 2);

      throw null;
   }

   public BlockPos getSignPosition() {
      return this.signPosition;
   }

   static {
      I();
   }

   public SPacketSignEditorOpen() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeBlockPos(this.signPosition);
      I["".length()].length();
   }
}

package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockDirt extends Block {
   // $FF: synthetic field
   public static final PropertyEnum<BlockDirt.DirtType> VARIANT;
   // $FF: synthetic field
   public static final PropertyBool SNOWY;
   // $FF: synthetic field
   private static final String[] I;

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockDirt.DirtType.byMetadata(var1));
   }

   protected BlockDirt() {
      super(Material.GROUND);
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockDirt.DirtType.DIRT).withProperty(SNOWY, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public int damageDropped(IBlockState var1) {
      BlockDirt.DirtType var2 = (BlockDirt.DirtType)var1.getValue(VARIANT);
      if (var2 == BlockDirt.DirtType.PODZOL) {
         var2 = BlockDirt.DirtType.DIRT;
      }

      return var2.getMetadata();
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockDirt.DirtType)var1.getValue(VARIANT)).getMetadata();
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[189 ^ 185];
      var10001 = I[188 ^ 185];
      var10002 = I[106 ^ 108];
      var10001 = I[137 ^ 142];
      var10000 = I[179 ^ 187];
      var10001 = I[83 ^ 90];
      var10002 = I[15 ^ 5];
      var10001 = I[148 ^ 159];
      I[108 ^ 96].length();
      I[72 ^ 69].length();
      I[75 ^ 69].length();
      var2.add(new ItemStack(this, " ".length(), BlockDirt.DirtType.DIRT.getMetadata()));
      I[28 ^ 19].length();
      I[3 ^ 19].length();
      I[189 ^ 172].length();
      I[85 ^ 71].length();
      I[95 ^ 76].length();
      I[53 ^ 33].length();
      var2.add(new ItemStack(this, " ".length(), BlockDirt.DirtType.COARSE_DIRT.getMetadata()));
      I[104 ^ 125].length();
      I[18 ^ 4].length();
      I[100 ^ 115].length();
      I[129 ^ 153].length();
      I[180 ^ 173].length();
      I[222 ^ 196].length();
      var2.add(new ItemStack(this, " ".length(), BlockDirt.DirtType.PODZOL.getMetadata()));
      I[147 ^ 136].length();
      I[77 ^ 81].length();
      I[109 ^ 112].length();
      I[60 ^ 34].length();
      I[18 ^ 13].length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[23 ^ 63];
      String var10001 = I[167 ^ 142];
      String var10002 = I[187 ^ 145];
      var10001 = I[24 ^ 51];
      var10000 = I[105 ^ 69];
      var10001 = I[99 ^ 78];
      var10002 = I[46 ^ 0];
      var10001 = I[155 ^ 180];
      var10000 = I[88 ^ 104];
      var10001 = I[151 ^ 166];
      var10002 = I[94 ^ 108];
      var10001 = I[132 ^ 183];
      I[72 ^ 124].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[168 ^ 157].length();
      I[147 ^ 165].length();
      var10003["".length()] = VARIANT;
      I[14 ^ 57].length();
      I[92 ^ 100].length();
      var10003[" ".length()] = SNOWY;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      if (var1.getValue(VARIANT) == BlockDirt.DirtType.PODZOL) {
         Block var4 = var2.getBlockState(var3.up()).getBlock();
         PropertyBool var10001 = SNOWY;
         int var10002;
         if (var4 != Blocks.SNOW && var4 != Blocks.SNOW_LAYER) {
            var10002 = "".length();
         } else {
            var10002 = " ".length();
            "".length();
            if (false) {
               throw null;
            }
         }

         var1 = var1.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      }

      return var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != -1);

      throw null;
   }

   private static void I() {
      I = new String[27 ^ 32];
      I["".length()] = I("櫨仦", "gsvQO");
      I[" ".length()] = I("倧惤", "ZYbvH");
      I["  ".length()] = I("嚘氲", "yieEu");
      I["   ".length()] = I("椻击", "ETPgY");
      I[61 ^ 57] = I("椌洮", "qbRgO");
      I[161 ^ 164] = I("嚲俲", "SnSuO");
      I[4 ^ 2] = I("刐滿", "LMTPQ");
      I[143 ^ 136] = I("斒濲", "sVxaJ");
      I[44 ^ 36] = I("啢分", "cMpdL");
      I[96 ^ 105] = I("斍匥", "afkkG");
      I[58 ^ 48] = I("厱欩", "ZqsXu");
      I[78 ^ 69] = I("勦圧", "dGjjG");
      I[96 ^ 108] = I("溹剔嚝", "XHvSY");
      I[63 ^ 50] = I("尓凕昵", "HToDj");
      I[12 ^ 2] = I("剞墚庌", "jShhD");
      I[189 ^ 178] = I("售岦嚋", "WxaIo");
      I[125 ^ 109] = I("椵佌倈", "rBjOX");
      I[145 ^ 128] = I("括厧廳悎亞", "XYLcS");
      I[77 ^ 95] = I("別宽忝", "BBPfu");
      I[171 ^ 184] = I("嗐帿峑弫俫", "lgmJy");
      I[49 ^ 37] = I("並榤暏", "BOqKu");
      I[179 ^ 166] = I("吕傻", "iVVEw");
      I[156 ^ 138] = I("侬憥", "xUGId");
      I[109 ^ 122] = I("哼", "RRyWO");
      I[52 ^ 44] = I("峖吾斏氅", "RRUsB");
      I[81 ^ 72] = I("唤婼冩枕", "AWTsT");
      I[141 ^ 151] = I("娼廵嬮暠", "UTaJE");
      I[158 ^ 133] = I("会凹丈", "eDuql");
      I[180 ^ 168] = I("喷漕欹毧摑", "qIFRe");
      I[48 ^ 45] = I("嫵", "cfTzH");
      I[181 ^ 171] = I("免", "BPbvE");
      I[18 ^ 13] = I("杘次峣楟樇", "iFAQX");
      I[1 ^ 33] = I("瀇持", "GPmav");
      I[82 ^ 115] = I("叄囥", "SJFPe");
      I[71 ^ 101] = I("宏徱", "GySCu");
      I[80 ^ 115] = I("倱抏", "NwBOb");
      I[187 ^ 159] = I("柦幰漵嶂", "rXBhU");
      I[156 ^ 185] = I("係儨帮掟徴", "JFMIg");
      I[50 ^ 20] = I("煊幹湯濦橶", "jhkBH");
      I[5 ^ 34] = I("嘫", "JYXle");
      I[135 ^ 175] = I("梒湑", "cQRyu");
      I[126 ^ 87] = I("伦廥", "hOiOa");
      I[188 ^ 150] = I("毂师", "duVHq");
      I[98 ^ 73] = I("惦拑", "IehzC");
      I[136 ^ 164] = I("嬑撂", "GoFOg");
      I[119 ^ 90] = I("榍円", "lZdst");
      I[71 ^ 105] = I("埚传", "kjdjA");
      I[140 ^ 163] = I("浇埇", "rqPyz");
      I[184 ^ 136] = I("噖楼", "aPskA");
      I[44 ^ 29] = I("信涋", "NzMeb");
      I[64 ^ 114] = I("梄欑", "jDukI");
      I[49 ^ 2] = I("儛夸", "EMwGF");
      I[154 ^ 174] = I("已朼孎", "vkRAq");
      I[132 ^ 177] = I("灷怾敯圑嵾", "cSiPi");
      I[15 ^ 57] = I("嫦嘣梬汖厷", "pULkb");
      I[101 ^ 82] = I("扎", "Alamt");
      I[10 ^ 50] = I("枉", "VqwoN");
      I[157 ^ 164] = I("\u001d7(\u0003\f\u0005\"", "kVZjm");
      I[87 ^ 109] = I("5\u000f\u000e\u0004+", "FaasR");
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[170 ^ 138];
      String var10001 = I[162 ^ 131];
      String var10002 = I[176 ^ 146];
      var10001 = I[191 ^ 156];
      I[75 ^ 111].length();
      I[118 ^ 83].length();
      I[63 ^ 25].length();
      I[85 ^ 114].length();
      return new ItemStack(this, " ".length(), ((BlockDirt.DirtType)var3.getValue(VARIANT)).getMetadata());
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[1 ^ 56], BlockDirt.DirtType.class);
      SNOWY = PropertyBool.create(I[77 ^ 119]);
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return ((BlockDirt.DirtType)var1.getValue(VARIANT)).getColor();
   }

   public static enum DirtType implements IStringSerializable {
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private final MapColor color;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      COARSE_DIRT,
      // $FF: synthetic field
      DIRT,
      // $FF: synthetic field
      PODZOL;

      // $FF: synthetic field
      private final int metadata;
      // $FF: synthetic field
      private final String unlocalizedName;

      private DirtType(int var3, String var4, String var5, MapColor var6) {
         this.metadata = var3;
         this.name = var4;
         this.unlocalizedName = var5;
         this.color = var6;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 != -1);

         throw null;
      }

      static {
         I();
         DIRT = new BlockDirt.DirtType(I["".length()], "".length(), "".length(), I[" ".length()], I["  ".length()], MapColor.DIRT);
         COARSE_DIRT = new BlockDirt.DirtType(I["   ".length()], " ".length(), " ".length(), I[114 ^ 118], I[32 ^ 37], MapColor.DIRT);
         PODZOL = new BlockDirt.DirtType(I[107 ^ 109], "  ".length(), "  ".length(), I[131 ^ 132], MapColor.OBSIDIAN);
         BlockDirt.DirtType[] var10000 = new BlockDirt.DirtType["   ".length()];
         var10000["".length()] = DIRT;
         var10000[" ".length()] = COARSE_DIRT;
         var10000["  ".length()] = PODZOL;
         BlockDirt.DirtType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockDirt.DirtType var3 = var0[var2];
            METADATA_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(1 > 0);

         throw null;
      }

      private DirtType(int var3, String var4, MapColor var5) {
         this(var3, var4, var4, var5);
      }

      public String getName() {
         return this.name;
      }

      public String toString() {
         return this.name;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      public int getMetadata() {
         return this.metadata;
      }

      public static BlockDirt.DirtType byMetadata(int var0) {
         if (var0 < 0 || var0 >= METADATA_LOOKUP.length) {
            var0 = "".length();
         }

         return METADATA_LOOKUP[var0];
      }

      public MapColor getColor() {
         return this.color;
      }

      private static void I() {
         I = new String[121 ^ 113];
         I["".length()] = I("\u000b'4\u0001", "OnfUM");
         I[" ".length()] = I("5\u0002\u00178", "QkeLc");
         I["  ".length()] = I(")!\u0007\b:!0", "MDaiO");
         I["   ".length()] = I(".\u001c\u001b\"2(\f\u001e939", "mSZpa");
         I[38 ^ 34] = I("'\u00047\u001e\u0002!42\u0005\u00030", "DkVlq");
         I[60 ^ 57] = I("6+ \u001c#0", "UDAnP");
         I[28 ^ 26] = I("\u0007\u0018\u000f28\u001b", "WWKhw");
         I[182 ^ 177] = I("#\u0001/1\u0019?", "SnKKv");
      }
   }
}

package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockBreakable extends Block {
   // $FF: synthetic field
   private final boolean ignoreSimilarity;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 1);

      throw null;
   }

   protected BlockBreakable(Material var1, boolean var2) {
      this(var1, var2, var1.getMaterialMapColor());
   }

   protected BlockBreakable(Material var1, boolean var2, MapColor var3) {
      super(var1, var3);
      this.ignoreSimilarity = var2;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      IBlockState var5 = var2.getBlockState(var3.offset(var4));
      Block var6 = var5.getBlock();
      if (this == Blocks.GLASS || this == Blocks.STAINED_GLASS) {
         if (var1 != var5) {
            return (boolean)" ".length();
         }

         if (var6 == this) {
            return (boolean)"".length();
         }
      }

      int var10000;
      if (!this.ignoreSimilarity && var6 == this) {
         var10000 = "".length();
         "".length();
         if (4 < 1) {
            throw null;
         }
      } else {
         var10000 = super.shouldSideBeRendered(var1, var2, var3, var4);
      }

      return (boolean)var10000;
   }
}

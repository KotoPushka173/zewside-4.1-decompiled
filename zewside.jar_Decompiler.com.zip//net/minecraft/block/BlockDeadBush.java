package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockDeadBush extends BlockBush {
   // $FF: synthetic field
   protected static final AxisAlignedBB DEAD_BUSH_AABB;
   // $FF: synthetic field
   private static final String[] I;

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.STICK;
   }

   protected BlockDeadBush() {
      super(Material.VINE);
   }

   public int quantityDropped(Random var1) {
      return var1.nextInt("   ".length());
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.WOOD;
   }

   protected boolean canSustainBush(IBlockState var1) {
      int var10000;
      if (var1.getBlock() != Blocks.SAND && var1.getBlock() != Blocks.HARDENED_CLAY && var1.getBlock() != Blocks.STAINED_HARDENED_CLAY && var1.getBlock() != Blocks.DIRT) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return DEAD_BUSH_AABB;
   }

   private static void I() {
      I = new String[187 ^ 179];
      I["".length()] = I("娧堪", "vYdUl");
      I[" ".length()] = I("呔擶", "IVCQH");
      I["  ".length()] = I("峂瀊", "aokjX");
      I["   ".length()] = I("旻厖", "EihaI");
      I[51 ^ 55] = I("楙惭區滀俐", "dbbwu");
      I[70 ^ 67] = I("嬪汖炌曯", "xIaNM");
      I[141 ^ 139] = I("俎劧", "YXfID");
      I[97 ^ 102] = I("亍", "EKYTE");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 1);

      throw null;
   }

   public boolean isReplaceable(IBlockAccess var1, BlockPos var2) {
      return (boolean)" ".length();
   }

   static {
      I();
      DEAD_BUSH_AABB = new AxisAlignedBB(0.09999999403953552D, 0.0D, 0.09999999403953552D, 0.8999999761581421D, 0.800000011920929D, 0.8999999761581421D);
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (!var1.isRemote && var6.getItem() == Items.SHEARS) {
         var2.addStat(StatList.getBlockStats(this));
         I[124 ^ 120].length();
         I[37 ^ 32].length();
         I[170 ^ 172].length();
         I[176 ^ 183].length();
         spawnAsEntity(var1, var3, new ItemStack(Blocks.DEADBUSH, " ".length(), "".length()));
         "".length();
         if (4 <= 0) {
            throw null;
         }
      } else {
         super.harvestBlock(var1, var2, var3, var4, var5, var6);
      }

   }
}

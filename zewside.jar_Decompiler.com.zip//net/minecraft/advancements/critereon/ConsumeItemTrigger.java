package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class ConsumeItemTrigger implements ICriterionTrigger<ConsumeItemTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_193149_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, ConsumeItemTrigger.Listeners> field_193150_b = Maps.newHashMap();

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 1);

      throw null;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<ConsumeItemTrigger.Instance> var2) {
      ConsumeItemTrigger.Listeners var3 = (ConsumeItemTrigger.Listeners)this.field_193150_b.get(var1);
      if (var3 != null) {
         var3.func_193237_b(var2);
         if (var3.func_193238_a()) {
            this.field_193150_b.remove(var1);
            I[170 ^ 161].length();
            I[139 ^ 135].length();
            I[202 ^ 199].length();
         }
      }

   }

   public ConsumeItemTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[119 ^ 103];
      String var10001 = I[15 ^ 30];
      String var10002 = I[189 ^ 175];
      var10001 = I[2 ^ 17];
      ItemPredicate var3 = ItemPredicate.func_192492_a(var1.get(I[150 ^ 130]));
      I[147 ^ 134].length();
      I[53 ^ 35].length();
      return new ConsumeItemTrigger.Instance(var3);
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<ConsumeItemTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      ConsumeItemTrigger.Listeners var3 = (ConsumeItemTrigger.Listeners)this.field_193150_b.get(var1);
      if (var3 == null) {
         I[105 ^ 109].length();
         I[13 ^ 8].length();
         I[133 ^ 131].length();
         I[112 ^ 119].length();
         I[23 ^ 31].length();
         var3 = new ConsumeItemTrigger.Listeners(var1);
         this.field_193150_b.put(var1, var3);
         I[32 ^ 41].length();
         I[7 ^ 13].length();
      }

      var3.func_193239_a(var2);
   }

   public void func_193148_a(EntityPlayerMP var1, ItemStack var2) {
      ConsumeItemTrigger.Listeners var3 = (ConsumeItemTrigger.Listeners)this.field_193150_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_193240_a(var2);
      }

   }

   private static void I() {
      I = new String[102 ^ 126];
      I["".length()] = I("捷搒", "CAmhJ");
      I[" ".length()] = I("榷奤", "Vvlaj");
      I["  ".length()] = I("慜俍", "UKMnj");
      I["   ".length()] = I("壖厝", "BaDyR");
      I[10 ^ 14] = I("估滤埢埉仱", "sBKmx");
      I[169 ^ 172] = I("忲梆棻", "RtDrk");
      I[185 ^ 191] = I("檨", "YtQXS");
      I[96 ^ 103] = I("枪撺", "aOcTT");
      I[58 ^ 50] = I("模厴昅況嚯", "pYYWm");
      I[159 ^ 150] = I("員", "doYsi");
      I[59 ^ 49] = I("恖曙暼弃", "CjHyW");
      I[89 ^ 82] = I("事敖撬檰徖", "MQGKD");
      I[183 ^ 187] = I("喢灶太婏", "EElEe");
      I[1 ^ 12] = I("奅幧柿尀嫳", "BzjAK");
      I[167 ^ 169] = I("壈媠参歘比", "wbyKb");
      I[13 ^ 2] = I("淐婖漲徬", "otAPf");
      I[189 ^ 173] = I("桗庣", "TIFbU");
      I[82 ^ 67] = I("嫤擵", "VdLLf");
      I[211 ^ 193] = I("嚠岬", "vEbSb");
      I[104 ^ 123] = I("汩愺", "AAHlQ");
      I[106 ^ 126] = I("\u0000'\u001c\f", "iSyaP");
      I[163 ^ 182] = I("佷", "WEcGh");
      I[166 ^ 176] = I("減", "tigQX");
      I[134 ^ 145] = I(" \u0000/\"%.\n\u001e8$&\u0002", "CoAQP");
   }

   public ResourceLocation func_192163_a() {
      return field_193149_a;
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193150_b.remove(var1);
      I[83 ^ 93].length();
      I[125 ^ 114].length();
   }

   static {
      I();
      field_193149_a = new ResourceLocation(I[126 ^ 105]);
   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<ConsumeItemTrigger.Instance>> field_193242_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_193241_a;
      // $FF: synthetic field
      private static final String[] I;

      public void func_193239_a(ICriterionTrigger.Listener<ConsumeItemTrigger.Instance> var1) {
         this.field_193242_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      public void func_193240_a(ItemStack var1) {
         ArrayList var2 = null;
         Iterator var3 = this.field_193242_b.iterator();

         ICriterionTrigger.Listener var4;
         while(var3.hasNext()) {
            var4 = (ICriterionTrigger.Listener)var3.next();
            if (((ConsumeItemTrigger.Instance)var4.func_192158_a()).func_193193_a(var1)) {
               if (var2 == null) {
                  var2 = Lists.newArrayList();
               }

               var2.add(var4);
               I["   ".length()].length();
               I[130 ^ 134].length();
            }

            "".length();
            if (-1 != -1) {
               throw null;
            }
         }

         if (var2 != null) {
            var3 = var2.iterator();

            while(var3.hasNext()) {
               var4 = (ICriterionTrigger.Listener)var3.next();
               var4.func_192159_a(this.field_193241_a);
               "".length();
               if (3 <= -1) {
                  throw null;
               }
            }
         }

      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 == 4);

         throw null;
      }

      public void func_193237_b(ICriterionTrigger.Listener<ConsumeItemTrigger.Instance> var1) {
         this.field_193242_b.remove(var1);
         I["  ".length()].length();
      }

      public boolean func_193238_a() {
         return this.field_193242_b.isEmpty();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193241_a = var1;
      }

      private static void I() {
         I = new String[18 ^ 23];
         I["".length()] = I("懇帯", "psnIc");
         I[" ".length()] = I("敖", "vHSFH");
         I["  ".length()] = I("澔季", "SszZd");
         I["   ".length()] = I("巬擶勶傮掤", "wMbrf");
         I[32 ^ 36] = I("檒歬漓巟嵰", "jznSM");
      }

      static {
         I();
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final ItemPredicate field_193194_a;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= 2);

         throw null;
      }

      public boolean func_193193_a(ItemStack var1) {
         return this.field_193194_a.func_192493_a(var1);
      }

      public Instance(ItemPredicate var1) {
         super(ConsumeItemTrigger.field_193149_a);
         this.field_193194_a = var1;
      }
   }
}

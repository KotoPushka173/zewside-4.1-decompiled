package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentKnockback extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public int getMaxLevel() {
      return "  ".length();
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I(".\u0003\u001e*.'\f\u0012\"", "EmqIE");
      I[" ".length()] = I("渜懭嵨哯椠", "ZdfNC");
      I["  ".length()] = I("吽欩", "KrXFw");
   }

   public int getMinEnchantability(int var1) {
      int var10000 = 182 ^ 179;
      int var10001 = 92 ^ 72;
      int var10003 = " ".length();
      I[" ".length()].length();
      I["  ".length()].length();
      return var10000 + var10001 * (var1 - var10003);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 3);

      throw null;
   }

   public int getMaxEnchantability(int var1) {
      return super.getMinEnchantability(var1) + (77 ^ 127);
   }

   protected EnchantmentKnockback(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.WEAPON, var2);
      this.setName(I["".length()]);
   }
}

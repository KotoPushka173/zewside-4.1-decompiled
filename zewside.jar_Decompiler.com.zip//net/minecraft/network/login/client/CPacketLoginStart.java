package net.minecraft.network.login.client;

import com.mojang.authlib.GameProfile;
import java.io.IOException;
import java.util.UUID;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.login.INetHandlerLoginServer;

public class CPacketLoginStart implements Packet<INetHandlerLoginServer> {
   // $FF: synthetic field
   private GameProfile profile;
   // $FF: synthetic field
   private static final String[] I;

   public GameProfile getProfile() {
      return this.profile;
   }

   public CPacketLoginStart() {
   }

   static {
      I();
   }

   private static void I() {
      I = new String[90 ^ 81];
      I["".length()] = I("析戽", "Vifby");
      I[" ".length()] = I("扪弉", "XqdLn");
      I["  ".length()] = I("汮婃", "GHbeu");
      I["   ".length()] = I("殸岷", "jNSpz");
      I[162 ^ 166] = I("伩刀嬞囇", "HnNzw");
      I[179 ^ 182] = I("晸冲椊", "ecgis");
      I[197 ^ 195] = I("楰媥", "ojCYw");
      I[80 ^ 87] = I("扐", "nFaJV");
      I[113 ^ 121] = I("彭栶城湿娢", "LoTmb");
      I[97 ^ 104] = I("炽倽楽巺槀", "uozrP");
      I[126 ^ 116] = I("勝揰庶烼咽", "DcUqf");
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.profile.getName());
      I[161 ^ 167].length();
      I[71 ^ 64].length();
      I[179 ^ 187].length();
      I[191 ^ 182].length();
      I[2 ^ 8].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[108 ^ 104].length();
      I[126 ^ 123].length();
      this.profile = new GameProfile((UUID)null, var1.readStringFromBuffer(111 ^ 127));
   }

   public CPacketLoginStart(GameProfile var1) {
      this.profile = var1;
   }

   public void processPacket(INetHandlerLoginServer var1) {
      var1.processLoginStart(this);
   }
}

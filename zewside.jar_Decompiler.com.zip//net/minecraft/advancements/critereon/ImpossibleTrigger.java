package net.minecraft.advancements.critereon;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.util.ResourceLocation;

public class ImpossibleTrigger implements ICriterionTrigger<ImpossibleTrigger.Instance> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final ResourceLocation field_192205_a;

   public ResourceLocation func_192163_a() {
      return field_192205_a;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<ImpossibleTrigger.Instance> var2) {
   }

   public void func_192167_a(PlayerAdvancements var1) {
   }

   public ImpossibleTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[169 ^ 173].length();
      I[23 ^ 18].length();
      I[162 ^ 164].length();
      return new ImpossibleTrigger.Instance();
   }

   static {
      I();
      field_192205_a = new ResourceLocation(I[159 ^ 152]);
   }

   private static void I() {
      I = new String[44 ^ 36];
      I["".length()] = I("敕厮", "wsBDt");
      I[" ".length()] = I("尫掠", "CQvdT");
      I["  ".length()] = I("凫嶤", "EWmvv");
      I["   ".length()] = I("毐灣", "IUgOy");
      I[99 ^ 103] = I("啭嗆仌", "isSgf");
      I[157 ^ 152] = I("局桹亀", "AedVM");
      I[60 ^ 58] = I("径標", "sdMnQ");
      I[172 ^ 171] = I("#\u00002,\n9\u0004 /\u001c", "JmBCy");
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<ImpossibleTrigger.Instance> var2) {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 2);

      throw null;
   }

   public static class Instance extends AbstractCriterionInstance {
      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > 0);

         throw null;
      }

      public Instance() {
         super(ImpossibleTrigger.field_192205_a);
      }
   }
}

package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;

public class NetherTravelTrigger implements ICriterionTrigger<NetherTravelTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_193169_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, NetherTravelTrigger.Listeners> field_193170_b = Maps.newHashMap();

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<NetherTravelTrigger.Instance> var2) {
      NetherTravelTrigger.Listeners var3 = (NetherTravelTrigger.Listeners)this.field_193170_b.get(var1);
      if (var3 != null) {
         var3.func_193481_b(var2);
         if (var3.func_193482_a()) {
            this.field_193170_b.remove(var1);
            I[35 ^ 36].length();
            I[11 ^ 3].length();
            I[38 ^ 47].length();
            I[146 ^ 152].length();
         }
      }

   }

   public void func_193168_a(EntityPlayerMP var1, Vec3d var2) {
      NetherTravelTrigger.Listeners var3 = (NetherTravelTrigger.Listeners)this.field_193170_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_193483_a(var1.getServerWorld(), var2, var1.posX, var1.posY, var1.posZ);
      }

   }

   private static void I() {
      I = new String[149 ^ 130];
      I["".length()] = I("坰塤", "rgMVg");
      I[" ".length()] = I("涯墭", "kJgGW");
      I["  ".length()] = I("媹劮", "VpTdg");
      I["   ".length()] = I("摌娨", "DKJGy");
      I[75 ^ 79] = I("榈", "SRCVp");
      I[104 ^ 109] = I("摨", "wBLdJ");
      I[147 ^ 149] = I("劏叛晹杹", "GLfwM");
      I[33 ^ 38] = I("然揢幒彮", "wlNam");
      I[118 ^ 126] = I("烧党剗侬室", "ZYvrV");
      I[53 ^ 60] = I("溤墬峢庴劔", "PNrCl");
      I[206 ^ 196] = I("傽歀夥偁亨", "RDJrF");
      I[8 ^ 3] = I("徠", "IdVDc");
      I[201 ^ 197] = I("哙嶅炼", "WxSqg");
      I[152 ^ 149] = I("俫淅", "suMHc");
      I[204 ^ 194] = I("梹滪", "hSPbx");
      I[116 ^ 123] = I("扯次", "iFrSi");
      I[130 ^ 146] = I("怨怪", "pWoiQ");
      I[11 ^ 26] = I("0\u001b$/\u00100\u0011", "UuPJb");
      I[48 ^ 34] = I("&69\u00127'", "CNPfR");
      I[40 ^ 59] = I("'*\"\u00124- 4", "CCQfU");
      I[156 ^ 136] = I("携懼", "XZYRP");
      I[39 ^ 50] = I("圦槟擹慭曭", "bmtxT");
      I[108 ^ 122] = I(":#\u001a\u0018)&\u0019\u001a\u0002-\"#\u0002", "TFnpL");
   }

   public ResourceLocation func_192163_a() {
      return field_193169_a;
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<NetherTravelTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      NetherTravelTrigger.Listeners var3 = (NetherTravelTrigger.Listeners)this.field_193170_b.get(var1);
      if (var3 == null) {
         I[151 ^ 147].length();
         I[51 ^ 54].length();
         var3 = new NetherTravelTrigger.Listeners(var1);
         this.field_193170_b.put(var1, var3);
         I[13 ^ 11].length();
      }

      var3.func_193484_a(var2);
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193170_b.remove(var1);
      I[24 ^ 19].length();
      I[99 ^ 111].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= -1);

      throw null;
   }

   static {
      I();
      field_193169_a = new ResourceLocation(I[24 ^ 14]);
   }

   public NetherTravelTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[5 ^ 8];
      String var10001 = I[1 ^ 15];
      String var10002 = I[77 ^ 66];
      var10001 = I[51 ^ 35];
      LocationPredicate var3 = LocationPredicate.func_193454_a(var1.get(I[26 ^ 11]));
      LocationPredicate var4 = LocationPredicate.func_193454_a(var1.get(I[46 ^ 60]));
      DistancePredicate var5 = DistancePredicate.func_193421_a(var1.get(I[26 ^ 9]));
      I[100 ^ 112].length();
      I[31 ^ 10].length();
      return new NetherTravelTrigger.Instance(var3, var4, var5);
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final LocationPredicate field_193207_a;
      // $FF: synthetic field
      private final LocationPredicate field_193208_b;
      // $FF: synthetic field
      private final DistancePredicate field_193209_c;

      public boolean func_193206_a(WorldServer var1, Vec3d var2, double var3, double var5, double var7) {
         if (!this.field_193207_a.func_193452_a(var1, var2.x, var2.y, var2.z)) {
            return (boolean)"".length();
         } else {
            return (boolean)(!this.field_193208_b.func_193452_a(var1, var3, var5, var7) ? "".length() : this.field_193209_c.func_193422_a(var2.x, var2.y, var2.z, var3, var5, var7));
         }
      }

      public Instance(LocationPredicate var1, LocationPredicate var2, DistancePredicate var3) {
         super(NetherTravelTrigger.field_193169_a);
         this.field_193207_a = var1;
         this.field_193208_b = var2;
         this.field_193209_c = var3;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= 1);

         throw null;
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_193485_a;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<NetherTravelTrigger.Instance>> field_193486_b = Sets.newHashSet();

      public void func_193484_a(ICriterionTrigger.Listener<NetherTravelTrigger.Instance> var1) {
         this.field_193486_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      private static void I() {
         I = new String[142 ^ 134];
         I["".length()] = I("勴", "XMUzW");
         I[" ".length()] = I("廤槳", "AeXfj");
         I["  ".length()] = I("堅幔", "iNUIQ");
         I["   ".length()] = I("泻瀲家汛檜", "RUtij");
         I[54 ^ 50] = I("仍嶐", "ltLcZ");
         I[163 ^ 166] = I("孜", "HLViw");
         I[61 ^ 59] = I("涧捘滋", "MDHwD");
         I[177 ^ 182] = I("敵冫慢", "mPWvu");
      }

      static {
         I();
      }

      public boolean func_193482_a() {
         return this.field_193486_b.isEmpty();
      }

      public void func_193481_b(ICriterionTrigger.Listener<NetherTravelTrigger.Instance> var1) {
         this.field_193486_b.remove(var1);
         I["  ".length()].length();
         I["   ".length()].length();
         I[151 ^ 147].length();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 < 3);

         throw null;
      }

      public void func_193483_a(WorldServer var1, Vec3d var2, double var3, double var5, double var7) {
         ArrayList var9 = null;
         Iterator var10 = this.field_193486_b.iterator();

         ICriterionTrigger.Listener var11;
         while(var10.hasNext()) {
            var11 = (ICriterionTrigger.Listener)var10.next();
            if (((NetherTravelTrigger.Instance)var11.func_192158_a()).func_193206_a(var1, var2, var3, var5, var7)) {
               if (var9 == null) {
                  var9 = Lists.newArrayList();
               }

               var9.add(var11);
               I[193 ^ 196].length();
               I[173 ^ 171].length();
               I[24 ^ 31].length();
            }

            "".length();
            if (false) {
               throw null;
            }
         }

         if (var9 != null) {
            var10 = var9.iterator();

            while(var10.hasNext()) {
               var11 = (ICriterionTrigger.Listener)var10.next();
               var11.func_192159_a(this.field_193485_a);
               "".length();
               if (false) {
                  throw null;
               }
            }
         }

      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193485_a = var1;
      }
   }
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockBeetroot extends BlockCrops {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final AxisAlignedBB[] BEETROOT_AABB;
   // $FF: synthetic field
   public static final PropertyInteger BEETROOT_AGE;

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (var4.nextInt("   ".length()) == 0) {
         this.checkAndDropBlock(var1, var2, var3);
         "".length();
         if (false) {
            throw null;
         }
      } else {
         super.updateTick(var1, var2, var3, var4);
      }

   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[13 ^ 9];
      var10001 = I[198 ^ 195];
      var10002 = I[118 ^ 112];
      var10001 = I[154 ^ 157];
      I[200 ^ 192].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[8 ^ 1].length();
      I[161 ^ 171].length();
      I[106 ^ 97].length();
      var10003["".length()] = BEETROOT_AGE;
      return new BlockStateContainer(this, var10003);
   }

   static {
      I();
      BEETROOT_AGE = PropertyInteger.create(I[185 ^ 181], "".length(), "   ".length());
      AxisAlignedBB[] var10000 = new AxisAlignedBB[169 ^ 173];
      var10000["".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.125D, 1.0D);
      var10000[" ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.25D, 1.0D);
      var10000["  ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.375D, 1.0D);
      var10000["   ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
      BEETROOT_AABB = var10000;
   }

   public int getMaxAge() {
      return "   ".length();
   }

   private static void I() {
      I = new String[95 ^ 82];
      I["".length()] = I("噱叔", "HvSzS");
      I[" ".length()] = I("嵰伄", "EIeRg");
      I["  ".length()] = I("挨枡", "axBOc");
      I["   ".length()] = I("寂嘂", "HiryG");
      I[52 ^ 48] = I("備伡", "dflni");
      I[34 ^ 39] = I("摂慒", "fBXTv");
      I[133 ^ 131] = I("楬嘝", "DErhw");
      I[79 ^ 72] = I("櫐拆", "mgdpE");
      I[43 ^ 35] = I("壖", "zynnL");
      I[25 ^ 16] = I("剓廾嫲晔", "JGisE");
      I[103 ^ 109] = I("涄", "CyeZB");
      I[46 ^ 37] = I("滛氀", "RPewW");
      I[92 ^ 80] = I("\u0019\u0001\u001c", "xfyZx");
   }

   protected int getBonemealAgeIncrease(World var1) {
      return super.getBonemealAgeIncrease(var1) / "   ".length();
   }

   protected PropertyInteger getAgeProperty() {
      return BEETROOT_AGE;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return BEETROOT_AABB[(Integer)var1.getValue(this.getAgeProperty())];
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   protected Item getCrop() {
      return Items.BEETROOT;
   }

   protected Item getSeed() {
      return Items.BEETROOT_SEEDS;
   }
}

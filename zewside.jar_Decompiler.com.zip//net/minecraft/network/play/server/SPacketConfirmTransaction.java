package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketConfirmTransaction implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private boolean accepted;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private short actionNumber;
   // $FF: synthetic field
   private int windowId;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != 4);

      throw null;
   }

   public SPacketConfirmTransaction() {
   }

   public SPacketConfirmTransaction(int var1, short var2, boolean var3) {
      this.windowId = var1;
      this.actionNumber = var2;
      this.accepted = var3;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleConfirmTransaction(this);
   }

   public boolean wasAccepted() {
      return this.accepted;
   }

   private static void I() {
      I = new String[94 ^ 86];
      I["".length()] = I("儩北亄柸", "DEXbL");
      I[" ".length()] = I("庋嘞樾拷傉", "JTHBx");
      I["  ".length()] = I("垛嶋滿搦", "Bxjld");
      I["   ".length()] = I("掶", "IXoOB");
      I[96 ^ 100] = I("愤卯", "RggAK");
      I[166 ^ 163] = I("權嗚", "xPNht");
      I[71 ^ 65] = I("勷沫", "BAArU");
      I[90 ^ 93] = I("嵄必叭咾剁", "HDdEt");
   }

   public short getActionNumber() {
      return this.actionNumber;
   }

   static {
      I();
   }

   public int getWindowId() {
      return this.windowId;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.windowId = var1.readUnsignedByte();
      this.actionNumber = var1.readShort();
      this.accepted = var1.readBoolean();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.windowId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeShort(this.actionNumber);
      I[132 ^ 128].length();
      I[143 ^ 138].length();
      I[182 ^ 176].length();
      var1.writeBoolean(this.accepted);
      I[63 ^ 56].length();
   }
}

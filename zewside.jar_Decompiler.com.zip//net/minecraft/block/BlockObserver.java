package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockObserver extends BlockDirectional {
   // $FF: synthetic field
   public static final PropertyBool field_190963_a;
   // $FF: synthetic field
   private static final String[] I;

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.getFront(var1 & (111 ^ 104)));
   }

   private static void I() {
      I = new String[140 ^ 150];
      I["".length()] = I("望伉", "SYjMd");
      I[" ".length()] = I("搰凍", "qFJqU");
      I["  ".length()] = I("毞姡", "tZGIj");
      I["   ".length()] = I("发溉", "Mggqz");
      I[160 ^ 164] = I("哢劎", "wuJJk");
      I[103 ^ 98] = I("棖墂", "IjoxZ");
      I[122 ^ 124] = I("湌侃", "OZBqM");
      I[62 ^ 57] = I("涒伣", "Olqjd");
      I[158 ^ 150] = I("史榠", "ibIrf");
      I[29 ^ 20] = I("噐栱", "KPMlO");
      I[47 ^ 37] = I("煞昈", "Nnmuq");
      I[172 ^ 167] = I("嗌取", "acphj");
      I[103 ^ 107] = I("檂煣濾炲", "VuXrG");
      I[91 ^ 86] = I("橬", "ypkxq");
      I[145 ^ 159] = I("掆嚉", "TecnX");
      I[75 ^ 68] = I("灊惍匚懫夒", "OrXBB");
      I[173 ^ 189] = I("梁尦嚫", "WVxRd");
      I[163 ^ 178] = I("擆偣柂欀", "CCzxI");
      I[46 ^ 60] = I("兛惸", "KareM");
      I[41 ^ 58] = I("剅寤悳", "EQRVO");
      I[88 ^ 76] = I("勠婏必挵", "QgNjY");
      I[74 ^ 95] = I("樳掘悂", "yqBIW");
      I[170 ^ 188] = I("湇楀", "XQtly");
      I[143 ^ 152] = I("洺烷丏懡", "QNMiq");
      I[216 ^ 192] = I("奡歅忌", "RdEcs");
      I[151 ^ 142] = I("\u0016\u0016\u001e\u001c\u0018\u0003\u001d", "fyiyj");
   }

   static {
      I();
      field_190963_a = PropertyBool.create(I[64 ^ 89]);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
   }

   protected void func_190961_e(World var1, BlockPos var2, IBlockState var3) {
      EnumFacing var4 = (EnumFacing)var3.getValue(FACING);
      BlockPos var5 = var2.offset(var4.getOpposite());
      var1.func_190524_a(var5, this, var2);
      var1.notifyNeighborsOfStateExcept(var5, this, var4);
   }

   public BlockObserver() {
      super(Material.ROCK);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.SOUTH).withProperty(field_190963_a, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.REDSTONE);
   }

   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return var1.getWeakPower(var2, var3, var4);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public boolean canProvidePower(IBlockState var1) {
      return (boolean)" ".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != 4);

      throw null;
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      if ((Boolean)var3.getValue(field_190963_a) && var1.isUpdateScheduled(var2, this)) {
         this.func_190961_e(var1, var2, var3.withProperty(field_190963_a, Boolean.valueOf((boolean)"".length())));
      }

   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[42 ^ 46];
      var10001 = I[139 ^ 142];
      var10002 = I[53 ^ 51];
      var10001 = I[2 ^ 5];
      var10000 = I[45 ^ 37];
      var10001 = I[87 ^ 94];
      var10002 = I[80 ^ 90];
      var10001 = I[121 ^ 114];
      I[177 ^ 189].length();
      I[140 ^ 129].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[99 ^ 109].length();
      I[87 ^ 88].length();
      I[173 ^ 189].length();
      var10003["".length()] = FACING;
      I[55 ^ 38].length();
      I[183 ^ 165].length();
      I[76 ^ 95].length();
      I[15 ^ 27].length();
      var10003[" ".length()] = field_190963_a;
      return new BlockStateContainer(this, var10003);
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getIndex();
      if ((Boolean)var1.getValue(field_190963_a)) {
         var2 |= 87 ^ 95;
      }

      return var2;
   }

   public void func_190962_b(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote && var3.offset((EnumFacing)var1.getValue(FACING)).equals(var5)) {
         this.func_190960_d(var1, var2, var3);
      }

   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if ((Boolean)var3.getValue(field_190963_a)) {
         var1.setBlockState(var2, var3.withProperty(field_190963_a, Boolean.valueOf((boolean)"".length())), "  ".length());
         I[177 ^ 164].length();
         "".length();
         if (-1 == 3) {
            throw null;
         }
      } else {
         var1.setBlockState(var2, var3.withProperty(field_190963_a, Boolean.valueOf((boolean)" ".length())), "  ".length());
         I[47 ^ 57].length();
         I[73 ^ 94].length();
         I[110 ^ 118].length();
         var1.scheduleUpdate(var2, this, "  ".length());
      }

      this.func_190961_e(var1, var2, var3);
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.func_190914_a(var2, var8).getOpposite());
   }

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if ((Boolean)var1.getValue(field_190963_a) && var1.getValue(FACING) == var4) {
         var10000 = 21 ^ 26;
         "".length();
         if (3 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   private void func_190960_d(IBlockState var1, World var2, BlockPos var3) {
      if (!(Boolean)var1.getValue(field_190963_a) && !var2.isUpdateScheduled(var3, this)) {
         var2.scheduleUpdate(var3, this, "  ".length());
      }

   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         if ((Boolean)var3.getValue(field_190963_a)) {
            this.updateTick(var1, var2, var3, var1.rand);
         }

         this.func_190960_d(var3, var1, var2);
      }

   }
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockFalling extends Block {
   // $FF: synthetic field
   public static boolean fallInstantly;
   // $FF: synthetic field
   private static final String[] I;

   public void onEndFalling(World var1, BlockPos var2, IBlockState var3, IBlockState var4) {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 0);

      throw null;
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      var1.scheduleUpdate(var2, this, this.tickRate(var1));
   }

   public int tickRate(World var1) {
      return "  ".length();
   }

   public BlockFalling(Material var1) {
      super(var1);
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      String var10000 = I[13 ^ 28];
      String var10001 = I[58 ^ 40];
      String var10002 = I[136 ^ 155];
      var10001 = I[22 ^ 2];
      if (var4.nextInt(158 ^ 142) == 0) {
         BlockPos var5 = var3.down();
         if (canFallThrough(var2.getBlockState(var5))) {
            double var6 = (double)((float)var3.getX() + var4.nextFloat());
            double var12 = (double)var3.getY();
            I[51 ^ 38].length();
            I[72 ^ 94].length();
            double var8 = var12 - 0.05D;
            double var10 = (double)((float)var3.getZ() + var4.nextFloat());
            EnumParticleTypes var13 = EnumParticleTypes.FALLING_DUST;
            int[] var10008 = new int[" ".length()];
            I[107 ^ 124].length();
            var10008["".length()] = Block.getStateId(var1);
            var2.spawnParticle(var13, var6, var8, var10, 0.0D, 0.0D, 0.0D, var10008);
         }
      }

   }

   private static void I() {
      I = new String[16 ^ 8];
      I["".length()] = I("伛义", "GgkAP");
      I[" ".length()] = I("满曑", "SOoXV");
      I["  ".length()] = I("楿凾", "xIXem");
      I["   ".length()] = I("曔曼", "hNpLZ");
      I[36 ^ 32] = I("兙", "JJDRf");
      I[151 ^ 146] = I("涟斿樅", "uLhuo");
      I[183 ^ 177] = I("尒洫幝", "SzaqB");
      I[146 ^ 149] = I("斵", "SMIRb");
      I[70 ^ 78] = I("柞", "ssuvj");
      I[146 ^ 155] = I("揨劤劈懮檯", "qWlqb");
      I[43 ^ 33] = I("偞滼啡榫", "QsaJb");
      I[10 ^ 1] = I("朁敱噏柠", "cPZyx");
      I[130 ^ 142] = I("嬕劤柡", "RLmAq");
      I[175 ^ 162] = I("戼瀾帉嶅", "hOqmH");
      I[171 ^ 165] = I("恋枩宄泍", "XoIni");
      I[19 ^ 28] = I("搰堎撤旕", "JiNnw");
      I[3 ^ 19] = I("匟", "wIrmK");
      I[42 ^ 59] = I("浑厘", "Atskr");
      I[27 ^ 9] = I("亹冠", "GawqQ");
      I[116 ^ 103] = I("崠嵆", "aolJk");
      I[174 ^ 186] = I("侾杒", "BHSkz");
      I[32 ^ 53] = I("冦忞先惓", "tPujK");
      I[89 ^ 79] = I("斘垀", "kvjgz");
      I[132 ^ 147] = I("攩栂", "MhuIo");
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote) {
         this.checkFallable(var1, var2);
      }

   }

   public void func_190974_b(World var1, BlockPos var2) {
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      var2.scheduleUpdate(var3, this, this.tickRate(var2));
   }

   static {
      I();
   }

   private void checkFallable(World var1, BlockPos var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (canFallThrough(var1.getBlockState(var2.down())) && var2.getY() >= 0) {
         int var3 = 87 ^ 119;
         if (!fallInstantly && var1.isAreaLoaded(var2.add(-(126 ^ 94), -(106 ^ 74), -(75 ^ 107)), var2.add(184 ^ 152, 48 ^ 16, 85 ^ 117))) {
            if (!var1.isRemote) {
               I[172 ^ 168].length();
               I[167 ^ 162].length();
               I[94 ^ 88].length();
               I[177 ^ 182].length();
               I[73 ^ 65].length();
               EntityFallingBlock var5 = new EntityFallingBlock(var1, (double)var2.getX() + 0.5D, (double)var2.getY(), (double)var2.getZ() + 0.5D, var1.getBlockState(var2));
               this.onStartFalling(var5);
               var1.spawnEntityInWorld(var5);
               I[178 ^ 187].length();
               I[131 ^ 137].length();
               I[62 ^ 53].length();
               I[42 ^ 38].length();
               "".length();
               if (4 <= 1) {
                  throw null;
               }
            }
         } else {
            var1.setBlockToAir(var2);
            I[78 ^ 67].length();
            I[41 ^ 39].length();
            BlockPos var4 = var2.down();

            while(canFallThrough(var1.getBlockState(var4)) && var4.getY() > 0) {
               var4 = var4.down();
               "".length();
               if (0 >= 2) {
                  throw null;
               }
            }

            if (var4.getY() > 0) {
               var1.setBlockState(var4.up(), this.getDefaultState());
               I[127 ^ 112].length();
               I[8 ^ 24].length();
            }
         }
      }

   }

   public static boolean canFallThrough(IBlockState var0) {
      Block var1 = var0.getBlock();
      Material var2 = var0.getMaterial();
      int var10000;
      if (var1 != Blocks.FIRE && var2 != Material.AIR && var2 != Material.WATER && var2 != Material.LAVA) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (0 <= -1) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public int getDustColor(IBlockState var1) {
      return -(13703128 + 777699 - 5020150 + 7316539);
   }

   protected void onStartFalling(EntityFallingBlock var1) {
   }

   public BlockFalling() {
      super(Material.SAND);
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }
}

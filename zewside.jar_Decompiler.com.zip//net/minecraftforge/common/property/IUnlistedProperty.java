package net.minecraftforge.common.property;

public interface IUnlistedProperty<V> {
   boolean isValid(V var1);

   Class<V> getType();

   String getName();

   String valueToString(V var1);
}

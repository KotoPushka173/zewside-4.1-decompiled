package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class InventoryChangeTrigger implements ICriterionTrigger<InventoryChangeTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_192209_a;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, InventoryChangeTrigger.Listeners> field_192210_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192210_b.remove(var1);
      I[64 ^ 73].length();
   }

   static {
      I();
      field_192209_a = new ResourceLocation(I[65 ^ 90]);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 4);

      throw null;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<InventoryChangeTrigger.Instance> var2) {
      InventoryChangeTrigger.Listeners var3 = (InventoryChangeTrigger.Listeners)this.field_192210_b.get(var1);
      if (var3 != null) {
         var3.func_192487_b(var2);
         if (var3.func_192488_a()) {
            this.field_192210_b.remove(var1);
            I[155 ^ 157].length();
            I[30 ^ 25].length();
            I[110 ^ 102].length();
         }
      }

   }

   public void func_192208_a(EntityPlayerMP var1, InventoryPlayer var2) {
      InventoryChangeTrigger.Listeners var3 = (InventoryChangeTrigger.Listeners)this.field_192210_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_192486_a(var2);
      }

   }

   public InventoryChangeTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[18 ^ 24];
      String var10001 = I[141 ^ 134];
      String var10002 = I[179 ^ 191];
      var10001 = I[146 ^ 159];
      var10000 = I[21 ^ 27];
      var10001 = I[139 ^ 132];
      var10002 = I[94 ^ 78];
      var10001 = I[214 ^ 199];
      var10001 = I[108 ^ 126];
      I[27 ^ 8].length();
      I[54 ^ 34].length();
      JsonObject var3 = JsonUtils.getJsonObject(var1, var10001, new JsonObject());
      MinMaxBounds var4 = MinMaxBounds.func_192515_a(var3.get(I[49 ^ 36]));
      MinMaxBounds var5 = MinMaxBounds.func_192515_a(var3.get(I[31 ^ 9]));
      MinMaxBounds var6 = MinMaxBounds.func_192515_a(var3.get(I[75 ^ 92]));
      ItemPredicate[] var7 = ItemPredicate.func_192494_b(var1.get(I[168 ^ 176]));
      I[106 ^ 115].length();
      I[78 ^ 84].length();
      return new InventoryChangeTrigger.Instance(var4, var5, var6, var7);
   }

   public ResourceLocation func_192163_a() {
      return field_192209_a;
   }

   private static void I() {
      I = new String[43 ^ 55];
      I["".length()] = I("炪潪", "ByTWc");
      I[" ".length()] = I("搞楒", "YRUpn");
      I["  ".length()] = I("婌惖", "NEjaC");
      I["   ".length()] = I("姝嚝", "fqrLf");
      I[163 ^ 167] = I("喵慊堲", "jvpgA");
      I[48 ^ 53] = I("沘亩得", "GGhEi");
      I[125 ^ 123] = I("冰喵樥拐戗", "EcvYn");
      I[31 ^ 24] = I("嘣", "AApIV");
      I[110 ^ 102] = I("灪國師", "UorTN");
      I[72 ^ 65] = I("拞姪嚯漛汹", "CHozc");
      I[44 ^ 38] = I("噤渉", "mtCpw");
      I[3 ^ 8] = I("傑打", "Axnyj");
      I[5 ^ 9] = I("深乡", "fDQpd");
      I[71 ^ 74] = I("柖屲", "FmSku");
      I[162 ^ 172] = I("嗂奻", "wudZB");
      I[75 ^ 68] = I("橓刔", "LXyvH");
      I[88 ^ 72] = I("摀俀", "rWCgb");
      I[120 ^ 105] = I("橡淨", "MzbON");
      I[45 ^ 63] = I("#\")#1", "PNFWB");
      I[91 ^ 72] = I("仼", "msQYA");
      I[128 ^ 148] = I("叆漨", "zxCrL");
      I[188 ^ 169] = I("\u0016\u0011\u0005\u001d?\u0010\u0017\u0002", "yrfhO");
      I[5 ^ 19] = I("\u00171+\u001b", "qDGwb");
      I[91 ^ 76] = I("\u001c*\u001c\u00104", "yGldM");
      I[86 ^ 78] = I("\u001f&\"\b\u0007", "vRGet");
      I[113 ^ 104] = I("拈嬓挣", "gGXQf");
      I[159 ^ 133] = I("振婘", "xaiwa");
      I[216 ^ 195] = I("\u0019\u0005.\u0015,\u0004\u0004*\t\u001d\u0013\u00039\u001e%\u0015\u000f", "pkXpB");
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<InventoryChangeTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      InventoryChangeTrigger.Listeners var3 = (InventoryChangeTrigger.Listeners)this.field_192210_b.get(var1);
      if (var3 == null) {
         I[133 ^ 129].length();
         var3 = new InventoryChangeTrigger.Listeners(var1);
         this.field_192210_b.put(var1, var3);
         I[100 ^ 97].length();
      }

      var3.func_192489_a(var2);
   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<InventoryChangeTrigger.Instance>> field_192491_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_192490_a;
      // $FF: synthetic field
      private static final String[] I;

      static {
         I();
      }

      public boolean func_192488_a() {
         return this.field_192491_b.isEmpty();
      }

      private static void I() {
         I = new String[145 ^ 148];
         I["".length()] = I("旴淳橝刬", "SxRVA");
         I[" ".length()] = I("崓即歨", "qAfXx");
         I["  ".length()] = I("俘亮", "gvCKu");
         I["   ".length()] = I("模恄勑侻巴", "WSiTe");
         I[198 ^ 194] = I("孃烂恱坪勿", "mIgRO");
      }

      public void func_192489_a(ICriterionTrigger.Listener<InventoryChangeTrigger.Instance> var1) {
         this.field_192491_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      public void func_192487_b(ICriterionTrigger.Listener<InventoryChangeTrigger.Instance> var1) {
         this.field_192491_b.remove(var1);
         I["  ".length()].length();
         I["   ".length()].length();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192490_a = var1;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 > 0);

         throw null;
      }

      public void func_192486_a(InventoryPlayer var1) {
         ArrayList var2 = null;
         Iterator var3 = this.field_192491_b.iterator();

         ICriterionTrigger.Listener var4;
         while(var3.hasNext()) {
            var4 = (ICriterionTrigger.Listener)var3.next();
            if (((InventoryChangeTrigger.Instance)var4.func_192158_a()).func_192265_a(var1)) {
               if (var2 == null) {
                  var2 = Lists.newArrayList();
               }

               var2.add(var4);
               I[52 ^ 48].length();
            }

            "".length();
            if (2 <= -1) {
               throw null;
            }
         }

         if (var2 != null) {
            var3 = var2.iterator();

            while(var3.hasNext()) {
               var4 = (ICriterionTrigger.Listener)var3.next();
               var4.func_192159_a(this.field_192490_a);
               "".length();
               if (1 == 2) {
                  throw null;
               }
            }
         }

      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final MinMaxBounds field_192266_a;
      // $FF: synthetic field
      private final ItemPredicate[] field_192269_d;
      // $FF: synthetic field
      private final MinMaxBounds field_192267_b;
      // $FF: synthetic field
      private final MinMaxBounds field_192268_c;

      public boolean func_192265_a(InventoryPlayer var1) {
         int var2 = "".length();
         int var3 = "".length();
         int var4 = "".length();
         ArrayList var5 = Lists.newArrayList(this.field_192269_d);
         int var6 = "".length();

         do {
            if (var6 >= var1.getSizeInventory()) {
               if (!this.field_192267_b.func_192514_a((float)var2)) {
                  return (boolean)"".length();
               }

               if (!this.field_192268_c.func_192514_a((float)var3)) {
                  return (boolean)"".length();
               }

               if (!this.field_192266_a.func_192514_a((float)var4)) {
                  return (boolean)"".length();
               }

               if (!var5.isEmpty()) {
                  return (boolean)"".length();
               }

               return (boolean)" ".length();
            }

            ItemStack var7 = var1.getStackInSlot(var6);
            if (var7.isEmpty()) {
               ++var3;
               "".length();
               if (4 <= 2) {
                  throw null;
               }
            } else {
               ++var4;
               if (var7.func_190916_E() >= var7.getMaxStackSize()) {
                  ++var2;
               }

               Iterator var8 = var5.iterator();

               while(var8.hasNext()) {
                  ItemPredicate var9 = (ItemPredicate)var8.next();
                  if (var9.func_192493_a(var7)) {
                     var8.remove();
                  }

                  "".length();
                  if (3 == 0) {
                     throw null;
                  }
               }
            }

            ++var6;
            "".length();
         } while(true);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 < 4);

         throw null;
      }

      public Instance(MinMaxBounds var1, MinMaxBounds var2, MinMaxBounds var3, ItemPredicate[] var4) {
         super(InventoryChangeTrigger.field_192209_a);
         this.field_192266_a = var1;
         this.field_192267_b = var2;
         this.field_192268_c = var3;
         this.field_192269_d = var4;
      }
   }
}

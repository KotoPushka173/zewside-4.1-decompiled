package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockSnow extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyInteger LAYERS;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] SNOW_AABB;

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      int var7 = (Integer)var1.getValue(LAYERS);
      int var8 = " ".length();
      I[136 ^ 140].length();
      int var4 = var7 - var8;
      float var5 = 0.125F;
      AxisAlignedBB var6 = var1.getBoundingBox(var2, var3);
      I[175 ^ 170].length();
      I[96 ^ 102].length();
      I[54 ^ 49].length();
      return new AxisAlignedBB(var6.minX, var6.minY, var6.minZ, var6.maxX, (double)((float)var4 * 0.125F), var6.maxZ);
   }

   private boolean checkAndDropBlock(World var1, BlockPos var2, IBlockState var3) {
      if (!this.canPlaceBlockAt(var1, var2)) {
         this.dropBlockAsItem(var1, var2, var3, "".length());
         var1.setBlockToAir(var2);
         I[7 ^ 13].length();
         I[148 ^ 159].length();
         I[11 ^ 7].length();
         return (boolean)"".length();
      } else {
         return (boolean)" ".length();
      }
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[9 ^ 20];
      String var10001 = I[221 ^ 195];
      String var10002 = I[218 ^ 197];
      var10001 = I[93 ^ 125];
      var10000 = I[59 ^ 26];
      var10001 = I[231 ^ 197];
      var10002 = I[1 ^ 34];
      var10001 = I[60 ^ 24];
      I[140 ^ 169].length();
      I[68 ^ 98].length();
      I[225 ^ 198].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[60 ^ 20].length();
      I[234 ^ 195].length();
      I[9 ^ 35].length();
      I[101 ^ 78].length();
      var10003["".length()] = LAYERS;
      return new BlockStateContainer(this, var10003);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      this.checkAndDropBlock(var2, var3, var1);
      I[165 ^ 173].length();
      I[33 ^ 40].length();
   }

   public boolean isFullyOpaque(IBlockState var1) {
      int var10000;
      if ((Integer)var1.getValue(LAYERS) == (89 ^ 81)) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private static void I() {
      I = new String[0 ^ 45];
      I["".length()] = I("泃囬", "DhiVA");
      I[" ".length()] = I("晴墁", "ShmJP");
      I["  ".length()] = I("巜帡", "BCuxK");
      I["   ".length()] = I("憢戀", "jWMGa");
      I[96 ^ 100] = I("枫", "RngJZ");
      I[146 ^ 151] = I("摄揮戰伦瀾", "nelyn");
      I[127 ^ 121] = I("廤", "DxfjK");
      I[91 ^ 92] = I("摟慤殻崢", "zHoLR");
      I[136 ^ 128] = I("奜峷叵", "CcnAm");
      I[201 ^ 192] = I("涽", "bgNhF");
      I[14 ^ 4] = I("吋", "azrWJ");
      I[63 ^ 52] = I("戵圔", "lNVMs");
      I[180 ^ 184] = I("散屿摓漶", "lNnOi");
      I[21 ^ 24] = I("奆嬘", "DDwAV");
      I[34 ^ 44] = I("彚喴", "bnWvL");
      I[52 ^ 59] = I("廈煐", "SgNMm");
      I[91 ^ 75] = I("渹揄", "ANuOR");
      I[64 ^ 81] = I("澺卥恝", "TxRKP");
      I[162 ^ 176] = I("潄", "EHxik");
      I[81 ^ 66] = I("渞榌嵸沏", "BfdKp");
      I[72 ^ 92] = I("冁嶯", "kOAud");
      I[121 ^ 108] = I("嵢旎", "JGByJ");
      I[134 ^ 144] = I("抵姤偎", "OeLVJ");
      I[0 ^ 23] = I("梵傦恡寵唙", "aIyBB");
      I[41 ^ 49] = I("棏塑帑", "nFrXS");
      I[10 ^ 19] = I("冥椰浔揭", "lyslb");
      I[165 ^ 191] = I("嬨倌媏", "mCjwU");
      I[143 ^ 148] = I("欕曡", "cyhPl");
      I[23 ^ 11] = I("听揋", "wxcVq");
      I[63 ^ 34] = I("墄咒", "fzUvy");
      I[220 ^ 194] = I("審檒", "FRywT");
      I[131 ^ 156] = I("戺孞", "PNrds");
      I[146 ^ 178] = I("名嶩", "aLIuI");
      I[77 ^ 108] = I("劰暼", "JBMrA");
      I[139 ^ 169] = I("汫庁", "ypxeI");
      I[21 ^ 54] = I("傾攏", "IdqFE");
      I[152 ^ 188] = I("朶冼", "nZJiK");
      I[231 ^ 194] = I("壞毄媾恒喺", "jPlWB");
      I[231 ^ 193] = I("潃充嫕檍凪", "gOZBa");
      I[45 ^ 10] = I("句嬧慶", "KTyQK");
      I[105 ^ 65] = I("灂", "bZwuy");
      I[79 ^ 102] = I("哩", "UEKtr");
      I[142 ^ 164] = I("彰", "lZHyA");
      I[27 ^ 48] = I("娮抿怶", "rjrrC");
      I[234 ^ 198] = I("%\u0005,+5:", "IdUNG");
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = BlockFaceShape.SOLID;
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      IBlockState var3 = var1.getBlockState(var2.down());
      Block var4 = var3.getBlock();
      if (var4 != Blocks.ICE && var4 != Blocks.PACKED_ICE && var4 != Blocks.BARRIER) {
         BlockFaceShape var5 = var3.func_193401_d(var1, var2.down(), EnumFacing.UP);
         int var10000;
         if (var5 != BlockFaceShape.SOLID && var3.getMaterial() != Material.LEAVES && (var4 != this || (Integer)var3.getValue(LAYERS) != (57 ^ 49))) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (-1 < -1) {
               throw null;
            }
         }

         return (boolean)var10000;
      } else {
         return (boolean)"".length();
      }
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   public int getMetaFromState(IBlockState var1) {
      int var10000 = (Integer)var1.getValue(LAYERS);
      int var10001 = " ".length();
      I[108 ^ 118].length();
      I[54 ^ 45].length();
      I[146 ^ 142].length();
      return var10000 - var10001;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (var1.getLightFor(EnumSkyBlock.BLOCK, var2) > (90 ^ 81)) {
         this.dropBlockAsItem(var1, var2, var1.getBlockState(var2), "".length());
         var1.setBlockToAir(var2);
         I[55 ^ 33].length();
         I[147 ^ 132].length();
         I[119 ^ 111].length();
         I[101 ^ 124].length();
      }

   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return SNOW_AABB[(Integer)var1.getValue(LAYERS)];
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (var4 == EnumFacing.UP) {
         return (boolean)" ".length();
      } else {
         IBlockState var5 = var2.getBlockState(var3.offset(var4));
         int var10000;
         if (var5.getBlock() == this && (Integer)var5.getValue(LAYERS) >= (Integer)var1.getValue(LAYERS)) {
            var10000 = "".length();
            "".length();
            if (3 == -1) {
               throw null;
            }
         } else {
            var10000 = super.shouldSideBeRendered(var1, var2, var3, var4);
         }

         return (boolean)var10000;
      }
   }

   public boolean isReplaceable(IBlockAccess var1, BlockPos var2) {
      int var10000;
      if ((Integer)var1.getBlockState(var2).getValue(LAYERS) == " ".length()) {
         var10000 = " ".length();
         "".length();
         if (2 < 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(LAYERS, (var1 & (30 ^ 25)) + " ".length());
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      int var10000;
      if ((Integer)var1.getBlockState(var2).getValue(LAYERS) < (122 ^ 127)) {
         var10000 = " ".length();
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.SNOWBALL;
   }

   protected BlockSnow() {
      super(Material.SNOW);
      this.setDefaultState(this.blockState.getBaseState().withProperty(LAYERS, " ".length()));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   static {
      I();
      LAYERS = PropertyInteger.create(I[119 ^ 91], " ".length(), 116 ^ 124);
      AxisAlignedBB[] var10000 = new AxisAlignedBB[151 ^ 158];
      var10000["".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 1.0D);
      var10000[" ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.125D, 1.0D);
      var10000["  ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.25D, 1.0D);
      var10000["   ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.375D, 1.0D);
      var10000[49 ^ 53] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
      var10000[74 ^ 79] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.625D, 1.0D);
      var10000[33 ^ 39] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.75D, 1.0D);
      var10000[22 ^ 17] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.875D, 1.0D);
      var10000[27 ^ 19] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      SNOW_AABB = var10000;
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      String var10000 = I[105 ^ 100];
      String var10001 = I[137 ^ 135];
      String var10002 = I[26 ^ 21];
      var10001 = I[144 ^ 128];
      I[113 ^ 96].length();
      I[189 ^ 175].length();
      I[89 ^ 74].length();
      spawnAsEntity(var1, var3, new ItemStack(Items.SNOWBALL, (Integer)var4.getValue(LAYERS) + " ".length(), "".length()));
      var1.setBlockToAir(var3);
      I[166 ^ 178].length();
      I[157 ^ 136].length();
      var2.addStat(StatList.getBlockStats(this));
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.UUID;
import net.minecraft.entity.item.EntityPainting;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class SPacketSpawnPainting implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int entityID;
   // $FF: synthetic field
   private String title;
   // $FF: synthetic field
   private EnumFacing facing;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private BlockPos position;
   // $FF: synthetic field
   private UUID uniqueId;

   public SPacketSpawnPainting(EntityPainting var1) {
      this.entityID = var1.getEntityId();
      this.uniqueId = var1.getUniqueID();
      this.position = var1.getHangingPosition();
      this.facing = var1.facingDirection;
      this.title = var1.art.title;
   }

   public int getEntityID() {
      return this.entityID;
   }

   public String getTitle() {
      return this.title;
   }

   public SPacketSpawnPainting() {
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityID = var1.readVarIntFromBuffer();
      this.uniqueId = var1.readUuid();
      this.title = var1.readStringFromBuffer(EntityPainting.EnumArt.MAX_NAME_LENGTH);
      this.position = var1.readBlockPos();
      this.facing = EnumFacing.byHorizontalIndex(var1.readUnsignedByte());
   }

   private static void I() {
      I = new String[204 ^ 193];
      I["".length()] = I("壽洊摭氡", "oRQat");
      I[" ".length()] = I("洽浺灬滃梓", "vyYhG");
      I["  ".length()] = I("求埑樸摽妩", "llwSb");
      I["   ".length()] = I("晚泠仕烩倵", "fgFRt");
      I[111 ^ 107] = I("溢嫟漄", "UYZrd");
      I[67 ^ 70] = I("毗渠凌淓樯", "GqpES");
      I[0 ^ 6] = I("丼旻氋啟扯", "RALPe");
      I[119 ^ 112] = I("媷枙岩僤婑", "tvhtW");
      I[126 ^ 118] = I("挢昜汮", "gUHCL");
      I[119 ^ 126] = I("摁浽", "aVRce");
      I[167 ^ 173] = I("呷宁妶坤僎", "jkHoX");
      I[106 ^ 97] = I("半", "LObNq");
      I[20 ^ 24] = I("岆傛泍毋炝", "RpQLy");
   }

   public EnumFacing getFacing() {
      return this.facing;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 0);

      throw null;
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityID);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeUuid(this.uniqueId);
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeString(this.title);
      I[161 ^ 165].length();
      I[54 ^ 51].length();
      I[104 ^ 110].length();
      I[4 ^ 3].length();
      var1.writeBlockPos(this.position);
      I[82 ^ 90].length();
      I[149 ^ 156].length();
      I[0 ^ 10].length();
      var1.writeByte(this.facing.getHorizontalIndex());
      I[176 ^ 187].length();
      I[183 ^ 187].length();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSpawnPainting(this);
   }

   public UUID getUniqueId() {
      return this.uniqueId;
   }

   public BlockPos getPosition() {
      return this.position;
   }
}

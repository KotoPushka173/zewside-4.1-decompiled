package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentArrowDamage extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   public EnchantmentArrowDamage(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.BOW, var2);
      this.setName(I["".length()]);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 2);

      throw null;
   }

   public int getMaxEnchantability(int var1) {
      return this.getMinEnchantability(var1) + (52 ^ 59);
   }

   public int getMinEnchantability(int var1) {
      int var10000 = " ".length();
      int var10002 = " ".length();
      I[" ".length()].length();
      return var10000 + (var1 - var10002) * (161 ^ 171);
   }

   public int getMaxLevel() {
      return 58 ^ 63;
   }

   private static void I() {
      I = new String["  ".length()];
      I["".length()] = I("2\u0010==>\u0017\u0003\"3.6", "SbORI");
      I[" ".length()] = I("乱", "PimDF");
   }

   static {
      I();
   }
}

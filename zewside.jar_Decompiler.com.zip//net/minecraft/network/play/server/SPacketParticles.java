package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.EnumParticleTypes;

public class SPacketParticles implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private float yOffset;
   // $FF: synthetic field
   private float particleSpeed;
   // $FF: synthetic field
   private float xOffset;
   // $FF: synthetic field
   private EnumParticleTypes particleType;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private float zOffset;
   // $FF: synthetic field
   private boolean longDistance;
   // $FF: synthetic field
   private float zCoord;
   // $FF: synthetic field
   private int particleCount;
   // $FF: synthetic field
   private float xCoord;
   // $FF: synthetic field
   private float yCoord;
   // $FF: synthetic field
   private int[] particleArguments;

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleParticles(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.particleType = EnumParticleTypes.getParticleFromId(var1.readInt());
      if (this.particleType == null) {
         this.particleType = EnumParticleTypes.BARRIER;
      }

      this.longDistance = var1.readBoolean();
      this.xCoord = var1.readFloat();
      this.yCoord = var1.readFloat();
      this.zCoord = var1.readFloat();
      this.xOffset = var1.readFloat();
      this.yOffset = var1.readFloat();
      this.zOffset = var1.readFloat();
      this.particleSpeed = var1.readFloat();
      this.particleCount = var1.readInt();
      int var2 = this.particleType.getArgumentCount();
      this.particleArguments = new int[var2];
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            return;
         }

         this.particleArguments[var3] = var1.readVarIntFromBuffer();
         ++var3;
         "".length();
      } while(4 > 2);

      throw null;
   }

   public SPacketParticles(EnumParticleTypes var1, boolean var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, int var10, int... var11) {
      this.particleType = var1;
      this.longDistance = var2;
      this.xCoord = var3;
      this.yCoord = var4;
      this.zCoord = var5;
      this.xOffset = var6;
      this.yOffset = var7;
      this.zOffset = var8;
      this.particleSpeed = var9;
      this.particleCount = var10;
      this.particleArguments = var11;
   }

   public float getParticleSpeed() {
      return this.particleSpeed;
   }

   public int[] getParticleArgs() {
      return this.particleArguments;
   }

   public float getZOffset() {
      return this.zOffset;
   }

   public double getXCoordinate() {
      return (double)this.xCoord;
   }

   public float getYOffset() {
      return this.yOffset;
   }

   public float getXOffset() {
      return this.xOffset;
   }

   static {
      I();
   }

   public int getParticleCount() {
      return this.particleCount;
   }

   public EnumParticleTypes getParticleType() {
      return this.particleType;
   }

   public boolean isLongDistance() {
      return this.longDistance;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeInt(this.particleType.getParticleID());
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeBoolean(this.longDistance);
      I["   ".length()].length();
      I[79 ^ 75].length();
      I[38 ^ 35].length();
      I[144 ^ 150].length();
      I[154 ^ 157].length();
      var1.writeFloat(this.xCoord);
      I[117 ^ 125].length();
      I[80 ^ 89].length();
      I[77 ^ 71].length();
      I[157 ^ 150].length();
      var1.writeFloat(this.yCoord);
      I[13 ^ 1].length();
      I[171 ^ 166].length();
      I[124 ^ 114].length();
      I[203 ^ 196].length();
      var1.writeFloat(this.zCoord);
      I[48 ^ 32].length();
      I[182 ^ 167].length();
      var1.writeFloat(this.xOffset);
      I[209 ^ 195].length();
      I[187 ^ 168].length();
      var1.writeFloat(this.yOffset);
      I[152 ^ 140].length();
      I[101 ^ 112].length();
      var1.writeFloat(this.zOffset);
      I[9 ^ 31].length();
      I[26 ^ 13].length();
      var1.writeFloat(this.particleSpeed);
      I[73 ^ 81].length();
      I[184 ^ 161].length();
      var1.writeInt(this.particleCount);
      I[105 ^ 115].length();
      I[90 ^ 65].length();
      I[96 ^ 124].length();
      int var2 = this.particleType.getArgumentCount();
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            return;
         }

         var1.writeVarIntToBuffer(this.particleArguments[var3]);
         I[96 ^ 125].length();
         ++var3;
         "".length();
      } while(2 != 0);

      throw null;
   }

   private static void I() {
      I = new String[108 ^ 114];
      I["".length()] = I("嗰扲圷", "ewIWB");
      I[" ".length()] = I("兒", "UJhEh");
      I["  ".length()] = I("傀揈", "yWtFe");
      I["   ".length()] = I("姝峈惡", "OLvsI");
      I[156 ^ 152] = I("亾樺拼", "gBluD");
      I[157 ^ 152] = I("曲滎湚兲旔", "YWZdC");
      I[14 ^ 8] = I("仦亃彻", "OQPeW");
      I[116 ^ 115] = I("怚売囙", "bgwtj");
      I[111 ^ 103] = I("托捛", "acsNc");
      I[86 ^ 95] = I("淄嬬", "Fvwhz");
      I[6 ^ 12] = I("擛樉庘梟", "QwrGk");
      I[122 ^ 113] = I("忌汒椫斉滦", "hnmxh");
      I[109 ^ 97] = I("汋抖匩晤", "uYtWy");
      I[88 ^ 85] = I("朂樝", "fSEEL");
      I[158 ^ 144] = I("徉", "CzZnF");
      I[172 ^ 163] = I("咣型烙", "mzqNG");
      I[41 ^ 57] = I("制檑流态", "WpSjM");
      I[72 ^ 89] = I("善摃", "UUqeT");
      I[108 ^ 126] = I("卫滿栝俇", "LUBIF");
      I[159 ^ 140] = I("漾湴徛潑", "DWKKl");
      I[25 ^ 13] = I("樫", "uelCW");
      I[120 ^ 109] = I("哯安", "unEjm");
      I[49 ^ 39] = I("岷毹庻橚", "bPdLF");
      I[177 ^ 166] = I("波堚伏梧", "vmYbx");
      I[116 ^ 108] = I("哨泷", "uBeKK");
      I[45 ^ 52] = I("倈", "SFXWE");
      I[156 ^ 134] = I("凖崮", "dKUHS");
      I[20 ^ 15] = I("嗮", "yNEpr");
      I[88 ^ 68] = I("某斃婍勒敯", "XMXJA");
      I[222 ^ 195] = I("廦咨", "OlKNZ");
   }

   public double getZCoordinate() {
      return (double)this.zCoord;
   }

   public double getYCoordinate() {
      return (double)this.yCoord;
   }

   public SPacketParticles() {
   }
}

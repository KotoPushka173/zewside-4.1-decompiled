package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.item.Item;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketCooldown implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int ticks;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private Item item;

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.item = Item.getItemById(var1.readVarIntFromBuffer());
      this.ticks = var1.readVarIntFromBuffer();
   }

   public SPacketCooldown(Item var1, int var2) {
      this.item = var1;
      this.ticks = var2;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleCooldown(this);
   }

   public int getTicks() {
      return this.ticks;
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(Item.getIdFromItem(this.item));
      I["".length()].length();
      var1.writeVarIntToBuffer(this.ticks);
      I[" ".length()].length();
      I["  ".length()].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != 2);

      throw null;
   }

   public Item getItem() {
      return this.item;
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("庚娊", "NXkge");
      I[" ".length()] = I("偸", "vodST");
      I["  ".length()] = I("柳沠亀", "TeuuA");
   }

   public SPacketCooldown() {
   }
}

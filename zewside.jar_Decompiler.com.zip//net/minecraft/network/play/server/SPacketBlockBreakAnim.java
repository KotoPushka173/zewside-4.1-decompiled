package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;

public class SPacketBlockBreakAnim implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int breakerId;
   // $FF: synthetic field
   private int progress;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private BlockPos position;

   public int getBreakerId() {
      return this.breakerId;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleBlockBreakAnim(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.breakerId = var1.readVarIntFromBuffer();
      this.position = var1.readBlockPos();
      this.progress = var1.readUnsignedByte();
   }

   static {
      I();
   }

   public SPacketBlockBreakAnim(int var1, BlockPos var2, int var3) {
      this.breakerId = var1;
      this.position = var2;
      this.progress = var3;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.breakerId);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeBlockPos(this.position);
      I["  ".length()].length();
      I["   ".length()].length();
      I[35 ^ 39].length();
      var1.writeByte(this.progress);
      I[138 ^ 143].length();
      I[29 ^ 27].length();
      I[48 ^ 55].length();
   }

   private static void I() {
      I = new String[134 ^ 142];
      I["".length()] = I("噗", "xHuxh");
      I[" ".length()] = I("凯漅", "gBgXK");
      I["  ".length()] = I("溳彧", "seWJC");
      I["   ".length()] = I("僃岽姡使", "gsCxd");
      I[92 ^ 88] = I("壗截抩仴", "NoJMp");
      I[198 ^ 195] = I("上", "ZMQCF");
      I[5 ^ 3] = I("枰弊歃", "BhALa");
      I[21 ^ 18] = I("掜俨交", "nuZNb");
   }

   public int getProgress() {
      return this.progress;
   }

   public SPacketBlockBreakAnim() {
   }

   public BlockPos getPosition() {
      return this.position;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 0);

      throw null;
   }
}

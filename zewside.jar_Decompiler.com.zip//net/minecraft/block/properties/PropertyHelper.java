package net.minecraft.block.properties;

import com.google.common.base.MoreObjects;

public abstract class PropertyHelper<T extends Comparable<T>> implements IProperty<T> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Class<T> valueClass;
   // $FF: synthetic field
   private final String name;

   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)" ".length();
      } else if (!(var1 instanceof PropertyHelper)) {
         return (boolean)"".length();
      } else {
         PropertyHelper var2 = (PropertyHelper)var1;
         int var10000;
         if (this.valueClass.equals(var2.valueClass) && this.name.equals(var2.name)) {
            var10000 = " ".length();
            "".length();
            if (1 <= -1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   static {
      I();
   }

   public Class<T> getValueClass() {
      return this.valueClass;
   }

   protected PropertyHelper(String var1, Class<T> var2) {
      this.valueClass = var2;
      this.name = var1;
   }

   public String getName() {
      return this.name;
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I(",-<\u001c", "BLQyV");
      I[" ".length()] = I(",\u0015(4\u0011", "OyINk");
      I["  ".length()] = I(":\u00029:\b?", "LcUOm");
   }

   public String toString() {
      return MoreObjects.toStringHelper(this).add(I["".length()], this.name).add(I[" ".length()], this.valueClass).add(I["  ".length()], this.getAllowedValues()).toString();
   }

   public int hashCode() {
      return (12 ^ 19) * this.valueClass.hashCode() + this.name.hashCode();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 4);

      throw null;
   }
}

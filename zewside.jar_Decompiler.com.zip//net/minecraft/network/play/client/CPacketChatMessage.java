package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketChatMessage implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private String message;
   // $FF: synthetic field
   private static final String[] I;

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.message = var1.readStringFromBuffer(40 + 42 - -64 + 110);
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processChatMessage(this);
   }

   public CPacketChatMessage(String var1) {
      if (var1.length() > 254 + 148 - 359 + 213) {
         var1 = var1.substring("".length(), 18 + 244 - 74 + 68);
      }

      this.message = var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 1);

      throw null;
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("歮奕凤哚戄", "HAhGT");
      I[" ".length()] = I("浿厲", "oCBSm");
      I["  ".length()] = I("斉健巩", "Sutxj");
   }

   public String getMessage() {
      return this.message;
   }

   public CPacketChatMessage() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.message);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }

   static {
      I();
   }
}

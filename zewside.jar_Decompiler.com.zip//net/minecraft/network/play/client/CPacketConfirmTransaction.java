package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketConfirmTransaction implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private short uid;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private boolean accepted;
   // $FF: synthetic field
   private int windowId;

   public CPacketConfirmTransaction(int var1, short var2, boolean var3) {
      this.windowId = var1;
      this.uid = var2;
      this.accepted = var3;
   }

   private static void I() {
      I = new String[121 ^ 126];
      I["".length()] = I("烾婕喓喃", "hwQne");
      I[" ".length()] = I("梄晧孁姍幼", "IBAtK");
      I["  ".length()] = I("几撰", "UxipW");
      I["   ".length()] = I("崚", "icglU");
      I[94 ^ 90] = I("伳", "TByqJ");
      I[15 ^ 10] = I("搃坅判", "SPJwl");
      I[89 ^ 95] = I("懧梩岛殴", "NQuTg");
   }

   static {
      I();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.windowId = var1.readByte();
      this.uid = var1.readShort();
      int var10001;
      if (var1.readByte() != 0) {
         var10001 = " ".length();
         "".length();
         if (3 <= 1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.accepted = (boolean)var10001;
   }

   public CPacketConfirmTransaction() {
   }

   public short getUid() {
      return this.uid;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processConfirmTransaction(this);
   }

   public int getWindowId() {
      return this.windowId;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.windowId);
      I["".length()].length();
      var1.writeShort(this.uid);
      I[" ".length()].length();
      I["  ".length()].length();
      int var10001;
      if (this.accepted) {
         var10001 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      var1.writeByte(var10001);
      I["   ".length()].length();
      I[75 ^ 79].length();
      I[51 ^ 54].length();
      I[137 ^ 143].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }
}

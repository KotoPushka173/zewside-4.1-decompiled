package net.minecraft.block;

import com.google.common.cache.LoadingCache;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemMonsterPlacer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockPortal extends BlockBreakable {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB Z_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB Y_AABB;
   // $FF: synthetic field
   public static final PropertyEnum<EnumFacing.Axis> AXIS;
   // $FF: synthetic field
   protected static final AxisAlignedBB X_AABB;

   protected BlockStateContainer createBlockState() {
      String var10000 = I[16 ^ 58];
      String var10001 = I[109 ^ 70];
      String var10002 = I[95 ^ 115];
      var10001 = I[90 ^ 119];
      var10000 = I[151 ^ 185];
      var10001 = I[176 ^ 159];
      var10002 = I[240 ^ 192];
      var10001 = I[64 ^ 113];
      I[23 ^ 37].length();
      I[5 ^ 54].length();
      I[120 ^ 76].length();
      I[162 ^ 151].length();
      I[52 ^ 2].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[33 ^ 22].length();
      var10003["".length()] = AXIS;
      return new BlockStateContainer(this, var10003);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing$Axis[((EnumFacing.Axis)var1.getValue(AXIS)).ordinal()]) {
      case 1:
         return X_AABB;
      case 2:
      default:
         return Y_AABB;
      case 3:
         return Z_AABB;
      }
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      var3 = var3.offset(var4);
      EnumFacing.Axis var5 = null;
      if (var1.getBlock() == this) {
         var5 = (EnumFacing.Axis)var1.getValue(AXIS);
         if (var5 == null) {
            return (boolean)"".length();
         }

         if (var5 == EnumFacing.Axis.Z && var4 != EnumFacing.EAST && var4 != EnumFacing.WEST) {
            return (boolean)"".length();
         }

         if (var5 == EnumFacing.Axis.X && var4 != EnumFacing.SOUTH && var4 != EnumFacing.NORTH) {
            return (boolean)"".length();
         }
      }

      int var10000;
      if (var2.getBlockState(var3.west()).getBlock() == this && var2.getBlockState(var3.west("  ".length())).getBlock() != this) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var6 = var10000;
      if (var2.getBlockState(var3.east()).getBlock() == this && var2.getBlockState(var3.east("  ".length())).getBlock() != this) {
         var10000 = " ".length();
         "".length();
         if (-1 != -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var7 = var10000;
      if (var2.getBlockState(var3.north()).getBlock() == this && var2.getBlockState(var3.north("  ".length())).getBlock() != this) {
         var10000 = " ".length();
         "".length();
         if (-1 != -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var8 = var10000;
      if (var2.getBlockState(var3.south()).getBlock() == this && var2.getBlockState(var3.south("  ".length())).getBlock() != this) {
         var10000 = " ".length();
         "".length();
         if (0 >= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var9 = var10000;
      if (var6 == 0 && var7 == 0 && var5 != EnumFacing.Axis.X) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (4 != 4) {
            throw null;
         }
      }

      int var10 = var10000;
      if (var8 == 0 && var9 == 0 && var5 != EnumFacing.Axis.Z) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (0 >= 1) {
            throw null;
         }
      }

      int var11 = var10000;
      if (var10 != 0 && var4 == EnumFacing.WEST) {
         return (boolean)" ".length();
      } else if (var10 != 0 && var4 == EnumFacing.EAST) {
         return (boolean)" ".length();
      } else if (var11 != 0 && var4 == EnumFacing.NORTH) {
         return (boolean)" ".length();
      } else {
         if (var11 != 0 && var4 == EnumFacing.SOUTH) {
            var10000 = " ".length();
            "".length();
            if (2 <= -1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public boolean trySpawnPortal(World var1, BlockPos var2) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[185 ^ 189];
      var10000 = I[51 ^ 54];
      var10001 = I[119 ^ 113];
      var10002 = I[91 ^ 92];
      var10001 = I[133 ^ 141];
      I[57 ^ 48].length();
      I[186 ^ 176].length();
      I[11 ^ 0].length();
      BlockPortal.Size var3 = new BlockPortal.Size(var1, var2, EnumFacing.Axis.X);
      if (var3.isValid() && var3.portalBlockCount == 0) {
         var3.placePortalBlocks();
         return (boolean)" ".length();
      } else {
         I[68 ^ 72].length();
         BlockPortal.Size var4 = new BlockPortal.Size(var1, var2, EnumFacing.Axis.Z);
         if (var4.isValid() && var4.portalBlockCount == 0) {
            var4.placePortalBlocks();
            return (boolean)" ".length();
         } else {
            return (boolean)"".length();
         }
      }
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState();
      PropertyEnum var10001 = AXIS;
      EnumFacing.Axis var10002;
      if ((var1 & "   ".length()) == "  ".length()) {
         var10002 = EnumFacing.Axis.Z;
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10002 = EnumFacing.Axis.X;
      }

      return var10000.withProperty(var10001, var10002);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public int getMetaFromState(IBlockState var1) {
      return getMetaForAxis((EnumFacing.Axis)var1.getValue(AXIS));
   }

   public static int getMetaForAxis(EnumFacing.Axis var0) {
      if (var0 == EnumFacing.Axis.X) {
         return " ".length();
      } else {
         int var10000;
         if (var0 == EnumFacing.Axis.Z) {
            var10000 = "  ".length();
            "".length();
            if (2 <= 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return var10000;
      }
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      if (var4.nextInt(84 ^ 48) == 0) {
         var2.playSound((double)var3.getX() + 0.5D, (double)var3.getY() + 0.5D, (double)var3.getZ() + 0.5D, SoundEvents.BLOCK_PORTAL_AMBIENT, SoundCategory.BLOCKS, 0.5F, var4.nextFloat() * 0.4F + 0.8F, (boolean)"".length());
      }

      int var5 = "".length();

      do {
         if (var5 >= (149 ^ 145)) {
            return;
         }

         double var6 = (double)((float)var3.getX() + var4.nextFloat());
         double var8 = (double)((float)var3.getY() + var4.nextFloat());
         double var10 = (double)((float)var3.getZ() + var4.nextFloat());
         double var10000 = (double)var4.nextFloat();
         I[71 ^ 101].length();
         double var12 = (var10000 - 0.5D) * 0.5D;
         var10000 = (double)var4.nextFloat();
         I[18 ^ 49].length();
         I[85 ^ 113].length();
         double var14 = (var10000 - 0.5D) * 0.5D;
         var10000 = (double)var4.nextFloat();
         I[80 ^ 117].length();
         I[90 ^ 124].length();
         double var16 = (var10000 - 0.5D) * 0.5D;
         int var19 = var4.nextInt("  ".length()) * "  ".length();
         int var10001 = " ".length();
         I[141 ^ 170].length();
         I[25 ^ 49].length();
         I[32 ^ 9].length();
         int var18 = var19 - var10001;
         if (var2.getBlockState(var3.west()).getBlock() != this && var2.getBlockState(var3.east()).getBlock() != this) {
            var6 = (double)var3.getX() + 0.5D + 0.25D * (double)var18;
            var12 = (double)(var4.nextFloat() * 2.0F * (float)var18);
            "".length();
            if (4 < 1) {
               throw null;
            }
         } else {
            var10 = (double)var3.getZ() + 0.5D + 0.25D * (double)var18;
            var16 = (double)(var4.nextFloat() * 2.0F * (float)var18);
         }

         var2.spawnParticle(EnumParticleTypes.PORTAL, var6, var8, var10, var12, var14, var16);
         ++var5;
         "".length();
      } while(4 >= 3);

      throw null;
   }

   static {
      I();
      String var10000 = I[252 ^ 162];
      EnumFacing.Axis[] var10002 = new EnumFacing.Axis["  ".length()];
      var10002["".length()] = EnumFacing.Axis.X;
      var10002[" ".length()] = EnumFacing.Axis.Z;
      AXIS = PropertyEnum.create(var10000, EnumFacing.Axis.class, (Enum[])var10002);
      X_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 1.0D, 1.0D, 0.625D);
      Z_AABB = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 1.0D, 1.0D);
      Y_AABB = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 1.0D, 0.625D);
   }

   private static void I() {
      I = new String[89 ^ 6];
      I["".length()] = I("- \u0007=\u000b\u001a?+%\u0007 !-", "IOJRi");
      I[" ".length()] = I("檹昻", "BNNzD");
      I["  ".length()] = I("桕炒", "DiVbB");
      I["   ".length()] = I("榴匴", "ZYhAW");
      I[77 ^ 73] = I("涺旋", "jOUzh");
      I[121 ^ 124] = I("伟毂", "nEQug");
      I[146 ^ 148] = I("堧桻", "grZql");
      I[1 ^ 6] = I("嗮曡", "EIqYx");
      I[133 ^ 141] = I("屹憿", "LCvfm");
      I[2 ^ 11] = I("毹槹", "HtIqF");
      I[53 ^ 63] = I("杸息", "ZGTOz");
      I[93 ^ 86] = I("櫪", "GgljT");
      I[205 ^ 193] = I("找喠炆", "HnOmZ");
      I[205 ^ 192] = I("墖捹", "lzRSO");
      I[58 ^ 52] = I("呆墴", "DUuJe");
      I[140 ^ 131] = I("勌他", "nAGnX");
      I[107 ^ 123] = I("橞濸", "AxieR");
      I[154 ^ 139] = I("氄搧", "PECMu");
      I[7 ^ 21] = I("氨塽", "ruIll");
      I[84 ^ 71] = I("冠凄", "irEko");
      I[39 ^ 51] = I("妦唯", "hWAVQ");
      I[182 ^ 163] = I("尚凟檔", "wZPZH");
      I[7 ^ 17] = I("棜搪昔", "HevfA");
      I[96 ^ 119] = I("暄懈俻", "CaOhG");
      I[25 ^ 1] = I("劮", "pQtLh");
      I[9 ^ 16] = I("烳帊", "tDoHt");
      I[103 ^ 125] = I("坸扗掓", "LSFpJ");
      I[68 ^ 95] = I("劽", "hGHHW");
      I[40 ^ 52] = I("哬", "TMtxp");
      I[11 ^ 22] = I("滛区曆", "tVGJH");
      I[38 ^ 56] = I("欳", "IbsMo");
      I[182 ^ 169] = I("沦嗂崫挅忞", "RNgmw");
      I[92 ^ 124] = I("曦倭渠", "hadWB");
      I[77 ^ 108] = I("亯幓凟朔", "kIwqR");
      I[25 ^ 59] = I("慺嘶帜浬", "AUzlc");
      I[151 ^ 180] = I("伋堑东丧", "PMlAD");
      I[138 ^ 174] = I("惣", "AVjZU");
      I[7 ^ 34] = I("扷暛", "rRoxd");
      I[5 ^ 35] = I("弢掃寚报俅", "wWNhN");
      I[142 ^ 169] = I("惦", "AzPvO");
      I[130 ^ 170] = I("慑吟", "eYVRg");
      I[91 ^ 114] = I("垞可", "TuRWZ");
      I[46 ^ 4] = I("呆唏", "nrFlc");
      I[114 ^ 89] = I("庶揙", "MpzrR");
      I[37 ^ 9] = I("烉垪", "pRWVr");
      I[145 ^ 188] = I("濛搖", "gHVMF");
      I[170 ^ 132] = I("媚殤", "zzJLp");
      I[180 ^ 155] = I("丆岻", "OHGmb");
      I[24 ^ 40] = I("沚丸", "NXixE");
      I[92 ^ 109] = I("噜旄", "acHTS");
      I[80 ^ 98] = I("棗", "mOoHg");
      I[1 ^ 50] = I("抦伂咽", "HcCMQ");
      I[136 ^ 188] = I("渗", "HWwCX");
      I[6 ^ 51] = I("澻火", "yligR");
      I[63 ^ 9] = I("屍冿唘枣", "vtcxR");
      I[181 ^ 130] = I("创浻伯", "mWJTo");
      I[17 ^ 41] = I("彫攥", "WabOz");
      I[78 ^ 119] = I("宣嵓", "USKOy");
      I[254 ^ 196] = I("剰斿", "MpuPP");
      I[48 ^ 11] = I("溹条", "IBJUJ");
      I[63 ^ 3] = I("徧掵", "ewvSc");
      I[120 ^ 69] = I("灇坿", "taYnp");
      I[134 ^ 184] = I("柆佑", "pBqhd");
      I[97 ^ 94] = I("唵憵", "OqPYL");
      I[112 ^ 48] = I("昽娵", "zitsR");
      I[214 ^ 151] = I("娣庍", "AZZdg");
      I[194 ^ 128] = I("埐婶", "aYWcg");
      I[111 ^ 44] = I("櫚埢", "vzySW");
      I[124 ^ 56] = I("嶪俹", "vneuc");
      I[64 ^ 5] = I("呆劗", "pdMEt");
      I[111 ^ 41] = I("坌椹", "pxSNm");
      I[25 ^ 94] = I("懵樁", "SegVV");
      I[202 ^ 130] = I("弇汑", "RrwmI");
      I[16 ^ 89] = I("坱档", "JTcan");
      I[102 ^ 44] = I("噚挸", "fUBSa");
      I[52 ^ 127] = I("懌后", "lLcmT");
      I[248 ^ 180] = I("冦嗡朕浵埔", "KZrCr");
      I[18 ^ 95] = I("剜掬册", "ygGDn");
      I[103 ^ 41] = I("嘜", "iPYbt");
      I[249 ^ 182] = I("憞浘", "nXOUV");
      I[198 ^ 150] = I("壱会凱奭吩", "SSIbC");
      I[35 ^ 114] = I("楷吖濲战永", "nwYiM");
      I[231 ^ 181] = I("掑毆", "QDEUd");
      I[211 ^ 128] = I("弩卌步慠楯", "QKzBI");
      I[56 ^ 108] = I("僆岒溹", "VPoha");
      I[71 ^ 18] = I("僥", "eOnIw");
      I[149 ^ 195] = I("槐仑", "LWmeC");
      I[245 ^ 162] = I("搽", "VxiCg");
      I[78 ^ 22] = I("堤战娇", "nzAsN");
      I[192 ^ 153] = I("壨", "lSwgz");
      I[42 ^ 112] = I("寵庯晧", "IYTJy");
      I[55 ^ 108] = I("濇", "BzJmb");
      I[242 ^ 174] = I("呖", "DOcWa");
      I[249 ^ 164] = I("堡梸剽儴", "TwJga");
      I[56 ^ 102] = I("\u00176\b\u0000", "vNasa");
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
      case 2:
         switch(null.$SwitchMap$net$minecraft$util$EnumFacing$Axis[((EnumFacing.Axis)var1.getValue(AXIS)).ordinal()]) {
         case 1:
            return var1.withProperty(AXIS, EnumFacing.Axis.Z);
         case 3:
            return var1.withProperty(AXIS, EnumFacing.Axis.X);
         default:
            return var1;
         }
      default:
         return var1;
      }
   }

   public BlockPattern.PatternHelper createPatternHelper(World var1, BlockPos var2) {
      String var10000 = I[60 ^ 4];
      String var10001 = I[169 ^ 144];
      String var10002 = I[62 ^ 4];
      var10001 = I[12 ^ 55];
      var10000 = I[139 ^ 183];
      var10001 = I[49 ^ 12];
      var10002 = I[173 ^ 147];
      var10001 = I[136 ^ 183];
      var10000 = I[62 ^ 126];
      var10001 = I[201 ^ 136];
      var10002 = I[211 ^ 145];
      var10001 = I[113 ^ 50];
      var10000 = I[245 ^ 177];
      var10001 = I[238 ^ 171];
      var10002 = I[254 ^ 184];
      var10001 = I[61 ^ 122];
      var10000 = I[72 ^ 0];
      var10001 = I[108 ^ 37];
      var10002 = I[55 ^ 125];
      var10001 = I[72 ^ 3];
      EnumFacing.Axis var3 = EnumFacing.Axis.Z;
      I[230 ^ 170].length();
      I[29 ^ 80].length();
      I[117 ^ 59].length();
      BlockPortal.Size var4 = new BlockPortal.Size(var1, var2, EnumFacing.Axis.X);
      LoadingCache var5 = BlockPattern.createLoadingCache(var1, (boolean)" ".length());
      if (!var4.isValid()) {
         var3 = EnumFacing.Axis.X;
         I[26 ^ 85].length();
         var4 = new BlockPortal.Size(var1, var2, EnumFacing.Axis.Z);
      }

      if (!var4.isValid()) {
         I[78 ^ 30].length();
         I[71 ^ 22].length();
         return new BlockPattern.PatternHelper(var2, EnumFacing.NORTH, EnumFacing.UP, var5, " ".length(), " ".length(), " ".length());
      } else {
         int[] var6 = new int[EnumFacing.AxisDirection.values().length];
         EnumFacing var7 = var4.rightDir.rotateYCCW();
         BlockPos var21 = var4.bottomLeft;
         int var25 = var4.getHeight();
         int var23 = " ".length();
         I[196 ^ 150].length();
         I[87 ^ 4].length();
         BlockPos var8 = var21.up(var25 - var23);
         EnumFacing.AxisDirection[] var9 = EnumFacing.AxisDirection.values();
         int var10 = var9.length;
         int var11 = "".length();

         do {
            EnumFacing var10003;
            int var10004;
            int var10005;
            BlockPattern.PatternHelper var22;
            BlockPos var24;
            if (var11 >= var10) {
               EnumFacing.AxisDirection var17 = EnumFacing.AxisDirection.POSITIVE;
               EnumFacing.AxisDirection[] var18 = EnumFacing.AxisDirection.values();
               var11 = var18.length;
               int var19 = "".length();

               do {
                  if (var19 >= var11) {
                     var22 = new BlockPattern.PatternHelper;
                     I[74 ^ 19].length();
                     I[33 ^ 123].length();
                     I[118 ^ 45].length();
                     if (var7.getAxisDirection() == var17) {
                        var24 = var8;
                        "".length();
                        if (0 == -1) {
                           throw null;
                        }
                     } else {
                        var10003 = var4.rightDir;
                        var10004 = var4.getWidth();
                        var10005 = " ".length();
                        I[20 ^ 72].length();
                        I[215 ^ 138].length();
                        var24 = var8.offset(var10003, var10004 - var10005);
                     }

                     var22.<init>(var24, EnumFacing.getFacingFromAxis(var17, var3), EnumFacing.UP, var5, var4.getWidth(), var4.getHeight(), " ".length());
                     return var22;
                  }

                  EnumFacing.AxisDirection var20 = var18[var19];
                  if (var6[var20.ordinal()] < var6[var17.ordinal()]) {
                     var17 = var20;
                  }

                  ++var19;
                  "".length();
               } while(4 > -1);

               throw null;
            }

            EnumFacing.AxisDirection var12 = var9[var11];
            var22 = new BlockPattern.PatternHelper;
            I[40 ^ 124].length();
            I[95 ^ 10].length();
            I[243 ^ 165].length();
            I[3 ^ 84].length();
            if (var7.getAxisDirection() == var12) {
               var24 = var8;
               "".length();
               if (2 >= 3) {
                  throw null;
               }
            } else {
               var10003 = var4.rightDir;
               var10004 = var4.getWidth();
               var10005 = " ".length();
               I[30 ^ 70].length();
               var24 = var8.offset(var10003, var10004 - var10005);
            }

            var22.<init>(var24, EnumFacing.getFacingFromAxis(var12, var3), EnumFacing.UP, var5, var4.getWidth(), var4.getHeight(), " ".length());
            BlockPattern.PatternHelper var13 = var22;
            int var14 = "".length();

            while(var14 < var4.getWidth()) {
               int var15 = "".length();

               while(var15 < var4.getHeight()) {
                  BlockWorldState var16 = var13.translateOffset(var14, var15, " ".length());
                  if (var16.getBlockState() != null && var16.getBlockState().getMaterial() != Material.AIR) {
                     var25 = var12.ordinal();
                     var6[var25] += " ".length();
                  }

                  ++var15;
                  "".length();
                  if (1 <= 0) {
                     throw null;
                  }
               }

               ++var14;
               "".length();
               if (-1 >= 3) {
                  throw null;
               }
            }

            ++var11;
            "".length();
         } while(4 >= 1);

         throw null;
      }
   }

   public BlockPortal() {
      super(Material.PORTAL, (boolean)"".length());
      this.setDefaultState(this.blockState.getBaseState().withProperty(AXIS, EnumFacing.Axis.X));
      this.setTickRandomly((boolean)" ".length());
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      return ItemStack.field_190927_a;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      String var10000 = I[188 ^ 177];
      String var10001 = I[31 ^ 17];
      String var10002 = I[114 ^ 125];
      var10001 = I[114 ^ 98];
      var10000 = I[56 ^ 41];
      var10001 = I[55 ^ 37];
      var10002 = I[76 ^ 95];
      var10001 = I[46 ^ 58];
      EnumFacing.Axis var6 = (EnumFacing.Axis)var1.getValue(AXIS);
      BlockPortal.Size var7;
      if (var6 == EnumFacing.Axis.X) {
         I[133 ^ 144].length();
         I[184 ^ 174].length();
         I[139 ^ 156].length();
         I[63 ^ 39].length();
         I[96 ^ 121].length();
         var7 = new BlockPortal.Size(var2, var3, EnumFacing.Axis.X);
         if (!var7.isValid() || var7.portalBlockCount < var7.width * var7.height) {
            var2.setBlockState(var3, Blocks.AIR.getDefaultState());
            I[25 ^ 3].length();
            I[50 ^ 41].length();
            I[220 ^ 192].length();
         }

         "".length();
         if (-1 >= 0) {
            throw null;
         }
      } else if (var6 == EnumFacing.Axis.Z) {
         I[102 ^ 123].length();
         I[123 ^ 101].length();
         I[159 ^ 128].length();
         var7 = new BlockPortal.Size(var2, var3, EnumFacing.Axis.Z);
         if (!var7.isValid() || var7.portalBlockCount < var7.width * var7.height) {
            var2.setBlockState(var3, Blocks.AIR.getDefaultState());
            I[56 ^ 24].length();
            I[136 ^ 169].length();
         }
      }

   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.TRANSLUCENT;
   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      if (!var4.isRiding() && !var4.isBeingRidden() && var4.isNonBoss()) {
         var4.setPortal(var2);
      }

   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      super.updateTick(var1, var2, var3, var4);
      if (var1.provider.isSurfaceWorld() && var1.getGameRules().getBoolean(I["".length()]) && var4.nextInt(529 + 1092 - 296 + 675) < var1.getDifficulty().getDifficultyId()) {
         int var5 = var2.getY();
         BlockPos var6 = var2;

         while(!var1.getBlockState(var6).isFullyOpaque() && var6.getY() > 0) {
            var6 = var6.down();
            "".length();
            if (false) {
               throw null;
            }
         }

         if (var5 > 0 && !var1.getBlockState(var6.up()).isNormalCube()) {
            Entity var7 = ItemMonsterPlacer.spawnCreature(var1, EntityList.getKey(EntityPigZombie.class), (double)var6.getX() + 0.5D, (double)var6.getY() + 1.1D, (double)var6.getZ() + 0.5D);
            if (var7 != null) {
               var7.timeUntilPortal = var7.getPortalCooldown();
            }
         }
      }

   }

   public static class Size {
      // $FF: synthetic field
      private final EnumFacing leftDir;
      // $FF: synthetic field
      private int width;
      // $FF: synthetic field
      private final EnumFacing.Axis axis;
      // $FF: synthetic field
      private final EnumFacing rightDir;
      // $FF: synthetic field
      private BlockPos bottomLeft;
      // $FF: synthetic field
      private final World world;
      // $FF: synthetic field
      private int height;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private int portalBlockCount;

      public Size(World var1, BlockPos var2, EnumFacing.Axis var3) {
         this.world = var1;
         this.axis = var3;
         if (var3 == EnumFacing.Axis.X) {
            this.leftDir = EnumFacing.EAST;
            this.rightDir = EnumFacing.WEST;
            "".length();
            if (3 < 0) {
               throw null;
            }
         } else {
            this.leftDir = EnumFacing.NORTH;
            this.rightDir = EnumFacing.SOUTH;
         }

         BlockPos var4 = var2;

         while(var2.getY() > var4.getY() - (52 ^ 33) && var2.getY() > 0 && this.isEmptyBlock(var1.getBlockState(var2.down()).getBlock())) {
            var2 = var2.down();
            "".length();
            if (4 == 2) {
               throw null;
            }
         }

         int var5 = this.getDistanceUntilEdge(var2, this.leftDir) - " ".length();
         if (var5 >= 0) {
            this.bottomLeft = var2.offset(this.leftDir, var5);
            this.width = this.getDistanceUntilEdge(this.bottomLeft, this.rightDir);
            if (this.width < "  ".length() || this.width > (79 ^ 90)) {
               this.bottomLeft = null;
               this.width = "".length();
            }
         }

         if (this.bottomLeft != null) {
            this.height = this.calculatePortalHeight();
         }

      }

      protected int getDistanceUntilEdge(BlockPos var1, EnumFacing var2) {
         int var3 = "".length();

         while(var3 < (123 ^ 109)) {
            BlockPos var4 = var1.offset(var2, var3);
            if (!this.isEmptyBlock(this.world.getBlockState(var4).getBlock())) {
               break;
            }

            if (this.world.getBlockState(var4.down()).getBlock() != Blocks.OBSIDIAN) {
               "".length();
               if (4 == 1) {
                  throw null;
               }
               break;
            }

            ++var3;
            "".length();
            if (3 != 3) {
               throw null;
            }
         }

         Block var5 = this.world.getBlockState(var1.offset(var2, var3)).getBlock();
         int var10000;
         if (var5 == Blocks.OBSIDIAN) {
            var10000 = var3;
            "".length();
            if (2 <= -1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return var10000;
      }

      protected int calculatePortalHeight() {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         var10000 = I[37 ^ 33];
         var10001 = I[38 ^ 35];
         var10002 = I[134 ^ 128];
         var10001 = I[97 ^ 102];
         this.height = "".length();

         int var1;
         label70:
         while(this.height < (87 ^ 66)) {
            var1 = "".length();

            do {
               if (var1 >= this.width) {
                  I[33 ^ 47].length();
                  I[190 ^ 177].length();
                  I[6 ^ 22].length();
                  this.height += " ".length();
                  "".length();
                  if (-1 != -1) {
                     throw null;
                  }
                  continue label70;
               }

               BlockPos var2 = this.bottomLeft.offset(this.rightDir, var1).up(this.height);
               Block var3 = this.world.getBlockState(var2).getBlock();
               if (!this.isEmptyBlock(var3)) {
                  "".length();
                  if (0 == 2) {
                     throw null;
                  }
                  break label70;
               }

               if (var3 == Blocks.PORTAL) {
                  I[35 ^ 43].length();
                  I[164 ^ 173].length();
                  I[16 ^ 26].length();
                  this.portalBlockCount += " ".length();
               }

               if (var1 == 0) {
                  var3 = this.world.getBlockState(var2.offset(this.leftDir)).getBlock();
                  if (var3 != Blocks.OBSIDIAN) {
                     "".length();
                     if (0 == 3) {
                        throw null;
                     }
                     break label70;
                  }
               } else {
                  int var4 = this.width;
                  int var5 = " ".length();
                  I[178 ^ 185].length();
                  I[190 ^ 178].length();
                  I[124 ^ 113].length();
                  if (var1 == var4 - var5) {
                     var3 = this.world.getBlockState(var2.offset(this.rightDir)).getBlock();
                     if (var3 != Blocks.OBSIDIAN) {
                        "".length();
                        if (2 >= 3) {
                           throw null;
                        }
                        break label70;
                     }
                  }
               }

               ++var1;
               "".length();
            } while(-1 != 4);

            throw null;
         }

         var1 = "".length();

         while(var1 < this.width) {
            if (this.world.getBlockState(this.bottomLeft.offset(this.rightDir, var1).up(this.height)).getBlock() != Blocks.OBSIDIAN) {
               this.height = "".length();
               "".length();
               if (3 == -1) {
                  throw null;
               }
               break;
            }

            ++var1;
            "".length();
            if (1 < -1) {
               throw null;
            }
         }

         if (this.height <= (142 ^ 155) && this.height >= "   ".length()) {
            return this.height;
         } else {
            this.bottomLeft = null;
            this.width = "".length();
            this.height = "".length();
            return "".length();
         }
      }

      protected boolean isEmptyBlock(Block var1) {
         int var10000;
         if (var1.blockMaterial != Material.AIR && var1 != Blocks.FIRE && var1 != Blocks.PORTAL) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (4 <= 2) {
               throw null;
            }
         }

         return (boolean)var10000;
      }

      public int getHeight() {
         return this.height;
      }

      static {
         I();
      }

      public boolean isValid() {
         int var10000;
         if (this.bottomLeft != null && this.width >= "  ".length() && this.width <= (107 ^ 126) && this.height >= "   ".length() && this.height <= (127 ^ 106)) {
            var10000 = " ".length();
            "".length();
            if (3 <= 2) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 == -1);

         throw null;
      }

      public int getWidth() {
         return this.width;
      }

      private static void I() {
         I = new String[18 ^ 6];
         I["".length()] = I("涃橹", "Puexk");
         I[" ".length()] = I("徙懳", "VWWZo");
         I["  ".length()] = I("宮慗", "QQKFD");
         I["   ".length()] = I("娹摜", "WLwhm");
         I[48 ^ 52] = I("洰仌", "IbqSj");
         I[44 ^ 41] = I("嶲嵩", "EBQfl");
         I[55 ^ 49] = I("奛彊", "Lahhs");
         I[150 ^ 145] = I("怨八", "eyKyp");
         I[8 ^ 0] = I("徍卿丟", "bjuOQ");
         I[180 ^ 189] = I("惜恛氈匸徜", "oeCNg");
         I[15 ^ 5] = I("晄噝橪偮偶", "JycDJ");
         I[74 ^ 65] = I("俭円歑廣揖", "gtmyr");
         I[108 ^ 96] = I("尛", "IBFXD");
         I[108 ^ 97] = I("斃悷", "jkmUd");
         I[137 ^ 135] = I("卮噹嫈倩晸", "hOyhe");
         I[178 ^ 189] = I("媀劭宻堢剘", "fNtAo");
         I[141 ^ 157] = I("敢呱揫", "dpheH");
         I[136 ^ 153] = I("擭塏咫", "eAqCp");
         I[112 ^ 98] = I("氻楒洣烿權", "zgggT");
         I[89 ^ 74] = I("庒", "AWABp");
      }

      public void placePortalBlocks() {
         int var1 = "".length();

         do {
            if (var1 >= this.width) {
               return;
            }

            BlockPos var2 = this.bottomLeft.offset(this.rightDir, var1);
            int var3 = "".length();

            while(var3 < this.height) {
               this.world.setBlockState(var2.up(var3), Blocks.PORTAL.getDefaultState().withProperty(BlockPortal.AXIS, this.axis), "  ".length());
               I[108 ^ 125].length();
               I[143 ^ 157].length();
               I[121 ^ 106].length();
               ++var3;
               "".length();
               if (-1 >= 3) {
                  throw null;
               }
            }

            ++var1;
            "".length();
         } while(4 >= 0);

         throw null;
      }
   }
}

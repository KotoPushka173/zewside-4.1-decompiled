package net.minecraft.scoreboard;

import com.google.common.collect.Maps;
import java.util.Collection;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.util.text.TextFormatting;

public abstract class Team {
   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public abstract Team.CollisionRule getCollisionRule();

   public boolean isSameTeam(@Nullable Team var1) {
      if (var1 == null) {
         return (boolean)"".length();
      } else {
         int var10000;
         if (this == var1) {
            var10000 = " ".length();
            "".length();
            if (-1 >= 3) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public abstract Collection<String> getMembershipCollection();

   public abstract String formatString(String var1);

   public abstract Team.EnumVisible getDeathMessageVisibility();

   public abstract TextFormatting getChatFormat();

   public abstract String getRegisteredName();

   public abstract Team.EnumVisible getNameTagVisibility();

   public abstract boolean getAllowFriendlyFire();

   public abstract boolean getSeeFriendlyInvisiblesEnabled();

   public static enum CollisionRule {
      // $FF: synthetic field
      ALWAYS,
      // $FF: synthetic field
      NEVER;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      public final String name;
      // $FF: synthetic field
      HIDE_FOR_OTHER_TEAMS,
      // $FF: synthetic field
      HIDE_FOR_OWN_TEAM;

      // $FF: synthetic field
      public final int id;
      // $FF: synthetic field
      private static final Map<String, Team.CollisionRule> nameMap;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 >= -1);

         throw null;
      }

      @Nullable
      public static Team.CollisionRule getByName(String var0) {
         return (Team.CollisionRule)nameMap.get(var0);
      }

      private static void I() {
         I = new String[88 ^ 80];
         I["".length()] = I("\b\b\u000f\u0012=\u001a", "IDXSd");
         I[" ".length()] = I("8\u001f\u0004\u0011\u0016*", "Ysspo");
         I["  ".length()] = I("\u0019\n\"=\u001d", "WOtxO");
         I["   ".length()] = I("\u0005*5 \u001d", "kOCEo");
         I[27 ^ 31] = I("#&=\u0011)- +\u000b9?'<\u0006)?*8\u0019%", "koyTv");
         I[121 ^ 124] = I("\u00128&\u000e+\u0016%0\u00140\u0007,8\u0015", "bMUfd");
         I[91 ^ 93] = I("1\u000f \u0013(?\t6\t8.\b;\u000228\u000b", "yFdVw");
         I[12 ^ 11] = I("\u001e7 \r\u0018\u0019,\u0007\u00006\u0003", "nBSeW");
      }

      static {
         I();
         ALWAYS = new Team.CollisionRule(I["".length()], "".length(), I[" ".length()], "".length());
         NEVER = new Team.CollisionRule(I["  ".length()], " ".length(), I["   ".length()], " ".length());
         HIDE_FOR_OTHER_TEAMS = new Team.CollisionRule(I[72 ^ 76], "  ".length(), I[77 ^ 72], "  ".length());
         HIDE_FOR_OWN_TEAM = new Team.CollisionRule(I[95 ^ 89], "   ".length(), I[180 ^ 179], "   ".length());
         Team.CollisionRule[] var10000 = new Team.CollisionRule[31 ^ 27];
         var10000["".length()] = ALWAYS;
         var10000[" ".length()] = NEVER;
         var10000["  ".length()] = HIDE_FOR_OTHER_TEAMS;
         var10000["   ".length()] = HIDE_FOR_OWN_TEAM;
         nameMap = Maps.newHashMap();
         Team.CollisionRule[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            Team.CollisionRule var3 = var0[var2];
            nameMap.put(var3.name, var3);
            ++var2;
            "".length();
         } while(4 >= 2);

         throw null;
      }

      private CollisionRule(String var3, int var4) {
         this.name = var3;
         this.id = var4;
      }

      public static String[] getNames() {
         return (String[])((String[])nameMap.keySet().toArray(new String[nameMap.size()]));
      }
   }

   public static enum EnumVisible {
      // $FF: synthetic field
      private static final Map<String, Team.EnumVisible> nameMap;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      HIDE_FOR_OWN_TEAM;

      // $FF: synthetic field
      public final String internalName;
      // $FF: synthetic field
      HIDE_FOR_OTHER_TEAMS;

      // $FF: synthetic field
      public final int id;
      // $FF: synthetic field
      ALWAYS,
      // $FF: synthetic field
      NEVER;

      private static void I() {
         I = new String[143 ^ 135];
         I["".length()] = I("6\u0015 \u000b\u0014$", "wYwJM");
         I[" ".length()] = I("4?'' &", "USPFY");
         I["  ".length()] = I("+6\u0003)%", "esUlw");
         I["   ".length()] = I("8\n%\u0011\u001a", "VoSth");
         I[156 ^ 152] = I("0//\u0013\f>)9\t\u001c,..\u0004\f,#*\u001b\u0000", "xfkVS");
         I[23 ^ 18] = I("1'4&\u00026<\u001f7,<<\u0004&%4=", "YNPCD");
         I[181 ^ 179] = I("\u0003\b(+8\r\u000e>1(\u001c\u000f3:\"\n\f", "KAlng");
         I[29 ^ 26] = I("\u001f>>(!\u0018%\u0015:\t#2; ", "wWZMg");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 > -1);

         throw null;
      }

      public static String[] getNames() {
         return (String[])((String[])nameMap.keySet().toArray(new String[nameMap.size()]));
      }

      private EnumVisible(String var3, int var4) {
         this.internalName = var3;
         this.id = var4;
      }

      @Nullable
      public static Team.EnumVisible getByName(String var0) {
         return (Team.EnumVisible)nameMap.get(var0);
      }

      static {
         I();
         ALWAYS = new Team.EnumVisible(I["".length()], "".length(), I[" ".length()], "".length());
         NEVER = new Team.EnumVisible(I["  ".length()], " ".length(), I["   ".length()], " ".length());
         HIDE_FOR_OTHER_TEAMS = new Team.EnumVisible(I[12 ^ 8], "  ".length(), I[66 ^ 71], "  ".length());
         HIDE_FOR_OWN_TEAM = new Team.EnumVisible(I[56 ^ 62], "   ".length(), I[70 ^ 65], "   ".length());
         Team.EnumVisible[] var10000 = new Team.EnumVisible[194 ^ 198];
         var10000["".length()] = ALWAYS;
         var10000[" ".length()] = NEVER;
         var10000["  ".length()] = HIDE_FOR_OTHER_TEAMS;
         var10000["   ".length()] = HIDE_FOR_OWN_TEAM;
         nameMap = Maps.newHashMap();
         Team.EnumVisible[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            Team.EnumVisible var3 = var0[var2];
            nameMap.put(var3.internalName, var3);
            ++var2;
            "".length();
         } while(1 >= 0);

         throw null;
      }
   }
}

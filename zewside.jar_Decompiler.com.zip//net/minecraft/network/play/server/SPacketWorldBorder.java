package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.border.WorldBorder;

public class SPacketWorldBorder implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int warningTime;
   // $FF: synthetic field
   private double centerZ;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private double centerX;
   // $FF: synthetic field
   private long timeUntilTarget;
   // $FF: synthetic field
   private double targetSize;
   // $FF: synthetic field
   private int size;
   // $FF: synthetic field
   private SPacketWorldBorder.Action action;
   // $FF: synthetic field
   private int warningDistance;
   // $FF: synthetic field
   private double diameter;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.action);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      switch(null.$SwitchMap$net$minecraft$network$play$server$SPacketWorldBorder$Action[this.action.ordinal()]) {
      case 1:
         var1.writeDouble(this.targetSize);
         I[145 ^ 149].length();
         I[47 ^ 42].length();
         "".length();
         if (3 != 3) {
            throw null;
         }
         break;
      case 2:
         var1.writeDouble(this.diameter);
         I[123 ^ 125].length();
         I[156 ^ 155].length();
         var1.writeDouble(this.targetSize);
         I[98 ^ 106].length();
         I[57 ^ 48].length();
         I[146 ^ 152].length();
         var1.writeVarLong(this.timeUntilTarget);
         I[124 ^ 119].length();
         I[27 ^ 23].length();
         "".length();
         if (2 < -1) {
            throw null;
         }
         break;
      case 3:
         var1.writeDouble(this.centerX);
         I[58 ^ 55].length();
         var1.writeDouble(this.centerZ);
         I[101 ^ 107].length();
         I[22 ^ 25].length();
         "".length();
         if (2 != 2) {
            throw null;
         }
         break;
      case 4:
         var1.writeVarIntToBuffer(this.warningDistance);
         I[106 ^ 122].length();
         I[163 ^ 178].length();
         I[31 ^ 13].length();
         I[3 ^ 16].length();
         I[146 ^ 134].length();
         "".length();
         if (4 != 4) {
            throw null;
         }
         break;
      case 5:
         var1.writeVarIntToBuffer(this.warningTime);
         I[122 ^ 111].length();
         I[165 ^ 179].length();
         "".length();
         if (false) {
            throw null;
         }
         break;
      case 6:
         var1.writeDouble(this.centerX);
         I[41 ^ 62].length();
         I[175 ^ 183].length();
         var1.writeDouble(this.centerZ);
         I[124 ^ 101].length();
         I[23 ^ 13].length();
         I[181 ^ 174].length();
         var1.writeDouble(this.diameter);
         I[217 ^ 197].length();
         var1.writeDouble(this.targetSize);
         I[74 ^ 87].length();
         I[114 ^ 108].length();
         I[127 ^ 96].length();
         var1.writeVarLong(this.timeUntilTarget);
         I[120 ^ 88].length();
         I[133 ^ 164].length();
         I[114 ^ 80].length();
         var1.writeVarIntToBuffer(this.size);
         I[17 ^ 50].length();
         var1.writeVarIntToBuffer(this.warningDistance);
         I[158 ^ 186].length();
         var1.writeVarIntToBuffer(this.warningTime);
         I[153 ^ 188].length();
         I[16 ^ 54].length();
         I[83 ^ 116].length();
         I[170 ^ 130].length();
      }

   }

   public SPacketWorldBorder() {
   }

   private static void I() {
      I = new String[43 ^ 2];
      I["".length()] = I("偣啪惟佝噧", "TfBiC");
      I[" ".length()] = I("曻圼", "haUpA");
      I["  ".length()] = I("椃哾嶋毖嚉", "eRQWc");
      I["   ".length()] = I("屼徬", "qItmY");
      I[147 ^ 151] = I("剿桔妚烘", "aAjEw");
      I[189 ^ 184] = I("嬎梚又", "yCAHa");
      I[50 ^ 52] = I("儍嫻昨悞氎", "bMxCF");
      I[166 ^ 161] = I("书娎塬", "IqeOI");
      I[171 ^ 163] = I("岩晥攅", "pGSCX");
      I[20 ^ 29] = I("态姂攼悅", "UCrup");
      I[79 ^ 69] = I("暴憨潭", "SRJmz");
      I[79 ^ 68] = I("棋泃丩", "JKvLi");
      I[64 ^ 76] = I("役愮懴士澄", "HbKWl");
      I[178 ^ 191] = I("暏恑戗兞慰", "YhRJm");
      I[59 ^ 53] = I("壥", "rHlvw");
      I[138 ^ 133] = I("嵕峊渷", "irLje");
      I[120 ^ 104] = I("圮昘", "mBoOe");
      I[157 ^ 140] = I("渠", "eipGw");
      I[23 ^ 5] = I("寱惃", "HRdUG");
      I[58 ^ 41] = I("密姄", "LqjWz");
      I[129 ^ 149] = I("侳", "tPRvt");
      I[88 ^ 77] = I("噫橀憱光実", "ikRMn");
      I[190 ^ 168] = I("匨壌封劧嗍", "muMsF");
      I[208 ^ 199] = I("僦母抙棐慫", "bdYga");
      I[185 ^ 161] = I("抠孰", "UPzRB");
      I[70 ^ 95] = I("漠溷渥", "ERbBz");
      I[156 ^ 134] = I("忳", "oEwog");
      I[56 ^ 35] = I("坁仇揃占", "sSYhf");
      I[126 ^ 98] = I("浛捡瀌", "hobMu");
      I[96 ^ 125] = I("濬", "vAEJt");
      I[29 ^ 3] = I("叻侾擜揄揖", "lyMuy");
      I[163 ^ 188] = I("刖噲漱啛", "CBXIz");
      I[87 ^ 119] = I("恨佽岦", "sZSiv");
      I[13 ^ 44] = I("枘勃喚", "lwZzZ");
      I[181 ^ 151] = I("壃吶嫱", "QAwqG");
      I[117 ^ 86] = I("塻咻杙寢濺", "PWJaR");
      I[134 ^ 162] = I("害冡噸溪", "kzJRb");
      I[95 ^ 122] = I("溇", "BBEzS");
      I[120 ^ 94] = I("並壚咛", "ErZpA");
      I[3 ^ 36] = I("拾溰侔", "CpSZi");
      I[93 ^ 117] = I("嶝曒暈", "NEkQL");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   public SPacketWorldBorder(WorldBorder var1, SPacketWorldBorder.Action var2) {
      this.action = var2;
      this.centerX = var1.getCenterX();
      this.centerZ = var1.getCenterZ();
      this.diameter = var1.getDiameter();
      this.targetSize = var1.getTargetSize();
      this.timeUntilTarget = var1.getTimeUntilTarget();
      this.size = var1.getSize();
      this.warningDistance = var1.getWarningDistance();
      this.warningTime = var1.getWarningTime();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleWorldBorder(this);
   }

   static {
      I();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.action = (SPacketWorldBorder.Action)var1.readEnumValue(SPacketWorldBorder.Action.class);
      switch(null.$SwitchMap$net$minecraft$network$play$server$SPacketWorldBorder$Action[this.action.ordinal()]) {
      case 1:
         this.targetSize = var1.readDouble();
         "".length();
         if (0 == 3) {
            throw null;
         }
         break;
      case 2:
         this.diameter = var1.readDouble();
         this.targetSize = var1.readDouble();
         this.timeUntilTarget = var1.readVarLong();
         "".length();
         if (1 <= 0) {
            throw null;
         }
         break;
      case 3:
         this.centerX = var1.readDouble();
         this.centerZ = var1.readDouble();
         "".length();
         if (-1 >= 0) {
            throw null;
         }
         break;
      case 4:
         this.warningDistance = var1.readVarIntFromBuffer();
         "".length();
         if (-1 == 0) {
            throw null;
         }
         break;
      case 5:
         this.warningTime = var1.readVarIntFromBuffer();
         "".length();
         if (3 <= 2) {
            throw null;
         }
         break;
      case 6:
         this.centerX = var1.readDouble();
         this.centerZ = var1.readDouble();
         this.diameter = var1.readDouble();
         this.targetSize = var1.readDouble();
         this.timeUntilTarget = var1.readVarLong();
         this.size = var1.readVarIntFromBuffer();
         this.warningDistance = var1.readVarIntFromBuffer();
         this.warningTime = var1.readVarIntFromBuffer();
      }

   }

   public void apply(WorldBorder var1) {
      switch(null.$SwitchMap$net$minecraft$network$play$server$SPacketWorldBorder$Action[this.action.ordinal()]) {
      case 1:
         var1.setTransition(this.targetSize);
         "".length();
         if (0 >= 4) {
            throw null;
         }
         break;
      case 2:
         var1.setTransition(this.diameter, this.targetSize, this.timeUntilTarget);
         "".length();
         if (1 < 1) {
            throw null;
         }
         break;
      case 3:
         var1.setCenter(this.centerX, this.centerZ);
         "".length();
         if (0 < -1) {
            throw null;
         }
         break;
      case 4:
         var1.setWarningDistance(this.warningDistance);
         "".length();
         if (4 <= 0) {
            throw null;
         }
         break;
      case 5:
         var1.setWarningTime(this.warningTime);
         "".length();
         if (4 == 0) {
            throw null;
         }
         break;
      case 6:
         var1.setCenter(this.centerX, this.centerZ);
         if (this.timeUntilTarget > 0L) {
            var1.setTransition(this.diameter, this.targetSize, this.timeUntilTarget);
            "".length();
            if (-1 >= 2) {
               throw null;
            }
         } else {
            var1.setTransition(this.targetSize);
         }

         var1.setSize(this.size);
         var1.setWarningDistance(this.warningDistance);
         var1.setWarningTime(this.warningTime);
      }

   }

   public static enum Action {
      // $FF: synthetic field
      SET_SIZE,
      // $FF: synthetic field
      SET_WARNING_TIME,
      // $FF: synthetic field
      SET_WARNING_BLOCKS;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      LERP_SIZE,
      // $FF: synthetic field
      SET_CENTER,
      // $FF: synthetic field
      INITIALIZE;

      private static void I() {
         I = new String[119 ^ 113];
         I["".length()] = I("%$\u0005\t1?;\u0014", "vaQVb");
         I[" ".length()] = I("<\u0010\u001a\u0006\u000f#\u001c\u0012\u0013", "pUHVP");
         I["  ".length()] = I("\u001d\u0000\u0007;\u0014\u000b\u000b\u0007!\u0005", "NESdW");
         I["   ".length()] = I("=;\u0013\u0018\u001f59\u0013\u0016\u0013", "tuZLV");
         I[161 ^ 165] = I("\u0015\u0004\u00181\u0000\u0007\u0013\u0002'\u0019\u0001\u001e\u0018'\u001a\u0003", "FALnW");
         I[154 ^ 159] = I("#\b\u000e\u0016\u00061\u001f\u0014\u0000\u001f7\u0012\u0018\u0005\u001e3\u0006\t", "pMZIQ");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 != 0);

         throw null;
      }

      static {
         I();
         SET_SIZE = new SPacketWorldBorder.Action(I["".length()], "".length());
         LERP_SIZE = new SPacketWorldBorder.Action(I[" ".length()], " ".length());
         SET_CENTER = new SPacketWorldBorder.Action(I["  ".length()], "  ".length());
         INITIALIZE = new SPacketWorldBorder.Action(I["   ".length()], "   ".length());
         SET_WARNING_TIME = new SPacketWorldBorder.Action(I[80 ^ 84], 155 ^ 159);
         SET_WARNING_BLOCKS = new SPacketWorldBorder.Action(I[7 ^ 2], 193 ^ 196);
         SPacketWorldBorder.Action[] var10000 = new SPacketWorldBorder.Action[40 ^ 46];
         var10000["".length()] = SET_SIZE;
         var10000[" ".length()] = LERP_SIZE;
         var10000["  ".length()] = SET_CENTER;
         var10000["   ".length()] = INITIALIZE;
         var10000[136 ^ 140] = SET_WARNING_TIME;
         var10000[26 ^ 31] = SET_WARNING_BLOCKS;
      }
   }
}

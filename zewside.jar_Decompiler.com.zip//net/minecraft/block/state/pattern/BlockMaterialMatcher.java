package net.minecraft.block.state.pattern;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;

public class BlockMaterialMatcher implements Predicate<IBlockState> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Material material;

   public boolean apply(@Nullable IBlockState var1) {
      int var10000;
      if (var1 != null && var1.getMaterial() == this.material) {
         var10000 = " ".length();
         "".length();
         if (1 < -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private BlockMaterialMatcher(Material var1) {
      this.material = var1;
   }

   public static BlockMaterialMatcher forMaterial(Material var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[189 ^ 185].length();
      return new BlockMaterialMatcher(var0);
   }

   private static void I() {
      I = new String[167 ^ 162];
      I["".length()] = I("孲揧", "hRtro");
      I[" ".length()] = I("侧枽", "kaYuY");
      I["  ".length()] = I("歕劗", "AelBD");
      I["   ".length()] = I("夤嚾", "EXKSH");
      I[45 ^ 41] = I("墩业孊", "Lvgmk");
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.scoreboard.ScoreObjective;

public class SPacketDisplayObjective implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int position;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private String scoreName;

   public SPacketDisplayObjective() {
   }

   public String getName() {
      return this.scoreName;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > -1);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleDisplayObjective(this);
   }

   public int getPosition() {
      return this.position;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.position = var1.readByte();
      this.scoreName = var1.readStringFromBuffer(5 ^ 21);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.position);
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeString(this.scoreName);
      I[186 ^ 190].length();
      I[136 ^ 141].length();
      I[181 ^ 179].length();
      I[128 ^ 135].length();
   }

   private static void I() {
      I = new String[66 ^ 74];
      I["".length()] = I("", "uXKiw");
      I[" ".length()] = I("悹", "NNdDK");
      I["  ".length()] = I("嚩", "FkefN");
      I["   ".length()] = I("嵊", "sITMB");
      I[131 ^ 135] = I("凥寷帊", "MRRbw");
      I[171 ^ 174] = I("侻", "KrUIj");
      I[57 ^ 63] = I("媉滮", "tOdvI");
      I[22 ^ 17] = I("敞暇瀴彰", "wZJYF");
   }

   static {
      I();
   }

   public SPacketDisplayObjective(int var1, ScoreObjective var2) {
      this.position = var1;
      if (var2 == null) {
         this.scoreName = I["".length()];
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      } else {
         this.scoreName = var2.getName();
      }

   }
}

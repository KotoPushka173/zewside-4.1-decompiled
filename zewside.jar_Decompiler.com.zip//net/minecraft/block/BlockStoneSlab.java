package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockStoneSlab extends BlockSlab {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockStoneSlab.EnumType> VARIANT;
   // $FF: synthetic field
   public static final PropertyBool SEAMLESS;

   protected BlockStateContainer createBlockState() {
      String var10000 = I[42 ^ 62];
      String var10001 = I[145 ^ 132];
      String var10002 = I[99 ^ 117];
      var10001 = I[29 ^ 10];
      var10000 = I[85 ^ 77];
      var10001 = I[178 ^ 171];
      var10002 = I[190 ^ 164];
      var10001 = I[166 ^ 189];
      var10000 = I[166 ^ 186];
      var10001 = I[161 ^ 188];
      var10002 = I[84 ^ 74];
      var10001 = I[21 ^ 10];
      var10000 = I[43 ^ 11];
      var10001 = I[30 ^ 63];
      var10002 = I[15 ^ 45];
      var10001 = I[3 ^ 32];
      var10000 = I[145 ^ 181];
      var10001 = I[155 ^ 190];
      var10002 = I[129 ^ 167];
      var10001 = I[25 ^ 62];
      var10000 = I[92 ^ 116];
      var10001 = I[154 ^ 179];
      var10002 = I[115 ^ 89];
      var10001 = I[53 ^ 30];
      BlockStateContainer var1;
      IProperty[] var10003;
      if (this.isDouble()) {
         I[23 ^ 59].length();
         var10003 = new IProperty["  ".length()];
         I[182 ^ 155].length();
         var10003["".length()] = SEAMLESS;
         I[68 ^ 106].length();
         I[172 ^ 131].length();
         I[136 ^ 184].length();
         I[38 ^ 23].length();
         var10003[" ".length()] = VARIANT;
         var1 = new BlockStateContainer(this, var10003);
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         I[171 ^ 153].length();
         var10003 = new IProperty["  ".length()];
         I[135 ^ 180].length();
         I[55 ^ 3].length();
         I[156 ^ 169].length();
         I[165 ^ 147].length();
         var10003["".length()] = HALF;
         I[6 ^ 49].length();
         I[171 ^ 147].length();
         I[10 ^ 51].length();
         var10003[" ".length()] = VARIANT;
         var1 = new BlockStateContainer(this, var10003);
      }

      return var1;
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var2 = this.getDefaultState().withProperty(VARIANT, BlockStoneSlab.EnumType.byMetadata(var1 & (178 ^ 181)));
      if (this.isDouble()) {
         PropertyBool var10001 = SEAMLESS;
         int var10002;
         if ((var1 & (184 ^ 176)) != 0) {
            var10002 = " ".length();
            "".length();
            if (3 <= 0) {
               throw null;
            }
         } else {
            var10002 = "".length();
         }

         var2 = var2.withProperty(var10001, Boolean.valueOf((boolean)var10002));
         "".length();
         if (3 <= 2) {
            throw null;
         }
      } else {
         PropertyEnum var3 = HALF;
         BlockSlab.EnumBlockHalf var4;
         if ((var1 & (155 ^ 147)) == 0) {
            var4 = BlockSlab.EnumBlockHalf.BOTTOM;
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var4 = BlockSlab.EnumBlockHalf.TOP;
         }

         var2 = var2.withProperty(var3, var4);
      }

      return var2;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 != 0);

      throw null;
   }

   public IProperty<?> getVariantProperty() {
      return VARIANT;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((BlockStoneSlab.EnumType)var1.getValue(VARIANT)).getMetadata();
      if (this.isDouble()) {
         if ((Boolean)var1.getValue(SEAMLESS)) {
            var2 |= 125 ^ 117;
            "".length();
            if (1 < 0) {
               throw null;
            }
         }
      } else if (var1.getValue(HALF) == BlockSlab.EnumBlockHalf.TOP) {
         var2 |= 146 ^ 154;
      }

      return var2;
   }

   private static void I() {
      I = new String[161 ^ 157];
      I["".length()] = I("厌圵", "mXSYo");
      I[" ".length()] = I("捵幁", "ruSYO");
      I["  ".length()] = I("員搷", "XhURi");
      I["   ".length()] = I("帖吃", "zqCoT");
      I[134 ^ 130] = I("渹囚", "ZxjmN");
      I[164 ^ 161] = I("壣兴", "eZQNv");
      I[33 ^ 39] = I("橨煬", "OBrFm");
      I[117 ^ 114] = I("卯僬", "mfaUK");
      I[42 ^ 34] = I("濥濁", "AGitA");
      I[118 ^ 127] = I("岼", "sCcbJ");
      I[104 ^ 98] = I("咯抦", "qssvk");
      I[40 ^ 35] = I("[", "ucLcY");
      I[168 ^ 164] = I("匴丸", "MtwVh");
      I[122 ^ 119] = I("懚怘", "hLHXs");
      I[191 ^ 177] = I("呠圉", "ZGbuL");
      I[99 ^ 108] = I("寖劓", "eTGCe");
      I[187 ^ 171] = I("峢吙", "wQXPW");
      I[171 ^ 186] = I("岐揹呿摻渜", "xbntW");
      I[13 ^ 31] = I("孍庭", "InbQc");
      I[137 ^ 154] = I("榺", "RPQcA");
      I[48 ^ 36] = I("欎仾", "AkSmG");
      I[190 ^ 171] = I("堐埅", "AqEvA");
      I[188 ^ 170] = I("堐凵", "fsSrO");
      I[101 ^ 114] = I("枓栌", "ADhqn");
      I[90 ^ 66] = I("姢扞", "bqfxp");
      I[140 ^ 149] = I("儦孙", "mWgid");
      I[21 ^ 15] = I("巵嶒", "WhSUS");
      I[131 ^ 152] = I("庸派", "KBbCG");
      I[221 ^ 193] = I("呀敩", "BOkkk");
      I[166 ^ 187] = I("朡圗", "fIGHF");
      I[135 ^ 153] = I("懾啇", "fpCDJ");
      I[103 ^ 120] = I("啢伫", "EMlKq");
      I[131 ^ 163] = I("勊妜", "cgZtg");
      I[98 ^ 67] = I("採峑", "ChHWg");
      I[59 ^ 25] = I("哄劲", "UltgE");
      I[166 ^ 133] = I("倂庵", "JTOYd");
      I[35 ^ 7] = I("曠举", "hjBgT");
      I[229 ^ 192] = I("恢暱", "OcHKW");
      I[182 ^ 144] = I("恨椩", "BWIys");
      I[19 ^ 52] = I("樞淖", "pYHHr");
      I[23 ^ 63] = I("優抴", "HhMcz");
      I[147 ^ 186] = I("桭僅", "xhDCi");
      I[5 ^ 47] = I("呻柳", "oanoU");
      I[87 ^ 124] = I("传挬", "yhhKw");
      I[116 ^ 88] = I("枌态举嶮", "lxFCL");
      I[145 ^ 188] = I("唳暑", "hIsEH");
      I[41 ^ 7] = I("忠嵟揈", "YDotp");
      I[91 ^ 116] = I("慠", "YrWze");
      I[165 ^ 149] = I("沇摀寲揢", "SbVMD");
      I[3 ^ 50] = I("瀻墻沒", "ztSZy");
      I[79 ^ 125] = I("瀘栚欜", "HPDRU");
      I[91 ^ 104] = I("勞儳", "JoTBX");
      I[8 ^ 60] = I("囫氺儫匷拼", "ySono");
      I[184 ^ 141] = I("啊", "kIcUn");
      I[19 ^ 37] = I("湳溯澛嘞", "QZVAO");
      I[37 ^ 18] = I("濴濒", "wKfer");
      I[26 ^ 34] = I("槁匶旉倘尝", "KFJRl");
      I[68 ^ 125] = I("却", "YNbYA");
      I[149 ^ 175] = I("\u0016\u001d,)\u0003\u0000\u000b>", "exMDo");
      I[2 ^ 57] = I("2-\u0017\u0002\r*8", "DLekl");
   }

   public String getUnlocalizedName(int var1) {
      String var10000 = I[31 ^ 26];
      String var10001 = I[107 ^ 109];
      String var10002 = I[70 ^ 65];
      var10001 = I[10 ^ 2];
      I[108 ^ 101].length();
      I[119 ^ 125].length();
      return super.getUnlocalizedName() + I[80 ^ 91] + BlockStoneSlab.EnumType.byMetadata(var1).getUnlocalizedName();
   }

   public BlockStoneSlab() {
      super(Material.ROCK);
      IBlockState var1 = this.blockState.getBaseState();
      if (this.isDouble()) {
         var1 = var1.withProperty(SEAMLESS, Boolean.valueOf((boolean)"".length()));
         "".length();
         if (1 < -1) {
            throw null;
         }
      } else {
         var1 = var1.withProperty(HALF, BlockSlab.EnumBlockHalf.BOTTOM);
      }

      this.setDefaultState(var1.withProperty(VARIANT, BlockStoneSlab.EnumType.STONE));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return ((BlockStoneSlab.EnumType)var1.getValue(VARIANT)).getMapColor();
   }

   static {
      I();
      SEAMLESS = PropertyBool.create(I[19 ^ 41]);
      VARIANT = PropertyEnum.create(I[161 ^ 154], BlockStoneSlab.EnumType.class);
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockStoneSlab.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[170 ^ 174].length();
      return new ItemStack(Blocks.STONE_SLAB, " ".length(), ((BlockStoneSlab.EnumType)var3.getValue(VARIANT)).getMetadata());
   }

   public Comparable<?> getTypeForItem(ItemStack var1) {
      return BlockStoneSlab.EnumType.byMetadata(var1.getMetadata() & (96 ^ 103));
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[206 ^ 194];
      String var10001 = I[167 ^ 170];
      String var10002 = I[5 ^ 11];
      var10001 = I[44 ^ 35];
      BlockStoneSlab.EnumType[] var3 = BlockStoneSlab.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockStoneSlab.EnumType var6 = var3[var5];
         if (var6 != BlockStoneSlab.EnumType.WOOD) {
            I[52 ^ 36].length();
            I[54 ^ 39].length();
            I[31 ^ 13].length();
            var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
            I[187 ^ 168].length();
         }

         ++var5;
         "".length();
      } while(4 > 1);

      throw null;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.STONE_SLAB);
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      STONE,
      // $FF: synthetic field
      NETHERBRICK,
      // $FF: synthetic field
      BRICK;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      SAND;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final MapColor mapColor;
      // $FF: synthetic field
      SMOOTHBRICK;

      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      COBBLESTONE;

      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      QUARTZ,
      // $FF: synthetic field
      WOOD;

      public MapColor getMapColor() {
         return this.mapColor;
      }

      private EnumType(int var3, MapColor var4, String var5) {
         this(var3, var4, var5, var5);
      }

      public String getName() {
         return this.name;
      }

      private EnumType(int var3, MapColor var4, String var5, String var6) {
         this.meta = var3;
         this.mapColor = var4;
         this.name = var5;
         this.unlocalizedName = var6;
      }

      public String toString() {
         return this.name;
      }

      private static void I() {
         I = new String[155 ^ 142];
         I["".length()] = I("+'\u0004%/", "xsKkj");
         I[" ".length()] = I("\u001f\u0013\u001d\u001c\u001d", "lgrrx");
         I["  ".length()] = I("#\u0014\u001d\u0011", "pUSUh");
         I["   ".length()] = I("=\u0004\u0002 \u0003:\n\u0002!", "NelDp");
         I[149 ^ 145] = I("<\u000e(\u000e", "OoFjg");
         I[39 ^ 34] = I("'\b\u000e#", "pGAgp");
         I[101 ^ 99] = I("\r\u001e8&3\u0015\u001d3", "zqWBl");
         I[38 ^ 33] = I("?\u001f\u0007\u0013", "Hphwu");
         I[177 ^ 185] = I("\u0004\u0005\u0017\u0018/\u0002\u0019\u0001\u0015-\u0002", "GJUZc");
         I[123 ^ 114] = I(".\u00005\u0012?(\u001c#\u001f=(", "MoWpS");
         I[42 ^ 32] = I("'\u001c\u000f\u0011!!", "DsmsM");
         I[41 ^ 34] = I("\n?.5 ", "Hmgvk");
         I[116 ^ 120] = I("\u000e\u0013\u000b72", "labTY");
         I[191 ^ 178] = I("\u001a\u0019\"\u0016\u000e\u0001\u0016?\u0010\u0019\u0002", "ITmYZ");
         I[151 ^ 153] = I("\t9\u001d'\u0002%/\u0000 \u0004\u0011", "zMrIg");
         I[27 ^ 20] = I("\u00118&*!\n\u0006=*;\u0007\u0017;,6\t", "bUIEU");
         I[141 ^ 157] = I("4\u00040\u0005\u0012(\u00036\u0004\u00141", "zAdMW");
         I[31 ^ 14] = I("9\u0010 \u000e\u000e%*6\u0014\u00024\u001e", "WuTfk");
         I[30 ^ 12] = I("\u0000\u0014\f$\u0011\u001c3\n%\u0017\u0005", "nqxLt");
         I[87 ^ 68] = I("\u0006\u0019\f&0\r", "WLMtd");
         I[208 ^ 196] = I("<\")3\u00057", "MWHAq");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 != 1);

         throw null;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      public int getMetadata() {
         return this.meta;
      }

      public static BlockStoneSlab.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      static {
         I();
         STONE = new BlockStoneSlab.EnumType(I["".length()], "".length(), "".length(), MapColor.STONE, I[" ".length()]);
         SAND = new BlockStoneSlab.EnumType(I["  ".length()], " ".length(), " ".length(), MapColor.SAND, I["   ".length()], I[118 ^ 114]);
         WOOD = new BlockStoneSlab.EnumType(I[23 ^ 18], "  ".length(), "  ".length(), MapColor.WOOD, I[2 ^ 4], I[89 ^ 94]);
         COBBLESTONE = new BlockStoneSlab.EnumType(I[94 ^ 86], "   ".length(), "   ".length(), MapColor.STONE, I[161 ^ 168], I[144 ^ 154]);
         BRICK = new BlockStoneSlab.EnumType(I[21 ^ 30], 169 ^ 173, 100 ^ 96, MapColor.RED, I[142 ^ 130]);
         SMOOTHBRICK = new BlockStoneSlab.EnumType(I[207 ^ 194], 183 ^ 178, 22 ^ 19, MapColor.STONE, I[31 ^ 17], I[141 ^ 130]);
         NETHERBRICK = new BlockStoneSlab.EnumType(I[209 ^ 193], 102 ^ 96, 70 ^ 64, MapColor.NETHERRACK, I[90 ^ 75], I[45 ^ 63]);
         QUARTZ = new BlockStoneSlab.EnumType(I[60 ^ 47], 61 ^ 58, 156 ^ 155, MapColor.QUARTZ, I[97 ^ 117]);
         BlockStoneSlab.EnumType[] var10000 = new BlockStoneSlab.EnumType[104 ^ 96];
         var10000["".length()] = STONE;
         var10000[" ".length()] = SAND;
         var10000["  ".length()] = WOOD;
         var10000["   ".length()] = COBBLESTONE;
         var10000[91 ^ 95] = BRICK;
         var10000[54 ^ 51] = SMOOTHBRICK;
         var10000[82 ^ 84] = NETHERBRICK;
         var10000[1 ^ 6] = QUARTZ;
         BlockStoneSlab.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockStoneSlab.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(4 >= 4);

         throw null;
      }
   }
}

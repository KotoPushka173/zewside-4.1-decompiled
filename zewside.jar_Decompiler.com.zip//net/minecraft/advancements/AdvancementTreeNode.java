package net.minecraft.advancements;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;

public class AdvancementTreeNode {
   // $FF: synthetic field
   private int field_192335_h;
   // $FF: synthetic field
   private AdvancementTreeNode field_192334_g;
   // $FF: synthetic field
   private float field_192337_j;
   // $FF: synthetic field
   private final int field_192331_d;
   // $FF: synthetic field
   private float field_192336_i;
   // $FF: synthetic field
   private final Advancement field_192328_a;
   // $FF: synthetic field
   private final List<AdvancementTreeNode> field_192332_e = Lists.newArrayList();
   // $FF: synthetic field
   private AdvancementTreeNode field_192333_f;
   // $FF: synthetic field
   private final AdvancementTreeNode field_192329_b;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final AdvancementTreeNode field_192330_c;
   // $FF: synthetic field
   private float field_192339_l;
   // $FF: synthetic field
   private float field_192338_k;

   private AdvancementTreeNode func_192324_a(AdvancementTreeNode var1) {
      String var10000 = I[57 ^ 21];
      String var10001 = I[155 ^ 182];
      String var10002 = I[145 ^ 191];
      var10001 = I[80 ^ 127];
      var10000 = I[62 ^ 14];
      var10001 = I[166 ^ 151];
      var10002 = I[89 ^ 107];
      var10001 = I[7 ^ 52];
      if (this.field_192330_c == null) {
         return var1;
      } else {
         AdvancementTreeNode var2 = this;
         AdvancementTreeNode var3 = this;
         AdvancementTreeNode var4 = this.field_192330_c;
         AdvancementTreeNode var5 = (AdvancementTreeNode)this.field_192329_b.field_192332_e.get("".length());
         float var6 = this.field_192337_j;
         float var7 = this.field_192337_j;
         float var8 = var4.field_192337_j;
         float var9 = var5.field_192337_j;

         float var12;
         while(var4.func_192317_d() != null && var2.func_192321_c() != null) {
            var4 = var4.func_192317_d();
            var2 = var2.func_192321_c();
            var5 = var5.func_192321_c();
            var3 = var3.func_192317_d();
            var3.field_192333_f = this;
            float var11 = var4.field_192336_i + var8;
            var12 = var2.field_192336_i + var6;
            I[165 ^ 145].length();
            I[46 ^ 27].length();
            float var10 = var11 - var12 + 1.0F;
            if (var10 > 0.0F) {
               var4.func_192326_a(this, var1).func_192316_a(this, var10);
               var6 += var10;
               var7 += var10;
            }

            var8 += var4.field_192337_j;
            var6 += var2.field_192337_j;
            var9 += var5.field_192337_j;
            var7 += var3.field_192337_j;
            "".length();
            if (-1 == 3) {
               throw null;
            }
         }

         if (var4.func_192317_d() != null && var3.func_192317_d() == null) {
            var3.field_192334_g = var4.func_192317_d();
            I[134 ^ 176].length();
            I[20 ^ 35].length();
            var12 = var3.field_192337_j;
            I[165 ^ 157].length();
            I[122 ^ 67].length();
            I[109 ^ 87].length();
            var3.field_192337_j = var12 + (var8 - var7);
            "".length();
            if (-1 == 0) {
               throw null;
            }
         } else {
            if (var2.func_192321_c() != null && var5.func_192321_c() == null) {
               var5.field_192334_g = var2.func_192321_c();
               I[89 ^ 98].length();
               I[159 ^ 163].length();
               var12 = var5.field_192337_j;
               I[170 ^ 151].length();
               I[24 ^ 38].length();
               var5.field_192337_j = var12 + (var6 - var9);
            }

            var1 = this;
         }

         return var1;
      }
   }

   private static void I() {
      I = new String[219 ^ 168];
      I["".length()] = I("\u0005\u0011\u001ep,f\u0000\u001f$12\u0019\u001f9x'\u001eP>60\u0019\u0003>:*\u0015P6<0\u0011\u001e4=+\u0015\u001e#y", "FppWX");
      I[" ".length()] = I("烰厵", "eQolz");
      I["  ".length()] = I("嚬徾", "XaTwx");
      I["   ".length()] = I("効柳", "eHgQr");
      I[43 ^ 47] = I("油扂", "dbJqV");
      I[138 ^ 143] = I("恐氶变樧橊", "rWQdv");
      I[139 ^ 141] = I("愤", "mCqwR");
      I[27 ^ 28] = I("烫椑", "xbtjI");
      I[86 ^ 94] = I("契孷桧圈挜", "VBHBt");
      I[204 ^ 197] = I("掻尨", "gOGAK");
      I[151 ^ 157] = I("幎柦劊", "ayACw");
      I[99 ^ 104] = I("幨抉咰摇", "fNGAN");
      I[146 ^ 158] = I("烵橦噛嚘垐", "LJbtk");
      I[11 ^ 6] = I("擫渲柔坆", "mlwer");
      I[66 ^ 76] = I("政凯", "jFGGA");
      I[78 ^ 65] = I("歀拴", "GQHIu");
      I[176 ^ 160] = I("曔柨", "vFEAp");
      I[5 ^ 20] = I("棪擻", "cdLQM");
      I[161 ^ 179] = I("嚹澩", "BvNbz");
      I[167 ^ 180] = I("仗丞埔怐樠", "rCzQO");
      I[190 ^ 170] = I("堭媡廭怕", "SGKZI");
      I[190 ^ 171] = I("姗梀", "EmKFd");
      I[12 ^ 26] = I("憵浱", "KXMtc");
      I[104 ^ 127] = I("瀂季", "OxmrJ");
      I[153 ^ 129] = I("冧囋", "DPoGK");
      I[190 ^ 167] = I("沇溍懪恅", "SORTr");
      I[115 ^ 105] = I("弯槾", "mNDwJ");
      I[72 ^ 83] = I("昫惇", "JInfd");
      I[189 ^ 161] = I("槗嫌", "AWeWz");
      I[63 ^ 34] = I("怏岴", "Tufcj");
      I[31 ^ 1] = I("免中", "HRsyZ");
      I[177 ^ 174] = I("峞沕", "aryzi");
      I[124 ^ 92] = I("庇挡", "RbkyM");
      I[85 ^ 116] = I("卵桽", "jXKYS");
      I[159 ^ 189] = I("旼濞晵俆旵", "pewiy");
      I[151 ^ 180] = I("丨僙伜擡", "OJyIc");
      I[63 ^ 27] = I("僝冸嚲", "lhlfE");
      I[111 ^ 74] = I("加氧忶", "WpGjz");
      I[77 ^ 107] = I("橳濠桱庞徏", "HOvnU");
      I[169 ^ 142] = I("名峔嵷哛單", "kKQuP");
      I[155 ^ 179] = I("宱岉滫", "dJkep");
      I[0 ^ 41] = I("瀿嗜压嗖", "Rffsj");
      I[155 ^ 177] = I("撎堀始濹", "spovF");
      I[16 ^ 59] = I("晍殓", "AkNij");
      I[58 ^ 22] = I("樝妳", "zkeFg");
      I[80 ^ 125] = I("掩尯", "lUIgb");
      I[51 ^ 29] = I("亲愩", "AoQNW");
      I[53 ^ 26] = I("冔僔", "FsPVF");
      I[29 ^ 45] = I("梯承", "tptdi");
      I[155 ^ 170] = I("殚棖", "IHuqr");
      I[76 ^ 126] = I("傣惗", "vkaHE");
      I[105 ^ 90] = I("柆復", "bGwcm");
      I[52 ^ 0] = I("傎怨溿", "zQGVr");
      I[158 ^ 171] = I("懲噊", "hFipY");
      I[30 ^ 40] = I("挘", "nUcQs");
      I[78 ^ 121] = I("懿栭樑剕", "tPiWz");
      I[26 ^ 34] = I("攆嚭枭嵲哸", "MLNCV");
      I[161 ^ 152] = I("柨", "bwgIF");
      I[138 ^ 176] = I("娪烙淛", "mKnDw");
      I[131 ^ 184] = I("俔战决楧棺", "aoKAO");
      I[255 ^ 195] = I("哱", "HTnpC");
      I[191 ^ 130] = I("濮娶楶", "tbBev");
      I[171 ^ 149] = I("炂", "veARK");
      I[71 ^ 120] = I("唢圙", "pvbrB");
      I[35 ^ 99] = I("挗別", "CyUPy");
      I[203 ^ 138] = I("徏惭", "IVABT");
      I[117 ^ 55] = I("坹澬", "jFeyr");
      I[118 ^ 53] = I("埐拈", "udzBJ");
      I[196 ^ 128] = I("服唰", "EVSXf");
      I[5 ^ 64] = I("淝侑", "GVUBd");
      I[33 ^ 103] = I("您挕", "lwQDp");
      I[23 ^ 80] = I("搳栗", "tLLnd");
      I[229 ^ 173] = I("漵埮", "YUveE");
      I[41 ^ 96] = I("囇儶", "XUJmD");
      I[59 ^ 113] = I("姘廝", "DccyD");
      I[112 ^ 59] = I("傍斆", "iyJCV");
      I[227 ^ 175] = I("巊弘", "PjGfG");
      I[75 ^ 6] = I("榄妑", "OGGEU");
      I[4 ^ 74] = I("慓亟", "cnjqe");
      I[241 ^ 190] = I("垟拘", "ySLBF");
      I[20 ^ 68] = I("仯櫮", "aEKqf");
      I[35 ^ 114] = I("射洢", "DBXgu");
      I[73 ^ 27] = I("嘲卞", "BhIqy");
      I[197 ^ 150] = I("哖叒", "RkCBc");
      I[198 ^ 146] = I("勯崺悱埓孺", "xOhJY");
      I[251 ^ 174] = I("囹", "oLlTe");
      I[121 ^ 47] = I("嗧烅炝", "guviH");
      I[106 ^ 61] = I("卪愑嫠搾伫", "hoguv");
      I[210 ^ 138] = I("垉梕庀慏殱", "sefHw");
      I[124 ^ 37] = I("煅炏朇控", "OYKak");
      I[37 ^ 127] = I("汃揭晒", "YUzPd");
      I[14 ^ 85] = I("凣啝塯", "jhPnu");
      I[91 ^ 7] = I("暈毟", "gwrEb");
      I[67 ^ 30] = I("仔勌", "uFzsZ");
      I[97 ^ 63] = I("棂毁", "AQsVH");
      I[154 ^ 197] = I("他杞桶懋", "pUrdD");
      I[79 ^ 47] = I("抦桼束", "YyTNW");
      I[204 ^ 173] = I("导", "NGhAq");
      I[87 ^ 53] = I("棷喚兤", "AKENH");
      I[117 ^ 22] = I("僪伻儎啃", "ggfNc");
      I[1 ^ 101] = I("媖晓", "OSsAi");
      I[110 ^ 11] = I("怏栵", "phIQF");
      I[219 ^ 189] = I("岩供", "NmeYU");
      I[32 ^ 71] = I("柔晕", "YdduA");
      I[239 ^ 135] = I("姫楙", "UhVMc");
      I[29 ^ 116] = I("慸媲", "Zgksq");
      I[6 ^ 108] = I("啀楇", "dGHGB");
      I[62 ^ 85] = I("妣液", "WEIKT");
      I[119 ^ 27] = I("恩泖峸", "foEts");
      I[11 ^ 102] = I("堧揍凔愩惌", "tltUD");
      I[97 ^ 15] = I("2\u0000\u0001O\u001dQ\u0011\u0000\u001b\u0000\u0005\b\u0000\u0006I\u0012\t\u0006\u0004\r\u0003\u0004\u0001H\u0006\u0017A\u000e\u0006I\u0018\u000f\u0019\u0001\u001a\u0018\u0003\u0003\rI\u0003\u000e\u0000\u001cH", "qaohi");
      I[200 ^ 167] = I("巔漎柗", "yncxq");
      I[57 ^ 73] = I("嚿昡德淪橕", "WGrni");
      I[16 ^ 97] = I("沑泊棣勁姁", "zBCpe");
      I[117 ^ 7] = I("槵开", "ZvtkZ");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   private void func_192318_a(float var1) {
      String var10000 = I[137 ^ 156];
      String var10001 = I[174 ^ 184];
      String var10002 = I[59 ^ 44];
      var10001 = I[176 ^ 168];
      I[156 ^ 133].length();
      this.field_192336_i += var1;
      Iterator var2 = this.field_192332_e.iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         AdvancementTreeNode var3 = (AdvancementTreeNode)var2.next();
         var3.func_192318_a(var1);
         "".length();
      } while(1 < 4);

      throw null;
   }

   @Nullable
   private AdvancementTreeNode func_192321_c() {
      if (this.field_192334_g != null) {
         return this.field_192334_g;
      } else {
         AdvancementTreeNode var10000;
         if (!this.field_192332_e.isEmpty()) {
            var10000 = (AdvancementTreeNode)this.field_192332_e.get("".length());
            "".length();
            if (2 < 0) {
               throw null;
            }
         } else {
            var10000 = null;
         }

         return var10000;
      }
   }

   static {
      I();
   }

   private float func_192319_a(float var1, int var2, float var3) {
      String var10000 = I[52 ^ 58];
      String var10001 = I[131 ^ 140];
      String var10002 = I[103 ^ 119];
      var10001 = I[212 ^ 197];
      I[9 ^ 27].length();
      I[6 ^ 21].length();
      I[106 ^ 126].length();
      this.field_192336_i += var1;
      this.field_192335_h = var2;
      if (this.field_192336_i < var3) {
         var3 = this.field_192336_i;
      }

      Iterator var4 = this.field_192332_e.iterator();

      do {
         if (!var4.hasNext()) {
            return var3;
         }

         AdvancementTreeNode var5 = (AdvancementTreeNode)var4.next();
         var3 = var5.func_192319_a(var1 + this.field_192337_j, var2 + " ".length(), var3);
         "".length();
      } while(4 == 4);

      throw null;
   }

   private void func_192327_e() {
      if (this.field_192328_a.func_192068_c() != null) {
         this.field_192328_a.func_192068_c().func_192292_a((float)this.field_192335_h, this.field_192336_i);
      }

      if (!this.field_192332_e.isEmpty()) {
         Iterator var1 = this.field_192332_e.iterator();

         while(var1.hasNext()) {
            AdvancementTreeNode var2 = (AdvancementTreeNode)var1.next();
            var2.func_192327_e();
            "".length();
            if (false) {
               throw null;
            }
         }
      }

   }

   private void func_192325_b() {
      String var10000 = I[126 ^ 100];
      String var10001 = I[181 ^ 174];
      String var10002 = I[21 ^ 9];
      var10001 = I[141 ^ 144];
      var10000 = I[31 ^ 1];
      var10001 = I[56 ^ 39];
      var10002 = I[38 ^ 6];
      var10001 = I[102 ^ 71];
      float var1 = 0.0F;
      float var2 = 0.0F;
      int var5 = this.field_192332_e.size();
      int var6 = " ".length();
      I[163 ^ 129].length();
      I[99 ^ 64].length();
      I[96 ^ 68].length();
      int var3 = var5 - var6;

      do {
         if (var3 < 0) {
            return;
         }

         AdvancementTreeNode var4 = (AdvancementTreeNode)this.field_192332_e.get(var3);
         I[10 ^ 47].length();
         I[96 ^ 70].length();
         I[92 ^ 123].length();
         I[26 ^ 50].length();
         var4.field_192336_i += var1;
         I[183 ^ 158].length();
         var4.field_192337_j += var1;
         var2 += var4.field_192338_k;
         var1 += var4.field_192339_l + var2;
         --var3;
         "".length();
      } while(1 >= -1);

      throw null;
   }

   public static void func_192323_a(Advancement var0) {
      String var10000 = I[81 ^ 53];
      String var10001 = I[223 ^ 186];
      String var10002 = I[199 ^ 161];
      var10001 = I[251 ^ 156];
      var10000 = I[44 ^ 68];
      var10001 = I[14 ^ 103];
      var10002 = I[222 ^ 180];
      var10001 = I[10 ^ 97];
      if (var0.func_192068_c() == null) {
         I[81 ^ 61].length();
         I[230 ^ 139].length();
         IllegalArgumentException var3 = new IllegalArgumentException(I[240 ^ 158]);
         I[83 ^ 60].length();
         I[244 ^ 132].length();
         throw var3;
      } else {
         I[222 ^ 175].length();
         I[62 ^ 76].length();
         AdvancementTreeNode var1 = new AdvancementTreeNode(var0, (AdvancementTreeNode)null, (AdvancementTreeNode)null, " ".length(), "".length());
         var1.func_192320_a();
         float var2 = var1.func_192319_a(0.0F, "".length(), var1.field_192336_i);
         if (var2 < 0.0F) {
            var1.func_192318_a(-var2);
         }

         var1.func_192327_e();
      }
   }

   @Nullable
   private AdvancementTreeNode func_192322_a(Advancement var1, @Nullable AdvancementTreeNode var2) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[117 ^ 113];
      if (var1.func_192068_c() != null) {
         I[56 ^ 61].length();
         I[93 ^ 91].length();
         I[58 ^ 61].length();
         var2 = new AdvancementTreeNode(var1, this, var2, this.field_192332_e.size() + " ".length(), this.field_192335_h + " ".length());
         this.field_192332_e.add(var2);
         I[103 ^ 111].length();
         I[100 ^ 109].length();
         I[62 ^ 52].length();
         "".length();
         if (1 >= 2) {
            throw null;
         }
      } else {
         Iterator var3 = var1.func_192069_e().iterator();

         while(var3.hasNext()) {
            Advancement var4 = (Advancement)var3.next();
            var2 = this.func_192322_a(var4, var2);
            "".length();
            if (2 != 2) {
               throw null;
            }
         }
      }

      return var2;
   }

   private AdvancementTreeNode func_192326_a(AdvancementTreeNode var1, AdvancementTreeNode var2) {
      AdvancementTreeNode var10000;
      if (this.field_192333_f != null && var1.field_192329_b.field_192332_e.contains(this.field_192333_f)) {
         var10000 = this.field_192333_f;
         "".length();
         if (2 == 3) {
            throw null;
         }
      } else {
         var10000 = var2;
      }

      return var10000;
   }

   private void func_192316_a(AdvancementTreeNode var1, float var2) {
      String var10000 = I[92 ^ 99];
      String var10001 = I[93 ^ 29];
      String var10002 = I[42 ^ 107];
      var10001 = I[230 ^ 164];
      var10000 = I[32 ^ 99];
      var10001 = I[192 ^ 132];
      var10002 = I[112 ^ 53];
      var10001 = I[63 ^ 121];
      var10000 = I[43 ^ 108];
      var10001 = I[6 ^ 78];
      var10002 = I[51 ^ 122];
      var10001 = I[10 ^ 64];
      var10000 = I[253 ^ 182];
      var10001 = I[70 ^ 10];
      var10002 = I[197 ^ 136];
      var10001 = I[140 ^ 194];
      var10000 = I[26 ^ 85];
      var10001 = I[193 ^ 145];
      var10002 = I[239 ^ 190];
      var10001 = I[117 ^ 39];
      int var4 = var1.field_192331_d;
      int var6 = this.field_192331_d;
      I[79 ^ 28].length();
      I[247 ^ 163].length();
      I[21 ^ 64].length();
      float var3 = (float)(var4 - var6);
      if (var3 != 0.0F) {
         I[237 ^ 187].length();
         I[104 ^ 63].length();
         float var7 = var1.field_192338_k;
         float var5 = var2 / var3;
         I[11 ^ 83].length();
         I[126 ^ 39].length();
         I[209 ^ 139].length();
         var1.field_192338_k = var7 - var5;
         I[53 ^ 110].length();
         I[60 ^ 96].length();
         this.field_192338_k += var2 / var3;
      }

      I[48 ^ 109].length();
      I[21 ^ 75].length();
      I[42 ^ 117].length();
      I[81 ^ 49].length();
      var1.field_192339_l += var2;
      I[247 ^ 150].length();
      I[164 ^ 198].length();
      var1.field_192336_i += var2;
      I[243 ^ 144].length();
      var1.field_192337_j += var2;
   }

   private void func_192320_a() {
      if (this.field_192332_e.isEmpty()) {
         if (this.field_192330_c != null) {
            this.field_192336_i = this.field_192330_c.field_192336_i + 1.0F;
            "".length();
            if (3 < 1) {
               throw null;
            }
         } else {
            this.field_192336_i = 0.0F;
            "".length();
            if (2 >= 4) {
               throw null;
            }
         }
      } else {
         AdvancementTreeNode var1 = null;
         Iterator var2 = this.field_192332_e.iterator();

         while(var2.hasNext()) {
            AdvancementTreeNode var3 = (AdvancementTreeNode)var2.next();
            var3.func_192320_a();
            AdvancementTreeNode var10001;
            if (var1 == null) {
               var10001 = var3;
               "".length();
               if (-1 >= 0) {
                  throw null;
               }
            } else {
               var10001 = var1;
            }

            var1 = var3.func_192324_a(var10001);
            "".length();
            if (1 >= 3) {
               throw null;
            }
         }

         this.func_192325_b();
         float var10000 = ((AdvancementTreeNode)this.field_192332_e.get("".length())).field_192336_i;
         List var5 = this.field_192332_e;
         int var10002 = this.field_192332_e.size();
         int var10003 = " ".length();
         I[140 ^ 135].length();
         float var4 = (var10000 + ((AdvancementTreeNode)var5.get(var10002 - var10003)).field_192336_i) / 2.0F;
         if (this.field_192330_c != null) {
            this.field_192336_i = this.field_192330_c.field_192336_i + 1.0F;
            float var6 = this.field_192336_i;
            I[37 ^ 41].length();
            I[204 ^ 193].length();
            this.field_192337_j = var6 - var4;
            "".length();
            if (1 == 4) {
               throw null;
            }
         } else {
            this.field_192336_i = var4;
         }
      }

   }

   @Nullable
   private AdvancementTreeNode func_192317_d() {
      if (this.field_192334_g != null) {
         return this.field_192334_g;
      } else {
         AdvancementTreeNode var1;
         if (!this.field_192332_e.isEmpty()) {
            List var10000 = this.field_192332_e;
            int var10001 = this.field_192332_e.size();
            int var10002 = " ".length();
            I[12 ^ 38].length();
            I[28 ^ 55].length();
            var1 = (AdvancementTreeNode)var10000.get(var10001 - var10002);
            "".length();
            if (1 <= 0) {
               throw null;
            }
         } else {
            var1 = null;
         }

         return var1;
      }
   }

   public AdvancementTreeNode(Advancement var1, @Nullable AdvancementTreeNode var2, @Nullable AdvancementTreeNode var3, int var4, int var5) {
      if (var1.func_192068_c() == null) {
         throw new IllegalArgumentException(I["".length()]);
      } else {
         this.field_192328_a = var1;
         this.field_192329_b = var2;
         this.field_192330_c = var3;
         this.field_192331_d = var4;
         this.field_192333_f = this;
         this.field_192335_h = var5;
         this.field_192336_i = -1.0F;
         AdvancementTreeNode var6 = null;
         Iterator var7 = var1.func_192069_e().iterator();

         do {
            if (!var7.hasNext()) {
               return;
            }

            Advancement var8 = (Advancement)var7.next();
            var6 = this.func_192322_a(var8, var6);
            "".length();
         } while(2 != -1);

         throw null;
      }
   }
}

package net.minecraft.block;

import com.google.common.base.Predicate;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityComparator;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockRedstoneComparator extends BlockRedstoneDiode implements ITileEntityProvider {
   // $FF: synthetic field
   public static final PropertyBool POWERED;
   // $FF: synthetic field
   public static final PropertyEnum<BlockRedstoneComparator.Mode> MODE;
   // $FF: synthetic field
   private static final String[] I;

   protected void updateState(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isBlockTickPending(var2, this)) {
         int var4 = this.calculateOutput(var1, var2, var3);
         TileEntity var5 = var1.getTileEntity(var2);
         int var10000;
         if (var5 instanceof TileEntityComparator) {
            var10000 = ((TileEntityComparator)var5).getOutputSignal();
            "".length();
            if (4 <= 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         int var6 = var10000;
         if (var4 != var6 || this.isPowered(var3) != this.shouldBePowered(var1, var2, var3)) {
            if (this.isFacingTowardsRepeater(var1, var2, var3)) {
               var1.updateBlockTick(var2, this, "  ".length(), -" ".length());
               "".length();
               if (4 <= 1) {
                  throw null;
               }
            } else {
               var1.updateBlockTick(var2, this, "  ".length(), "".length());
            }
         }
      }

   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, EnumFacing.byHorizontalIndex(var1));
      PropertyBool var10001 = POWERED;
      int var10002;
      if ((var1 & (112 ^ 120)) > 0) {
         var10002 = " ".length();
         "".length();
         if (4 <= -1) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      PropertyEnum var2 = MODE;
      BlockRedstoneComparator.Mode var3;
      if ((var1 & (27 ^ 31)) > 0) {
         var3 = BlockRedstoneComparator.Mode.SUBTRACT;
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var3 = BlockRedstoneComparator.Mode.COMPARE;
      }

      return var10000.withProperty(var2, var3);
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      super.onBlockAdded(var1, var2, var3);
      var1.setTileEntity(var2, this.createNewTileEntity(var1, "".length()));
   }

   private void onStateChange(World var1, BlockPos var2, IBlockState var3) {
      int var4 = this.calculateOutput(var1, var2, var3);
      TileEntity var5 = var1.getTileEntity(var2);
      int var6 = "".length();
      if (var5 instanceof TileEntityComparator) {
         TileEntityComparator var7 = (TileEntityComparator)var5;
         var6 = var7.getOutputSignal();
         var7.setOutputSignal(var4);
      }

      if (var6 != var4 || var3.getValue(MODE) == BlockRedstoneComparator.Mode.COMPARE) {
         boolean var9 = this.shouldBePowered(var1, var2, var3);
         boolean var8 = this.isPowered(var3);
         if (var8 && !var9) {
            var1.setBlockState(var2, var3.withProperty(POWERED, Boolean.valueOf((boolean)"".length())), "  ".length());
            I[83 ^ 72].length();
            I[159 ^ 131].length();
            I[41 ^ 52].length();
            "".length();
            if (4 == 0) {
               throw null;
            }
         } else if (!var8 && var9) {
            var1.setBlockState(var2, var3.withProperty(POWERED, Boolean.valueOf((boolean)" ".length())), "  ".length());
            I[119 ^ 105].length();
            I[110 ^ 113].length();
            I[96 ^ 64].length();
         }

         this.notifyNeighbors(var1, var2, var3);
      }

   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (this.isRepeaterPowered) {
         var1.setBlockState(var2, this.getUnpoweredState(var3).withProperty(POWERED, Boolean.valueOf((boolean)" ".length())), 56 ^ 60);
         I[66 ^ 99].length();
         I[78 ^ 108].length();
         I[69 ^ 102].length();
      }

      this.onStateChange(var1, var2, var3);
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[108 ^ 74];
      String var10001 = I[91 ^ 124];
      String var10002 = I[70 ^ 110];
      var10001 = I[162 ^ 139];
      I[9 ^ 35].length();
      I[172 ^ 135].length();
      I[171 ^ 135].length();
      return new TileEntityComparator();
   }

   protected IBlockState getPoweredState(IBlockState var1) {
      Boolean var2 = (Boolean)var1.getValue(POWERED);
      BlockRedstoneComparator.Mode var3 = (BlockRedstoneComparator.Mode)var1.getValue(MODE);
      EnumFacing var4 = (EnumFacing)var1.getValue(FACING);
      return Blocks.POWERED_COMPARATOR.getDefaultState().withProperty(FACING, var4).withProperty(POWERED, var2).withProperty(MODE, var3);
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
      if ((Boolean)var1.getValue(POWERED)) {
         var2 |= 40 ^ 32;
      }

      if (var1.getValue(MODE) == BlockRedstoneComparator.Mode.SUBTRACT) {
         var2 |= 148 ^ 144;
      }

      return var2;
   }

   protected boolean shouldBePowered(World var1, BlockPos var2, IBlockState var3) {
      int var4 = this.calculateInputStrength(var1, var2, var3);
      if (var4 >= (152 ^ 151)) {
         return (boolean)" ".length();
      } else if (var4 == 0) {
         return (boolean)"".length();
      } else {
         int var5 = this.getPowerOnSides(var1, var2, var3);
         if (var5 == 0) {
            return (boolean)" ".length();
         } else {
            int var10000;
            if (var4 >= var5) {
               var10000 = " ".length();
               "".length();
               if (3 <= 1) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      }
   }

   protected int calculateInputStrength(World var1, BlockPos var2, IBlockState var3) {
      int var4 = super.calculateInputStrength(var1, var2, var3);
      EnumFacing var5 = (EnumFacing)var3.getValue(FACING);
      BlockPos var6 = var2.offset(var5);
      IBlockState var7 = var1.getBlockState(var6);
      if (var7.hasComparatorInputOverride()) {
         var4 = var7.getComparatorInputOverride(var1, var6);
         "".length();
         if (0 >= 3) {
            throw null;
         }
      } else if (var4 < (127 ^ 112) && var7.isNormalCube()) {
         var6 = var6.offset(var5);
         var7 = var1.getBlockState(var6);
         if (var7.hasComparatorInputOverride()) {
            var4 = var7.getComparatorInputOverride(var1, var6);
            "".length();
            if (2 < 1) {
               throw null;
            }
         } else if (var7.getMaterial() == Material.AIR) {
            EntityItemFrame var8 = this.findItemFrame(var1, var5, var6);
            if (var8 != null) {
               var4 = var8.getAnalogOutput();
            }
         }
      }

      return var4;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   protected int getActiveSignal(IBlockAccess var1, BlockPos var2, IBlockState var3) {
      TileEntity var4 = var1.getTileEntity(var2);
      int var10000;
      if (var4 instanceof TileEntityComparator) {
         var10000 = ((TileEntityComparator)var4).getOutputSignal();
         "".length();
         if (0 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   public BlockRedstoneComparator(boolean var1) {
      super(var1);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(POWERED, Boolean.valueOf((boolean)"".length())).withProperty(MODE, BlockRedstoneComparator.Mode.COMPARE));
      this.isBlockContainer = (boolean)" ".length();
   }

   public boolean eventReceived(IBlockState var1, World var2, BlockPos var3, int var4, int var5) {
      super.eventReceived(var1, var2, var3, var4, var5);
      I[126 ^ 90].length();
      I[81 ^ 116].length();
      TileEntity var6 = var2.getTileEntity(var3);
      int var10000;
      if (var6 == null) {
         var10000 = "".length();
         "".length();
         if (4 < 3) {
            throw null;
         }
      } else {
         var10000 = var6.receiveClientEvent(var4, var5);
      }

      return (boolean)var10000;
   }

   private int calculateOutput(World var1, BlockPos var2, IBlockState var3) {
      int var10000;
      if (var3.getValue(MODE) == BlockRedstoneComparator.Mode.SUBTRACT) {
         var10000 = this.calculateInputStrength(var1, var2, var3);
         int var10001 = this.getPowerOnSides(var1, var2, var3);
         I[1 ^ 6].length();
         I[149 ^ 157].length();
         var10000 = Math.max(var10000 - var10001, "".length());
         "".length();
         if (-1 != -1) {
            throw null;
         }
      } else {
         var10000 = this.calculateInputStrength(var1, var2, var3);
      }

      return var10000;
   }

   static {
      I();
      POWERED = PropertyBool.create(I[122 ^ 63]);
      MODE = PropertyEnum.create(I[227 ^ 165], BlockRedstoneComparator.Mode.class);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (!var4.capabilities.allowEdit) {
         return (boolean)"".length();
      } else {
         var3 = var3.cycleProperty(MODE);
         float var10000;
         if (var3.getValue(MODE) == BlockRedstoneComparator.Mode.SUBTRACT) {
            var10000 = 0.55F;
            "".length();
            if (4 == 2) {
               throw null;
            }
         } else {
            var10000 = 0.5F;
         }

         float var10 = var10000;
         var1.playSound(var4, var2, SoundEvents.BLOCK_COMPARATOR_CLICK, SoundCategory.BLOCKS, 0.3F, var10);
         var1.setBlockState(var2, var3, "  ".length());
         I[159 ^ 135].length();
         I[62 ^ 39].length();
         I[181 ^ 175].length();
         this.onStateChange(var1, var2, var3);
         return (boolean)" ".length();
      }
   }

   protected IBlockState getUnpoweredState(IBlockState var1) {
      Boolean var2 = (Boolean)var1.getValue(POWERED);
      BlockRedstoneComparator.Mode var3 = (BlockRedstoneComparator.Mode)var1.getValue(MODE);
      EnumFacing var4 = (EnumFacing)var1.getValue(FACING);
      return Blocks.UNPOWERED_COMPARATOR.getDefaultState().withProperty(FACING, var4).withProperty(POWERED, var2).withProperty(MODE, var3);
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[42 ^ 46];
      I[35 ^ 38].length();
      I[74 ^ 76].length();
      return new ItemStack(Items.COMPARATOR);
   }

   protected boolean isPowered(IBlockState var1) {
      int var10000;
      if (!this.isRepeaterPowered && !(Boolean)var1.getValue(POWERED)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public String getLocalizedName() {
      return I18n.translateToLocal(I["".length()]);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 > 0);

      throw null;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.COMPARATOR;
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, var8.getHorizontalFacing().getOpposite()).withProperty(POWERED, Boolean.valueOf((boolean)"".length())).withProperty(MODE, BlockRedstoneComparator.Mode.COMPARE);
   }

   @Nullable
   private EntityItemFrame findItemFrame(World var1, final EnumFacing var2, BlockPos var3) {
      String var10000 = I[78 ^ 71];
      String var10001 = I[183 ^ 189];
      String var10002 = I[161 ^ 170];
      var10001 = I[99 ^ 111];
      var10000 = I[60 ^ 49];
      var10001 = I[129 ^ 143];
      var10002 = I[10 ^ 5];
      var10001 = I[109 ^ 125];
      I[68 ^ 85].length();
      I[33 ^ 51].length();
      I[177 ^ 162].length();
      I[17 ^ 5].length();
      AxisAlignedBB var6 = new AxisAlignedBB((double)var3.getX(), (double)var3.getY(), (double)var3.getZ(), (double)(var3.getX() + " ".length()), (double)(var3.getY() + " ".length()), (double)(var3.getZ() + " ".length()));
      I[153 ^ 140].length();
      I[65 ^ 87].length();
      I[27 ^ 12].length();
      List var4 = var1.getEntitiesWithinAABB(EntityItemFrame.class, var6, new Predicate<Entity>() {
         public boolean apply(@Nullable Entity var1) {
            int var10000;
            if (var1 != null && var1.getHorizontalFacing() == var2) {
               var10000 = " ".length();
               "".length();
               if (false) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 >= 2);

            throw null;
         }
      });
      EntityItemFrame var5;
      if (var4.size() == " ".length()) {
         var5 = (EntityItemFrame)var4.get("".length());
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var5 = null;
      }

      return var5;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   protected int getDelay(IBlockState var1) {
      return "  ".length();
   }

   private static void I() {
      I = new String[98 ^ 37];
      I["".length()] = I("'\u0005\u0013\"L-\u001e\u001b?\u0003<\u0010\u0002 \u0010`\u001f\u0017\"\u0007", "NqvOb");
      I[" ".length()] = I("樋果", "BdNhe");
      I["  ".length()] = I("儈徤", "DTGur");
      I["   ".length()] = I("履傟", "IVDKD");
      I[23 ^ 19] = I("慸划", "rsYUm");
      I[165 ^ 160] = I("汳她", "eEYGM");
      I[189 ^ 187] = I("棬料厾差僕", "qIBhG");
      I[191 ^ 184] = I("喜火", "uEkOs");
      I[68 ^ 76] = I("伦擵埀幵", "UKUXT");
      I[35 ^ 42] = I("年捋", "QPnWk");
      I[42 ^ 32] = I("奖浭", "dUIxa");
      I[172 ^ 167] = I("撝愌", "JFoDX");
      I[121 ^ 117] = I("壢擧", "oOxSb");
      I[138 ^ 135] = I("仛灎", "wRrRG");
      I[19 ^ 29] = I("毺泝", "uUDfu");
      I[158 ^ 145] = I("昪暵", "Ucbnx");
      I[128 ^ 144] = I("撗咤", "qvddz");
      I[10 ^ 27] = I("信", "ZwGUE");
      I[157 ^ 143] = I("啨宪嵍", "JpGLq");
      I[208 ^ 195] = I("垖慴媉", "AOjYR");
      I[208 ^ 196] = I("煪瀳伞", "nlwac");
      I[18 ^ 7] = I("扤境", "oGUfP");
      I[132 ^ 146] = I("宯灤扽洫毺", "iZWvY");
      I[122 ^ 109] = I("卆嗵垼俀囆", "pJkYi");
      I[143 ^ 151] = I("徘屻庽洪", "EsDPD");
      I[123 ^ 98] = I("昼", "YVvsa");
      I[116 ^ 110] = I("梙", "EzxMd");
      I[172 ^ 183] = I("仔", "eknna");
      I[6 ^ 26] = I("旀凬佈", "cZpjW");
      I[96 ^ 125] = I("怸", "hJYFM");
      I[217 ^ 199] = I("忿姲", "EqSug");
      I[18 ^ 13] = I("卛仍", "tkwFG");
      I[27 ^ 59] = I("剮伟撀", "vBnHQ");
      I[21 ^ 52] = I("厊", "PRDrW");
      I[68 ^ 102] = I("榈帛", "gOmAs");
      I[47 ^ 12] = I("準", "MWxcS");
      I[84 ^ 112] = I("瀯埧", "jTsVs");
      I[129 ^ 164] = I("溛汥勤朄", "vvskb");
      I[91 ^ 125] = I("军棞", "rWVzz");
      I[47 ^ 8] = I("栝濗", "ADyjK");
      I[31 ^ 55] = I("晣搥", "ByXYV");
      I[15 ^ 38] = I("炛杢", "siIqX");
      I[2 ^ 40] = I("沛汿怯丮", "ObEQp");
      I[47 ^ 4] = I("昈桹", "Anzye");
      I[22 ^ 58] = I("恑悐叧", "nNfDk");
      I[43 ^ 6] = I("勌櫘", "FrCvG");
      I[9 ^ 39] = I("枷俑", "BeKWT");
      I[171 ^ 132] = I("懫敛", "HaiQm");
      I[240 ^ 192] = I("朹杛", "yGhrf");
      I[153 ^ 168] = I("寉圚", "IvjrZ");
      I[50 ^ 0] = I("潺敲", "Zwunc");
      I[81 ^ 98] = I("営旿", "TirLB");
      I[123 ^ 79] = I("有來", "rWknS");
      I[157 ^ 168] = I("兆基", "cVJcp");
      I[167 ^ 145] = I("瀪汦", "Nnmvn");
      I[123 ^ 76] = I("悙憴", "WkyCF");
      I[77 ^ 117] = I("儓垹", "zOizd");
      I[141 ^ 180] = I("欵使", "UjtNU");
      I[89 ^ 99] = I("敜澻", "TpHHL");
      I[61 ^ 6] = I("密染", "zhWbJ");
      I[179 ^ 143] = I("棙显", "DhnGF");
      I[5 ^ 56] = I("嘞", "CroES");
      I[20 ^ 42] = I("慫", "hulTO");
      I[189 ^ 130] = I("咩", "BygLH");
      I[8 ^ 72] = I("偅岏曑供", "WmgyU");
      I[100 ^ 37] = I("弤", "PcTul");
      I[50 ^ 112] = I("喋灄嶃偂尩", "fzIic");
      I[3 ^ 64] = I("浈俽帙州湍", "QlLhJ");
      I[30 ^ 90] = I("汆", "LQhTM");
      I[77 ^ 8] = I("\u0004\u000e6<&\u0011\u0005", "taAYT");
      I[52 ^ 114] = I(".\u0007\u0014!", "ChpDo");
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[112 ^ 93];
      String var10001 = I[57 ^ 23];
      String var10002 = I[174 ^ 129];
      var10001 = I[105 ^ 89];
      var10000 = I[176 ^ 129];
      var10001 = I[97 ^ 83];
      var10002 = I[159 ^ 172];
      var10001 = I[242 ^ 198];
      var10000 = I[12 ^ 57];
      var10001 = I[131 ^ 181];
      var10002 = I[168 ^ 159];
      var10001 = I[60 ^ 4];
      var10000 = I[74 ^ 115];
      var10001 = I[137 ^ 179];
      var10002 = I[124 ^ 71];
      var10001 = I[28 ^ 32];
      I[253 ^ 192].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[132 ^ 186].length();
      I[31 ^ 32].length();
      I[42 ^ 106].length();
      var10003["".length()] = FACING;
      I[100 ^ 37].length();
      var10003[" ".length()] = MODE;
      I[55 ^ 117].length();
      I[28 ^ 95].length();
      I[194 ^ 134].length();
      var10003["  ".length()] = POWERED;
      return new BlockStateContainer(this, var10003);
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      super.breakBlock(var1, var2, var3);
      var1.removeTileEntity(var2);
      this.notifyNeighbors(var1, var2, var3);
   }

   public static enum Mode implements IStringSerializable {
      // $FF: synthetic field
      SUBTRACT;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      COMPARE;

      private static void I() {
         I = new String[44 ^ 40];
         I["".length()] = I("\u000e!\u0005)\u0012\u001f+", "MnHyS");
         I[" ".length()] = I("\"8&4$32", "AWKDE");
         I["  ".length()] = I("\u0010\r-&1\u0002\u001b;", "CXorc");
         I["   ".length()] = I("=#8,0/5.", "NVZXB");
      }

      static {
         I();
         COMPARE = new BlockRedstoneComparator.Mode(I["".length()], "".length(), I[" ".length()]);
         SUBTRACT = new BlockRedstoneComparator.Mode(I["  ".length()], " ".length(), I["   ".length()]);
         BlockRedstoneComparator.Mode[] var10000 = new BlockRedstoneComparator.Mode["  ".length()];
         var10000["".length()] = COMPARE;
         var10000[" ".length()] = SUBTRACT;
      }

      private Mode(String var3) {
         this.name = var3;
      }

      public String toString() {
         return this.name;
      }

      public String getName() {
         return this.name;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 >= 0);

         throw null;
      }
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketSpawnExperienceOrb implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private double posY;
   // $FF: synthetic field
   private int xpValue;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private double posZ;
   // $FF: synthetic field
   private int entityID;
   // $FF: synthetic field
   private double posX;

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityID = var1.readVarIntFromBuffer();
      this.posX = var1.readDouble();
      this.posY = var1.readDouble();
      this.posZ = var1.readDouble();
      this.xpValue = var1.readShort();
   }

   public double getX() {
      return this.posX;
   }

   public SPacketSpawnExperienceOrb(EntityXPOrb var1) {
      this.entityID = var1.getEntityId();
      this.posX = var1.posX;
      this.posY = var1.posY;
      this.posZ = var1.posZ;
      this.xpValue = var1.getXpValue();
   }

   public SPacketSpawnExperienceOrb() {
   }

   public double getZ() {
      return this.posZ;
   }

   public int getXPValue() {
      return this.xpValue;
   }

   public int getEntityID() {
      return this.entityID;
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityID);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeDouble(this.posX);
      I["   ".length()].length();
      I[96 ^ 100].length();
      I[65 ^ 68].length();
      I[199 ^ 193].length();
      var1.writeDouble(this.posY);
      I[100 ^ 99].length();
      I[184 ^ 176].length();
      I[41 ^ 32].length();
      var1.writeDouble(this.posZ);
      I[55 ^ 61].length();
      I[88 ^ 83].length();
      var1.writeShort(this.xpValue);
      I[46 ^ 34].length();
      I[37 ^ 40].length();
      I[69 ^ 75].length();
      I[148 ^ 155].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 0);

      throw null;
   }

   public double getY() {
      return this.posY;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSpawnExperienceOrb(this);
   }

   private static void I() {
      I = new String[66 ^ 82];
      I["".length()] = I("墈嚌徾惁沚", "UvqAm");
      I[" ".length()] = I("炎寈湺吞佷", "Lbuym");
      I["  ".length()] = I("亀捒朇孬叇", "lGYoY");
      I["   ".length()] = I("丂併淉", "FRzXr");
      I[185 ^ 189] = I("岘嚳民", "zTVci");
      I[4 ^ 1] = I("灬", "jBHSs");
      I[138 ^ 140] = I("嬅卵桱橑", "xuGDX");
      I[16 ^ 23] = I("昨斻暨", "hWHXm");
      I[101 ^ 109] = I("洈凄塟桋", "mJvaI");
      I[76 ^ 69] = I("瀶", "QItxJ");
      I[135 ^ 141] = I("剅侲", "rcjvK");
      I[136 ^ 131] = I("炣", "YWIJo");
      I[4 ^ 8] = I("婗极", "lcQLU");
      I[76 ^ 65] = I("垣", "ACwxj");
      I[120 ^ 118] = I("哄", "kvMlB");
      I[36 ^ 43] = I("婁傹戅喫沃", "hIxHw");
   }
}

package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;

public class LevitationTrigger implements ICriterionTrigger<LevitationTrigger.Instance> {
   // $FF: synthetic field
   private final Map<PlayerAdvancements, LevitationTrigger.Listeners> field_193165_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final ResourceLocation field_193164_a;
   // $FF: synthetic field
   private static final String[] I;

   public ResourceLocation func_192163_a() {
      return field_193164_a;
   }

   public void func_193162_a(EntityPlayerMP var1, Vec3d var2, int var3) {
      LevitationTrigger.Listeners var4 = (LevitationTrigger.Listeners)this.field_193165_b.get(var1.func_192039_O());
      if (var4 != null) {
         var4.func_193448_a(var1, var2, var3);
      }

   }

   private static void I() {
      I = new String[52 ^ 35];
      I["".length()] = I("巇杢", "rFaZu");
      I[" ".length()] = I("恚溅", "VJfiJ");
      I["  ".length()] = I("嵾乻", "XAuce");
      I["   ".length()] = I("品兜", "gEEUU");
      I[19 ^ 23] = I("媺嚘儾烈", "pOmZw");
      I[99 ^ 102] = I("戎梣懆楧歫", "IgujX");
      I[26 ^ 28] = I("劼澈潏拀", "DIJur");
      I[141 ^ 138] = I("毷刨暙俣倰", "Esrwg");
      I[80 ^ 88] = I("帩偝廲冪", "zTRAM");
      I[176 ^ 185] = I("懅", "pYLhk");
      I[79 ^ 69] = I("偅昰櫪", "JeMji");
      I[18 ^ 25] = I("侃惊地", "oOzIB");
      I[38 ^ 42] = I("哱", "kroSp");
      I[46 ^ 35] = I("洺付", "nFVNH");
      I[115 ^ 125] = I("扽溊", "VPakT");
      I[201 ^ 198] = I("搸且", "azJZe");
      I[62 ^ 46] = I("滯搀", "JoIwN");
      I[184 ^ 169] = I("<>\u001b%&64\r", "XWhQG");
      I[123 ^ 105] = I("/\u001d \u000e'\"\u0007<", "KhRoS");
      I[190 ^ 173] = I("樚嶉", "PLimp");
      I[30 ^ 10] = I("嫿烜哾噀哏", "fpNik");
      I[173 ^ 184] = I("愼柀垷沋", "bGwmY");
      I[90 ^ 76] = I("\u00182\u00011%\u0015#\u001e7?", "tWwXQ");
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<LevitationTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      LevitationTrigger.Listeners var3 = (LevitationTrigger.Listeners)this.field_193165_b.get(var1);
      if (var3 == null) {
         I[101 ^ 97].length();
         I[177 ^ 180].length();
         I[138 ^ 140].length();
         var3 = new LevitationTrigger.Listeners(var1);
         this.field_193165_b.put(var1, var3);
         I[42 ^ 45].length();
      }

      var3.func_193449_a(var2);
   }

   static {
      I();
      field_193164_a = new ResourceLocation(I[45 ^ 59]);
   }

   public LevitationTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[91 ^ 86];
      String var10001 = I[29 ^ 19];
      String var10002 = I[148 ^ 155];
      var10001 = I[152 ^ 136];
      DistancePredicate var3 = DistancePredicate.func_193421_a(var1.get(I[132 ^ 149]));
      MinMaxBounds var4 = MinMaxBounds.func_192515_a(var1.get(I[187 ^ 169]));
      I[82 ^ 65].length();
      I[10 ^ 30].length();
      I[26 ^ 15].length();
      return new LevitationTrigger.Instance(var3, var4);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 4);

      throw null;
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193165_b.remove(var1);
      I[158 ^ 146].length();
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<LevitationTrigger.Instance> var2) {
      LevitationTrigger.Listeners var3 = (LevitationTrigger.Listeners)this.field_193165_b.get(var1);
      if (var3 != null) {
         var3.func_193446_b(var2);
         if (var3.func_193447_a()) {
            this.field_193165_b.remove(var1);
            I[53 ^ 61].length();
            I[186 ^ 179].length();
            I[202 ^ 192].length();
            I[12 ^ 7].length();
         }
      }

   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_193450_a;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<LevitationTrigger.Instance>> field_193451_b = Sets.newHashSet();

      public boolean func_193447_a() {
         return this.field_193451_b.isEmpty();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193450_a = var1;
      }

      public void func_193446_b(ICriterionTrigger.Listener<LevitationTrigger.Instance> var1) {
         this.field_193451_b.remove(var1);
         I["   ".length()].length();
      }

      static {
         I();
      }

      public void func_193448_a(EntityPlayerMP var1, Vec3d var2, int var3) {
         ArrayList var4 = null;
         Iterator var5 = this.field_193451_b.iterator();

         ICriterionTrigger.Listener var6;
         while(var5.hasNext()) {
            var6 = (ICriterionTrigger.Listener)var5.next();
            if (((LevitationTrigger.Instance)var6.func_192158_a()).func_193201_a(var1, var2, var3)) {
               if (var4 == null) {
                  var4 = Lists.newArrayList();
               }

               var4.add(var6);
               I[76 ^ 72].length();
            }

            "".length();
            if (false) {
               throw null;
            }
         }

         if (var4 != null) {
            var5 = var4.iterator();

            while(var5.hasNext()) {
               var6 = (ICriterionTrigger.Listener)var5.next();
               var6.func_192159_a(this.field_193450_a);
               "".length();
               if (2 >= 4) {
                  throw null;
               }
            }
         }

      }

      private static void I() {
         I = new String[191 ^ 186];
         I["".length()] = I("搈悿栍倐", "MWkzf");
         I[" ".length()] = I("恖抵吒幝僴", "GFTZA");
         I["  ".length()] = I("情嗜嗌掭", "GQxjL");
         I["   ".length()] = I("漟亠椤佛", "DjHkD");
         I[139 ^ 143] = I("檁", "uYWnu");
      }

      public void func_193449_a(ICriterionTrigger.Listener<LevitationTrigger.Instance> var1) {
         this.field_193451_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 == 4);

         throw null;
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final MinMaxBounds field_193203_b;
      // $FF: synthetic field
      private final DistancePredicate field_193202_a;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 >= -1);

         throw null;
      }

      public boolean func_193201_a(EntityPlayerMP var1, Vec3d var2, int var3) {
         return (boolean)(!this.field_193202_a.func_193422_a(var2.x, var2.y, var2.z, var1.posX, var1.posY, var1.posZ) ? "".length() : this.field_193203_b.func_192514_a((float)var3));
      }

      public Instance(DistancePredicate var1, MinMaxBounds var2) {
         super(LevitationTrigger.field_193164_a);
         this.field_193202_a = var1;
         this.field_193203_b = var2;
      }
   }
}

package net.minecraft.block;

import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockGlazedTerracotta extends BlockHorizontal {
   // $FF: synthetic field
   private static final String[] I;

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public EnumPushReaction getMobilityFlag(IBlockState var1) {
      return EnumPushReaction.PUSH_ONLY;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 3);

      throw null;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.byHorizontalIndex(var1));
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
      return var2;
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, var8.getHorizontalFacing().getOpposite());
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   private static void I() {
      I = new String[148 ^ 155];
      I["".length()] = I("\u0013\u00199\u001b \u0010!=\u00137\u0015\u00167\u00151\u0015", "tuXaE");
      I[" ".length()] = I("慏湡", "dfpZA");
      I["  ".length()] = I("屟恿", "AAbRE");
      I["   ".length()] = I("樍宎", "TXrzh");
      I[75 ^ 79] = I("徻悶", "ZJIdJ");
      I[23 ^ 18] = I("帟刹", "zSmzu");
      I[150 ^ 144] = I("撸堵", "xKrPx");
      I[2 ^ 5] = I("巙媻", "SaIsZ");
      I[40 ^ 32] = I("滨嗚", "qcdKN");
      I[168 ^ 161] = I("悰嘮", "QRbtq");
      I[98 ^ 104] = I("桲愢", "PksNh");
      I[103 ^ 108] = I("攬彗", "VfDFi");
      I[4 ^ 8] = I("忲憼攉堀僶", "hhuta");
      I[67 ^ 78] = I("憉内", "RDpnS");
      I[29 ^ 19] = I("怵仂擡主", "WxBIX");
   }

   static {
      I();
   }

   public BlockGlazedTerracotta(EnumDyeColor var1) {
      super(Material.ROCK, MapColor.func_193558_a(var1));
      this.setHardness(1.4F);
      this.setSoundType(SoundType.STONE);
      String var2 = var1.getUnlocalizedName();
      if (var2.length() > " ".length()) {
         String var3 = var2.substring("".length(), " ".length()).toUpperCase() + var2.substring(" ".length(), var2.length());
         this.setUnlocalizedName(I["".length()] + var3);
      }

      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[129 ^ 133];
      var10000 = I[40 ^ 45];
      var10001 = I[164 ^ 162];
      var10002 = I[104 ^ 111];
      var10001 = I[31 ^ 23];
      I[141 ^ 132].length();
      I[29 ^ 23].length();
      I[106 ^ 97].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[151 ^ 155].length();
      I[83 ^ 94].length();
      I[158 ^ 144].length();
      var10003["".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }
}

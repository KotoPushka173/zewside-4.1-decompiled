package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentBindingCurse extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   public EnchantmentBindingCurse(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.WEARABLE, var2);
      this.setName(I["".length()]);
   }

   public int getMaxEnchantability(int var1) {
      return 45 ^ 31;
   }

   public boolean isTreasureEnchantment() {
      return (boolean)" ".length();
   }

   public boolean func_190936_d() {
      return (boolean)" ".length();
   }

   static {
      I();
   }

   public int getMaxLevel() {
      return " ".length();
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("\u0017\u001f!\"\"\u001b\u0011\u0010%>\u0007\u0005*", "uvOFK");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public int getMinEnchantability(int var1) {
      return 137 ^ 144;
   }
}

package net.minecraft.block;

import java.util.Iterator;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockLadder extends Block {
   // $FF: synthetic field
   protected static final AxisAlignedBB LADDER_EAST_AABB;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB LADDER_WEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB LADDER_SOUTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB LADDER_NORTH_AABB;

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
         return LADDER_NORTH_AABB;
      case 2:
         return LADDER_SOUTH_AABB;
      case 3:
         return LADDER_WEST_AABB;
      case 4:
      default:
         return LADDER_EAST_AABB;
      }
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   private static void I() {
      I = new String[143 ^ 128];
      I["".length()] = I("槒巜嚴", "rkGdV");
      I[" ".length()] = I("激亸嚡毾", "TtJHY");
      I["  ".length()] = I("孍懠儽汥", "roHXW");
      I["   ".length()] = I("唔倘", "rLjHe");
      I[88 ^ 92] = I("娓堙", "OROpw");
      I[140 ^ 137] = I("恖咝", "KwEsr");
      I[146 ^ 148] = I("嫐尞", "pKCSq");
      I[129 ^ 134] = I("內斟", "hwwzh");
      I[23 ^ 31] = I("瀿柡", "aBjXl");
      I[137 ^ 128] = I("孫慌", "cAINM");
      I[154 ^ 144] = I("坯呔", "PjTZl");
      I[104 ^ 99] = I("嘩", "vKBwy");
      I[120 ^ 116] = I("挹淿", "mayMv");
      I[50 ^ 63] = I("摢掵椘濿", "AyIQL");
      I[43 ^ 37] = I("忳楀侮", "CagXo");
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["   ".length()];
      String var10001 = I[43 ^ 47];
      String var10002 = I[72 ^ 77];
      var10001 = I[66 ^ 68];
      var10000 = I[90 ^ 93];
      var10001 = I[126 ^ 118];
      var10002 = I[8 ^ 1];
      var10001 = I[155 ^ 145];
      I[5 ^ 14].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[80 ^ 92].length();
      I[60 ^ 49].length();
      I[21 ^ 27].length();
      var10003["".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumFacing)var1.getValue(FACING)).getIndex();
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      EnumFacing var6 = (EnumFacing)var1.getValue(FACING);
      if (!this.func_193392_c(var2, var3.offset(var6.getOpposite()), var6)) {
         this.dropBlockAsItem(var2, var3, var1, "".length());
         var2.setBlockToAir(var3);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }

      super.neighborChanged(var1, var2, var3, var4, var5);
   }

   protected BlockLadder() {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      LADDER_EAST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.1875D, 1.0D, 1.0D);
      LADDER_WEST_AABB = new AxisAlignedBB(0.8125D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      LADDER_SOUTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.1875D);
      LADDER_NORTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.8125D, 1.0D, 1.0D, 1.0D);
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      if (var3.getAxis().isHorizontal() && this.func_193392_c(var1, var2.offset(var3.getOpposite()), var3)) {
         return this.getDefaultState().withProperty(FACING, var3);
      } else {
         Iterator var9 = EnumFacing.Plane.HORIZONTAL.iterator();

         do {
            if (!var9.hasNext()) {
               return this.getDefaultState();
            }

            EnumFacing var10 = (EnumFacing)var9.next();
            if (this.func_193392_c(var1, var2.offset(var10.getOpposite()), var10)) {
               return this.getDefaultState().withProperty(FACING, var10);
            }

            "".length();
         } while(-1 != 2);

         throw null;
      }
   }

   public IBlockState getStateFromMeta(int var1) {
      EnumFacing var2 = EnumFacing.getFront(var1);
      if (var2.getAxis() == EnumFacing.Axis.Y) {
         var2 = EnumFacing.NORTH;
      }

      return this.getDefaultState().withProperty(FACING, var2);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= -1);

      throw null;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   private boolean func_193392_c(World var1, BlockPos var2, EnumFacing var3) {
      IBlockState var4 = var1.getBlockState(var2);
      boolean var5 = func_193382_c(var4.getBlock());
      int var10000;
      if (!var5 && var4.func_193401_d(var1, var2, var3) == BlockFaceShape.SOLID && !var4.canProvidePower()) {
         var10000 = " ".length();
         "".length();
         if (3 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public boolean canPlaceBlockOnSide(World var1, BlockPos var2, EnumFacing var3) {
      if (this.func_193392_c(var1, var2.west(), var3)) {
         return (boolean)" ".length();
      } else if (this.func_193392_c(var1, var2.east(), var3)) {
         return (boolean)" ".length();
      } else {
         return (boolean)(this.func_193392_c(var1, var2.north(), var3) ? " ".length() : this.func_193392_c(var1, var2.south(), var3));
      }
   }
}

package net.minecraft.enchantment;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;

public class EnchantmentThorns extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   public int getMaxLevel() {
      return "   ".length();
   }

   public boolean canApply(ItemStack var1) {
      int var10000;
      if (var1.getItem() instanceof ItemArmor) {
         var10000 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = super.canApply(var1);
      }

      return (boolean)var10000;
   }

   public static boolean shouldHit(int var0, Random var1) {
      if (var0 <= 0) {
         return (boolean)"".length();
      } else {
         int var10000;
         if (var1.nextFloat() < 0.15F * (float)var0) {
            var10000 = " ".length();
            "".length();
            if (4 <= 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public int getMaxEnchantability(int var1) {
      return super.getMinEnchantability(var1) + (103 ^ 85);
   }

   public void onUserHurt(EntityLivingBase var1, Entity var2, int var3) {
      Random var4 = var1.getRNG();
      ItemStack var5 = EnchantmentHelper.getEnchantedItem(Enchantments.THORNS, var1);
      if (shouldHit(var3, var4)) {
         if (var2 != null) {
            var2.attackEntityFrom(DamageSource.causeThornsDamage(var1), (float)getDamage(var3, var4));
            I["   ".length()].length();
            I[70 ^ 66].length();
            I[168 ^ 173].length();
         }

         if (!var5.isEmpty()) {
            var5.damageItem("   ".length(), var1);
            "".length();
            if (2 >= 4) {
               throw null;
            }
         }
      } else if (!var5.isEmpty()) {
         var5.damageItem(" ".length(), var1);
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 >= -1);

      throw null;
   }

   public int getMinEnchantability(int var1) {
      int var10000 = 74 ^ 64;
      int var10001 = 137 ^ 157;
      int var10003 = " ".length();
      I[" ".length()].length();
      I["  ".length()].length();
      return var10000 + var10001 * (var1 - var10003);
   }

   public static int getDamage(int var0, Random var1) {
      int var10000;
      if (var0 > (112 ^ 122)) {
         int var10001 = 131 ^ 137;
         I[88 ^ 94].length();
         I[2 ^ 5].length();
         var10000 = var0 - var10001;
         "".length();
         if (2 < 0) {
            throw null;
         }
      } else {
         var10000 = " ".length() + var1.nextInt(59 ^ 63);
      }

      return var10000;
   }

   static {
      I();
   }

   private static void I() {
      I = new String[163 ^ 171];
      I["".length()] = I(":0=\u0007)=", "NXRuG");
      I[" ".length()] = I("焑啲惿宄", "PFAGR");
      I["  ".length()] = I("恗浧懎", "lKAeW");
      I["   ".length()] = I("昀唷嵟旕", "Hjube");
      I[34 ^ 38] = I("噆倨愥愬", "CYNup");
      I[160 ^ 165] = I("勛伡嬠摚坋", "Elzlq");
      I[187 ^ 189] = I("樒堦戠", "mAzoJ");
      I[152 ^ 159] = I("淆欥", "ADxnX");
   }

   public EnchantmentThorns(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.ARMOR_CHEST, var2);
      this.setName(I["".length()]);
   }
}

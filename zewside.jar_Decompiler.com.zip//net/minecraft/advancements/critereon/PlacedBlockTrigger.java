package net.minecraft.advancements.critereon;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldServer;

public class PlacedBlockTrigger implements ICriterionTrigger<PlacedBlockTrigger.Instance> {
   // $FF: synthetic field
   private final Map<PlayerAdvancements, PlacedBlockTrigger.Listeners> field_193175_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final ResourceLocation field_193174_a;
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
      field_193174_a = new ResourceLocation(I[99 ^ 61]);
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<PlacedBlockTrigger.Instance> var2) {
      PlacedBlockTrigger.Listeners var3 = (PlacedBlockTrigger.Listeners)this.field_193175_b.get(var1);
      if (var3 != null) {
         var3.func_193487_b(var2);
         if (var3.func_193488_a()) {
            this.field_193175_b.remove(var1);
            I[156 ^ 154].length();
         }
      }

   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<PlacedBlockTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      PlacedBlockTrigger.Listeners var3 = (PlacedBlockTrigger.Listeners)this.field_193175_b.get(var1);
      if (var3 == null) {
         I[148 ^ 144].length();
         var3 = new PlacedBlockTrigger.Listeners(var1);
         this.field_193175_b.put(var1, var3);
         I[152 ^ 157].length();
      }

      var3.func_193490_a(var2);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 2);

      throw null;
   }

   private static void I() {
      I = new String[80 ^ 15];
      I["".length()] = I("樚嘖", "bZneS");
      I[" ".length()] = I("拧怟", "kcaXp");
      I["  ".length()] = I("汆泓", "vxOYF");
      I["   ".length()] = I("亣槀", "gZcEB");
      I[22 ^ 18] = I("廸瀙堊噣", "qWQTL");
      I[139 ^ 142] = I("検", "yvXzz");
      I[79 ^ 73] = I("楙岕攥棅榁", "VcxPW");
      I[64 ^ 71] = I("仩嫉嬓偀愧", "sbgmm");
      I[168 ^ 160] = I("恀慻憗伺岼", "kaeXU");
      I[154 ^ 147] = I("嫲徸", "ppAub");
      I[16 ^ 26] = I("懋搏", "NJBEh");
      I[49 ^ 58] = I("啁埳", "tMCYv");
      I[100 ^ 104] = I("澢未", "jEIRu");
      I[56 ^ 53] = I("嶠氇", "fywpZ");
      I[112 ^ 126] = I("嘉婱", "WweSz");
      I[146 ^ 157] = I("喿嗦", "JEEjb");
      I[15 ^ 31] = I("核櫊", "Riayj");
      I[143 ^ 158] = I("唺媮", "dRPcE");
      I[113 ^ 99] = I("咍灰", "bkHOs");
      I[102 ^ 117] = I("楁濉", "DMqpy");
      I[182 ^ 162] = I("勈庫", "DrXue");
      I[188 ^ 169] = I("孓咀", "ykvli");
      I[126 ^ 104] = I("兯哘", "ZUbae");
      I[9 ^ 30] = I("滕揈", "Ibxls");
      I[58 ^ 34] = I("増呐", "kPaXz");
      I[139 ^ 146] = I("仜恝", "MltCg");
      I[221 ^ 199] = I("吧拆", "AofLT");
      I[185 ^ 162] = I("崘汾", "yXeew");
      I[62 ^ 34] = I("宔垃", "JtPLm");
      I[127 ^ 98] = I("洼匣", "bmrKV");
      I[165 ^ 187] = I("屝摥", "esbcV");
      I[105 ^ 118] = I("擪帱", "QDLLj");
      I[54 ^ 22] = I("唍娩", "sEptv");
      I[57 ^ 24] = I("偂墺", "bRERV");
      I[80 ^ 114] = I("煽搪", "zGyPr");
      I[229 ^ 198] = I("呄昭", "lgASO");
      I[142 ^ 170] = I("丧乜", "cjGMd");
      I[153 ^ 188] = I("悻揋", "jVHCJ");
      I[65 ^ 103] = I("晠幈", "quPLI");
      I[62 ^ 25] = I("佅嬬", "RMQlj");
      I[52 ^ 28] = I("嫂煘", "oEXXE");
      I[13 ^ 36] = I("借朩", "bCChS");
      I[29 ^ 55] = I("哘岵", "RzNhL");
      I[156 ^ 183] = I("旈泰", "XvbWk");
      I[43 ^ 7] = I("栊剽", "doOdW");
      I[20 ^ 57] = I("\n\u001b\u0019\u000e;", "hwvmP");
      I[35 ^ 13] = I("幋", "HjZqt");
      I[65 ^ 110] = I("悉", "xhJsN");
      I[180 ^ 132] = I("&!?*\u0003", "DMPIh");
      I[141 ^ 188] = I("愆坵橱", "GfSTB");
      I[54 ^ 4] = I("步昽", "vjUOr");
      I[87 ^ 100] = I("屗嚵朏倜", "wNKyl");
      I[187 ^ 143] = I("弥槚幾", "UnXtP");
      I[119 ^ 66] = I("滅", "AGuju");
      I[247 ^ 193] = I("9\u000f*;-\u001b\u000fa7.\u0003\u0002*u6\u0015\u0011$ue", "laAUB");
      I[96 ^ 87] = I("s", "TvSgQ");
      I[124 ^ 68] = I("恾回扁垂", "jsQwn");
      I[158 ^ 167] = I("泮掔", "tRIVN");
      I[49 ^ 11] = I("渴厓櫐", "apbQV");
      I[171 ^ 144] = I("&7\u0004\r\u0017", "UCeyr");
      I[137 ^ 181] = I("尯歋代", "AEZOP");
      I[50 ^ 15] = I("\u0007\u001b\u001bC&d\u001e\u0010\u0002;*\u001fU\u0006>+\u0019\u001eD!0\u001b\u0001\u0001r3\u0013\u0001\f=1\u000eU\u0005r7\n\u0010\u0007;\"\u0013\u0016D0(\u0015\u0016\u000fr0\u0003\u0005\u0001", "DzudR");
      I[174 ^ 144] = I("扯壡揈悄噺", "gBfJy");
      I[152 ^ 167] = I("止夬", "biExB");
      I[97 ^ 33] = I("\u0000\r\f\u001f-", "symkH");
      I[238 ^ 175] = I("垝春灲弩", "WNRyU");
      I[247 ^ 181] = I("滹岦孔", "DtBZQ");
      I[28 ^ 95] = I("櫬嘤檣三圖", "AloMu");
      I[62 ^ 122] = I("堃", "RbRCl");
      I[244 ^ 177] = I("梩像", "YRXsw");
      I[31 ^ 89] = I("嵬偕槖俣呪", "hdAnl");
      I[5 ^ 66] = I("\u001d+87??+s;<'&8y#<$'<p87<)5:1*yw", "HESYP");
      I[42 ^ 98] = I("jr\u0005\u0006\u001am0\u000f\u0006\u000b&rD", "MRcih");
      I[255 ^ 182] = I("]", "zjUkV");
      I[213 ^ 159] = I("旨昵", "Nkbtu");
      I[68 ^ 15] = I("旞濵", "WHxoC");
      I[95 ^ 19] = I("愵坘", "ujSuh");
      I[123 ^ 54] = I("幛哖楼櫻嶠", "ipsaa");
      I[248 ^ 182] = I("検强", "MqXWX");
      I[136 ^ 199] = I("'&/\u0012<\u0007,y\u0011<\u0001+2S#\u001a)-\u0016p\u0018)5\u00065No", "nHYsP");
      I[26 ^ 74] = I("^l$<\nY<0<\b\u001c>6*X^", "yLBSx");
      I[117 ^ 36] = I("qs=\u0005Z4?=\b\u0011vt", "VSRkz");
      I[100 ^ 54] = I("f", "AqIyI");
      I[27 ^ 72] = I("杸潎嗤润乯", "YNHKM");
      I[19 ^ 71] = I("恀", "MsWfL");
      I[96 ^ 53] = I("慶戨咯巛", "Swrmn");
      I[39 ^ 113] = I("揹庲录媹", "MgzuF");
      I[78 ^ 25] = I("倣", "NNtvg");
      I[204 ^ 148] = I("&(\b\u0015\u0010#(\u0005", "JGktd");
      I[206 ^ 151] = I("\b!\b.", "aUmCE");
      I[214 ^ 140] = I("剏埡叧尡", "xLobO");
      I[215 ^ 140] = I("杩捄", "ppaIY");
      I[243 ^ 175] = I("温兲汚", "ztIsJ");
      I[80 ^ 13] = I("徤嘐潭煹", "BgcEE");
      I[55 ^ 105] = I("5\u0006;:\u0011!585\u001b&\u0001", "EjZYt");
   }

   public void func_193173_a(EntityPlayerMP var1, BlockPos var2, ItemStack var3) {
      IBlockState var4 = var1.world.getBlockState(var2);
      PlacedBlockTrigger.Listeners var5 = (PlacedBlockTrigger.Listeners)this.field_193175_b.get(var1.func_192039_O());
      if (var5 != null) {
         var5.func_193489_a(var4, var2, var1.getServerWorld(), var3);
      }

   }

   public PlacedBlockTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[106 ^ 99];
      String var10001 = I[28 ^ 22];
      String var10002 = I[51 ^ 56];
      var10001 = I[155 ^ 151];
      var10000 = I[37 ^ 40];
      var10001 = I[175 ^ 161];
      var10002 = I[103 ^ 104];
      var10001 = I[114 ^ 98];
      var10000 = I[166 ^ 183];
      var10001 = I[15 ^ 29];
      var10002 = I[91 ^ 72];
      var10001 = I[100 ^ 112];
      var10000 = I[59 ^ 46];
      var10001 = I[155 ^ 141];
      var10002 = I[112 ^ 103];
      var10001 = I[22 ^ 14];
      var10000 = I[124 ^ 101];
      var10001 = I[33 ^ 59];
      var10002 = I[141 ^ 150];
      var10001 = I[45 ^ 49];
      var10000 = I[122 ^ 103];
      var10001 = I[121 ^ 103];
      var10002 = I[7 ^ 24];
      var10001 = I[69 ^ 101];
      var10000 = I[128 ^ 161];
      var10001 = I[231 ^ 197];
      var10002 = I[52 ^ 23];
      var10001 = I[102 ^ 66];
      var10000 = I[154 ^ 191];
      var10001 = I[114 ^ 84];
      var10002 = I[158 ^ 185];
      var10001 = I[163 ^ 139];
      var10000 = I[127 ^ 86];
      var10001 = I[109 ^ 71];
      var10002 = I[169 ^ 130];
      var10001 = I[32 ^ 12];
      Block var3 = null;
      JsonSyntaxException var14;
      if (var1.has(I[65 ^ 108])) {
         I[151 ^ 185].length();
         I[165 ^ 138].length();
         ResourceLocation var4 = new ResourceLocation(JsonUtils.getString(var1, I[31 ^ 47]));
         if (!Block.REGISTRY.containsKey(var4)) {
            I[114 ^ 67].length();
            I[40 ^ 26].length();
            I[108 ^ 95].length();
            I[55 ^ 3].length();
            I[104 ^ 93].length();
            var14 = new JsonSyntaxException(I[142 ^ 184] + var4 + I[26 ^ 45]);
            I[83 ^ 107].length();
            I[115 ^ 74].length();
            I[70 ^ 124].length();
            throw var14;
         }

         var3 = (Block)Block.REGISTRY.getObject(var4);
      }

      HashMap var11 = null;
      if (var1.has(I[129 ^ 186])) {
         if (var3 == null) {
            I[146 ^ 174].length();
            var14 = new JsonSyntaxException(I[137 ^ 180]);
            I[5 ^ 59].length();
            I[136 ^ 183].length();
            throw var14;
         }

         BlockStateContainer var5 = var3.getBlockState();
         Iterator var6 = JsonUtils.getJsonObject(var1, I[231 ^ 167]).entrySet().iterator();

         while(var6.hasNext()) {
            Entry var7 = (Entry)var6.next();
            IProperty var8 = var5.getProperty((String)var7.getKey());
            if (var8 == null) {
               I[106 ^ 43].length();
               I[103 ^ 37].length();
               I[195 ^ 128].length();
               I[207 ^ 139].length();
               I[72 ^ 13].length();
               I[43 ^ 109].length();
               var14 = new JsonSyntaxException(I[75 ^ 12] + (String)var7.getKey() + I[211 ^ 155] + Block.REGISTRY.getNameForObject(var3) + I[4 ^ 77]);
               I[207 ^ 133].length();
               I[52 ^ 127].length();
               I[41 ^ 101].length();
               throw var14;
            }

            String var9 = JsonUtils.getString((JsonElement)var7.getValue(), (String)var7.getKey());
            Optional var10 = var8.parseValue(var9);
            if (!var10.isPresent()) {
               I[113 ^ 60].length();
               I[104 ^ 38].length();
               var14 = new JsonSyntaxException(I[90 ^ 21] + var9 + I[67 ^ 19] + (String)var7.getKey() + I[148 ^ 197] + Block.REGISTRY.getNameForObject(var3) + I[115 ^ 33]);
               I[33 ^ 114].length();
               I[124 ^ 40].length();
               throw var14;
            }

            if (var11 == null) {
               var11 = Maps.newHashMap();
            }

            var11.put(var8, var10.get());
            I[15 ^ 90].length();
            I[3 ^ 85].length();
            I[202 ^ 157].length();
            "".length();
            if (4 == -1) {
               throw null;
            }
         }
      }

      LocationPredicate var12 = LocationPredicate.func_193454_a(var1.get(I[218 ^ 130]));
      ItemPredicate var13 = ItemPredicate.func_192492_a(var1.get(I[196 ^ 157]));
      I[199 ^ 157].length();
      I[192 ^ 155].length();
      I[29 ^ 65].length();
      I[84 ^ 9].length();
      return new PlacedBlockTrigger.Instance(var3, var11, var12, var13);
   }

   public ResourceLocation func_192163_a() {
      return field_193174_a;
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193175_b.remove(var1);
      I[97 ^ 102].length();
      I[46 ^ 38].length();
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final Map<IProperty<?>, Object> field_193212_b;
      // $FF: synthetic field
      private final Block field_193211_a;
      // $FF: synthetic field
      private final ItemPredicate field_193214_d;
      // $FF: synthetic field
      private final LocationPredicate field_193213_c;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 < 4);

         throw null;
      }

      public boolean func_193210_a(IBlockState var1, BlockPos var2, WorldServer var3, ItemStack var4) {
         if (this.field_193211_a != null && var1.getBlock() != this.field_193211_a) {
            return (boolean)"".length();
         } else {
            if (this.field_193212_b != null) {
               Iterator var5 = this.field_193212_b.entrySet().iterator();

               while(var5.hasNext()) {
                  Entry var6 = (Entry)var5.next();
                  if (var1.getValue((IProperty)var6.getKey()) != var6.getValue()) {
                     return (boolean)"".length();
                  }

                  "".length();
                  if (3 < -1) {
                     throw null;
                  }
               }
            }

            return (boolean)(!this.field_193213_c.func_193453_a(var3, (float)var2.getX(), (float)var2.getY(), (float)var2.getZ()) ? "".length() : this.field_193214_d.func_192493_a(var4));
         }
      }

      public Instance(@Nullable Block var1, @Nullable Map<IProperty<?>, Object> var2, LocationPredicate var3, ItemPredicate var4) {
         super(PlacedBlockTrigger.field_193174_a);
         this.field_193211_a = var1;
         this.field_193212_b = var2;
         this.field_193213_c = var3;
         this.field_193214_d = var4;
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final PlayerAdvancements field_193491_a;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<PlacedBlockTrigger.Instance>> field_193492_b = Sets.newHashSet();

      public void func_193490_a(ICriterionTrigger.Listener<PlacedBlockTrigger.Instance> var1) {
         this.field_193492_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      static {
         I();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 != 1);

         throw null;
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193491_a = var1;
      }

      public void func_193487_b(ICriterionTrigger.Listener<PlacedBlockTrigger.Instance> var1) {
         this.field_193492_b.remove(var1);
         I["  ".length()].length();
      }

      public void func_193489_a(IBlockState var1, BlockPos var2, WorldServer var3, ItemStack var4) {
         ArrayList var5 = null;
         Iterator var6 = this.field_193492_b.iterator();

         ICriterionTrigger.Listener var7;
         while(var6.hasNext()) {
            var7 = (ICriterionTrigger.Listener)var6.next();
            if (((PlacedBlockTrigger.Instance)var7.func_192158_a()).func_193210_a(var1, var2, var3, var4)) {
               if (var5 == null) {
                  var5 = Lists.newArrayList();
               }

               var5.add(var7);
               I["   ".length()].length();
               I[16 ^ 20].length();
            }

            "".length();
            if (1 <= -1) {
               throw null;
            }
         }

         if (var5 != null) {
            var6 = var5.iterator();

            while(var6.hasNext()) {
               var7 = (ICriterionTrigger.Listener)var6.next();
               var7.func_192159_a(this.field_193491_a);
               "".length();
               if (4 < 2) {
                  throw null;
               }
            }
         }

      }

      private static void I() {
         I = new String[33 ^ 36];
         I["".length()] = I("嫫", "tEeuV");
         I[" ".length()] = I("嵭楰埑殑栽", "sDOXb");
         I["  ".length()] = I("按", "AlrEu");
         I["   ".length()] = I("娱暷摳楃", "jrGud");
         I[181 ^ 177] = I("屚摲流溢", "EgdzU");
      }

      public boolean func_193488_a() {
         return this.field_193492_b.isEmpty();
      }
   }
}

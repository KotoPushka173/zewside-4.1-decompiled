package net.minecraft.network.play.server;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class SPacketExplosion implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private List<BlockPos> affectedBlockPositions;
   // $FF: synthetic field
   private float strength;
   // $FF: synthetic field
   private double posZ;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private float motionZ;
   // $FF: synthetic field
   private float motionX;
   // $FF: synthetic field
   private double posX;
   // $FF: synthetic field
   private float motionY;
   // $FF: synthetic field
   private double posY;

   public double getZ() {
      return this.posZ;
   }

   public SPacketExplosion() {
   }

   public List<BlockPos> getAffectedBlockPositions() {
      return this.affectedBlockPositions;
   }

   public double getX() {
      return this.posX;
   }

   public float getStrength() {
      return this.strength;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      this.posX = (double)var1.readFloat();
      this.posY = (double)var1.readFloat();
      this.posZ = (double)var1.readFloat();
      this.strength = var1.readFloat();
      int var2 = var1.readInt();
      this.affectedBlockPositions = Lists.newArrayListWithCapacity(var2);
      int var3 = (int)this.posX;
      int var4 = (int)this.posY;
      int var5 = (int)this.posZ;
      int var6 = "".length();

      do {
         if (var6 >= var2) {
            this.motionX = var1.readFloat();
            this.motionY = var1.readFloat();
            this.motionZ = var1.readFloat();
            return;
         }

         int var7 = var1.readByte() + var3;
         int var8 = var1.readByte() + var4;
         int var9 = var1.readByte() + var5;
         List var10 = this.affectedBlockPositions;
         I[189 ^ 185].length();
         I[27 ^ 30].length();
         I[35 ^ 37].length();
         I[13 ^ 10].length();
         var10.add(new BlockPos(var7, var8, var9));
         I[108 ^ 100].length();
         ++var6;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   public float getMotionZ() {
      return this.motionZ;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleExplosion(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeFloat((float)this.posX);
      I[1 ^ 8].length();
      I[138 ^ 128].length();
      I[109 ^ 102].length();
      var1.writeFloat((float)this.posY);
      I[24 ^ 20].length();
      I[143 ^ 130].length();
      I[137 ^ 135].length();
      I[10 ^ 5].length();
      var1.writeFloat((float)this.posZ);
      I[142 ^ 158].length();
      var1.writeFloat(this.strength);
      I[152 ^ 137].length();
      I[39 ^ 53].length();
      var1.writeInt(this.affectedBlockPositions.size());
      I[119 ^ 100].length();
      int var2 = (int)this.posX;
      int var3 = (int)this.posY;
      int var4 = (int)this.posZ;
      Iterator var5 = this.affectedBlockPositions.iterator();

      do {
         if (!var5.hasNext()) {
            var1.writeFloat(this.motionX);
            I[42 ^ 11].length();
            I[127 ^ 93].length();
            var1.writeFloat(this.motionY);
            I[116 ^ 87].length();
            I[165 ^ 129].length();
            I[27 ^ 62].length();
            var1.writeFloat(this.motionZ);
            I[191 ^ 153].length();
            I[0 ^ 39].length();
            I[8 ^ 32].length();
            return;
         }

         BlockPos var6 = (BlockPos)var5.next();
         int var10000 = var6.getX();
         I[131 ^ 151].length();
         int var7 = var10000 - var2;
         var10000 = var6.getY();
         I[120 ^ 109].length();
         I[147 ^ 133].length();
         int var8 = var10000 - var3;
         var10000 = var6.getZ();
         I[184 ^ 175].length();
         I[88 ^ 64].length();
         I[77 ^ 84].length();
         I[97 ^ 123].length();
         int var9 = var10000 - var4;
         var1.writeByte(var7);
         I[132 ^ 159].length();
         I[145 ^ 141].length();
         var1.writeByte(var8);
         I[58 ^ 39].length();
         var1.writeByte(var9);
         I[68 ^ 90].length();
         I[179 ^ 172].length();
         I[67 ^ 99].length();
         "".length();
      } while(1 != 4);

      throw null;
   }

   public SPacketExplosion(double var1, double var3, double var5, float var7, List<BlockPos> var8, Vec3d var9) {
      this.posX = var1;
      this.posY = var3;
      this.posZ = var5;
      this.strength = var7;
      this.affectedBlockPositions = Lists.newArrayList(var8);
      if (var9 != null) {
         this.motionX = (float)var9.x;
         this.motionY = (float)var9.y;
         this.motionZ = (float)var9.z;
      }

   }

   public float getMotionX() {
      return this.motionX;
   }

   private static void I() {
      I = new String[50 ^ 27];
      I["".length()] = I("枀烓", "ITTEZ");
      I[" ".length()] = I("堟倫", "BoNSN");
      I["  ".length()] = I("嗂岛", "cnAzi");
      I["   ".length()] = I("拰俷", "JgVpZ");
      I[171 ^ 175] = I("斠", "aUWMd");
      I[171 ^ 174] = I("僋射暯曬", "QnVbg");
      I[74 ^ 76] = I("嬦", "MRKtD");
      I[59 ^ 60] = I("戓墟朗", "Rgnbd");
      I[0 ^ 8] = I("召奖", "IqOyW");
      I[182 ^ 191] = I("卫曜", "OgWGc");
      I[159 ^ 149] = I("晱摰俋唠", "YzMJG");
      I[48 ^ 59] = I("恚憉", "YIVGd");
      I[149 ^ 153] = I("潽喦", "SOZgJ");
      I[3 ^ 14] = I("庛挞愣嫺", "pVCFH");
      I[9 ^ 7] = I("棦淗旪泞", "IgmFy");
      I[146 ^ 157] = I("吠烜发榖壯", "ggMkk");
      I[157 ^ 141] = I("厁瀀偠滬匭", "qWKWa");
      I[66 ^ 83] = I("淐喖抯", "Ngrnb");
      I[174 ^ 188] = I("啹彣勯廵", "eIKix");
      I[184 ^ 171] = I("刏帐棲樽孃", "FnruF");
      I[182 ^ 162] = I("嶉", "iRFSh");
      I[40 ^ 61] = I("歕", "yaTYd");
      I[58 ^ 44] = I("擸澱杺嶿", "Zqrkd");
      I[56 ^ 47] = I("潃昤侨", "TFmJi");
      I[123 ^ 99] = I("婘刧烝尼墨", "gKWgE");
      I[30 ^ 7] = I("洕始凰烅抍", "KkhdL");
      I[81 ^ 75] = I("扰墛", "UUQJX");
      I[92 ^ 71] = I("壌斨", "UBDVG");
      I[105 ^ 117] = I("坯廆", "VOAgT");
      I[47 ^ 50] = I("扦桰咖", "GohEL");
      I[70 ^ 88] = I("匾擥溄", "hQIJB");
      I[102 ^ 121] = I("婮歨侱恴愨", "jksUL");
      I[38 ^ 6] = I("塗漟寧敩殱", "LcICB");
      I[166 ^ 135] = I("梦嬌嘲樀", "YFSjK");
      I[76 ^ 110] = I("墘摀攀丈瀦", "XlIaV");
      I[151 ^ 180] = I("旁攤己戁嵅", "boEfL");
      I[83 ^ 119] = I("嬂抷", "QJjOv");
      I[114 ^ 87] = I("傑", "eAbZj");
      I[26 ^ 60] = I("尷", "DElLz");
      I[33 ^ 6] = I("应拵", "eUBwr");
      I[146 ^ 186] = I("潼唲", "VwpEz");
   }

   public double getY() {
      return this.posY;
   }

   public float getMotionY() {
      return this.motionY;
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }
}

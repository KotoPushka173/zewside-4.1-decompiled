package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentArrowKnockback extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   public int getMinEnchantability(int var1) {
      int var10000 = 160 ^ 172;
      int var10002 = " ".length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      I[190 ^ 186].length();
      return var10000 + (var1 - var10002) * (14 ^ 26);
   }

   public int getMaxLevel() {
      return "  ".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public int getMaxEnchantability(int var1) {
      return this.getMinEnchantability(var1) + (38 ^ 63);
   }

   private static void I() {
      I = new String[147 ^ 150];
      I["".length()] = I("7\u0004#\u0007&\u001d\u0018>\u000b:4\u00172\u0003", "VvQhQ");
      I[" ".length()] = I("湣俪惜煞崒", "bizME");
      I["  ".length()] = I("寷愔", "vrbVl");
      I["   ".length()] = I("奲柜嵬斘", "WePOl");
      I[113 ^ 117] = I("厦敛", "IUgOx");
   }

   public EnchantmentArrowKnockback(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.BOW, var2);
      this.setName(I["".length()]);
   }

   static {
      I();
   }
}

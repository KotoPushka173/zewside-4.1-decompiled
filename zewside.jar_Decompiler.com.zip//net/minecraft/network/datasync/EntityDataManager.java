package net.minecraft.network.datasync;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.annotation.Nullable;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.ReportedException;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityDataManager {
   // $FF: synthetic field
   private final Entity entity;
   // $FF: synthetic field
   private static final Map<Class<? extends Entity>, Integer> NEXT_ID_MAP;
   // $FF: synthetic field
   private static final Logger LOGGER;
   // $FF: synthetic field
   private boolean empty = " ".length();
   // $FF: synthetic field
   private final ReadWriteLock lock = new ReentrantReadWriteLock();
   // $FF: synthetic field
   private boolean dirty;
   // $FF: synthetic field
   private final Map<Integer, EntityDataManager.DataEntry<?>> entries = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;

   public <T> T get(DataParameter<T> var1) {
      return this.getEntry(var1).getValue();
   }

   public <T> void register(DataParameter<T> var1, T var2) {
      String var10000 = I[170 ^ 179];
      String var10001 = I[141 ^ 151];
      String var10002 = I[183 ^ 172];
      var10001 = I[223 ^ 195];
      var10000 = I[32 ^ 61];
      var10001 = I[9 ^ 23];
      var10002 = I[69 ^ 90];
      var10001 = I[52 ^ 20];
      var10000 = I[103 ^ 70];
      var10001 = I[71 ^ 101];
      var10002 = I[173 ^ 142];
      var10001 = I[75 ^ 111];
      var10000 = I[130 ^ 167];
      var10001 = I[50 ^ 20];
      var10002 = I[85 ^ 114];
      var10001 = I[238 ^ 198];
      var10000 = I[236 ^ 197];
      var10001 = I[97 ^ 75];
      var10002 = I[152 ^ 179];
      var10001 = I[148 ^ 184];
      var10000 = I[30 ^ 51];
      var10001 = I[33 ^ 15];
      var10002 = I[42 ^ 5];
      var10001 = I[108 ^ 92];
      int var3 = var1.getId();
      IllegalArgumentException var4;
      if (var3 > 196 + 54 - 58 + 62) {
         I[35 ^ 18].length();
         I[74 ^ 120].length();
         I[86 ^ 101].length();
         var4 = new IllegalArgumentException(I[174 ^ 154] + var3 + I[131 ^ 182] + (119 + 12 - 60 + 183) + I[244 ^ 194]);
         I[43 ^ 28].length();
         I[42 ^ 18].length();
         throw var4;
      } else if (this.entries.containsKey(var3)) {
         I[139 ^ 178].length();
         I[68 ^ 126].length();
         I[120 ^ 67].length();
         I[159 ^ 163].length();
         var4 = new IllegalArgumentException(I[151 ^ 170] + var3 + I[121 ^ 71]);
         I[45 ^ 18].length();
         I[39 ^ 103].length();
         I[80 ^ 17].length();
         throw var4;
      } else if (DataSerializers.getSerializerId(var1.getSerializer()) < 0) {
         I[195 ^ 129].length();
         I[213 ^ 150].length();
         I[246 ^ 178].length();
         I[6 ^ 67].length();
         I[12 ^ 74].length();
         I[237 ^ 170].length();
         var4 = new IllegalArgumentException(I[214 ^ 158] + var1.getSerializer() + I[108 ^ 37] + var3 + I[215 ^ 157]);
         I[59 ^ 112].length();
         I[122 ^ 54].length();
         I[198 ^ 139].length();
         I[118 ^ 56].length();
         throw var4;
      } else {
         this.setEntry(var1, var2);
      }
   }

   public EntityDataManager(Entity var1) {
      this.entity = var1;
   }

   @Nullable
   public List<EntityDataManager.DataEntry<?>> getAll() {
      ArrayList var1 = null;
      this.lock.readLock().lock();
      Iterator var2 = this.entries.values().iterator();

      do {
         if (!var2.hasNext()) {
            this.lock.readLock().unlock();
            return var1;
         }

         EntityDataManager.DataEntry var3 = (EntityDataManager.DataEntry)var2.next();
         if (var1 == null) {
            var1 = Lists.newArrayList();
         }

         var1.add(var3.func_192735_d());
         I[35 ^ 82].length();
         I[198 ^ 180].length();
         I[205 ^ 190].length();
         "".length();
      } while(0 < 3);

      throw null;
   }

   private <T> void setEntry(DataParameter<T> var1, T var2) {
      String var10000 = I[99 ^ 44];
      String var10001 = I[145 ^ 193];
      String var10002 = I[223 ^ 142];
      var10001 = I[56 ^ 106];
      I[71 ^ 20].length();
      I[61 ^ 105].length();
      I[56 ^ 109].length();
      I[10 ^ 92].length();
      EntityDataManager.DataEntry var3 = new EntityDataManager.DataEntry(var1, var2);
      this.lock.writeLock().lock();
      this.entries.put(var1.getId(), var3);
      I[147 ^ 196].length();
      this.empty = (boolean)"".length();
      this.lock.writeLock().unlock();
   }

   private <T> EntityDataManager.DataEntry<T> getEntry(DataParameter<T> var1) {
      String var10000 = I[72 ^ 16];
      String var10001 = I[205 ^ 148];
      String var10002 = I[33 ^ 123];
      var10001 = I[92 ^ 7];
      this.lock.readLock().lock();

      EntityDataManager.DataEntry var2;
      try {
         var2 = (EntityDataManager.DataEntry)this.entries.get(var1.getId());
      } catch (Throwable var6) {
         CrashReport var4 = CrashReport.makeCrashReport(var6, I[26 ^ 70]);
         CrashReportCategory var5 = var4.makeCategory(I[207 ^ 146]);
         var5.addCrashSection(I[217 ^ 135], var1);
         I[104 ^ 55].length();
         ReportedException var7 = new ReportedException(var4);
         I[42 ^ 74].length();
         I[197 ^ 164].length();
         I[102 ^ 4].length();
         I[198 ^ 165].length();
         I[14 ^ 106].length();
         throw var7;
      }

      "".length();
      if (4 == 3) {
         throw null;
      } else {
         this.lock.readLock().unlock();
         return var2;
      }
   }

   @Nullable
   public static List<EntityDataManager.DataEntry<?>> readEntries(PacketBuffer var0) throws IOException {
      String var10000 = I[56 + 121 - 134 + 92];
      String var10001 = I[52 + 6 - 33 + 111];
      String var10002 = I[15 + 12 - 17 + 127];
      var10001 = I[126 + 71 - 150 + 91];
      var10000 = I[109 + 13 - 78 + 95];
      var10001 = I[117 + 113 - 204 + 114];
      var10002 = I[57 + 1 - -40 + 43];
      var10001 = I[52 + 98 - 65 + 57];
      var10000 = I[81 + 141 - 129 + 50];
      var10001 = I[54 + 102 - 68 + 56];
      var10002 = I[71 + 21 - 86 + 139];
      var10001 = I[134 + 94 - 170 + 88];
      var10000 = I[2 + 99 - 1 + 47];
      var10001 = I[37 + 63 - 45 + 93];
      var10002 = I[101 + 45 - 7 + 10];
      var10001 = I[18 + 30 - 44 + 146];
      ArrayList var1 = null;

      do {
         short var5 = var0.readUnsignedByte();
         I[73 + 69 - 129 + 138].length();
         I[102 + 91 - 115 + 74].length();
         short var2 = var5;
         if (var5 == 136 + 99 - -5 + 15) {
            return var1;
         }

         if (var1 == null) {
            var1 = Lists.newArrayList();
         }

         int var3 = var0.readVarIntFromBuffer();
         DataSerializer var4 = DataSerializers.getSerializer(var3);
         if (var4 == null) {
            I[72 + 48 - 69 + 102].length();
            I[146 + 15 - 14 + 7].length();
            I[108 + 0 - -1 + 46].length();
            I[149 + 67 - 84 + 24].length();
            I[111 + 60 - 130 + 116].length();
            I[58 + 119 - 148 + 129].length();
            DecoderException var6 = new DecoderException(I[80 + 140 - 185 + 124] + var3);
            I[67 + 129 - 194 + 158].length();
            I[64 + 88 - 141 + 150].length();
            I[140 + 75 - 108 + 55].length();
            I[34 + 111 - -8 + 10].length();
            throw var6;
         }

         I[73 + 117 - 148 + 122].length();
         I[15 + 160 - 146 + 136].length();
         I[46 + 42 - -32 + 46].length();
         var1.add(new EntityDataManager.DataEntry(var4.createKey(var2), var4.read(var0)));
         I[98 + 22 - 25 + 72].length();
         I[36 + 1 - -86 + 45].length();
         "".length();
      } while(0 != -1);

      throw null;
   }

   public static void writeEntries(List<EntityDataManager.DataEntry<?>> var0, PacketBuffer var1) throws IOException {
      if (var0 != null) {
         int var2 = "".length();
         int var3 = var0.size();

         while(var2 < var3) {
            EntityDataManager.DataEntry var4 = (EntityDataManager.DataEntry)var0.get(var2);
            writeEntry(var1, var4);
            ++var2;
            "".length();
            if (-1 != -1) {
               throw null;
            }
         }
      }

      var1.writeByte(85 + 131 - 191 + 230);
      I[37 ^ 67].length();
      I[76 ^ 43].length();
      I[48 ^ 88].length();
      I[42 ^ 67].length();
      I[233 ^ 131].length();
   }

   private static void I() {
      I = new String[143 + 137 - 177 + 66];
      I["".length()] = I("払湞", "mAWJY");
      I[" ".length()] = I("戉惂", "aeVQk");
      I["  ".length()] = I("崂噞", "FUJke");
      I["   ".length()] = I("婟漫", "RcDRm");
      I[34 ^ 38] = I("奼吩", "nmEuf");
      I[184 ^ 189] = I("圩嬩", "iyAba");
      I[110 ^ 104] = I("炪夃", "cWOSq");
      I[163 ^ 164] = I("歍戚", "GVRoa");
      I[109 ^ 101] = I("潮劐", "fdjHB");
      I[3 ^ 10] = I("瀋塟", "MZGCn");
      I[136 ^ 130] = I("带湑", "sWwBK");
      I[76 ^ 71] = I("嘳夐", "HuRZk");
      I[150 ^ 154] = I("\n\u001c0#:\u000b02j7\u000f\u0015:/0N\u001f98nN\u0002+j2\u001c\u0016;j/\u0013", "nyVJT");
      I[19 ^ 30] = I("朱噐灮凑劚", "xtfAu");
      I[142 ^ 128] = I("巽卸徊煆嚺", "jcDwN");
      I[174 ^ 161] = I("哔儜勤敝", "YtBdL");
      I[172 ^ 188] = I("啦嫾溘氿", "rlQqK");
      I[116 ^ 101] = I("為", "YPzgk");
      I[214 ^ 196] = I("%0\u001b\bY\u00170\u0003\u001c\u001cA8\u000bI\u0010\u0012q\u001b\u0006\u0016A3\u0006\u000eY\u00168\u001b\u0001Y", "aQoiy");
      I[140 ^ 159] = I("NyO'\u001b\u0017y\u000e\u0019Z", "oYgjz");
      I[86 ^ 66] = I("L", "eIftU");
      I[158 ^ 139] = I("溊媤", "XDdBg");
      I[105 ^ 127] = I("問噐泡", "DuGaw");
      I[148 ^ 131] = I("佊叙仴労", "ZlBnI");
      I[219 ^ 195] = I("汆毶严", "ZeBRw");
      I[111 ^ 118] = I("循懮", "BzVmc");
      I[16 ^ 10] = I("嚊楂", "vnbqw");
      I[77 ^ 86] = I("望堀", "XHdAz");
      I[174 ^ 178] = I("抐枰", "lhkZz");
      I[50 ^ 47] = I("仾挐", "hpxKh");
      I[50 ^ 44] = I("惁滤", "mZejp");
      I[40 ^ 55] = I("些析", "XJNsL");
      I[184 ^ 152] = I("嬓榘", "MnmSr");
      I[7 ^ 38] = I("樋戤", "pnMrT");
      I[190 ^ 156] = I("娑濑", "YtJwj");
      I[166 ^ 133] = I("庙斔", "DjDnf");
      I[9 ^ 45] = I("怖墔", "mkdbD");
      I[172 ^ 137] = I("寴为", "MLFEM");
      I[144 ^ 182] = I("枠剢", "ehqfb");
      I[162 ^ 133] = I("傟撈", "BWtCC");
      I[233 ^ 193] = I("杛把", "NrJBN");
      I[169 ^ 128] = I("仛樗", "JgPBG");
      I[1 ^ 43] = I("浮殛", "BFIWm");
      I[187 ^ 144] = I("嚨忂", "wPwXk");
      I[145 ^ 189] = I("浅塟", "BfTpR");
      I[172 ^ 129] = I("嬐傦", "ccrcN");
      I[14 ^ 32] = I("槣唫", "LzIgl");
      I[68 ^ 107] = I("劾僞", "DdDfX");
      I[175 ^ 159] = I("拉晅", "dEtbn");
      I[58 ^ 11] = I("啖", "ffNWr");
      I[3 ^ 49] = I("敎刃攖", "kLJmp");
      I[135 ^ 180] = I("単懀楙", "ywofy");
      I[166 ^ 146] = I("\u0005\u000f>'C7\u000f&3\u0006a\u0007.f\n2N>)\fa\f#!C6\u0007>.C", "AnJFc");
      I[108 ^ 89] = I("fWa\u001c8?W \"y", "GwIQY");
      I[104 ^ 94] = I("h", "AeEQk");
      I[0 ^ 55] = I("佫潑圷奱冓", "QryPS");
      I[140 ^ 180] = I("春怂庽", "FdzHy");
      I[116 ^ 77] = I("居槷欫", "FPHgl");
      I[185 ^ 131] = I("橂", "QSklg");
      I[129 ^ 186] = I("散嵗氷山彰", "eSNQj");
      I[149 ^ 169] = I("弘傜槜櫶", "UuwrG");
      I[136 ^ 181] = I("\u0000\u0011\u0000\u001a\u001a'\u0005\u0004\u0013S-\u0000P\u0000\u0012(\u0011\u0015V\u0015+\u0016P", "Ddpvs");
      I[176 ^ 142] = I("D", "eTHzM");
      I[20 ^ 43] = I("廉剎摥", "voTpe");
      I[252 ^ 188] = I("仇卷伳拭", "UCsMD");
      I[30 ^ 95] = I("呢劑墪滆", "EAhla");
      I[64 ^ 2] = I("朤", "rxrRx");
      I[135 ^ 196] = I("灵撍漫", "MVnOh");
      I[202 ^ 142] = I("傛匩已容", "FpUkQ");
      I[200 ^ 141] = I("怩哼咈国", "QGnBp");
      I[198 ^ 128] = I("戎汩", "zWgfb");
      I[199 ^ 128] = I("歼樝撓", "IkzJS");
      I[199 ^ 143] = I("\u00067820:*>2%6=j$2!0+;>)<8w", "SYJWW");
      I[228 ^ 173] = I("F\u001663p", "fpYAP");
      I[63 ^ 117] = I("y", "XdLIK");
      I[230 ^ 173] = I("曨壹射傲炥", "hRAmZ");
      I[61 ^ 113] = I("湿坨漂溵樑", "wHZvN");
      I[77 ^ 0] = I("儌劒媵护剙", "RldQE");
      I[224 ^ 174] = I("樉瀙捊", "kUQsH");
      I[65 ^ 14] = I("煋仍", "ZpSXv");
      I[21 ^ 69] = I("柹峴", "cQGEq");
      I[36 ^ 117] = I("慞彽", "bKPVM");
      I[85 ^ 7] = I("梻捔", "kGllU");
      I[88 ^ 11] = I("扡废孥偋瀐", "BDvJD");
      I[41 ^ 125] = I("戺昺柹", "cxPxY");
      I[196 ^ 145] = I("涯夹", "MhKAb");
      I[34 ^ 116] = I("妯媨偄婕", "fxTbw");
      I[216 ^ 143] = I("潹姏拉暷", "fScys");
      I[112 ^ 40] = I("炦壙", "xSfhH");
      I[212 ^ 141] = I("殧框", "KSoUx");
      I[117 ^ 47] = I("孇殹", "zHynI");
      I[29 ^ 70] = I("嬼憹", "QJebi");
      I[24 ^ 68] = I("\u000b\u0014\"#8\"\u0016v$(\"\u0012>25l\u00148#88\bv308\u0010", "LqVWQ");
      I[22 ^ 75] = I("\u0019(\u0006\f\u000f/5H\n\t>8\u001c\u0016G.0\u001c\u000e", "JQhog");
      I[198 ^ 152] = I("0\u0005\u001f\u0005u= ", "tdkdU");
      I[158 ^ 193] = I("悗", "EcfBo");
      I[221 ^ 189] = I("媦彦", "iYdRb");
      I[55 ^ 86] = I("怺傽剡", "uedLm");
      I[41 ^ 75] = I("歚孂厔噰浹", "ANyLx");
      I[19 ^ 112] = I("湭欅", "iQqwz");
      I[232 ^ 140] = I("烔槡嫸", "WnzzH");
      I[219 ^ 190] = I("俑厅冡壦", "auvyt");
      I[196 ^ 162] = I("剾托慬槑毊", "EhxzZ");
      I[5 ^ 98] = I("凲汎歘堌晀", "AnuBI");
      I[75 ^ 35] = I("忾洲濧楲尘", "fiteN");
      I[236 ^ 133] = I("寻仕楴", "NAhys");
      I[9 ^ 99] = I("洇凲", "JUcEQ");
      I[23 ^ 124] = I("椄刵棲", "cBDrP");
      I[224 ^ 140] = I("瀽", "KVXXE");
      I[228 ^ 137] = I("廓嬹抻橥", "acplW");
      I[251 ^ 149] = I("抠凛", "VAswy");
      I[27 ^ 116] = I("妄喵冼", "GYRJP");
      I[1 ^ 113] = I("帵", "HpjNY");
      I[23 ^ 102] = I("澙仫屺", "QYFym");
      I[246 ^ 132] = I("案唞", "VTQCK");
      I[195 ^ 176] = I("侘既昿榋", "SvlpT");
      I[11 ^ 127] = I("厩汃", "nPrzy");
      I[234 ^ 159] = I("樘対", "XiQyH");
      I[18 ^ 100] = I("僁偆", "TkqAZ");
      I[23 ^ 96] = I("慎呼", "ihzkb");
      I[44 ^ 84] = I("澥扩", "jmMkQ");
      I[208 ^ 169] = I("氡枯", "uymnR");
      I[8 ^ 114] = I("勔屎", "trMdl");
      I[94 ^ 37] = I("欿刵", "oenOx");
      I[35 ^ 95] = I("喺彼旮岲嫈", "NLcIr");
      I[224 ^ 157] = I("倉嵞", "tYODp");
      I[59 ^ 69] = I("朊", "eYnIB");
      I[117 + 88 - 78 + 0] = I("声悌偣", "iejRr");
      I[124 + 62 - 104 + 46] = I("姺忷滫啹", "PJUoP");
      I[89 + 4 - 58 + 94] = I("\u00108?*\u001728t7\u001d7?5(\u0011?3&d\f<&1d", "EVTDx");
      I[124 + 110 - 149 + 45] = I("揟囪弯", "RwvJr");
      I[101 + 71 - 120 + 79] = I("擁曮檗婈斒", "HHJAR");
      I[109 + 65 - 122 + 80] = I("晎愨柂嗯嶺", "VikyW");
      I[27 + 115 - 109 + 100] = I("勰增剑昏", "ewsuq");
      I[1 + 102 - 45 + 76] = I("汚椀嫴懘", "NVjFR");
      I[97 + 120 - 100 + 18] = I("每嚲", "nCQes");
      I[63 + 123 - 96 + 46] = I("噑冕", "CwkOO");
      I[53 + 87 - 97 + 94] = I("减煡", "wxRRm");
      I[94 + 126 - 206 + 124] = I("孅桘", "EUBFt");
      I[129 + 82 - 116 + 44] = I("採毩", "btThP");
      I[72 + 107 - 105 + 66] = I("棰姽", "geBMg");
      I[65 + 98 - 38 + 16] = I("唫扁", "BeHPw");
      I[1 + 120 - -14 + 7] = I("拴椊", "sHecH");
      I[109 + 60 - 47 + 21] = I("峓烛", "OQNMa");
      I[86 + 21 - 90 + 127] = I("峈姉", "ivxbl");
      I[99 + 104 - 94 + 36] = I("壞儣", "UZpQj");
      I[117 + 19 - 111 + 121] = I("昰击", "rCYOV");
      I[125 + 117 - 174 + 79] = I("仳檤", "ECqoZ");
      I[41 + 12 - -1 + 94] = I("孚榭", "IhTQM");
      I[75 + 13 - 62 + 123] = I("丩捏", "BedaE");
      I[23 + 107 - 81 + 101] = I("咏廿", "aLRpC");
      I[43 + 101 - 87 + 94] = I("檏", "tOVtr");
      I[60 + 103 - 123 + 112] = I("冉喅屣殜", "ZXrpJ");
      I[54 + 80 - 107 + 126] = I("彌棿", "lZuTr");
      I[64 + 51 - 15 + 54] = I("妉巒晜嗞", "OwHjw");
      I[6 + 20 - -50 + 79] = I("憁哶扲恑嘝", "ojcQz");
      I[77 + 47 - 12 + 44] = I("情", "YxOCz");
      I[3 + 54 - -37 + 63] = I("氉捨", "KcvwU");
      I[78 + 19 - 3 + 64] = I("栣憅", "zkDCU");
      I[3 + 105 - -30 + 21] = I("9\n\f\u001f\b\u001b\nG\u0002\u0002\u001e\r\u0006\u001d\u000e\u0016\u0001\u0015Q\u0013\u0015\u0014\u0002Q", "ldgqg");
      I[45 + 79 - 9 + 45] = I("寑", "FduVN");
      I[96 + 102 - 193 + 156] = I("实潄昴嗹宾", "dRpLk");
      I[157 + 23 - 121 + 103] = I("殽", "uaufQ");
      I[137 + 0 - 117 + 143] = I("堘儉敉擇", "ACxjg");
      I[130 + 20 - 130 + 144] = I("匳榫卮券敨", "vPJOX");
      I[114 + 145 - 220 + 126] = I("宄凒", "krmuz");
      I[46 + 20 - -18 + 82] = I("孻媬", "CHoWQ");
      I[84 + 150 - 206 + 139] = I("姐", "wKhIc");
      I[143 + 15 - 81 + 91] = I("役", "FtrlA");
   }

   public void setClean() {
      this.dirty = (boolean)"".length();
      this.lock.readLock().lock();
      Iterator var1 = this.entries.values().iterator();

      do {
         if (!var1.hasNext()) {
            this.lock.readLock().unlock();
            return;
         }

         EntityDataManager.DataEntry var2 = (EntityDataManager.DataEntry)var1.next();
         var2.setDirty((boolean)"".length());
         "".length();
      } while(4 >= 0);

      throw null;
   }

   public boolean isEmpty() {
      return this.empty;
   }

   protected <T> void setEntryValue(EntityDataManager.DataEntry<T> var1, EntityDataManager.DataEntry<?> var2) {
      var1.setValue(var2.getValue());
   }

   private static <T> void writeEntry(PacketBuffer var0, EntityDataManager.DataEntry<T> var1) throws IOException {
      String var10000 = I[226 ^ 150];
      String var10001 = I[49 ^ 68];
      String var10002 = I[204 ^ 186];
      var10001 = I[254 ^ 137];
      var10000 = I[69 ^ 61];
      var10001 = I[45 ^ 84];
      var10002 = I[221 ^ 167];
      var10001 = I[100 ^ 31];
      DataParameter var2 = var1.getKey();
      int var3 = DataSerializers.getSerializerId(var2.getSerializer());
      if (var3 < 0) {
         I[54 ^ 74].length();
         I[189 ^ 192].length();
         I[238 ^ 144].length();
         I[18 + 52 - -22 + 35].length();
         I[0 + 74 - 59 + 113].length();
         EncoderException var4 = new EncoderException(I[41 + 85 - 38 + 41] + var2.getSerializer());
         I[50 + 91 - 14 + 3].length();
         I[32 + 105 - 71 + 65].length();
         throw var4;
      } else {
         var0.writeByte(var2.getId());
         I[39 + 120 - 140 + 113].length();
         var0.writeVarIntToBuffer(var3);
         I[80 + 61 - 60 + 52].length();
         I[52 + 116 - 109 + 75].length();
         var2.getSerializer().write(var0, var1.getValue());
      }
   }

   @Nullable
   public List<EntityDataManager.DataEntry<?>> getDirty() {
      ArrayList var1 = null;
      if (this.dirty) {
         this.lock.readLock().lock();
         Iterator var2 = this.entries.values().iterator();

         while(var2.hasNext()) {
            EntityDataManager.DataEntry var3 = (EntityDataManager.DataEntry)var2.next();
            if (var3.isDirty()) {
               var3.setDirty((boolean)"".length());
               if (var1 == null) {
                  var1 = Lists.newArrayList();
               }

               var1.add(var3.func_192735_d());
               I[91 ^ 48].length();
               I[0 ^ 108].length();
               I[170 ^ 199].length();
            }

            "".length();
            if (0 <= -1) {
               throw null;
            }
         }

         this.lock.readLock().unlock();
      }

      this.dirty = (boolean)"".length();
      return var1;
   }

   public <T> void setDirty(DataParameter<T> var1) {
      this.getEntry(var1).dirty = (boolean)" ".length();
      I[58 ^ 95].length();
      this.dirty = (boolean)" ".length();
   }

   public <T> void set(DataParameter<T> var1, T var2) {
      EntityDataManager.DataEntry var3 = this.getEntry(var1);
      if (ObjectUtils.notEqual(var2, var3.getValue())) {
         var3.setValue(var2);
         this.entity.notifyDataManagerChange(var1);
         var3.setDirty((boolean)" ".length());
         this.dirty = (boolean)" ".length();
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > -1);

      throw null;
   }

   public void setEntryValues(List<EntityDataManager.DataEntry<?>> var1) {
      this.lock.writeLock().lock();
      Iterator var2 = var1.iterator();

      do {
         if (!var2.hasNext()) {
            this.lock.writeLock().unlock();
            this.dirty = (boolean)" ".length();
            return;
         }

         EntityDataManager.DataEntry var3 = (EntityDataManager.DataEntry)var2.next();
         EntityDataManager.DataEntry var4 = (EntityDataManager.DataEntry)this.entries.get(var3.getKey().getId());
         if (var4 != null) {
            this.setEntryValue(var4, var3);
            this.entity.notifyDataManagerChange(var3.getKey());
         }

         "".length();
      } while(2 > -1);

      throw null;
   }

   public boolean isDirty() {
      return this.dirty;
   }

   public static <T> DataParameter<T> createKey(Class<? extends Entity> var0, DataSerializer<T> var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[45 ^ 41];
      var10001 = I[71 ^ 66];
      var10002 = I[158 ^ 152];
      var10001 = I[76 ^ 75];
      var10000 = I[31 ^ 23];
      var10001 = I[200 ^ 193];
      var10002 = I[206 ^ 196];
      var10001 = I[48 ^ 59];
      if (LOGGER.isDebugEnabled()) {
         label43: {
            try {
               Class var2 = Class.forName(Thread.currentThread().getStackTrace()["  ".length()].getClassName());
               if (!var2.equals(var0)) {
                  Logger var7 = LOGGER;
                  var10001 = I[88 ^ 84];
                  I[201 ^ 196].length();
                  var7.debug(var10001, var0, var2, new RuntimeException());
               }
            } catch (ClassNotFoundException var5) {
               break label43;
            }

            "".length();
            if (4 < -1) {
               throw null;
            }
         }
      }

      int var6;
      if (NEXT_ID_MAP.containsKey(var0)) {
         var6 = (Integer)NEXT_ID_MAP.get(var0) + " ".length();
         "".length();
         if (0 >= 4) {
            throw null;
         }
      } else {
         int var3 = "".length();
         Class var4 = var0;

         while(var4 != Entity.class) {
            var4 = var4.getSuperclass();
            if (NEXT_ID_MAP.containsKey(var4)) {
               var3 = (Integer)NEXT_ID_MAP.get(var4) + " ".length();
               "".length();
               if (3 >= 4) {
                  throw null;
               }
               break;
            }
         }

         var6 = var3;
      }

      if (var6 > 154 + 56 - 196 + 240) {
         I[162 ^ 172].length();
         I[175 ^ 160].length();
         I[43 ^ 59].length();
         I[72 ^ 89].length();
         IllegalArgumentException var8 = new IllegalArgumentException(I[84 ^ 70] + var6 + I[136 ^ 155] + (67 + 74 - 95 + 208) + I[159 ^ 139]);
         I[19 ^ 6].length();
         I[208 ^ 198].length();
         throw var8;
      } else {
         NEXT_ID_MAP.put(var0, var6);
         I[88 ^ 79].length();
         I[31 ^ 7].length();
         return var1.createKey(var6);
      }
   }

   public void writeEntries(PacketBuffer var1) throws IOException {
      this.lock.readLock().lock();
      Iterator var2 = this.entries.values().iterator();

      do {
         if (!var2.hasNext()) {
            this.lock.readLock().unlock();
            var1.writeByte(212 + 181 - 262 + 124);
            I[12 ^ 98].length();
            I[34 ^ 77].length();
            I[215 ^ 167].length();
            return;
         }

         EntityDataManager.DataEntry var3 = (EntityDataManager.DataEntry)var2.next();
         writeEntry(var1, var3);
         "".length();
      } while(2 != 1);

      throw null;
   }

   static {
      I();
      LOGGER = LogManager.getLogger();
      NEXT_ID_MAP = Maps.newHashMap();
   }

   public static class DataEntry<T> {
      // $FF: synthetic field
      private boolean dirty;
      // $FF: synthetic field
      private T value;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final DataParameter<T> key;

      public void setValue(T var1) {
         this.value = var1;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 != 0);

         throw null;
      }

      public DataParameter<T> getKey() {
         return this.key;
      }

      public EntityDataManager.DataEntry<T> func_192735_d() {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         I[101 ^ 97].length();
         I[12 ^ 9].length();
         I[32 ^ 38].length();
         I[147 ^ 148].length();
         I[76 ^ 68].length();
         return new EntityDataManager.DataEntry(this.key, this.key.getSerializer().func_192717_a(this.value));
      }

      public boolean isDirty() {
         return this.dirty;
      }

      public void setDirty(boolean var1) {
         this.dirty = var1;
      }

      public T getValue() {
         return this.value;
      }

      public DataEntry(DataParameter<T> var1, T var2) {
         this.key = var1;
         this.value = var2;
         this.dirty = (boolean)" ".length();
      }

      private static void I() {
         I = new String[52 ^ 61];
         I["".length()] = I("偋煾", "DsDcY");
         I[" ".length()] = I("殨婧", "VIpYm");
         I["  ".length()] = I("悫惫", "jhlLb");
         I["   ".length()] = I("偕晀", "GPTeb");
         I[170 ^ 174] = I("数壩前游", "yEzEe");
         I[4 ^ 1] = I("漾屉坽", "SsGgD");
         I[120 ^ 126] = I("晳嬾桰挋", "vlXpH");
         I[122 ^ 125] = I("淛昿", "ItMIf");
         I[47 ^ 39] = I("浲叱俴", "YcFNr");
      }

      static {
         I();
      }
   }
}

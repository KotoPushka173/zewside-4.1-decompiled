package net.minecraft.enchantment;

import java.util.Random;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public class EnchantmentDurability extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   protected EnchantmentDurability(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.BREAKABLE, var2);
      this.setName(I["".length()]);
   }

   public boolean canApply(ItemStack var1) {
      int var10000;
      if (var1.isItemStackDamageable()) {
         var10000 = " ".length();
         "".length();
         if (3 <= -1) {
            throw null;
         }
      } else {
         var10000 = super.canApply(var1);
      }

      return (boolean)var10000;
   }

   private static void I() {
      I = new String[134 ^ 130];
      I["".length()] = I("\u0015\u0006+\u0014\b\u0018\u001f0\u0001\u0013", "qsYuj");
      I[" ".length()] = I("契斡凴唳", "extDI");
      I["  ".length()] = I("埻噬帚垰", "rJHpJ");
      I["   ".length()] = I("亯冊寧渄", "bpaMV");
   }

   static {
      I();
   }

   public int getMaxLevel() {
      return "   ".length();
   }

   public int getMaxEnchantability(int var1) {
      return super.getMinEnchantability(var1) + (187 ^ 137);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 4);

      throw null;
   }

   public static boolean negateDamage(ItemStack var0, int var1, Random var2) {
      if (var0.getItem() instanceof ItemArmor && var2.nextFloat() < 0.6F) {
         return (boolean)"".length();
      } else {
         int var10000;
         if (var2.nextInt(var1 + " ".length()) > 0) {
            var10000 = " ".length();
            "".length();
            if (1 == 4) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public int getMinEnchantability(int var1) {
      int var10000 = 163 ^ 166;
      int var10002 = " ".length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      return var10000 + (var1 - var10002) * (201 ^ 193);
   }
}

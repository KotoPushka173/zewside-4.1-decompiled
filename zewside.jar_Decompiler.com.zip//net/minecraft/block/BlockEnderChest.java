package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.InventoryEnderChest;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockEnderChest extends BlockContainer {
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   protected static final AxisAlignedBB ENDER_CHEST_AABB;
   // $FF: synthetic field
   private static final String[] I;

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   protected boolean canSilkHarvest() {
      return (boolean)" ".length();
   }

   private static void I() {
      I = new String[102 ^ 122];
      I["".length()] = I("启", "nISYF");
      I[" ".length()] = I("涝", "agoyb");
      I["  ".length()] = I("倓孻", "FdGYf");
      I["   ".length()] = I("汩忳", "aPSoJ");
      I[175 ^ 171] = I("挰拺", "ucIIC");
      I[11 ^ 14] = I("炏寏", "ywDJd");
      I[197 ^ 195] = I("惡氯歂旓停", "xtwGx");
      I[159 ^ 152] = I("丕", "IqCpq");
      I[49 ^ 57] = I("檸啓峹洹倄", "kIgTA");
      I[3 ^ 10] = I("岠", "uEqAe");
      I[77 ^ 71] = I("汞嵭傊晏", "bYLPV");
      I[90 ^ 81] = I("媰宺", "QPZVI");
      I[6 ^ 10] = I("澊某俔啸", "CjeJK");
      I[83 ^ 94] = I("掮润", "BEBrq");
      I[175 ^ 161] = I("棭剗", "MKlKZ");
      I[40 ^ 39] = I("拱幥", "oQJxR");
      I[175 ^ 191] = I("汧昄", "tzwha");
      I[82 ^ 67] = I("淤敉", "dTsdn");
      I[23 ^ 5] = I("嫽廐", "ishYg");
      I[137 ^ 154] = I("淘巾", "UfqYH");
      I[32 ^ 52] = I("榾慶", "FXNsd");
      I[51 ^ 38] = I("凖侇", "Ummdy");
      I[58 ^ 44] = I("儭", "hLinP");
      I[66 ^ 85] = I("帋", "JniWs");
      I[86 ^ 78] = I("惖", "ojJlY");
      I[154 ^ 131] = I("佳會", "pUVVk");
      I[3 ^ 25] = I("烌", "UTnzy");
      I[0 ^ 27] = I("氧敉沃", "bUjpa");
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      var1.setBlockState(var2, var3.withProperty(FACING, var4.getHorizontalFacing().getOpposite()), "  ".length());
      I["".length()].length();
      I[" ".length()].length();
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      InventoryEnderChest var10 = var4.getInventoryEnderChest();
      TileEntity var11 = var1.getTileEntity(var2);
      if (var10 != null && var11 instanceof TileEntityEnderChest) {
         if (var1.getBlockState(var2.up()).isNormalCube()) {
            return (boolean)" ".length();
         } else if (var1.isRemote) {
            return (boolean)" ".length();
         } else {
            var10.setChestTileEntity((TileEntityEnderChest)var11);
            var4.displayGUIChest(var10);
            var4.addStat(StatList.ENDERCHEST_OPENED);
            return (boolean)" ".length();
         }
      } else {
         return (boolean)" ".length();
      }
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      int var5 = "".length();

      do {
         if (var5 >= "   ".length()) {
            return;
         }

         int var10000 = var4.nextInt("  ".length()) * "  ".length();
         int var10001 = " ".length();
         I[101 ^ 109].length();
         I[112 ^ 121].length();
         I[76 ^ 70].length();
         int var6 = var10000 - var10001;
         var10000 = var4.nextInt("  ".length()) * "  ".length();
         var10001 = " ".length();
         I[158 ^ 149].length();
         I[155 ^ 151].length();
         int var7 = var10000 - var10001;
         double var8 = (double)var3.getX() + 0.5D + 0.25D * (double)var6;
         double var10 = (double)((float)var3.getY() + var4.nextFloat());
         double var12 = (double)var3.getZ() + 0.5D + 0.25D * (double)var7;
         double var14 = (double)(var4.nextFloat() * (float)var6);
         double var20 = (double)var4.nextFloat();
         I[17 ^ 28].length();
         double var16 = (var20 - 0.5D) * 0.125D;
         double var18 = (double)(var4.nextFloat() * (float)var7);
         var2.spawnParticle(EnumParticleTypes.PORTAL, var8, var10, var12, var14, var16, var18);
         ++var5;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[168 ^ 166];
      String var10001 = I[140 ^ 131];
      String var10002 = I[3 ^ 19];
      var10001 = I[22 ^ 7];
      var10000 = I[160 ^ 178];
      var10001 = I[90 ^ 73];
      var10002 = I[209 ^ 197];
      var10001 = I[172 ^ 185];
      I[116 ^ 98].length();
      I[124 ^ 107].length();
      I[185 ^ 161].length();
      I[166 ^ 191].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[186 ^ 160].length();
      I[122 ^ 97].length();
      var10003["".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   protected BlockEnderChest() {
      super(Material.ROCK);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return ENDER_CHEST_AABB;
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["  ".length()];
      String var10001 = I["   ".length()];
      String var10002 = I[191 ^ 187];
      var10001 = I[105 ^ 108];
      I[124 ^ 122].length();
      I[63 ^ 56].length();
      return new TileEntityEnderChest();
   }

   public boolean func_190946_v(IBlockState var1) {
      return (boolean)" ".length();
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.OBSIDIAN);
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.ENTITYBLOCK_ANIMATED;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState getStateFromMeta(int var1) {
      EnumFacing var2 = EnumFacing.getFront(var1);
      if (var2.getAxis() == EnumFacing.Axis.Y) {
         var2 = EnumFacing.NORTH;
      }

      return this.getDefaultState().withProperty(FACING, var2);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, var8.getHorizontalFacing().getOpposite());
   }

   public int quantityDropped(Random var1) {
      return 144 ^ 152;
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      ENDER_CHEST_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.875D, 0.9375D);
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumFacing)var1.getValue(FACING)).getIndex();
   }
}

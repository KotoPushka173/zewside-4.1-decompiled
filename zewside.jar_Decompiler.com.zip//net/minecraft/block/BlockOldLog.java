package net.minecraft.block;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockOldLog extends BlockLog {
   // $FF: synthetic field
   public static final PropertyEnum<BlockPlanks.EnumType> VARIANT;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 4);

      throw null;
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[175 ^ 171];
      var10001 = I[37 ^ 32];
      var10002 = I[131 ^ 133];
      var10001 = I[190 ^ 185];
      var10000 = I[39 ^ 47];
      var10001 = I[126 ^ 119];
      var10002 = I[135 ^ 141];
      var10001 = I[39 ^ 44];
      var10000 = I[73 ^ 69];
      var10001 = I[44 ^ 33];
      var10002 = I[204 ^ 194];
      var10001 = I[189 ^ 178];
      I[187 ^ 171].length();
      I[62 ^ 47].length();
      var2.add(new ItemStack(this, " ".length(), BlockPlanks.EnumType.OAK.getMetadata()));
      I[63 ^ 45].length();
      I[99 ^ 112].length();
      I[135 ^ 147].length();
      I[99 ^ 118].length();
      I[80 ^ 70].length();
      I[164 ^ 179].length();
      var2.add(new ItemStack(this, " ".length(), BlockPlanks.EnumType.SPRUCE.getMetadata()));
      I[113 ^ 105].length();
      I[169 ^ 176].length();
      I[37 ^ 63].length();
      I[57 ^ 34].length();
      I[64 ^ 92].length();
      var2.add(new ItemStack(this, " ".length(), BlockPlanks.EnumType.BIRCH.getMetadata()));
      I[65 ^ 92].length();
      I[185 ^ 167].length();
      I[19 ^ 12].length();
      I[62 ^ 30].length();
      I[185 ^ 152].length();
      I[172 ^ 142].length();
      var2.add(new ItemStack(this, " ".length(), BlockPlanks.EnumType.JUNGLE.getMetadata()));
      I[51 ^ 16].length();
      I[166 ^ 130].length();
      I[34 ^ 7].length();
      I[164 ^ 130].length();
   }

   private static void I() {
      I = new String[80 ^ 20];
      I["".length()] = I("佨墣", "wcyNN");
      I[" ".length()] = I("浨州", "iLVxh");
      I["  ".length()] = I("毴島", "MLLHM");
      I["   ".length()] = I("嗱坜", "oFjAQ");
      I[185 ^ 189] = I("烎櫦", "yuVZn");
      I[38 ^ 35] = I("敶湍", "EWrdz");
      I[60 ^ 58] = I("弦椏", "WPWrS");
      I[97 ^ 102] = I("扖晾", "vXOLc");
      I[173 ^ 165] = I("埄抯", "KHcPt");
      I[9 ^ 0] = I("湤壇", "IReLl");
      I[97 ^ 107] = I("朐攏", "BuqJw");
      I[57 ^ 50] = I("柔灸", "eThWT");
      I[69 ^ 73] = I("棓們", "zYpgW");
      I[37 ^ 40] = I("崒堅", "JJquN");
      I[112 ^ 126] = I("岞厢", "ThpgI");
      I[144 ^ 159] = I("亘喙", "hYvAf");
      I[77 ^ 93] = I("拫憺唾", "OcvgB");
      I[40 ^ 57] = I("椫廼", "FqIwc");
      I[114 ^ 96] = I("喇曁", "TZwAQ");
      I[172 ^ 191] = I("刱庋惲氚", "joevg");
      I[143 ^ 155] = I("憃泓宐", "VHMpQ");
      I[150 ^ 131] = I("梁", "FLjZe");
      I[165 ^ 179] = I("摢潟儁嬻弦", "MQpkp");
      I[123 ^ 108] = I("堑", "bGjfn");
      I[28 ^ 4] = I("柣堔寊住杆", "ZVNoW");
      I[217 ^ 192] = I("库悉搷", "vjcVi");
      I[33 ^ 59] = I("柈兂歼戺嗏", "Lkypm");
      I[172 ^ 183] = I("溤噷", "vqihN");
      I[16 ^ 12] = I("忲", "QdaND");
      I[167 ^ 186] = I("廍僅坔", "VDiGq");
      I[170 ^ 180] = I("樣撺嘁", "DLNHN");
      I[52 ^ 43] = I("漲恲", "dOcJO");
      I[8 ^ 40] = I("峈様倮楨", "ndpfD");
      I[94 ^ 127] = I("堉", "GddzA");
      I[224 ^ 194] = I("佋丄旴榰淐", "bRAVf");
      I[67 ^ 96] = I("勫歱", "yfzWt");
      I[27 ^ 63] = I("婜", "liKXV");
      I[133 ^ 160] = I("娚僟壌柡歕", "kazTA");
      I[67 ^ 101] = I("嘂幨婵潎堽", "gWAzN");
      I[171 ^ 140] = I("憨吁", "cUPRN");
      I[154 ^ 178] = I("娴愾", "EpUxq");
      I[118 ^ 95] = I("墊上", "RFTKG");
      I[61 ^ 23] = I("晍暑", "xQPhI");
      I[191 ^ 148] = I("侥懀", "AunFe");
      I[134 ^ 170] = I("崱戭", "bizov");
      I[187 ^ 150] = I("榜抗", "wonjs");
      I[109 ^ 67] = I("擹僯", "dYDjR");
      I[151 ^ 184] = I("溭愈", "dZSRj");
      I[164 ^ 148] = I("漨宕", "FapIL");
      I[44 ^ 29] = I("憺吲", "EAOZU");
      I[113 ^ 67] = I("枟崠", "UqXbN");
      I[47 ^ 28] = I("嵯", "EwYOg");
      I[183 ^ 131] = I("仈寥", "ForuS");
      I[134 ^ 179] = I("妌摷乮拶峟", "cRLbk");
      I[104 ^ 94] = I("媹檬墒拈吗", "XPRjt");
      I[29 ^ 42] = I("夒廍敽", "cNCcV");
      I[10 ^ 50] = I("材", "ZzqEb");
      I[31 ^ 38] = I("洧佗", "GsaLX");
      I[190 ^ 132] = I("岻揓勼", "uHBvp");
      I[182 ^ 141] = I("旴像", "TsexB");
      I[32 ^ 28] = I("嫈暓", "OCLrw");
      I[112 ^ 77] = I("囦仩", "heIft");
      I[22 ^ 40] = I("愪潹", "OMFsF");
      I[174 ^ 145] = I("湤孌", "fSwaR");
      I[26 ^ 90] = I("励巒斳", "IJQVN");
      I[83 ^ 18] = I("槶斬侼", "utqRb");
      I[195 ^ 129] = I("叶湈", "QyWYY");
      I[213 ^ 150] = I("&\u00123\u0013\u0016>\u0007", "PsAzw");
   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I[45 ^ 17];
      String var10001 = I[123 ^ 70];
      String var10002 = I[177 ^ 143];
      var10001 = I[46 ^ 17];
      I[14 ^ 78].length();
      I[254 ^ 191].length();
      I[27 ^ 89].length();
      return new ItemStack(Item.getItemFromBlock(this), " ".length(), ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata());
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[38 ^ 1];
      String var10001 = I[62 ^ 22];
      String var10002 = I[65 ^ 104];
      var10001 = I[16 ^ 58];
      var10000 = I[160 ^ 139];
      var10001 = I[67 ^ 111];
      var10002 = I[36 ^ 9];
      var10001 = I[89 ^ 119];
      var10000 = I[0 ^ 47];
      var10001 = I[13 ^ 61];
      var10002 = I[173 ^ 156];
      var10001 = I[101 ^ 87];
      I[13 ^ 62].length();
      I[166 ^ 146].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[28 ^ 41].length();
      I[183 ^ 129].length();
      I[3 ^ 52].length();
      var10003["".length()] = VARIANT;
      I[126 ^ 70].length();
      I[75 ^ 114].length();
      I[148 ^ 174].length();
      I[35 ^ 24].length();
      var10003[" ".length()] = LOG_AXIS;
      return new BlockStateContainer(this, var10003);
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      BlockPlanks.EnumType var4 = (BlockPlanks.EnumType)var1.getValue(VARIANT);
      switch(null.$SwitchMap$net$minecraft$block$BlockLog$EnumAxis[((BlockLog.EnumAxis)var1.getValue(LOG_AXIS)).ordinal()]) {
      case 1:
      case 2:
      case 3:
      default:
         switch(null.$SwitchMap$net$minecraft$block$BlockPlanks$EnumType[var4.ordinal()]) {
         case 1:
         default:
            return BlockPlanks.EnumType.SPRUCE.getMapColor();
         case 2:
            return BlockPlanks.EnumType.DARK_OAK.getMapColor();
         case 3:
            return MapColor.QUARTZ;
         case 4:
            return BlockPlanks.EnumType.SPRUCE.getMapColor();
         }
      case 4:
         return var4.getMapColor();
      }
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
      switch(null.$SwitchMap$net$minecraft$block$BlockLog$EnumAxis[((BlockLog.EnumAxis)var1.getValue(LOG_AXIS)).ordinal()]) {
      case 1:
         var2 |= 73 ^ 77;
         "".length();
         if (3 < -1) {
            throw null;
         }
         break;
      case 2:
         var2 |= 69 ^ 77;
         "".length();
         if (false) {
            throw null;
         }
         break;
      case 3:
         var2 |= 151 ^ 155;
      }

      return var2;
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[108 ^ 47], BlockPlanks.EnumType.class, new Predicate<BlockPlanks.EnumType>() {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(0 < 1);

            throw null;
         }

         public boolean apply(@Nullable BlockPlanks.EnumType var1) {
            int var10000;
            if (var1.getMetadata() < (26 ^ 30)) {
               var10000 = " ".length();
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      });
   }

   public BlockOldLog() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockPlanks.EnumType.OAK).withProperty(LOG_AXIS, BlockLog.EnumAxis.Y));
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var2 = this.getDefaultState().withProperty(VARIANT, BlockPlanks.EnumType.byMetadata((var1 & "   ".length()) % (151 ^ 147)));
      switch(var1 & (21 ^ 25)) {
      case 0:
         var2 = var2.withProperty(LOG_AXIS, BlockLog.EnumAxis.Y);
         "".length();
         if (4 < 4) {
            throw null;
         }
         break;
      case 4:
         var2 = var2.withProperty(LOG_AXIS, BlockLog.EnumAxis.X);
         "".length();
         if (1 == 3) {
            throw null;
         }
         break;
      case 8:
         var2 = var2.withProperty(LOG_AXIS, BlockLog.EnumAxis.Z);
         "".length();
         if (4 != 4) {
            throw null;
         }
         break;
      default:
         var2 = var2.withProperty(LOG_AXIS, BlockLog.EnumAxis.NONE);
      }

      return var2;
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
   }
}

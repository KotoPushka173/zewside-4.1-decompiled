package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityNote;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockNote extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final List<SoundEvent> INSTRUMENTS;

   private SoundEvent getInstrument(int var1) {
      if (var1 < 0 || var1 >= INSTRUMENTS.size()) {
         var1 = "".length();
      }

      return (SoundEvent)INSTRUMENTS.get(var1);
   }

   public boolean eventReceived(IBlockState var1, World var2, BlockPos var3, int var4, int var5) {
      int var10002 = 44 ^ 32;
      I[22 ^ 16].length();
      float var6 = (float)Math.pow(2.0D, (double)(var5 - var10002) / 12.0D);
      var2.playSound((EntityPlayer)null, var3, this.getInstrument(var4), SoundCategory.RECORDS, 3.0F, var6);
      var2.spawnParticle(EnumParticleTypes.NOTE, (double)var3.getX() + 0.5D, (double)var3.getY() + 1.2D, (double)var3.getZ() + 0.5D, (double)var5 / 24.0D, 0.0D, 0.0D);
      return (boolean)" ".length();
   }

   static {
      I();
      SoundEvent[] var10000 = new SoundEvent[66 ^ 72];
      var10000["".length()] = SoundEvents.BLOCK_NOTE_HARP;
      var10000[" ".length()] = SoundEvents.BLOCK_NOTE_BASEDRUM;
      var10000["  ".length()] = SoundEvents.BLOCK_NOTE_SNARE;
      var10000["   ".length()] = SoundEvents.BLOCK_NOTE_HAT;
      var10000[80 ^ 84] = SoundEvents.BLOCK_NOTE_BASS;
      var10000[191 ^ 186] = SoundEvents.field_193809_ey;
      var10000[148 ^ 146] = SoundEvents.field_193807_ew;
      var10000[158 ^ 153] = SoundEvents.field_193810_ez;
      var10000[143 ^ 135] = SoundEvents.field_193808_ex;
      var10000[82 ^ 91] = SoundEvents.field_193785_eE;
      INSTRUMENTS = Lists.newArrayList(var10000);
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[80 ^ 84].length();
      I[176 ^ 181].length();
      return new TileEntityNote();
   }

   public void onBlockClicked(World var1, BlockPos var2, EntityPlayer var3) {
      if (!var1.isRemote) {
         TileEntity var4 = var1.getTileEntity(var2);
         if (var4 instanceof TileEntityNote) {
            ((TileEntityNote)var4).triggerNote(var1, var2);
            var3.addStat(StatList.NOTEBLOCK_PLAYED);
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 2);

      throw null;
   }

   public BlockNote() {
      super(Material.WOOD);
      this.setCreativeTab(CreativeTabs.REDSTONE);
   }

   private static void I() {
      I = new String[132 ^ 131];
      I["".length()] = I("押沝", "Kyqxl");
      I[" ".length()] = I("囤关", "GRNXS");
      I["  ".length()] = I("掤漾", "kiLqV");
      I["   ".length()] = I("煶柲", "OYhhi");
      I[37 ^ 33] = I("半奅湁溱啄", "KdgKE");
      I[177 ^ 180] = I("殌兼枍", "xvxsZ");
      I[186 ^ 188] = I("僤寢涅梃媚", "eRfaU");
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         TileEntity var10 = var1.getTileEntity(var2);
         if (var10 instanceof TileEntityNote) {
            TileEntityNote var11 = (TileEntityNote)var10;
            var11.changePitch();
            var11.triggerNote(var1, var2);
            var4.addStat(StatList.NOTEBLOCK_TUNED);
         }

         return (boolean)" ".length();
      }
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      boolean var6 = var2.isBlockPowered(var3);
      TileEntity var7 = var2.getTileEntity(var3);
      if (var7 instanceof TileEntityNote) {
         TileEntityNote var8 = (TileEntityNote)var7;
         if (var8.previousRedstoneState != var6) {
            if (var6) {
               var8.triggerNote(var2, var3);
            }

            var8.previousRedstoneState = var6;
         }
      }

   }
}

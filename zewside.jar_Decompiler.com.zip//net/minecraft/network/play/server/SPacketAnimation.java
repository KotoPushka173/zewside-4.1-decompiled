package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketAnimation implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private int type;

   public int getAnimationType() {
      return this.type;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleAnimation(this);
   }

   private static void I() {
      I = new String[58 ^ 63];
      I["".length()] = I("且匿", "fSchO");
      I[" ".length()] = I("墮煿亰湭炬", "ulqFf");
      I["  ".length()] = I("凲", "XMBHP");
      I["   ".length()] = I("楻捪奮", "PtaDz");
      I[19 ^ 23] = I("嵽", "DqTRW");
   }

   static {
      I();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.type = var1.readUnsignedByte();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   public SPacketAnimation() {
   }

   public SPacketAnimation(Entity var1, int var2) {
      this.entityId = var1.getEntityId();
      this.type = var2;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeByte(this.type);
      I["  ".length()].length();
      I["   ".length()].length();
      I[75 ^ 79].length();
   }

   public int getEntityID() {
      return this.entityId;
   }
}

package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.handler.codec.CorruptedFrameException;
import java.util.List;

public class NettyVarint21FrameDecoder extends ByteToMessageDecoder {
   // $FF: synthetic field
   private static final String[] I;

   protected void decode(ChannelHandlerContext var1, ByteBuf var2, List<Object> var3) throws Exception {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[61 ^ 57];
      var10001 = I[144 ^ 149];
      var10002 = I[2 ^ 4];
      var10001 = I[119 ^ 112];
      var2.markReaderIndex();
      I[117 ^ 125].length();
      I[71 ^ 78].length();
      byte[] var4 = new byte["   ".length()];
      int var5 = "".length();

      do {
         if (var5 >= var4.length) {
            I[166 ^ 187].length();
            I[30 ^ 0].length();
            I[18 ^ 13].length();
            I[15 ^ 47].length();
            CorruptedFrameException var11 = new CorruptedFrameException(I[95 ^ 126]);
            I[169 ^ 139].length();
            I[100 ^ 71].length();
            I[9 ^ 45].length();
            I[69 ^ 96].length();
            I[53 ^ 19].length();
            throw var11;
         }

         if (!var2.isReadable()) {
            var2.resetReaderIndex();
            I[168 ^ 162].length();
            I[179 ^ 184].length();
            return;
         }

         var4[var5] = var2.readByte();
         if (var4[var5] >= 0) {
            I[116 ^ 120].length();
            I[161 ^ 172].length();
            I[147 ^ 157].length();
            PacketBuffer var6 = new PacketBuffer(Unpooled.wrappedBuffer(var4));

            label81: {
               try {
                  int var7 = var6.readVarIntFromBuffer();
                  if (var2.readableBytes() < var7) {
                     var2.resetReaderIndex();
                     I[161 ^ 178].length();
                     break label81;
                  }

                  var3.add(var2.readBytes(var7));
                  I[99 ^ 108].length();
                  I[102 ^ 118].length();
                  I[33 ^ 48].length();
               } catch (Throwable var10) {
                  var6.release();
                  I[32 ^ 55].length();
                  I[144 ^ 136].length();
                  I[17 ^ 8].length();
                  I[123 ^ 97].length();
                  I[139 ^ 144].length();
                  I[158 ^ 130].length();
                  throw var10;
               }

               var6.release();
               I[160 ^ 178].length();
               return;
            }

            var6.release();
            I[95 ^ 75].length();
            I[172 ^ 185].length();
            I[153 ^ 143].length();
            "".length();
            if (1 >= 2) {
               throw null;
            }

            return;
         }

         ++var5;
         "".length();
      } while(4 >= 2);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   static {
      I();
   }

   private static void I() {
      I = new String[60 ^ 27];
      I["".length()] = I("叆唆", "ywLoZ");
      I[" ".length()] = I("娿咲", "ZaRoY");
      I["  ".length()] = I("嗟尭", "GqPKm");
      I["   ".length()] = I("彾伓", "Lblnz");
      I[197 ^ 193] = I("庍勠", "xGArU");
      I[13 ^ 8] = I("槬挛", "Zokpg");
      I[177 ^ 183] = I("匈浱", "ylsnc");
      I[121 ^ 126] = I("檀瀪", "TFpfc");
      I[105 ^ 97] = I("個夙瀵", "fEXPg");
      I[185 ^ 176] = I("娐悿冠", "Pgrts");
      I[134 ^ 140] = I("湊卦", "JYWOw");
      I[123 ^ 112] = I("堨娩暭毀", "qhWzA");
      I[67 ^ 79] = I("栖府暕憫暶", "qWzNK");
      I[63 ^ 50] = I("曻", "nPrJP");
      I[24 ^ 22] = I("煢瀔堥", "cVrXv");
      I[186 ^ 181] = I("嫔歵漟", "ryvXw");
      I[130 ^ 146] = I("涯憿", "WESoR");
      I[161 ^ 176] = I("架備健柒嚀", "PHqmg");
      I[122 ^ 104] = I("嚤巷嶷", "Ddtee");
      I[141 ^ 158] = I("沊勋丁", "imqTw");
      I[94 ^ 74] = I("愆", "ALlkN");
      I[93 ^ 72] = I("旞徐接嶌永", "Fotwv");
      I[210 ^ 196] = I("媻", "rNKfC");
      I[32 ^ 55] = I("吱侍愮", "DhQvl");
      I[96 ^ 120] = I("潼拰奻濞", "nbwyQ");
      I[66 ^ 91] = I("濆揎损侍", "bTnzD");
      I[221 ^ 199] = I("旙弗憨", "Vmved");
      I[82 ^ 73] = I("滕歃濔仏欴", "guKNe");
      I[132 ^ 152] = I("妏", "bmElV");
      I[186 ^ 167] = I("刣惬叶垝", "LOigG");
      I[50 ^ 44] = I("帠摞揥殕", "OMEfh");
      I[96 ^ 127] = I("枤涃戮", "jsxkK");
      I[4 ^ 36] = I("桥瀕", "SmsWK");
      I[115 ^ 82] = I("\u001f*\u001c2\r\u001bo\u0005<\u001d\u0016=R!\u0011\u0012!RgH^-\u001b!", "sOrUy");
      I[65 ^ 99] = I("泶杼堀", "DFqZq");
      I[109 ^ 78] = I("佱", "fbuig");
      I[98 ^ 70] = I("湪娂", "AhmWt");
      I[154 ^ 191] = I("剼宥", "oOcUC");
      I[96 ^ 70] = I("咩娱忀暵坍", "oNpLV");
   }
}

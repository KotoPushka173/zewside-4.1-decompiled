package net.minecraft.network.play.server;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Team;

public class SPacketTeams implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private String nameTagVisibility;
   // $FF: synthetic field
   private int color;
   // $FF: synthetic field
   private String collisionRule;
   // $FF: synthetic field
   private String name;
   // $FF: synthetic field
   private String prefix;
   // $FF: synthetic field
   private final Collection<String> players;
   // $FF: synthetic field
   private String suffix;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int friendlyFlags;
   // $FF: synthetic field
   private int action;
   // $FF: synthetic field
   private String displayName;

   static {
      I();
   }

   public Collection<String> getPlayers() {
      return this.players;
   }

   public int getAction() {
      return this.action;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.name = var1.readStringFromBuffer(68 ^ 84);
      this.action = var1.readByte();
      if (this.action == 0 || this.action == "  ".length()) {
         this.displayName = var1.readStringFromBuffer(31 ^ 63);
         this.prefix = var1.readStringFromBuffer(14 ^ 30);
         this.suffix = var1.readStringFromBuffer(172 ^ 188);
         this.friendlyFlags = var1.readByte();
         this.nameTagVisibility = var1.readStringFromBuffer(117 ^ 85);
         this.collisionRule = var1.readStringFromBuffer(118 ^ 86);
         this.color = var1.readByte();
      }

      if (this.action == 0 || this.action == "   ".length() || this.action == (66 ^ 70)) {
         int var2 = var1.readVarIntFromBuffer();
         int var3 = "".length();

         while(var3 < var2) {
            this.players.add(var1.readStringFromBuffer(74 ^ 98));
            I[205 ^ 195].length();
            ++var3;
            "".length();
            if (-1 >= 3) {
               throw null;
            }
         }
      }

   }

   public String getNameTagVisibility() {
      return this.nameTagVisibility;
   }

   public SPacketTeams(ScorePlayerTeam var1, int var2) {
      this.name = I[20 ^ 16];
      this.displayName = I[88 ^ 93];
      this.prefix = I[198 ^ 192];
      this.suffix = I[73 ^ 78];
      this.nameTagVisibility = Team.EnumVisible.ALWAYS.internalName;
      this.collisionRule = Team.CollisionRule.ALWAYS.name;
      this.color = -" ".length();
      this.players = Lists.newArrayList();
      this.name = var1.getRegisteredName();
      this.action = var2;
      if (var2 == 0 || var2 == "  ".length()) {
         this.displayName = var1.getTeamName();
         this.prefix = var1.getColorPrefix();
         this.suffix = var1.getColorSuffix();
         this.friendlyFlags = var1.getFriendlyFlags();
         this.nameTagVisibility = var1.getNameTagVisibility().internalName;
         this.collisionRule = var1.getCollisionRule().name;
         this.color = var1.getChatFormat().getColorIndex();
      }

      if (var2 == 0) {
         this.players.addAll(var1.getMembershipCollection());
      }

   }

   public String getCollisionRule() {
      return this.collisionRule;
   }

   public String getPrefix() {
      return this.prefix;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.name);
      I[44 ^ 35].length();
      I[65 ^ 81].length();
      I[190 ^ 175].length();
      I[123 ^ 105].length();
      var1.writeByte(this.action);
      I[142 ^ 157].length();
      if (this.action == 0 || this.action == "  ".length()) {
         var1.writeString(this.displayName);
         I[5 ^ 17].length();
         var1.writeString(this.prefix);
         I[91 ^ 78].length();
         var1.writeString(this.suffix);
         I[175 ^ 185].length();
         I[16 ^ 7].length();
         I[186 ^ 162].length();
         I[126 ^ 103].length();
         var1.writeByte(this.friendlyFlags);
         I[41 ^ 51].length();
         I[153 ^ 130].length();
         var1.writeString(this.nameTagVisibility);
         I[34 ^ 62].length();
         var1.writeString(this.collisionRule);
         I[11 ^ 22].length();
         I[169 ^ 183].length();
         var1.writeByte(this.color);
         I[118 ^ 105].length();
         I[58 ^ 26].length();
      }

      if (this.action == 0 || this.action == "   ".length() || this.action == (119 ^ 115)) {
         var1.writeVarIntToBuffer(this.players.size());
         I[5 ^ 36].length();
         Iterator var2 = this.players.iterator();

         while(var2.hasNext()) {
            String var3 = (String)var2.next();
            var1.writeString(var3);
            I[87 ^ 117].length();
            I[134 ^ 165].length();
            I[182 ^ 146].length();
            "".length();
            if (3 < 1) {
               throw null;
            }
         }
      }

   }

   private static void I() {
      I = new String[132 ^ 161];
      I["".length()] = I("", "jCvSB");
      I[" ".length()] = I("", "nSLYH");
      I["  ".length()] = I("", "VOOvV");
      I["   ".length()] = I("", "tmzTM");
      I[161 ^ 165] = I("", "WXmqN");
      I[197 ^ 192] = I("", "RtZjs");
      I[137 ^ 143] = I("", "LsPod");
      I[103 ^ 96] = I("", "VERjQ");
      I[81 ^ 89] = I("", "XvQfd");
      I[24 ^ 17] = I("", "XZqRn");
      I[186 ^ 176] = I("", "FCJLS");
      I[40 ^ 35] = I("", "JGTqF");
      I[39 ^ 43] = I("\n=\u001c\u001a\u0002#x\u0005\u0007\u001e3x\n\u0017M-7\u0001\u001cM(*H\u001e\b&.\rR\u000b(*H\u0002\u0001&!\r\u0000M$7\u0006\u0001\u00195-\u000b\u0006\u00025", "GXhrm");
      I[23 ^ 26] = I("\u0014\u001f(+'6\u0000i1#*\u001d&&b&\u0016i<7(\u001ff7/4\u00070", "DsIRB");
      I[88 ^ 86] = I("旜歚抦", "YiIIp");
      I[153 ^ 150] = I("势堡唬煸枰", "AQdpI");
      I[67 ^ 83] = I("暚梗", "qxZPt");
      I[39 ^ 54] = I("嚑楳昙帶", "nLobm");
      I[210 ^ 192] = I("侨昱", "Ldmao");
      I[103 ^ 116] = I("潝煶嫷", "tWvOD");
      I[122 ^ 110] = I("烴", "JWHWi");
      I[89 ^ 76] = I("儇剟棽濾", "orjzi");
      I[24 ^ 14] = I("摸", "ZUFDj");
      I[17 ^ 6] = I("剦", "qiSVZ");
      I[146 ^ 138] = I("啀漩峭煦媎", "DAPcs");
      I[133 ^ 156] = I("椼", "GWMZI");
      I[154 ^ 128] = I("寂喇", "djLhJ");
      I[101 ^ 126] = I("姤噲", "JhCef");
      I[61 ^ 33] = I("噐椳捲写", "pKJhq");
      I[19 ^ 14] = I("濣消拥", "wMPjZ");
      I[143 ^ 145] = I("幹巣執", "YIuWL");
      I[182 ^ 169] = I("扭妴", "esbxW");
      I[95 ^ 127] = I("伎宁灯樗", "lilGc");
      I[131 ^ 162] = I("廠", "dqqRW");
      I[169 ^ 139] = I("唚搞哉剝允", "jBLMQ");
      I[0 ^ 35] = I("嚪", "hasjm");
      I[141 ^ 169] = I("栩", "BIoXk");
   }

   public SPacketTeams() {
      this.name = I["".length()];
      this.displayName = I[" ".length()];
      this.prefix = I["  ".length()];
      this.suffix = I["   ".length()];
      this.nameTagVisibility = Team.EnumVisible.ALWAYS.internalName;
      this.collisionRule = Team.CollisionRule.ALWAYS.name;
      this.color = -" ".length();
      this.players = Lists.newArrayList();
   }

   public int getFriendlyFlags() {
      return this.friendlyFlags;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 >= 1);

      throw null;
   }

   public String getDisplayName() {
      return this.displayName;
   }

   public String getName() {
      return this.name;
   }

   public String getSuffix() {
      return this.suffix;
   }

   public SPacketTeams(ScorePlayerTeam var1, Collection<String> var2, int var3) {
      this.name = I[202 ^ 194];
      this.displayName = I[141 ^ 132];
      this.prefix = I[133 ^ 143];
      this.suffix = I[140 ^ 135];
      this.nameTagVisibility = Team.EnumVisible.ALWAYS.internalName;
      this.collisionRule = Team.CollisionRule.ALWAYS.name;
      this.color = -" ".length();
      this.players = Lists.newArrayList();
      if (var3 != "   ".length() && var3 != (50 ^ 54)) {
         throw new IllegalArgumentException(I[122 ^ 118]);
      } else if (var2 != null && !var2.isEmpty()) {
         this.action = var3;
         this.name = var1.getRegisteredName();
         this.players.addAll(var2);
         "".length();
         if (4 == 1) {
            throw null;
         }
      } else {
         throw new IllegalArgumentException(I[172 ^ 161]);
      }
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleTeams(this);
   }

   public int getColor() {
      return this.color;
   }
}

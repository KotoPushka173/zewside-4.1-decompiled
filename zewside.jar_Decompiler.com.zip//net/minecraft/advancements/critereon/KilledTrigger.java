package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;

public class KilledTrigger implements ICriterionTrigger<KilledTrigger.Instance> {
   // $FF: synthetic field
   private final ResourceLocation field_192214_b;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, KilledTrigger.Listeners> field_192213_a = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;

   public KilledTrigger(ResourceLocation var1) {
      this.field_192214_b = var1;
   }

   public KilledTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[181 ^ 187];
      String var10001 = I[86 ^ 89];
      String var10002 = I[120 ^ 104];
      var10001 = I[123 ^ 106];
      I[176 ^ 162].length();
      I[212 ^ 199].length();
      return new KilledTrigger.Instance(this.field_192214_b, EntityPredicate.func_192481_a(var1.get(I[178 ^ 166])), DamageSourcePredicate.func_192447_a(var1.get(I[181 ^ 160])));
   }

   public ResourceLocation func_192163_a() {
      return this.field_192214_b;
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 >= 1);

      throw null;
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192213_a.remove(var1);
      I[18 ^ 30].length();
      I[107 ^ 102].length();
   }

   public void func_192211_a(EntityPlayerMP var1, Entity var2, DamageSource var3) {
      KilledTrigger.Listeners var4 = (KilledTrigger.Listeners)this.field_192213_a.get(var1.func_192039_O());
      if (var4 != null) {
         var4.func_192503_a(var1, var2, var3);
      }

   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<KilledTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      KilledTrigger.Listeners var3 = (KilledTrigger.Listeners)this.field_192213_a.get(var1);
      if (var3 == null) {
         I[151 ^ 147].length();
         I[24 ^ 29].length();
         I[3 ^ 5].length();
         var3 = new KilledTrigger.Listeners(var1);
         this.field_192213_a.put(var1, var3);
         I[9 ^ 14].length();
         I[153 ^ 145].length();
      }

      var3.func_192504_a(var2);
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<KilledTrigger.Instance> var2) {
      KilledTrigger.Listeners var3 = (KilledTrigger.Listeners)this.field_192213_a.get(var1);
      if (var3 != null) {
         var3.func_192501_b(var2);
         if (var3.func_192502_a()) {
            this.field_192213_a.remove(var1);
            I[36 ^ 45].length();
            I[99 ^ 105].length();
            I[6 ^ 13].length();
         }
      }

   }

   private static void I() {
      I = new String[22 ^ 0];
      I["".length()] = I("二撖", "ZUYkM");
      I[" ".length()] = I("丰憉", "ntZrn");
      I["  ".length()] = I("孇枼", "yJjDy");
      I["   ".length()] = I("垃仐", "BXujU");
      I[20 ^ 16] = I("娳槷悼瀔", "YKwfJ");
      I[96 ^ 101] = I("煔嶺歝愫児", "lINcs");
      I[195 ^ 197] = I("沐搹剋偧", "ffcNZ");
      I[145 ^ 150] = I("吥橦垱沁斄", "gkMXt");
      I[188 ^ 180] = I("兓", "rejkD");
      I[49 ^ 56] = I("瀾", "PwyDu");
      I[171 ^ 161] = I("宽", "OfLrw");
      I[152 ^ 147] = I("涎堪", "qHCDm");
      I[136 ^ 132] = I("櫃仵楲儕", "sSEiU");
      I[75 ^ 70] = I("儙仔嘤", "KzIFT");
      I[28 ^ 18] = I("可冖", "nckqx");
      I[110 ^ 97] = I("尻傈", "csaMP");
      I[160 ^ 176] = I("淫烆", "qVABe");
      I[7 ^ 22] = I("敱煚", "mQeTW");
      I[125 ^ 111] = I("増噞槦伏惮", "enTHp");
      I[27 ^ 8] = I("卓", "WzqSc");
      I[141 ^ 153] = I("6\n-\u0000\u0011*", "SdYie");
      I[144 ^ 133] = I("\u001d:;<\r\u00184\b2\b\u0019$", "vSWPd");
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final EntityPredicate field_192271_a;
      // $FF: synthetic field
      private final DamageSourcePredicate field_192272_b;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 < 3);

         throw null;
      }

      public Instance(ResourceLocation var1, EntityPredicate var2, DamageSourcePredicate var3) {
         super(var1);
         this.field_192271_a = var2;
         this.field_192272_b = var3;
      }

      public boolean func_192270_a(EntityPlayerMP var1, Entity var2, DamageSource var3) {
         int var10000;
         if (!this.field_192272_b.func_193418_a(var1, var3)) {
            var10000 = "".length();
            "".length();
            if (4 < 1) {
               throw null;
            }
         } else {
            var10000 = this.field_192271_a.func_192482_a(var1, var2);
         }

         return (boolean)var10000;
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_192505_a;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<KilledTrigger.Instance>> field_192506_b = Sets.newHashSet();

      public void func_192501_b(ICriterionTrigger.Listener<KilledTrigger.Instance> var1) {
         this.field_192506_b.remove(var1);
         I["   ".length()].length();
         I[145 ^ 149].length();
      }

      static {
         I();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192505_a = var1;
      }

      private static void I() {
         I = new String[37 ^ 44];
         I["".length()] = I("水", "XPqXE");
         I[" ".length()] = I("洽", "jHNDv");
         I["  ".length()] = I("惖圻満", "nLYAA");
         I["   ".length()] = I("灂欦", "cESPv");
         I[117 ^ 113] = I("悻栖俓崎攊", "aBeKj");
         I[32 ^ 37] = I("怇澕卟催梣", "lnwYC");
         I[160 ^ 166] = I("氺払擀", "FANGg");
         I[158 ^ 153] = I("剿俩倢嘧", "HHlJy");
         I[99 ^ 107] = I("娩唨始", "iLkIm");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 < 1);

         throw null;
      }

      public void func_192503_a(EntityPlayerMP var1, Entity var2, DamageSource var3) {
         ArrayList var4 = null;
         Iterator var5 = this.field_192506_b.iterator();

         ICriterionTrigger.Listener var6;
         while(var5.hasNext()) {
            var6 = (ICriterionTrigger.Listener)var5.next();
            if (((KilledTrigger.Instance)var6.func_192158_a()).func_192270_a(var1, var2, var3)) {
               if (var4 == null) {
                  var4 = Lists.newArrayList();
               }

               var4.add(var6);
               I[98 ^ 103].length();
               I[51 ^ 53].length();
               I[84 ^ 83].length();
               I[176 ^ 184].length();
            }

            "".length();
            if (-1 != -1) {
               throw null;
            }
         }

         if (var4 != null) {
            var5 = var4.iterator();

            while(var5.hasNext()) {
               var6 = (ICriterionTrigger.Listener)var5.next();
               var6.func_192159_a(this.field_192505_a);
               "".length();
               if (4 != 4) {
                  throw null;
               }
            }
         }

      }

      public void func_192504_a(ICriterionTrigger.Listener<KilledTrigger.Instance> var1) {
         this.field_192506_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }

      public boolean func_192502_a() {
         return this.field_192506_b.isEmpty();
      }
   }
}

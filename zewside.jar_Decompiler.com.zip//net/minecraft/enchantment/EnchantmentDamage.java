package net.minecraft.enchantment;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;

public class EnchantmentDamage extends Enchantment {
   // $FF: synthetic field
   private static final int[] BASE_ENCHANTABILITY;
   // $FF: synthetic field
   public final int damageType;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final int[] THRESHOLD_ENCHANTABILITY;
   // $FF: synthetic field
   private static final int[] LEVEL_ENCHANTABILITY;
   // $FF: synthetic field
   private static final String[] PROTECTION_NAME;

   public int getMinEnchantability(int var1) {
      int var10000 = BASE_ENCHANTABILITY[this.damageType];
      int var10002 = " ".length();
      I["".length()].length();
      return var10000 + (var1 - var10002) * LEVEL_ENCHANTABILITY[this.damageType];
   }

   public boolean canApplyTogether(Enchantment var1) {
      int var10000;
      if (!(var1 instanceof EnchantmentDamage)) {
         var10000 = " ".length();
         "".length();
         if (0 == 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public float calcDamageByCreature(int var1, EnumCreatureAttribute var2) {
      if (this.damageType == 0) {
         int var10001 = "".length();
         int var10003 = " ".length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
         return 1.0F + (float)Math.max(var10001, var1 - var10003) * 0.5F;
      } else if (this.damageType == " ".length() && var2 == EnumCreatureAttribute.UNDEAD) {
         return (float)var1 * 2.5F;
      } else {
         float var10000;
         if (this.damageType == "  ".length() && var2 == EnumCreatureAttribute.ARTHROPOD) {
            var10000 = (float)var1 * 2.5F;
            "".length();
            if (2 <= 0) {
               throw null;
            }
         } else {
            var10000 = 0.0F;
         }

         return var10000;
      }
   }

   public int getMaxLevel() {
      return 167 ^ 162;
   }

   static {
      I();
      String[] var10000 = new String["   ".length()];
      var10000["".length()] = I[154 ^ 136];
      var10000[" ".length()] = I[27 ^ 8];
      var10000["  ".length()] = I[20 ^ 0];
      PROTECTION_NAME = var10000;
      int[] var0 = new int["   ".length()];
      var0["".length()] = " ".length();
      var0[" ".length()] = 65 ^ 68;
      var0["  ".length()] = 48 ^ 53;
      BASE_ENCHANTABILITY = var0;
      var0 = new int["   ".length()];
      var0["".length()] = 40 ^ 35;
      var0[" ".length()] = 36 ^ 44;
      var0["  ".length()] = 114 ^ 122;
      LEVEL_ENCHANTABILITY = var0;
      var0 = new int["   ".length()];
      var0["".length()] = 37 ^ 49;
      var0[" ".length()] = 19 ^ 7;
      var0["  ".length()] = 1 ^ 21;
      THRESHOLD_ENCHANTABILITY = var0;
   }

   private static void I() {
      I = new String[48 ^ 37];
      I["".length()] = I("孰椻欺栨", "VYRES");
      I[" ".length()] = I("喺昿", "uXpcH");
      I["  ".length()] = I("亳", "NOPnY");
      I["   ".length()] = I("归欮", "uFrVE");
      I[125 ^ 121] = I("嶮捯", "InbSX");
      I[89 ^ 92] = I("汾扗", "gKlhI");
      I[26 ^ 28] = I("壥刾", "rKHex");
      I[135 ^ 128] = I("溫昶", "HxKHI");
      I[106 ^ 98] = I("丵", "NfOWz");
      I[60 ^ 53] = I("滵梍", "zyCZI");
      I[200 ^ 194] = I("\b\u00003!0\u0003\u001a=,?\u0019@4(<\f\t5g", "mnPIQ");
      I[148 ^ 159] = I("惔崳", "ponKp");
      I[50 ^ 62] = I("嘞倢", "ktEyN");
      I[80 ^ 93] = I("斚侊", "HQeys");
      I[86 ^ 88] = I("丽岸", "ArGlu");
      I[1 ^ 14] = I("步坊氦瀷丶", "eDWpS");
      I[44 ^ 60] = I("桭庨渚", "fBAbT");
      I[126 ^ 111] = I("檒溦橡", "kthvy");
      I[64 ^ 82] = I("\u0006\u001a\u0005", "gvisW");
      I[115 ^ 96] = I("$+*+\u00125", "QENNs");
      I[103 ^ 115] = I("/\u0019\"\u0004\u0011!\u001b9\b\u0010", "NkVlc");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   public void onEntityDamaged(EntityLivingBase var1, Entity var2, int var3) {
      String var10000 = I[30 ^ 21];
      String var10001 = I[92 ^ 80];
      String var10002 = I[62 ^ 51];
      var10001 = I[106 ^ 100];
      if (var2 instanceof EntityLivingBase) {
         EntityLivingBase var4 = (EntityLivingBase)var2;
         if (this.damageType == "  ".length() && var4.getCreatureAttribute() == EnumCreatureAttribute.ARTHROPOD) {
            int var5 = (83 ^ 71) + var1.getRNG().nextInt((60 ^ 54) * var3);
            I[43 ^ 36].length();
            I[83 ^ 67].length();
            I[54 ^ 39].length();
            var4.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, var5, "   ".length()));
         }
      }

   }

   public int getMaxEnchantability(int var1) {
      return this.getMinEnchantability(var1) + THRESHOLD_ENCHANTABILITY[this.damageType];
   }

   public boolean canApply(ItemStack var1) {
      int var10000;
      if (var1.getItem() instanceof ItemAxe) {
         var10000 = " ".length();
         "".length();
         if (4 <= -1) {
            throw null;
         }
      } else {
         var10000 = super.canApply(var1);
      }

      return (boolean)var10000;
   }

   public EnchantmentDamage(Enchantment.Rarity var1, int var2, EntityEquipmentSlot... var3) {
      super(var1, EnumEnchantmentType.WEAPON, var3);
      this.damageType = var2;
   }

   public String getName() {
      String var10000 = I[55 ^ 51];
      String var10001 = I[182 ^ 179];
      String var10002 = I[125 ^ 123];
      var10001 = I[88 ^ 95];
      I[178 ^ 186].length();
      I[155 ^ 146].length();
      return I[109 ^ 103] + PROTECTION_NAME[this.damageType];
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketPlayerAbilities implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private float flySpeed;
   // $FF: synthetic field
   private float walkSpeed;
   // $FF: synthetic field
   private boolean allowFlying;
   // $FF: synthetic field
   private boolean invulnerable;
   // $FF: synthetic field
   private boolean creativeMode;
   // $FF: synthetic field
   private boolean flying;
   // $FF: synthetic field
   private static final String[] I;

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handlePlayerAbilities(this);
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 1);

      throw null;
   }

   public void setFlySpeed(float var1) {
      this.flySpeed = var1;
   }

   public void setInvulnerable(boolean var1) {
      this.invulnerable = var1;
   }

   public float getFlySpeed() {
      return this.flySpeed;
   }

   public void setAllowFlying(boolean var1) {
      this.allowFlying = var1;
   }

   public void setFlying(boolean var1) {
      this.flying = var1;
   }

   public void setCreativeMode(boolean var1) {
      this.creativeMode = var1;
   }

   public SPacketPlayerAbilities() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      int var2 = "".length();
      if (this.isInvulnerable()) {
         var2 = (byte)(var2 | " ".length());
      }

      if (this.isFlying()) {
         var2 = (byte)(var2 | "  ".length());
      }

      if (this.isAllowFlying()) {
         var2 = (byte)(var2 | 15 ^ 11);
      }

      if (this.isCreativeMode()) {
         var2 = (byte)(var2 | 20 ^ 28);
      }

      var1.writeByte(var2);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeFloat(this.flySpeed);
      I["  ".length()].length();
      I["   ".length()].length();
      I[58 ^ 62].length();
      I[191 ^ 186].length();
      I[91 ^ 93].length();
      var1.writeFloat(this.walkSpeed);
      I[77 ^ 74].length();
      I[29 ^ 21].length();
   }

   public void setWalkSpeed(float var1) {
      this.walkSpeed = var1;
   }

   private static void I() {
      I = new String[184 ^ 177];
      I["".length()] = I("恙廹垐徃忉", "aceKU");
      I[" ".length()] = I("墤嗑恗", "gtDXh");
      I["  ".length()] = I("搋炾", "AXeoJ");
      I["   ".length()] = I("屵淁", "LQnmM");
      I[143 ^ 139] = I("卌嵷尲伖摦", "ksqBR");
      I[47 ^ 42] = I("嗼噷侁妑庨", "daxML");
      I[131 ^ 133] = I("忋", "fFvmk");
      I[109 ^ 106] = I("庹檙傑毳", "wxDPm");
      I[160 ^ 168] = I("泉店槻傄溈", "vdliw");
   }

   public float getWalkSpeed() {
      return this.walkSpeed;
   }

   public boolean isAllowFlying() {
      return this.allowFlying;
   }

   public SPacketPlayerAbilities(PlayerCapabilities var1) {
      this.setInvulnerable(var1.disableDamage);
      this.setFlying(var1.isFlying);
      this.setAllowFlying(var1.allowFlying);
      this.setCreativeMode(var1.isCreativeMode);
      this.setFlySpeed(var1.getFlySpeed());
      this.setWalkSpeed(var1.getWalkSpeed());
   }

   public boolean isInvulnerable() {
      return this.invulnerable;
   }

   public boolean isCreativeMode() {
      return this.creativeMode;
   }

   public boolean isFlying() {
      return this.flying;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      byte var2 = var1.readByte();
      int var10001;
      if ((var2 & " ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setInvulnerable((boolean)var10001);
      if ((var2 & "  ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (1 <= -1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setFlying((boolean)var10001);
      if ((var2 & (15 ^ 11)) > 0) {
         var10001 = " ".length();
         "".length();
         if (2 <= -1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setAllowFlying((boolean)var10001);
      if ((var2 & (134 ^ 142)) > 0) {
         var10001 = " ".length();
         "".length();
         if (-1 >= 2) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setCreativeMode((boolean)var10001);
      this.setFlySpeed(var1.readFloat());
      this.setWalkSpeed(var1.readFloat());
   }
}

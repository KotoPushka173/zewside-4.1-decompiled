package net.minecraft.dispenser;

public class PositionImpl implements IPosition {
   // $FF: synthetic field
   protected final double x;
   // $FF: synthetic field
   protected final double z;
   // $FF: synthetic field
   protected final double y;

   public double getZ() {
      return this.z;
   }

   public double getX() {
      return this.x;
   }

   public PositionImpl(double var1, double var3, double var5) {
      this.x = var1;
      this.y = var3;
      this.z = var5;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 1);

      throw null;
   }

   public double getY() {
      return this.y;
   }
}

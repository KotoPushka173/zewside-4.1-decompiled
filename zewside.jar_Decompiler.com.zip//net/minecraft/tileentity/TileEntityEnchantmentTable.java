package net.minecraft.tileentity;

import java.util.Random;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerEnchantment;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IInteractionObject;

public class TileEntityEnchantmentTable extends TileEntity implements ITickable, IInteractionObject {
   // $FF: synthetic field
   private static final Random rand;
   // $FF: synthetic field
   public float bookSpread;
   // $FF: synthetic field
   public float pageFlip;
   // $FF: synthetic field
   public float pageFlipPrev;
   // $FF: synthetic field
   public float bookRotation;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public float flipA;
   // $FF: synthetic field
   public float tRot;
   // $FF: synthetic field
   public float bookSpreadPrev;
   // $FF: synthetic field
   public float flipT;
   // $FF: synthetic field
   private String customName;
   // $FF: synthetic field
   public int tickCount;
   // $FF: synthetic field
   public float bookRotationPrev;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 0);

      throw null;
   }

   public void update() {
      String var10000 = I[22 ^ 16];
      String var10001 = I[106 ^ 109];
      String var10002 = I[145 ^ 153];
      var10001 = I[176 ^ 185];
      var10000 = I[203 ^ 193];
      var10001 = I[160 ^ 171];
      var10002 = I[37 ^ 41];
      var10001 = I[74 ^ 71];
      var10000 = I[65 ^ 79];
      var10001 = I[153 ^ 150];
      var10002 = I[129 ^ 145];
      var10001 = I[23 ^ 6];
      var10000 = I[28 ^ 14];
      var10001 = I[186 ^ 169];
      var10002 = I[148 ^ 128];
      var10001 = I[123 ^ 110];
      var10000 = I[106 ^ 124];
      var10001 = I[42 ^ 61];
      var10002 = I[154 ^ 130];
      var10001 = I[167 ^ 190];
      var10000 = I[218 ^ 192];
      var10001 = I[23 ^ 12];
      var10002 = I[6 ^ 26];
      var10001 = I[93 ^ 64];
      var10000 = I[104 ^ 118];
      var10001 = I[137 ^ 150];
      var10002 = I[180 ^ 148];
      var10001 = I[156 ^ 189];
      var10000 = I[229 ^ 199];
      var10001 = I[145 ^ 178];
      var10002 = I[92 ^ 120];
      var10001 = I[99 ^ 70];
      var10000 = I[42 ^ 12];
      var10001 = I[114 ^ 85];
      var10002 = I[154 ^ 178];
      var10001 = I[1 ^ 40];
      var10000 = I[129 ^ 171];
      var10001 = I[115 ^ 88];
      var10002 = I[66 ^ 110];
      var10001 = I[238 ^ 195];
      var10000 = I[69 ^ 107];
      var10001 = I[6 ^ 41];
      var10002 = I[160 ^ 144];
      var10001 = I[62 ^ 15];
      var10000 = I[160 ^ 146];
      var10001 = I[242 ^ 193];
      var10002 = I[134 ^ 178];
      var10001 = I[81 ^ 100];
      this.bookSpreadPrev = this.bookSpread;
      this.bookRotationPrev = this.bookRotation;
      EntityPlayer var1 = this.world.getClosestPlayer((double)((float)this.pos.getX() + 0.5F), (double)((float)this.pos.getY() + 0.5F), (double)((float)this.pos.getZ() + 0.5F), 3.0D, (boolean)"".length());
      float var14;
      if (var1 != null) {
         double var10 = var1.posX;
         double var13 = (double)((float)this.pos.getX() + 0.5F);
         I[40 ^ 30].length();
         double var2 = var10 - var13;
         var10 = var1.posZ;
         var13 = (double)((float)this.pos.getZ() + 0.5F);
         I[146 ^ 165].length();
         double var4 = var10 - var13;
         this.tRot = (float)MathHelper.atan2(var4, var2);
         I[152 ^ 160].length();
         I[116 ^ 77].length();
         this.bookSpread += 0.1F;
         if (this.bookSpread < 0.5F || rand.nextInt(167 ^ 143) == 0) {
            float var6 = this.flipT;

            do {
               I[121 ^ 67].length();
               var14 = this.flipT;
               int var12 = rand.nextInt(129 ^ 133);
               int var10003 = rand.nextInt(19 ^ 23);
               I[104 ^ 83].length();
               I[39 ^ 27].length();
               I[93 ^ 96].length();
               I[90 ^ 100].length();
               this.flipT = var14 + (float)(var12 - var10003);
            } while(var6 == this.flipT);

            "".length();
            if (3 <= -1) {
               throw null;
            }
         }

         "".length();
         if (false) {
            throw null;
         }
      } else {
         I[3 ^ 60].length();
         I[79 ^ 15].length();
         this.tRot += 0.02F;
         I[97 ^ 32].length();
         I[28 ^ 94].length();
         var14 = this.bookSpread;
         I[103 ^ 36].length();
         I[21 ^ 81].length();
         I[49 ^ 116].length();
         this.bookSpread = var14 - 0.1F;
      }

      do {
         if (!(this.bookRotation >= 3.1415927F)) {
            do {
               if (!(this.bookRotation < -3.1415927F)) {
                  do {
                     if (!(this.tRot >= 3.1415927F)) {
                        do {
                           if (!(this.tRot < -3.1415927F)) {
                              float var11 = this.tRot;
                              var14 = this.bookRotation;
                              I[84 ^ 1].length();
                              float var7 = var11 - var14;

                              do {
                                 if (!(var7 >= 3.1415927F)) {
                                    do {
                                       if (!(var7 < -3.1415927F)) {
                                          I[241 ^ 168].length();
                                          I[79 ^ 21].length();
                                          I[5 ^ 94].length();
                                          this.bookRotation += var7 * 0.4F;
                                          this.bookSpread = MathHelper.clamp(this.bookSpread, 0.0F, 1.0F);
                                          I[199 ^ 155].length();
                                          I[221 ^ 128].length();
                                          this.tickCount += " ".length();
                                          this.pageFlipPrev = this.pageFlip;
                                          var11 = this.flipT;
                                          var14 = this.pageFlip;
                                          I[197 ^ 155].length();
                                          I[232 ^ 183].length();
                                          I[238 ^ 142].length();
                                          I[59 ^ 90].length();
                                          float var3 = (var11 - var14) * 0.4F;
                                          float var8 = 0.2F;
                                          var3 = MathHelper.clamp(var3, -0.2F, 0.2F);
                                          I[216 ^ 186].length();
                                          I[161 ^ 194].length();
                                          I[225 ^ 133].length();
                                          I[120 ^ 29].length();
                                          var14 = this.flipA;
                                          float var9 = this.flipA;
                                          I[244 ^ 146].length();
                                          I[234 ^ 141].length();
                                          I[205 ^ 165].length();
                                          this.flipA = var14 + (var3 - var9) * 0.9F;
                                          I[212 ^ 189].length();
                                          I[230 ^ 140].length();
                                          I[233 ^ 130].length();
                                          I[91 ^ 55].length();
                                          this.pageFlip += this.flipA;
                                          return;
                                       }

                                       var7 += 6.2831855F;
                                       "".length();
                                    } while(-1 != 1);

                                    throw null;
                                 }

                                 I[49 ^ 103].length();
                                 I[196 ^ 147].length();
                                 I[39 ^ 127].length();
                                 var7 -= 6.2831855F;
                                 "".length();
                              } while(0 < 2);

                              throw null;
                           }

                           I[199 ^ 148].length();
                           I[87 ^ 3].length();
                           this.tRot += 6.2831855F;
                           "".length();
                        } while(2 >= 1);

                        throw null;
                     }

                     I[22 ^ 89].length();
                     I[208 ^ 128].length();
                     I[194 ^ 147].length();
                     var14 = this.tRot;
                     I[113 ^ 35].length();
                     this.tRot = var14 - 6.2831855F;
                     "".length();
                  } while(3 == 3);

                  throw null;
               }

               I[225 ^ 173].length();
               I[231 ^ 170].length();
               I[94 ^ 16].length();
               this.bookRotation += 6.2831855F;
               "".length();
            } while(1 > -1);

            throw null;
         }

         I[4 ^ 66].length();
         I[247 ^ 176].length();
         var14 = this.bookRotation;
         I[200 ^ 128].length();
         I[57 ^ 112].length();
         I[97 ^ 43].length();
         I[232 ^ 163].length();
         this.bookRotation = var14 - 6.2831855F;
         "".length();
      } while(1 != 3);

      throw null;
   }

   public void setCustomName(String var1) {
      this.customName = var1;
   }

   private static void I() {
      I = new String[0 + 35 - -81 + 11];
      I["".length()] = I("濵煢", "RLFOo");
      I[" ".length()] = I("灰漥厁擜", "vvhAs");
      I["  ".length()] = I("枾呌榹娬", "ZCmrY");
      I["   ".length()] = I("\u001b\u001f\u001e-<5$\f46", "XjmYS");
      I[1 ^ 5] = I("\u0016\u001d\u0014'.8&\u0006>$", "UhgSA");
      I[127 ^ 122] = I("(\u001a\t#%\u0006!\u001b:/", "kozWJ");
      I[43 ^ 45] = I("喩施", "GrSKY");
      I[0 ^ 7] = I("楋棽", "RGMjC");
      I[100 ^ 108] = I("榜卛", "GTKfg");
      I[173 ^ 164] = I("宁捩", "iFSmP");
      I[12 ^ 6] = I("坋唉", "ziVUX");
      I[202 ^ 193] = I("宏枬", "GsRIz");
      I[21 ^ 25] = I("志搹", "COlll");
      I[177 ^ 188] = I("洶搏", "WVXgC");
      I[135 ^ 137] = I("嗺坑", "SHUzW");
      I[73 ^ 70] = I("栠殆", "tvKjh");
      I[38 ^ 54] = I("侜媐", "hKDwQ");
      I[188 ^ 173] = I("徠办", "mMIYO");
      I[191 ^ 173] = I("儛敜", "VBNvf");
      I[48 ^ 35] = I("广仜", "zuSQC");
      I[59 ^ 47] = I("嵐歶", "SgCIU");
      I[179 ^ 166] = I("噲楄", "FwsnB");
      I[65 ^ 87] = I("漴攺", "OKkUS");
      I[185 ^ 174] = I("壩渍", "wmuQx");
      I[128 ^ 152] = I("捔播", "pyydD");
      I[42 ^ 51] = I("噳椲", "whwgr");
      I[175 ^ 181] = I("寅晼", "BsgYj");
      I[75 ^ 80] = I("冹檤", "VLVFQ");
      I[65 ^ 93] = I("柲毽", "cCOMv");
      I[217 ^ 196] = I("喦淙", "NiBmm");
      I[170 ^ 180] = I("旑嵔", "aobGo");
      I[111 ^ 112] = I("混偧", "hlKiQ");
      I[30 ^ 62] = I("摍彲", "UoTWq");
      I[22 ^ 55] = I("兲櫨", "dcfYe");
      I[125 ^ 95] = I("徙拿", "CxDER");
      I[177 ^ 146] = I("增伤", "zRAFd");
      I[40 ^ 12] = I("塃汹", "gVTiF");
      I[156 ^ 185] = I("乂樤", "xwThX");
      I[122 ^ 92] = I("徕嶟", "eXWGw");
      I[32 ^ 7] = I("堙伆", "vZLhN");
      I[236 ^ 196] = I("掤定", "RUNOG");
      I[99 ^ 74] = I("呢彽", "dUgLa");
      I[38 ^ 12] = I("滢凯", "MGsfl");
      I[37 ^ 14] = I("榫争", "BwsgV");
      I[236 ^ 192] = I("侉搮", "FYuGF");
      I[82 ^ 127] = I("匞嵖", "oTJDS");
      I[145 ^ 191] = I("摁浃", "DbTwv");
      I[111 ^ 64] = I("榼啠", "MnQVi");
      I[60 ^ 12] = I("兡怇", "dqHVO");
      I[153 ^ 168] = I("戼俬", "cfrYC");
      I[64 ^ 114] = I("圛剂", "VNUxh");
      I[66 ^ 113] = I("寸柞", "karni");
      I[56 ^ 12] = I("帍溚", "SCJad");
      I[164 ^ 145] = I("烆峄", "ucnxx");
      I[128 ^ 182] = I("瀫峬", "Pduoi");
      I[44 ^ 27] = I("廄桵", "VGUHH");
      I[143 ^ 183] = I("廭捱嵥濐権", "YojzS");
      I[63 ^ 6] = I("叻", "XTmgW");
      I[156 ^ 166] = I("俹暔愕榥歃", "xPhXz");
      I[151 ^ 172] = I("丘仵淝噯", "ENRUS");
      I[107 ^ 87] = I("帻样喊憛", "Ewjyj");
      I[69 ^ 120] = I("樻彤晴", "REoZn");
      I[99 ^ 93] = I("漑庖宽凹", "ZSdCu");
      I[128 ^ 191] = I("擪櫦", "NzkJq");
      I[208 ^ 144] = I("点唧塔勂", "piysw");
      I[213 ^ 148] = I("灘擶偡奐", "lmPYa");
      I[83 ^ 17] = I("恷烫慊僦旿", "nXQZQ");
      I[243 ^ 176] = I("叡僞怛壀", "fAlHo");
      I[71 ^ 3] = I("樹", "dBZOb");
      I[46 ^ 107] = I("壏勪", "GyxPS");
      I[134 ^ 192] = I("澥", "meWDE");
      I[246 ^ 177] = I("歧愨澢", "FjEVX");
      I[39 ^ 111] = I("唺洈", "pINYq");
      I[77 ^ 4] = I("巰媱", "Qjjsr");
      I[127 ^ 53] = I("煵挺嵝", "uecWw");
      I[209 ^ 154] = I("沸庄涤涊", "FBTmI");
      I[230 ^ 170] = I("仌", "bDftK");
      I[232 ^ 165] = I("棜怜媍", "Iotvk");
      I[9 ^ 71] = I("嗚坠寣", "VuNgh");
      I[106 ^ 37] = I("杻", "qoVPv");
      I[145 ^ 193] = I("擙偠橩澣", "MYseJ");
      I[33 ^ 112] = I("嬲", "quroT");
      I[109 ^ 63] = I("凭", "ceRAb");
      I[236 ^ 191] = I("昆毰惤", "ATdKt");
      I[70 ^ 18] = I("橨枤僣焆", "yZVCI");
      I[119 ^ 34] = I("孃", "FFRkT");
      I[218 ^ 140] = I("汛擪愚", "AFrPP");
      I[220 ^ 139] = I("奣備殌", "LkduS");
      I[26 ^ 66] = I("伙", "seHXr");
      I[126 ^ 39] = I("烵", "aDmKj");
      I[118 ^ 44] = I("徘忞妃嬑姊", "WJaDS");
      I[219 ^ 128] = I("欑娭岳橵", "nNMLU");
      I[252 ^ 160] = I("槩澏勋剆", "JBPze");
      I[100 ^ 57] = I("烝椰殣", "BFryX");
      I[231 ^ 185] = I("柆丒", "EwwyG");
      I[92 ^ 3] = I("侮叺冔", "KAYGH");
      I[45 ^ 77] = I("卛句", "vaTty");
      I[193 ^ 160] = I("堯悲", "erjhE");
      I[111 ^ 13] = I("樳旍椰", "ZNzMP");
      I[4 ^ 103] = I("灜侬坡", "QtxLs");
      I[26 ^ 126] = I("槶伧啍", "pNYQh");
      I[198 ^ 163] = I("溭圍抂", "MiMsd");
      I[202 ^ 172] = I("曺", "gnhdj");
      I[31 ^ 120] = I("孀斎周偳", "UiLME");
      I[79 ^ 39] = I("堣濷", "cmJuS");
      I[125 ^ 20] = I("呀噠", "JUZkI");
      I[7 ^ 109] = I("康坟妮棩", "hDflk");
      I[227 ^ 136] = I("濷奼氒偙摷", "TmCcJ");
      I[106 ^ 6] = I("崬嘆弳沼崮", "XfijV");
      I[199 ^ 170] = I("\f5\u001d\u0011\u0016\u00064\u0016\u0017Y\n4\u0010\r\u0016\u0001.", "oZsew");
      I[82 ^ 60] = I("仒坨", "KROBc");
      I[198 ^ 169] = I("暢撎", "nPcrk");
      I[105 ^ 25] = I("伛坶", "yOPkz");
      I[89 ^ 40] = I("煕慊", "gtDEc");
      I[101 ^ 23] = I("巭奥", "StyMj");
      I[250 ^ 137] = I("堈圫", "liBQX");
      I[209 ^ 165] = I("剸滫", "GKYiq");
      I[206 ^ 187] = I("煲乫", "aCmIB");
      I[37 ^ 83] = I("橸", "wUIyN");
      I[212 ^ 163] = I("彙亚敺潴", "GkOFO");
      I[213 ^ 173] = I("婰暠", "XdZog");
      I[233 ^ 144] = I("嵧泻", "SwsZJ");
      I[88 ^ 34] = I("湾仟", "OurxW");
      I[202 ^ 177] = I("格沯", "QIlHi");
      I[31 ^ 99] = I("灜旾", "DkRtt");
      I[97 ^ 28] = I("制梎", "oDudY");
      I[61 ^ 67] = I("\u001f<\"&%\u00004*7|\u0017;/+'\u001c!%-!-!-!*\u0017", "rULCF");
   }

   public ITextComponent getDisplayName() {
      String var10000 = I[197 ^ 171];
      String var10001 = I[254 ^ 145];
      String var10002 = I[115 ^ 3];
      var10001 = I[222 ^ 175];
      var10000 = I[202 ^ 184];
      var10001 = I[81 ^ 34];
      var10002 = I[126 ^ 10];
      var10001 = I[20 ^ 97];
      Object var1;
      if (this.hasCustomName()) {
         I[215 ^ 161].length();
         I[206 ^ 185].length();
         var1 = new TextComponentString(this.getName());
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         I[84 ^ 44].length();
         var1 = new TextComponentTranslation(this.getName(), new Object["".length()]);
      }

      return (ITextComponent)var1;
   }

   public Container createContainer(InventoryPlayer var1, EntityPlayer var2) {
      String var10000 = I[233 ^ 144];
      String var10001 = I[76 ^ 54];
      String var10002 = I[81 ^ 42];
      var10001 = I[6 ^ 122];
      I[79 ^ 50].length();
      return new ContainerEnchantment(var1, this.world, this.pos);
   }

   public String getName() {
      String var10000;
      if (this.hasCustomName()) {
         var10000 = this.customName;
         "".length();
         if (2 >= 3) {
            throw null;
         }
      } else {
         var10000 = I[230 ^ 139];
      }

      return var10000;
   }

   public boolean hasCustomName() {
      int var10000;
      if (this.customName != null && !this.customName.isEmpty()) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public NBTTagCompound writeToNBT(NBTTagCompound var1) {
      super.writeToNBT(var1);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      if (this.hasCustomName()) {
         var1.setString(I["   ".length()], this.customName);
      }

      return var1;
   }

   public String getGuiID() {
      return I[30 ^ 96];
   }

   static {
      I();
      rand = new Random();
   }

   public void readFromNBT(NBTTagCompound var1) {
      super.readFromNBT(var1);
      if (var1.hasKey(I[111 ^ 107], 68 ^ 76)) {
         this.customName = var1.getString(I[24 ^ 29]);
      }

   }
}

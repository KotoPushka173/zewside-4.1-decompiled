package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketSetExperience implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int level;
   // $FF: synthetic field
   private float experienceBar;
   // $FF: synthetic field
   private int totalExperience;
   // $FF: synthetic field
   private static final String[] I;

   private static void I() {
      I = new String[132 ^ 141];
      I["".length()] = I("梘", "cvJnZ");
      I[" ".length()] = I("佢尗啭塏喂", "VBaHv");
      I["  ".length()] = I("攇伔帻婏昕", "aXgKS");
      I["   ".length()] = I("烡焺厯毑", "XyfTH");
      I[100 ^ 96] = I("壜挦涆怨", "gFsjy");
      I[117 ^ 112] = I("丩潲梣汎", "CoGgL");
      I[176 ^ 182] = I("弞湆櫇憈", "gsfLl");
      I[100 ^ 99] = I("孝濲仨坺攽", "jaLEF");
      I[89 ^ 81] = I("亽椴揔嵣", "AXYTq");
   }

   public int getLevel() {
      return this.level;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeFloat(this.experienceBar);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeVarIntToBuffer(this.level);
      I["   ".length()].length();
      I[115 ^ 119].length();
      I[78 ^ 75].length();
      var1.writeVarIntToBuffer(this.totalExperience);
      I[14 ^ 8].length();
      I[134 ^ 129].length();
      I[42 ^ 34].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 2);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.experienceBar = var1.readFloat();
      this.level = var1.readVarIntFromBuffer();
      this.totalExperience = var1.readVarIntFromBuffer();
   }

   public SPacketSetExperience() {
   }

   public float getExperienceBar() {
      return this.experienceBar;
   }

   static {
      I();
   }

   public int getTotalExperience() {
      return this.totalExperience;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSetExperience(this);
   }

   public SPacketSetExperience(float var1, int var2, int var3) {
      this.experienceBar = var1;
      this.totalExperience = var2;
      this.level = var3;
   }
}

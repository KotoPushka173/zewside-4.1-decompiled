package net.minecraft.block;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRailPowered extends BlockRailBase {
   // $FF: synthetic field
   public static final PropertyBool POWERED;
   // $FF: synthetic field
   public static final PropertyEnum<BlockRailBase.EnumRailDirection> SHAPE;
   // $FF: synthetic field
   private static final String[] I;

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).ordinal()]) {
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 9:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 10:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         }
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH);
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 9:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 10:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         }
      case 3:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH);
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 9:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 10:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         }
      default:
         return var1;
      }
   }

   private static void I() {
      I = new String[39 ^ 13];
      I["".length()] = I("測姃", "XsXFy");
      I[" ".length()] = I("揤懌", "mznkp");
      I["  ".length()] = I("傝挎", "APdKL");
      I["   ".length()] = I("搣儲", "Hugbl");
      I[181 ^ 177] = I("凳个", "nFlBS");
      I[21 ^ 16] = I("嗐媍", "RZuND");
      I[14 ^ 8] = I("孄悔", "bewQA");
      I[109 ^ 106] = I("弦摞", "huXUI");
      I[107 ^ 99] = I("僙", "qbhmt");
      I[204 ^ 197] = I("嚓梅坾壷怚", "MxYnU");
      I[126 ^ 116] = I("嬽徼歞毢", "MbgjR");
      I[121 ^ 114] = I("坒唓佲峀懣", "SCnQg");
      I[55 ^ 59] = I("伐崃唑亱", "dbbLa");
      I[135 ^ 138] = I("寭佷樏", "OeLpv");
      I[147 ^ 157] = I("椺烁奔墖兿", "Ayebr");
      I[103 ^ 104] = I("崾悷洃", "kmWoU");
      I[169 ^ 185] = I("媒忻劜堗", "UlBlS");
      I[183 ^ 166] = I("僔婈", "CzrqD");
      I[92 ^ 78] = I("欑宜噼惑吭", "oqEkq");
      I[156 ^ 143] = I("焯", "mGOiV");
      I[7 ^ 19] = I("旭埼", "IJNmn");
      I[46 ^ 59] = I("侅侁", "iVnEc");
      I[122 ^ 108] = I("凍孽", "LufOZ");
      I[61 ^ 42] = I("娕唞", "uvdrA");
      I[5 ^ 29] = I("噢湐", "DbgsW");
      I[74 ^ 83] = I("劆湄", "uDJmJ");
      I[83 ^ 73] = I("娷忰", "fhqdx");
      I[125 ^ 102] = I("模撏", "wHlIh");
      I[150 ^ 138] = I("数涵", "nYgbq");
      I[11 ^ 22] = I("儳卫", "DoucI");
      I[52 ^ 42] = I("煍冨", "ZofBY");
      I[190 ^ 161] = I("搶呌", "XGyTR");
      I[19 ^ 51] = I("柂垻", "kBefo");
      I[23 ^ 54] = I("慂勾", "BFQWf");
      I[189 ^ 159] = I("娋栮", "jdKZJ");
      I[8 ^ 43] = I("氞崏晔凊樭", "jgQfx");
      I[119 ^ 83] = I("楗偬", "gMUkY");
      I[182 ^ 147] = I("煑媗佁欃", "XRGVQ");
      I[113 ^ 87] = I("勲", "LdTAK");
      I[13 ^ 42] = I("厘椽媦", "NmCBB");
      I[141 ^ 165] = I(" 81\u0013#", "SPPcF");
      I[114 ^ 91] = I("\u0018\t=\u001d0\r\u0002", "hfJxB");
   }

   protected void updateState(IBlockState var1, World var2, BlockPos var3, Block var4) {
      byte var5 = (Boolean)var1.getValue(POWERED);
      int var10000;
      if (!var2.isBlockPowered(var3) && !this.findPoweredRailSignal(var2, var3, var1, (boolean)" ".length(), "".length()) && !this.findPoweredRailSignal(var2, var3, var1, (boolean)"".length(), "".length())) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (1 == 4) {
            throw null;
         }
      }

      int var6 = var10000;
      if (var6 != var5) {
         var2.setBlockState(var3, var1.withProperty(POWERED, Boolean.valueOf((boolean)var6)), "   ".length());
         I[40 ^ 59].length();
         I[22 ^ 2].length();
         I[18 ^ 7].length();
         I[91 ^ 77].length();
         var2.notifyNeighborsOfStateChange(var3.down(), this, (boolean)"".length());
         if (((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).isAscending()) {
            var2.notifyNeighborsOfStateChange(var3.up(), this, (boolean)"".length());
         }
      }

   }

   protected BlockRailPowered() {
      super((boolean)" ".length());
      this.setDefaultState(this.blockState.getBaseState().withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH).withProperty(POWERED, Boolean.valueOf((boolean)"".length())));
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(SHAPE, BlockRailBase.EnumRailDirection.byMetadata(var1 & (192 ^ 199)));
      PropertyBool var10001 = POWERED;
      int var10002;
      if ((var1 & (148 ^ 156)) > 0) {
         var10002 = " ".length();
         "".length();
         if (2 < 2) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public IProperty<BlockRailBase.EnumRailDirection> getShapeProperty() {
      return SHAPE;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      BlockRailBase.EnumRailDirection var3 = (BlockRailBase.EnumRailDirection)var1.getValue(SHAPE);
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[var3.ordinal()]) {
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 9:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 10:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         default:
            return super.withMirror(var1, var2);
         }
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[var3.ordinal()]) {
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 5:
         case 6:
         default:
            "".length();
            if (1 == 2) {
               throw null;
            }
            break;
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 9:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 10:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         }
      default:
         return super.withMirror(var1, var2);
      }
   }

   protected boolean isSameRailWithPower(World var1, BlockPos var2, boolean var3, int var4, BlockRailBase.EnumRailDirection var5) {
      IBlockState var6 = var1.getBlockState(var2);
      if (var6.getBlock() != this) {
         return (boolean)"".length();
      } else {
         BlockRailBase.EnumRailDirection var7 = (BlockRailBase.EnumRailDirection)var6.getValue(SHAPE);
         if (var5 != BlockRailBase.EnumRailDirection.EAST_WEST || var7 != BlockRailBase.EnumRailDirection.NORTH_SOUTH && var7 != BlockRailBase.EnumRailDirection.ASCENDING_NORTH && var7 != BlockRailBase.EnumRailDirection.ASCENDING_SOUTH) {
            if (var5 != BlockRailBase.EnumRailDirection.NORTH_SOUTH || var7 != BlockRailBase.EnumRailDirection.EAST_WEST && var7 != BlockRailBase.EnumRailDirection.ASCENDING_EAST && var7 != BlockRailBase.EnumRailDirection.ASCENDING_WEST) {
               if ((Boolean)var6.getValue(POWERED)) {
                  int var10000;
                  if (var1.isBlockPowered(var2)) {
                     var10000 = " ".length();
                     "".length();
                     if (4 != 4) {
                        throw null;
                     }
                  } else {
                     var10000 = this.findPoweredRailSignal(var1, var2, var6, var3, var4 + " ".length());
                  }

                  return (boolean)var10000;
               } else {
                  return (boolean)"".length();
               }
            } else {
               return (boolean)"".length();
            }
         } else {
            return (boolean)"".length();
         }
      }
   }

   static {
      I();
      SHAPE = PropertyEnum.create(I[57 ^ 17], BlockRailBase.EnumRailDirection.class, new Predicate<BlockRailBase.EnumRailDirection>() {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 > 2);

            throw null;
         }

         public boolean apply(@Nullable BlockRailBase.EnumRailDirection var1) {
            int var10000;
            if (var1 != BlockRailBase.EnumRailDirection.NORTH_EAST && var1 != BlockRailBase.EnumRailDirection.NORTH_WEST && var1 != BlockRailBase.EnumRailDirection.SOUTH_EAST && var1 != BlockRailBase.EnumRailDirection.SOUTH_WEST) {
               var10000 = " ".length();
               "".length();
               if (3 != 3) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      });
      POWERED = PropertyBool.create(I[146 ^ 187]);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > -1);

      throw null;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[131 ^ 148];
      String var10001 = I[114 ^ 106];
      String var10002 = I[103 ^ 126];
      var10001 = I[134 ^ 156];
      var10000 = I[29 ^ 6];
      var10001 = I[51 ^ 47];
      var10002 = I[106 ^ 119];
      var10001 = I[173 ^ 179];
      var10000 = I[149 ^ 138];
      var10001 = I[68 ^ 100];
      var10002 = I[52 ^ 21];
      var10001 = I[114 ^ 80];
      I[13 ^ 46].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[93 ^ 121].length();
      I[20 ^ 49].length();
      I[115 ^ 85].length();
      var10003["".length()] = SHAPE;
      I[128 ^ 167].length();
      var10003[" ".length()] = POWERED;
      return new BlockStateContainer(this, var10003);
   }

   protected boolean findPoweredRailSignal(World var1, BlockPos var2, IBlockState var3, boolean var4, int var5) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[58 ^ 62];
      var10001 = I[194 ^ 199];
      var10002 = I[41 ^ 47];
      var10001 = I[166 ^ 161];
      if (var5 >= (71 ^ 79)) {
         return (boolean)"".length();
      } else {
         int var6 = var2.getX();
         int var7 = var2.getY();
         int var8 = var2.getZ();
         int var9 = " ".length();
         BlockRailBase.EnumRailDirection var10 = (BlockRailBase.EnumRailDirection)var3.getValue(SHAPE);
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[var10.ordinal()]) {
         case 1:
            if (var4) {
               ++var8;
               "".length();
               if (4 <= 3) {
                  throw null;
               }
            } else {
               --var8;
               "".length();
               if (-1 == 2) {
                  throw null;
               }
            }
            break;
         case 2:
            if (var4) {
               --var6;
               "".length();
               if (-1 == 1) {
                  throw null;
               }
            } else {
               ++var6;
               "".length();
               if (3 < 3) {
                  throw null;
               }
            }
            break;
         case 3:
            if (var4) {
               --var6;
               "".length();
               if (-1 != -1) {
                  throw null;
               }
            } else {
               ++var6;
               ++var7;
               var9 = "".length();
            }

            var10 = BlockRailBase.EnumRailDirection.EAST_WEST;
            "".length();
            if (4 == 0) {
               throw null;
            }
            break;
         case 4:
            if (var4) {
               --var6;
               ++var7;
               var9 = "".length();
               "".length();
               if (4 <= 3) {
                  throw null;
               }
            } else {
               ++var6;
            }

            var10 = BlockRailBase.EnumRailDirection.EAST_WEST;
            "".length();
            if (4 != 4) {
               throw null;
            }
            break;
         case 5:
            if (var4) {
               ++var8;
               "".length();
               if (3 == 4) {
                  throw null;
               }
            } else {
               --var8;
               ++var7;
               var9 = "".length();
            }

            var10 = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
            "".length();
            if (-1 >= 4) {
               throw null;
            }
            break;
         case 6:
            if (var4) {
               ++var8;
               ++var7;
               var9 = "".length();
               "".length();
               if (3 < 2) {
                  throw null;
               }
            } else {
               --var8;
            }

            var10 = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
         }

         I[83 ^ 91].length();
         I[141 ^ 132].length();
         I[142 ^ 132].length();
         if (this.isSameRailWithPower(var1, new BlockPos(var6, var7, var8), var4, var5, var10)) {
            return (boolean)" ".length();
         } else {
            int var11;
            if (var9 != 0) {
               I[149 ^ 158].length();
               I[38 ^ 42].length();
               I[80 ^ 93].length();
               I[13 ^ 3].length();
               int var10006 = " ".length();
               I[22 ^ 25].length();
               I[65 ^ 81].length();
               I[69 ^ 84].length();
               I[99 ^ 113].length();
               if (this.isSameRailWithPower(var1, new BlockPos(var6, var7 - var10006, var8), var4, var5, var10)) {
                  var11 = " ".length();
                  "".length();
                  if (false) {
                     throw null;
                  }

                  return (boolean)var11;
               }
            }

            var11 = "".length();
            return (boolean)var11;
         }
      }
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).getMetadata();
      if ((Boolean)var1.getValue(POWERED)) {
         var2 |= 22 ^ 30;
      }

      return var2;
   }
}

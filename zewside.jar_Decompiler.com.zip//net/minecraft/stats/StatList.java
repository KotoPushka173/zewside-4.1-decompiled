package net.minecraft.stats;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityList;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextComponentTranslation;

public class StatList {
   // $FF: synthetic field
   public static final List<StatCrafting> USE_ITEM_STATS;
   // $FF: synthetic field
   public static final StatBase BREWINGSTAND_INTERACTION;
   // $FF: synthetic field
   public static final StatBase ENDERCHEST_OPENED;
   // $FF: synthetic field
   public static final StatBase field_191272_ae;
   // $FF: synthetic field
   public static final StatBase DISPENSER_INSPECTED;
   // $FF: synthetic field
   public static final StatBase BANNER_CLEANED;
   // $FF: synthetic field
   public static final StatBase DIVE_ONE_CM;
   // $FF: synthetic field
   public static final StatBase FLY_ONE_CM;
   // $FF: synthetic field
   public static final StatBase DEATHS;
   // $FF: synthetic field
   public static final StatBase AVIATE_ONE_CM;
   // $FF: synthetic field
   public static final StatBase SWIM_ONE_CM;
   // $FF: synthetic field
   public static final StatBase BOAT_ONE_CM;
   // $FF: synthetic field
   public static final StatBase RECORD_PLAYED;
   // $FF: synthetic field
   public static final StatBase TIME_SINCE_DEATH;
   // $FF: synthetic field
   public static final List<StatBase> BASIC_STATS;
   // $FF: synthetic field
   public static final StatBase TRAPPED_CHEST_TRIGGERED;
   // $FF: synthetic field
   public static final StatBase CROUCH_ONE_CM;
   // $FF: synthetic field
   public static final StatBase DAMAGE_DEALT;
   // $FF: synthetic field
   public static final StatBase FLOWER_POTTED;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final StatBase FURNACE_INTERACTION;
   // $FF: synthetic field
   public static final StatBase HOPPER_INSPECTED;
   // $FF: synthetic field
   private static final StatBase[] BLOCKS_STATS;
   // $FF: synthetic field
   private static final StatBase[] OBJECTS_DROPPED_STATS;
   // $FF: synthetic field
   public static final StatBase TALKED_TO_VILLAGER;
   // $FF: synthetic field
   public static final StatBase JUMP;
   // $FF: synthetic field
   public static final StatBase MINECART_ONE_CM;
   // $FF: synthetic field
   public static final StatBase CLIMB_ONE_CM;
   // $FF: synthetic field
   public static final StatBase CHEST_OPENED;
   // $FF: synthetic field
   public static final StatBase PIG_ONE_CM;
   // $FF: synthetic field
   public static final StatBase LEAVE_GAME;
   // $FF: synthetic field
   public static final StatBase FALL_ONE_CM;
   // $FF: synthetic field
   public static final StatBase DROP;
   // $FF: synthetic field
   public static final StatBase DAMAGE_TAKEN;
   // $FF: synthetic field
   public static final List<StatCrafting> MINE_BLOCK_STATS;
   // $FF: synthetic field
   public static final StatBase ANIMALS_BRED;
   // $FF: synthetic field
   public static final StatBase SLEEP_IN_BED;
   // $FF: synthetic field
   public static final StatBase PLAY_ONE_MINUTE;
   // $FF: synthetic field
   public static final StatBase SPRINT_ONE_CM;
   // $FF: synthetic field
   public static final StatBase HORSE_ONE_CM;
   // $FF: synthetic field
   public static final StatBase PLAYER_KILLS;
   // $FF: synthetic field
   public static final StatBase DROPPER_INSPECTED;
   // $FF: synthetic field
   protected static final Map<String, StatBase> ID_TO_STAT_MAP;
   // $FF: synthetic field
   public static final StatBase BEACON_INTERACTION;
   // $FF: synthetic field
   public static final StatBase ARMOR_CLEANED;
   // $FF: synthetic field
   public static final StatBase TRADED_WITH_VILLAGER;
   // $FF: synthetic field
   public static final StatBase FISH_CAUGHT;
   // $FF: synthetic field
   private static final StatBase[] OBJECTS_PICKED_UP_STATS;
   // $FF: synthetic field
   private static final StatBase[] OBJECT_BREAK_STATS;
   // $FF: synthetic field
   public static final StatBase CRAFTING_TABLE_INTERACTION;
   // $FF: synthetic field
   public static final StatBase CAKE_SLICES_EATEN;
   // $FF: synthetic field
   public static final StatBase CAULDRON_FILLED;
   // $FF: synthetic field
   public static final List<StatBase> ALL_STATS;
   // $FF: synthetic field
   public static final StatBase MOB_KILLS;
   // $FF: synthetic field
   public static final StatBase CAULDRON_USED;
   // $FF: synthetic field
   public static final StatBase NOTEBLOCK_TUNED;
   // $FF: synthetic field
   private static final StatBase[] CRAFTS_STATS;
   // $FF: synthetic field
   public static final StatBase SNEAK_TIME;
   // $FF: synthetic field
   public static final StatBase ITEM_ENCHANTED;
   // $FF: synthetic field
   public static final StatBase WALK_ONE_CM;
   // $FF: synthetic field
   private static final StatBase[] OBJECT_USE_STATS;
   // $FF: synthetic field
   public static final StatBase NOTEBLOCK_PLAYED;

   @Nullable
   public static StatBase getObjectsPickedUpStats(Item var0) {
      return OBJECTS_PICKED_UP_STATS[Item.getIdFromItem(var0)];
   }

   @Nullable
   public static StatBase getOneShotStat(String var0) {
      return (StatBase)ID_TO_STAT_MAP.get(var0);
   }

   @Nullable
   public static StatBase getBlockStats(Block var0) {
      return BLOCKS_STATS[Block.getIdFromBlock(var0)];
   }

   public static StatBase getStatEntityKilledBy(EntityList.EntityEggInfo var0) {
      String var10000 = I[192 + 46 - 186 + 177];
      String var10001 = I[190 + 11 - 75 + 104];
      String var10002 = I[180 + 214 - 331 + 168];
      var10001 = I[28 + 171 - 121 + 154];
      var10000 = I[172 + 3 - 4 + 62];
      var10001 = I[117 + 212 - 121 + 26];
      var10002 = I[96 + 218 - 186 + 107];
      var10001 = I[66 + 18 - -50 + 102];
      var10000 = I[146 + 147 - 154 + 98];
      var10001 = I[178 + 38 - 147 + 169];
      var10002 = I[19 + 91 - 96 + 225];
      var10001 = I[103 + 186 - 210 + 161];
      var10000 = I[68 + 235 - 180 + 118];
      var10001 = I[90 + 215 - 108 + 45];
      var10002 = I[14 + 93 - -10 + 126];
      var10001 = I[81 + 177 - 20 + 6];
      var10000 = I[244 + 88 - 99 + 12];
      var10001 = I[50 + 93 - 63 + 166];
      var10002 = I[101 + 224 - 218 + 140];
      var10001 = I[193 + 81 - 237 + 211];
      var10000 = I[15 + 19 - -42 + 173];
      var10001 = I[99 + 176 - 54 + 29];
      var10002 = I[122 + 227 - 234 + 136];
      var10001 = I[59 + 144 - -14 + 35];
      String var1 = EntityList.func_191302_a(var0.spawnedID);
      StatBase var2;
      if (var1 == null) {
         var2 = null;
         "".length();
         if (4 == 1) {
            throw null;
         }
      } else {
         I[246 + 196 - 425 + 236].length();
         I[169 + 191 - 291 + 185].length();
         I[14 + 80 - -150 + 11].length();
         I[94 + 162 - 51 + 51].length();
         I[210 + 17 - 68 + 98].length();
         I[136 + 257 - 145 + 10].length();
         I[207 + 100 - 142 + 94].length();
         I[153 + 219 - 338 + 226].length();
         var10002 = I[157 + 104 - 223 + 223] + var1;
         I[189 + 129 - 86 + 30].length();
         String var10005 = I[145 + 110 - 33 + 41];
         Object[] var10006 = new Object[" ".length()];
         I[41 + 100 - 125 + 248].length();
         I[196 + 35 - 183 + 217].length();
         I[222 + 123 - 130 + 51].length();
         I[187 + 124 - 50 + 6].length();
         int var10008 = "".length();
         I[147 + 92 - 94 + 123].length();
         I[267 + 14 - 232 + 220].length();
         I[228 + 82 - 220 + 180].length();
         I[75 + 197 - 121 + 120].length();
         I[190 + 15 - -54 + 13].length();
         var10006[var10008] = new TextComponentTranslation(I[145 + 84 - 228 + 272] + var1 + I[170 + 6 - 105 + 203], new Object["".length()]);
         var2 = (new StatBase(var10002, new TextComponentTranslation(var10005, var10006))).registerStat();
      }

      return var2;
   }

   static {
      I();
      ID_TO_STAT_MAP = Maps.newHashMap();
      ALL_STATS = Lists.newArrayList();
      BASIC_STATS = Lists.newArrayList();
      USE_ITEM_STATS = Lists.newArrayList();
      MINE_BLOCK_STATS = Lists.newArrayList();
      LEAVE_GAME = (new StatBasic(I[274 + 272 - 545 + 274], new TextComponentTranslation(I[97 + 200 - 278 + 257], new Object["".length()]))).initIndependentStat().registerStat();
      PLAY_ONE_MINUTE = (new StatBasic(I[73 + 169 - 187 + 222], new TextComponentTranslation(I[4 + 250 - 195 + 219], new Object["".length()]), StatBase.timeStatType)).initIndependentStat().registerStat();
      TIME_SINCE_DEATH = (new StatBasic(I[128 + 224 - 81 + 8], new TextComponentTranslation(I[271 + 228 - 379 + 160], new Object["".length()]), StatBase.timeStatType)).initIndependentStat().registerStat();
      SNEAK_TIME = (new StatBasic(I[219 + 0 - 191 + 253], new TextComponentTranslation(I[173 + 14 - -54 + 41], new Object["".length()]), StatBase.timeStatType)).initIndependentStat().registerStat();
      WALK_ONE_CM = (new StatBasic(I[279 + 162 - 279 + 121], new TextComponentTranslation(I[241 + 193 - 263 + 113], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      CROUCH_ONE_CM = (new StatBasic(I[187 + 191 - 244 + 151], new TextComponentTranslation(I[147 + 188 - 212 + 163], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      SPRINT_ONE_CM = (new StatBasic(I[148 + 73 - 192 + 258], new TextComponentTranslation(I[72 + 151 - -54 + 11], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      SWIM_ONE_CM = (new StatBasic(I[172 + 103 - 187 + 201], new TextComponentTranslation(I[128 + 196 - 47 + 13], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      FALL_ONE_CM = (new StatBasic(I[53 + 263 - 66 + 41], new TextComponentTranslation(I[117 + 50 - -20 + 105], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      CLIMB_ONE_CM = (new StatBasic(I[284 + 146 - 193 + 56], new TextComponentTranslation(I[244 + 19 - 37 + 68], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      FLY_ONE_CM = (new StatBasic(I[24 + 272 - 239 + 238], new TextComponentTranslation(I[175 + 189 - 127 + 59], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      DIVE_ONE_CM = (new StatBasic(I[105 + 79 - -64 + 49], new TextComponentTranslation(I[270 + 204 - 381 + 205], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      MINECART_ONE_CM = (new StatBasic(I[156 + 257 - 348 + 234], new TextComponentTranslation(I[88 + 167 - 239 + 284], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      BOAT_ONE_CM = (new StatBasic(I[121 + 252 - 316 + 244], new TextComponentTranslation(I[285 + 211 - 332 + 138], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      PIG_ONE_CM = (new StatBasic(I[254 + 38 - 248 + 259], new TextComponentTranslation(I[213 + 94 - 71 + 68], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      HORSE_ONE_CM = (new StatBasic(I[126 + 296 - 229 + 112], new TextComponentTranslation(I[230 + 176 - 353 + 253], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      AVIATE_ONE_CM = (new StatBasic(I[34 + 134 - -55 + 84], new TextComponentTranslation(I[48 + 198 - 177 + 239], new Object["".length()]), StatBase.distanceStatType)).initIndependentStat().registerStat();
      JUMP = (new StatBasic(I[211 + 293 - 284 + 89], new TextComponentTranslation(I[220 + 268 - 273 + 95], new Object["".length()]))).initIndependentStat().registerStat();
      DROP = (new StatBasic(I[236 + 173 - 390 + 292], new TextComponentTranslation(I[252 + 189 - 161 + 32], new Object["".length()]))).initIndependentStat().registerStat();
      DAMAGE_DEALT = (new StatBasic(I[228 + 135 - 316 + 266], new TextComponentTranslation(I[252 + 197 - 416 + 281], new Object["".length()]), StatBase.divideByTen)).registerStat();
      DAMAGE_TAKEN = (new StatBasic(I[91 + 241 - 283 + 266], new TextComponentTranslation(I[256 + 78 - 246 + 228], new Object["".length()]), StatBase.divideByTen)).registerStat();
      DEATHS = (new StatBasic(I[195 + 98 - 261 + 285], new TextComponentTranslation(I[93 + 40 - -17 + 168], new Object["".length()]))).registerStat();
      MOB_KILLS = (new StatBasic(I[175 + 145 - 226 + 225], new TextComponentTranslation(I[65 + 12 - -68 + 175], new Object["".length()]))).registerStat();
      ANIMALS_BRED = (new StatBasic(I[40 + 31 - -94 + 156], new TextComponentTranslation(I[148 + 140 - 158 + 192], new Object["".length()]))).registerStat();
      PLAYER_KILLS = (new StatBasic(I[281 + 255 - 519 + 306], new TextComponentTranslation(I[62 + 238 - 30 + 54], new Object["".length()]))).registerStat();
      FISH_CAUGHT = (new StatBasic(I[107 + 264 - 52 + 6], new TextComponentTranslation(I[160 + 178 - 128 + 116], new Object["".length()]))).registerStat();
      TALKED_TO_VILLAGER = (new StatBasic(I[96 + 288 - 190 + 133], new TextComponentTranslation(I[209 + 313 - 328 + 134], new Object["".length()]))).registerStat();
      TRADED_WITH_VILLAGER = (new StatBasic(I[148 + 57 - 118 + 242], new TextComponentTranslation(I[145 + 221 - 67 + 31], new Object["".length()]))).registerStat();
      CAKE_SLICES_EATEN = (new StatBasic(I[108 + 209 - 217 + 231], new TextComponentTranslation(I[133 + 167 - 277 + 309], new Object["".length()]))).registerStat();
      CAULDRON_FILLED = (new StatBasic(I[232 + 41 - 209 + 269], new TextComponentTranslation(I[84 + 199 - 94 + 145], new Object["".length()]))).registerStat();
      CAULDRON_USED = (new StatBasic(I[299 + 74 - 57 + 19], new TextComponentTranslation(I[23 + 308 - 126 + 131], new Object["".length()]))).registerStat();
      ARMOR_CLEANED = (new StatBasic(I[180 + 149 - 138 + 146], new TextComponentTranslation(I[9 + 312 - 65 + 82], new Object["".length()]))).registerStat();
      BANNER_CLEANED = (new StatBasic(I[276 + 219 - 481 + 325], new TextComponentTranslation(I[275 + 332 - 412 + 145], new Object["".length()]))).registerStat();
      BREWINGSTAND_INTERACTION = (new StatBasic(I[266 + 43 - 113 + 145], new TextComponentTranslation(I[210 + 113 - 252 + 271], new Object["".length()]))).registerStat();
      BEACON_INTERACTION = (new StatBasic(I[313 + 130 - 425 + 325], new TextComponentTranslation(I[267 + 127 - 304 + 254], new Object["".length()]))).registerStat();
      DROPPER_INSPECTED = (new StatBasic(I[74 + 321 - 235 + 185], new TextComponentTranslation(I[91 + 323 - 132 + 64], new Object["".length()]))).registerStat();
      HOPPER_INSPECTED = (new StatBasic(I[216 + 122 - 286 + 295], new TextComponentTranslation(I[214 + 313 - 278 + 99], new Object["".length()]))).registerStat();
      DISPENSER_INSPECTED = (new StatBasic(I[216 + 229 - 404 + 308], new TextComponentTranslation(I[265 + 153 - 282 + 214], new Object["".length()]))).registerStat();
      NOTEBLOCK_PLAYED = (new StatBasic(I[224 + 159 - 268 + 236], new TextComponentTranslation(I[259 + 206 - 426 + 313], new Object["".length()]))).registerStat();
      NOTEBLOCK_TUNED = (new StatBasic(I[158 + 17 - 71 + 249], new TextComponentTranslation(I[102 + 273 - 58 + 37], new Object["".length()]))).registerStat();
      FLOWER_POTTED = (new StatBasic(I[53 + 26 - -262 + 14], new TextComponentTranslation(I[333 + 25 - 46 + 44], new Object["".length()]))).registerStat();
      TRAPPED_CHEST_TRIGGERED = (new StatBasic(I[113 + 216 - 207 + 235], new TextComponentTranslation(I[43 + 316 - 112 + 111], new Object["".length()]))).registerStat();
      ENDERCHEST_OPENED = (new StatBasic(I[34 + 18 - -198 + 109], new TextComponentTranslation(I[109 + 141 - 57 + 167], new Object["".length()]))).registerStat();
      ITEM_ENCHANTED = (new StatBasic(I[280 + 237 - 308 + 152], new TextComponentTranslation(I[202 + 142 - 51 + 69], new Object["".length()]))).registerStat();
      RECORD_PLAYED = (new StatBasic(I[187 + 133 - 287 + 330], new TextComponentTranslation(I[111 + 60 - 26 + 219], new Object["".length()]))).registerStat();
      FURNACE_INTERACTION = (new StatBasic(I[268 + 297 - 451 + 251], new TextComponentTranslation(I[181 + 204 - 217 + 198], new Object["".length()]))).registerStat();
      CRAFTING_TABLE_INTERACTION = (new StatBasic(I[334 + 225 - 320 + 128], new TextComponentTranslation(I[97 + 29 - -219 + 23], new Object["".length()]))).registerStat();
      CHEST_OPENED = (new StatBasic(I[171 + 149 - 51 + 100], new TextComponentTranslation(I[112 + 76 - 13 + 195], new Object["".length()]))).registerStat();
      SLEEP_IN_BED = (new StatBasic(I[29 + 235 - -86 + 21], new TextComponentTranslation(I[160 + 215 - 46 + 43], new Object["".length()]))).registerStat();
      field_191272_ae = (new StatBasic(I[50 + 135 - 7 + 195], new TextComponentTranslation(I[31 + 57 - -19 + 267], new Object["".length()]))).registerStat();
      BLOCKS_STATS = new StatBase[2391 + 1875 - 2777 + 2607];
      CRAFTS_STATS = new StatBase[8537 + 9887 - -4336 + 9240];
      OBJECT_USE_STATS = new StatBase[28629 + 31916 - '튓' + 25362];
      OBJECT_BREAK_STATS = new StatBase[5186 + 17331 - -1052 + 8431];
      OBJECTS_PICKED_UP_STATS = new StatBase[13075 + 15053 - 4345 + 8217];
      OBJECTS_DROPPED_STATS = new StatBase[4690 + 5543 - -9568 + 12199];
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   @Nullable
   public static StatBase getCraftStats(Item var0) {
      return CRAFTS_STATS[Item.getIdFromItem(var0)];
   }

   private static void mergeStatBases(StatBase[] var0, Block var1, Block var2) {
      int var3 = Block.getIdFromBlock(var1);
      int var4 = Block.getIdFromBlock(var2);
      if (var0[var3] != null && var0[var4] == null) {
         var0[var4] = var0[var3];
         "".length();
         if (4 == 1) {
            throw null;
         }
      } else {
         ALL_STATS.remove(var0[var3]);
         I[107 + 140 - 226 + 158].length();
         I[94 + 105 - 197 + 178].length();
         MINE_BLOCK_STATS.remove(var0[var3]);
         I[152 + 139 - 236 + 126].length();
         I[124 + 117 - 116 + 57].length();
         I[157 + 81 - 194 + 139].length();
         BASIC_STATS.remove(var0[var3]);
         I[81 + 50 - 109 + 162].length();
         var0[var3] = var0[var4];
      }

   }

   private static void initItemDepleteStats() {
      String var10000 = I[229 ^ 135];
      String var10001 = I[18 ^ 113];
      String var10002 = I[160 ^ 196];
      var10001 = I[123 ^ 30];
      var10000 = I[11 ^ 109];
      var10001 = I[200 ^ 175];
      var10002 = I[29 ^ 117];
      var10001 = I[95 ^ 54];
      var10000 = I[90 ^ 48];
      var10001 = I[198 ^ 173];
      var10002 = I[23 ^ 123];
      var10001 = I[207 ^ 162];
      var10000 = I[227 ^ 141];
      var10001 = I[111 ^ 0];
      var10002 = I[236 ^ 156];
      var10001 = I[23 ^ 102];
      Iterator var0 = Item.REGISTRY.iterator();

      do {
         if (!var0.hasNext()) {
            replaceAllSimilarBlocks(OBJECT_BREAK_STATS);
            return;
         }

         Item var1 = (Item)var0.next();
         if (var1 != null) {
            int var2 = Item.getIdFromItem(var1);
            String var3 = getItemName(var1);
            if (var3 != null && var1.isDamageable()) {
               StatBase[] var4 = OBJECT_BREAK_STATS;
               I[51 ^ 65].length();
               I[97 ^ 18].length();
               String var10004 = I[242 ^ 134];
               I[122 ^ 15].length();
               I[119 ^ 1].length();
               String var10008 = I[33 ^ 86];
               Object[] var10009 = new Object[" ".length()];
               I[23 ^ 111].length();
               int var10011 = "".length();
               I[83 ^ 42].length();
               I[36 ^ 94].length();
               var10009[var10011] = (new ItemStack(var1)).getTextComponent();
               var4[var2] = (new StatCrafting(var10004, var3, new TextComponentTranslation(var10008, var10009), var1)).registerStat();
            }
         }

         "".length();
      } while(3 >= 3);

      throw null;
   }

   public static void init() {
      initMiningStats();
      initStats();
      initItemDepleteStats();
      initCraftableStats();
      initPickedUpAndDroppedStats();
   }

   public static StatBase getStatKillEntity(EntityList.EntityEggInfo var0) {
      String var10000 = I[133 + 171 - 278 + 159];
      String var10001 = I[69 + 170 - 211 + 158];
      String var10002 = I[152 + 148 - 189 + 76];
      var10001 = I[79 + 75 - 2 + 36];
      var10000 = I[186 + 120 - 213 + 96];
      var10001 = I[98 + 13 - 53 + 132];
      var10002 = I[55 + 42 - -19 + 75];
      var10001 = I[127 + 74 - 180 + 171];
      var10000 = I[97 + 23 - 116 + 189];
      var10001 = I[190 + 32 - 96 + 68];
      var10002 = I[34 + 89 - 42 + 114];
      var10001 = I[143 + 195 - 194 + 52];
      var10000 = I[145 + 52 - 135 + 135];
      var10001 = I[164 + 39 - 17 + 12];
      var10002 = I[179 + 174 - 211 + 57];
      var10001 = I[147 + 62 - 54 + 45];
      var10000 = I[126 + 9 - 87 + 153];
      var10001 = I[134 + 12 - 139 + 195];
      var10002 = I[169 + 29 - 178 + 183];
      var10001 = I[46 + 4 - -76 + 78];
      var10000 = I[129 + 108 - 57 + 25];
      var10001 = I[151 + 68 - 130 + 117];
      var10002 = I[63 + 163 - 21 + 2];
      var10001 = I[132 + 148 - 78 + 6];
      String var1 = EntityList.func_191302_a(var0.spawnedID);
      StatBase var2;
      if (var1 == null) {
         var2 = null;
         "".length();
         if (2 < -1) {
            throw null;
         }
      } else {
         I[150 + 103 - 64 + 20].length();
         I[200 + 2 - 75 + 83].length();
         I[77 + 138 - 44 + 40].length();
         I[128 + 15 - 101 + 170].length();
         I[49 + 1 - 27 + 190].length();
         I[62 + 1 - -11 + 140].length();
         I[171 + 72 - 57 + 29].length();
         var10002 = I[142 + 7 - 34 + 101] + var1;
         I[59 + 134 - 145 + 169].length();
         I[15 + 188 - 30 + 45].length();
         I[33 + 24 - 43 + 205].length();
         String var10005 = I[168 + 58 - 18 + 12];
         Object[] var10006 = new Object[" ".length()];
         I[135 + 25 - -15 + 46].length();
         int var10008 = "".length();
         I[40 + 186 - 60 + 56].length();
         I[83 + 209 - 211 + 142].length();
         I[35 + 66 - -86 + 37].length();
         I[112 + 30 - -45 + 38].length();
         I[167 + 213 - 365 + 211].length();
         var10006[var10008] = new TextComponentTranslation(I[125 + 195 - 220 + 127] + var1 + I[37 + 118 - 87 + 160], new Object["".length()]);
         var2 = (new StatBase(var10002, new TextComponentTranslation(var10005, var10006))).registerStat();
      }

      return var2;
   }

   private static void replaceAllSimilarBlocks(StatBase[] var0) {
      mergeStatBases(var0, Blocks.WATER, Blocks.FLOWING_WATER);
      mergeStatBases(var0, Blocks.LAVA, Blocks.FLOWING_LAVA);
      mergeStatBases(var0, Blocks.LIT_PUMPKIN, Blocks.PUMPKIN);
      mergeStatBases(var0, Blocks.LIT_FURNACE, Blocks.FURNACE);
      mergeStatBases(var0, Blocks.LIT_REDSTONE_ORE, Blocks.REDSTONE_ORE);
      mergeStatBases(var0, Blocks.POWERED_REPEATER, Blocks.UNPOWERED_REPEATER);
      mergeStatBases(var0, Blocks.POWERED_COMPARATOR, Blocks.UNPOWERED_COMPARATOR);
      mergeStatBases(var0, Blocks.REDSTONE_TORCH, Blocks.UNLIT_REDSTONE_TORCH);
      mergeStatBases(var0, Blocks.LIT_REDSTONE_LAMP, Blocks.REDSTONE_LAMP);
      mergeStatBases(var0, Blocks.DOUBLE_STONE_SLAB, Blocks.STONE_SLAB);
      mergeStatBases(var0, Blocks.DOUBLE_WOODEN_SLAB, Blocks.WOODEN_SLAB);
      mergeStatBases(var0, Blocks.DOUBLE_STONE_SLAB2, Blocks.STONE_SLAB2);
      mergeStatBases(var0, Blocks.GRASS, Blocks.DIRT);
      mergeStatBases(var0, Blocks.FARMLAND, Blocks.DIRT);
   }

   private static void initStats() {
      String var10000 = I[30 ^ 92];
      String var10001 = I[103 ^ 36];
      String var10002 = I[86 ^ 18];
      var10001 = I[24 ^ 93];
      var10000 = I[45 ^ 107];
      var10001 = I[203 ^ 140];
      var10002 = I[25 ^ 81];
      var10001 = I[94 ^ 23];
      var10000 = I[142 ^ 196];
      var10001 = I[12 ^ 71];
      var10002 = I[218 ^ 150];
      var10001 = I[201 ^ 132];
      var10000 = I[110 ^ 32];
      var10001 = I[127 ^ 48];
      var10002 = I[227 ^ 179];
      var10001 = I[48 ^ 97];
      Iterator var0 = Item.REGISTRY.iterator();

      do {
         if (!var0.hasNext()) {
            replaceAllSimilarBlocks(OBJECT_USE_STATS);
            return;
         }

         Item var1 = (Item)var0.next();
         if (var1 != null) {
            int var2 = Item.getIdFromItem(var1);
            String var3 = getItemName(var1);
            if (var3 != null) {
               StatBase[] var4 = OBJECT_USE_STATS;
               I[10 ^ 88].length();
               I[75 ^ 24].length();
               I[37 ^ 113].length();
               String var10004 = I[37 ^ 112];
               I[253 ^ 171].length();
               I[149 ^ 194].length();
               I[81 ^ 9].length();
               String var10008 = I[87 ^ 14];
               Object[] var10009 = new Object[" ".length()];
               I[102 ^ 60].length();
               int var10011 = "".length();
               I[59 ^ 96].length();
               I[118 ^ 42].length();
               I[111 ^ 50].length();
               I[2 ^ 92].length();
               var10009[var10011] = (new ItemStack(var1)).getTextComponent();
               var4[var2] = (new StatCrafting(var10004, var3, new TextComponentTranslation(var10008, var10009), var1)).registerStat();
               if (!(var1 instanceof ItemBlock)) {
                  USE_ITEM_STATS.add((StatCrafting)OBJECT_USE_STATS[var2]);
                  I[243 ^ 172].length();
                  I[207 ^ 175].length();
                  I[249 ^ 152].length();
               }
            }
         }

         "".length();
      } while(4 >= 4);

      throw null;
   }

   @Nullable
   public static StatBase getObjectUseStats(Item var0) {
      return OBJECT_USE_STATS[Item.getIdFromItem(var0)];
   }

   private static void initMiningStats() {
      String var10000 = I[156 ^ 191];
      String var10001 = I[90 ^ 126];
      String var10002 = I[170 ^ 143];
      var10001 = I[119 ^ 81];
      var10000 = I[45 ^ 10];
      var10001 = I[153 ^ 177];
      var10002 = I[118 ^ 95];
      var10001 = I[152 ^ 178];
      var10000 = I[130 ^ 169];
      var10001 = I[121 ^ 85];
      var10002 = I[71 ^ 106];
      var10001 = I[47 ^ 1];
      var10000 = I[22 ^ 57];
      var10001 = I[60 ^ 12];
      var10002 = I[186 ^ 139];
      var10001 = I[116 ^ 70];
      Iterator var0 = Block.REGISTRY.iterator();

      do {
         if (!var0.hasNext()) {
            replaceAllSimilarBlocks(BLOCKS_STATS);
            return;
         }

         Block var1 = (Block)var0.next();
         Item var2 = Item.getItemFromBlock(var1);
         if (var2 != Items.field_190931_a) {
            int var3 = Block.getIdFromBlock(var1);
            String var4 = getItemName(var2);
            if (var4 != null && var1.getEnableStats()) {
               StatBase[] var5 = BLOCKS_STATS;
               I[43 ^ 24].length();
               I[40 ^ 28].length();
               I[152 ^ 173].length();
               String var10004 = I[1 ^ 55];
               I[63 ^ 8].length();
               I[122 ^ 66].length();
               I[251 ^ 194].length();
               String var10008 = I[26 ^ 32];
               Object[] var10009 = new Object[" ".length()];
               I[176 ^ 139].length();
               int var10011 = "".length();
               I[137 ^ 181].length();
               I[111 ^ 82].length();
               var10009[var10011] = (new ItemStack(var1)).getTextComponent();
               var5[var3] = (new StatCrafting(var10004, var4, new TextComponentTranslation(var10008, var10009), var2)).registerStat();
               MINE_BLOCK_STATS.add((StatCrafting)BLOCKS_STATS[var3]);
               I[186 ^ 132].length();
               I[142 ^ 177].length();
               I[46 ^ 110].length();
               I[102 ^ 39].length();
            }
         }

         "".length();
      } while(-1 < 2);

      throw null;
   }

   @Nullable
   public static StatBase getDroppedObjectStats(Item var0) {
      return OBJECTS_DROPPED_STATS[Item.getIdFromItem(var0)];
   }

   private static void initPickedUpAndDroppedStats() {
      String var10000 = I[3 ^ 120];
      String var10001 = I[80 ^ 44];
      String var10002 = I[50 ^ 79];
      var10001 = I[125 ^ 3];
      var10000 = I[61 + 110 - 167 + 123];
      var10001 = I[85 + 4 - -15 + 24];
      var10002 = I[88 + 105 - 86 + 22];
      var10001 = I[75 + 66 - 33 + 22];
      var10000 = I[103 + 62 - 105 + 71];
      var10001 = I[120 + 73 - 188 + 127];
      var10002 = I[104 + 21 - 87 + 95];
      var10001 = I[97 + 47 - 15 + 5];
      var10000 = I[84 + 105 - 64 + 10];
      var10001 = I[57 + 45 - 62 + 96];
      var10002 = I[131 + 121 - 124 + 9];
      var10001 = I[78 + 2 - -23 + 35];
      var10000 = I[55 + 125 - 110 + 69];
      var10001 = I[13 + 138 - 80 + 69];
      var10002 = I[44 + 68 - 77 + 106];
      var10001 = I[3 + 122 - 105 + 122];
      var10000 = I[136 + 124 - 212 + 95];
      var10001 = I[100 + 32 - 77 + 89];
      var10002 = I[45 + 47 - 10 + 63];
      var10001 = I[117 + 60 - 98 + 67];
      var10000 = I[105 + 77 - 85 + 50];
      var10001 = I[1 + 132 - -4 + 11];
      var10002 = I[136 + 19 - 143 + 137];
      var10001 = I[143 + 111 - 134 + 30];
      var10000 = I[12 + 138 - 147 + 148];
      var10001 = I[97 + 70 - 142 + 127];
      var10002 = I[116 + 21 - 4 + 20];
      var10001 = I[36 + 60 - 52 + 110];
      Iterator var0 = Item.REGISTRY.iterator();

      do {
         if (!var0.hasNext()) {
            replaceAllSimilarBlocks(OBJECT_BREAK_STATS);
            return;
         }

         Item var1 = (Item)var0.next();
         if (var1 != null) {
            int var2 = Item.getIdFromItem(var1);
            String var3 = getItemName(var1);
            if (var3 != null) {
               StatBase[] var4 = OBJECTS_PICKED_UP_STATS;
               I[8 + 147 - 133 + 133].length();
               I[97 + 134 - 187 + 112].length();
               I[150 + 62 - 190 + 135].length();
               String var10004 = I[95 + 157 - 229 + 135];
               I[138 + 88 - 129 + 62].length();
               I[120 + 145 - 254 + 149].length();
               String var10008 = I[151 + 79 - 167 + 98];
               Object[] var10009 = new Object[" ".length()];
               I[112 + 11 - 99 + 138].length();
               I[77 + 88 - 26 + 24].length();
               I[86 + 145 - 90 + 23].length();
               int var10011 = "".length();
               I[50 + 48 - 61 + 128].length();
               I[136 + 125 - 205 + 110].length();
               I[30 + 57 - 53 + 133].length();
               var10009[var10011] = (new ItemStack(var1)).getTextComponent();
               var4[var2] = (new StatCrafting(var10004, var3, new TextComponentTranslation(var10008, var10009), var1)).registerStat();
               var4 = OBJECTS_DROPPED_STATS;
               I[80 + 82 - 93 + 99].length();
               I[104 + 158 - 215 + 122].length();
               var10004 = I[125 + 1 - -42 + 2];
               I[67 + 14 - -77 + 13].length();
               I[161 + 168 - 266 + 109].length();
               var10008 = I[109 + 38 - 119 + 145];
               var10009 = new Object[" ".length()];
               I[77 + 35 - -49 + 13].length();
               I[43 + 85 - 38 + 85].length();
               var10011 = "".length();
               I[135 + 157 - 205 + 89].length();
               I[169 + 142 - 265 + 131].length();
               I[171 + 68 - 166 + 105].length();
               var10009[var10011] = (new ItemStack(var1)).getTextComponent();
               var4[var2] = (new StatCrafting(var10004, var3, new TextComponentTranslation(var10008, var10009), var1)).registerStat();
            }
         }

         "".length();
      } while(1 >= 0);

      throw null;
   }

   @Nullable
   public static StatBase getObjectBreakStats(Item var0) {
      return OBJECT_BREAK_STATS[Item.getIdFromItem(var0)];
   }

   private static void initCraftableStats() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[8 ^ 12];
      var10001 = I[34 ^ 39];
      var10002 = I[141 ^ 139];
      var10001 = I[5 ^ 2];
      var10000 = I[58 ^ 50];
      var10001 = I[88 ^ 81];
      var10002 = I[122 ^ 112];
      var10001 = I[180 ^ 191];
      var10000 = I[54 ^ 58];
      var10001 = I[90 ^ 87];
      var10002 = I[157 ^ 147];
      var10001 = I[89 ^ 86];
      HashSet var0 = Sets.newHashSet();
      Iterator var1 = CraftingManager.field_193380_a.iterator();

      do {
         if (!var1.hasNext()) {
            var1 = FurnaceRecipes.instance().getSmeltingList().values().iterator();

            do {
               if (!var1.hasNext()) {
                  var1 = var0.iterator();

                  do {
                     if (!var1.hasNext()) {
                        replaceAllSimilarBlocks(CRAFTS_STATS);
                        return;
                     }

                     Item var6 = (Item)var1.next();
                     if (var6 != null) {
                        int var7 = Item.getIdFromItem(var6);
                        String var4 = getItemName(var6);
                        if (var4 != null) {
                           StatBase[] var8 = CRAFTS_STATS;
                           I[96 ^ 116].length();
                           I[167 ^ 178].length();
                           I[92 ^ 74].length();
                           I[115 ^ 100].length();
                           String var10004 = I[189 ^ 165];
                           I[189 ^ 164].length();
                           String var10008 = I[191 ^ 165];
                           Object[] var10009 = new Object[" ".length()];
                           I[175 ^ 180].length();
                           I[86 ^ 74].length();
                           I[161 ^ 188].length();
                           I[38 ^ 56].length();
                           I[83 ^ 76].length();
                           int var10011 = "".length();
                           I[92 ^ 124].length();
                           I[53 ^ 20].length();
                           I[82 ^ 112].length();
                           var10009[var10011] = (new ItemStack(var6)).getTextComponent();
                           var8[var7] = (new StatCrafting(var10004, var4, new TextComponentTranslation(var10008, var10009), var6)).registerStat();
                        }
                     }

                     "".length();
                  } while(2 >= 2);

                  throw null;
               }

               ItemStack var5 = (ItemStack)var1.next();
               var0.add(var5.getItem());
               I[96 ^ 113].length();
               I[11 ^ 25].length();
               I[47 ^ 60].length();
               "".length();
            } while(3 >= 0);

            throw null;
         }

         IRecipe var2 = (IRecipe)var1.next();
         ItemStack var3 = var2.getRecipeOutput();
         if (!var3.isEmpty()) {
            var0.add(var2.getRecipeOutput().getItem());
            I[99 ^ 115].length();
         }

         "".length();
      } while(-1 < 4);

      throw null;
   }

   private static void I() {
      I = new String[358 + 127 - 174 + 64];
      I["".length()] = I("曰枥", "zvEvG");
      I[" ".length()] = I("棪挒", "QgEvk");
      I["  ".length()] = I("丹擥", "qSYWq");
      I["   ".length()] = I("叐挫", "Bjlzp");
      I[26 ^ 30] = I("忏夅", "hfUXM");
      I[173 ^ 168] = I("侢兂", "OKyRv");
      I[105 ^ 111] = I("喑孚", "VCUXN");
      I[183 ^ 176] = I("摾煤", "ogjTG");
      I[155 ^ 147] = I("妡优", "DUgfI");
      I[88 ^ 81] = I("丛惁", "kCaeE");
      I[41 ^ 35] = I("嚂卧", "NKkVi");
      I[11 ^ 0] = I("埄偢", "JddkD");
      I[96 ^ 108] = I("俬俕", "mXLhc");
      I[203 ^ 198] = I("寎浏", "aaTyj");
      I[138 ^ 132] = I("囨嗣", "siWbs");
      I[12 ^ 3] = I("媣婘", "RFAbS");
      I[215 ^ 199] = I("摒懏嚫喬吣", "eZmDT");
      I[132 ^ 149] = I("唤曷滓", "oJQDv");
      I[157 ^ 143] = I("単", "KwaDz");
      I[120 ^ 107] = I("恋搛", "zVloj");
      I[170 ^ 190] = I("櫤泫", "JkpLs");
      I[187 ^ 174] = I("嘏浏柾", "ooWZZ");
      I[159 ^ 137] = I("棷", "nsiTN");
      I[73 ^ 94] = I("涅攉嚲嗈", "bnysh");
      I[132 ^ 156] = I("\u000b\u001e*\rx\u001b\u0018*\u001f\"1\u001e.\u0014x", "xjKyV");
      I[115 ^ 106] = I("哩刞橦", "aAqwI");
      I[96 ^ 122] = I("\u0006% \u001fk\u0016# \r1<%$\u0006", "uQAkE");
      I[138 ^ 145] = I("沋夯懴樢嵅", "KJVKo");
      I[118 ^ 106] = I("汮旿囸嚡", "FXutd");
      I[114 ^ 111] = I("溩", "vzaiG");
      I[151 ^ 137] = I("敎埲僪婕", "rmFnW");
      I[140 ^ 147] = I("偼嘸庨敹屮", "bPoDu");
      I[94 ^ 126] = I("卖峙榽", "xarBE");
      I[97 ^ 64] = I("戊拺忬", "hhzgr");
      I[135 ^ 165] = I("庿峘敞", "NVrLq");
      I[127 ^ 92] = I("擝斄", "xdlyr");
      I[156 ^ 184] = I("坖俬", "DVsrx");
      I[148 ^ 177] = I("怉储", "FlkeW");
      I[116 ^ 82] = I("噉桢", "QKMRp");
      I[123 ^ 92] = I("瀽关", "QAqtM");
      I[146 ^ 186] = I("崇恼", "fWZQi");
      I[40 ^ 1] = I("咹湏", "XhHEx");
      I[154 ^ 176] = I("亦奷", "UsXyZ");
      I[99 ^ 72] = I("汱榚", "LLpsJ");
      I[232 ^ 196] = I("嗎澺", "HjaDJ");
      I[53 ^ 24] = I("检涵", "jIoMQ");
      I[114 ^ 92] = I("汧叀", "osMGL");
      I[40 ^ 7] = I("唔妢", "kvZTX");
      I[130 ^ 178] = I("桋撇", "nCHAZ");
      I[137 ^ 184] = I("厲母", "FWLlV");
      I[75 ^ 121] = I("刢懍", "JawTW");
      I[97 ^ 82] = I("嵔", "wjRyJ");
      I[22 ^ 34] = I("拮培挵", "VtKJZ");
      I[13 ^ 56] = I("佗崳垘傟低", "jFHll");
      I[1 ^ 55] = I("\u00073%\u001dZ\u0019.*\f6\u0018('\u0002Z", "tGDit");
      I[173 ^ 154] = I("妱灗匯", "zSGJC");
      I[69 ^ 125] = I("娊呪", "JHmEo");
      I[123 ^ 66] = I("妘朐敿", "nYqke");
      I[4 ^ 62] = I("\u0010\u0002.\u0012C\u000e\u001f!\u0003/\u000f\u0019,\r", "cvOfm");
      I[151 ^ 172] = I("朅槦亃殃", "EssdQ");
      I[166 ^ 154] = I("旐吃氚洹嗸", "cGjsK");
      I[187 ^ 134] = I("弦", "nJhNi");
      I[33 ^ 31] = I("媎兺個检囹", "wVhZh");
      I[120 ^ 71] = I("瀝择庾沖", "dkeHA");
      I[225 ^ 161] = I("樾", "KUfms");
      I[201 ^ 136] = I("刊屹次", "KVoym");
      I[133 ^ 199] = I("傲弝", "SPZPh");
      I[253 ^ 190] = I("傹奵", "YNyoi");
      I[15 ^ 75] = I("湵壎", "mDXjG");
      I[8 ^ 77] = I("怎殦", "QwOTM");
      I[119 ^ 49] = I("桥刐", "kPvtS");
      I[126 ^ 57] = I("汜宄", "yCQCp");
      I[211 ^ 155] = I("濝妘", "zhAMc");
      I[66 ^ 11] = I("喨庻", "PCyoK");
      I[101 ^ 47] = I("佳扵", "kOusH");
      I[69 ^ 14] = I("悗扇", "xMDmU");
      I[221 ^ 145] = I("枔峡", "qVeOR");
      I[43 ^ 102] = I("医墁", "OVvhL");
      I[203 ^ 133] = I("墏澝", "CQnoP");
      I[106 ^ 37] = I("媋勴", "KXbDo");
      I[91 ^ 11] = I("世唽", "GtuZk");
      I[47 ^ 126] = I("孃沝", "yMbTx");
      I[248 ^ 170] = I("朑朔煰", "TBbmX");
      I[226 ^ 177] = I("兩寕", "CRXQd");
      I[236 ^ 184] = I("儱孕情櫪溌", "vWxRq");
      I[11 ^ 94] = I("\u0017\u0006)\u001fd\u0011\u0001-\">\u0001\u001ff", "drHkJ");
      I[69 ^ 19] = I("嚬泄尔擠", "wXFlr");
      I[61 ^ 106] = I("扪棸媅憒妰", "LZPCM");
      I[3 ^ 91] = I("倎煔桯", "DBUyZ");
      I[9 ^ 80] = I("$:\u000f\u0013I\"=\u000b.\u00132#", "WNngg");
      I[116 ^ 46] = I("曣憁渀", "DcTBO");
      I[100 ^ 63] = I("奵嚰奾煬毥", "bIOIa");
      I[220 ^ 128] = I("湈尫", "jYQNw");
      I[30 ^ 67] = I("戄昻", "HOEUm");
      I[206 ^ 144] = I("娺晚柀佯", "AszEL");
      I[199 ^ 152] = I("孷侁抠塻", "YBxoY");
      I[102 ^ 6] = I("倔", "swmcO");
      I[79 ^ 46] = I("喙嫍", "tmTUY");
      I[121 ^ 27] = I("桟峣", "XzXws");
      I[9 ^ 106] = I("嚵杀", "GqzHw");
      I[229 ^ 129] = I("懟嶜", "tfLgV");
      I[10 ^ 111] = I("圣擋", "GmJGL");
      I[206 ^ 168] = I("岅栱", "ZRSMW");
      I[235 ^ 140] = I("候桌", "FDZFU");
      I[51 ^ 91] = I("慘堛", "EPDaw");
      I[237 ^ 132] = I("凃灊", "iPKFA");
      I[111 ^ 5] = I("径氣", "GTpHv");
      I[244 ^ 159] = I("晼奡", "EvrwP");
      I[58 ^ 86] = I("恛摩", "pNwTh");
      I[6 ^ 107] = I("佘尮", "IyDHd");
      I[213 ^ 187] = I("娯殅", "qrCWc");
      I[53 ^ 90] = I("沌嚃", "fTZiH");
      I[8 ^ 120] = I("卢床", "zQHlH");
      I[44 ^ 93] = I("枞洡", "dvXbe");
      I[76 ^ 62] = I("噕嬪抴拘", "RAAmN");
      I[176 ^ 195] = I("俹垶墰憌", "eLoCq");
      I[56 ^ 76] = I("\u0010\r) c\u0001\u000b-5&*\r-9c", "cyHTM");
      I[120 ^ 13] = I("冤樴懷剾", "Heivl");
      I[4 ^ 114] = I("崌扫", "RcZhr");
      I[14 ^ 121] = I("\u0006\u001b'\u001b`\u0017\u001d#\u000e%<\u001b#\u0002", "uoFoN");
      I[225 ^ 153] = I("媴愎", "zYdqK");
      I[239 ^ 150] = I("掷榓", "ybhPj");
      I[196 ^ 190] = I("底煊拱", "SeBiV");
      I[5 ^ 126] = I("垹慝", "FIoRH");
      I[213 ^ 169] = I("凁圴", "RLQjT");
      I[87 ^ 42] = I("氧氃", "IYHDP");
      I[78 ^ 48] = I("啗咲", "lzsRU");
      I[106 + 108 - 151 + 64] = I("喊幑", "DkKnZ");
      I[62 + 22 - -30 + 14] = I("棹煿", "pLmkj");
      I[69 + 48 - 23 + 35] = I("孩娄", "DjVrp");
      I[128 + 17 - 58 + 43] = I("囻椳", "hOcxW");
      I[104 + 26 - 81 + 82] = I("勫万", "kNRAS");
      I[86 + 30 - 12 + 28] = I("氣樱", "YQYhT");
      I[130 + 119 - 164 + 48] = I("凣浛", "hzdRB");
      I[89 + 54 - 107 + 98] = I("叠楄", "kJoCK");
      I[70 + 131 - 81 + 15] = I("涤忪", "qxFHi");
      I[3 + 93 - -23 + 17] = I("娭湰", "dIvIM");
      I[13 + 125 - 83 + 82] = I("栰寑", "FIMvP");
      I[133 + 57 - 108 + 56] = I("挄儯", "SkQru");
      I[27 + 78 - -7 + 27] = I("可滱", "mCTwb");
      I[109 + 88 - 181 + 124] = I("壠佰", "ujfeR");
      I[14 + 29 - -70 + 28] = I("傇制", "NfFwW");
      I[124 + 126 - 221 + 113] = I("晁呜", "FUOQZ");
      I[0 + 23 - -6 + 114] = I("妮嗶", "rWHxe");
      I[129 + 40 - 140 + 115] = I("垢剓", "JTWFq");
      I[127 + 51 - 83 + 50] = I("彩嗅", "EebCp");
      I[65 + 16 - 75 + 140] = I("最溠", "hweZA");
      I[76 + 15 - -28 + 28] = I("沋檼", "Tdzzt");
      I[40 + 1 - -59 + 48] = I("懴兤", "bEHgi");
      I[18 + 30 - 2 + 103] = I("埜垌", "cxUJh");
      I[141 + 52 - 171 + 128] = I("啽樷", "CjLBg");
      I[87 + 107 - 106 + 63] = I("惍淑", "uHEiz");
      I[140 + 102 - 219 + 129] = I("懤掕", "mdZqp");
      I[14 + 71 - -8 + 60] = I("灔撰", "FPtGi");
      I[104 + 61 - 25 + 14] = I("槔榖", "krCar");
      I[25 + 131 - 86 + 85] = I("昦泲", "elVqr");
      I[120 + 2 - 121 + 155] = I("卵掬嵉悒", "ytTTp");
      I[95 + 2 - -55 + 5] = I("慿呰奠", "pxJat");
      I[134 + 105 - 178 + 97] = I("; ,1]8=..\u00068z", "HTMEs");
      I[19 + 78 - 58 + 120] = I("椒埊冻", "AgZLD");
      I[58 + 21 - -67 + 14] = I("壥凴嵲昇炝", "lMdtW");
      I[4 + 134 - 43 + 66] = I("\u001f\"#<v\u001c?!#-\u001c", "lVBHX");
      I[129 + 134 - 167 + 66] = I("帰吖樏忺巒", "IZMGg");
      I[114 + 21 - 80 + 108] = I("屡幐擩树去", "JuXjg");
      I[27 + 30 - -20 + 87] = I("歀妃", "wRwav");
      I[140 + 102 - 220 + 143] = I("忷愙従忩嵈", "RKiGp");
      I[58 + 149 - 91 + 50] = I("扪", "smWqy");
      I[80 + 87 - 137 + 137] = I("泰凌刏壟彖", "xqUXF");
      I[44 + 13 - -56 + 55] = I("儋吴擑兛刨", "nNswX");
      I[115 + 54 - 160 + 160] = I("慏", "JYRcu");
      I[16 + 120 - -25 + 9] = I("\u0014&5\u001bm\u0003 ;\u001fm", "gRToC");
      I[47 + 20 - -71 + 33] = I("提", "dSKrE");
      I[88 + 62 - 9 + 31] = I("巹", "UfgxN");
      I[0 + 149 - 22 + 46] = I("\u0018\u001e#\u001a~\u000f\u0018-\u001e", "kjBnP");
      I[82 + 52 - 104 + 144] = I("濠", "bPfAk");
      I[18 + 96 - -26 + 35] = I("橖昙拊沁崅", "pkYnF");
      I[43 + 8 - -119 + 6] = I("煐槇徜", "pHTdG");
      I[139 + 66 - 120 + 92] = I("烥敲氂唠厈", "VtQHV");
      I[2 + 67 - -51 + 58] = I("攚丶倢", "IZFdJ");
      I[122 + 149 - 188 + 96] = I("剺塻杼", "Rithv");
      I[103 + 68 - 22 + 31] = I("徯夊沞柇佄", "UKlPZ");
      I[167 + 1 - 59 + 72] = I("墐悽傛", "tOByd");
      I[114 + 114 - 143 + 97] = I("壣啣傋殣椭", "HCKas");
      I[21 + 67 - 38 + 133] = I("榒恀", "RebRO");
      I[141 + 178 - 274 + 139] = I("橤挈", "gXUDZ");
      I[114 + 93 - 103 + 81] = I("惎挫", "yERhX");
      I[114 + 104 - 52 + 20] = I("忯咽", "GVpyu");
      I[118 + 3 - 108 + 174] = I("廣灘", "cPlwy");
      I[87 + 141 - 131 + 91] = I("即曫", "CoWiz");
      I[8 + 169 - 108 + 120] = I("俤敺", "HXrud");
      I[185 + 3 - 14 + 16] = I("壐楌", "JfLAq");
      I[136 + 79 - 174 + 150] = I("怪温", "JdzYu");
      I[128 + 167 - 233 + 130] = I("庐宓", "FEglb");
      I[93 + 42 - 100 + 158] = I("瀉低", "NGLPT");
      I[50 + 39 - -29 + 76] = I("劲拋", "MJTTp");
      I[85 + 130 - 209 + 189] = I("傋捬", "tdFYR");
      I[81 + 120 - 72 + 67] = I("愴樐", "jMeoa");
      I[63 + 138 - 96 + 92] = I("押妮", "swzMm");
      I[172 + 145 - 268 + 149] = I("侽户", "SAARq");
      I[113 + 97 - 125 + 114] = I("塘夈", "JhKJX");
      I[100 + 136 - 78 + 42] = I("卧樐", "umdXp");
      I[199 + 162 - 324 + 164] = I("昲渼", "AjGym");
      I[74 + 35 - -1 + 92] = I("嘣敦", "saTGf");
      I[153 + 54 - 91 + 87] = I("了幃", "MeqiJ");
      I[191 + 17 - 30 + 26] = I("尤厪", "TVuyo");
      I[129 + 43 - 31 + 64] = I("廀卹", "ZEvQi");
      I[27 + 120 - 1 + 60] = I("淨斤", "mdgZs");
      I[51 + 158 - 134 + 132] = I("凔浭", "SpaJO");
      I[116 + 103 - 118 + 107] = I("殊嬈", "noWph");
      I[167 + 207 - 350 + 185] = I("捝愺", "utUzP");
      I[67 + 48 - -29 + 66] = I("婗劔択棴", "mbNkP");
      I[83 + 156 - 211 + 183] = I("孂梃源", "Yrmmt");
      I[19 + 18 - -9 + 166] = I("煿忑渙兖涔", "jHKoZ");
      I[161 + 57 - 77 + 72] = I("气渡尨侎寕", "hrkSq");
      I[57 + 195 - 137 + 99] = I("崭剈奬乢咾", "XAfUR");
      I[139 + 1 - 98 + 173] = I("扐", "AOAsc");
      I[60 + 206 - 128 + 78] = I("\u001f8#6@\u0007%..+\u00028+6\u0017B", "lLBBn");
      I[11 + 50 - -1 + 155] = I("槯擋印", "xCjvK");
      I[28 + 47 - -68 + 75] = I("喑婟售報", "RpqgN");
      I[24 + 22 - -161 + 12] = I("斅汲彑", "pJSTf");
      I[183 + 130 - 181 + 88] = I("!\u0019\u0012:{7\u0003\u0007'!+&\u001a\"9", "RmsNU");
      I[203 + 163 - 277 + 132] = I("洳朱", "pHSJZ");
      I[83 + 149 - 67 + 57] = I("勋欞廞冴搖", "rnkCY");
      I[164 + 139 - 145 + 65] = I("櫠", "bfSfP");
      I[195 + 220 - 358 + 167] = I("榖供橍教", "pWDGa");
      I[14 + 147 - 140 + 204] = I("弩体婒坓擤", "dmzgL");
      I[146 + 211 - 147 + 16] = I("堷擃", "dlZQh");
      I[4 + 195 - 150 + 178] = I("\u0015$\u0010!3\td", "pJdHG");
      I[211 + 2 - 104 + 119] = I("L\r\u0003>)", "bcbSL");
      I[0 + 38 - -80 + 111] = I("棥叮", "napsS");
      I[49 + 185 - 107 + 103] = I("戞倽", "ZDdyi");
      I[92 + 188 - 159 + 110] = I("债栏", "UWbmb");
      I[80 + 17 - 86 + 221] = I("戋埗", "RekJC");
      I[184 + 182 - 246 + 113] = I("吚崾", "cKTJi");
      I[107 + 85 - 80 + 122] = I("戣恂", "CivBE");
      I[176 + 34 - 61 + 86] = I("啔嘖", "IArHn");
      I[120 + 139 - 55 + 32] = I("廌匬", "PRhwb");
      I[201 + 178 - 370 + 228] = I("卑姂", "tpiHE");
      I[220 + 126 - 175 + 67] = I("恪晙", "IhWRU");
      I[5 + 207 - 56 + 83] = I("挿杔", "OBYiL");
      I[119 + 62 - 132 + 191] = I("杈氊", "SdmBt");
      I[40 + 194 - 86 + 93] = I("溒槥", "BxGme");
      I[63 + 216 - 70 + 33] = I("斪儗", "PmSQD");
      I[31 + 182 - 141 + 171] = I("僔扷", "xTtcm");
      I[170 + 176 - 268 + 166] = I("棖代", "MmBUG");
      I[181 + 22 - 139 + 181] = I("廟斟", "NlSFC");
      I[144 + 120 - 124 + 106] = I("州崲", "mOeqB");
      I[141 + 193 - 258 + 171] = I("妬烖", "jyWPb");
      I[100 + 151 - 50 + 47] = I("报影", "sMOUh");
      I[44 + 151 - 6 + 60] = I("榅卢", "marVc");
      I[109 + 170 - 122 + 93] = I("準姥", "vLBhx");
      I[142 + 215 - 155 + 49] = I("姣坼", "sABwQ");
      I[177 + 213 - 373 + 235] = I("寺榒", "DJaLe");
      I[148 + 194 - 321 + 232] = I("奞帯", "ElPNa");
      I[118 + 123 - 221 + 234] = I("樃滖桖嵽", "mAXxc");
      I[23 + 15 - -141 + 76] = I("忶湭懒丶傎", "eXzbR");
      I[180 + 58 - 111 + 129] = I("弇塾兩囹忨", "xnKBb");
      I[103 + 132 - 139 + 161] = I("暋愰", "kEStD");
      I[135 + 38 - 94 + 179] = I("栒恍尲劸", "PrKtV");
      I[52 + 238 - 185 + 154] = I("儌漓", "HqksT");
      I[30 + 170 - 99 + 159] = I("曐", "aFxYI");
      I[222 + 179 - 248 + 108] = I(":\u001d\u0016!c,\u0007\u0003<90\"\u001e9!,\r5,c", "IiwUM");
      I[43 + 97 - -52 + 70] = I("泿侓漄", "eMWRi");
      I[177 + 51 - 215 + 250] = I("\u001c&\u0003.y\n<\u00163#\u0016\u0019\u000b6;\n6 #", "oRbZW");
      I[100 + 245 - 85 + 4] = I("丘", "Vlktb");
      I[93 + 37 - 123 + 258] = I("岬尉浡剅", "fMKDn");
      I[29 + 21 - -32 + 184] = I("抃寍槽", "xCaJF");
      I[151 + 187 - 144 + 73] = I("哑咴", "QZmDT");
      I[121 + 154 - 249 + 242] = I("桔烷", "ZEirK");
      I[241 + 129 - 199 + 98] = I("戒坹揚", "sdAIK");
      I[231 + 265 - 356 + 130] = I("姣", "ZTVoN");
      I[37 + 88 - -116 + 30] = I("冑溩", "RVKeX");
      I[33 + 91 - -134 + 14] = I("唈唋峕", "zqxcF");
      I[99 + 87 - 78 + 165] = I(",\u0003\u0012\u0007\u00120C", "Imfnf");
      I[149 + 19 - -46 + 60] = I("O\u0002;%<", "alZHY");
      I[114 + 187 - 93 + 67] = I("? .>| 1.<7\u000b5\"/", "LTOJR");
      I[62 + 44 - -157 + 13] = I("\u0011&\u0003\"j\u000e7\u0003 !%3\u000f3", "bRbVD");
      I[72 + 232 - 133 + 106] = I("\u001c\u001b1%y\u001f\u00031(\u0018\u0001\n\u001d89\u001a\u001b5", "ooPQW");
      I[237 + 113 - 150 + 78] = I("%\u0006\b5m&\u001e\b8\f8\u0017$(-#\u0006\f", "VriAC");
      I[217 + 157 - 359 + 264] = I(")?;\u001a[.\"7\u000b&3%9\u000b1?*.\u0006", "ZKZnu");
      I[146 + 256 - 332 + 210] = I("\u0016\u000e6\u0016A\u0011\u0013:\u0007<\f\u00144\u0007+\u0000\u001b#\n", "ezWbo");
      I[267 + 178 - 436 + 272] = I("1\u001e-$]1\u0004)1\u0018\u0016\u0003!5", "BjLPs");
      I[150 + 22 - 43 + 153] = I("\u0017\u000e-\u0000Y\u0017\u0014)\u0015\u001c0\u0013!\u0011", "dzLtw");
      I[28 + 251 - 278 + 282] = I("51\u0019\u0003H1$\u0014\u001c)( ;\u001a", "FExwf");
      I[232 + 246 - 413 + 219] = I("\u0003\u001b\b\u0010}\u0007\u000e\u0005\u000f\u001c\u001e\n*\t", "poidS");
      I[214 + 59 - 7 + 19] = I("'\u0018\u0019\u0018Z7\u001e\u0017\u0019\u0017<#\u0016\t79", "Tlxlt");
      I[159 + 255 - 406 + 278] = I(")\u0007\f;w9\u0001\u0002::2<\u0003*\u001a7", "ZsmOY");
      I[13 + 173 - 39 + 140] = I(" \u0016\u00136] \u0012\u0000+\u001d'-\u001c'0>", "SbrBs");
      I[110 + 66 - 4 + 116] = I("\u0000\u0019;\u0019C\u0000\u001d(\u0004\u0003\u0007\"4\b.\u001e", "smZmm");
      I[222 + 277 - 309 + 99] = I("!=-\u001e_!>%\u0007><,\u000f\u0007", "RILjq");
      I[144 + 240 - 203 + 109] = I("<\u0018\u0013\u001d]<\u001b\u001b\u0004<!\t1\u0004", "Olris");
      I[31 + 84 - -75 + 101] = I("\n\u0015+\u0002]\u001f\u0000&\u001a<\u0017\u0004\t\u001b", "yaJvs");
      I[112 + 114 - 94 + 160] = I("$<\u0006\u001df1)\u000b\u0005\u00079-$\u0004", "WHgiH");
      I[103 + 47 - 96 + 239] = I("\u0015\u00108\u001dY\u0005\b0\u0004\u0015)\n<*\u001a", "fdYiw");
      I[206 + 169 - 303 + 222] = I("\u0011\r\u0017\u001f|\u0001\u0015\u001f\u00060-\u0017\u0013(?", "byvkR");
      I[259 + 7 - 129 + 158] = I("4\u00022\u0019K!\u001a*\"\u000b\"5>", "GvSme");
      I[251 + 135 - 356 + 266] = I("\n\u0013\u0012-C\u001f\u000b\n\u0016\u0003\u001c$\u001e", "ygsYm");
      I[38 + 103 - 12 + 168] = I("+\u001877{<\u0005 &\u001a6\t\u0015.", "XlVCU");
      I[89 + 149 - 28 + 88] = I("\t\u001d\",~\u001e\u00005=\u001f\u0014\f\u00005", "ziCXP");
      I[50 + 27 - -110 + 112] = I("*=\u0007'O4 \b6\u00028;\u0012\u001c\u000f<\n\u000b", "YIfSa");
      I[93 + 200 - 72 + 79] = I("+\u0013,=c5\u000e#,.9\u00159\u0006#=$ ", "XgMIM");
      I[216 + 106 - 246 + 225] = I("\u000b3\u000f W\u001a(\u000f 6\u0016\"-9", "xGnTy");
      I[286 + 109 - 318 + 225] = I("'$0$E6?0$$:5\u0012=", "TPQPk");
      I[62 + 34 - -80 + 127] = I("\u00020$\rT\u0001-\"6\u0014\u0014\u0007(", "qDEyz");
      I[62 + 266 - 92 + 68] = I("%\u00007\u001ax&\u001d1!837;", "VtVnV");
      I[14 + 268 - 254 + 277] = I("\u0017<\u0019 [\f'\n'\u0010+&\u001d\u0017\u0018", "dHxTu");
      I[35 + 134 - -2 + 135] = I("\u0007\"(\u0012i\u001c9;\u0015\";8,%*", "tVIfG");
      I[268 + 106 - 197 + 130] = I("\u0016<2\u0001^\u0004>:\u0014\u0004\u0000\u0007=\u00103\b", "eHSup");
      I[225 + 184 - 340 + 239] = I("!\u001e%\"Y3\u001c-7\u00037%*34?", "RjDVw");
      I[156 + 306 - 206 + 53] = I(";=\"7D\"<.3", "HICCj");
      I[10 + 132 - -154 + 14] = I("+<(\u001e|2=$\u001a", "XHIjR");
      I[24 + 210 - 5 + 82] = I("\u0019\u0015\u0011$x\u000e\u0013\u001f ", "japPV");
      I[186 + 286 - 403 + 243] = I("#\u0012\u0002\u0006V4\u0014\f\u0002", "Pfcrx");
      I[61 + 106 - -75 + 71] = I("\u0002\u0011\u0011-j\u0015\u0004\u001d8#\u0014!\u00158(\u0005", "qepYD");
      I[58 + 95 - -155 + 6] = I("?!\f\u0017m(4\u0000\u0002$)\u0011\b\u0002/8", "LUmcC");
      I[169 + 278 - 324 + 192] = I("!5\u0006;Y6 \n.\u00107\u0015\u0006$\u0012<", "RAgOw");
      I[135 + 173 - 116 + 124] = I("%\r9#o2\u001856&3-9<$8", "VyXWA");
      I[20 + 205 - -92 + 0] = I("\u001d05>c\n!5>%\u001d", "nDTJM");
      I[55 + 59 - -170 + 34] = I("\u0017\u00049!e\u0000\u00159!#\u0017", "dpXUK");
      I[128 + 71 - 22 + 142] = I("\u0016> \u0003`\b%#<'\t&2", "eJAwN");
      I[78 + 266 - 44 + 20] = I("\t\u001f\u0012\u0017Y\u0017\u0004\u0011(\u001e\u0016\u0007\u0000", "zkscw");
      I[271 + 201 - 244 + 93] = I("08\"\rB\"\"*\u0014\r/?\u0001\u000b\t'", "CLCyl");
      I[192 + 150 - 326 + 306] = I("%\u0007\u0000\u0003j7\u001d\b\u001a%:\u0000#\u0005!2", "VsawD");
      I[67 + 163 - 96 + 189] = I("7\u000e\"\u001bt4\u0016\"\u0016?61*\u000367", "DzCoZ");
      I[318 + 59 - 158 + 105] = I("\u001a:\u0018\fw\u0019\"\u0018\u0001<\u001b\u0005\u0010\u00145\u001a", "iNyxY");
      I[245 + 309 - 261 + 32] = I("\u00190\t5|\f-\u001b)\u0011\u000b1\u000f)&", "jDhAR");
      I[114 + 194 - 54 + 72] = I("\u0005&)\u001cB\u0010;;\u0000/\u0017'/\u0000\u0018", "vRHhl");
      I[15 + 55 - -229 + 28] = I("\u00037,\rF\u0004\"!\u0012\r\u0014\u0017\"/\u0001\u001c/,\u001e\r\u0002", "pCMyh");
      I[98 + 236 - 130 + 124] = I("\u001c0& Z\u001b%+?\u0011\u000b\u0010(\u0002\u001d\u0003(&3\u0011\u001d", "oDGTt");
      I[77 + 319 - 264 + 197] = I("\n\u0015-\u0005J\r\u0013-\u0015\u0001\u001d6%\u0005\f/\b \u001d\u0005\u001e\u0004>", "yaLqd");
      I[133 + 245 - 66 + 18] = I("8\u0001\f\u0018Z?\u0007\f\b\u0011/\"\u0004\u0018\u001c\u001d\u001c\u0001\u0000\u0015,\u0010\u001f", "Kumlt");
      I[85 + 128 - 68 + 186] = I(">\u0002;\u001aj.\u00171\u000b\u0017!\u001f9\u000b7\b\u0017.\u000b*", "MvZnD");
      I[320 + 287 - 483 + 208] = I("\u001d\u001d,&a\r\b&7\u001c\u0002\u0000.7<+\b97!", "niMRO");
      I[229 + 100 - 113 + 117] = I("9#\u0003.G)6\u00176\r88\f\u001c\u0000&;\u0007>", "JWbZi");
      I[43 + 84 - 111 + 318] = I("\u001b\u00198;T\u000b\f,#\u001e\u001a\u00027\t\u0013\u0004\u0001<+", "hmYOz");
      I[40 + 44 - -180 + 71] = I("\u0011.\"\f^\u0001;6\u0014\u0014\u00105--\u0003\u0007>", "bZCxp");
      I[185 + 262 - 315 + 204] = I("\u0007\u001e\u0003;h\u0017\u000b\u0017#\"\u0006\u0005\f\u001a5\u0011\u000e", "tjbOF");
      I[295 + 313 - 512 + 241] = I("?\u0013\u000b\rC-\u0015\u0007\u0016\u001f\u000f\u000b\u000f\u0018\u0003)\u0003", "Lgjym");
      I[42 + 336 - 223 + 183] = I("7;7\u001da%=;\u0006=\u0007#3\b!!+", "DOViO");
      I[327 + 210 - 451 + 253] = I("\u0001\u0019/\u0017H\u0010\f \r\u0003\u0000.\"\u0006\u0007\u001c\b*", "rmNcf");
      I[318 + 90 - 106 + 38] = I("\u0014\u0003\u00109~\u0005\u0016\u001f#5\u00154\u001d(1\t\u0012\u0015", "gwqMP");
      I[16 + 46 - -91 + 188] = I("\u000b\u0018\u0005\rT\u001a\u001e\u0001\u000e\u0013\u0016\u000b\u0017\r\u001b\u0016\b-\u0017\u000e\u001d\u001e\u0005\u001a\u000e\u0011\u0003\n", "xldyz");
      I[96 + 275 - 321 + 292] = I("2\u0015\u0002\u001aG#\u0013\u0006\u0019\u0000/\u0006\u0010\u001a\b/\u0005*\u0000\u001d$\u0013\u0002\r\u001d(\u000e\r", "Aacni");
      I[193 + 300 - 282 + 132] = I("4\u0011\u000f\u001bl%\u0000\u000f\f-),\u0000\u001b'5\u0004\r\u001b+(\u000b", "GenoB");
      I[288 + 29 - 171 + 198] = I("\n:#1v\u001b+#&7\u0017\u0007,1=\u000b/!11\u0016 ", "yNBEX");
      I[57 + 119 - 91 + 260] = I("!\u001d$\u0000l6\u001b*\u000427\u001b\f\u001a1\"\f&\u0000'6", "RiEtB");
      I[244 + 200 - 385 + 287] = I("\u001b\u00168\u0016l\f\u00106\u00122\r\u0010\u0010\f1\u0018\u0007:\u0016'\f", "hbYbB");
      I[126 + 311 - 308 + 218] = I("\u0015>\b:J\u000e%\u0019>\u0001\u0014\u0003\u0007=\u0014\u0003)\u001d+\u0000", "fJiNd");
      I[309 + 339 - 551 + 251] = I("\u001b\u0018\u000f;~\u0000\u0003\u001e?5\u001a%\u0000< \r\u000f\u001a*4", "hlnOP");
      I[307 + 289 - 461 + 214] = I("\u0000\u001a4\"x\u0017\u0007&&3\u001d\u001d0$\u001f\u001d\u001d%35\u0007\u000b1", "snUVV");
      I[191 + 344 - 496 + 311] = I("\u0010\u001e\u0017=H\u0007\u0003\u00059\u0003\r\u0019\u0013;/\r\u0019\u0006,\u0005\u0017\u000f\u0012", "cjvIf");
      I[232 + 146 - 304 + 277] = I(";\u0017\u0002-j&\f\u0017<&$\f\u00002\u0014$\u0002\u001a< ", "HccYD");
      I[155 + 325 - 341 + 213] = I("%\u0013\u001b1E8\b\u000e \t:\b\u0019.;:\u0006\u0003 \u000f", "VgzEk");
      I[352 + 93 - 192 + 100] = I("\u0012\u00070;L\u000f\u001c%*\u0000\r\u001c2$6\u0014\u001d4+", "asQOb");
      I[203 + 257 - 262 + 156] = I("\u0006,/:h\u001b7:+$\u00197-%\u0012\u00006+*", "uXNNF");
      I[39 + 136 - -39 + 141] = I("\u0010\u0005)?F\u0005\u001d'<\r\u0011!'?\u001c\u0006\u0015", "cqHKh");
      I[325 + 150 - 177 + 58] = I(";>65V.&86\u001d:\u001a85\f-.", "HJWAx");
      I[233 + 106 - 175 + 193] = I("%-\u0004\u0017^\"+\u0004\u0013\u00003=&\u000b\u0015%-1\u0011\u00191>\u0000\u0011\u00152", "VYecp");
      I[341 + 282 - 386 + 121] = I("#>\u0017\u0007B$8\u0017\u0003\u001c5.5\u001b\t#>\"\u0001\u00057-\u0013\u0001\t4", "PJvsl");
      I[185 + 282 - 284 + 176] = I("\u0011-7\u0000X\u000772\u0011\u0004\u000113\u0007\u0002-)3\u001a\u0013\u0006", "bYVtv");
      I[157 + 31 - -13 + 159] = I("0.\u0006\u001eH&4\u0003\u000f\u0014 2\u0002\u0019\u0012\f*\u0002\u0004\u0003'", "CZgjf");
      I[17 + 274 - 275 + 345] = I("8#81A\"#<(*%41$\u0001?2=", "KWYEo");
      I[266 + 348 - 472 + 220] = I(":\u0019\u00039~ \u0019\u0007 \u0015'\u000e\n,>=\b\u0006", "ImbMP");
      I[246 + 208 - 218 + 127] = I("\u0017\u001e/5h\u0016\u000f-.4\u0000:\" ?\u0001\u000e", "djNAF");
      I[362 + 154 - 216 + 64] = I(":\u0019\u0002\u001c];\b\u0000\u0007\u0001-=\u000f\t\n,\t", "Imchs");
      I[356 + 345 - 412 + 76] = I("\u001d;\"\u0010o\b:1\n \r*\n\n5\u000b=\"\u00075\u0007 -", "nOCdA");
      I[152 + 203 - 159 + 170] = I("\u0010<0\u001bX\u0005=#\u0001\u0017\u0000-\u0018\u0001\u0002\u0006:0\f\u0002\n'?", "cHQov");
      I[139 + 43 - 77 + 262] = I("\u0012#\n\u001b\\\u0002%\n\t\u0006\b9\f;\u0013\u0003;\u000e&\u001c\u00152\u0019\u000e\u0011\u0015>\u0004\u0001", "aWkor");
      I[255 + 108 - 79 + 84] = I("+\u0001\u000f2V/\u001a\u001c-\u001a=\u001b\r.16\u0001\u000b4\u0019;\u0001\u0007)\u0016", "XunFx");
      I[108 + 115 - -142 + 4] = I("\u001f\u0019\u00190~\u000f\u0005\u001d7$#\u001d\u001d*5\b", "lmxDP");
      I[182 + 267 - 298 + 219] = I("\u0001\u001a\u001b0b\u0011\u0006\u001f78=\u001e\u001f*)\u0016", "rnzDL");
      I[133 + 352 - 447 + 333] = I("\u0004\u0001\u0010\u0004~\u0004\u0019\u0014\u0015 >\u001b3\u00154", "wuqpP");
      I[110 + 268 - 347 + 341] = I("4\u001b%\u001f_4\u0003!\u000e\u0001\u000e\u0001\u0006\u000e\u0015", "GoDkq");
      I[29 + 137 - -34 + 173] = I("\u0005\u001a\u0004\u001dT\u0005\u0006\u0010\u0005\u0011\u0013\u001c'\u0006\u00029\u001e\u0000\u0007\u001f\u0012", "vneiz");
      I[323 + 294 - 613 + 370] = I("\u0017.\u0000\u000ex\u00172\u0014\u0016=\u0001(#\u0015.+*\u0004\u00143\u0000", "dZazV");
   }

   private static String getItemName(Item var0) {
      ResourceLocation var1 = (ResourceLocation)Item.REGISTRY.getNameForObject(var0);
      String var10000;
      if (var1 != null) {
         var10000 = var1.toString().replace((char)('½' ^ '\u0087'), (char)('Z' ^ 't'));
         "".length();
         if (0 == 4) {
            throw null;
         }
      } else {
         var10000 = null;
      }

      return var10000;
   }
}

package net.minecraft.block;

import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
import net.minecraft.dispenser.IBehaviorDispenseItem;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityDropper;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockDropper extends BlockDispenser {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final IBehaviorDispenseItem dropBehavior = new BehaviorDefaultDispenseItem();

   private static void I() {
      I = new String[113 ^ 127];
      I["".length()] = I("宣儚", "tBxXf");
      I[" ".length()] = I("弼乴", "xRkGo");
      I["  ".length()] = I("抩扩", "qmbeF");
      I["   ".length()] = I("捳池", "lVhWk");
      I[19 ^ 23] = I("埯桫壗槄", "IKZcK");
      I[133 ^ 128] = I("崄少厊", "CeQDl");
      I[90 ^ 92] = I("形嘪浛潡塊", "BZssS");
      I[21 ^ 18] = I("汹嘓", "UIAPr");
      I[0 ^ 8] = I("屢栄", "YkIBB");
      I[40 ^ 33] = I("奱堔", "lvJBO");
      I[50 ^ 56] = I("搼杭", "VRCew");
      I[10 ^ 1] = I("欆思帣敗搲", "SbIBI");
      I[7 ^ 11] = I("埵汊毀暻", "FCnhJ");
      I[78 ^ 67] = I("仧啽信煲", "vpXZj");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 3);

      throw null;
   }

   static {
      I();
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[105 ^ 109].length();
      I[166 ^ 163].length();
      I[167 ^ 161].length();
      return new TileEntityDropper();
   }

   protected IBehaviorDispenseItem getBehavior(ItemStack var1) {
      return this.dropBehavior;
   }

   protected void dispense(World var1, BlockPos var2) {
      String var10000 = I[132 ^ 131];
      String var10001 = I[141 ^ 133];
      String var10002 = I[144 ^ 153];
      var10001 = I[70 ^ 76];
      I[207 ^ 196].length();
      I[138 ^ 134].length();
      I[68 ^ 73].length();
      BlockSourceImpl var3 = new BlockSourceImpl(var1, var2);
      TileEntityDispenser var4 = (TileEntityDispenser)var3.getBlockTileEntity();
      if (var4 != null) {
         int var5 = var4.getDispenseSlot();
         if (var5 < 0) {
            var1.playEvent(400 + 16 - -513 + 72, var2, "".length());
            "".length();
            if (4 < 1) {
               throw null;
            }
         } else {
            ItemStack var6 = var4.getStackInSlot(var5);
            if (!var6.isEmpty()) {
               EnumFacing var7 = (EnumFacing)var1.getBlockState(var2).getValue(FACING);
               BlockPos var8 = var2.offset(var7);
               IInventory var9 = TileEntityHopper.getInventoryAtPosition(var1, (double)var8.getX(), (double)var8.getY(), (double)var8.getZ());
               ItemStack var10;
               if (var9 == null) {
                  var10 = this.dropBehavior.dispense(var3, var6);
                  "".length();
                  if (3 >= 4) {
                     throw null;
                  }
               } else {
                  var10 = TileEntityHopper.putStackInInventoryAllSlots(var4, var9, var6.copy().splitStack(" ".length()), var7.getOpposite());
                  if (var10.isEmpty()) {
                     var10 = var6.copy();
                     var10.func_190918_g(" ".length());
                     "".length();
                     if (3 <= -1) {
                        throw null;
                     }
                  } else {
                     var10 = var6.copy();
                  }
               }

               var4.setInventorySlotContents(var5, var10);
            }
         }
      }

   }
}

package net.minecraft.stats;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.play.server.SPacketRecipeBook;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RecipeBookServer extends RecipeBook {
   // $FF: synthetic field
   private static final Logger field_192828_d;
   // $FF: synthetic field
   private static final String[] I;

   public NBTTagCompound func_192824_e() {
      String var10000 = I[73 ^ 66];
      String var10001 = I[172 ^ 160];
      String var10002 = I[167 ^ 170];
      var10001 = I[104 ^ 102];
      var10000 = I[127 ^ 112];
      var10001 = I[171 ^ 187];
      var10002 = I[173 ^ 188];
      var10001 = I[99 ^ 113];
      var10000 = I[5 ^ 22];
      var10001 = I[61 ^ 41];
      var10002 = I[66 ^ 87];
      var10001 = I[26 ^ 12];
      var10000 = I[139 ^ 156];
      var10001 = I[154 ^ 130];
      var10002 = I[35 ^ 58];
      var10001 = I[138 ^ 144];
      var10000 = I[223 ^ 196];
      var10001 = I[153 ^ 133];
      var10002 = I[191 ^ 162];
      var10001 = I[172 ^ 178];
      I[154 ^ 133].length();
      I[148 ^ 180].length();
      I[46 ^ 15].length();
      NBTTagCompound var1 = new NBTTagCompound();
      var1.setBoolean(I[111 ^ 77], this.field_192818_b);
      var1.setBoolean(I[16 ^ 51], this.field_192819_c);
      I[71 ^ 99].length();
      I[22 ^ 51].length();
      I[1 ^ 39].length();
      I[123 ^ 92].length();
      I[173 ^ 133].length();
      NBTTagList var2 = new NBTTagList();
      Iterator var3 = this.func_194079_d().iterator();

      do {
         if (!var3.hasNext()) {
            var1.setTag(I[149 ^ 184], var2);
            I[1 ^ 47].length();
            I[12 ^ 35].length();
            I[135 ^ 183].length();
            NBTTagList var6 = new NBTTagList();
            Iterator var7 = this.func_194080_e().iterator();

            do {
               if (!var7.hasNext()) {
                  var1.setTag(I[121 ^ 75], var6);
                  return var1;
               }

               IRecipe var5 = (IRecipe)var7.next();
               I[135 ^ 182].length();
               var6.appendTag(new NBTTagString(((ResourceLocation)CraftingManager.field_193380_a.getNameForObject(var5)).toString()));
               "".length();
            } while(4 != 0);

            throw null;
         }

         IRecipe var4 = (IRecipe)var3.next();
         I[94 ^ 119].length();
         I[124 ^ 86].length();
         I[69 ^ 110].length();
         I[170 ^ 134].length();
         var2.appendTag(new NBTTagString(((ResourceLocation)CraftingManager.field_193380_a.getNameForObject(var4)).toString()));
         "".length();
      } while(3 != 1);

      throw null;
   }

   public void func_192826_c(EntityPlayerMP var1) {
      String var10000 = I[136 ^ 194];
      String var10001 = I[203 ^ 128];
      String var10002 = I[117 ^ 57];
      var10001 = I[3 ^ 78];
      NetHandlerPlayServer var2 = var1.connection;
      I[225 ^ 175].length();
      I[120 ^ 55].length();
      var2.sendPacket(new SPacketRecipeBook(SPacketRecipeBook.State.INIT, this.func_194079_d(), this.func_194080_e(), this.field_192818_b, this.field_192819_c));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 >= 1);

      throw null;
   }

   private static void I() {
      I = new String[145 ^ 193];
      I["".length()] = I("剝帬炫泐", "OhyhT");
      I[" ".length()] = I("摊溴傐毂", "PJgwF");
      I["  ".length()] = I("剿国宰厺榅", "lVDDw");
      I["   ".length()] = I("啰妑泞暴煆", "cbJEN");
      I[67 ^ 71] = I("様巺寣攢型", "vflgm");
      I[49 ^ 52] = I("娸勦", "PZABh");
      I[1 ^ 7] = I("徜侯", "afzwk");
      I[128 ^ 135] = I("朓嚁", "VWLZO");
      I[116 ^ 124] = I("帰沌", "esbPc");
      I[171 ^ 162] = I("井奼夯枚", "meVpm");
      I[146 ^ 152] = I("沷斥", "otNkB");
      I[191 ^ 180] = I("桴唋", "nbMvy");
      I[31 ^ 19] = I("摥哿", "HTKWP");
      I[110 ^ 99] = I("嗬掔", "gRVrL");
      I[53 ^ 59] = I("澑漤", "PILxq");
      I[180 ^ 187] = I("廜濚", "lLDWf");
      I[156 ^ 140] = I("吉媯", "UpIKC");
      I[67 ^ 82] = I("棷崣", "gVJWo");
      I[155 ^ 137] = I("抶殸", "zKlUI");
      I[166 ^ 181] = I("巁廯", "IarmU");
      I[9 ^ 29] = I("崛峮", "tffWp");
      I[179 ^ 166] = I("榻柙", "KhsBl");
      I[137 ^ 159] = I("巈沾", "qxwie");
      I[147 ^ 132] = I("俸憛", "EnCSc");
      I[110 ^ 118] = I("催擒", "PzucA");
      I[149 ^ 140] = I("歏侯", "kCwkL");
      I[84 ^ 78] = I("冖且", "fGxkx");
      I[83 ^ 72] = I("斫崊", "rDkUT");
      I[11 ^ 23] = I("旽埠", "ydUgh");
      I[100 ^ 121] = I("涒柿", "qKrrr");
      I[25 ^ 7] = I("嘎媓", "mtbRP");
      I[103 ^ 120] = I("厶媦淼濇", "Qjclv");
      I[13 ^ 45] = I("夶冘", "BfzIP");
      I[112 ^ 81] = I("伟", "KsJJj");
      I[185 ^ 155] = I("\u0002069\u0001$3\u0014\"", "kCqLh");
      I[173 ^ 142] = I("<\u0011\u00021\u001f!\u000761\u001d2!69\u0015!\u0003&4\u0016", "UbDXs");
      I[79 ^ 107] = I("栞嬉挵炼", "TqqwB");
      I[2 ^ 39] = I("彀姎捪煫", "OWvns");
      I[142 ^ 168] = I("恭", "GQSGW");
      I[70 ^ 97] = I("倈岈嚎冡", "dvoyq");
      I[77 ^ 101] = I("滣柙濰丙巉", "Ejcls");
      I[184 ^ 145] = I("傍沾濅", "NpNvS");
      I[125 ^ 87] = I("卤柽旱", "dOjYy");
      I[12 ^ 39] = I("寃", "YNXII");
      I[140 ^ 160] = I("巠峣扝堢澒", "kPzxJ");
      I[19 ^ 62] = I("1\n5\u0002\u0016&\u001c", "CoVkf");
      I[52 ^ 26] = I("灆固", "BfiBx");
      I[136 ^ 167] = I("滂嵏沵剭", "ZQOsi");
      I[78 ^ 126] = I("淓椡宼坪", "YbZJn");
      I[22 ^ 39] = I("儌澄渨啫", "tmevS");
      I[150 ^ 164] = I("!\t\r\u0000\u0012<\u0015?\t7,\u0003+", "UfOeV");
      I[162 ^ 145] = I("撨凪", "cACys");
      I[113 ^ 69] = I("彀佀", "rOyXN");
      I[245 ^ 192] = I("汔供", "fCxMc");
      I[167 ^ 145] = I("孽淙", "uUJWy");
      I[108 ^ 91] = I("煯堮", "OmEpy");
      I[175 ^ 151] = I("溛揶", "vsDRE");
      I[251 ^ 194] = I("灁炼", "YzKmh");
      I[254 ^ 196] = I("檵对", "kLDiO");
      I[67 ^ 120] = I("\u001a>\u00049;<=&\"", "sMCLR");
      I[56 ^ 4] = I(":'<\u000f)'1\b\u000f+4\u0017\b\u0007#'5\u0018\n ", "STzfE");
      I[91 ^ 102] = I("\b\u0011*#>\u001f\u0007", "ztIJN");
      I[153 ^ 167] = I("摨榗", "VYRKc");
      I[160 ^ 159] = I("棯櫪", "pfWDD");
      I[243 ^ 179] = I("佂崧", "bhQlZ");
      I[118 ^ 55] = I("沅剙媻堼", "WLkLv");
      I[207 ^ 141] = I(" \u001a.\u0012\u0002T\u001c(W\n\u001b\t#W\u0013\u001a\u001a\"\u0014\t\u0013\u0006.\r\u0003\u0010H5\u0012\u0005\u001d\u0018\"MF\u000f\u0015g\u0005\u0003\u0019\u00071\u0012\u0002T\u0006(\u0000H", "thGwf");
      I[5 ^ 70] = I("\u001e\b\u000e\u00116\u0003\u0014<\u0018\u0013\u0013\u0002(", "jgLtr");
      I[92 ^ 24] = I("汃", "fZZMa");
      I[24 ^ 93] = I("\u0007>\u0003.4s8\u0005k<<-\u000ek%=>\u000f(?4\"\u0003157l\u0018.3:<\u000fqp(1J95>#\u001c.4s\"\u0005<~", "SLjKP");
      I[90 ^ 28] = I("巌灟挚沗", "kzzJt");
      I[31 ^ 88] = I("嗯", "GpvKQ");
      I[143 ^ 199] = I("榉哩媎", "mAzqa");
      I[203 ^ 130] = I("娟", "ntYSo");
      I[100 ^ 46] = I("县撷", "mjhQg");
      I[33 ^ 106] = I("弽媍", "VZWpr");
      I[91 ^ 23] = I("塨妋", "SotNb");
      I[55 ^ 122] = I("昴俙", "Vsvas");
      I[208 ^ 158] = I("怅棚欚", "HIhXB");
      I[73 ^ 6] = I("庯昑厚", "nnDPR");
   }

   private List<IRecipe> func_194079_d() {
      ArrayList var1 = Lists.newArrayList();
      int var2 = this.field_194077_a.nextSetBit("".length());

      do {
         if (var2 < 0) {
            return var1;
         }

         var1.add(CraftingManager.field_193380_a.getObjectById(var2));
         I[105 ^ 47].length();
         I[194 ^ 133].length();
         var2 = this.field_194077_a.nextSetBit(var2 + " ".length());
         "".length();
      } while(3 >= 1);

      throw null;
   }

   public void func_192825_a(NBTTagCompound var1) {
      String var10000 = I[125 ^ 78];
      String var10001 = I[189 ^ 137];
      String var10002 = I[176 ^ 133];
      var10001 = I[153 ^ 175];
      var10000 = I[111 ^ 88];
      var10001 = I[25 ^ 33];
      var10002 = I[4 ^ 61];
      var10001 = I[44 ^ 22];
      this.field_192818_b = var1.getBoolean(I[0 ^ 59]);
      this.field_192819_c = var1.getBoolean(I[48 ^ 12]);
      NBTTagList var2 = var1.getTagList(I[121 ^ 68], 205 ^ 197);
      int var3 = "".length();

      do {
         if (var3 >= var2.tagCount()) {
            NBTTagList var7 = var1.getTagList(I[253 ^ 190], 87 ^ 95);
            int var8 = "".length();

            do {
               if (var8 >= var7.tagCount()) {
                  return;
               }

               I[86 ^ 18].length();
               ResourceLocation var9 = new ResourceLocation(var7.getStringTagAt(var8));
               IRecipe var6 = CraftingManager.func_193373_a(var9);
               if (var6 == null) {
                  field_192828_d.info(I[105 ^ 44], var9);
                  "".length();
                  if (2 < 1) {
                     throw null;
                  }
               } else {
                  this.func_193825_e(var6);
               }

               ++var8;
               "".length();
            } while(0 < 4);

            throw null;
         }

         I[190 ^ 128].length();
         I[104 ^ 87].length();
         I[244 ^ 180].length();
         I[251 ^ 186].length();
         ResourceLocation var4 = new ResourceLocation(var2.getStringTagAt(var3));
         IRecipe var5 = CraftingManager.func_193373_a(var4);
         if (var5 == null) {
            field_192828_d.info(I[41 ^ 107], var4);
            "".length();
            if (4 != 4) {
               throw null;
            }
         } else {
            this.func_194073_a(var5);
         }

         ++var3;
         "".length();
      } while(3 > 0);

      throw null;
   }

   static {
      I();
      field_192828_d = LogManager.getLogger();
   }

   private void func_194081_a(SPacketRecipeBook.State var1, EntityPlayerMP var2, List<IRecipe> var3) {
      String var10000 = I[76 ^ 73];
      String var10001 = I[86 ^ 80];
      String var10002 = I[12 ^ 11];
      var10001 = I[92 ^ 84];
      NetHandlerPlayServer var4 = var2.connection;
      I[95 ^ 86].length();
      I[134 ^ 140].length();
      var4.sendPacket(new SPacketRecipeBook(var1, var3, Collections.emptyList(), this.field_192818_b, this.field_192819_c));
   }

   private List<IRecipe> func_194080_e() {
      ArrayList var1 = Lists.newArrayList();
      int var2 = this.field_194078_b.nextSetBit("".length());

      do {
         if (var2 < 0) {
            return var1;
         }

         var1.add(CraftingManager.field_193380_a.getObjectById(var2));
         I[38 ^ 110].length();
         I[120 ^ 49].length();
         var2 = this.field_194078_b.nextSetBit(var2 + " ".length());
         "".length();
      } while(0 != -1);

      throw null;
   }

   public void func_193835_a(List<IRecipe> var1, EntityPlayerMP var2) {
      ArrayList var3 = Lists.newArrayList();
      Iterator var4 = var1.iterator();

      do {
         if (!var4.hasNext()) {
            this.func_194081_a(SPacketRecipeBook.State.ADD, var2, var3);
            return;
         }

         IRecipe var5 = (IRecipe)var4.next();
         if (!this.field_194077_a.get(func_194075_d(var5)) && !var5.func_192399_d()) {
            this.func_194073_a(var5);
            this.func_193825_e(var5);
            var3.add(var5);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            CriteriaTriggers.field_192126_f.func_192225_a(var2, var5);
         }

         "".length();
      } while(0 >= 0);

      throw null;
   }

   public void func_193834_b(List<IRecipe> var1, EntityPlayerMP var2) {
      ArrayList var3 = Lists.newArrayList();
      Iterator var4 = var1.iterator();

      do {
         if (!var4.hasNext()) {
            this.func_194081_a(SPacketRecipeBook.State.REMOVE, var2, var3);
            return;
         }

         IRecipe var5 = (IRecipe)var4.next();
         if (this.field_194077_a.get(func_194075_d(var5))) {
            this.func_193831_b(var5);
            var3.add(var5);
            I["   ".length()].length();
            I[109 ^ 105].length();
         }

         "".length();
      } while(true);

      throw null;
   }
}

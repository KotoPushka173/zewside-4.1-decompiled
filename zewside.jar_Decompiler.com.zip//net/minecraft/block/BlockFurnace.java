package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockFurnace extends BlockContainer {
   // $FF: synthetic field
   private final boolean isBurning;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static boolean keepInventory;
   // $FF: synthetic field
   public static final PropertyDirection FACING;

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.FURNACE);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[124 ^ 88];
      String var10001 = I[19 ^ 54];
      String var10002 = I[146 ^ 180];
      var10001 = I[101 ^ 66];
      var10000 = I[20 ^ 60];
      var10001 = I[167 ^ 142];
      var10002 = I[83 ^ 121];
      var10001 = I[116 ^ 95];
      I[237 ^ 193].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[91 ^ 118].length();
      I[97 ^ 79].length();
      I[189 ^ 146].length();
      I[20 ^ 36].length();
      var10003["".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      if (this.isBurning) {
         EnumFacing var5 = (EnumFacing)var1.getValue(FACING);
         double var6 = (double)var3.getX() + 0.5D;
         double var8 = (double)var3.getY() + var4.nextDouble() * 6.0D / 16.0D;
         double var10 = (double)var3.getZ() + 0.5D;
         double var12 = 0.52D;
         double var10000 = var4.nextDouble() * 0.6D;
         I["  ".length()].length();
         I["   ".length()].length();
         I[86 ^ 82].length();
         double var14 = var10000 - 0.3D;
         if (var4.nextDouble() < 0.1D) {
            var2.playSound((double)var3.getX() + 0.5D, (double)var3.getY(), (double)var3.getZ() + 0.5D, SoundEvents.BLOCK_FURNACE_FIRE_CRACKLE, SoundCategory.BLOCKS, 1.0F, 1.0F, (boolean)"".length());
         }

         EnumParticleTypes var10001;
         switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var5.ordinal()]) {
         case 1:
            var10001 = EnumParticleTypes.SMOKE_NORMAL;
            I[152 ^ 157].length();
            I[102 ^ 96].length();
            var2.spawnParticle(var10001, var6 - 0.52D, var8, var10 + var14, 0.0D, 0.0D, 0.0D);
            var10001 = EnumParticleTypes.FLAME;
            I[182 ^ 177].length();
            var2.spawnParticle(var10001, var6 - 0.52D, var8, var10 + var14, 0.0D, 0.0D, 0.0D);
            "".length();
            if (4 <= -1) {
               throw null;
            }
            break;
         case 2:
            var2.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, var6 + 0.52D, var8, var10 + var14, 0.0D, 0.0D, 0.0D);
            var2.spawnParticle(EnumParticleTypes.FLAME, var6 + 0.52D, var8, var10 + var14, 0.0D, 0.0D, 0.0D);
            "".length();
            if (-1 >= 1) {
               throw null;
            }
            break;
         case 3:
            var10001 = EnumParticleTypes.SMOKE_NORMAL;
            double var10002 = var6 + var14;
            I[64 ^ 72].length();
            I[147 ^ 154].length();
            I[180 ^ 190].length();
            var2.spawnParticle(var10001, var10002, var8, var10 - 0.52D, 0.0D, 0.0D, 0.0D);
            var10001 = EnumParticleTypes.FLAME;
            var10002 = var6 + var14;
            I[53 ^ 62].length();
            I[156 ^ 144].length();
            var2.spawnParticle(var10001, var10002, var8, var10 - 0.52D, 0.0D, 0.0D, 0.0D);
            "".length();
            if (4 < 0) {
               throw null;
            }
            break;
         case 4:
            var2.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, var6 + var14, var8, var10 + 0.52D, 0.0D, 0.0D, 0.0D);
            var2.spawnParticle(EnumParticleTypes.FLAME, var6 + var14, var8, var10 + 0.52D, 0.0D, 0.0D, 0.0D);
         }
      }

   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, var8.getHorizontalFacing().getOpposite());
   }

   public static void setState(boolean var0, World var1, BlockPos var2) {
      IBlockState var3 = var1.getBlockState(var2);
      TileEntity var4 = var1.getTileEntity(var2);
      keepInventory = (boolean)" ".length();
      if (var0) {
         var1.setBlockState(var2, Blocks.LIT_FURNACE.getDefaultState().withProperty(FACING, var3.getValue(FACING)), "   ".length());
         I[74 ^ 71].length();
         I[118 ^ 120].length();
         var1.setBlockState(var2, Blocks.LIT_FURNACE.getDefaultState().withProperty(FACING, var3.getValue(FACING)), "   ".length());
         I[67 ^ 76].length();
         I[124 ^ 108].length();
         "".length();
         if (1 <= -1) {
            throw null;
         }
      } else {
         var1.setBlockState(var2, Blocks.FURNACE.getDefaultState().withProperty(FACING, var3.getValue(FACING)), "   ".length());
         I[56 ^ 41].length();
         I[71 ^ 85].length();
         var1.setBlockState(var2, Blocks.FURNACE.getDefaultState().withProperty(FACING, var3.getValue(FACING)), "   ".length());
         I[146 ^ 129].length();
         I[159 ^ 139].length();
         I[97 ^ 116].length();
      }

      keepInventory = (boolean)"".length();
      if (var4 != null) {
         var4.validate();
         var1.setTileEntity(var2, var4);
      }

   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      return Container.calcRedstone(var2.getTileEntity(var3));
   }

   private static void I() {
      I = new String[181 ^ 132];
      I["".length()] = I("厚", "bMphF");
      I[" ".length()] = I("洆烘椧", "OGRDW");
      I["  ".length()] = I("凣洸", "cqAyF");
      I["   ".length()] = I("檬剜", "cLzEa");
      I[144 ^ 148] = I("叒峛攓", "yuvuq");
      I[83 ^ 86] = I("恙", "MikRI");
      I[74 ^ 76] = I("俧喁廟塮嘍", "Bbjkp");
      I[123 ^ 124] = I("梉炒", "dnKui");
      I[5 ^ 13] = I("挋墐儼匔侠", "aQlVi");
      I[68 ^ 77] = I("匾擜凁估幕", "gUnRG");
      I[109 ^ 103] = I("旤帣擎偗撼", "pZAcY");
      I[56 ^ 51] = I("伌梆剛寪屟", "MzNIQ");
      I[61 ^ 49] = I("捧倌扬楟", "vttmf");
      I[62 ^ 51] = I("浢廾儇兤", "Jbkqi");
      I[30 ^ 16] = I("忌", "Qzhdw");
      I[76 ^ 67] = I("棐尵咳", "nFKiQ");
      I[22 ^ 6] = I("啋湗朖噊彍", "PmQgY");
      I[50 ^ 35] = I("帬凜", "sYNVu");
      I[114 ^ 96] = I("樵昡搪佃朚", "ppQit");
      I[116 ^ 103] = I("娅", "piDME");
      I[42 ^ 62] = I("夏忑凂", "QLPlk");
      I[84 ^ 65] = I("哠摗樓", "EUAoW");
      I[158 ^ 136] = I("桠煖", "lyXBZ");
      I[57 ^ 46] = I("旒椇", "qpWap");
      I[149 ^ 141] = I("擝得", "CMRWb");
      I[166 ^ 191] = I("攱仩", "yhrcg");
      I[147 ^ 137] = I("弓卲浪", "Oehrv");
      I[127 ^ 100] = I("汪崫淓侖", "bYSWP");
      I[70 ^ 90] = I("搄", "xjvZA");
      I[110 ^ 115] = I("匌檠", "rNhAG");
      I[87 ^ 73] = I("嚧氏", "EXSru");
      I[27 ^ 4] = I("淎拥", "FRZhZ");
      I[8 ^ 40] = I("楒欹", "hmtav");
      I[68 ^ 101] = I("扮嬠", "kPqkq");
      I[25 ^ 59] = I("従憒宲挧", "BeWxX");
      I[97 ^ 66] = I("桲嘓伿嚱", "afqPD");
      I[43 ^ 15] = I("梡亾", "VsZHb");
      I[90 ^ 127] = I("烛兽", "qFFXj");
      I[71 ^ 97] = I("冔攓", "lOWZA");
      I[179 ^ 148] = I("巹氹", "UopFl");
      I[188 ^ 148] = I("桸侄", "YiioQ");
      I[156 ^ 181] = I("屨微", "YooTo");
      I[178 ^ 152] = I("実歕", "AKgBB");
      I[138 ^ 161] = I("扞惸", "SLyxx");
      I[190 ^ 146] = I("剎", "CAtvK");
      I[118 ^ 91] = I("殱漦另攞", "LsQRy");
      I[129 ^ 175] = I("仍宦", "cIEfB");
      I[13 ^ 34] = I("徏喦悀", "YTIAU");
      I[59 ^ 11] = I("吖曇杴澳", "YtoYZ");
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumFacing)var1.getValue(FACING)).getIndex();
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[91 ^ 69];
      String var10001 = I[104 ^ 119];
      String var10002 = I[131 ^ 163];
      var10001 = I[86 ^ 119];
      I[49 ^ 19].length();
      I[20 ^ 55].length();
      return new ItemStack(Blocks.FURNACE);
   }

   protected BlockFurnace(boolean var1) {
      super(Material.ROCK);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
      this.isBurning = var1;
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      if (!keepInventory) {
         TileEntity var4 = var1.getTileEntity(var2);
         if (var4 instanceof TileEntityFurnace) {
            InventoryHelper.dropInventoryItems(var1, (BlockPos)var2, (TileEntityFurnace)var4);
            var1.updateComparatorOutputLevel(var2, this);
         }
      }

      super.breakBlock(var1, var2, var3);
   }

   public IBlockState getStateFromMeta(int var1) {
      EnumFacing var2 = EnumFacing.getFront(var1);
      if (var2.getAxis() == EnumFacing.Axis.Y) {
         var2 = EnumFacing.NORTH;
      }

      return this.getDefaultState().withProperty(FACING, var2);
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[74 ^ 92];
      String var10001 = I[156 ^ 139];
      String var10002 = I[120 ^ 96];
      var10001 = I[11 ^ 18];
      I[96 ^ 122].length();
      I[66 ^ 89].length();
      return new TileEntityFurnace();
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         TileEntity var10 = var1.getTileEntity(var2);
         if (var10 instanceof TileEntityFurnace) {
            var4.displayGUIChest((TileEntityFurnace)var10);
            var4.addStat(StatList.FURNACE_INTERACTION);
         }

         return (boolean)" ".length();
      }
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      var1.setBlockState(var2, var3.withProperty(FACING, var4.getHorizontalFacing().getOpposite()), "  ".length());
      I[190 ^ 162].length();
      I[32 ^ 61].length();
      if (var5.hasDisplayName()) {
         TileEntity var6 = var1.getTileEntity(var2);
         if (var6 instanceof TileEntityFurnace) {
            ((TileEntityFurnace)var6).setCustomInventoryName(var5.getDisplayName());
         }
      }

   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 2);

      throw null;
   }

   private void setDefaultFacing(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         IBlockState var4 = var1.getBlockState(var2.north());
         IBlockState var5 = var1.getBlockState(var2.south());
         IBlockState var6 = var1.getBlockState(var2.west());
         IBlockState var7 = var1.getBlockState(var2.east());
         EnumFacing var8 = (EnumFacing)var3.getValue(FACING);
         if (var8 == EnumFacing.NORTH && var4.isFullBlock() && !var5.isFullBlock()) {
            var8 = EnumFacing.SOUTH;
            "".length();
            if (false) {
               throw null;
            }
         } else if (var8 == EnumFacing.SOUTH && var5.isFullBlock() && !var4.isFullBlock()) {
            var8 = EnumFacing.NORTH;
            "".length();
            if (-1 != -1) {
               throw null;
            }
         } else if (var8 == EnumFacing.WEST && var6.isFullBlock() && !var7.isFullBlock()) {
            var8 = EnumFacing.EAST;
            "".length();
            if (3 < 0) {
               throw null;
            }
         } else if (var8 == EnumFacing.EAST && var7.isFullBlock() && !var6.isFullBlock()) {
            var8 = EnumFacing.WEST;
         }

         var1.setBlockState(var2, var3.withProperty(FACING, var8), "  ".length());
         I["".length()].length();
         I[" ".length()].length();
      }

   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      this.setDefaultFacing(var1, var2, var3);
   }
}

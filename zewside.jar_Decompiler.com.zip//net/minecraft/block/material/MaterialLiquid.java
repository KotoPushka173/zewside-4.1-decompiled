package net.minecraft.block.material;

public class MaterialLiquid extends Material {
   public boolean isLiquid() {
      return (boolean)" ".length();
   }

   public boolean blocksMovement() {
      return (boolean)"".length();
   }

   public MaterialLiquid(MapColor var1) {
      super(var1);
      this.setReplaceable();
      this.setNoPushMobility();
   }

   public boolean isSolid() {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 1);

      throw null;
   }
}

package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class NettyPacketEncoder extends MessageToByteEncoder<Packet<?>> {
   // $FF: synthetic field
   private static final Marker RECEIVED_PACKET_MARKER;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final Logger LOGGER;
   // $FF: synthetic field
   private final EnumPacketDirection direction;

   protected void encode(ChannelHandlerContext var1, Packet<?> var2, ByteBuf var3) throws Exception, IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[161 ^ 165];
      var10001 = I[21 ^ 16];
      var10002 = I[1 ^ 7];
      var10001 = I[67 ^ 68];
      var10000 = I[81 ^ 89];
      var10001 = I[71 ^ 78];
      var10002 = I[95 ^ 85];
      var10001 = I[70 ^ 77];
      var10000 = I[189 ^ 177];
      var10001 = I[105 ^ 100];
      var10002 = I[140 ^ 130];
      var10001 = I[147 ^ 156];
      EnumConnectionState var4 = (EnumConnectionState)var1.channel().attr(NetworkManager.PROTOCOL_ATTRIBUTE_KEY).get();
      if (var4 == null) {
         I[98 ^ 114].length();
         I[69 ^ 84].length();
         I[25 ^ 11].length();
         I[123 ^ 104].length();
         RuntimeException var10 = new RuntimeException(I[177 ^ 165] + var2.toString());
         I[154 ^ 143].length();
         I[9 ^ 31].length();
         I[116 ^ 99].length();
         I[152 ^ 128].length();
         throw var10;
      } else {
         Integer var5 = var4.getPacketId(this.direction, var2);
         if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(RECEIVED_PACKET_MARKER, I[161 ^ 184], var1.channel().attr(NetworkManager.PROTOCOL_ATTRIBUTE_KEY).get(), var5, var2.getClass().getName());
         }

         if (var5 == null) {
            I[5 ^ 31].length();
            I[217 ^ 194].length();
            I[77 ^ 81].length();
            IOException var9 = new IOException(I[177 ^ 172]);
            I[87 ^ 73].length();
            I[103 ^ 120].length();
            I[176 ^ 144].length();
            I[151 ^ 182].length();
            throw var9;
         } else {
            I[226 ^ 192].length();
            I[127 ^ 92].length();
            I[35 ^ 7].length();
            PacketBuffer var6 = new PacketBuffer(var3);
            var6.writeVarIntToBuffer(var5);
            I[90 ^ 127].length();
            I[191 ^ 153].length();

            try {
               var2.writePacketData(var6);
            } catch (Throwable var8) {
               LOGGER.error(var8);
               return;
            }

            "".length();
            if (0 == 2) {
               throw null;
            }
         }
      }
   }

   public NettyPacketEncoder(EnumPacketDirection var1) {
      this.direction = var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   private static void I() {
      I = new String[153 ^ 177];
      I["".length()] = I("濣剱", "DXvjA");
      I[" ".length()] = I("奚喣", "zVndL");
      I["  ".length()] = I("毄勁", "oAMiz");
      I["   ".length()] = I("榹晥", "lYOyZ");
      I[102 ^ 98] = I("栟忥", "OUqoM");
      I[6 ^ 3] = I("垎灞", "kbfAD");
      I[199 ^ 193] = I("攫梅", "NFMIm");
      I[155 ^ 156] = I("岙攰", "FcOmX");
      I[165 ^ 173] = I("孜奨", "HgXOb");
      I[165 ^ 172] = I("烡哷", "qZgBc");
      I[160 ^ 170] = I("妦榽", "CiSeH");
      I[79 ^ 68] = I("潞渓", "cBaHd");
      I[184 ^ 180] = I("旴护", "OfsIG");
      I[136 ^ 133] = I("剰搅", "jlJFo");
      I[32 ^ 46] = I("斅歱", "XzhEl");
      I[74 ^ 69] = I("暩傇", "ExqDI");
      I[176 ^ 160] = I("揪暊", "ayhYd");
      I[176 ^ 161] = I("庁匊叐揓岞", "oRWAe");
      I[128 ^ 146] = I("怊", "HpHoK");
      I[30 ^ 13] = I("檑梿婸寓", "uglFG");
      I[121 ^ 109] = I(":\f\r?\u0010\u001a\u0017\n>\u001b)\u0011\f%\u001a\u001a\f\u000fq\u0000\u0017\b\r>\u0002\u0017YC", "yccQu");
      I[34 ^ 55] = I("換擃", "YkvYG");
      I[2 ^ 20] = I("塘寛旞偙彥", "lVsgX");
      I[74 ^ 93] = I("乫啢抳", "UTEla");
      I[129 ^ 153] = I("创弘", "ADPgJ");
      I[48 ^ 41] = I("(8:~K<\u0016\u0013~\u0010\u001a0N?\u0016", "gmnDk");
      I[53 ^ 47] = I("堰", "OCNfn");
      I[113 ^ 106] = I("匶慦佚囝", "QaLBv");
      I[172 ^ 176] = I("授泓幬慉濺", "FqDHf");
      I[92 ^ 65] = I(".\u00124~\u0007M\u0000?+\u001a\f\u001f3#\u0016M\u00064+\u0016\n\u001a)-\u0016\u001f\u0016>y\u0003\f\u00101<\u0007", "msZYs");
      I[114 ^ 108] = I("洒煕", "FQeRG");
      I[188 ^ 163] = I("囲旺渰妅募", "RvdHL");
      I[20 ^ 52] = I("厑凯湨", "ZqrNl");
      I[38 ^ 7] = I("岄槚唚叽", "BVJKJ");
      I[17 ^ 51] = I("七朒搾", "YroFt");
      I[10 ^ 41] = I("溕奓捋朩", "qRNHU");
      I[157 ^ 185] = I("姶叄忨嵆偅", "DdjsZ");
      I[148 ^ 177] = I("漭挤", "sNZMr");
      I[39 ^ 1] = I("潾戭愮嫼涢", "fKiHZ");
      I[225 ^ 198] = I("',*%-#2:+&#", "wminh");
   }

   static {
      I();
      LOGGER = LogManager.getLogger();
      RECEIVED_PACKET_MARKER = MarkerManager.getMarker(I[161 ^ 134], NetworkManager.NETWORK_PACKETS_MARKER);
   }
}

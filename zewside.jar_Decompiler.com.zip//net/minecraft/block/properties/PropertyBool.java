package net.minecraft.block.properties;

import com.google.common.base.Optional;
import com.google.common.collect.ImmutableSet;
import java.util.Collection;

public class PropertyBool extends PropertyHelper<Boolean> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final ImmutableSet<Boolean> allowedValues = ImmutableSet.of(Boolean.valueOf((boolean)" ".length()), Boolean.valueOf((boolean)"".length()));

   private static void I() {
      I = new String[110 ^ 102];
      I["".length()] = I("洹多", "xjluf");
      I[" ".length()] = I("嶃审", "RGEYs");
      I["  ".length()] = I("嚣垊", "kReQx");
      I["   ".length()] = I("捙压", "hkhUO");
      I[46 ^ 42] = I("歺姮", "AQrPQ");
      I[151 ^ 146] = I("弰懆櫕斂", "TvtzQ");
      I[123 ^ 125] = I("\u00028<5", "vJIPY");
      I[80 ^ 87] = I("\u0000\f:\u001a<", "fmViY");
   }

   public int hashCode() {
      return (19 ^ 12) * super.hashCode() + this.allowedValues.hashCode();
   }

   public Optional<Boolean> parseValue(String var1) {
      Optional var10000;
      if (!I[161 ^ 167].equals(var1) && !I[54 ^ 49].equals(var1)) {
         var10000 = Optional.absent();
         "".length();
         if (4 == 0) {
            throw null;
         }
      } else {
         var10000 = Optional.of(Boolean.valueOf(var1));
      }

      return var10000;
   }

   public Collection<Boolean> getAllowedValues() {
      return this.allowedValues;
   }

   static {
      I();
   }

   public static PropertyBool create(String var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[197 ^ 193].length();
      I[21 ^ 16].length();
      return new PropertyBool(var0);
   }

   public String getName(Boolean var1) {
      return var1.toString();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 0);

      throw null;
   }

   protected PropertyBool(String var1) {
      super(var1, Boolean.class);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)" ".length();
      } else if (var1 instanceof PropertyBool && super.equals(var1)) {
         PropertyBool var2 = (PropertyBool)var1;
         return this.allowedValues.equals(var2.allowedValues);
      } else {
         return (boolean)"".length();
      }
   }
}

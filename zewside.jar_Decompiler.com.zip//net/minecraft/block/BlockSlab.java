package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockSlab extends Block {
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_BOTTOM_HALF;
   // $FF: synthetic field
   public static final PropertyEnum<BlockSlab.EnumBlockHalf> HALF;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_TOP_HALF;
   // $FF: synthetic field
   private static final String[] I;

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (this.isDouble()) {
         return super.shouldSideBeRendered(var1, var2, var3, var4);
      } else if (var4 != EnumFacing.UP && var4 != EnumFacing.DOWN && !super.shouldSideBeRendered(var1, var2, var3, var4)) {
         return (boolean)"".length();
      } else {
         IBlockState var5 = var2.getBlockState(var3.offset(var4));
         int var10000;
         if (isHalfSlab(var5) && var5.getValue(HALF) == BlockSlab.EnumBlockHalf.TOP) {
            var10000 = " ".length();
            "".length();
            if (4 <= 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         int var6 = var10000;
         if (isHalfSlab(var1) && var1.getValue(HALF) == BlockSlab.EnumBlockHalf.TOP) {
            var10000 = " ".length();
            "".length();
            if (3 <= 2) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         int var7 = var10000;
         if (var7 != 0) {
            if (var4 == EnumFacing.DOWN) {
               return (boolean)" ".length();
            } else if (var4 == EnumFacing.UP && super.shouldSideBeRendered(var1, var2, var3, var4)) {
               return (boolean)" ".length();
            } else {
               if (isHalfSlab(var5) && var6 != 0) {
                  var10000 = "".length();
               } else {
                  var10000 = " ".length();
                  "".length();
                  if (3 < 0) {
                     throw null;
                  }
               }

               return (boolean)var10000;
            }
         } else if (var4 == EnumFacing.UP) {
            return (boolean)" ".length();
         } else if (var4 == EnumFacing.DOWN && super.shouldSideBeRendered(var1, var2, var3, var4)) {
            return (boolean)" ".length();
         } else {
            if (isHalfSlab(var5) && var6 == 0) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (-1 == 2) {
                  throw null;
               }
            }

            return (boolean)var10000;
         }
      }
   }

   protected boolean canSilkHarvest() {
      return (boolean)"".length();
   }

   public boolean isFullCube(IBlockState var1) {
      return this.isDouble();
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return this.isDouble();
   }

   public int quantityDropped(Random var1) {
      int var10000;
      if (this.isDouble()) {
         var10000 = "  ".length();
         "".length();
         if (3 < 2) {
            throw null;
         }
      } else {
         var10000 = " ".length();
      }

      return var10000;
   }

   public abstract IProperty<?> getVariantProperty();

   public BlockSlab(Material var1, MapColor var2) {
      super(var1, var2);
      this.fullBlock = this.isDouble();
      this.setLightOpacity(76 + 26 - -32 + 121);
   }

   public abstract Comparable<?> getTypeForItem(ItemStack var1);

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      IBlockState var9 = super.getStateForPlacement(var1, var2, var3, var4, var5, var6, var7, var8).withProperty(HALF, BlockSlab.EnumBlockHalf.BOTTOM);
      if (this.isDouble()) {
         return var9;
      } else {
         IBlockState var10000;
         if (var3 != EnumFacing.DOWN && (var3 == EnumFacing.UP || (double)var5 <= 0.5D)) {
            var10000 = var9;
            "".length();
            if (4 < 0) {
               throw null;
            }
         } else {
            var10000 = var9.withProperty(HALF, BlockSlab.EnumBlockHalf.TOP);
         }

         return var10000;
      }
   }

   public BlockSlab(Material var1) {
      this(var1, var1.getMaterialMapColor());
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      if (((BlockSlab)var2.getBlock()).isDouble()) {
         return BlockFaceShape.SOLID;
      } else if (var4 == EnumFacing.UP && var2.getValue(HALF) == BlockSlab.EnumBlockHalf.TOP) {
         return BlockFaceShape.SOLID;
      } else {
         BlockFaceShape var10000;
         if (var4 == EnumFacing.DOWN && var2.getValue(HALF) == BlockSlab.EnumBlockHalf.BOTTOM) {
            var10000 = BlockFaceShape.SOLID;
            "".length();
            if (3 <= 2) {
               throw null;
            }
         } else {
            var10000 = BlockFaceShape.UNDEFINED;
         }

         return var10000;
      }
   }

   static {
      I();
      HALF = PropertyEnum.create(I["".length()], BlockSlab.EnumBlockHalf.class);
      AABB_BOTTOM_HALF = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
      AABB_TOP_HALF = new AxisAlignedBB(0.0D, 0.5D, 0.0D, 1.0D, 1.0D, 1.0D);
   }

   public abstract String getUnlocalizedName(int var1);

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      if (this.isDouble()) {
         return FULL_BLOCK_AABB;
      } else {
         AxisAlignedBB var10000;
         if (var1.getValue(HALF) == BlockSlab.EnumBlockHalf.TOP) {
            var10000 = AABB_TOP_HALF;
            "".length();
            if (4 < 0) {
               throw null;
            }
         } else {
            var10000 = AABB_BOTTOM_HALF;
         }

         return var10000;
      }
   }

   public abstract boolean isDouble();

   public boolean isFullyOpaque(IBlockState var1) {
      int var10000;
      if (!((BlockSlab)var1.getBlock()).isDouble() && var1.getValue(HALF) != BlockSlab.EnumBlockHalf.TOP) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (2 == 0) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("?-:-", "WLVKy");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 2);

      throw null;
   }

   protected static boolean isHalfSlab(IBlockState var0) {
      Block var1 = var0.getBlock();
      int var10000;
      if (var1 != Blocks.STONE_SLAB && var1 != Blocks.WOODEN_SLAB && var1 != Blocks.STONE_SLAB2 && var1 != Blocks.PURPUR_SLAB) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (4 <= 2) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public static enum EnumBlockHalf implements IStringSerializable {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      TOP,
      // $FF: synthetic field
      BOTTOM;

      // $FF: synthetic field
      private final String name;

      static {
         I();
         TOP = new BlockSlab.EnumBlockHalf(I["".length()], "".length(), I[" ".length()]);
         BOTTOM = new BlockSlab.EnumBlockHalf(I["  ".length()], " ".length(), I["   ".length()]);
         BlockSlab.EnumBlockHalf[] var10000 = new BlockSlab.EnumBlockHalf["  ".length()];
         var10000["".length()] = TOP;
         var10000[" ".length()] = BOTTOM;
      }

      private EnumBlockHalf(String var3) {
         this.name = var3;
      }

      private static void I() {
         I = new String[124 ^ 120];
         I["".length()] = I("\u0006\r=", "RBmYl");
         I[" ".length()] = I(",\n9", "XeIbm");
         I["  ".length()] = I("/\r\u0016-\r ", "mBByB");
         I["   ".length()] = I("\u0011\u001c-$+\u001e", "ssYPD");
      }

      public String getName() {
         return this.name;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= 0);

         throw null;
      }

      public String toString() {
         return this.name;
      }
   }
}

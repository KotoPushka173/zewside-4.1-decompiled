package net.minecraft.advancements;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Iterator;
import net.minecraft.command.CommandResultStats;
import net.minecraft.command.FunctionObject;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootContext;

public class AdvancementRewards {
   // $FF: synthetic field
   private final ResourceLocation[] field_192117_d;
   // $FF: synthetic field
   private final int field_192115_b;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final FunctionObject.CacheableFunction field_193129_e;
   // $FF: synthetic field
   private final ResourceLocation[] field_192116_c;
   // $FF: synthetic field
   public static final AdvancementRewards field_192114_a;

   static {
      I();
      field_192114_a = new AdvancementRewards("".length(), new ResourceLocation["".length()], new ResourceLocation["".length()], FunctionObject.CacheableFunction.field_193519_a);
   }

   public void func_192113_a(final EntityPlayerMP var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[147 ^ 151];
      var10001 = I[116 ^ 113];
      var10002 = I[162 ^ 164];
      var10001 = I[35 ^ 36];
      var1.addExperience(this.field_192115_b);
      I[129 ^ 137].length();
      I[103 ^ 110].length();
      LootContext var2 = (new LootContext.Builder(var1.getServerWorld())).withLootedEntity(var1).build();
      int var3 = "".length();
      ResourceLocation[] var4 = this.field_192116_c;
      int var5 = var4.length;
      int var6 = "".length();

      do {
         if (var6 >= var5) {
            if (var3 != 0) {
               var1.inventoryContainer.detectAndSendChanges();
            }

            if (this.field_192117_d.length > 0) {
               var1.func_193102_a(this.field_192117_d);
            }

            final MinecraftServer var11 = var1.mcServer;
            FunctionObject var12 = this.field_193129_e.func_193518_a(var11.func_193030_aL());
            if (var12 != null) {
               I[103 ^ 108].length();
               I[133 ^ 137].length();
               I[9 ^ 4].length();
               ICommandSender var13 = new ICommandSender() {
                  // $FF: synthetic field
                  private static final String[] I;

                  public String getName() {
                     return var1.getName();
                  }

                  static {
                     I();
                  }

                  public boolean sendCommandFeedback() {
                     return var11.worldServers["".length()].getGameRules().getBoolean(I["".length()]);
                  }

                  public Entity getCommandSenderEntity() {
                     return var1;
                  }

                  public boolean canCommandSenderUseCommand(int var1x, String var2) {
                     int var10000;
                     if (var1x <= "  ".length()) {
                        var10000 = " ".length();
                        "".length();
                        if (4 == 0) {
                           throw null;
                        }
                     } else {
                        var10000 = "".length();
                     }

                     return (boolean)var10000;
                  }

                  public World getEntityWorld() {
                     return var1.world;
                  }

                  public void addChatMessage(ITextComponent var1x) {
                  }

                  public Vec3d getPositionVector() {
                     return var1.getPositionVector();
                  }

                  public MinecraftServer getServer() {
                     return var1.getServer();
                  }

                  public ITextComponent getDisplayName() {
                     return var1.getDisplayName();
                  }

                  public BlockPos getPosition() {
                     return var1.getPosition();
                  }

                  public void setCommandStat(CommandResultStats.Type var1x, int var2) {
                     var1.setCommandStat(var1x, var2);
                  }

                  private static void I() {
                     I = new String[" ".length()];
                     I["".length()] = I("\u0000:\u001e\u0006\u0014\r11\u0007\u001a\u0000><\u001e\u0001\u0013 \u0007", "cUsku");
                  }

                  private static String I(String s, String s1) {
                     StringBuilder sb = new StringBuilder();
                     char[] key = s1.toCharArray();
                     int i = "".length();
                     char[] var5 = s.toCharArray();
                     int var6 = var5.length;
                     int var7 = "".length();

                     do {
                        if (var7 >= var6) {
                           return sb.toString();
                        }

                        char c = var5[var7];
                        sb.append((char)(c ^ key[i % key.length]));
                        ++i;
                        ++var7;
                        "".length();
                     } while(0 != 2);

                     throw null;
                  }
               };
               var11.func_193030_aL().func_194019_a(var12, var13);
               I[179 ^ 189].length();
               I[168 ^ 167].length();
            }

            return;
         }

         ResourceLocation var7 = var4[var6];
         Iterator var8 = var1.world.getLootTableManager().getLootTableFromLocation(var7).generateLootForPools(var1.getRNG(), var2).iterator();

         while(var8.hasNext()) {
            ItemStack var9 = (ItemStack)var8.next();
            if (var1.func_191521_c(var9)) {
               World var14 = var1.world;
               EntityPlayer var15 = (EntityPlayer)null;
               double var16 = var1.posX;
               double var10003 = var1.posY;
               double var10004 = var1.posZ;
               SoundEvent var10005 = SoundEvents.ENTITY_ITEM_PICKUP;
               SoundCategory var10006 = SoundCategory.PLAYERS;
               float var10008 = var1.getRNG().nextFloat();
               float var10009 = var1.getRNG().nextFloat();
               I[30 ^ 20].length();
               var14.playSound(var15, var16, var10003, var10004, var10005, var10006, 0.2F, ((var10008 - var10009) * 0.7F + 1.0F) * 2.0F);
               var3 = " ".length();
               "".length();
               if (0 == 4) {
                  throw null;
               }
            } else {
               EntityItem var10 = var1.dropItem(var9, (boolean)"".length());
               if (var10 != null) {
                  var10.setNoPickupDelay();
                  var10.setOwner(var1.getName());
               }
            }

            "".length();
            if (3 < -1) {
               throw null;
            }
         }

         ++var6;
         "".length();
      } while(4 != 3);

      throw null;
   }

   public String toString() {
      String var10000 = I[13 ^ 29];
      String var10001 = I[145 ^ 128];
      String var10002 = I[73 ^ 91];
      var10001 = I[11 ^ 24];
      I[156 ^ 136].length();
      return I[87 ^ 66] + this.field_192115_b + I[186 ^ 172] + Arrays.toString((Object[])this.field_192116_c) + I[190 ^ 169] + Arrays.toString((Object[])this.field_192117_d) + I[143 ^ 151] + this.field_193129_e + ('t' ^ '\t');
   }

   private static void I() {
      I = new String[6 ^ 31];
      I["".length()] = I("侨坷", "ISttb");
      I[" ".length()] = I("彌旞", "CtHTl");
      I["  ".length()] = I("偯嘐", "NwRyF");
      I["   ".length()] = I("坳庖", "iIWtm");
      I[146 ^ 150] = I("堥椮", "hnDFT");
      I[152 ^ 157] = I("拱伶", "TzILm");
      I[133 ^ 131] = I("悝泜", "JyldP");
      I[99 ^ 100] = I("摵峌", "mVzYz");
      I[121 ^ 113] = I("摡", "cuFTe");
      I[47 ^ 38] = I("嗖楻抒審", "TTjtQ");
      I[101 ^ 111] = I("撸", "qFFmE");
      I[128 ^ 139] = I("叝喋層檊唴", "doLtS");
      I[167 ^ 171] = I("憨惇叀媃", "EWwdQ");
      I[165 ^ 168] = I("崒汯填", "qwgMO");
      I[164 ^ 170] = I("杂", "tYROS");
      I[110 ^ 97] = I("暯廍歺楮", "dtnPn");
      I[171 ^ 187] = I("揑呋", "vdXyM");
      I[212 ^ 197] = I("捣擏", "eJIXj");
      I[112 ^ 98] = I("岮戙", "doWvT");
      I[86 ^ 69] = I("塆書", "nuwXi");
      I[58 ^ 46] = I("悹", "QnDSC");
      I[144 ^ 133] = I("\u0010\u0001\u001d\b&2\u0000\u0006\f&%7\u000e\u001e)#\u0001\u0018\u0012-)\u0015\u000e\u001b!4\u000b\b\fu", "QekiH");
      I[60 ^ 42] = I("TD\t-\u000b\fY", "xdeBd");
      I[86 ^ 65] = I("FI\u0017\u0000\u0015\u0003\u0019\u0000\u0016K", "jieev");
      I[131 ^ 155] = I("Vr\u001077\u0019&\u001f-7G", "zRvBY");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= -1);

      throw null;
   }

   public AdvancementRewards(int var1, ResourceLocation[] var2, ResourceLocation[] var3, FunctionObject.CacheableFunction var4) {
      this.field_192115_b = var1;
      this.field_192116_c = var2;
      this.field_192117_d = var3;
      this.field_193129_e = var4;
   }

   public static class Deserializer implements JsonDeserializer<AdvancementRewards> {
      // $FF: synthetic field
      private static final String[] I;

      public AdvancementRewards deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         var10000 = I[10 ^ 14];
         var10001 = I[67 ^ 70];
         var10002 = I[36 ^ 34];
         var10001 = I[17 ^ 22];
         var10000 = I[189 ^ 181];
         var10001 = I[139 ^ 130];
         var10002 = I[187 ^ 177];
         var10001 = I[80 ^ 91];
         var10000 = I[185 ^ 181];
         var10001 = I[174 ^ 163];
         var10002 = I[102 ^ 104];
         var10001 = I[135 ^ 136];
         var10000 = I[178 ^ 162];
         var10001 = I[209 ^ 192];
         var10002 = I[176 ^ 162];
         var10001 = I[121 ^ 106];
         var10000 = I[49 ^ 37];
         var10001 = I[79 ^ 90];
         var10002 = I[122 ^ 108];
         var10001 = I[66 ^ 85];
         var10000 = I[218 ^ 194];
         var10001 = I[88 ^ 65];
         var10002 = I[16 ^ 10];
         var10001 = I[111 ^ 116];
         var10000 = I[158 ^ 130];
         var10001 = I[157 ^ 128];
         var10002 = I[60 ^ 34];
         var10001 = I[20 ^ 11];
         var10000 = I[113 ^ 81];
         var10001 = I[77 ^ 108];
         var10002 = I[117 ^ 87];
         var10001 = I[95 ^ 124];
         var10000 = I[97 ^ 69];
         var10001 = I[57 ^ 28];
         var10002 = I[173 ^ 139];
         var10001 = I[146 ^ 181];
         var10000 = I[17 ^ 57];
         var10001 = I[19 ^ 58];
         var10002 = I[191 ^ 149];
         var10001 = I[80 ^ 123];
         JsonObject var4 = JsonUtils.getJsonObject(var1, I[234 ^ 198]);
         int var5 = JsonUtils.getInt(var4, I[5 ^ 40], "".length());
         var10001 = I[132 ^ 170];
         I[87 ^ 120].length();
         I[13 ^ 61].length();
         I[47 ^ 30].length();
         JsonArray var6 = JsonUtils.getJsonArray(var4, var10001, new JsonArray());
         ResourceLocation[] var7 = new ResourceLocation[var6.size()];
         int var8 = "".length();

         do {
            JsonElement var10004;
            if (var8 >= var7.length) {
               var10001 = I[148 ^ 175];
               I[99 ^ 95].length();
               I[125 ^ 64].length();
               JsonArray var12 = JsonUtils.getJsonArray(var4, var10001, new JsonArray());
               ResourceLocation[] var9 = new ResourceLocation[var12.size()];
               int var10 = "".length();

               do {
                  if (var10 >= var9.length) {
                     FunctionObject.CacheableFunction var13;
                     if (var4.has(I[80 ^ 0])) {
                        I[106 ^ 59].length();
                        I[192 ^ 146].length();
                        I[47 ^ 124].length();
                        I[224 ^ 180].length();
                        var13 = new FunctionObject.CacheableFunction(new ResourceLocation(JsonUtils.getString(var4, I[104 ^ 61])));
                        "".length();
                        if (0 <= -1) {
                           throw null;
                        }
                     } else {
                        var13 = FunctionObject.CacheableFunction.field_193519_a;
                     }

                     I[201 ^ 159].length();
                     I[47 ^ 120].length();
                     I[223 ^ 135].length();
                     return new AdvancementRewards(var5, var7, var9, var13);
                  }

                  I[115 ^ 77].length();
                  I[0 ^ 63].length();
                  I[221 ^ 157].length();
                  I[120 ^ 57].length();
                  var10004 = var12.get(var10);
                  I[91 ^ 25].length();
                  I[63 ^ 124].length();
                  var9[var10] = new ResourceLocation(JsonUtils.getString(var10004, I[74 ^ 14] + var10 + I[92 ^ 25]));
                  IRecipe var11 = CraftingManager.func_193373_a(var9[var10]);
                  if (var11 == null) {
                     I[64 ^ 6].length();
                     I[41 ^ 110].length();
                     I[193 ^ 137].length();
                     I[9 ^ 64].length();
                     I[219 ^ 145].length();
                     JsonSyntaxException var14 = new JsonSyntaxException(I[17 ^ 90] + var9[var10] + I[81 ^ 29]);
                     I[97 ^ 44].length();
                     I[61 ^ 115].length();
                     I[13 ^ 66].length();
                     throw var14;
                  }

                  ++var10;
                  "".length();
               } while(1 > 0);

               throw null;
            }

            I[57 ^ 11].length();
            I[20 ^ 39].length();
            I[39 ^ 19].length();
            I[5 ^ 48].length();
            var10004 = var6.get(var8);
            I[157 ^ 171].length();
            I[23 ^ 32].length();
            I[137 ^ 177].length();
            var7[var8] = new ResourceLocation(JsonUtils.getString(var10004, I[58 ^ 3] + var8 + I[110 ^ 84]));
            ++var8;
            "".length();
         } while(1 < 3);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 != 3);

         throw null;
      }

      static {
         I();
      }

      private static void I() {
         I = new String[103 ^ 62];
         I["".length()] = I("桒批", "MvtIq");
         I[" ".length()] = I("卅潣", "eXeAS");
         I["  ".length()] = I("杜湝", "ykEto");
         I["   ".length()] = I("涽加", "Cmmhr");
         I[91 ^ 95] = I("弼瀒", "VyTQR");
         I[55 ^ 50] = I("娙淖", "PLiyt");
         I[115 ^ 117] = I("嶦土", "TtKvO");
         I[14 ^ 9] = I("姁垌", "gqbUk");
         I[56 ^ 48] = I("崍烮", "VyHcv");
         I[25 ^ 16] = I("嘢殱", "vPgCc");
         I[78 ^ 68] = I("僬劼", "RiDyZ");
         I[51 ^ 56] = I("匙澪", "DHGRj");
         I[6 ^ 10] = I("嬩宐", "gTGro");
         I[3 ^ 14] = I("庄攑", "EFYCk");
         I[202 ^ 196] = I("瀲嘮", "fYhMP");
         I[64 ^ 79] = I("坑宙", "HJHBw");
         I[79 ^ 95] = I("坴桜", "vspRh");
         I[124 ^ 109] = I("化娭", "xhewo");
         I[155 ^ 137] = I("垇寸", "lUUSV");
         I[98 ^ 113] = I("巨淗", "HisEy");
         I[132 ^ 144] = I("傄泓", "gCDTJ");
         I[143 ^ 154] = I("旎淦", "Qbsbh");
         I[144 ^ 134] = I("尛墼", "WMHaS");
         I[140 ^ 155] = I("卶毱", "IVXtJ");
         I[142 ^ 150] = I("妡擣", "hFCuG");
         I[147 ^ 138] = I("櫏梱", "YjfZl");
         I[50 ^ 40] = I("枝嫎", "BapgE");
         I[103 ^ 124] = I("娴棲", "zzczk");
         I[102 ^ 122] = I("帶媙", "VkYaS");
         I[126 ^ 99] = I("嗆坩", "iUOxn");
         I[146 ^ 140] = I("敥橍", "MweCp");
         I[25 ^ 6] = I("侰楝", "NZSSx");
         I[137 ^ 169] = I("刨人", "MiQLG");
         I[143 ^ 174] = I("偫愆", "oGinC");
         I[20 ^ 54] = I("沩幤", "mWzhM");
         I[181 ^ 150] = I("侰嗁", "wDpDn");
         I[116 ^ 80] = I("慝存", "qLeyp");
         I[140 ^ 169] = I("業惕", "qasnb");
         I[177 ^ 151] = I("曖吊", "pzssy");
         I[137 ^ 174] = I("君彅", "mlEZC");
         I[167 ^ 143] = I("廌屼", "zxtbl");
         I[96 ^ 73] = I("寏柽", "MjYCC");
         I[123 ^ 81] = I("啰儱", "ugMFM");
         I[126 ^ 85] = I("枢悻", "hEhov");
         I[161 ^ 141] = I("\u001b\u000121\u001d\r\u0017", "idEPo");
         I[105 ^ 68] = I("\u0015 ?5\u0016\u0019=!3\u0001", "pXOPd");
         I[181 ^ 155] = I("\u001c=\u001a7", "pRuCU");
         I[139 ^ 164] = I("敏", "eHhsA");
         I[137 ^ 185] = I("嵲凭洺亮慂", "QWtBv");
         I[189 ^ 140] = I("憓唭", "CENDU");
         I[6 ^ 52] = I("嵭厵嬊", "QXzmY");
         I[178 ^ 129] = I("姚劢朞", "IszTE");
         I[84 ^ 96] = I("圑棙憩徭儣", "nvDBp");
         I[101 ^ 80] = I("榒揵憓", "beQFI");
         I[163 ^ 149] = I("吊炙掖儯", "rjoje");
         I[175 ^ 152] = I("涎佨欂", "VvNkc");
         I[143 ^ 183] = I("撷淜枛嗿", "gtiAi");
         I[61 ^ 4] = I("$#\u001b&\u0014", "HLtRO");
         I[66 ^ 120] = I("\u0007", "ZAXOl");
         I[126 ^ 69] = I("\u0011.08!\u00068", "cKSQQ");
         I[114 ^ 78] = I("嶵", "esgcT");
         I[4 ^ 57] = I("仨农寗", "DTNLo");
         I[97 ^ 95] = I("仸抟撣怭", "vHGnp");
         I[120 ^ 71] = I("择樟", "dMkno");
         I[23 ^ 87] = I("椶", "yIiwa");
         I[233 ^ 168] = I("娙榩", "ZtJZL");
         I[64 ^ 2] = I("滖漏", "CjEej");
         I[77 ^ 14] = I("伸婦嵲", "pHJxw");
         I[79 ^ 11] = I("\u0006\u0001.*\u0005\u0011\u0017\u0016", "tdMCu");
         I[98 ^ 39] = I("\t", "TGbLU");
         I[215 ^ 145] = I("峨漛", "vYgrN");
         I[34 ^ 101] = I("淏戎妗歧", "PQdif");
         I[72 ^ 0] = I("崍潈技", "NYHBt");
         I[39 ^ 110] = I("寮揰漋毭", "SdFHq");
         I[120 ^ 50] = I("堉毉應漓任", "jeYdC");
         I[248 ^ 179] = I("9\u0003\u0019$=\u001b\u0003R87\u000f\u0004\u0002/rK", "lmrJR");
         I[116 ^ 56] = I("Q", "vJbte");
         I[6 ^ 75] = I("庚捝懶偶姾", "WMLsC");
         I[81 ^ 31] = I("扼埌悹", "tkmPk");
         I[100 ^ 43] = I("唟", "tfckk");
         I[48 ^ 96] = I("\n#%1\u0006\u00059%", "lVKRr");
         I[88 ^ 9] = I("測森圣樬涍", "MSUeO");
         I[237 ^ 191] = I("澯戭", "hwmJL");
         I[24 ^ 75] = I("幔桟幦", "bdWUk");
         I[111 ^ 59] = I("榼", "nconp");
         I[66 ^ 23] = I("\"\u001d&\u00141-\u0007&", "DhHwE");
         I[25 ^ 79] = I("潦", "KqVSK");
         I[54 ^ 97] = I("几掕奪", "aXutb");
         I[123 ^ 35] = I("嘝嵔桑", "BMzTf");
      }
   }
}

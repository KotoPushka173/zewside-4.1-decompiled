package net.minecraft.advancements.critereon;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.math.MathHelper;

public class DistancePredicate {
   // $FF: synthetic field
   private final MinMaxBounds field_193425_c;
   // $FF: synthetic field
   private final MinMaxBounds field_193424_b;
   // $FF: synthetic field
   private final MinMaxBounds field_193426_d;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final MinMaxBounds field_193427_e;
   // $FF: synthetic field
   public static final DistancePredicate field_193423_a;
   // $FF: synthetic field
   private final MinMaxBounds field_193428_f;

   public boolean func_193422_a(double var1, double var3, double var5, double var7, double var9, double var11) {
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      float var13 = (float)(var1 - var7);
      I["   ".length()].length();
      I[53 ^ 49].length();
      I[180 ^ 177].length();
      I[39 ^ 33].length();
      I[115 ^ 116].length();
      float var14 = (float)(var3 - var9);
      I[13 ^ 5].length();
      I[189 ^ 180].length();
      I[174 ^ 164].length();
      float var15 = (float)(var5 - var11);
      if (this.field_193424_b.func_192514_a(MathHelper.abs(var13)) && this.field_193425_c.func_192514_a(MathHelper.abs(var14)) && this.field_193426_d.func_192514_a(MathHelper.abs(var15))) {
         return (boolean)(!this.field_193427_e.func_192513_a((double)(var13 * var13 + var15 * var15)) ? "".length() : this.field_193428_f.func_192513_a((double)(var13 * var13 + var14 * var14 + var15 * var15)));
      } else {
         return (boolean)"".length();
      }
   }

   public static DistancePredicate func_193421_a(@Nullable JsonElement var0) {
      String var10000 = I[33 ^ 42];
      String var10001 = I[138 ^ 134];
      String var10002 = I[186 ^ 183];
      var10001 = I[96 ^ 110];
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = JsonUtils.getJsonObject(var0, I[90 ^ 85]);
         MinMaxBounds var2 = MinMaxBounds.func_192515_a(var1.get(I[114 ^ 98]));
         MinMaxBounds var3 = MinMaxBounds.func_192515_a(var1.get(I[138 ^ 155]));
         MinMaxBounds var4 = MinMaxBounds.func_192515_a(var1.get(I[93 ^ 79]));
         MinMaxBounds var5 = MinMaxBounds.func_192515_a(var1.get(I[212 ^ 199]));
         MinMaxBounds var6 = MinMaxBounds.func_192515_a(var1.get(I[212 ^ 192]));
         I[148 ^ 129].length();
         I[108 ^ 122].length();
         I[181 ^ 162].length();
         return new DistancePredicate(var2, var3, var4, var5, var6);
      } else {
         return field_193423_a;
      }
   }

   public DistancePredicate(MinMaxBounds var1, MinMaxBounds var2, MinMaxBounds var3, MinMaxBounds var4, MinMaxBounds var5) {
      this.field_193424_b = var1;
      this.field_193425_c = var2;
      this.field_193426_d = var3;
      this.field_193427_e = var4;
      this.field_193428_f = var5;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > -1);

      throw null;
   }

   static {
      I();
      field_193423_a = new DistancePredicate(MinMaxBounds.field_192516_a, MinMaxBounds.field_192516_a, MinMaxBounds.field_192516_a, MinMaxBounds.field_192516_a, MinMaxBounds.field_192516_a);
   }

   private static void I() {
      I = new String[59 ^ 35];
      I["".length()] = I("昋楜", "XfjBn");
      I[" ".length()] = I("斧哝乼堧湻", "oAIRs");
      I["  ".length()] = I("敉漢杞埬", "CjyMK");
      I["   ".length()] = I("损席", "DLtET");
      I[80 ^ 84] = I("淒涝劐榯", "cFVFl");
      I[67 ^ 70] = I("朻", "GImcN");
      I[45 ^ 43] = I("坜", "vdcog");
      I[88 ^ 95] = I("濣", "JWDDq");
      I[83 ^ 91] = I("烵氒搝", "RCLaU");
      I[64 ^ 73] = I("懠唥嶔据涚", "oZYnd");
      I[55 ^ 61] = I("椮", "oiyoI");
      I[152 ^ 147] = I("晓僾", "zEMKx");
      I[10 ^ 6] = I("杋厬", "PqNtS");
      I[161 ^ 172] = I("兓晋", "UcKkh");
      I[191 ^ 177] = I("屯摕", "PoHsD");
      I[44 ^ 35] = I("\u0000\u0018\u0001\u0006\u0004\n\u0012\u0017", "dqrre");
      I[0 ^ 16] = I("\u001a", "bBFAy");
      I[102 ^ 119] = I("\u0000", "yaPmn");
      I[179 ^ 161] = I(")", "SvlNM");
      I[11 ^ 24] = I("\u0010\u0003\u0003\u000b\u0017\u0017\u0002\u0005\u0003\u0001", "xlqbm");
      I[175 ^ 187] = I("2:\u0017\u001d\n&,\u0001", "SXdrf");
      I[84 ^ 65] = I("渾亵促殠嫧", "hYGBX");
      I[26 ^ 12] = I("嚢", "zFuqv");
      I[113 ^ 102] = I("夲枭", "cfcdx");
   }
}

package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockCactus extends Block {
   // $FF: synthetic field
   public static final PropertyInteger AGE;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB CACTUS_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB CACTUS_COLLISION_AABB;

   private static void I() {
      I = new String[25 ^ 3];
      I["".length()] = I("烜樱", "WjCni");
      I[" ".length()] = I("暠濻暂嘉唃", "Utnzr");
      I["  ".length()] = I("欫瀶斀挒孃", "FNpna");
      I["   ".length()] = I("庅嫸", "EOmiu");
      I[178 ^ 182] = I("棟", "hpLnf");
      I[94 ^ 91] = I("兣墵意", "exjbo");
      I[21 ^ 19] = I("址", "rKSwM");
      I[109 ^ 106] = I("斃", "bCmrk");
      I[148 ^ 156] = I("氠宙", "MiwqC");
      I[17 ^ 24] = I("廬嶕捐柌彴", "hWtaz");
      I[93 ^ 87] = I("檬捻", "FMFnN");
      I[77 ^ 70] = I("岅掤截", "TLUxR");
      I[53 ^ 57] = I("楖欏渟", "sALsG");
      I[82 ^ 95] = I("搕殂", "zNbJx");
      I[69 ^ 75] = I("檁徢", "ZQBPS");
      I[179 ^ 188] = I("僎杽", "xvAqO");
      I[54 ^ 38] = I("欛灁", "WZYkt");
      I[0 ^ 17] = I("挧帳", "JnciD");
      I[81 ^ 67] = I("掍榈", "mOOoM");
      I[5 ^ 22] = I("吉切", "FQMoJ");
      I[99 ^ 119] = I("忀僊", "pJxcS");
      I[183 ^ 162] = I("囘唼", "UfVsh");
      I[146 ^ 132] = I("伮儸", "lzEbw");
      I[129 ^ 150] = I("唯杣淪", "nMxmW");
      I[105 ^ 113] = I("淽坧州专噊", "WDJeI");
      I[85 ^ 76] = I("\u000e\u001d5", "ozPOk");
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!this.canBlockStay(var2, var3)) {
         var2.destroyBlock(var3, (boolean)" ".length());
         I[134 ^ 142].length();
      }

   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      var4.attackEntityFrom(DamageSource.cactus, 1.0F);
      I[177 ^ 184].length();
      I[183 ^ 189].length();
      I[97 ^ 106].length();
      I[38 ^ 42].length();
   }

   public boolean canBlockStay(World var1, BlockPos var2) {
      Iterator var3 = EnumFacing.Plane.HORIZONTAL.iterator();

      do {
         if (!var3.hasNext()) {
            Block var6 = var1.getBlockState(var2.down()).getBlock();
            int var10000;
            if (var6 != Blocks.CACTUS && (var6 != Blocks.SAND || var1.getBlockState(var2.up()).getMaterial().isLiquid())) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (2 >= 3) {
                  throw null;
               }
            }

            return (boolean)var10000;
         }

         EnumFacing var4 = (EnumFacing)var3.next();
         Material var5 = var1.getBlockState(var2.offset(var4)).getMaterial();
         if (var5.isSolid() || var5 == Material.LAVA) {
            return (boolean)"".length();
         }

         "".length();
      } while(4 > 2);

      throw null;
   }

   protected BlockCactus() {
      super(Material.CACTUS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(AGE, "".length()));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return CACTUS_COLLISION_AABB;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   static {
      I();
      AGE = PropertyInteger.create(I[105 ^ 112], "".length(), 207 ^ 192);
      CACTUS_COLLISION_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.9375D, 0.9375D);
      CACTUS_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 1.0D, 0.9375D);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[167 ^ 170];
      String var10001 = I[99 ^ 109];
      String var10002 = I[174 ^ 161];
      var10001 = I[157 ^ 141];
      var10000 = I[8 ^ 25];
      var10001 = I[16 ^ 2];
      var10002 = I[31 ^ 12];
      var10001 = I[142 ^ 154];
      I[12 ^ 25].length();
      I[93 ^ 75].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[49 ^ 38].length();
      I[104 ^ 112].length();
      var10003["".length()] = AGE;
      return new BlockStateContainer(this, var10003);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != -1);

      throw null;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(AGE, var1);
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (super.canPlaceBlockAt(var1, var2)) {
         var10000 = this.canBlockStay(var1, var2);
         "".length();
         if (3 < 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public AxisAlignedBB getSelectedBoundingBox(IBlockState var1, World var2, BlockPos var3) {
      return CACTUS_AABB.offset(var3);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(AGE);
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      BlockPos var5 = var2.up();
      if (var1.isAirBlock(var5)) {
         int var6 = " ".length();

         while(var1.getBlockState(var2.down(var6)).getBlock() == this) {
            ++var6;
            "".length();
            if (2 <= 1) {
               throw null;
            }
         }

         if (var6 < "   ".length()) {
            int var7 = (Integer)var3.getValue(AGE);
            if (var7 == (101 ^ 106)) {
               var1.setBlockState(var5, this.getDefaultState());
               I["".length()].length();
               I[" ".length()].length();
               IBlockState var8 = var3.withProperty(AGE, "".length());
               var1.setBlockState(var2, var8, 174 ^ 170);
               I["  ".length()].length();
               I["   ".length()].length();
               I[171 ^ 175].length();
               I[117 ^ 112].length();
               var8.neighborChanged(var1, var5, this, var2);
               "".length();
               if (3 != 3) {
                  throw null;
               }
            } else {
               var1.setBlockState(var2, var3.withProperty(AGE, var7 + " ".length()), 23 ^ 19);
               I[130 ^ 132].length();
               I[20 ^ 19].length();
            }
         }
      }

   }
}

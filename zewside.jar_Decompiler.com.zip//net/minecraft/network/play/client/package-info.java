package net.minecraft.network.play.client;

import javax.annotation.ParametersAreNonnullByDefault;
import mcp.MethodsReturnNonnullByDefault;

// $FF: synthetic class
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
interface package-info {
}

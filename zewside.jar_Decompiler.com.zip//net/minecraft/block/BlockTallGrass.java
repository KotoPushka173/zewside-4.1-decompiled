package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockTallGrass extends BlockBush implements IGrowable {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockTallGrass.EnumType> TYPE;
   // $FF: synthetic field
   protected static final AxisAlignedBB TALL_GRASS_AABB;

   public void grow(World var1, Random var2, BlockPos var3, IBlockState var4) {
      BlockDoublePlant.EnumPlantType var5 = BlockDoublePlant.EnumPlantType.GRASS;
      if (var4.getValue(TYPE) == BlockTallGrass.EnumType.FERN) {
         var5 = BlockDoublePlant.EnumPlantType.FERN;
      }

      if (Blocks.DOUBLE_PLANT.canPlaceBlockAt(var1, var3)) {
         Blocks.DOUBLE_PLANT.placeAt(var1, var3, var5, "  ".length());
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[94 ^ 70];
      String var10001 = I[163 ^ 186];
      String var10002 = I[18 ^ 8];
      var10001 = I[112 ^ 107];
      var10000 = I[18 ^ 14];
      var10001 = I[169 ^ 180];
      var10002 = I[146 ^ 140];
      var10001 = I[217 ^ 198];
      I[90 ^ 122].length();
      I[73 ^ 104].length();
      I[181 ^ 151].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[27 ^ 56].length();
      I[187 ^ 159].length();
      I[14 ^ 43].length();
      var10003["".length()] = TYPE;
      return new BlockStateContainer(this, var10003);
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (!var1.isRemote && var6.getItem() == Items.SHEARS) {
         var2.addStat(StatList.getBlockStats(this));
         I[151 ^ 147].length();
         I[152 ^ 157].length();
         I[93 ^ 91].length();
         I[54 ^ 49].length();
         spawnAsEntity(var1, var3, new ItemStack(Blocks.TALLGRASS, " ".length(), ((BlockTallGrass.EnumType)var4.getValue(TYPE)).getMeta()));
         "".length();
         if (4 == -1) {
            throw null;
         }
      } else {
         super.harvestBlock(var1, var2, var3, var4, var5, var6);
      }

   }

   protected BlockTallGrass() {
      super(Material.VINE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(TYPE, BlockTallGrass.EnumType.DEAD_BUSH));
   }

   public boolean canGrow(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      int var10000;
      if (var3.getValue(TYPE) != BlockTallGrass.EnumType.DEAD_BUSH) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      Item var10000;
      if (var2.nextInt(165 ^ 173) == 0) {
         var10000 = Items.WHEAT_SEEDS;
         "".length();
         if (0 == -1) {
            throw null;
         }
      } else {
         var10000 = Items.field_190931_a;
      }

      return var10000;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(TYPE, BlockTallGrass.EnumType.byMetadata(var1));
   }

   public boolean isReplaceable(IBlockAccess var1, BlockPos var2) {
      return (boolean)" ".length();
   }

   public Block.EnumOffsetType getOffsetType() {
      return Block.EnumOffsetType.XYZ;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return TALL_GRASS_AABB;
   }

   public boolean canBlockStay(World var1, BlockPos var2, IBlockState var3) {
      return this.canSustainBush(var1.getBlockState(var2.down()));
   }

   private static void I() {
      I = new String[127 ^ 88];
      I["".length()] = I("婸夁", "RWfha");
      I[" ".length()] = I("殀姎", "VzKAn");
      I["  ".length()] = I("撿刡", "tSTCI");
      I["   ".length()] = I("哏歨", "OxaOm");
      I[38 ^ 34] = I("昰倏性", "tSohB");
      I[120 ^ 125] = I("灦", "XrbQD");
      I[158 ^ 152] = I("勰", "YmHkx");
      I[69 ^ 66] = I("唪幹", "uxUII");
      I[108 ^ 100] = I("惡槀", "HClee");
      I[3 ^ 10] = I("凣津", "jEVuD");
      I[63 ^ 53] = I("槿圊", "tkjeI");
      I[12 ^ 7] = I("槁墬", "NHgFC");
      I[95 ^ 83] = I("怴洋挪壒濲", "gpcWB");
      I[32 ^ 45] = I("滹掸厣", "xnZkU");
      I[96 ^ 110] = I("敒炜", "sOymm");
      I[82 ^ 93] = I("林娒", "wznli");
      I[186 ^ 170] = I("呠済", "iNiNI");
      I[114 ^ 99] = I("掹湥", "zdvdf");
      I[21 ^ 7] = I("呍潎", "KJHMH");
      I[187 ^ 168] = I("佄湞戢", "kvuXq");
      I[109 ^ 121] = I("滝", "wKwZP");
      I[188 ^ 169] = I("忑擾催傂劍", "VkSpm");
      I[34 ^ 52] = I("剔濲噇枟圜", "OsTlc");
      I[115 ^ 100] = I("昞亊夕墕", "yXQpr");
      I[183 ^ 175] = I("涋啠", "mIhdG");
      I[35 ^ 58] = I("嫠揯", "UQuSu");
      I[69 ^ 95] = I("仾洭", "MYYGk");
      I[29 ^ 6] = I("呇潌", "nJipG");
      I[183 ^ 171] = I("泲朷", "Votyj");
      I[84 ^ 73] = I("戗孶", "Prnxg");
      I[182 ^ 168] = I("拉徿", "ylZAW");
      I[145 ^ 142] = I("噏扭", "mAMEf");
      I[178 ^ 146] = I("嗤", "IGrkR");
      I[1 ^ 32] = I("堄涜擿慗", "oTCAe");
      I[62 ^ 28] = I("峻殪櫨宦", "HkKQU");
      I[168 ^ 139] = I("卌", "eBSsP");
      I[143 ^ 171] = I("嬓姜", "GNdFs");
      I[70 ^ 99] = I("壄湅嚥", "bVrFa");
      I[190 ^ 152] = I(",\u0003\u0005'", "XzuBe");
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[134 ^ 142];
      String var10001 = I[73 ^ 64];
      String var10002 = I[61 ^ 55];
      var10001 = I[80 ^ 91];
      I[47 ^ 35].length();
      I[30 ^ 19].length();
      return new ItemStack(this, " ".length(), var3.getBlock().getMetaFromState(var3));
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockTallGrass.EnumType)var1.getValue(TYPE)).getMeta();
   }

   public boolean canUseBonemeal(World var1, Random var2, BlockPos var3, IBlockState var4) {
      return (boolean)" ".length();
   }

   static {
      I();
      TYPE = PropertyEnum.create(I[139 ^ 173], BlockTallGrass.EnumType.class);
      TALL_GRASS_AABB = new AxisAlignedBB(0.09999999403953552D, 0.0D, 0.09999999403953552D, 0.8999999761581421D, 0.800000011920929D, 0.8999999761581421D);
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[151 ^ 153];
      String var10001 = I[143 ^ 128];
      String var10002 = I[119 ^ 103];
      var10001 = I[108 ^ 125];
      int var3 = " ".length();

      do {
         if (var3 >= "   ".length()) {
            return;
         }

         I[175 ^ 189].length();
         I[16 ^ 3].length();
         I[83 ^ 71].length();
         I[17 ^ 4].length();
         var2.add(new ItemStack(this, " ".length(), var3));
         I[156 ^ 138].length();
         I[30 ^ 9].length();
         ++var3;
         "".length();
      } while(4 >= 4);

      throw null;
   }

   public int quantityDroppedWithBonus(int var1, Random var2) {
      return " ".length() + var2.nextInt(var1 * "  ".length() + " ".length());
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      GRASS,
      // $FF: synthetic field
      FERN;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      DEAD_BUSH;

      public String getName() {
         return this.name;
      }

      static {
         I();
         DEAD_BUSH = new BlockTallGrass.EnumType(I["".length()], "".length(), "".length(), I[" ".length()]);
         GRASS = new BlockTallGrass.EnumType(I["  ".length()], " ".length(), " ".length(), I["   ".length()]);
         FERN = new BlockTallGrass.EnumType(I[1 ^ 5], "  ".length(), "  ".length(), I[150 ^ 147]);
         BlockTallGrass.EnumType[] var10000 = new BlockTallGrass.EnumType["   ".length()];
         var10000["".length()] = DEAD_BUSH;
         var10000[" ".length()] = GRASS;
         var10000["  ".length()] = FERN;
         BlockTallGrass.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockTallGrass.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMeta()] = var3;
            ++var2;
            "".length();
         } while(1 != 3);

         throw null;
      }

      private static void I() {
         I = new String[187 ^ 189];
         I["".length()] = I("0\r\u0013626\u001d\u0001:", "tHRrm");
         I[" ".length()] = I(")=\u000e\u0007\u000b/-\u001c\u000b", "MXocT");
         I["  ".length()] = I("\r\u001b\b&%", "JIIuv");
         I["   ".length()] = I("\u0016\f5:9\u0005\u001f8%\u0015", "bmYVf");
         I[179 ^ 183] = I("\u001f\u00011\u0014", "YDcZi");
         I[128 ^ 133] = I("3\u000f8\u0003", "UjJmR");
      }

      public static BlockTallGrass.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > -1);

         throw null;
      }

      private EnumType(int var3, String var4) {
         this.meta = var3;
         this.name = var4;
      }

      public int getMeta() {
         return this.meta;
      }

      public String toString() {
         return this.name;
      }
   }
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockMycelium extends Block {
   // $FF: synthetic field
   public static final PropertyBool SNOWY;
   // $FF: synthetic field
   private static final String[] I;

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote) {
         if (var1.getLightFromNeighbors(var2.up()) < (98 ^ 102) && var1.getBlockState(var2.up()).getLightOpacity() > "  ".length()) {
            var1.setBlockState(var2, Blocks.DIRT.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.DIRT));
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            I["   ".length()].length();
            "".length();
            if (4 <= 2) {
               throw null;
            }
         } else if (var1.getLightFromNeighbors(var2.up()) >= (35 ^ 42)) {
            int var5 = "".length();

            while(var5 < (60 ^ 56)) {
               int var10001 = var4.nextInt("   ".length());
               int var10002 = " ".length();
               I[143 ^ 139].length();
               I[78 ^ 75].length();
               I[132 ^ 130].length();
               var10001 -= var10002;
               var10002 = var4.nextInt(71 ^ 66);
               int var10003 = "   ".length();
               I[44 ^ 43].length();
               var10002 -= var10003;
               var10003 = var4.nextInt("   ".length());
               int var10004 = " ".length();
               I[144 ^ 152].length();
               BlockPos var6 = var2.add(var10001, var10002, var10003 - var10004);
               IBlockState var7 = var1.getBlockState(var6);
               IBlockState var8 = var1.getBlockState(var6.up());
               if (var7.getBlock() == Blocks.DIRT && var7.getValue(BlockDirt.VARIANT) == BlockDirt.DirtType.DIRT && var1.getLightFromNeighbors(var6.up()) >= (11 ^ 15) && var8.getLightOpacity() <= "  ".length()) {
                  var1.setBlockState(var6, this.getDefaultState());
                  I[83 ^ 90].length();
                  I[51 ^ 57].length();
               }

               ++var5;
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            }
         }
      }

   }

   static {
      I();
      SNOWY = PropertyBool.create(I[57 ^ 33]);
   }

   protected BlockMycelium() {
      super(Material.GRASS, MapColor.PURPLE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(SNOWY, Boolean.valueOf((boolean)"".length())));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      super.randomDisplayTick(var1, var2, var3, var4);
      if (var4.nextInt(187 ^ 177) == 0) {
         var2.spawnParticle(EnumParticleTypes.TOWN_AURA, (double)((float)var3.getX() + var4.nextFloat()), (double)((float)var3.getY() + 1.1F), (double)((float)var3.getZ() + var4.nextFloat()), 0.0D, 0.0D, 0.0D);
      }

   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Blocks.DIRT.getItemDropped(Blocks.DIRT.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.DIRT), var2, var3);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 3);

      throw null;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[35 ^ 40];
      String var10001 = I[114 ^ 126];
      String var10002 = I[68 ^ 73];
      var10001 = I[123 ^ 117];
      var10000 = I[204 ^ 195];
      var10001 = I[122 ^ 106];
      var10002 = I[127 ^ 110];
      var10001 = I[167 ^ 181];
      I[186 ^ 169].length();
      I[184 ^ 172].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[138 ^ 159].length();
      I[153 ^ 143].length();
      I[40 ^ 63].length();
      var10003["".length()] = SNOWY;
      return new BlockStateContainer(this, var10003);
   }

   public int getMetaFromState(IBlockState var1) {
      return "".length();
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      Block var4 = var2.getBlockState(var3.up()).getBlock();
      PropertyBool var10001 = SNOWY;
      int var10002;
      if (var4 != Blocks.SNOW && var4 != Blocks.SNOW_LAYER) {
         var10002 = "".length();
      } else {
         var10002 = " ".length();
         "".length();
         if (3 < 3) {
            throw null;
         }
      }

      return var1.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   private static void I() {
      I = new String[78 ^ 87];
      I["".length()] = I("媕嗑岤", "DdrOn");
      I[" ".length()] = I("毠傇", "MTfFh");
      I["  ".length()] = I("尩匹", "lRezS");
      I["   ".length()] = I("拁啳唱兙", "DnMec");
      I[115 ^ 119] = I("婙撰揾", "DUnkV");
      I[12 ^ 9] = I("啜烟媊", "TcdQL");
      I[100 ^ 98] = I("栟扨", "vmggf");
      I[133 ^ 130] = I("殩毫", "JdBcA");
      I[67 ^ 75] = I("晢炚偸忪", "sVhXz");
      I[160 ^ 169] = I("岟滽捹楝咓", "GsgCR");
      I[132 ^ 142] = I("勊晣暃拭嬗", "GLUSf");
      I[63 ^ 52] = I("杷崎", "VjDwN");
      I[6 ^ 10] = I("枼埽", "TWEiu");
      I[144 ^ 157] = I("姷勂", "wAMWS");
      I[35 ^ 45] = I("泽斦", "fyKaT");
      I[179 ^ 188] = I("捄寺", "tuCdc");
      I[64 ^ 80] = I("无歺", "pRGcp");
      I[6 ^ 23] = I("堾杈", "jCyKw");
      I[101 ^ 119] = I("嵻哛", "FjMch");
      I[62 ^ 45] = I("栻灒", "XDCnn");
      I[52 ^ 32] = I("漲曛", "lDHuz");
      I[144 ^ 133] = I("嗑愱敗憢", "jboWn");
      I[113 ^ 103] = I("柲", "RLBls");
      I[170 ^ 189] = I("不潈", "avxsv");
      I[111 ^ 119] = I("\u001a48:\u001b", "iZWMb");
   }
}

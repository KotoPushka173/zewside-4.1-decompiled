package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;

public class BlockPrismarine extends Block {
   // $FF: synthetic field
   public static final int ROUGH_META;
   // $FF: synthetic field
   public static final int BRICKS_META;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockPrismarine.EnumType> VARIANT;
   // $FF: synthetic field
   public static final int DARK_META;

   private static void I() {
      I = new String[147 ^ 160];
      I["".length()] = I("儂婿", "VGwYx");
      I[" ".length()] = I("匝勬", "cwjbB");
      I["  ".length()] = I("吲扡", "EwGhv");
      I["   ".length()] = I("帱涣", "kdDIF");
      I[86 ^ 82] = I("強溂嶵嗛", "UCujE");
      I[155 ^ 158] = I("椬", "OXQvT");
      I[40 ^ 46] = I("弗媬榐崒桪", "sBoHz");
      I[144 ^ 151] = I("V", "xRReB");
      I[135 ^ 143] = I("e\u001b$\b3", "KuEeV");
      I[80 ^ 89] = I("慁幌", "FiGJU");
      I[111 ^ 101] = I("渞战", "ASwpF");
      I[93 ^ 86] = I("唳妸", "dnPtj");
      I[80 ^ 92] = I("媅幜", "kxnNW");
      I[181 ^ 184] = I("惯漷", "BIMyH");
      I[89 ^ 87] = I("崭椨", "XRtVW");
      I[99 ^ 108] = I("杂塄", "jKDhB");
      I[187 ^ 171] = I("动攊", "CQvXT");
      I[162 ^ 179] = I("啐", "rKQzA");
      I[22 ^ 4] = I("嶈泸", "cHubw");
      I[58 ^ 41] = I("杳堇", "qbcWR");
      I[3 ^ 23] = I("奸唴搫", "smgIA");
      I[99 ^ 118] = I("岏斱", "mSzuj");
      I[72 ^ 94] = I("漢帔檬", "ufoOl");
      I[88 ^ 79] = I("濼旁", "BywFg");
      I[100 ^ 124] = I("忁枧", "FtzYx");
      I[186 ^ 163] = I("仈檪", "iMyzU");
      I[162 ^ 184] = I("桷澚", "BUkeZ");
      I[187 ^ 160] = I("乂宋", "hbcFq");
      I[58 ^ 38] = I("敘姥", "glfQv");
      I[56 ^ 37] = I("晇澺", "wimkl");
      I[163 ^ 189] = I("劅岞", "xIOeu");
      I[137 ^ 150] = I("揼凳", "eMRjm");
      I[116 ^ 84] = I("卢斶", "CABVB");
      I[153 ^ 184] = I("严湭", "IalRY");
      I[157 ^ 191] = I("幷炅", "dsFqg");
      I[113 ^ 82] = I("剁僼吮多煇", "djcWc");
      I[173 ^ 137] = I("唄娀峥", "VZfwc");
      I[89 ^ 124] = I("汇倀溣", "jhVHx");
      I[30 ^ 56] = I("渮拤墇摍栳", "tUQJj");
      I[162 ^ 133] = I("潹", "InHyj");
      I[127 ^ 87] = I("欶潀杘", "smQNQ");
      I[72 ^ 97] = I("婶廋", "NqZzf");
      I[154 ^ 176] = I("條娼暈", "mdGgi");
      I[65 ^ 106] = I("卫垈惚忍倄", "xkjVt");
      I[76 ^ 96] = I("炕", "DspkQ");
      I[33 ^ 12] = I("她岆", "bFgvw");
      I[157 ^ 179] = I("悩御囏", "eXCah");
      I[59 ^ 20] = I("潳", "ZlylF");
      I[178 ^ 130] = I("倸侜斳", "BBAWm");
      I[118 ^ 71] = I("変凙咫俞", "PAXyn");
      I[20 ^ 38] = I("/\u0000\u0004\u001e\u000b7\u0015", "Yavwj");
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[173 ^ 186];
      String var10001 = I[173 ^ 181];
      String var10002 = I[26 ^ 3];
      var10001 = I[165 ^ 191];
      var10000 = I[140 ^ 151];
      var10001 = I[221 ^ 193];
      var10002 = I[139 ^ 150];
      var10001 = I[121 ^ 103];
      var10000 = I[106 ^ 117];
      var10001 = I[23 ^ 55];
      var10002 = I[19 ^ 50];
      var10001 = I[111 ^ 77];
      I[6 ^ 37].length();
      I[184 ^ 156].length();
      var2.add(new ItemStack(this, " ".length(), ROUGH_META));
      I[68 ^ 97].length();
      I[177 ^ 151].length();
      I[121 ^ 94].length();
      I[74 ^ 98].length();
      I[84 ^ 125].length();
      var2.add(new ItemStack(this, " ".length(), BRICKS_META));
      I[64 ^ 106].length();
      I[128 ^ 171].length();
      I[97 ^ 77].length();
      I[50 ^ 31].length();
      I[179 ^ 157].length();
      var2.add(new ItemStack(this, " ".length(), DARK_META));
      I[75 ^ 100].length();
      I[81 ^ 97].length();
      I[243 ^ 194].length();
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockPrismarine.EnumType.byMetadata(var1));
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[79 ^ 125], BlockPrismarine.EnumType.class);
      ROUGH_META = BlockPrismarine.EnumType.ROUGH.getMetadata();
      BRICKS_META = BlockPrismarine.EnumType.BRICKS.getMetadata();
      DARK_META = BlockPrismarine.EnumType.DARK.getMetadata();
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      MapColor var10000;
      if (var1.getValue(VARIANT) == BlockPrismarine.EnumType.ROUGH) {
         var10000 = MapColor.CYAN;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = MapColor.DIAMOND;
      }

      return var10000;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[30 ^ 23];
      String var10001 = I[186 ^ 176];
      String var10002 = I[26 ^ 17];
      var10001 = I[22 ^ 26];
      var10000 = I[36 ^ 41];
      var10001 = I[54 ^ 56];
      var10002 = I[143 ^ 128];
      var10001 = I[158 ^ 142];
      I[180 ^ 165].length();
      I[153 ^ 139].length();
      I[82 ^ 65].length();
      I[178 ^ 166].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[191 ^ 170].length();
      I[186 ^ 172].length();
      var10003["".length()] = VARIANT;
      return new BlockStateContainer(this, var10003);
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockPrismarine.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 1);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockPrismarine.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public BlockPrismarine() {
      super(Material.ROCK);
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockPrismarine.EnumType.ROUGH));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public String getLocalizedName() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[118 ^ 114].length();
      I[105 ^ 108].length();
      I[66 ^ 68].length();
      return I18n.translateToLocal(this.getUnlocalizedName() + I[179 ^ 180] + BlockPrismarine.EnumType.ROUGH.getUnlocalizedName() + I[19 ^ 27]);
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      ROUGH,
      // $FF: synthetic field
      DARK;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      BRICKS;

      private static void I() {
         I = new String[168 ^ 161];
         I["".length()] = I(":\u001c\u001e\r!", "hSKJi");
         I[" ".length()] = I(" +1\u001f\u00051+1\u0002\r", "PYXlh");
         I["  ".length()] = I("\u0004\u0003$(\u0005", "vlQOm");
         I["   ".length()] = I("-1 $2<", "ocigy");
         I[156 ^ 152] = I("\u0007=-<;\u0016=-!3(-6&5\u001c<", "wODOV");
         I[15 ^ 10] = I("-8\u000f\u0007\u0006<", "OJfdm");
         I[131 ^ 133] = I("\u0002\u000e?\u001a", "FOmQh");
         I[7 ^ 0] = I("\t*\u0010 *\u001d9\u000b8\u0018\f9\u000b%\u0010", "mKbKu");
         I[39 ^ 47] = I("\u0003\u0017 \u0013", "gvRxZ");
      }

      public int getMetadata() {
         return this.meta;
      }

      private EnumType(int var3, String var4, String var5) {
         this.meta = var3;
         this.name = var4;
         this.unlocalizedName = var5;
      }

      public String toString() {
         return this.name;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      public static BlockPrismarine.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      static {
         I();
         ROUGH = new BlockPrismarine.EnumType(I["".length()], "".length(), "".length(), I[" ".length()], I["  ".length()]);
         BRICKS = new BlockPrismarine.EnumType(I["   ".length()], " ".length(), " ".length(), I[71 ^ 67], I[125 ^ 120]);
         DARK = new BlockPrismarine.EnumType(I[117 ^ 115], "  ".length(), "  ".length(), I[64 ^ 71], I[183 ^ 191]);
         BlockPrismarine.EnumType[] var10000 = new BlockPrismarine.EnumType["   ".length()];
         var10000["".length()] = ROUGH;
         var10000[" ".length()] = BRICKS;
         var10000["  ".length()] = DARK;
         BlockPrismarine.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockPrismarine.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(-1 < 3);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 < 3);

         throw null;
      }

      public String getName() {
         return this.name;
      }
   }
}

package net.minecraft.scoreboard;

import java.util.Iterator;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.storage.WorldSavedData;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ScoreboardSaveData extends WorldSavedData {
   // $FF: synthetic field
   private static final Logger LOGGER;
   // $FF: synthetic field
   private NBTTagCompound delayedInitNbt;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private Scoreboard theScoreboard;

   private static void I() {
      I = new String[67 + 77 - 121 + 113];
      I["".length()] = I("\u0016:\u000e'\u0000\u00076\u0000'\u0001", "eYaUe");
      I[" ".length()] = I("\u001743(\u0000,?/(\u0010", "XVYMc");
      I["  ".length()] = I("7\u0005\t(2\u0015:\u000b>%\u0002\u001a", "gihQW");
      I["   ".length()] = I("\u000b\n:6\u001a.\u001a\u001a*\u0019;\u0010", "OcIFv");
      I[113 ^ 117] = I("\u00131\u001d6\u001f6!=*\u001c#+", "WXnFs");
      I[116 ^ 113] = I("\u0004#;\u001b'", "PFZvT");
      I[145 ^ 151] = I(",\u0016+<\u0018", "xsJQk");
      I[59 ^ 60] = I("\r/9\f", "CNTiB");
      I[173 ^ 165] = I("&#\u0019\t\u000f\u00033$\u0018\u000e\u0007", "bJjyc");
      I[167 ^ 174] = I("7\u0000\u000b.!\f\t\u00051", "cejCb");
      I[131 ^ 137] = I("#4\u0011\"*\u0018=\u001f=", "wQpOi");
      I[176 ^ 187] = I("\u0012\u0002\n2<:", "BpoTU");
      I[64 ^ 76] = I("\u001b4\u000f\u0016-0", "HAipD");
      I[34 ^ 47] = I("7.6\u001c.003\u00167\u0012.#50\u0004'", "vBZsY");
      I[82 ^ 92] = I(".6\u0003.5)(\u0006$,\u000b6\u0016\u0007+\u001d?", "oZoAB");
      I[101 ^ 106] = I("4\b+\u0000?\u000e\b \"!\u001e$ 0$\u0014\u0004,*(\u0014", "gmNFM");
      I[78 ^ 94] = I("\u0003/\u0017\n\u001d9/\u001c(\u0003)\u0003\u001c:\u0006##\u0010 \n#", "PJrLo");
      I[120 ^ 105] = I("\u001e(7\" 1.\f.\u00079+3+\u001d$0", "PIZGt");
      I[190 ^ 172] = I("\n9$\u0001\"%?\u001f\r\u0005-: \b\u001f0!", "DXIdv");
      I[121 ^ 106] = I("\u000b\" !\u0011\u0002\"2&\u0018(\"\u0017<\n&%(9\u0010;>", "OGAUy");
      I[165 ^ 177] = I("(.)\u001a\u0019!.;\u001d\u0010\u000b.\u001e\u0007\u0002\u0005)!\u0002\u0018\u00182", "lKHnq");
      I[94 ^ 75] = I(")\u0001\u0018\u0007-\u0019\u0007\u001b\u0005\u0016\u001f\u0002\u0011", "jntkD");
      I[189 ^ 171] = I("36>=\u0003\u00030=?8\u000557", "pYRQj");
      I[97 ^ 118] = I("5\u0018\u0003\u0015*\u0017\u0007", "etblO");
      I[20 ^ 12] = I("泰宻瀞濴壱", "rNcTk");
      I[171 ^ 178] = I("栦攋", "fsxaw");
      I[44 ^ 54] = I("呈奉", "OxGpr");
      I[141 ^ 150] = I("漹妄", "vyNBN");
      I[186 ^ 166] = I("抋溋", "vggjK");
      I[143 ^ 146] = I("嚖呯", "qsxax");
      I[118 ^ 104] = I("姑卖", "lSDoH");
      I[93 ^ 66] = I("浪巄", "jCICZ");
      I[18 ^ 50] = I("掛欇", "mZqFl");
      I[23 ^ 54] = I("匸櫲懨涮", "kVwHr");
      I[96 ^ 66] = I("0\n-\u00053", "CfBql");
      I[142 ^ 173] = I("堇棁", "tKHZk");
      I[228 ^ 192] = I("僨澏姩", "djBiu");
      I[128 ^ 165] = I("剗婜澊杸", "uEQSM");
      I[162 ^ 132] = I("殌塾", "DiyeO");
      I[180 ^ 147] = I(" \u0002.\u0007,", "SnAss");
      I[87 ^ 127] = I(".\u0004\u000b\u001a\u0007\u001f\u001f\u0003 \u0003\u0000\u0013", "mvbnb");
      I[48 ^ 25] = I("+\u0002\f4", "ecaQx");
      I[71 ^ 109] = I("\u0010\u0001>895\u0011\u0003)81", "ThMHU");
      I[75 ^ 96] = I("#?'\u0001/\u0003\u000e0\u0015/", "qZIeJ");
      I[3 ^ 47] = I(")(($\u0015\u0012#4$", "fJBAv");
      I[24 ^ 53] = I("<-\t(", "rLdMW");
      I[27 ^ 53] = I("5\u0016\u0006*$", "fuiXA");
      I[65 ^ 110] = I("\u000b\u001f6\u001b\u0010#", "GpUpu");
      I[27 ^ 43] = I("\r,!;4%", "ACBPQ");
      I[75 ^ 122] = I("-\u001a%\u000f\"Y\u001c#J5\u0018\u001e)J5\u001a\u0007>\u000f$\u0016\t>\u000ef\u000e\u00018\u0002)\f\u001cl\u0002'\u000f\u0001\"\rf\u0018H?\t)\u000b\r.\u0005'\u000b\fbDh", "yhLjF");
      I[14 ^ 60] = I("\"\b\b7/\u0019\u0003\u00147?", "mjbRL");
      I[145 ^ 162] = I("\u0000=8\u001e6\"\u0002:\b!5\"", "PQYgS");
      I[127 ^ 75] = I("\u0005\u000f\u0016*\t", "QjwGz");
      I[43 ^ 30] = I("嫅榬", "WEAbg");
      I[114 ^ 68] = I("咓坝", "YZPhV");
      I[99 ^ 84] = I("榆塊", "cdHOD");
      I[7 ^ 63] = I("潖檊", "UeYlM");
      I[51 ^ 10] = I("媕栅", "VRLpO");
      I[83 ^ 105] = I("噹嚱", "LAzqO");
      I[169 ^ 146] = I("奀娧", "sqZMY");
      I[108 ^ 80] = I("沽旒", "RpWvI");
      I[171 ^ 150] = I("媭捉", "nZwnI");
      I[7 ^ 57] = I("塥尼", "PHBRf");
      I[111 ^ 80] = I("吚倩", "ILhfk");
      I[73 ^ 9] = I("塵杳", "vUFEd");
      I[98 ^ 35] = I("俆敪", "lWvWC");
      I[253 ^ 191] = I("橀斁", "zzWQG");
      I[70 ^ 5] = I("婤挄", "IMzRE");
      I[222 ^ 154] = I("洳憬", "uneAu");
      I[241 ^ 180] = I("仩寱廫乒", "QoskR");
      I[7 ^ 65] = I("世党杪厯", "xahTl");
      I[66 ^ 5] = I("渇櫢暷灋憄", "BeSqh");
      I[125 ^ 53] = I("儮渶", "LECUQ");
      I[235 ^ 162] = I("姿", "VTIyd");
      I[3 ^ 73] = I("享湕", "vPJhI");
      I[77 ^ 6] = I("%#\b\u0014", "kBeqc");
      I[69 ^ 9] = I("\u0014\u000e\t\b91\u001e4\u001985", "PgzxU");
      I[214 ^ 155] = I("\u0006\u000e\u0002\u00185=\u0007\f\u0007", "Rkcuv");
      I[22 ^ 88] = I("\t<*6+!", "YNOPB");
      I[101 ^ 42] = I("\u0016\u0019'*\u000b=", "ElALb");
      I[44 ^ 124] = I(",\u0000\u000f\u001a4+\u001e\n\u0010-\t\u0000\u001a3*\u001f\t", "mlcuC");
      I[255 ^ 174] = I(":\f3%#\u0000\f8\u0007=\u0010 8\u00158\u001a\u00004\u000f4\u001a", "iiVcQ");
      I[204 ^ 158] = I("\u001d\u0006,\u0017!2\u0000\u0017\u001b\u0006:\u0005(\u001e\u001c'\u001e", "SgAru");
      I[10 ^ 89] = I("(1 \u0001\u000b!12\u0006\u0002\u000b1\u0017\u001c\u0010\u00056(\u0019\n\u0018-", "lTAuc");
      I[74 ^ 30] = I("\u001a:+ \u001f*<(\"$,9\"", "YUGLv");
      I[27 ^ 78] = I("坁", "cUeHx");
      I[89 ^ 15] = I("朠悵媑敉", "NhRfr");
      I[72 ^ 31] = I("急曔灣", "BvGrB");
      I[88 ^ 0] = I("拐樺氦", "XVIxT");
      I[32 ^ 121] = I("!..\u00031\u00031", "qBOzT");
      I[5 ^ 95] = I("涆瀰", "qCSjG");
      I[74 ^ 17] = I("應死", "XEyyb");
      I[119 ^ 43] = I("椰刘", "UjKWe");
      I[206 ^ 147] = I("潖懮", "oKXqE");
      I[152 ^ 198] = I("渔惇", "DCNVg");
      I[0 ^ 95] = I("垰峫", "LYpHw");
      I[245 ^ 149] = I("柘仗", "HPldW");
      I[125 ^ 28] = I("框墔", "indjp");
      I[77 ^ 47] = I("江澶", "IitLk");
      I[244 ^ 151] = I("她嫦勛槗", "uWrmJ");
      I[43 ^ 79] = I("瀃潦敽尛", "JdKWG");
      I[239 ^ 138] = I("昿", "EJlTH");
      I[212 ^ 178] = I("<\u00077\u0006)", "OkXrv");
      I[89 ^ 62] = I("538\u0014\b\u0010#\u0018\b\u000b\u0005)", "qZKdd");
      I[226 ^ 138] = I("塦槿", "QiZgy");
      I[37 ^ 76] = I("塤滝", "VpxwN");
      I[203 ^ 161] = I("濤嗀", "PyhpI");
      I[64 ^ 43] = I("暥凓", "vvXUs");
      I[91 ^ 55] = I("双杏", "POCUU");
      I[168 ^ 197] = I("婅巢", "fHAkb");
      I[14 ^ 96] = I("憥傓", "JAyLz");
      I[101 ^ 10] = I("剸侟", "MYtsc");
      I[237 ^ 157] = I("溜槗僳喉", "EdUuD");
      I[16 ^ 97] = I("濰暯", "oCIjY");
      I[212 ^ 166] = I("媣恝", "Ijisl");
      I[121 ^ 10] = I("橪潹徧", "ttbKQ");
      I[25 ^ 109] = I("俬囂殧栞漭", "NBJUx");
      I[66 ^ 55] = I("\u00019\u000f,", "OXbIm");
      I[214 ^ 160] = I("($\u0007\u000e\u001c\u0019?\u000f4\u0018\u00063", "kVnzy");
      I[91 ^ 44] = I(".\u001d<;\u000b\u000b\r\u0001*\n\u000f", "jtOKg");
      I[194 ^ 186] = I(" \b=\r*\u00009*\u0019*", "rmSiO");
      I[26 ^ 99] = I("娿炰", "KxHaY");
      I[78 ^ 52] = I("唙椥", "cClrv");
      I[67 ^ 56] = I("擸掀", "SifQt");
      I[9 ^ 117] = I("寽伮", "dyARJ");
      I[50 ^ 79] = I("抃朔", "TEyAq");
      I[220 ^ 162] = I("惿僻", "uZKSK");
      I[48 + 66 - 70 + 83] = I("匃挤", "TUfUv");
      I[122 + 98 - 164 + 72] = I("嫛挟", "MJglI");
      I[58 + 3 - 57 + 125] = I("圞歡侩摠孁", "WSCoo");
      I[62 + 36 - 87 + 119] = I("婪毹娮忿", "ApOXR");
      I[57 + 120 - 142 + 96] = I("嗑嘰嶼", "NcZvS");
      I[21 + 63 - 75 + 123] = I("\u001a\r\u0005\u0004", "Tlhaw");
      I[113 + 25 - 33 + 28] = I("6'\"+\u001b\r,>+", "yEHNx");
      I[18 + 2 - 0 + 114] = I("8\u0005\t!\u001f", "kffSz");
      I[114 + 66 - 103 + 58] = I("\u00165\n(\u0006>", "ZZiCc");
   }

   public NBTTagCompound writeToNBT(NBTTagCompound var1) {
      if (this.theScoreboard == null) {
         LOGGER.warn(I[244 ^ 197]);
         return var1;
      } else {
         var1.setTag(I[41 ^ 27], this.objectivesToNbt());
         var1.setTag(I[57 ^ 10], this.scoresToNbt());
         var1.setTag(I[85 ^ 97], this.teamsToNbt());
         this.fillInDisplaySlots(var1);
         return var1;
      }
   }

   static {
      I();
      LOGGER = LogManager.getLogger();
   }

   protected void readScores(NBTTagList var1) {
      int var2 = "".length();

      do {
         if (var2 >= var1.tagCount()) {
            return;
         }

         NBTTagCompound var3 = var1.getCompoundTagAt(var2);
         ScoreObjective var4 = this.theScoreboard.getObjective(var3.getString(I[90 ^ 118]));
         String var5 = var3.getString(I[48 ^ 29]);
         if (var5.length() > (57 ^ 17)) {
            var5 = var5.substring("".length(), 89 ^ 113);
         }

         Score var6 = this.theScoreboard.getOrCreateScore(var5, var4);
         var6.setScorePoints(var3.getInteger(I[142 ^ 160]));
         if (var3.hasKey(I[93 ^ 114])) {
            var6.setLocked(var3.getBoolean(I[29 ^ 45]));
         }

         ++var2;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   public void readFromNBT(NBTTagCompound var1) {
      if (this.theScoreboard == null) {
         this.delayedInitNbt = var1;
         "".length();
         if (-1 >= 0) {
            throw null;
         }
      } else {
         this.readObjectives(var1.getTagList(I[" ".length()], 70 ^ 76));
         this.readScores(var1.getTagList(I["  ".length()], 55 ^ 61));
         if (var1.hasKey(I["   ".length()], 64 ^ 74)) {
            this.readDisplayConfig(var1.getCompoundTag(I[17 ^ 21]));
         }

         if (var1.hasKey(I[123 ^ 126], 86 ^ 95)) {
            this.readTeams(var1.getTagList(I[64 ^ 70], 201 ^ 195));
         }
      }

   }

   protected NBTTagList teamsToNbt() {
      String var10000 = I[98 ^ 87];
      String var10001 = I[97 ^ 87];
      String var10002 = I[133 ^ 178];
      var10001 = I[255 ^ 199];
      var10000 = I[60 ^ 5];
      var10001 = I[253 ^ 199];
      var10002 = I[152 ^ 163];
      var10001 = I[183 ^ 139];
      var10000 = I[113 ^ 76];
      var10001 = I[37 ^ 27];
      var10002 = I[159 ^ 160];
      var10001 = I[71 ^ 7];
      var10000 = I[245 ^ 180];
      var10001 = I[19 ^ 81];
      var10002 = I[124 ^ 63];
      var10001 = I[117 ^ 49];
      I[234 ^ 175].length();
      NBTTagList var1 = new NBTTagList();
      Iterator var2 = this.theScoreboard.getTeams().iterator();

      do {
         if (!var2.hasNext()) {
            return var1;
         }

         ScorePlayerTeam var3 = (ScorePlayerTeam)var2.next();
         I[37 ^ 99].length();
         I[193 ^ 134].length();
         I[205 ^ 133].length();
         I[211 ^ 154].length();
         I[219 ^ 145].length();
         NBTTagCompound var4 = new NBTTagCompound();
         var4.setString(I[87 ^ 28], var3.getRegisteredName());
         var4.setString(I[192 ^ 140], var3.getTeamName());
         if (var3.getChatFormat().getColorIndex() >= 0) {
            var4.setString(I[192 ^ 141], var3.getChatFormat().getFriendlyName());
         }

         var4.setString(I[217 ^ 151], var3.getColorPrefix());
         var4.setString(I[246 ^ 185], var3.getColorSuffix());
         var4.setBoolean(I[22 ^ 70], var3.getAllowFriendlyFire());
         var4.setBoolean(I[76 ^ 29], var3.getSeeFriendlyInvisiblesEnabled());
         var4.setString(I[107 ^ 57], var3.getNameTagVisibility().internalName);
         var4.setString(I[25 ^ 74], var3.getDeathMessageVisibility().internalName);
         var4.setString(I[255 ^ 171], var3.getCollisionRule().name);
         I[126 ^ 43].length();
         I[196 ^ 146].length();
         NBTTagList var5 = new NBTTagList();
         Iterator var6 = var3.getMembershipCollection().iterator();

         while(var6.hasNext()) {
            String var7 = (String)var6.next();
            I[82 ^ 5].length();
            I[253 ^ 165].length();
            var5.appendTag(new NBTTagString(var7));
            "".length();
            if (1 < -1) {
               throw null;
            }
         }

         var4.setTag(I[104 ^ 49], var5);
         var1.appendTag(var4);
         "".length();
      } while(-1 != 2);

      throw null;
   }

   protected NBTTagList objectivesToNbt() {
      String var10000 = I[228 ^ 140];
      String var10001 = I[16 ^ 121];
      String var10002 = I[223 ^ 181];
      var10001 = I[116 ^ 31];
      var10000 = I[76 ^ 32];
      var10001 = I[10 ^ 103];
      var10002 = I[194 ^ 172];
      var10001 = I[231 ^ 136];
      I[115 ^ 3].length();
      I[92 ^ 45].length();
      I[17 ^ 99].length();
      NBTTagList var1 = new NBTTagList();
      Iterator var2 = this.theScoreboard.getScoreObjectives().iterator();

      do {
         if (!var2.hasNext()) {
            return var1;
         }

         ScoreObjective var3 = (ScoreObjective)var2.next();
         if (var3.getCriteria() != null) {
            I[84 ^ 39].length();
            I[55 ^ 67].length();
            NBTTagCompound var4 = new NBTTagCompound();
            var4.setString(I[218 ^ 175], var3.getName());
            var4.setString(I[68 ^ 50], var3.getCriteria().getName());
            var4.setString(I[34 ^ 85], var3.getDisplayName());
            var4.setString(I[111 ^ 23], var3.getRenderType().getRenderType());
            var1.appendTag(var4);
         }

         "".length();
      } while(2 == 2);

      throw null;
   }

   public ScoreboardSaveData(String var1) {
      super(var1);
   }

   protected void loadTeamPlayers(ScorePlayerTeam var1, NBTTagList var2) {
      int var3 = "".length();

      do {
         if (var3 >= var2.tagCount()) {
            return;
         }

         this.theScoreboard.addPlayerToTeam(var2.getStringTagAt(var3), var1.getRegisteredName());
         I[85 ^ 77].length();
         ++var3;
         "".length();
      } while(2 >= 0);

      throw null;
   }

   public ScoreboardSaveData() {
      this(I["".length()]);
   }

   protected void readDisplayConfig(NBTTagCompound var1) {
      String var10000 = I[68 ^ 93];
      String var10001 = I[61 ^ 39];
      String var10002 = I[56 ^ 35];
      var10001 = I[38 ^ 58];
      var10000 = I[16 ^ 13];
      var10001 = I[182 ^ 168];
      var10002 = I[47 ^ 48];
      var10001 = I[4 ^ 36];
      int var2 = "".length();

      do {
         if (var2 >= (81 ^ 66)) {
            return;
         }

         I[74 ^ 107].length();
         if (var1.hasKey(I[17 ^ 51] + var2, 147 ^ 155)) {
            I[106 ^ 73].length();
            I[126 ^ 90].length();
            I[78 ^ 107].length();
            I[162 ^ 132].length();
            String var3 = var1.getString(I[164 ^ 131] + var2);
            ScoreObjective var4 = this.theScoreboard.getObjective(var3);
            this.theScoreboard.setObjectiveInDisplaySlot(var2, var4);
         }

         ++var2;
         "".length();
      } while(3 == 3);

      throw null;
   }

   protected void readObjectives(NBTTagList var1) {
      int var2 = "".length();

      do {
         if (var2 >= var1.tagCount()) {
            return;
         }

         NBTTagCompound var3 = var1.getCompoundTagAt(var2);
         IScoreCriteria var4 = (IScoreCriteria)IScoreCriteria.INSTANCES.get(var3.getString(I[103 ^ 79]));
         if (var4 != null) {
            String var5 = var3.getString(I[123 ^ 82]);
            if (var5.length() > (63 ^ 47)) {
               var5 = var5.substring("".length(), 9 ^ 25);
            }

            ScoreObjective var6 = this.theScoreboard.addScoreObjective(var5, var4);
            var6.setDisplayName(var3.getString(I[117 ^ 95]));
            var6.setRenderType(IScoreCriteria.EnumRenderType.getByName(var3.getString(I[163 ^ 136])));
         }

         ++var2;
         "".length();
      } while(-1 != 1);

      throw null;
   }

   protected NBTTagList scoresToNbt() {
      String var10000 = I[97 ^ 24];
      String var10001 = I[121 ^ 3];
      String var10002 = I[72 ^ 51];
      var10001 = I[2 ^ 126];
      var10000 = I[97 ^ 28];
      var10001 = I[82 ^ 44];
      var10002 = I[18 + 38 - 25 + 96];
      var10001 = I[23 + 127 - 35 + 13];
      I[36 + 71 - -21 + 1].length();
      I[117 + 40 - 91 + 64].length();
      NBTTagList var1 = new NBTTagList();
      Iterator var2 = this.theScoreboard.getScores().iterator();

      do {
         if (!var2.hasNext()) {
            return var1;
         }

         Score var3 = (Score)var2.next();
         if (var3.getObjective() != null) {
            I[82 + 1 - 28 + 76].length();
            NBTTagCompound var4 = new NBTTagCompound();
            var4.setString(I[81 + 25 - 52 + 78], var3.getPlayerName());
            var4.setString(I[112 + 71 - 139 + 89], var3.getObjective().getName());
            var4.setInteger(I[79 + 57 - 19 + 17], var3.getScorePoints());
            var4.setBoolean(I[37 + 3 - -23 + 72], var3.isLocked());
            var1.appendTag(var4);
         }

         "".length();
      } while(3 == 3);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 0);

      throw null;
   }

   public void setScoreboard(Scoreboard var1) {
      this.theScoreboard = var1;
      if (this.delayedInitNbt != null) {
         this.readFromNBT(this.delayedInitNbt);
      }

   }

   protected void readTeams(NBTTagList var1) {
      int var2 = "".length();

      do {
         if (var2 >= var1.tagCount()) {
            return;
         }

         NBTTagCompound var3 = var1.getCompoundTagAt(var2);
         String var4 = var3.getString(I[88 ^ 95]);
         if (var4.length() > (75 ^ 91)) {
            var4 = var4.substring("".length(), 189 ^ 173);
         }

         ScorePlayerTeam var5 = this.theScoreboard.createTeam(var4);
         String var6 = var3.getString(I[93 ^ 85]);
         if (var6.length() > (191 ^ 159)) {
            var6 = var6.substring("".length(), 118 ^ 86);
         }

         var5.setTeamName(var6);
         if (var3.hasKey(I[129 ^ 136], 76 ^ 68)) {
            var5.setChatFormat(TextFormatting.getValueByName(var3.getString(I[60 ^ 54])));
         }

         var5.setNamePrefix(var3.getString(I[50 ^ 57]));
         var5.setNameSuffix(var3.getString(I[181 ^ 185]));
         if (var3.hasKey(I[159 ^ 146], 45 ^ 78)) {
            var5.setAllowFriendlyFire(var3.getBoolean(I[14 ^ 0]));
         }

         if (var3.hasKey(I[101 ^ 106], 57 ^ 90)) {
            var5.setSeeFriendlyInvisiblesEnabled(var3.getBoolean(I[168 ^ 184]));
         }

         Team.EnumVisible var7;
         if (var3.hasKey(I[73 ^ 88], 134 ^ 142)) {
            var7 = Team.EnumVisible.getByName(var3.getString(I[184 ^ 170]));
            if (var7 != null) {
               var5.setNameTagVisibility(var7);
            }
         }

         if (var3.hasKey(I[17 ^ 2], 173 ^ 165)) {
            var7 = Team.EnumVisible.getByName(var3.getString(I[129 ^ 149]));
            if (var7 != null) {
               var5.setDeathMessageVisibility(var7);
            }
         }

         if (var3.hasKey(I[61 ^ 40], 78 ^ 70)) {
            Team.CollisionRule var8 = Team.CollisionRule.getByName(var3.getString(I[27 ^ 13]));
            if (var8 != null) {
               var5.setCollisionRule(var8);
            }
         }

         this.loadTeamPlayers(var5, var3.getTagList(I[164 ^ 179], 110 ^ 102));
         ++var2;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   protected void fillInDisplaySlots(NBTTagCompound var1) {
      String var10000 = I[207 ^ 149];
      String var10001 = I[206 ^ 149];
      String var10002 = I[229 ^ 185];
      var10001 = I[69 ^ 24];
      var10000 = I[68 ^ 26];
      var10001 = I[196 ^ 155];
      var10002 = I[117 ^ 21];
      var10001 = I[16 ^ 113];
      I[56 ^ 90].length();
      I[2 ^ 97].length();
      I[231 ^ 131].length();
      NBTTagCompound var2 = new NBTTagCompound();
      int var3 = "".length();
      int var4 = "".length();

      do {
         if (var4 >= (13 ^ 30)) {
            if (var3 != 0) {
               var1.setTag(I[68 ^ 35], var2);
            }

            return;
         }

         ScoreObjective var5 = this.theScoreboard.getObjectiveInDisplaySlot(var4);
         if (var5 != null) {
            I[27 ^ 126].length();
            var2.setString(I[202 ^ 172] + var4, var5.getName());
            var3 = " ".length();
         }

         ++var4;
         "".length();
      } while(2 == 2);

      throw null;
   }
}

package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRotatedPillar extends Block {
   // $FF: synthetic field
   public static final PropertyEnum<EnumFacing.Axis> AXIS;
   // $FF: synthetic field
   private static final String[] I;

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      EnumFacing.Axis var3 = (EnumFacing.Axis)var1.getValue(AXIS);
      if (var3 == EnumFacing.Axis.X) {
         var2 |= 37 ^ 33;
         "".length();
         if (4 < 2) {
            throw null;
         }
      } else if (var3 == EnumFacing.Axis.Z) {
         var2 |= 190 ^ 182;
      }

      return var2;
   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I[31 ^ 16];
      String var10001 = I[163 ^ 179];
      String var10002 = I[43 ^ 58];
      var10001 = I[44 ^ 62];
      I[125 ^ 110].length();
      I[209 ^ 197].length();
      return new ItemStack(Item.getItemFromBlock(this));
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return super.getStateForPlacement(var1, var2, var3, var4, var5, var6, var7, var8).withProperty(AXIS, var3.getAxis());
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 3);

      throw null;
   }

   protected BlockRotatedPillar(Material var1) {
      super(var1, var1.getMaterialMapColor());
   }

   protected BlockRotatedPillar(Material var1, MapColor var2) {
      super(var1, var2);
   }

   static {
      I();
      AXIS = PropertyEnum.create(I[151 ^ 130], EnumFacing.Axis.class);
   }

   public IBlockState getStateFromMeta(int var1) {
      EnumFacing.Axis var2 = EnumFacing.Axis.Y;
      int var3 = var1 & (143 ^ 131);
      if (var3 == (102 ^ 98)) {
         var2 = EnumFacing.Axis.X;
         "".length();
         if (1 == 3) {
            throw null;
         }
      } else if (var3 == (185 ^ 177)) {
         var2 = EnumFacing.Axis.Z;
      }

      return this.getDefaultState().withProperty(AXIS, var2);
   }

   private static void I() {
      I = new String[154 ^ 140];
      I["".length()] = I("捙潨", "ZwGHf");
      I[" ".length()] = I("澸澺", "FUMyG");
      I["  ".length()] = I("毐沊", "ADYsy");
      I["   ".length()] = I("僻汰", "nphuH");
      I[26 ^ 30] = I("晳峩", "sILrh");
      I[48 ^ 53] = I("切桍", "kmdsV");
      I[132 ^ 130] = I("櫨媛", "sLkJh");
      I[16 ^ 23] = I("炋峭", "JACCI");
      I[152 ^ 144] = I("淘", "zGCaE");
      I[180 ^ 189] = I("嘴恖徾仧", "plmIn");
      I[178 ^ 184] = I("恐坧檕", "StYRX");
      I[102 ^ 109] = I("垺椎捿儾", "LmBfU");
      I[170 ^ 166] = I("昏", "JicKn");
      I[24 ^ 21] = I("泘徺", "duTkD");
      I[37 ^ 43] = I("櫯", "Vtfln");
      I[108 ^ 99] = I("傽慚", "OfjGb");
      I[179 ^ 163] = I("仝旯", "YytpM");
      I[112 ^ 97] = I("時吜", "XZTzk");
      I[215 ^ 197] = I("嶣匠", "oyblH");
      I[52 ^ 39] = I("枌形嫧懭", "CJFxf");
      I[90 ^ 78] = I("冷", "NIfIU");
      I[17 ^ 4] = I("\u00053\u000e5", "dKgFB");
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
      case 2:
         switch(null.$SwitchMap$net$minecraft$util$EnumFacing$Axis[((EnumFacing.Axis)var1.getValue(AXIS)).ordinal()]) {
         case 1:
            return var1.withProperty(AXIS, EnumFacing.Axis.Z);
         case 2:
            return var1.withProperty(AXIS, EnumFacing.Axis.X);
         default:
            return var1;
         }
      default:
         return var1;
      }
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[11 ^ 15];
      var10001 = I[9 ^ 12];
      var10002 = I[62 ^ 56];
      var10001 = I[135 ^ 128];
      I[152 ^ 144].length();
      I[44 ^ 37].length();
      I[48 ^ 58].length();
      I[109 ^ 102].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[62 ^ 50].length();
      I[53 ^ 56].length();
      I[120 ^ 118].length();
      var10003["".length()] = AXIS;
      return new BlockStateContainer(this, var10003);
   }
}

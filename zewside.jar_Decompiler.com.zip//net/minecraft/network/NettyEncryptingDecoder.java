package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.ShortBufferException;

public class NettyEncryptingDecoder extends MessageToMessageDecoder<ByteBuf> {
   // $FF: synthetic field
   private final NettyEncryptionTranslator decryptionCodec;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 3);

      throw null;
   }

   public NettyEncryptingDecoder(Cipher var1) {
      this.decryptionCodec = new NettyEncryptionTranslator(var1);
   }

   static {
      I();
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("杈", "EnboO");
      I[" ".length()] = I("恢", "ZaeyD");
      I["  ".length()] = I("局姚扥", "WUtxS");
   }

   protected void decode(ChannelHandlerContext var1, ByteBuf var2, List<Object> var3) throws ShortBufferException, Exception {
      var3.add(this.decryptionCodec.decipher(var1, var2));
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }
}

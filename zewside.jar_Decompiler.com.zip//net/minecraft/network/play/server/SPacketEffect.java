package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;

public class SPacketEffect implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int soundData;
   // $FF: synthetic field
   private int soundType;
   // $FF: synthetic field
   private BlockPos soundPos;
   // $FF: synthetic field
   private boolean serverWide;

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.soundType = var1.readInt();
      this.soundPos = var1.readBlockPos();
      this.soundData = var1.readInt();
      this.serverWide = var1.readBoolean();
   }

   public boolean isSoundServerwide() {
      return this.serverWide;
   }

   public SPacketEffect() {
   }

   static {
      I();
   }

   public int getSoundData() {
      return this.soundData;
   }

   public SPacketEffect(int var1, BlockPos var2, int var3, boolean var4) {
      this.soundType = var1;
      this.soundPos = var2;
      this.soundData = var3;
      this.serverWide = var4;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 2);

      throw null;
   }

   public BlockPos getSoundPos() {
      return this.soundPos;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEffect(this);
   }

   public int getSoundType() {
      return this.soundType;
   }

   private static void I() {
      I = new String[65 ^ 71];
      I["".length()] = I("嫓憸昤椶", "IKsTJ");
      I[" ".length()] = I("兣夞勏勸损", "rqsmg");
      I["  ".length()] = I("懊", "pROth");
      I["   ".length()] = I("怯滐搏槥", "GlrbK");
      I[100 ^ 96] = I("呶坲汸湃掟", "acuFE");
      I[189 ^ 184] = I("瀼埚巷潓揙", "DyLLr");
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeInt(this.soundType);
      I["".length()].length();
      var1.writeBlockPos(this.soundPos);
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeInt(this.soundData);
      I["   ".length()].length();
      var1.writeBoolean(this.serverWide);
      I[196 ^ 192].length();
      I[89 ^ 92].length();
   }
}

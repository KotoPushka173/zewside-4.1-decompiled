package net.minecraft.network.login.server;

import java.io.IOException;
import java.security.PublicKey;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.login.INetHandlerLoginClient;
import net.minecraft.util.CryptManager;

public class SPacketEncryptionRequest implements Packet<INetHandlerLoginClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private PublicKey publicKey;
   // $FF: synthetic field
   private byte[] verifyToken;
   // $FF: synthetic field
   private String hashedServerId;

   private static void I() {
      I = new String[164 ^ 172];
      I["".length()] = I("愵滻型彖", "VBltM");
      I[" ".length()] = I("嘛梧枻", "MFlGy");
      I["  ".length()] = I("滶毾塱涄", "rHpnH");
      I["   ".length()] = I("檊効劥", "PLQKo");
      I[122 ^ 126] = I("杍丝欰", "EMHyp");
      I[52 ^ 49] = I("徍桲梔浑楛", "mYAqU");
      I[135 ^ 129] = I("殃炐丶泶愤", "YOXPz");
      I[179 ^ 180] = I("森壟", "PEjWk");
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.hashedServerId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeByteArray(this.publicKey.getEncoded());
      I[60 ^ 56].length();
      var1.writeByteArray(this.verifyToken);
      I[80 ^ 85].length();
      I[52 ^ 50].length();
      I[45 ^ 42].length();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.hashedServerId = var1.readStringFromBuffer(60 ^ 40);
      this.publicKey = CryptManager.decodePublicKey(var1.readByteArray());
      this.verifyToken = var1.readByteArray();
   }

   public SPacketEncryptionRequest(String var1, PublicKey var2, byte[] var3) {
      this.hashedServerId = var1;
      this.publicKey = var2;
      this.verifyToken = var3;
   }

   public String getServerId() {
      return this.hashedServerId;
   }

   public void processPacket(INetHandlerLoginClient var1) {
      var1.handleEncryptionRequest(this);
   }

   public SPacketEncryptionRequest() {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 2);

      throw null;
   }

   public byte[] getVerifyToken() {
      return this.verifyToken;
   }

   public PublicKey getPublicKey() {
      return this.publicKey;
   }
}

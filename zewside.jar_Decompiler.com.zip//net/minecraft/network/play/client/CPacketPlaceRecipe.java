package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketPlaceRecipe implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private IRecipe field_194321_b;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private boolean field_194322_c;
   // $FF: synthetic field
   private int field_194320_a;

   public CPacketPlaceRecipe() {
   }

   public boolean func_194319_c() {
      return this.field_194322_c;
   }

   public CPacketPlaceRecipe(int var1, IRecipe var2, boolean var3) {
      this.field_194320_a = var1;
      this.field_194321_b = var2;
      this.field_194322_c = var3;
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != 3);

      throw null;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.func_194308_a(this);
   }

   private static void I() {
      I = new String[80 ^ 86];
      I["".length()] = I("喬侸", "uKDIi");
      I[" ".length()] = I("災", "LATYN");
      I["  ".length()] = I("杕喝板滫", "BZvhR");
      I["   ".length()] = I("灐桘", "vLMoz");
      I[75 ^ 79] = I("枺嶏剓榷", "jqWrX");
      I[33 ^ 36] = I("亄汴汦尦", "RwGZs");
   }

   public int func_194318_a() {
      return this.field_194320_a;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.field_194320_a = var1.readByte();
      this.field_194321_b = CraftingManager.func_193374_a(var1.readVarIntFromBuffer());
      this.field_194322_c = var1.readBoolean();
   }

   public IRecipe func_194317_b() {
      return this.field_194321_b;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.field_194320_a);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeVarIntToBuffer(CraftingManager.func_193375_a(this.field_194321_b));
      I["   ".length()].length();
      I[140 ^ 136].length();
      var1.writeBoolean(this.field_194322_c);
      I[192 ^ 197].length();
   }
}

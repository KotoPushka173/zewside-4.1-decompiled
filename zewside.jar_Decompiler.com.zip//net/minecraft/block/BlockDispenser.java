package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
import net.minecraft.dispenser.IBehaviorDispenseItem;
import net.minecraft.dispenser.IBlockSource;
import net.minecraft.dispenser.IPosition;
import net.minecraft.dispenser.PositionImpl;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityDropper;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.RegistryDefaulted;
import net.minecraft.world.World;

public class BlockDispenser extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected Random rand = new Random();
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   public static final RegistryDefaulted<Item, IBehaviorDispenseItem> DISPENSE_BEHAVIOR_REGISTRY;
   // $FF: synthetic field
   public static final PropertyBool TRIGGERED;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, EnumFacing.getFront(var1 & (75 ^ 76)));
      PropertyBool var10001 = TRIGGERED;
      int var10002;
      if ((var1 & (22 ^ 30)) > 0) {
         var10002 = " ".length();
         "".length();
         if (1 < 0) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public static IPosition getDispensePosition(IBlockSource var0) {
      String var10000 = I[99 ^ 116];
      String var10001 = I[151 ^ 143];
      String var10002 = I[111 ^ 118];
      var10001 = I[106 ^ 112];
      EnumFacing var1 = (EnumFacing)var0.getBlockState().getValue(FACING);
      double var2 = var0.getX() + 0.7D * (double)var1.getFrontOffsetX();
      double var4 = var0.getY() + 0.7D * (double)var1.getFrontOffsetY();
      double var6 = var0.getZ() + 0.7D * (double)var1.getFrontOffsetZ();
      I[126 ^ 101].length();
      I[91 ^ 71].length();
      I[45 ^ 48].length();
      I[14 ^ 16].length();
      return new PositionImpl(var2, var4, var6);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   static {
      I();
      FACING = BlockDirectional.FACING;
      TRIGGERED = PropertyBool.create(I[189 ^ 140]);
      DISPENSE_BEHAVIOR_REGISTRY = new RegistryDefaulted(new BehaviorDefaultDispenseItem());
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         TileEntity var10 = var1.getTileEntity(var2);
         if (var10 instanceof TileEntityDispenser) {
            var4.displayGUIChest((TileEntityDispenser)var10);
            if (var10 instanceof TileEntityDropper) {
               var4.addStat(StatList.DROPPER_INSPECTED);
               "".length();
               if (4 < 4) {
                  throw null;
               }
            } else {
               var4.addStat(StatList.DISPENSER_INSPECTED);
            }
         }

         return (boolean)" ".length();
      }
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      return Container.calcRedstone(var2.getTileEntity(var3));
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      TileEntity var4 = var1.getTileEntity(var2);
      if (var4 instanceof TileEntityDispenser) {
         InventoryHelper.dropInventoryItems(var1, (BlockPos)var2, (TileEntityDispenser)var4);
         var1.updateComparatorOutputLevel(var2, this);
      }

      super.breakBlock(var1, var2, var3);
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[72 ^ 70];
      String var10001 = I[2 ^ 13];
      String var10002 = I[59 ^ 43];
      var10001 = I[5 ^ 20];
      I[32 ^ 50].length();
      I[184 ^ 171].length();
      I[32 ^ 52].length();
      I[149 ^ 128].length();
      return new TileEntityDispenser();
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      var1.setBlockState(var2, var3.withProperty(FACING, EnumFacing.func_190914_a(var2, var4)), "  ".length());
      I[53 ^ 35].length();
      if (var5.hasDisplayName()) {
         TileEntity var6 = var1.getTileEntity(var2);
         if (var6 instanceof TileEntityDispenser) {
            ((TileEntityDispenser)var6).func_190575_a(var5.getDisplayName());
         }
      }

   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.func_190914_a(var2, var8)).withProperty(TRIGGERED, Boolean.valueOf((boolean)"".length()));
   }

   private static void I() {
      I = new String[115 ^ 65];
      I["".length()] = I("媏卖灮几", "soSax");
      I[" ".length()] = I("濧烞咡棖", "ZLCar");
      I["  ".length()] = I("咠涴", "mrJRZ");
      I["   ".length()] = I("煌呖", "cUNaT");
      I[180 ^ 176] = I("僡攒", "irxVz");
      I[170 ^ 175] = I("斅枇", "GyJXY");
      I[0 ^ 6] = I("叏克", "fdQra");
      I[161 ^ 166] = I("暝朙", "uRPEC");
      I[118 ^ 126] = I("又埛参昭烞", "zSpRI");
      I[0 ^ 9] = I("峸浍拋媿桒", "osJPR");
      I[128 ^ 138] = I("币烺恇炏", "gwbRR");
      I[111 ^ 100] = I("信幷啽嫉灟", "tgrwC");
      I[131 ^ 143] = I("淹岛徰柪", "LllMD");
      I[189 ^ 176] = I("僀塚斾", "jTAAe");
      I[152 ^ 150] = I("庡潚", "PTFVD");
      I[132 ^ 139] = I("拾它", "tjgmY");
      I[60 ^ 44] = I("勛勴", "sWUQi");
      I[104 ^ 121] = I("垝滞", "lYDvI");
      I[35 ^ 49] = I("儼宬冀", "WbrFP");
      I[102 ^ 117] = I("墿", "zOEkw");
      I[77 ^ 89] = I("忆坿勴", "wpTcf");
      I[214 ^ 195] = I("潢宥", "CKxLZ");
      I[75 ^ 93] = I("呍噀亏嵇", "uAmGb");
      I[81 ^ 70] = I("欣暧", "tjoZs");
      I[179 ^ 171] = I("勑憼", "lSriI");
      I[172 ^ 181] = I("掜岻", "IWCgg");
      I[82 ^ 72] = I("昲氾", "ORjAE");
      I[175 ^ 180] = I("惞婴奣宻捾", "RpKiX");
      I[125 ^ 97] = I("保湁慮梥拻", "cAfux");
      I[2 ^ 31] = I("枰侽", "BhNtF");
      I[6 ^ 24] = I("歘", "SPNtY");
      I[33 ^ 62] = I("徔庀", "VBjwg");
      I[228 ^ 196] = I("瀗攱", "VJcJO");
      I[156 ^ 189] = I("川囋", "YyzEw");
      I[162 ^ 128] = I("圄幾", "IVBbv");
      I[138 ^ 169] = I("嗯嘬", "dNlJt");
      I[41 ^ 13] = I("恶暷", "mHSIr");
      I[77 ^ 104] = I("櫏彊", "AoFYc");
      I[114 ^ 84] = I("屃洠", "SVxXT");
      I[146 ^ 181] = I("烠煠", "zlfkV");
      I[185 ^ 145] = I("塯倄", "HaAxv");
      I[126 ^ 87] = I("淅倦", "MxOXH");
      I[167 ^ 141] = I("殽午", "vpYBZ");
      I[108 ^ 71] = I("凧剙漸洐櫴", "oQMcG");
      I[47 ^ 3] = I("劬", "TRcqJ");
      I[41 ^ 4] = I("怷嫾叫", "Iimbv");
      I[159 ^ 177] = I("湼洫偒咆塯", "UUKpN");
      I[47 ^ 0] = I("拸彰庩仸则", "IyWhI");
      I[22 ^ 38] = I("墳便刕梾", "OugFv");
      I[184 ^ 137] = I("16-/\u0014 6!,", "EDDHs");
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      super.onBlockAdded(var1, var2, var3);
      this.setDefaultDirection(var1, var2, var3);
   }

   protected void dispense(World var1, BlockPos var2) {
      String var10000 = I["   ".length()];
      String var10001 = I[183 ^ 179];
      String var10002 = I[91 ^ 94];
      var10001 = I[27 ^ 29];
      I[50 ^ 53].length();
      I[31 ^ 23].length();
      BlockSourceImpl var3 = new BlockSourceImpl(var1, var2);
      TileEntityDispenser var4 = (TileEntityDispenser)var3.getBlockTileEntity();
      if (var4 != null) {
         int var5 = var4.getDispenseSlot();
         if (var5 < 0) {
            var1.playEvent(685 + 630 - 1076 + 762, var2, "".length());
            "".length();
            if (4 <= 3) {
               throw null;
            }
         } else {
            ItemStack var6 = var4.getStackInSlot(var5);
            IBehaviorDispenseItem var7 = this.getBehavior(var6);
            if (var7 != IBehaviorDispenseItem.DEFAULT_BEHAVIOR) {
               var4.setInventorySlotContents(var5, var7.dispense(var3, var6));
            }
         }
      }

   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getIndex();
      if ((Boolean)var1.getValue(TRIGGERED)) {
         var2 |= 118 ^ 126;
      }

      return var2;
   }

   protected BlockDispenser() {
      super(Material.ROCK);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(TRIGGERED, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.REDSTONE);
   }

   public int tickRate(World var1) {
      return 22 ^ 18;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote) {
         this.dispense(var1, var2);
      }

   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      int var10000;
      if (!var2.isBlockPowered(var3) && !var2.isBlockPowered(var3.up())) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (-1 != -1) {
            throw null;
         }
      }

      int var6 = var10000;
      boolean var7 = (Boolean)var1.getValue(TRIGGERED);
      if (var6 != 0 && !var7) {
         var2.scheduleUpdate(var3, this, this.tickRate(var2));
         var2.setBlockState(var3, var1.withProperty(TRIGGERED, Boolean.valueOf((boolean)" ".length())), 31 ^ 27);
         I[123 ^ 114].length();
         I[150 ^ 156].length();
         I[191 ^ 180].length();
         "".length();
         if (2 == -1) {
            throw null;
         }
      } else if (var6 == 0 && var7) {
         var2.setBlockState(var3, var1.withProperty(TRIGGERED, Boolean.valueOf((boolean)"".length())), 191 ^ 187);
         I[138 ^ 134].length();
         I[17 ^ 28].length();
      }

   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[26 ^ 5];
      String var10001 = I[21 ^ 53];
      String var10002 = I[60 ^ 29];
      var10001 = I[99 ^ 65];
      var10000 = I[68 ^ 103];
      var10001 = I[89 ^ 125];
      var10002 = I[28 ^ 57];
      var10001 = I[28 ^ 58];
      var10000 = I[1 ^ 38];
      var10001 = I[140 ^ 164];
      var10002 = I[237 ^ 196];
      var10001 = I[35 ^ 9];
      I[129 ^ 170].length();
      I[116 ^ 88].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[96 ^ 77].length();
      I[36 ^ 10].length();
      var10003["".length()] = FACING;
      I[101 ^ 74].length();
      I[100 ^ 84].length();
      var10003[" ".length()] = TRIGGERED;
      return new BlockStateContainer(this, var10003);
   }

   private void setDefaultDirection(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         EnumFacing var4 = (EnumFacing)var3.getValue(FACING);
         boolean var5 = var1.getBlockState(var2.north()).isFullBlock();
         boolean var6 = var1.getBlockState(var2.south()).isFullBlock();
         if (var4 == EnumFacing.NORTH && var5 && !var6) {
            var4 = EnumFacing.SOUTH;
            "".length();
            if (1 == -1) {
               throw null;
            }
         } else if (var4 == EnumFacing.SOUTH && var6 && !var5) {
            var4 = EnumFacing.NORTH;
            "".length();
            if (2 < 2) {
               throw null;
            }
         } else {
            boolean var7 = var1.getBlockState(var2.west()).isFullBlock();
            boolean var8 = var1.getBlockState(var2.east()).isFullBlock();
            if (var4 == EnumFacing.WEST && var7 && !var8) {
               var4 = EnumFacing.EAST;
               "".length();
               if (false) {
                  throw null;
               }
            } else if (var4 == EnumFacing.EAST && var8 && !var7) {
               var4 = EnumFacing.WEST;
            }
         }

         var1.setBlockState(var2, var3.withProperty(FACING, var4).withProperty(TRIGGERED, Boolean.valueOf((boolean)"".length())), "  ".length());
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }

   }

   protected IBehaviorDispenseItem getBehavior(ItemStack var1) {
      return (IBehaviorDispenseItem)DISPENSE_BEHAVIOR_REGISTRY.getObject(var1.getItem());
   }
}

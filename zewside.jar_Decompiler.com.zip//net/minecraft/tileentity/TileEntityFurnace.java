package net.minecraft.tileentity;

import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFurnace;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerFurnace;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.inventory.SlotFurnaceFuel;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBoat;
import net.minecraft.item.ItemDoor;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraft.util.math.MathHelper;

public class TileEntityFurnace extends TileEntityLockable implements ITickable, ISidedInventory {
   // $FF: synthetic field
   private static final int[] SLOTS_SIDES;
   // $FF: synthetic field
   private int totalCookTime;
   // $FF: synthetic field
   private String furnaceCustomName;
   // $FF: synthetic field
   private int furnaceBurnTime;
   // $FF: synthetic field
   private NonNullList<ItemStack> furnaceItemStacks;
   // $FF: synthetic field
   private static final int[] SLOTS_TOP;
   // $FF: synthetic field
   private int currentItemBurnTime;
   // $FF: synthetic field
   private static final int[] SLOTS_BOTTOM;
   // $FF: synthetic field
   private int cookTime;
   // $FF: synthetic field
   private static final String[] I;

   public static boolean isBurning(IInventory var0) {
      int var10000;
      if (var0.getField("".length()) > 0) {
         var10000 = " ".length();
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static boolean isItemFuel(ItemStack var0) {
      int var10000;
      if (getItemBurnTime(var0) > 0) {
         var10000 = " ".length();
         "".length();
         if (0 >= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   static {
      I();
      int[] var10000 = new int[" ".length()];
      var10000["".length()] = "".length();
      SLOTS_TOP = var10000;
      var10000 = new int["  ".length()];
      var10000["".length()] = "  ".length();
      var10000[" ".length()] = " ".length();
      SLOTS_BOTTOM = var10000;
      var10000 = new int[" ".length()];
      var10000["".length()] = " ".length();
      SLOTS_SIDES = var10000;
   }

   private boolean canSmelt() {
      if (((ItemStack)this.furnaceItemStacks.get("".length())).isEmpty()) {
         return (boolean)"".length();
      } else {
         ItemStack var1 = FurnaceRecipes.instance().getSmeltingResult((ItemStack)this.furnaceItemStacks.get("".length()));
         if (var1.isEmpty()) {
            return (boolean)"".length();
         } else {
            ItemStack var2 = (ItemStack)this.furnaceItemStacks.get("  ".length());
            if (var2.isEmpty()) {
               return (boolean)" ".length();
            } else if (!var2.isItemEqual(var1)) {
               return (boolean)"".length();
            } else if (var2.func_190916_E() < this.getInventoryStackLimit() && var2.func_190916_E() < var2.getMaxStackSize()) {
               return (boolean)" ".length();
            } else {
               int var10000;
               if (var2.func_190916_E() < var1.getMaxStackSize()) {
                  var10000 = " ".length();
                  "".length();
                  if (-1 != -1) {
                     throw null;
                  }
               } else {
                  var10000 = "".length();
               }

               return (boolean)var10000;
            }
         }
      }
   }

   public boolean isBurning() {
      int var10000;
      if (this.furnaceBurnTime > 0) {
         var10000 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public void openInventory(EntityPlayer var1) {
   }

   public String getName() {
      String var10000;
      if (this.hasCustomName()) {
         var10000 = this.furnaceCustomName;
         "".length();
         if (0 <= -1) {
            throw null;
         }
      } else {
         var10000 = I["   ".length()];
      }

      return var10000;
   }

   public String getGuiID() {
      return I[76 ^ 3];
   }

   public static void registerFixesFurnace(DataFixer var0) {
      String var10000 = I[67 ^ 71];
      String var10001 = I[184 ^ 189];
      String var10002 = I[39 ^ 33];
      var10001 = I[138 ^ 141];
      var10000 = I[14 ^ 6];
      var10001 = I[80 ^ 89];
      var10002 = I[186 ^ 176];
      var10001 = I[123 ^ 112];
      FixTypes var1 = FixTypes.BLOCK_ENTITY;
      I[62 ^ 50].length();
      String[] var10005 = new String[" ".length()];
      I[132 ^ 137].length();
      var10005["".length()] = I[38 ^ 40];
      var0.registerWalker(var1, new ItemStackDataLists(TileEntityFurnace.class, var10005));
   }

   public void update() {
      String var10000 = I[50 ^ 44];
      String var10001 = I[26 ^ 5];
      String var10002 = I[66 ^ 98];
      var10001 = I[22 ^ 55];
      var10000 = I[167 ^ 133];
      var10001 = I[45 ^ 14];
      var10002 = I[47 ^ 11];
      var10001 = I[139 ^ 174];
      var10000 = I[76 ^ 106];
      var10001 = I[191 ^ 152];
      var10002 = I[176 ^ 152];
      var10001 = I[42 ^ 3];
      boolean var1 = this.isBurning();
      int var2 = "".length();
      int var7;
      int var8;
      if (this.isBurning()) {
         I[19 ^ 57].length();
         I[77 ^ 102].length();
         I[87 ^ 123].length();
         I[46 ^ 3].length();
         I[0 ^ 46].length();
         var7 = this.furnaceBurnTime;
         var8 = " ".length();
         I[139 ^ 164].length();
         I[191 ^ 143].length();
         this.furnaceBurnTime = var7 - var8;
      }

      if (!this.world.isRemote) {
         ItemStack var3 = (ItemStack)this.furnaceItemStacks.get(" ".length());
         if (this.isBurning() || !var3.isEmpty() && !((ItemStack)this.furnaceItemStacks.get("".length())).isEmpty()) {
            if (!this.isBurning() && this.canSmelt()) {
               this.furnaceBurnTime = getItemBurnTime(var3);
               this.currentItemBurnTime = this.furnaceBurnTime;
               if (this.isBurning()) {
                  var2 = " ".length();
                  if (!var3.isEmpty()) {
                     Item var4 = var3.getItem();
                     var3.func_190918_g(" ".length());
                     if (var3.isEmpty()) {
                        Item var5 = var4.getContainerItem();
                        NonNullList var6 = this.furnaceItemStacks;
                        var7 = " ".length();
                        ItemStack var9;
                        if (var5 == null) {
                           var9 = ItemStack.field_190927_a;
                           "".length();
                           if (-1 != -1) {
                              throw null;
                           }
                        } else {
                           I[101 ^ 84].length();
                           I[44 ^ 30].length();
                           var9 = new ItemStack(var5);
                        }

                        var6.set(var7, var9);
                        I[78 ^ 125].length();
                        I[92 ^ 104].length();
                        I[108 ^ 89].length();
                     }
                  }
               }
            }

            if (this.isBurning() && this.canSmelt()) {
               I[115 ^ 69].length();
               I[163 ^ 148].length();
               I[20 ^ 44].length();
               I[171 ^ 146].length();
               this.cookTime += " ".length();
               if (this.cookTime == this.totalCookTime) {
                  this.cookTime = "".length();
                  this.totalCookTime = this.getCookTime((ItemStack)this.furnaceItemStacks.get("".length()));
                  this.smeltItem();
                  var2 = " ".length();
                  "".length();
                  if (3 != 3) {
                     throw null;
                  }
               }
            } else {
               this.cookTime = "".length();
               "".length();
               if (4 < 2) {
                  throw null;
               }
            }
         } else if (!this.isBurning() && this.cookTime > 0) {
            var7 = this.cookTime;
            var8 = "  ".length();
            I[86 ^ 108].length();
            I[117 ^ 78].length();
            I[104 ^ 84].length();
            I[10 ^ 55].length();
            this.cookTime = MathHelper.clamp(var7 - var8, "".length(), this.totalCookTime);
         }

         if (var1 != this.isBurning()) {
            var2 = " ".length();
            BlockFurnace.setState(this.isBurning(), this.world, this.pos);
         }
      }

      if (var2 != 0) {
         this.markDirty();
      }

   }

   public boolean canExtractItem(int var1, ItemStack var2, EnumFacing var3) {
      if (var3 == EnumFacing.DOWN && var1 == " ".length()) {
         Item var4 = var2.getItem();
         if (var4 != Items.WATER_BUCKET && var4 != Items.BUCKET) {
            return (boolean)"".length();
         }
      }

      return (boolean)" ".length();
   }

   public int getInventoryStackLimit() {
      return 218 ^ 154;
   }

   public void setCustomInventoryName(String var1) {
      this.furnaceCustomName = var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public boolean isItemValidForSlot(int var1, ItemStack var2) {
      if (var1 == "  ".length()) {
         return (boolean)"".length();
      } else if (var1 != " ".length()) {
         return (boolean)" ".length();
      } else {
         ItemStack var3 = (ItemStack)this.furnaceItemStacks.get(" ".length());
         int var10000;
         if (isItemFuel(var2) || SlotFurnaceFuel.isBucket(var2) && var3.getItem() != Items.BUCKET) {
            var10000 = " ".length();
            "".length();
            if (1 >= 3) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public TileEntityFurnace() {
      this.furnaceItemStacks = NonNullList.func_191197_a("   ".length(), ItemStack.field_190927_a);
   }

   public void closeInventory(EntityPlayer var1) {
   }

   private static void I() {
      I = new String[5 ^ 80];
      I["".length()] = I("恄冃", "aknUC");
      I[" ".length()] = I("摧欳夀彧伮", "qnGAr");
      I["  ".length()] = I("栟", "pBVNX");
      I["   ".length()] = I("\"%\u0000.\u0005($\u000b(J'?\u001c4\u0005\"/", "AJnZd");
      I[176 ^ 180] = I("渪开", "fOPyl");
      I[174 ^ 171] = I("勷应", "xGcKu");
      I[152 ^ 158] = I("桨渍", "sGJoW");
      I[82 ^ 85] = I("峴孍", "TXmRp");
      I[74 ^ 66] = I("灯塲", "ZGMur");
      I[157 ^ 148] = I("炶倖", "jOZZY");
      I[182 ^ 188] = I("檹徬", "EPtqW");
      I[13 ^ 6] = I("媼慨", "sdSfo");
      I[44 ^ 32] = I("勱", "jAGuK");
      I[205 ^ 192] = I("櫥唂", "EJElC");
      I[20 ^ 26] = I("%\u001d\u000e\t\u0017", "likdd");
      I[152 ^ 151] = I("&9\u0007;$\r!\u0010", "dLuUp");
      I[147 ^ 131] = I("\u000e6\u0004/3$4\u000e", "MYkDg");
      I[10 ^ 27] = I("4\u0007!-\u0016\u001e\u0005+\u0012-\u0003\t\"", "whNFB");
      I[5 ^ 23] = I("%\u0002?\u0019(\u000b9-\u0000\"", "fwLmG");
      I[191 ^ 172] = I("\u0007#\u00001=)\u0018\u0012(7", "DVsER");
      I[187 ^ 175] = I("柩唂巤槌洉", "LHdBP");
      I[163 ^ 182] = I("晠", "OCfJf");
      I[170 ^ 188] = I("煀", "CAklv");
      I[73 ^ 94] = I("\u0011\f7<=:\u0014 ", "SyERi");
      I[111 ^ 119] = I("\u001b6#?\u001014)", "XYLTD");
      I[148 ^ 141] = I("\f\u0005.$\u001d&\u0007$\u001b&;\u000b-", "OjAOI");
      I[51 ^ 41] = I("噒匘樋", "jgKgz");
      I[118 ^ 109] = I("愛", "twrAS");
      I[79 ^ 83] = I("殉洘枝嚃", "ExoVH");
      I[98 ^ 127] = I("\u0015,1'#;\u0017#>)", "VYBSL");
      I[60 ^ 34] = I("滾堼", "iqiJp");
      I[67 ^ 92] = I("佗撱", "rieKq");
      I[106 ^ 74] = I("惞儃", "VAPjd");
      I[43 ^ 10] = I("嘥懞", "CvPhR");
      I[60 ^ 30] = I("伴勣", "YPIEV");
      I[63 ^ 28] = I("暼榿", "kGOrC");
      I[35 ^ 7] = I("嶖榾", "VUsmZ");
      I[37 ^ 0] = I("浒墚", "lXLgR");
      I[46 ^ 8] = I("成夀", "XEGbS");
      I[89 ^ 126] = I("勾核", "QkruG");
      I[176 ^ 152] = I("涫孙", "UExHB");
      I[99 ^ 74] = I("厃漿", "UqTaU");
      I[140 ^ 166] = I("暂个律", "APKfa");
      I[66 ^ 105] = I("涻榏檵唨垧", "idEsz");
      I[156 ^ 176] = I("枱塜宬匞匋", "SAOLc");
      I[18 ^ 63] = I("奻", "uuhUd");
      I[113 ^ 95] = I("慮壝", "gaaIX");
      I[35 ^ 12] = I("奟斟彉", "gIVfD");
      I[31 ^ 47] = I("栅啯橉橷", "hJjmF");
      I[241 ^ 192] = I("婾嘕悿咜", "dhpql");
      I[96 ^ 82] = I("咠", "wvDNe");
      I[67 ^ 112] = I("在摉掟煹沼", "LJles");
      I[91 ^ 111] = I("斍姶慬帼", "InFRM");
      I[97 ^ 84] = I("匼橉拊", "YOgNg");
      I[39 ^ 17] = I("徑", "DLoTV");
      I[162 ^ 149] = I("淣捿", "lrVYf");
      I[87 ^ 111] = I("持伖弿囔漮", "teLnE");
      I[58 ^ 3] = I("煃啝櫁", "KTvLw");
      I[102 ^ 92] = I("壤晫", "ejtiA");
      I[171 ^ 144] = I("哽嚡孬焉", "gQqKh");
      I[177 ^ 141] = I("厡撡", "vkPgH");
      I[135 ^ 186] = I("岈", "XoDUT");
      I[28 ^ 34] = I("瀯桋", "MZwxl");
      I[65 ^ 126] = I("嬩朳", "DULDn");
      I[116 ^ 52] = I("幇恏", "sSKkq");
      I[3 ^ 66] = I("媍烙", "ACenQ");
      I[17 ^ 83] = I("淜北", "LdCqL");
      I[132 ^ 199] = I("渠岠幸囘", "ptpef");
      I[9 ^ 77] = I("勥松嶦剛", "aXRro");
      I[241 ^ 180] = I("寽澿侒濥嵪", "jnfXC");
      I[38 ^ 96] = I("姷丆楆", "QdiYP");
      I[38 ^ 97] = I("啐懆墺歞", "WfHHp");
      I[10 ^ 66] = I("娩浍淨哙庾", "pvayX");
      I[212 ^ 157] = I("扣", "oyUMN");
      I[46 ^ 100] = I("檉", "qPHye");
      I[235 ^ 160] = I("峍滗叚喲榄", "wAHvn");
      I[42 ^ 102] = I("\u0014\u0019\b%", "CVGay");
      I[111 ^ 34] = I("65(\u0012", "azgVj");
      I[2 ^ 76] = I("\u0010'7!", "GhxeB");
      I[96 ^ 47] = I(".##7\u00171++&N%??<\u0015 /", "CJMRt");
      I[88 ^ 8] = I("捜樨", "fGcyj");
      I[80 ^ 1] = I("氝劗", "bsEWP");
      I[19 ^ 65] = I("煱搠", "HzVbn");
      I[21 ^ 70] = I("媎擙", "IkMEM");
      I[242 ^ 166] = I("煥埰斍", "Xagfh");
   }

   public int getCookTime(ItemStack var1) {
      return 42 + 161 - 198 + 195;
   }

   public ItemStack decrStackSize(int var1, int var2) {
      return ItemStackHelper.getAndSplit(this.furnaceItemStacks, var1, var2);
   }

   public void setField(int var1, int var2) {
      switch(var1) {
      case 0:
         this.furnaceBurnTime = var2;
         "".length();
         if (4 != 4) {
            throw null;
         }
         break;
      case 1:
         this.currentItemBurnTime = var2;
         "".length();
         if (2 >= 3) {
            throw null;
         }
         break;
      case 2:
         this.cookTime = var2;
         "".length();
         if (1 < -1) {
            throw null;
         }
         break;
      case 3:
         this.totalCookTime = var2;
      }

   }

   public boolean hasCustomName() {
      int var10000;
      if (this.furnaceCustomName != null && !this.furnaceCustomName.isEmpty()) {
         var10000 = " ".length();
         "".length();
         if (1 == -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static int getItemBurnTime(ItemStack var0) {
      if (var0.isEmpty()) {
         return "".length();
      } else {
         Item var1 = var0.getItem();
         if (var1 == Item.getItemFromBlock(Blocks.WOODEN_SLAB)) {
            return 11 + 113 - -20 + 6;
         } else if (var1 == Item.getItemFromBlock(Blocks.WOOL)) {
            return 92 ^ 56;
         } else if (var1 == Item.getItemFromBlock(Blocks.CARPET)) {
            return 234 ^ 169;
         } else if (var1 == Item.getItemFromBlock(Blocks.LADDER)) {
            return 133 + 120 - 14 + 61;
         } else if (var1 == Item.getItemFromBlock(Blocks.WOODEN_BUTTON)) {
            return 28 ^ 120;
         } else if (Block.getBlockFromItem(var1).getDefaultState().getMaterial() == Material.WOOD) {
            return 105 + 164 - 47 + 78;
         } else if (var1 == Item.getItemFromBlock(Blocks.COAL_BLOCK)) {
            return 11575 + 65 - 2964 + 7324;
         } else if (var1 instanceof ItemTool && I[117 ^ 57].equals(((ItemTool)var1).getToolMaterialName())) {
            return 59 + 83 - 9 + 67;
         } else if (var1 instanceof ItemSword && I[208 ^ 157].equals(((ItemSword)var1).getToolMaterialName())) {
            return 71 + 178 - 174 + 125;
         } else if (var1 instanceof ItemHoe && I[6 ^ 72].equals(((ItemHoe)var1).getMaterialName())) {
            return 49 + 48 - 10 + 113;
         } else if (var1 == Items.STICK) {
            return 54 ^ 82;
         } else if (var1 != Items.BOW && var1 != Items.FISHING_ROD) {
            if (var1 == Items.SIGN) {
               return 24 + 1 - -99 + 76;
            } else if (var1 == Items.COAL) {
               return 1264 + 1338 - 2046 + 1044;
            } else if (var1 == Items.LAVA_BUCKET) {
               return 11704 + 15770 - 22747 + 15273;
            } else if (var1 != Item.getItemFromBlock(Blocks.SAPLING) && var1 != Items.BOWL) {
               if (var1 == Items.BLAZE_ROD) {
                  return 853 + 1497 - 139 + 189;
               } else if (var1 instanceof ItemDoor && var1 != Items.IRON_DOOR) {
                  return 85 + 4 - 81 + 192;
               } else {
                  int var10000;
                  if (var1 instanceof ItemBoat) {
                     var10000 = 125 + 93 - 8 + 190;
                     "".length();
                     if (1 < 1) {
                        throw null;
                     }
                  } else {
                     var10000 = "".length();
                  }

                  return var10000;
               }
            } else {
               return 86 ^ 50;
            }
         } else {
            return 19 + 75 - 27 + 233;
         }
      }
   }

   public ItemStack getStackInSlot(int var1) {
      return (ItemStack)this.furnaceItemStacks.get(var1);
   }

   public boolean func_191420_l() {
      Iterator var1 = this.furnaceItemStacks.iterator();

      do {
         if (!var1.hasNext()) {
            return (boolean)" ".length();
         }

         ItemStack var2 = (ItemStack)var1.next();
         if (!var2.isEmpty()) {
            return (boolean)"".length();
         }

         "".length();
      } while(2 < 4);

      throw null;
   }

   public void smeltItem() {
      String var10000 = I[115 ^ 77];
      String var10001 = I[153 ^ 166];
      String var10002 = I[62 ^ 126];
      var10001 = I[203 ^ 138];
      if (this.canSmelt()) {
         ItemStack var1 = (ItemStack)this.furnaceItemStacks.get("".length());
         ItemStack var2 = FurnaceRecipes.instance().getSmeltingResult(var1);
         ItemStack var3 = (ItemStack)this.furnaceItemStacks.get("  ".length());
         if (var3.isEmpty()) {
            this.furnaceItemStacks.set("  ".length(), var2.copy());
            I[224 ^ 162].length();
            I[108 ^ 47].length();
            I[253 ^ 185].length();
            I[123 ^ 62].length();
            I[52 ^ 114].length();
            "".length();
            if (2 <= -1) {
               throw null;
            }
         } else if (var3.getItem() == var2.getItem()) {
            var3.func_190917_f(" ".length());
         }

         if (var1.getItem() == Item.getItemFromBlock(Blocks.SPONGE) && var1.getMetadata() == " ".length() && !((ItemStack)this.furnaceItemStacks.get(" ".length())).isEmpty() && ((ItemStack)this.furnaceItemStacks.get(" ".length())).getItem() == Items.BUCKET) {
            NonNullList var4 = this.furnaceItemStacks;
            int var5 = " ".length();
            I[23 ^ 80].length();
            I[57 ^ 113].length();
            I[102 ^ 47].length();
            var4.set(var5, new ItemStack(Items.WATER_BUCKET));
            I[57 ^ 115].length();
            I[1 ^ 74].length();
         }

         var1.func_190918_g(" ".length());
      }

   }

   public int getSizeInventory() {
      return this.furnaceItemStacks.size();
   }

   public NBTTagCompound writeToNBT(NBTTagCompound var1) {
      super.writeToNBT(var1);
      I[37 ^ 49].length();
      I[51 ^ 38].length();
      I[61 ^ 43].length();
      var1.setShort(I[148 ^ 131], (short)this.furnaceBurnTime);
      var1.setShort(I[76 ^ 84], (short)this.cookTime);
      var1.setShort(I[26 ^ 3], (short)this.totalCookTime);
      ItemStackHelper.func_191282_a(var1, this.furnaceItemStacks);
      I[3 ^ 25].length();
      I[127 ^ 100].length();
      I[67 ^ 95].length();
      if (this.hasCustomName()) {
         var1.setString(I[14 ^ 19], this.furnaceCustomName);
      }

      return var1;
   }

   public int[] getSlotsForFace(EnumFacing var1) {
      if (var1 == EnumFacing.DOWN) {
         return SLOTS_BOTTOM;
      } else {
         int[] var10000;
         if (var1 == EnumFacing.UP) {
            var10000 = SLOTS_TOP;
            "".length();
            if (4 < 1) {
               throw null;
            }
         } else {
            var10000 = SLOTS_SIDES;
         }

         return var10000;
      }
   }

   public boolean isUsableByPlayer(EntityPlayer var1) {
      if (this.world.getTileEntity(this.pos) != this) {
         return (boolean)"".length();
      } else {
         int var10000;
         if (var1.getDistanceSq((double)this.pos.getX() + 0.5D, (double)this.pos.getY() + 0.5D, (double)this.pos.getZ() + 0.5D) <= 64.0D) {
            var10000 = " ".length();
            "".length();
            if (4 < 2) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public boolean canInsertItem(int var1, ItemStack var2, EnumFacing var3) {
      return this.isItemValidForSlot(var1, var2);
   }

   public void setInventorySlotContents(int var1, ItemStack var2) {
      ItemStack var3 = (ItemStack)this.furnaceItemStacks.get(var1);
      int var10000;
      if (!var2.isEmpty() && var2.isItemEqual(var3) && ItemStack.areItemStackTagsEqual(var2, var3)) {
         var10000 = " ".length();
         "".length();
         if (0 <= -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var4 = var10000;
      this.furnaceItemStacks.set(var1, var2);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      if (var2.func_190916_E() > this.getInventoryStackLimit()) {
         var2.func_190920_e(this.getInventoryStackLimit());
      }

      if (var1 == 0 && var4 == 0) {
         this.totalCookTime = this.getCookTime(var2);
         this.cookTime = "".length();
         this.markDirty();
      }

   }

   public ItemStack removeStackFromSlot(int var1) {
      return ItemStackHelper.getAndRemove(this.furnaceItemStacks, var1);
   }

   public int getField(int var1) {
      switch(var1) {
      case 0:
         return this.furnaceBurnTime;
      case 1:
         return this.currentItemBurnTime;
      case 2:
         return this.cookTime;
      case 3:
         return this.totalCookTime;
      default:
         return "".length();
      }
   }

   public void readFromNBT(NBTTagCompound var1) {
      super.readFromNBT(var1);
      this.furnaceItemStacks = NonNullList.func_191197_a(this.getSizeInventory(), ItemStack.field_190927_a);
      ItemStackHelper.func_191283_b(var1, this.furnaceItemStacks);
      this.furnaceBurnTime = var1.getShort(I[184 ^ 183]);
      this.cookTime = var1.getShort(I[88 ^ 72]);
      this.totalCookTime = var1.getShort(I[8 ^ 25]);
      this.currentItemBurnTime = getItemBurnTime((ItemStack)this.furnaceItemStacks.get(" ".length()));
      if (var1.hasKey(I[63 ^ 45], 144 ^ 152)) {
         this.furnaceCustomName = var1.getString(I[26 ^ 9]);
      }

   }

   public Container createContainer(InventoryPlayer var1, EntityPlayer var2) {
      String var10000 = I[87 ^ 7];
      String var10001 = I[214 ^ 135];
      String var10002 = I[85 ^ 7];
      var10001 = I[255 ^ 172];
      I[70 ^ 18].length();
      return new ContainerFurnace(var1, this);
   }

   public void clear() {
      this.furnaceItemStacks.clear();
   }

   public int getFieldCount() {
      return 80 ^ 84;
   }
}

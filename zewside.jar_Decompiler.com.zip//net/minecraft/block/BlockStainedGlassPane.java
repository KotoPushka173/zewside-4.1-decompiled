package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.Mirror;
import net.minecraft.util.NonNullList;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockStainedGlassPane extends BlockPane {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<EnumDyeColor> COLOR;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= -1);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(COLOR)).getMetadata();
   }

   static {
      I();
      COLOR = PropertyEnum.create(I[168 ^ 156], EnumDyeColor.class);
   }

   public int damageDropped(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(COLOR)).getMetadata();
   }

   public BlockStainedGlassPane() {
      super(Material.GLASS, (boolean)"".length());
      this.setDefaultState(this.blockState.getBaseState().withProperty(NORTH, Boolean.valueOf((boolean)"".length())).withProperty(EAST, Boolean.valueOf((boolean)"".length())).withProperty(SOUTH, Boolean.valueOf((boolean)"".length())).withProperty(WEST, Boolean.valueOf((boolean)"".length())).withProperty(COLOR, EnumDyeColor.WHITE));
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(COLOR, EnumDyeColor.byMetadata(var1));
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.TRANSLUCENT;
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      int var3 = "".length();

      do {
         if (var3 >= EnumDyeColor.values().length) {
            return;
         }

         I[99 ^ 103].length();
         I[52 ^ 49].length();
         I[133 ^ 131].length();
         I[37 ^ 34].length();
         var2.add(new ItemStack(this, " ".length(), var3));
         I[66 ^ 74].length();
         I[2 ^ 11].length();
         ++var3;
         "".length();
      } while(1 != 3);

      throw null;
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         BlockBeacon.updateColorAsync(var1, var2);
      }

   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[179 ^ 185];
      String var10001 = I[49 ^ 58];
      String var10002 = I[115 ^ 127];
      var10001 = I[32 ^ 45];
      var10000 = I[126 ^ 112];
      var10001 = I[34 ^ 45];
      var10002 = I[131 ^ 147];
      var10001 = I[140 ^ 157];
      var10000 = I[41 ^ 59];
      var10001 = I[128 ^ 147];
      var10002 = I[42 ^ 62];
      var10001 = I[88 ^ 77];
      var10000 = I[141 ^ 155];
      var10001 = I[35 ^ 52];
      var10002 = I[173 ^ 181];
      var10001 = I[70 ^ 95];
      var10000 = I[188 ^ 166];
      var10001 = I[149 ^ 142];
      var10002 = I[54 ^ 42];
      var10001 = I[188 ^ 161];
      var10000 = I[168 ^ 182];
      var10001 = I[46 ^ 49];
      var10002 = I[28 ^ 60];
      var10001 = I[62 ^ 31];
      I[114 ^ 80].length();
      I[84 ^ 119].length();
      I[135 ^ 163].length();
      IProperty[] var10003 = new IProperty[61 ^ 56];
      I[122 ^ 95].length();
      I[33 ^ 7].length();
      I[75 ^ 108].length();
      I[129 ^ 169].length();
      I[119 ^ 94].length();
      var10003["".length()] = NORTH;
      I[146 ^ 184].length();
      I[78 ^ 101].length();
      I[66 ^ 110].length();
      var10003[" ".length()] = EAST;
      I[178 ^ 159].length();
      var10003["  ".length()] = WEST;
      I[109 ^ 67].length();
      I[80 ^ 127].length();
      var10003["   ".length()] = SOUTH;
      I[127 ^ 79].length();
      I[163 ^ 146].length();
      I[75 ^ 121].length();
      I[30 ^ 45].length();
      var10003[163 ^ 167] = COLOR;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(NORTH));
      case 2:
         return var1.withProperty(EAST, var1.getValue(WEST)).withProperty(WEST, var1.getValue(EAST));
      default:
         return super.withMirror(var1, var2);
      }
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         BlockBeacon.updateColorAsync(var1, var2);
      }

   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.func_193558_a((EnumDyeColor)var1.getValue(COLOR));
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(EAST, var1.getValue(WEST)).withProperty(SOUTH, var1.getValue(NORTH)).withProperty(WEST, var1.getValue(EAST));
      case 2:
         return var1.withProperty(NORTH, var1.getValue(EAST)).withProperty(EAST, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(WEST)).withProperty(WEST, var1.getValue(NORTH));
      case 3:
         return var1.withProperty(NORTH, var1.getValue(WEST)).withProperty(EAST, var1.getValue(NORTH)).withProperty(SOUTH, var1.getValue(EAST)).withProperty(WEST, var1.getValue(SOUTH));
      default:
         return var1;
      }
   }

   private static void I() {
      I = new String[174 ^ 155];
      I["".length()] = I("坮欨", "UEXSq");
      I[" ".length()] = I("仃嚪", "fkbbE");
      I["  ".length()] = I("叢当", "utwWY");
      I["   ".length()] = I("堉哩", "HEwPl");
      I[113 ^ 117] = I("哻", "zQUYq");
      I[98 ^ 103] = I("枲", "Rcczq");
      I[69 ^ 67] = I("咀", "CaKYm");
      I[46 ^ 41] = I("噀擘塾丈", "FuCkZ");
      I[1 ^ 9] = I("嶧椵櫔岍瀿", "tgIjG");
      I[144 ^ 153] = I("榧", "JJwtm");
      I[134 ^ 140] = I("殗倽", "JpyIk");
      I[33 ^ 42] = I("榾曲", "gExFl");
      I[38 ^ 42] = I("勲晽", "NcRYW");
      I[100 ^ 105] = I("浽澜", "IPHRQ");
      I[204 ^ 194] = I("倴晥", "pPrMC");
      I[141 ^ 130] = I("欓怃", "FVLKX");
      I[123 ^ 107] = I("毮棾", "GpitO");
      I[7 ^ 22] = I("櫦嬬", "hQyPY");
      I[86 ^ 68] = I("匪台", "DYpwx");
      I[26 ^ 9] = I("梽僒", "ROLSj");
      I[145 ^ 133] = I("桧喅", "LABnY");
      I[147 ^ 134] = I("丆峯", "Kaljx");
      I[175 ^ 185] = I("殳喔", "TIUCg");
      I[135 ^ 144] = I("烳戽", "mHhtH");
      I[44 ^ 52] = I("峬懫", "QKOvj");
      I[54 ^ 47] = I("噅咛", "FXmnP");
      I[128 ^ 154] = I("桏枮", "jFoqA");
      I[76 ^ 87] = I("搀斌", "WNlxR");
      I[25 ^ 5] = I("抪姕", "OOWCL");
      I[79 ^ 82] = I("愠斄", "pJeOa");
      I[106 ^ 116] = I("捵李", "GnCeG");
      I[149 ^ 138] = I("澝摡", "Ibzda");
      I[10 ^ 42] = I("嗈咸", "cSKJg");
      I[24 ^ 57] = I("崝槾", "nczKg");
      I[2 ^ 32] = I("滲濘圮斸櫜", "KggzF");
      I[25 ^ 58] = I("匩", "quOSf");
      I[128 ^ 164] = I("瀰厔幺婁", "Zcvpe");
      I[140 ^ 169] = I("恗仌壸", "WOiJD");
      I[31 ^ 57] = I("囮扤坝", "tLmKC");
      I[72 ^ 111] = I("湫愿侖", "bzPrA");
      I[172 ^ 132] = I("将寀怶愓无", "ilryz");
      I[170 ^ 131] = I("嚟", "LvDNo");
      I[0 ^ 42] = I("屛椾佌徃沕", "TANSB");
      I[56 ^ 19] = I("奎圐", "KPcYx");
      I[10 ^ 38] = I("捴滈儮慭", "tQGKI");
      I[72 ^ 101] = I("峅桬嬆桰柎", "ZojmI");
      I[103 ^ 73] = I("溦恌澔", "YSCeG");
      I[189 ^ 146] = I("權厱怗桌", "TZucO");
      I[10 ^ 58] = I("撀哗儠", "aJHhO");
      I[247 ^ 198] = I("囑", "UmOyx");
      I[38 ^ 20] = I("壳", "SNfjp");
      I[149 ^ 166] = I("实恻抜澡巁", "OAkQi");
      I[12 ^ 56] = I("7\u0004!\u000b\u001a", "TkMdh");
   }
}

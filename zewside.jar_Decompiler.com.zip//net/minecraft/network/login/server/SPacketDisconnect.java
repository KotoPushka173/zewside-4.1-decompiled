package net.minecraft.network.login.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.login.INetHandlerLoginClient;
import net.minecraft.util.text.ITextComponent;

public class SPacketDisconnect implements Packet<INetHandlerLoginClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private ITextComponent reason;

   static {
      I();
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("歊柖", "vNlUr");
      I[" ".length()] = I("栦涩岿渺", "UqNKe");
      I["  ".length()] = I("啽宛寧濖欧", "sDmES");
   }

   public ITextComponent getReason() {
      return this.reason;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.reason = ITextComponent.Serializer.fromJsonLenient(var1.readStringFromBuffer(1865 + 6427 - -1302 + 23173));
   }

   public void processPacket(INetHandlerLoginClient var1) {
      var1.handleDisconnect(this);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 0);

      throw null;
   }

   public SPacketDisconnect(ITextComponent var1) {
      this.reason = var1;
   }

   public SPacketDisconnect() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeTextComponent(this.reason);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }
}

package net.minecraft.scoreboard;

public class ScoreObjective {
   // $FF: synthetic field
   private final IScoreCriteria objectiveCriteria;
   // $FF: synthetic field
   private final String name;
   // $FF: synthetic field
   private IScoreCriteria.EnumRenderType renderType;
   // $FF: synthetic field
   private String displayName;
   // $FF: synthetic field
   private final Scoreboard theScoreboard;

   public ScoreObjective(Scoreboard var1, String var2, IScoreCriteria var3) {
      this.theScoreboard = var1;
      this.name = var2;
      this.objectiveCriteria = var3;
      this.displayName = var2;
      this.renderType = var3.getRenderType();
   }

   public Scoreboard getScoreboard() {
      return this.theScoreboard;
   }

   public void setDisplayName(String var1) {
      this.displayName = var1;
      this.theScoreboard.onObjectiveDisplayNameChanged(this);
   }

   public String getName() {
      return this.name;
   }

   public void setRenderType(IScoreCriteria.EnumRenderType var1) {
      this.renderType = var1;
      this.theScoreboard.onObjectiveDisplayNameChanged(this);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   public IScoreCriteria getCriteria() {
      return this.objectiveCriteria;
   }

   public IScoreCriteria.EnumRenderType getRenderType() {
      return this.renderType;
   }

   public String getDisplayName() {
      return this.displayName;
   }
}

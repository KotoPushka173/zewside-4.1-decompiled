package net.minecraft.block.state.pattern;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;

public class BlockMatcher implements Predicate<IBlockState> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Block block;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 != 1);

      throw null;
   }

   public boolean apply(@Nullable IBlockState var1) {
      int var10000;
      if (var1 != null && var1.getBlock() == this.block) {
         var10000 = " ".length();
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static BlockMatcher forBlock(Block var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[177 ^ 181].length();
      I[124 ^ 121].length();
      I[190 ^ 184].length();
      I[86 ^ 81].length();
      return new BlockMatcher(var0);
   }

   static {
      I();
   }

   private BlockMatcher(Block var1) {
      this.block = var1;
   }

   private static void I() {
      I = new String[175 ^ 167];
      I["".length()] = I("栫她", "VTtPS");
      I[" ".length()] = I("圧哲", "HlMMN");
      I["  ".length()] = I("呀侚", "JZZQc");
      I["   ".length()] = I("榗园", "kktFh");
      I[18 ^ 22] = I("沚坶悟尲勇", "neDVg");
      I[53 ^ 48] = I("侰", "sewyl");
      I[89 ^ 95] = I("巆", "kpIRo");
      I[60 ^ 59] = I("崱垔", "Ulzak");
   }
}

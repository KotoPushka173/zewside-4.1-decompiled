package net.minecraft.advancements.critereon;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionType;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class ItemPredicate {
   // $FF: synthetic field
   private final Integer field_192497_c;
   // $FF: synthetic field
   private final NBTPredicate field_193445_h;
   // $FF: synthetic field
   private final MinMaxBounds field_193444_e;
   // $FF: synthetic field
   private final Item field_192496_b;
   // $FF: synthetic field
   public static final ItemPredicate field_192495_a;
   // $FF: synthetic field
   private final PotionType field_192500_f;
   // $FF: synthetic field
   private final MinMaxBounds field_192498_d;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final EnchantmentPredicate[] field_192499_e;

   public ItemPredicate(@Nullable Item var1, @Nullable Integer var2, MinMaxBounds var3, MinMaxBounds var4, EnchantmentPredicate[] var5, @Nullable PotionType var6, NBTPredicate var7) {
      this.field_192496_b = var1;
      this.field_192497_c = var2;
      this.field_192498_d = var3;
      this.field_193444_e = var4;
      this.field_192499_e = var5;
      this.field_192500_f = var6;
      this.field_193445_h = var7;
   }

   public static ItemPredicate[] func_192494_b(@Nullable JsonElement var0) {
      if (var0 != null && !var0.isJsonNull()) {
         JsonArray var1 = JsonUtils.getJsonArray(var0, I[103 ^ 36]);
         ItemPredicate[] var2 = new ItemPredicate[var1.size()];
         int var3 = "".length();

         do {
            if (var3 >= var2.length) {
               return var2;
            }

            var2[var3] = func_192492_a(var1.get(var3));
            ++var3;
            "".length();
         } while(1 < 3);

         throw null;
      } else {
         return new ItemPredicate["".length()];
      }
   }

   public boolean func_192493_a(ItemStack var1) {
      if (this.field_192496_b != null && var1.getItem() != this.field_192496_b) {
         return (boolean)"".length();
      } else if (this.field_192497_c != null && var1.getMetadata() != this.field_192497_c) {
         return (boolean)"".length();
      } else if (!this.field_192498_d.func_192514_a((float)var1.func_190916_E())) {
         return (boolean)"".length();
      } else if (this.field_193444_e != MinMaxBounds.field_192516_a && !var1.isItemStackDamageable()) {
         return (boolean)"".length();
      } else {
         MinMaxBounds var10000 = this.field_193444_e;
         int var10001 = var1.getMaxDamage();
         int var10002 = var1.getItemDamage();
         I["".length()].length();
         if (!var10000.func_192514_a((float)(var10001 - var10002))) {
            return (boolean)"".length();
         } else if (!this.field_193445_h.func_193478_a(var1)) {
            return (boolean)"".length();
         } else {
            Map var2 = EnchantmentHelper.getEnchantments(var1);
            int var3 = "".length();

            do {
               if (var3 >= this.field_192499_e.length) {
                  PotionType var4 = PotionUtils.getPotionFromItem(var1);
                  if (this.field_192500_f != null && this.field_192500_f != var4) {
                     return (boolean)"".length();
                  }

                  return (boolean)" ".length();
               }

               if (!this.field_192499_e[var3].func_192463_a(var2)) {
                  return (boolean)"".length();
               }

               ++var3;
               "".length();
            } while(true);

            throw null;
         }
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 2);

      throw null;
   }

   public static ItemPredicate func_192492_a(@Nullable JsonElement var0) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[122 ^ 126];
      var10000 = I[73 ^ 76];
      var10001 = I[180 ^ 178];
      var10002 = I[136 ^ 143];
      var10001 = I[7 ^ 15];
      var10000 = I[32 ^ 41];
      var10001 = I[21 ^ 31];
      var10002 = I[160 ^ 171];
      var10001 = I[185 ^ 181];
      var10000 = I[176 ^ 189];
      var10001 = I[15 ^ 1];
      var10002 = I[0 ^ 15];
      var10001 = I[52 ^ 36];
      var10000 = I[116 ^ 101];
      var10001 = I[181 ^ 167];
      var10002 = I[143 ^ 156];
      var10001 = I[116 ^ 96];
      var10000 = I[24 ^ 13];
      var10001 = I[117 ^ 99];
      var10002 = I[43 ^ 60];
      var10001 = I[43 ^ 51];
      var10000 = I[18 ^ 11];
      var10001 = I[126 ^ 100];
      var10002 = I[1 ^ 26];
      var10001 = I[74 ^ 86];
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = JsonUtils.getJsonObject(var0, I[128 ^ 157]);
         MinMaxBounds var2 = MinMaxBounds.func_192515_a(var1.get(I[219 ^ 197]));
         MinMaxBounds var3 = MinMaxBounds.func_192515_a(var1.get(I[75 ^ 84]));
         Integer var11;
         if (var1.has(I[81 ^ 113])) {
            var11 = JsonUtils.getInt(var1, I[121 ^ 88]);
            "".length();
            if (1 == -1) {
               throw null;
            }
         } else {
            var11 = null;
         }

         Integer var4 = var11;
         NBTPredicate var5 = NBTPredicate.func_193476_a(var1.get(I[105 ^ 75]));
         Item var6 = null;
         JsonSyntaxException var12;
         if (var1.has(I[148 ^ 183])) {
            I[162 ^ 134].length();
            I[10 ^ 47].length();
            I[109 ^ 75].length();
            ResourceLocation var7 = new ResourceLocation(JsonUtils.getString(var1, I[73 ^ 110]));
            var6 = (Item)Item.REGISTRY.getObject(var7);
            if (var6 == null) {
               I[168 ^ 128].length();
               I[125 ^ 84].length();
               I[24 ^ 50].length();
               I[29 ^ 54].length();
               I[5 ^ 41].length();
               I[123 ^ 86].length();
               var12 = new JsonSyntaxException(I[144 ^ 190] + var7 + I[127 ^ 80]);
               I[80 ^ 96].length();
               I[158 ^ 175].length();
               I[104 ^ 90].length();
               throw var12;
            }
         }

         EnchantmentPredicate[] var10 = EnchantmentPredicate.func_192465_b(var1.get(I[103 ^ 84]));
         PotionType var8 = null;
         if (var1.has(I[38 ^ 18])) {
            I[69 ^ 112].length();
            I[65 ^ 119].length();
            ResourceLocation var9 = new ResourceLocation(JsonUtils.getString(var1, I[25 ^ 46]));
            if (!PotionType.REGISTRY.containsKey(var9)) {
               I[167 ^ 159].length();
               I[138 ^ 179].length();
               I[39 ^ 29].length();
               I[107 ^ 80].length();
               var12 = new JsonSyntaxException(I[113 ^ 77] + var9 + I[64 ^ 125]);
               I[55 ^ 9].length();
               I[11 ^ 52].length();
               I[242 ^ 178].length();
               throw var12;
            }

            var8 = (PotionType)PotionType.REGISTRY.getObject(var9);
         }

         I[47 ^ 110].length();
         I[250 ^ 184].length();
         return new ItemPredicate(var6, var4, var2, var3, var10, var8, var5);
      } else {
         return field_192495_a;
      }
   }

   static {
      I();
      field_192495_a = new ItemPredicate();
   }

   public ItemPredicate() {
      this.field_192496_b = null;
      this.field_192497_c = null;
      this.field_192500_f = null;
      this.field_192498_d = MinMaxBounds.field_192516_a;
      this.field_193444_e = MinMaxBounds.field_192516_a;
      this.field_192499_e = new EnchantmentPredicate["".length()];
      this.field_193445_h = NBTPredicate.field_193479_a;
   }

   private static void I() {
      I = new String[110 ^ 42];
      I["".length()] = I("洟晟刖", "GnLrk");
      I[" ".length()] = I("吙杲", "NoLGc");
      I["  ".length()] = I("劽憢", "lkdXS");
      I["   ".length()] = I("匣毼", "smIEv");
      I[58 ^ 62] = I("嘤晝", "bnwfE");
      I[39 ^ 34] = I("湫吨", "ZbFID");
      I[158 ^ 152] = I("曃洉", "YJjOx");
      I[182 ^ 177] = I("坃惨", "EMcWJ");
      I[38 ^ 46] = I("濰妄", "Aagpi");
      I[35 ^ 42] = I("桕慭", "nlAOA");
      I[105 ^ 99] = I("扱叨", "eOBlq");
      I[9 ^ 2] = I("娬兲", "eyPPS");
      I[84 ^ 88] = I("斻橯", "vAgMj");
      I[39 ^ 42] = I("寿宽", "Zgyoi");
      I[205 ^ 195] = I("傼愃", "NmHxB");
      I[33 ^ 46] = I("煫柴", "UABDk");
      I[188 ^ 172] = I("榣寀", "ousPs");
      I[58 ^ 43] = I("梁怙", "QISjg");
      I[33 ^ 51] = I("嶘昦", "TTBmo");
      I[26 ^ 9] = I("夛杩", "NAjNf");
      I[77 ^ 89] = I("宗侲", "NLqxj");
      I[140 ^ 153] = I("擺歎", "JIkbs");
      I[112 ^ 102] = I("歚幰", "TDPzw");
      I[57 ^ 46] = I("吖勀", "SPrJH");
      I[188 ^ 164] = I("憯凘", "nojzS");
      I[116 ^ 109] = I("溯捇", "CZkkT");
      I[144 ^ 138] = I("侹槜", "Sqqqh");
      I[113 ^ 106] = I("怸囧", "ofGul");
      I[67 ^ 95] = I("昰澢", "biSfF");
      I[64 ^ 93] = I("/ $\u001b", "FTAvr");
      I[73 ^ 87] = I("(>\u001d\u0000\u0019", "KQhnm");
      I[49 ^ 46] = I("\u001e%\u00046,\u0013<\u001f#7", "zPvWN");
      I[145 ^ 177] = I("\n\f1$", "nmEEj");
      I[191 ^ 158] = I("\u0017\u0005\u001d\u0019", "sdixV");
      I[145 ^ 179] = I("\u0002\r6", "loBEf");
      I[53 ^ 22] = I("&\u00176\u0004", "OcSis");
      I[90 ^ 126] = I("挭亡勶攥岡", "GcGHe");
      I[84 ^ 113] = I("幊懖栗杗椌", "SmuHi");
      I[13 ^ 43] = I("瀮", "kwbVM");
      I[33 ^ 6] = I("9\u0007'\u0017", "PsBzS");
      I[27 ^ 51] = I("炍", "LNaYk");
      I[186 ^ 147] = I("乣偼", "FqaBV");
      I[98 ^ 72] = I("圎捎塊", "fDuda");
      I[166 ^ 141] = I("啟憝", "iqQWU");
      I[236 ^ 192] = I("嵱囃", "OTCtC");
      I[34 ^ 15] = I("浘啿曞娷瀺", "VgnqU");
      I[125 ^ 83] = I("$$\u0012\u0006(\u0006$Y\u00013\u0014'Y\u0001#Qm", "qJyhG");
      I[110 ^ 65] = I("l", "KMStZ");
      I[58 ^ 10] = I("攇姖嘢挊", "IfIwe");
      I[191 ^ 142] = I("晩姂濬周", "baGNo");
      I[148 ^ 166] = I("搦圇", "CmAVt");
      I[137 ^ 186] = I("\u0012,9\u0005.\u001967\b!\u00031", "wBZmO");
      I[80 ^ 100] = I("< \u0005\u0006!\"", "LOqoN");
      I[34 ^ 23] = I("柫戙", "HPdSD");
      I[15 ^ 57] = I("喷异宦嘶", "NQUKr");
      I[28 ^ 43] = I("57\u001d\u0011>+", "EXixQ");
      I[9 ^ 49] = I("叺炎", "bEyDq");
      I[24 ^ 33] = I("咶", "ZtIwV");
      I[132 ^ 190] = I("佸媽毭", "Fbuzd");
      I[129 ^ 186] = I("撮", "dqaLx");
      I[93 ^ 97] = I("!\u001c%>\u0016\u0003\u001cn \u0016\u0000\u001b!>YS", "trNPy");
      I[176 ^ 141] = I("\u007f", "XSajq");
      I[140 ^ 178] = I("娥橕局", "zSjAq");
      I[150 ^ 169] = I("晌兂揕慟", "ADHNj");
      I[6 ^ 70] = I("伕掷待", "LxgvA");
      I[57 ^ 120] = I("壥巋叙灨涻", "Gwhjr");
      I[106 ^ 40] = I("晕", "YfhDC");
      I[78 ^ 13] = I("*$\u0003\n\u0012", "CPfga");
   }
}

package net.minecraft.block;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockLilyPad extends BlockBush {
   // $FF: synthetic field
   protected static final AxisAlignedBB LILY_PAD_AABB;
   // $FF: synthetic field
   private static final String[] I;

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      super.onEntityCollidedWithBlock(var1, var2, var3, var4);
      if (var4 instanceof EntityBoat) {
         I[138 ^ 142].length();
         I[58 ^ 63].length();
         I[126 ^ 120].length();
         var1.destroyBlock(new BlockPos(var2), (boolean)" ".length());
         I[98 ^ 101].length();
         I[174 ^ 166].length();
         I[57 ^ 48].length();
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 3);

      throw null;
   }

   protected BlockLilyPad() {
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return LILY_PAD_AABB;
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      if (!(var6 instanceof EntityBoat)) {
         addCollisionBoxToList(var3, var4, var5, LILY_PAD_AABB);
      }

   }

   private static void I() {
      I = new String[51 ^ 57];
      I["".length()] = I("淹喔", "BgUtg");
      I[" ".length()] = I("瀏岴", "XdNno");
      I["  ".length()] = I("淓忶", "CIIhp");
      I["   ".length()] = I("烷嵷", "KexAD");
      I[26 ^ 30] = I("喍概卹憐", "zGzJs");
      I[81 ^ 84] = I("拢挪泆亩", "BbAiX");
      I[111 ^ 105] = I("橻惂晊", "lfFGl");
      I[194 ^ 197] = I("朽卧汒槵", "pWEbO");
      I[153 ^ 145] = I("檂", "jonVI");
      I[85 ^ 92] = I("媙姪桑楲囕", "AhveQ");
   }

   static {
      I();
      LILY_PAD_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.09375D, 0.9375D);
   }

   public int getMetaFromState(IBlockState var1) {
      return "".length();
   }

   public boolean canBlockStay(World var1, BlockPos var2, IBlockState var3) {
      if (var2.getY() >= 0 && var2.getY() < 186 + 131 - 175 + 114) {
         IBlockState var4 = var1.getBlockState(var2.down());
         Material var5 = var4.getMaterial();
         int var10000;
         if ((var5 != Material.WATER || (Integer)var4.getValue(BlockLiquid.LEVEL) != 0) && var5 != Material.ICE) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (-1 != -1) {
               throw null;
            }
         }

         return (boolean)var10000;
      } else {
         return (boolean)"".length();
      }
   }

   protected boolean canSustainBush(IBlockState var1) {
      int var10000;
      if (var1.getBlock() != Blocks.WATER && var1.getMaterial() != Material.ICE) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (1 >= 2) {
            throw null;
         }
      }

      return (boolean)var10000;
   }
}

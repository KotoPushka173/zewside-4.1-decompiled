package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenBigMushroom;

public class BlockMushroom extends BlockBush implements IGrowable {
   // $FF: synthetic field
   protected static final AxisAlignedBB MUSHROOM_AABB;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   static {
      I();
      MUSHROOM_AABB = new AxisAlignedBB(0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.699999988079071D, 0.4000000059604645D, 0.699999988079071D);
   }

   public boolean canUseBonemeal(World var1, Random var2, BlockPos var3, IBlockState var4) {
      int var10000;
      if ((double)var2.nextFloat() < 0.4D) {
         var10000 = " ".length();
         "".length();
         if (4 < 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public void grow(World var1, Random var2, BlockPos var3, IBlockState var4) {
      this.generateBigMushroom(var1, var3, var4, var2);
      I[75 ^ 99].length();
      I[52 ^ 29].length();
   }

   public boolean canGrow(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      return (boolean)" ".length();
   }

   protected BlockMushroom() {
      this.setTickRandomly((boolean)" ".length());
   }

   public boolean canBlockStay(World var1, BlockPos var2, IBlockState var3) {
      if (var2.getY() >= 0 && var2.getY() < 163 + 132 - 66 + 27) {
         IBlockState var4 = var1.getBlockState(var2.down());
         if (var4.getBlock() == Blocks.MYCELIUM) {
            return (boolean)" ".length();
         } else if (var4.getBlock() == Blocks.DIRT && var4.getValue(BlockDirt.VARIANT) == BlockDirt.DirtType.PODZOL) {
            return (boolean)" ".length();
         } else {
            int var10000;
            if (var1.getLight(var2) < (173 ^ 160) && this.canSustainBush(var4)) {
               var10000 = " ".length();
               "".length();
               if (-1 != -1) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      } else {
         return (boolean)"".length();
      }
   }

   private static void I() {
      I = new String[164 ^ 142];
      I["".length()] = I("橦太", "edmzz");
      I[" ".length()] = I("撒塶嘹堁", "HzjAk");
      I["  ".length()] = I("儕槌沴", "eNisw");
      I["   ".length()] = I("捦墵濉暦唑", "lsNDL");
      I[41 ^ 45] = I("弑", "xXZxL");
      I[29 ^ 24] = I("怗灏", "Yoryp");
      I[142 ^ 136] = I("卦", "DYcxO");
      I[166 ^ 161] = I("啠歿", "KlNZh");
      I[132 ^ 140] = I("昃朂曓捪", "jxvpg");
      I[63 ^ 54] = I("婍攗挸", "randa");
      I[110 ^ 100] = I("孠", "SfLyO");
      I[41 ^ 34] = I("旋", "DNbcj");
      I[159 ^ 147] = I("嫝敀桌幔", "scJQk");
      I[46 ^ 35] = I("捥憡洝曾埼", "rqbgu");
      I[107 ^ 101] = I("护拮媣", "ORCQg");
      I[41 ^ 38] = I("依刪吂唇兛", "JAXNf");
      I[2 ^ 18] = I("匜澠僥拏", "WGbLF");
      I[81 ^ 64] = I("恡妖仏桞帝", "ctJRY");
      I[184 ^ 170] = I("昢", "CgQGu");
      I[14 ^ 29] = I("奫彁噔垈欐", "tyzEX");
      I[184 ^ 172] = I("掸枣場嵡", "qpzZf");
      I[161 ^ 180] = I("汮囥", "rMBxg");
      I[159 ^ 137] = I("楓塎", "IAKDo");
      I[142 ^ 153] = I("枈槲", "jQIlZ");
      I[20 ^ 12] = I("剤洴", "RNzWu");
      I[46 ^ 55] = I("歨仳", "EJJCl");
      I[69 ^ 95] = I("浒忘", "qRGsn");
      I[32 ^ 59] = I("潥曝", "fTRlY");
      I[139 ^ 151] = I("唷旂", "YkMgG");
      I[80 ^ 77] = I("擟壨她摡悳", "nzgHr");
      I[186 ^ 164] = I("憷", "fAFox");
      I[149 ^ 138] = I("摐", "WsaTd");
      I[84 ^ 116] = I("効咍欓巟棬", "XVOKJ");
      I[180 ^ 149] = I("憥嘗撄", "oPdRq");
      I[185 ^ 155] = I("橠攵", "Gmvdp");
      I[1 ^ 34] = I("呩塁摉埈偶", "KqMWp");
      I[4 ^ 32] = I("倹柳劣", "Kcqzv");
      I[121 ^ 92] = I("宋伕", "QKckb");
      I[89 ^ 127] = I("炼厗柛坸", "TJOAW");
      I[42 ^ 13] = I("卛厚斐", "RCsvU");
      I[39 ^ 15] = I("媲彦", "uOXnJ");
      I[74 ^ 99] = I("堶椵吋揭", "EqVGZ");
   }

   protected boolean canSustainBush(IBlockState var1) {
      return var1.isFullBlock();
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (super.canPlaceBlockAt(var1, var2) && this.canBlockStay(var1, var2, this.getDefaultState())) {
         var10000 = " ".length();
         "".length();
         if (0 >= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public boolean generateBigMushroom(World var1, BlockPos var2, IBlockState var3, Random var4) {
      String var10000 = I[88 ^ 77];
      String var10001 = I[36 ^ 50];
      String var10002 = I[66 ^ 85];
      var10001 = I[167 ^ 191];
      var10000 = I[216 ^ 193];
      var10001 = I[166 ^ 188];
      var10002 = I[143 ^ 148];
      var10001 = I[117 ^ 105];
      var1.setBlockToAir(var2);
      I[82 ^ 79].length();
      I[68 ^ 90].length();
      I[136 ^ 151].length();
      I[161 ^ 129].length();
      I[2 ^ 35].length();
      WorldGenBigMushroom var5 = null;
      if (this == Blocks.BROWN_MUSHROOM) {
         I[104 ^ 74].length();
         var5 = new WorldGenBigMushroom(Blocks.BROWN_MUSHROOM_BLOCK);
         "".length();
         if (3 <= 1) {
            throw null;
         }
      } else if (this == Blocks.RED_MUSHROOM) {
         I[113 ^ 82].length();
         I[187 ^ 159].length();
         I[168 ^ 141].length();
         var5 = new WorldGenBigMushroom(Blocks.RED_MUSHROOM_BLOCK);
      }

      if (var5 != null && var5.generate(var1, var4, var2)) {
         return (boolean)" ".length();
      } else {
         var1.setBlockState(var2, var3, "   ".length());
         I[106 ^ 76].length();
         I[4 ^ 35].length();
         return (boolean)"".length();
      }
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (var4.nextInt(54 ^ 47) == 0) {
         int var5 = 9 ^ 12;
         int var6 = 109 ^ 105;
         Iterator var7 = BlockPos.getAllInBoxMutable(var2.add(-(180 ^ 176), -" ".length(), -(158 ^ 154)), var2.add(37 ^ 33, " ".length(), 116 ^ 112)).iterator();

         while(var7.hasNext()) {
            BlockPos var8 = (BlockPos)var7.next();
            if (var1.getBlockState(var8).getBlock() == this) {
               --var5;
               if (var5 <= 0) {
                  return;
               }
            }

            "".length();
            if (4 != 4) {
               throw null;
            }
         }

         int var10001 = var4.nextInt("   ".length());
         int var10002 = " ".length();
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
         I[54 ^ 50].length();
         var10001 -= var10002;
         var10002 = var4.nextInt("  ".length());
         int var10003 = var4.nextInt("  ".length());
         I[23 ^ 18].length();
         I[138 ^ 140].length();
         I[196 ^ 195].length();
         var10002 -= var10003;
         var10003 = var4.nextInt("   ".length());
         int var10004 = " ".length();
         I[57 ^ 49].length();
         I[64 ^ 73].length();
         I[33 ^ 43].length();
         I[109 ^ 102].length();
         BlockPos var9 = var2.add(var10001, var10002, var10003 - var10004);
         int var10 = "".length();

         while(var10 < (38 ^ 34)) {
            if (var1.isAirBlock(var9) && this.canBlockStay(var1, var9, this.getDefaultState())) {
               var2 = var9;
            }

            var10001 = var4.nextInt("   ".length());
            var10002 = " ".length();
            I[137 ^ 133].length();
            I[18 ^ 31].length();
            var10001 -= var10002;
            var10002 = var4.nextInt("  ".length());
            var10003 = var4.nextInt("  ".length());
            I[125 ^ 115].length();
            I[175 ^ 160].length();
            I[121 ^ 105].length();
            I[56 ^ 41].length();
            var10002 -= var10003;
            var10003 = var4.nextInt("   ".length());
            var10004 = " ".length();
            I[185 ^ 171].length();
            var9 = var2.add(var10001, var10002, var10003 - var10004);
            ++var10;
            "".length();
            if (2 < -1) {
               throw null;
            }
         }

         if (var1.isAirBlock(var9) && this.canBlockStay(var1, var9, this.getDefaultState())) {
            var1.setBlockState(var9, this.getDefaultState(), "  ".length());
            I[23 ^ 4].length();
            I[190 ^ 170].length();
         }
      }

   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MUSHROOM_AABB;
   }
}

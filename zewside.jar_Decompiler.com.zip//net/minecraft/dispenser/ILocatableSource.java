package net.minecraft.dispenser;

public interface ILocatableSource extends ILocation {
}

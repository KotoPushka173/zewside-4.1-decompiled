package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockDragonEgg extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB DRAGON_EGG_AABB;

   private void teleport(World var1, BlockPos var2) {
      IBlockState var3 = var1.getBlockState(var2);
      if (var3.getBlock() == this) {
         int var4 = "".length();

         while(var4 < 258 + 938 - 809 + 613) {
            int var10001 = var1.rand.nextInt(94 ^ 78);
            int var10002 = var1.rand.nextInt(41 ^ 57);
            I[6 ^ 11].length();
            I[182 ^ 184].length();
            var10001 -= var10002;
            var10002 = var1.rand.nextInt(61 ^ 53);
            int var10003 = var1.rand.nextInt(58 ^ 50);
            I[163 ^ 172].length();
            I[73 ^ 89].length();
            var10002 -= var10003;
            var10003 = var1.rand.nextInt(56 ^ 40);
            int var10004 = var1.rand.nextInt(44 ^ 60);
            I[8 ^ 25].length();
            BlockPos var5 = var2.add(var10001, var10002, var10003 - var10004);
            if (var1.getBlockState(var5).getBlock().blockMaterial == Material.AIR) {
               if (var1.isRemote) {
                  int var6 = "".length();

                  while(var6 < 91 + 52 - 28 + 13) {
                     double var7 = var1.rand.nextDouble();
                     float var10000 = var1.rand.nextFloat();
                     I[97 ^ 115].length();
                     I[53 ^ 38].length();
                     I[171 ^ 191].length();
                     float var9 = (var10000 - 0.5F) * 0.2F;
                     var10000 = var1.rand.nextFloat();
                     I[72 ^ 93].length();
                     I[134 ^ 144].length();
                     float var10 = (var10000 - 0.5F) * 0.2F;
                     var10000 = var1.rand.nextFloat();
                     I[169 ^ 190].length();
                     float var11 = (var10000 - 0.5F) * 0.2F;
                     double var18 = (double)var5.getX();
                     var10001 = var2.getX();
                     var10002 = var5.getX();
                     I[7 ^ 31].length();
                     var18 += (double)(var10001 - var10002) * var7;
                     double var19 = var1.rand.nextDouble();
                     I[122 ^ 99].length();
                     I[84 ^ 78].length();
                     double var12 = var18 + (var19 - 0.5D) + 0.5D;
                     var18 = (double)var5.getY();
                     var10001 = var2.getY();
                     var10002 = var5.getY();
                     I[1 ^ 26].length();
                     I[128 ^ 156].length();
                     I[30 ^ 3].length();
                     var18 = var18 + (double)(var10001 - var10002) * var7 + var1.rand.nextDouble();
                     I[34 ^ 60].length();
                     I[142 ^ 145].length();
                     I[188 ^ 156].length();
                     I[80 ^ 113].length();
                     double var14 = var18 - 0.5D;
                     var18 = (double)var5.getZ();
                     var10001 = var2.getZ();
                     var10002 = var5.getZ();
                     I[30 ^ 60].length();
                     I[49 ^ 18].length();
                     I[145 ^ 181].length();
                     I[66 ^ 103].length();
                     var18 += (double)(var10001 - var10002) * var7;
                     var19 = var1.rand.nextDouble();
                     I[183 ^ 145].length();
                     I[124 ^ 91].length();
                     double var16 = var18 + (var19 - 0.5D) + 0.5D;
                     var1.spawnParticle(EnumParticleTypes.PORTAL, var12, var14, var16, (double)var9, (double)var10, (double)var11);
                     ++var6;
                     "".length();
                     if (2 <= 1) {
                        throw null;
                     }
                  }

                  "".length();
                  if (3 == -1) {
                     throw null;
                  }
               } else {
                  var1.setBlockState(var5, var3, "  ".length());
                  I[90 ^ 114].length();
                  I[96 ^ 73].length();
                  I[91 ^ 113].length();
                  var1.setBlockToAir(var2);
                  I[115 ^ 88].length();
                  I[235 ^ 199].length();
                  I[15 ^ 34].length();
                  I[33 ^ 15].length();
               }

               return;
            }

            ++var4;
            "".length();
            if (false) {
               throw null;
            }
         }
      }

   }

   static {
      I();
      DRAGON_EGG_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 1.0D, 0.9375D);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      var2.scheduleUpdate(var3, this, this.tickRate(var2));
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      this.teleport(var1, var2);
      return (boolean)" ".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 4);

      throw null;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      this.checkFall(var1, var2);
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return (boolean)" ".length();
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      var1.scheduleUpdate(var2, this, this.tickRate(var1));
   }

   public BlockDragonEgg() {
      super(Material.DRAGON_EGG, MapColor.BLACK);
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public void onBlockClicked(World var1, BlockPos var2, EntityPlayer var3) {
      this.teleport(var1, var2);
   }

   private static void I() {
      I = new String[21 ^ 58];
      I["".length()] = I("廲卻", "FrjOc");
      I[" ".length()] = I("恸桑", "DydGf");
      I["  ".length()] = I("俸劊", "vTFea");
      I["   ".length()] = I("揰忲", "EEBpc");
      I[76 ^ 72] = I("欲屾", "MMreg");
      I[197 ^ 192] = I("屡头", "USxGv");
      I[29 ^ 27] = I("偰烜囚摢佌", "AkNaX");
      I[121 ^ 126] = I("址掶抚欬柇", "MgFme");
      I[42 ^ 34] = I("渝挸娳摐", "dOwij");
      I[86 ^ 95] = I("恴懽揆媟瀖", "AwwVT");
      I[117 ^ 127] = I("栈洿", "qJgHg");
      I[62 ^ 53] = I("哯橤", "uRhhV");
      I[38 ^ 42] = I("修傦", "YZNul");
      I[42 ^ 39] = I("浫堥垠", "NLadG");
      I[36 ^ 42] = I("摑嶭憬孏", "PykSX");
      I[14 ^ 1] = I("凵伎挦", "Caboc");
      I[117 ^ 101] = I("瀴", "tQncC");
      I[108 ^ 125] = I("椳博", "OmPUF");
      I[48 ^ 34] = I("恥处如椖念", "hGqdx");
      I[52 ^ 39] = I("揷推妠再厴", "RFklo");
      I[122 ^ 110] = I("渵", "JNpMZ");
      I[101 ^ 112] = I("拆", "IkzbB");
      I[134 ^ 144] = I("兣教媬", "Sfqzq");
      I[143 ^ 152] = I("壿厭", "anGLA");
      I[27 ^ 3] = I("介", "vwpti");
      I[87 ^ 78] = I("溸向", "KTyJn");
      I[1 ^ 27] = I("悂慆暿吰", "rGyzS");
      I[13 ^ 22] = I("墧溿損椣", "KKuEK");
      I[36 ^ 56] = I("擆呱炝", "xjTyO");
      I[105 ^ 116] = I("慮劒嚟曪", "TciZf");
      I[183 ^ 169] = I("吿汜潾嵱漊", "bXwPl");
      I[168 ^ 183] = I("唺案榾槁巕", "MWxxw");
      I[191 ^ 159] = I("楨攴", "pynho");
      I[48 ^ 17] = I("惋卽沊幵掼", "YPqou");
      I[106 ^ 72] = I("尾岺啇濻掚", "BesAf");
      I[170 ^ 137] = I("濸惵唳", "WnKmx");
      I[86 ^ 114] = I("氄", "GpvCU");
      I[93 ^ 120] = I("含忄汃噠", "tFHRW");
      I[13 ^ 43] = I("天槠潶", "XRMmb");
      I[61 ^ 26] = I("丄嘑", "BZrmq");
      I[7 ^ 47] = I("瀹", "fyQMY");
      I[1 ^ 40] = I("淭溉泒沤", "BRhZY");
      I[130 ^ 168] = I("妕忿巫", "OWFrq");
      I[176 ^ 155] = I("卼匝毿", "TXxZM");
      I[53 ^ 25] = I("扌渒徣", "IcCMP");
      I[4 ^ 41] = I("厎寊彜", "WpIHR");
      I[104 ^ 70] = I("喠储", "ncHwC");
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return DRAGON_EGG_AABB;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public int tickRate(World var1) {
      return 85 ^ 80;
   }

   private void checkFall(World var1, BlockPos var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (BlockFalling.canFallThrough(var1.getBlockState(var2.down())) && var2.getY() >= 0) {
         int var3 = 104 ^ 72;
         if (!BlockFalling.fallInstantly && var1.isAreaLoaded(var2.add(-(102 ^ 70), -(184 ^ 152), -(186 ^ 154)), var2.add(13 ^ 45, 152 ^ 184, 224 ^ 192))) {
            I[50 ^ 54].length();
            I[199 ^ 194].length();
            I[15 ^ 9].length();
            I[4 ^ 3].length();
            var1.spawnEntityInWorld(new EntityFallingBlock(var1, (double)((float)var2.getX() + 0.5F), (double)var2.getY(), (double)((float)var2.getZ() + 0.5F), this.getDefaultState()));
            I[165 ^ 173].length();
            "".length();
            if (0 < -1) {
               throw null;
            }
         } else {
            var1.setBlockToAir(var2);
            I[185 ^ 176].length();
            I[111 ^ 101].length();
            BlockPos var4 = var2;

            while(BlockFalling.canFallThrough(var1.getBlockState(var4)) && var4.getY() > 0) {
               var4 = var4.down();
               "".length();
               if (1 >= 2) {
                  throw null;
               }
            }

            if (var4.getY() > 0) {
               var1.setBlockState(var4, this.getDefaultState(), "  ".length());
               I[6 ^ 13].length();
               I[190 ^ 178].length();
            }
         }
      }

   }
}

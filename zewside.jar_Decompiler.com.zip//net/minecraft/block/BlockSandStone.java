package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockSandStone extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockSandStone.EnumType> TYPE;

   public BlockSandStone() {
      super(Material.ROCK);
      this.setDefaultState(this.blockState.getBaseState().withProperty(TYPE, BlockSandStone.EnumType.DEFAULT));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 4);

      throw null;
   }

   private static void I() {
      I = new String[39 ^ 61];
      I["".length()] = I("泛匑", "UQPil");
      I[" ".length()] = I("于一", "MurvB");
      I["  ".length()] = I("歋呪", "wLQKJ");
      I["   ".length()] = I("匫泐", "SrcVQ");
      I[128 ^ 132] = I("晒曊淑抍澴", "bEdBG");
      I[99 ^ 102] = I("岸旝梢氄撏", "wMpNX");
      I[57 ^ 63] = I("侜戉摉", "aXRhe");
      I[168 ^ 175] = I("儼", "bqhUL");
      I[163 ^ 171] = I("湫恓岘", "gUKHs");
      I[78 ^ 71] = I("冇毕", "bfaNU");
      I[120 ^ 114] = I("儨刌", "vlcWz");
      I[115 ^ 120] = I("岢涯", "uddkd");
      I[83 ^ 95] = I("央夕", "XCQDc");
      I[77 ^ 64] = I("悍樝", "dbEje");
      I[125 ^ 115] = I("员唅", "EZbKB");
      I[167 ^ 168] = I("澜垃", "ApBVz");
      I[162 ^ 178] = I("攵攘", "pkxLu");
      I[79 ^ 94] = I("烀垯", "FaxcV");
      I[165 ^ 183] = I("摃拃", "KccLq");
      I[77 ^ 94] = I("烌嶍劄杊", "ujPfG");
      I[126 ^ 106] = I("哸唂", "LZqjD");
      I[13 ^ 24] = I("勞", "DLqez");
      I[75 ^ 93] = I("曷", "NpoqB");
      I[156 ^ 139] = I("上壃擠噪", "ctuIC");
      I[149 ^ 141] = I("更恏樳岿嶢", "vamez");
      I[154 ^ 131] = I("\u001e;2=", "jBBXY");
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockSandStone.EnumType)var1.getValue(TYPE)).getMetadata();
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockSandStone.EnumType)var1.getValue(TYPE)).getMetadata();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[148 ^ 159];
      String var10001 = I[14 ^ 2];
      String var10002 = I[18 ^ 31];
      var10001 = I[31 ^ 17];
      var10000 = I[4 ^ 11];
      var10001 = I[156 ^ 140];
      var10002 = I[140 ^ 157];
      var10001 = I[135 ^ 149];
      I[96 ^ 115].length();
      I[47 ^ 59].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[19 ^ 6].length();
      I[113 ^ 103].length();
      I[11 ^ 28].length();
      I[189 ^ 165].length();
      var10003["".length()] = TYPE;
      return new BlockStateContainer(this, var10003);
   }

   static {
      I();
      TYPE = PropertyEnum.create(I[175 ^ 182], BlockSandStone.EnumType.class);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(TYPE, BlockSandStone.EnumType.byMetadata(var1));
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      BlockSandStone.EnumType[] var3 = BlockSandStone.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockSandStone.EnumType var6 = var3[var5];
         I[165 ^ 161].length();
         I[183 ^ 178].length();
         I[73 ^ 79].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[7 ^ 0].length();
         I[32 ^ 40].length();
         I[19 ^ 26].length();
         I[32 ^ 42].length();
         ++var5;
         "".length();
      } while(3 > 1);

      throw null;
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.SAND;
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      private final int metadata;
      // $FF: synthetic field
      CHISELED;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      DEFAULT;

      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      SMOOTH;

      private EnumType(int var3, String var4, String var5) {
         this.metadata = var3;
         this.name = var4;
         this.unlocalizedName = var5;
      }

      public static BlockSandStone.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      public String getName() {
         return this.name;
      }

      private static void I() {
         I = new String[19 ^ 26];
         I["".length()] = I("5\u0014%*==\u0005", "qQckh");
         I[" ".length()] = I("#\u0004:2&$\n:3", "PeTVU");
         I["  ".length()] = I("* \u001622\"1", "NEpSG");
         I["   ".length()] = I("(%.\u00113'(#", "kmgBv");
         I[119 ^ 115] = I("\"\u000e\u0001=\u001d-\u0003\f\u0011\u000b \b\f=\f.\b\r", "AfhNx");
         I[71 ^ 66] = I("\u000b-\u000e\u00045\u0004 \u0003", "hEgwP");
         I[58 ^ 60] = I("\u0004%\u0018-.\u001f", "WhWbz");
         I[128 ^ 135] = I("\u0014\u001e\u0006\r\u0018\u000f,\u001a\u0003\u0002\u0003\u0000\u001d\r\u0002\u0002", "gsibl");
         I[41 ^ 33] = I("\u0018\u0019 \u0005\u0012\u0003", "ktOjf");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 == 4);

         throw null;
      }

      public int getMetadata() {
         return this.metadata;
      }

      public String toString() {
         return this.name;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      static {
         I();
         DEFAULT = new BlockSandStone.EnumType(I["".length()], "".length(), "".length(), I[" ".length()], I["  ".length()]);
         CHISELED = new BlockSandStone.EnumType(I["   ".length()], " ".length(), " ".length(), I[111 ^ 107], I[158 ^ 155]);
         SMOOTH = new BlockSandStone.EnumType(I[95 ^ 89], "  ".length(), "  ".length(), I[175 ^ 168], I[48 ^ 56]);
         BlockSandStone.EnumType[] var10000 = new BlockSandStone.EnumType["   ".length()];
         var10000["".length()] = DEFAULT;
         var10000[" ".length()] = CHISELED;
         var10000["  ".length()] = SMOOTH;
         BlockSandStone.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockSandStone.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(3 > -1);

         throw null;
      }
   }
}

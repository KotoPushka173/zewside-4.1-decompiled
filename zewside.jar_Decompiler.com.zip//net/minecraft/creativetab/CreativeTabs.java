package net.minecraft.creativetab;

import java.util.Iterator;
import javax.annotation.Nullable;
import net.minecraft.block.BlockDoublePlant;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.PotionTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.NonNullList;

public abstract class CreativeTabs {
   // $FF: synthetic field
   public static final CreativeTabs INVENTORY;
   // $FF: synthetic field
   private String theTexture;
   // $FF: synthetic field
   public static final CreativeTabs REDSTONE;
   // $FF: synthetic field
   private boolean hasScrollbar;
   // $FF: synthetic field
   public static final CreativeTabs[] CREATIVE_TAB_ARRAY;
   // $FF: synthetic field
   public static final CreativeTabs FOOD;
   // $FF: synthetic field
   public static final CreativeTabs field_192395_m;
   // $FF: synthetic field
   public static final CreativeTabs TRANSPORTATION;
   // $FF: synthetic field
   public static final CreativeTabs DECORATIONS;
   // $FF: synthetic field
   private ItemStack iconItemStack;
   // $FF: synthetic field
   public static final CreativeTabs SEARCH;
   // $FF: synthetic field
   public static final CreativeTabs BREWING;
   // $FF: synthetic field
   private final int tabIndex;
   // $FF: synthetic field
   private EnumEnchantmentType[] enchantmentTypes;
   // $FF: synthetic field
   public static final CreativeTabs MISC;
   // $FF: synthetic field
   public static final CreativeTabs TOOLS;
   // $FF: synthetic field
   public static final CreativeTabs COMBAT;
   // $FF: synthetic field
   private boolean drawTitle;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final CreativeTabs BUILDING_BLOCKS;
   // $FF: synthetic field
   public static final CreativeTabs MATERIALS;
   // $FF: synthetic field
   private final String tabLabel;

   public CreativeTabs setNoTitle() {
      this.drawTitle = (boolean)"".length();
      return this;
   }

   public CreativeTabs setNoScrollbar() {
      this.hasScrollbar = (boolean)"".length();
      return this;
   }

   static {
      I();
      CREATIVE_TAB_ARRAY = new CreativeTabs[178 ^ 190];
      BUILDING_BLOCKS = new CreativeTabs("".length(), I[163 ^ 170]) {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[164 ^ 160].length();
            I[175 ^ 170].length();
            I[94 ^ 88].length();
            I[89 ^ 94].length();
            return new ItemStack(Item.getItemFromBlock(Blocks.BRICK_BLOCK));
         }

         private static void I() {
            I = new String[23 ^ 31];
            I["".length()] = I("廚感", "Fqsip");
            I[" ".length()] = I("圿儅", "qBpoV");
            I["  ".length()] = I("檐塸", "XHXRm");
            I["   ".length()] = I("嫤湭", "NwqLz");
            I[83 ^ 87] = I("港泓湬", "OueFk");
            I[108 ^ 105] = I("嫯冠瀲", "sNcvM");
            I[188 ^ 186] = I("恚枠", "ZejcY");
            I[177 ^ 182] = I("啣", "yVjyz");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 < 0);

            throw null;
         }
      };
      DECORATIONS = new CreativeTabs(" ".length(), I[160 ^ 170]) {
         // $FF: synthetic field
         private static final String[] I;

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[55 ^ 51].length();
            I[149 ^ 144].length();
            return new ItemStack(Item.getItemFromBlock(Blocks.DOUBLE_PLANT), " ".length(), BlockDoublePlant.EnumPlantType.PAEONIA.getMeta());
         }

         static {
            I();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 < 3);

            throw null;
         }

         private static void I() {
            I = new String[47 ^ 41];
            I["".length()] = I("埽斧", "malDH");
            I[" ".length()] = I("喃泋", "fmHZP");
            I["  ".length()] = I("块慫", "XzYCO");
            I["   ".length()] = I("媤恱", "SNBoI");
            I[189 ^ 185] = I("媤", "cnUBb");
            I[33 ^ 36] = I("喊", "uqvwB");
         }
      };
      REDSTONE = new CreativeTabs("  ".length(), I[102 ^ 109]) {
         // $FF: synthetic field
         private static final String[] I;

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[103 ^ 99].length();
            I[8 ^ 13].length();
            return new ItemStack(Items.REDSTONE);
         }

         private static void I() {
            I = new String[76 ^ 74];
            I["".length()] = I("攱俅", "ZkQBk");
            I[" ".length()] = I("漉卦", "NIkEN");
            I["  ".length()] = I("勽峪", "sSiWR");
            I["   ".length()] = I("嗕峜", "eaqwM");
            I[106 ^ 110] = I("椁櫐悃沯夔", "ePZHL");
            I[99 ^ 102] = I("淇庿吏暜寒", "DyQuR");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 != -1);

            throw null;
         }

         static {
            I();
         }
      };
      TRANSPORTATION = new CreativeTabs("   ".length(), I[105 ^ 101]) {
         // $FF: synthetic field
         private static final String[] I;

         private static void I() {
            I = new String[6 ^ 0];
            I["".length()] = I("昒撰", "yYSJm");
            I[" ".length()] = I("挎悇", "bXKCU");
            I["  ".length()] = I("桒屜", "JgbUQ");
            I["   ".length()] = I("埞勔", "sqUyo");
            I[178 ^ 182] = I("検歚丅榲樍", "fpVYF");
            I[16 ^ 21] = I("渵", "nTTPA");
         }

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[125 ^ 121].length();
            I[22 ^ 19].length();
            return new ItemStack(Item.getItemFromBlock(Blocks.GOLDEN_RAIL));
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 > 0);

            throw null;
         }

         static {
            I();
         }
      };
      MISC = new CreativeTabs(78 ^ 72, I[15 ^ 2]) {
         // $FF: synthetic field
         private static final String[] I;

         private static void I() {
            I = new String[129 ^ 132];
            I["".length()] = I("炷濦", "yhQBW");
            I[" ".length()] = I("戫嶟", "OMWUn");
            I["  ".length()] = I("濒叵", "CIbQd");
            I["   ".length()] = I("柋埢", "gdxEB");
            I[82 ^ 86] = I("哽", "jIYgs");
         }

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[133 ^ 129].length();
            return new ItemStack(Items.LAVA_BUCKET);
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 != -1);

            throw null;
         }

         static {
            I();
         }
      };
      SEARCH = (new CreativeTabs(27 ^ 30, I[66 ^ 76]) {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static void I() {
            I = new String[71 ^ 66];
            I["".length()] = I("憌匒", "RFjrU");
            I[" ".length()] = I("噟兡", "lcmiI");
            I["  ".length()] = I("漏歞", "AgWIT");
            I["   ".length()] = I("悤幉", "uoQAI");
            I[15 ^ 11] = I("抣伴", "vTkmw");
         }

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[141 ^ 137].length();
            return new ItemStack(Items.COMPASS);
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 == 4);

            throw null;
         }
      }).setBackgroundImageName(I[173 ^ 162]);
      FOOD = new CreativeTabs(132 ^ 131, I[39 ^ 55]) {
         // $FF: synthetic field
         private static final String[] I;

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 > 3);

            throw null;
         }

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[133 ^ 129].length();
            I[181 ^ 176].length();
            I[160 ^ 166].length();
            I[108 ^ 107].length();
            return new ItemStack(Items.APPLE);
         }

         private static void I() {
            I = new String[44 ^ 36];
            I["".length()] = I("怸氅", "rxuLW");
            I[" ".length()] = I("僩楸", "mDAdh");
            I["  ".length()] = I("比旗", "lXRIe");
            I["   ".length()] = I("傃励", "JQxcj");
            I[27 ^ 31] = I("圶従僿朜", "MDBDs");
            I[121 ^ 124] = I("徶", "MqCbo");
            I[172 ^ 170] = I("呒戟娃", "ycjEE");
            I[38 ^ 33] = I("唼", "GSKMX");
         }

         static {
            I();
         }
      };
      CreativeTabs var10000 = new CreativeTabs(156 ^ 148, I[108 ^ 125]) {
         // $FF: synthetic field
         private static final String[] I;

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[133 ^ 129].length();
            I[154 ^ 159].length();
            I[186 ^ 188].length();
            return new ItemStack(Items.IRON_AXE);
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 >= -1);

            throw null;
         }

         private static void I() {
            I = new String[85 ^ 82];
            I["".length()] = I("圓京", "ujASY");
            I[" ".length()] = I("劣促", "VQWbh");
            I["  ".length()] = I("孟慷", "ZGEws");
            I["   ".length()] = I("搩埣", "yJLlc");
            I[9 ^ 13] = I("劼夻揰", "tDlyO");
            I[141 ^ 136] = I("柫呗岏孲", "sSUoP");
            I[33 ^ 39] = I("凰漰", "LgPKe");
         }

         static {
            I();
         }
      };
      EnumEnchantmentType[] var10001 = new EnumEnchantmentType[72 ^ 76];
      var10001["".length()] = EnumEnchantmentType.ALL;
      var10001[" ".length()] = EnumEnchantmentType.DIGGER;
      var10001["  ".length()] = EnumEnchantmentType.FISHING_ROD;
      var10001["   ".length()] = EnumEnchantmentType.BREAKABLE;
      TOOLS = var10000.setRelevantEnchantmentTypes(var10001);
      var10000 = new CreativeTabs(187 ^ 178, I[69 ^ 87]) {
         // $FF: synthetic field
         private static final String[] I;

         private static void I() {
            I = new String[42 ^ 47];
            I["".length()] = I("歝巶", "AuuPh");
            I[" ".length()] = I("愦帇", "MJLuF");
            I["  ".length()] = I("枲冸", "gvupV");
            I["   ".length()] = I("佉卵", "AuNMw");
            I[73 ^ 77] = I("孒栖", "eUYzf");
         }

         static {
            I();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(true);

            throw null;
         }

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[11 ^ 15].length();
            return new ItemStack(Items.GOLDEN_SWORD);
         }
      };
      var10001 = new EnumEnchantmentType[111 ^ 101];
      var10001["".length()] = EnumEnchantmentType.ALL;
      var10001[" ".length()] = EnumEnchantmentType.ARMOR;
      var10001["  ".length()] = EnumEnchantmentType.ARMOR_FEET;
      var10001["   ".length()] = EnumEnchantmentType.ARMOR_HEAD;
      var10001[13 ^ 9] = EnumEnchantmentType.ARMOR_LEGS;
      var10001[125 ^ 120] = EnumEnchantmentType.ARMOR_CHEST;
      var10001[45 ^ 43] = EnumEnchantmentType.BOW;
      var10001[134 ^ 129] = EnumEnchantmentType.WEAPON;
      var10001[62 ^ 54] = EnumEnchantmentType.WEARABLE;
      var10001[153 ^ 144] = EnumEnchantmentType.BREAKABLE;
      COMBAT = var10000.setRelevantEnchantmentTypes(var10001);
      BREWING = new CreativeTabs(177 ^ 187, I[129 ^ 146]) {
         // $FF: synthetic field
         private static final String[] I;

         private static void I() {
            I = new String[152 ^ 144];
            I["".length()] = I("彖你", "eMPuq");
            I[" ".length()] = I("湫婁", "ZhAuw");
            I["  ".length()] = I("掘到", "HMRuT");
            I["   ".length()] = I("汶帋", "wrUuv");
            I[135 ^ 131] = I("樖大埣乃昁", "aumpI");
            I[171 ^ 174] = I("杁劦死淭宸", "DcWjW");
            I[170 ^ 172] = I("憂忩悏僟", "RxQMZ");
            I[52 ^ 51] = I("巉歱旷扸娻", "rrXAW");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 == -1);

            throw null;
         }

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[40 ^ 44].length();
            I[28 ^ 25].length();
            I[155 ^ 157].length();
            I[26 ^ 29].length();
            return PotionUtils.addPotionToItemStack(new ItemStack(Items.POTIONITEM), PotionTypes.WATER);
         }

         static {
            I();
         }
      };
      MATERIALS = MISC;
      field_192395_m = new CreativeTabs(183 ^ 179, I[109 ^ 121]) {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static void I() {
            I = new String[160 ^ 180];
            I["".length()] = I("剪徢", "rRGnI");
            I[" ".length()] = I("滥氋", "oEjbD");
            I["  ".length()] = I("悄滼", "Atuim");
            I["   ".length()] = I("凶屲", "BWvHz");
            I[73 ^ 77] = I("檱", "JgsDX");
            I[92 ^ 89] = I("慃", "ILgmm");
            I[41 ^ 47] = I("娃橱", "htRDb");
            I[30 ^ 25] = I("坟俻", "KLWXe");
            I[145 ^ 153] = I("斊俽", "mtHqi");
            I[183 ^ 190] = I("壼奔", "SIRkf");
            I[150 ^ 156] = I("婘樅", "gSLwq");
            I[86 ^ 93] = I("嚷桯廍", "YiYAo");
            I[16 ^ 28] = I("椴榁", "qnDSX");
            I[50 ^ 63] = I("垻", "XnSet");
            I[76 ^ 66] = I(",>2\u0007&\b6,\u001fc\u0000+!\u000e3\u0011:-\u0005c\u0006?+\u000e-\u0011~1\u0002'\u0000}", "eSBkC");
            I[76 ^ 67] = I("呶埏", "WnhnP");
            I[72 ^ 88] = I("澌共埯", "MNHsZ");
            I[183 ^ 166] = I("嚫抦懹悧", "YWrQz");
            I[29 ^ 15] = I("擠憑寜", "ipNtw");
            I[186 ^ 169] = I("儹仑囚戩瀙", "SecCo");
         }

         public void displayAllRelevantItems(NonNullList<ItemStack> var1) {
            String var10000 = I[154 ^ 156];
            String var10001 = I[40 ^ 47];
            String var10002 = I[191 ^ 183];
            var10001 = I[143 ^ 134];
            I[171 ^ 161].length();
            I[47 ^ 36].length();
            I[32 ^ 44].length();
            I[127 ^ 114].length();
            RuntimeException var2 = new RuntimeException(I[16 ^ 30]);
            I[204 ^ 195].length();
            I[184 ^ 168].length();
            I[78 ^ 95].length();
            I[15 ^ 29].length();
            I[154 ^ 137].length();
            throw var2;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 == 4);

            throw null;
         }

         public boolean func_192394_m() {
            return (boolean)" ".length();
         }

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[24 ^ 28].length();
            I[24 ^ 29].length();
            return new ItemStack(Blocks.BOOKSHELF);
         }
      };
      INVENTORY = (new CreativeTabs(181 ^ 190, I[189 ^ 168]) {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 > 1);

            throw null;
         }

         private static void I() {
            I = new String[143 ^ 135];
            I["".length()] = I("噟涵", "OXoOC");
            I[" ".length()] = I("沁戱", "LVoyb");
            I["  ".length()] = I("急澻", "zCqNX");
            I["   ".length()] = I("櫱晙", "LUYgk");
            I[152 ^ 156] = I("悄媐渳怢杢", "xTIWM");
            I[26 ^ 31] = I("暬", "MwRQf");
            I[34 ^ 36] = I("欵櫤卵帰劔", "UjXmK");
            I[34 ^ 37] = I("卄冔炻擉", "KEKNB");
         }

         public ItemStack getTabIconItem() {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            I[186 ^ 190].length();
            I[195 ^ 198].length();
            I[132 ^ 130].length();
            I[68 ^ 67].length();
            return new ItemStack(Item.getItemFromBlock(Blocks.CHEST));
         }
      }).setBackgroundImageName(I[9 ^ 31]).setNoScrollbar().setNoTitle();
   }

   public abstract ItemStack getTabIconItem();

   public EnumEnchantmentType[] getRelevantEnchantmentTypes() {
      return this.enchantmentTypes;
   }

   public void displayAllRelevantItems(NonNullList<ItemStack> var1) {
      Iterator var2 = Item.REGISTRY.iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         Item var3 = (Item)var2.next();
         var3.getSubItems(this, var1);
         "".length();
      } while(-1 < 1);

      throw null;
   }

   public boolean drawInForegroundOfTab() {
      return this.drawTitle;
   }

   private static void I() {
      I = new String[155 ^ 140];
      I["".length()] = I("\u00135=\n9T16\u0000", "zAXgJ");
      I[" ".length()] = I("啯煞", "EQCAi");
      I["  ".length()] = I("嚂埻", "JVHqv");
      I["   ".length()] = I("嫂橐", "GOjCW");
      I[132 ^ 128] = I("塂漒", "qbhGq");
      I[20 ^ 17] = I("啇棾淼剽恛", "KImya");
      I[107 ^ 109] = I("洜嶭浅忹楦", "lFYUg");
      I[78 ^ 73] = I("渼擃帨湋", "abKev");
      I[47 ^ 39] = I("\u000e\u00037\u0017#\u0015\u0018'\nJ", "gwRzd");
      I[22 ^ 31] = I("\r\u001d\u0000!\u0005\u0006\u0006\u000e\u000f\r\u0000\u000b\u0002>", "ohiMa");
      I[190 ^ 180] = I("4\t\u000f\u001b\u00141\u0018\u0005\u001b\b#", "Plltf");
      I[206 ^ 197] = I("\u0014\u0006#\u001b9\t\r\"", "fcGhM");
      I[205 ^ 193] = I("\"!\u0002\"\n&<\u00118\u0018\":\f\"", "VScLy");
      I[96 ^ 109] = I(")*\u0005\u0019", "DCvzc");
      I[68 ^ 74] = I(")\u000e\r\u0007&2", "ZkluE");
      I[42 ^ 37] = I("\u0019\u0000\u0006>\u0006\u0003\u0011\u0002!:\u0018Z\u0013=>", "ptcSY");
      I[209 ^ 193] = I("\u00039>\u0014", "eVQpm");
      I[191 ^ 174] = I("?\u0004;:\u0016", "KkTVe");
      I[2 ^ 16] = I("\u000e\t$.4\u0019", "mfILU");
      I[170 ^ 185] = I("\u000b7$\u0002!\u0007\"", "iEAuH");
      I[156 ^ 136] = I("0\f'\u0011 *", "XcSsA");
      I[172 ^ 185] = I("\u001b(\u0004\u0012\u0003\u0006)\u0000\u000e", "rFrwm");
      I[214 ^ 192] = I("\u000f8\u001a37\u00129\u001e/w\u00168\u000b", "fVlVY");
   }

   public boolean func_192394_m() {
      int var10000;
      if (this.getTabColumn() == (70 ^ 67)) {
         var10000 = " ".length();
         "".length();
         if (2 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int getTabColumn() {
      return this.tabIndex % (172 ^ 170);
   }

   public int getTabIndex() {
      return this.tabIndex;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 2);

      throw null;
   }

   public String getTranslatedTabLabel() {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[84 ^ 80];
      I[159 ^ 154].length();
      I[38 ^ 32].length();
      I[56 ^ 63].length();
      return I[112 ^ 120] + this.getTabLabel();
   }

   public ItemStack getIconItemStack() {
      if (this.iconItemStack.isEmpty()) {
         this.iconItemStack = this.getTabIconItem();
      }

      return this.iconItemStack;
   }

   public CreativeTabs setBackgroundImageName(String var1) {
      this.theTexture = var1;
      return this;
   }

   public boolean isTabInFirstRow() {
      int var10000;
      if (this.tabIndex < (0 ^ 6)) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public boolean shouldHidePlayerInventory() {
      return this.hasScrollbar;
   }

   public CreativeTabs(int var1, String var2) {
      this.theTexture = I["".length()];
      this.hasScrollbar = (boolean)" ".length();
      this.drawTitle = (boolean)" ".length();
      this.enchantmentTypes = new EnumEnchantmentType["".length()];
      this.tabIndex = var1;
      this.tabLabel = var2;
      this.iconItemStack = ItemStack.field_190927_a;
      CREATIVE_TAB_ARRAY[var1] = this;
   }

   public String getTabLabel() {
      return this.tabLabel;
   }

   public String getBackgroundImageName() {
      return this.theTexture;
   }

   public CreativeTabs setRelevantEnchantmentTypes(EnumEnchantmentType... var1) {
      this.enchantmentTypes = var1;
      return this;
   }

   public boolean hasRelevantEnchantmentType(@Nullable EnumEnchantmentType var1) {
      if (var1 != null) {
         EnumEnchantmentType[] var2 = this.enchantmentTypes;
         int var3 = var2.length;
         int var4 = "".length();

         while(var4 < var3) {
            EnumEnchantmentType var5 = var2[var4];
            if (var5 == var1) {
               return (boolean)" ".length();
            }

            ++var4;
            "".length();
            if (4 < -1) {
               throw null;
            }
         }
      }

      return (boolean)"".length();
   }
}

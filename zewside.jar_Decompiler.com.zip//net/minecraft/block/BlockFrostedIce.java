package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class BlockFrostedIce extends BlockIce {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyInteger AGE;

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      return ItemStack.field_190927_a;
   }

   private static void I() {
      I = new String[183 ^ 160];
      I["".length()] = I("擋仗厾滳", "ozTTq");
      I[" ".length()] = I("引唭僸喬", "TyXTu");
      I["  ".length()] = I("刏", "SEzTD");
      I["   ".length()] = I("倝斲典唑帓", "OFItg");
      I[73 ^ 77] = I("丩日淟崣孳", "TLRYs");
      I[180 ^ 177] = I("埅喅庫", "bpXRF");
      I[68 ^ 66] = I("滃剱坺檲恶", "BjMpo");
      I[150 ^ 145] = I("檜晛", "lBQMX");
      I[164 ^ 172] = I("泹崭", "AVhbY");
      I[149 ^ 156] = I("怸堤", "bFCqH");
      I[15 ^ 5] = I("愽棎", "OBBdn");
      I[80 ^ 91] = I("椺曝", "eKZor");
      I[60 ^ 48] = I("滦峡", "KZgfL");
      I[154 ^ 151] = I("匬徶", "CVuYR");
      I[126 ^ 112] = I("坪戴", "Hgpby");
      I[51 ^ 60] = I("澏敭榸", "tGxyc");
      I[89 ^ 73] = I("抒姊僆", "QWxuO");
      I[159 ^ 142] = I("槯", "KAGPc");
      I[129 ^ 147] = I("偛亨", "QARkg");
      I[75 ^ 88] = I("扐傣圞", "Legjc");
      I[134 ^ 146] = I("噮恀侁濴橃", "LuvNC");
      I[129 ^ 148] = I("倾", "oFyor");
      I[156 ^ 138] = I("#\t\u000e", "BnkEP");
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(AGE);
   }

   public BlockFrostedIce() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(AGE, "".length()));
   }

   protected void slightlyMelt(World var1, BlockPos var2, IBlockState var3, Random var4, boolean var5) {
      int var6 = (Integer)var3.getValue(AGE);
      if (var6 < "   ".length()) {
         var1.setBlockState(var2, var3.withProperty(AGE, var6 + " ".length()), "  ".length());
         I[4 ^ 0].length();
         I[194 ^ 199].length();
         I[180 ^ 178].length();
         var1.scheduleUpdate(var2, this, MathHelper.getInt(var4, 54 ^ 34, 144 ^ 184));
         "".length();
         if (0 >= 3) {
            throw null;
         }
      } else {
         this.turnIntoWater(var1, var2);
         if (var5) {
            EnumFacing[] var7 = EnumFacing.values();
            int var8 = var7.length;
            int var9 = "".length();

            while(var9 < var8) {
               EnumFacing var10 = var7[var9];
               BlockPos var11 = var2.offset(var10);
               IBlockState var12 = var1.getBlockState(var11);
               if (var12.getBlock() == this) {
                  this.slightlyMelt(var1, var11, var12, var4, (boolean)"".length());
               }

               ++var9;
               "".length();
               if (3 < 0) {
                  throw null;
               }
            }
         }
      }

   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (var4.nextInt("   ".length()) == 0 || this.countNeighbors(var1, var2) < (109 ^ 105)) {
         int var10000 = var1.getLightFromNeighbors(var2);
         int var10001 = 44 ^ 39;
         int var10002 = (Integer)var3.getValue(AGE);
         I["".length()].length();
         I[" ".length()].length();
         var10001 -= var10002;
         var10002 = var3.getLightOpacity();
         I["  ".length()].length();
         I["   ".length()].length();
         if (var10000 > var10001 - var10002) {
            this.slightlyMelt(var1, var2, var3, var4, (boolean)" ".length());
            "".length();
            if (3 <= -1) {
               throw null;
            }

            return;
         }
      }

      var1.scheduleUpdate(var2, this, MathHelper.getInt(var4, 43 ^ 63, 54 ^ 30));
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[181 ^ 178];
      String var10001 = I[88 ^ 80];
      String var10002 = I[65 ^ 72];
      var10001 = I[189 ^ 183];
      var10000 = I[132 ^ 143];
      var10001 = I[182 ^ 186];
      var10002 = I[84 ^ 89];
      var10001 = I[131 ^ 141];
      I[30 ^ 17].length();
      I[37 ^ 53].length();
      I[176 ^ 161].length();
      I[103 ^ 117].length();
      I[97 ^ 114].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[77 ^ 89].length();
      I[119 ^ 98].length();
      var10003["".length()] = AGE;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(AGE, MathHelper.clamp(var1, "".length(), "   ".length()));
   }

   static {
      I();
      AGE = PropertyInteger.create(I[150 ^ 128], "".length(), "   ".length());
   }

   private int countNeighbors(World var1, BlockPos var2) {
      int var3 = "".length();
      EnumFacing[] var4 = EnumFacing.values();
      int var5 = var4.length;
      int var6 = "".length();

      do {
         if (var6 >= var5) {
            return var3;
         }

         EnumFacing var7 = var4[var6];
         if (var1.getBlockState(var2.offset(var7)).getBlock() == this) {
            ++var3;
            if (var3 >= (21 ^ 17)) {
               return var3;
            }
         }

         ++var6;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (var4 == this) {
         int var6 = this.countNeighbors(var2, var3);
         if (var6 < "  ".length()) {
            this.turnIntoWater(var2, var3);
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 != 0);

      throw null;
   }
}

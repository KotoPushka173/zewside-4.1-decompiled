package net.minecraft.block;

import com.google.common.base.Predicate;
import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockTorch extends Block {
   // $FF: synthetic field
   protected static final AxisAlignedBB TORCH_SOUTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB TORCH_NORTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB STANDING_AABB;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB TORCH_EAST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB TORCH_WEST_AABB;

   protected boolean checkForDrop(World var1, BlockPos var2, IBlockState var3) {
      if (var3.getBlock() == this && this.canPlaceAt(var1, var2, (EnumFacing)var3.getValue(FACING))) {
         return (boolean)" ".length();
      } else {
         if (var1.getBlockState(var2).getBlock() == this) {
            this.dropBlockAsItem(var1, var2, var3, "".length());
            var1.setBlockToAir(var2);
            I[7 ^ 0].length();
         }

         return (boolean)"".length();
      }
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
         var2 |= " ".length();
         "".length();
         if (0 >= 3) {
            throw null;
         }
         break;
      case 2:
         var2 |= "  ".length();
         "".length();
         if (1 <= -1) {
            throw null;
         }
         break;
      case 3:
         var2 |= "   ".length();
         "".length();
         if (2 < 1) {
            throw null;
         }
         break;
      case 4:
         var2 |= 97 ^ 101;
         "".length();
         if (false) {
            throw null;
         }
         break;
      case 5:
      case 6:
      default:
         var2 |= 25 ^ 28;
      }

      return var2;
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      Iterator var3 = FACING.getAllowedValues().iterator();

      do {
         if (!var3.hasNext()) {
            return (boolean)"".length();
         }

         EnumFacing var4 = (EnumFacing)var3.next();
         if (this.canPlaceAt(var1, var2, var4)) {
            return (boolean)" ".length();
         }

         "".length();
      } while(4 != 0);

      throw null;
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      if (this.canPlaceAt(var1, var2, var3)) {
         return this.getDefaultState().withProperty(FACING, var3);
      } else {
         Iterator var9 = EnumFacing.Plane.HORIZONTAL.iterator();

         do {
            if (!var9.hasNext()) {
               return this.getDefaultState();
            }

            EnumFacing var10 = (EnumFacing)var9.next();
            if (this.canPlaceAt(var1, var2, var10)) {
               return this.getDefaultState().withProperty(FACING, var10);
            }

            "".length();
         } while(2 == 2);

         throw null;
      }
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var2 = this.getDefaultState();
      switch(var1) {
      case 1:
         var2 = var2.withProperty(FACING, EnumFacing.EAST);
         "".length();
         if (0 >= 2) {
            throw null;
         }
         break;
      case 2:
         var2 = var2.withProperty(FACING, EnumFacing.WEST);
         "".length();
         if (3 < -1) {
            throw null;
         }
         break;
      case 3:
         var2 = var2.withProperty(FACING, EnumFacing.SOUTH);
         "".length();
         if (0 >= 3) {
            throw null;
         }
         break;
      case 4:
         var2 = var2.withProperty(FACING, EnumFacing.NORTH);
         "".length();
         if (3 < 0) {
            throw null;
         }
         break;
      case 5:
      default:
         var2 = var2.withProperty(FACING, EnumFacing.UP);
      }

      return var2;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[91 ^ 83];
      String var10001 = I[125 ^ 116];
      String var10002 = I[88 ^ 82];
      var10001 = I[200 ^ 195];
      var10000 = I[38 ^ 42];
      var10001 = I[20 ^ 25];
      var10002 = I[44 ^ 34];
      var10001 = I[98 ^ 109];
      I[143 ^ 159].length();
      I[3 ^ 18].length();
      I[121 ^ 107].length();
      I[102 ^ 117].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[98 ^ 118].length();
      var10003["".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   protected BlockTorch() {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.UP));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   static {
      I();
      FACING = PropertyDirection.create(I[87 ^ 66], new Predicate<EnumFacing>() {
         public boolean apply(@Nullable EnumFacing var1) {
            int var10000;
            if (var1 != EnumFacing.DOWN) {
               var10000 = " ".length();
               "".length();
               if (0 >= 1) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 == 3);

            throw null;
         }
      });
      STANDING_AABB = new AxisAlignedBB(0.4000000059604645D, 0.0D, 0.4000000059604645D, 0.6000000238418579D, 0.6000000238418579D, 0.6000000238418579D);
      TORCH_NORTH_AABB = new AxisAlignedBB(0.3499999940395355D, 0.20000000298023224D, 0.699999988079071D, 0.6499999761581421D, 0.800000011920929D, 1.0D);
      TORCH_SOUTH_AABB = new AxisAlignedBB(0.3499999940395355D, 0.20000000298023224D, 0.0D, 0.6499999761581421D, 0.800000011920929D, 0.30000001192092896D);
      TORCH_WEST_AABB = new AxisAlignedBB(0.699999988079071D, 0.20000000298023224D, 0.3499999940395355D, 1.0D, 0.800000011920929D, 0.6499999761581421D);
      TORCH_EAST_AABB = new AxisAlignedBB(0.0D, 0.20000000298023224D, 0.3499999940395355D, 0.30000001192092896D, 0.800000011920929D, 0.6499999761581421D);
   }

   private boolean canPlaceAt(World var1, BlockPos var2, EnumFacing var3) {
      BlockPos var4 = var2.offset(var3.getOpposite());
      IBlockState var5 = var1.getBlockState(var4);
      Block var6 = var5.getBlock();
      BlockFaceShape var7 = var5.func_193401_d(var1, var4, var3);
      if (var3.equals(EnumFacing.UP) && this.canPlaceOn(var1, var4)) {
         return (boolean)" ".length();
      } else if (var3 != EnumFacing.UP && var3 != EnumFacing.DOWN) {
         int var10000;
         if (!func_193382_c(var6) && var7 == BlockFaceShape.SOLID) {
            var10000 = " ".length();
            "".length();
            if (2 >= 4) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      } else {
         return (boolean)"".length();
      }
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      this.checkForDrop(var1, var2, var3);
      I["".length()].length();
      I[" ".length()].length();
   }

   protected boolean onNeighborChangeInternal(World var1, BlockPos var2, IBlockState var3) {
      if (!this.checkForDrop(var1, var2, var3)) {
         return (boolean)" ".length();
      } else {
         EnumFacing var4 = (EnumFacing)var3.getValue(FACING);
         EnumFacing.Axis var5 = var4.getAxis();
         EnumFacing var6 = var4.getOpposite();
         BlockPos var7 = var2.offset(var6);
         int var8 = "".length();
         if (var5.isHorizontal() && var1.getBlockState(var7).func_193401_d(var1, var7, var4) != BlockFaceShape.SOLID) {
            var8 = " ".length();
            "".length();
            if (2 <= 1) {
               throw null;
            }
         } else if (var5.isVertical() && !this.canPlaceOn(var1, var7)) {
            var8 = " ".length();
         }

         if (var8 != 0) {
            this.dropBlockAsItem(var1, var2, var3, "".length());
            var1.setBlockToAir(var2);
            I[151 ^ 146].length();
            I[113 ^ 119].length();
            return (boolean)" ".length();
         } else {
            return (boolean)"".length();
         }
      }
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   private static void I() {
      I = new String[126 ^ 104];
      I["".length()] = I("悌妬", "pBErt");
      I[" ".length()] = I("峚", "qAfDs");
      I["  ".length()] = I("哉嚅", "Jvtvf");
      I["   ".length()] = I("氼", "bKonS");
      I[9 ^ 13] = I("殰悉咄", "cfvKm");
      I[155 ^ 158] = I("嬱劕渜敋", "QRBoQ");
      I[45 ^ 43] = I("奧樚", "jTEDE");
      I[106 ^ 109] = I("嫯傦恔", "qNnAo");
      I[2 ^ 10] = I("奉兰", "NlJBG");
      I[37 ^ 44] = I("拖朐", "TytCO");
      I[123 ^ 113] = I("僚嬑", "tEZhB");
      I[20 ^ 31] = I("况冎", "Kerkl");
      I[64 ^ 76] = I("娸咇", "hHBrx");
      I[47 ^ 34] = I("摰澝", "CyFvT");
      I[185 ^ 183] = I("槺毋", "FQtDs");
      I[103 ^ 104] = I("欍憥", "EnCUb");
      I[17 ^ 1] = I("偖氍嶊夳", "XrHZg");
      I[175 ^ 190] = I("涍滏媪", "DDfiW");
      I[185 ^ 171] = I("榉嵻噒唁伉", "bJVng");
      I[83 ^ 64] = I("横储廹声唕", "IzRgo");
      I[121 ^ 109] = I("槍毝歊", "sNgTN");
      I[34 ^ 55] = I("\u000f0\u001b!\u001e\u000e", "iQxHp");
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      EnumFacing var5 = (EnumFacing)var1.getValue(FACING);
      double var6 = (double)var3.getX() + 0.5D;
      double var8 = (double)var3.getY() + 0.7D;
      double var10 = (double)var3.getZ() + 0.5D;
      double var12 = 0.22D;
      double var14 = 0.27D;
      if (var5.getAxis().isHorizontal()) {
         EnumFacing var16 = var5.getOpposite();
         var2.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, var6 + 0.27D * (double)var16.getFrontOffsetX(), var8 + 0.22D, var10 + 0.27D * (double)var16.getFrontOffsetZ(), 0.0D, 0.0D, 0.0D);
         var2.spawnParticle(EnumParticleTypes.FLAME, var6 + 0.27D * (double)var16.getFrontOffsetX(), var8 + 0.22D, var10 + 0.27D * (double)var16.getFrontOffsetZ(), 0.0D, 0.0D, 0.0D);
         "".length();
         if (3 <= 2) {
            throw null;
         }
      } else {
         var2.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, var6, var8, var10, 0.0D, 0.0D, 0.0D);
         var2.spawnParticle(EnumParticleTypes.FLAME, var6, var8, var10, 0.0D, 0.0D, 0.0D);
      }

   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      this.onNeighborChangeInternal(var2, var3, var1);
      I["  ".length()].length();
      I["   ".length()].length();
      I[160 ^ 164].length();
   }

   private boolean canPlaceOn(World var1, BlockPos var2) {
      Block var3 = var1.getBlockState(var2).getBlock();
      int var10000;
      if (var3 != Blocks.END_GATEWAY && var3 != Blocks.LIT_PUMPKIN) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (4 != 4) {
            throw null;
         }
      }

      int var4 = var10000;
      if (var1.getBlockState(var2).isFullyOpaque()) {
         if (var4 == 0) {
            var10000 = " ".length();
            "".length();
            if (-1 != -1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      } else {
         if (!(var3 instanceof BlockFence) && var3 != Blocks.GLASS && var3 != Blocks.COBBLESTONE_WALL && var3 != Blocks.STAINED_GLASS) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (2 >= 3) {
               throw null;
            }
         }

         int var5 = var10000;
         if (var5 != 0 && var4 == 0) {
            var10000 = " ".length();
            "".length();
            if (4 < -1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
         return TORCH_EAST_AABB;
      case 2:
         return TORCH_WEST_AABB;
      case 3:
         return TORCH_SOUTH_AABB;
      case 4:
         return TORCH_NORTH_AABB;
      default:
         return STANDING_AABB;
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 1);

      throw null;
   }
}

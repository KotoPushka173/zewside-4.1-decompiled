package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketSpawnPlayer implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private double z;
   // $FF: synthetic field
   private byte pitch;
   // $FF: synthetic field
   private double y;
   // $FF: synthetic field
   private double x;
   // $FF: synthetic field
   private EntityDataManager watcher;
   // $FF: synthetic field
   private UUID uniqueId;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private List<EntityDataManager.DataEntry<?>> dataManagerEntries;
   // $FF: synthetic field
   private byte yaw;

   public double getY() {
      return this.y;
   }

   public byte getPitch() {
      return this.pitch;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.uniqueId = var1.readUuid();
      this.x = var1.readDouble();
      this.y = var1.readDouble();
      this.z = var1.readDouble();
      this.yaw = var1.readByte();
      this.pitch = var1.readByte();
      this.dataManagerEntries = EntityDataManager.readEntries(var1);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 0);

      throw null;
   }

   public SPacketSpawnPlayer(EntityPlayer var1) {
      this.entityId = var1.getEntityId();
      this.uniqueId = var1.getGameProfile().getId();
      this.x = var1.posX;
      this.y = var1.posY;
      this.z = var1.posZ;
      this.yaw = (byte)((int)(var1.rotationYaw * 256.0F / 360.0F));
      this.pitch = (byte)((int)(var1.rotationPitch * 256.0F / 360.0F));
      this.watcher = var1.getDataManager();
   }

   public byte getYaw() {
      return this.yaw;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSpawnPlayer(this);
   }

   static {
      I();
   }

   public int getEntityID() {
      return this.entityId;
   }

   public SPacketSpawnPlayer() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeUuid(this.uniqueId);
      I["  ".length()].length();
      var1.writeDouble(this.x);
      I["   ".length()].length();
      I[15 ^ 11].length();
      I[146 ^ 151].length();
      I[14 ^ 8].length();
      var1.writeDouble(this.y);
      I[79 ^ 72].length();
      var1.writeDouble(this.z);
      I[29 ^ 21].length();
      I[21 ^ 28].length();
      var1.writeByte(this.yaw);
      I[103 ^ 109].length();
      I[141 ^ 134].length();
      var1.writeByte(this.pitch);
      I[64 ^ 76].length();
      I[96 ^ 109].length();
      I[46 ^ 32].length();
      this.watcher.writeEntries(var1);
   }

   private static void I() {
      I = new String[21 ^ 26];
      I["".length()] = I("圙傲椅", "tPkTs");
      I[" ".length()] = I("曎", "hMvWN");
      I["  ".length()] = I("巰兗恔擲徂", "zgvkN");
      I["   ".length()] = I("嶕", "FrpGb");
      I[148 ^ 144] = I("毈", "FGGrc");
      I[169 ^ 172] = I("婪寮應峯埋", "Wxtzw");
      I[144 ^ 150] = I("氼", "yzWZn");
      I[58 ^ 61] = I("懅宎", "MfYkQ");
      I[149 ^ 157] = I("儈婯", "LCCYg");
      I[74 ^ 67] = I("潿殎朿烇", "QSggK");
      I[64 ^ 74] = I("坟", "udcgk");
      I[122 ^ 113] = I("旜榇晛倦", "mPPfM");
      I[98 ^ 110] = I("湔唿于曳", "tGTZA");
      I[17 ^ 28] = I("其昄", "KNxag");
      I[109 ^ 99] = I("刳", "knRQj");
   }

   @Nullable
   public List<EntityDataManager.DataEntry<?>> getDataManagerEntries() {
      return this.dataManagerEntries;
   }

   public double getZ() {
      return this.z;
   }

   public double getX() {
      return this.x;
   }

   public UUID getUniqueId() {
      return this.uniqueId;
   }
}

package net.minecraft.block;

import com.google.common.base.Predicate;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.util.EnumFacing;

public abstract class BlockHorizontal extends Block {
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   private static final String[] I;

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("2\u0000\u0010%\b3", "TasLf");
   }

   static {
      I();
      FACING = PropertyDirection.create(I["".length()], (Predicate)EnumFacing.Plane.HORIZONTAL);
   }

   protected BlockHorizontal(Material var1) {
      super(var1);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   protected BlockHorizontal(Material var1, MapColor var2) {
      super(var1, var2);
   }
}

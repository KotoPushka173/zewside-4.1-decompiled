package net.minecraft.block.state.pattern;

import com.google.common.base.Predicate;
import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;

public class BlockStateMatcher implements Predicate<IBlockState> {
   // $FF: synthetic field
   public static final Predicate<IBlockState> ANY;
   // $FF: synthetic field
   private final Map<IProperty<?>, Predicate<?>> propertyPredicates = Maps.newHashMap();
   // $FF: synthetic field
   private final BlockStateContainer blockstate;
   // $FF: synthetic field
   private static final String[] I;

   private BlockStateMatcher(BlockStateContainer var1) {
      this.blockstate = var1;
   }

   public boolean apply(@Nullable IBlockState var1) {
      if (var1 != null && var1.getBlock().equals(this.blockstate.getBlock())) {
         if (this.propertyPredicates.isEmpty()) {
            return (boolean)" ".length();
         } else {
            Iterator var2 = this.propertyPredicates.entrySet().iterator();

            do {
               if (!var2.hasNext()) {
                  return (boolean)" ".length();
               }

               Entry var3 = (Entry)var2.next();
               if (!this.matches(var1, (IProperty)var3.getKey(), (Predicate)var3.getValue())) {
                  return (boolean)"".length();
               }

               "".length();
            } while(3 != 0);

            throw null;
         }
      } else {
         return (boolean)"".length();
      }
   }

   public <V extends Comparable<V>> BlockStateMatcher where(IProperty<V> var1, Predicate<? extends V> var2) {
      String var10000 = I[140 ^ 132];
      String var10001 = I[53 ^ 60];
      String var10002 = I[52 ^ 62];
      var10001 = I[119 ^ 124];
      var10000 = I[3 ^ 15];
      var10001 = I[63 ^ 50];
      var10002 = I[8 ^ 6];
      var10001 = I[15 ^ 0];
      if (!this.blockstate.getProperties().contains(var1)) {
         I[215 ^ 199].length();
         I[10 ^ 27].length();
         I[133 ^ 151].length();
         I[125 ^ 110].length();
         IllegalArgumentException var3 = new IllegalArgumentException(this.blockstate + I[50 ^ 38] + var1);
         I[3 ^ 22].length();
         throw var3;
      } else {
         this.propertyPredicates.put(var1, var2);
         I[42 ^ 60].length();
         I[29 ^ 10].length();
         I[6 ^ 30].length();
         return this;
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   static {
      I();
      ANY = new Predicate<IBlockState>() {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 > 1);

            throw null;
         }

         public boolean apply(@Nullable IBlockState var1) {
            return (boolean)" ".length();
         }
      };
   }

   public static BlockStateMatcher forBlock(Block var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[10 ^ 14].length();
      I[15 ^ 10].length();
      I[148 ^ 146].length();
      I[127 ^ 120].length();
      return new BlockStateMatcher(var0.getBlockState());
   }

   private static void I() {
      I = new String[52 ^ 45];
      I["".length()] = I("懧呙", "OPBee");
      I[" ".length()] = I("忩卣", "gzCiL");
      I["  ".length()] = I("憾啙", "rpIWt");
      I["   ".length()] = I("凟峭", "XfprX");
      I[196 ^ 192] = I("彑汷漪娝涼", "kswUv");
      I[49 ^ 52] = I("憢奷敇兹", "qmMwJ");
      I[31 ^ 25] = I("杻亸嚮歔", "nyesB");
      I[137 ^ 142] = I("呛吡", "HihhW");
      I[31 ^ 23] = I("汰懏", "UqXwk");
      I[105 ^ 96] = I("支富", "olKoU");
      I[153 ^ 147] = I("浊樼", "KGSGZ");
      I[16 ^ 27] = I("峅嘎", "ecpPx");
      I[22 ^ 26] = I("嬮凋", "zRJwh");
      I[132 ^ 137] = I("厲堀", "LzVpG");
      I[158 ^ 144] = I("濿墀", "LSiPe");
      I[70 ^ 73] = I("僪悩", "IHDeU");
      I[190 ^ 174] = I("撳壄吗", "SlgDj");
      I[21 ^ 4] = I("掫涅始丿", "TNXsf");
      I[172 ^ 190] = I("恓桘暥徢", "AxzXj");
      I[190 ^ 173] = I("冰嚭偣杷", "OUmbT");
      I[4 ^ 16] = I("L$;\u0019 \u00033z\u0004;\u001c75\u0005:L7(\u0018>\t5.\u000en", "lGZwN");
      I[13 ^ 24] = I("瀹沱洌", "nDahO");
      I[160 ^ 182] = I("榙歚岮斪墓", "hPybW");
      I[181 ^ 162] = I("悿挪", "bAhvi");
      I[7 ^ 31] = I("侔愮岙", "ODWZc");
   }

   protected <T extends Comparable<T>> boolean matches(IBlockState var1, IProperty<T> var2, Predicate<T> var3) {
      return var3.apply(var1.getValue(var2));
   }
}

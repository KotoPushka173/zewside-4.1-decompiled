package net.minecraft.network.play.server;

import java.io.IOException;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketEntityAttach implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int vehicleEntityId;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int entityId;

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityAttach(this);
   }

   public int getEntityId() {
      return this.entityId;
   }

   static {
      I();
   }

   public SPacketEntityAttach() {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 1);

      throw null;
   }

   public int getVehicleEntityId() {
      return this.vehicleEntityId;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readInt();
      this.vehicleEntityId = var1.readInt();
   }

   public SPacketEntityAttach(Entity var1, @Nullable Entity var2) {
      this.entityId = var1.getEntityId();
      int var10001;
      if (var2 != null) {
         var10001 = var2.getEntityId();
         "".length();
         if (3 < 0) {
            throw null;
         }
      } else {
         var10001 = -" ".length();
      }

      this.vehicleEntityId = var10001;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeInt(this.entityId);
      I["".length()].length();
      var1.writeInt(this.vehicleEntityId);
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      I[188 ^ 184].length();
   }

   private static void I() {
      I = new String[117 ^ 112];
      I["".length()] = I("歐剮垪慰瀗", "puxga");
      I[" ".length()] = I("揈", "xGIiU");
      I["  ".length()] = I("匉峷", "tkimt");
      I["   ".length()] = I("宰", "pUmmL");
      I[12 ^ 8] = I("儺并敠植樺", "qZOKu");
   }
}

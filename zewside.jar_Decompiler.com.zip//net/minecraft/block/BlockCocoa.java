package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockCocoa extends BlockHorizontal implements IGrowable {
   // $FF: synthetic field
   protected static final AxisAlignedBB[] COCOA_EAST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] COCOA_NORTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] COCOA_WEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] COCOA_SOUTH_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyInteger AGE;

   public void grow(World var1, Random var2, BlockPos var3, IBlockState var4) {
      var1.setBlockState(var3, var4.withProperty(AGE, (Integer)var4.getValue(AGE) + " ".length()), "  ".length());
      I[1 ^ 19].length();
      I[103 ^ 116].length();
      I[68 ^ 80].length();
      I[68 ^ 81].length();
      I[70 ^ 80].length();
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      EnumFacing var6 = EnumFacing.fromAngle((double)var4.rotationYaw);
      var1.setBlockState(var2, var3.withProperty(FACING, var6), "  ".length());
      I["  ".length()].length();
      I["   ".length()].length();
      I[83 ^ 87].length();
   }

   public BlockCocoa() {
      super(Material.PLANTS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(AGE, "".length()));
      this.setTickRandomly((boolean)" ".length());
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static void I() {
      I = new String[160 ^ 139];
      I["".length()] = I("嬱斨梚", "Lgibw");
      I[" ".length()] = I("噺叓", "BWUGc");
      I["  ".length()] = I("摰拰桥咡殩", "rbVew");
      I["   ".length()] = I("殈宎妆框", "gVlYh");
      I[103 ^ 99] = I("劅器", "ItBRH");
      I[59 ^ 62] = I("忥培", "yIFnM");
      I[108 ^ 106] = I("朐摘", "ZggvB");
      I[187 ^ 188] = I("槉嵯", "kiCoH");
      I[141 ^ 133] = I("劤泆", "wKodO");
      I[89 ^ 80] = I("仁偍", "FAqWu");
      I[17 ^ 27] = I("咥澘搾嗏揽", "FEjNZ");
      I[91 ^ 80] = I("怪憐娊炠", "fnuVF");
      I[109 ^ 97] = I("峀坚啃椺櫼", "Impnu");
      I[56 ^ 53] = I("沩桥", "yUZrw");
      I[144 ^ 158] = I("刻泯", "WGcef");
      I[91 ^ 84] = I("嵽慩", "aHWQZ");
      I[10 ^ 26] = I("偹寤", "iUtvk");
      I[28 ^ 13] = I("濐殢咂傓", "ehbLh");
      I[61 ^ 47] = I("昺斾掎幑", "DeHiI");
      I[185 ^ 170] = I("恗", "zZEhs");
      I[183 ^ 163] = I("峬嗑澝", "caTgp");
      I[35 ^ 54] = I("叕寘", "CAoBD");
      I[76 ^ 90] = I("娩妘溂", "hVJoT");
      I[213 ^ 194] = I("冤塿", "rlxkI");
      I[115 ^ 107] = I("泽妑", "XjIxI");
      I[47 ^ 54] = I("抧彾", "ekmoy");
      I[63 ^ 37] = I("欞淶", "iKbMT");
      I[183 ^ 172] = I("梄柮", "RLWeF");
      I[160 ^ 188] = I("潂侙", "qSjcm");
      I[71 ^ 90] = I("椃烓", "VYoYP");
      I[70 ^ 88] = I("樵呅", "feCLh");
      I[123 ^ 100] = I("巒挡", "OXEfb");
      I[157 ^ 189] = I("堲嗯", "xUUfi");
      I[23 ^ 54] = I("橒亘", "CTZwv");
      I[191 ^ 157] = I("寿涉", "rywJg");
      I[177 ^ 146] = I("恂傒櫵", "sOQlK");
      I[131 ^ 167] = I("劗兇明敄", "YScWQ");
      I[87 ^ 114] = I("剻", "WuYka");
      I[148 ^ 178] = I("媱", "tvVVA");
      I[66 ^ 101] = I("澘呀兲坥椬", "aoEqp");
      I[12 ^ 36] = I("偔恤沒", "momny");
      I[76 ^ 101] = I("坦淿", "SrkVs");
      I[36 ^ 14] = I("(\u0000/", "IgJQr");
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      int var4 = (Integer)var1.getValue(AGE);
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
         return COCOA_SOUTH_AABB[var4];
      case 2:
      default:
         return COCOA_NORTH_AABB[var4];
      case 3:
         return COCOA_WEST_AABB[var4];
      case 4:
         return COCOA_EAST_AABB[var4];
      }
   }

   public boolean canGrow(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      int var10000;
      if ((Integer)var3.getValue(AGE) < "  ".length()) {
         var10000 = " ".length();
         "".length();
         if (-1 != -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      if (!var3.getAxis().isHorizontal()) {
         var3 = EnumFacing.NORTH;
      }

      return this.getDefaultState().withProperty(FACING, var3.getOpposite()).withProperty(AGE, "".length());
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= -1);

      throw null;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!this.canBlockStay(var1, var2, var3)) {
         this.dropBlock(var1, var2, var3);
         "".length();
         if (false) {
            throw null;
         }
      } else if (var1.rand.nextInt(10 ^ 15) == 0) {
         int var5 = (Integer)var3.getValue(AGE);
         if (var5 < "  ".length()) {
            var1.setBlockState(var2, var3.withProperty(AGE, var5 + " ".length()), "  ".length());
            I["".length()].length();
            I[" ".length()].length();
         }
      }

   }

   static {
      I();
      AGE = PropertyInteger.create(I[68 ^ 110], "".length(), "  ".length());
      AxisAlignedBB[] var10000 = new AxisAlignedBB["   ".length()];
      var10000["".length()] = new AxisAlignedBB(0.6875D, 0.4375D, 0.375D, 0.9375D, 0.75D, 0.625D);
      var10000[" ".length()] = new AxisAlignedBB(0.5625D, 0.3125D, 0.3125D, 0.9375D, 0.75D, 0.6875D);
      var10000["  ".length()] = new AxisAlignedBB(0.4375D, 0.1875D, 0.25D, 0.9375D, 0.75D, 0.75D);
      COCOA_EAST_AABB = var10000;
      var10000 = new AxisAlignedBB["   ".length()];
      var10000["".length()] = new AxisAlignedBB(0.0625D, 0.4375D, 0.375D, 0.3125D, 0.75D, 0.625D);
      var10000[" ".length()] = new AxisAlignedBB(0.0625D, 0.3125D, 0.3125D, 0.4375D, 0.75D, 0.6875D);
      var10000["  ".length()] = new AxisAlignedBB(0.0625D, 0.1875D, 0.25D, 0.5625D, 0.75D, 0.75D);
      COCOA_WEST_AABB = var10000;
      var10000 = new AxisAlignedBB["   ".length()];
      var10000["".length()] = new AxisAlignedBB(0.375D, 0.4375D, 0.0625D, 0.625D, 0.75D, 0.3125D);
      var10000[" ".length()] = new AxisAlignedBB(0.3125D, 0.3125D, 0.0625D, 0.6875D, 0.75D, 0.4375D);
      var10000["  ".length()] = new AxisAlignedBB(0.25D, 0.1875D, 0.0625D, 0.75D, 0.75D, 0.5625D);
      COCOA_NORTH_AABB = var10000;
      var10000 = new AxisAlignedBB["   ".length()];
      var10000["".length()] = new AxisAlignedBB(0.375D, 0.4375D, 0.6875D, 0.625D, 0.75D, 0.9375D);
      var10000[" ".length()] = new AxisAlignedBB(0.3125D, 0.3125D, 0.5625D, 0.6875D, 0.75D, 0.9375D);
      var10000["  ".length()] = new AxisAlignedBB(0.25D, 0.1875D, 0.4375D, 0.75D, 0.75D, 0.9375D);
      COCOA_SOUTH_AABB = var10000;
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      String var10000 = I[27 ^ 29];
      String var10001 = I[31 ^ 24];
      String var10002 = I[92 ^ 84];
      var10001 = I[130 ^ 139];
      int var6 = (Integer)var3.getValue(AGE);
      int var7 = " ".length();
      if (var6 >= "  ".length()) {
         var7 = "   ".length();
      }

      int var8 = "".length();

      do {
         if (var8 >= var7) {
            return;
         }

         I[30 ^ 20].length();
         I[74 ^ 65].length();
         I[21 ^ 25].length();
         spawnAsEntity(var1, var2, new ItemStack(Items.DYE, " ".length(), EnumDyeColor.BROWN.getDyeDamage()));
         ++var8;
         "".length();
      } while(4 > 0);

      throw null;
   }

   public boolean canBlockStay(World var1, BlockPos var2, IBlockState var3) {
      var2 = var2.offset((EnumFacing)var3.getValue(FACING));
      IBlockState var4 = var1.getBlockState(var2);
      int var10000;
      if (var4.getBlock() == Blocks.LOG && var4.getValue(BlockOldLog.VARIANT) == BlockPlanks.EnumType.JUNGLE) {
         var10000 = " ".length();
         "".length();
         if (1 >= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.byHorizontalIndex(var1)).withProperty(AGE, (var1 & (144 ^ 159)) >> "  ".length());
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean canUseBonemeal(World var1, Random var2, BlockPos var3, IBlockState var4) {
      return (boolean)" ".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[136 ^ 159];
      String var10001 = I[70 ^ 94];
      String var10002 = I[62 ^ 39];
      var10001 = I[19 ^ 9];
      var10000 = I[159 ^ 132];
      var10001 = I[140 ^ 144];
      var10002 = I[43 ^ 54];
      var10001 = I[124 ^ 98];
      var10000 = I[99 ^ 124];
      var10001 = I[126 ^ 94];
      var10002 = I[33 ^ 0];
      var10001 = I[135 ^ 165];
      I[90 ^ 121].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[147 ^ 183].length();
      I[224 ^ 197].length();
      I[47 ^ 9].length();
      var10003["".length()] = FACING;
      I[229 ^ 194].length();
      I[164 ^ 140].length();
      I[98 ^ 75].length();
      var10003[" ".length()] = AGE;
      return new BlockStateContainer(this, var10003);
   }

   private void dropBlock(World var1, BlockPos var2, IBlockState var3) {
      var1.setBlockState(var2, Blocks.AIR.getDefaultState(), "   ".length());
      I[135 ^ 130].length();
      this.dropBlockAsItem(var1, var2, var3, "".length());
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
      var2 |= (Integer)var1.getValue(AGE) << "  ".length();
      return var2;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!this.canBlockStay(var2, var3, var1)) {
         this.dropBlock(var2, var3, var1);
      }

   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[138 ^ 135];
      String var10001 = I[50 ^ 60];
      String var10002 = I[54 ^ 57];
      var10001 = I[75 ^ 91];
      I[129 ^ 144].length();
      return new ItemStack(Items.DYE, " ".length(), EnumDyeColor.BROWN.getDyeDamage());
   }
}

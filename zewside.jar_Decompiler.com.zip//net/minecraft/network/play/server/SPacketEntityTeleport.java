package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketEntityTeleport implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private boolean onGround;
   // $FF: synthetic field
   private byte pitch;
   // $FF: synthetic field
   private double posX;
   // $FF: synthetic field
   private byte yaw;
   // $FF: synthetic field
   private double posY;
   // $FF: synthetic field
   private double posZ;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private static final String[] I;

   public double getX() {
      return this.posX;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   private static void I() {
      I = new String[135 ^ 147];
      I["".length()] = I("嶪抸", "ViOZv");
      I[" ".length()] = I("撧", "kiJFv");
      I["  ".length()] = I("浅溟掛灇", "EkbNB");
      I["   ".length()] = I("屭", "dVhsx");
      I[5 ^ 1] = I("咦慊喍撦倳", "xMzWp");
      I[103 ^ 98] = I("孉傆", "WAKCc");
      I[195 ^ 197] = I("弩奟啞庖", "wiHSY");
      I[46 ^ 41] = I("旺夛", "EAsFe");
      I[39 ^ 47] = I("測噬汙", "MeaEd");
      I[129 ^ 136] = I("傺岈漕嗬弿", "hlUwi");
      I[150 ^ 156] = I("涿嵦晄幀", "bOHaz");
      I[107 ^ 96] = I("昽", "YUMVq");
      I[3 ^ 15] = I("勀噿嶨", "xVwKE");
      I[22 ^ 27] = I("擕嫳", "yAKyV");
      I[177 ^ 191] = I("仒摋博", "GKXPM");
      I[181 ^ 186] = I("枓旻峁", "dKWVM");
      I[64 ^ 80] = I("掣", "QGfqO");
      I[99 ^ 114] = I("涢", "yKwsk");
      I[117 ^ 103] = I("枱", "owUjg");
      I[9 ^ 26] = I("湶洟厏幌侏", "eEGlH");
   }

   public double getY() {
      return this.posY;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeDouble(this.posX);
      I["  ".length()].length();
      I["   ".length()].length();
      I[158 ^ 154].length();
      I[139 ^ 142].length();
      var1.writeDouble(this.posY);
      I[72 ^ 78].length();
      I[26 ^ 29].length();
      I[29 ^ 21].length();
      I[163 ^ 170].length();
      var1.writeDouble(this.posZ);
      I[172 ^ 166].length();
      I[77 ^ 70].length();
      I[50 ^ 62].length();
      var1.writeByte(this.yaw);
      I[28 ^ 17].length();
      I[35 ^ 45].length();
      I[143 ^ 128].length();
      var1.writeByte(this.pitch);
      I[65 ^ 81].length();
      var1.writeBoolean(this.onGround);
      I[159 ^ 142].length();
      I[88 ^ 74].length();
      I[137 ^ 154].length();
   }

   public double getZ() {
      return this.posZ;
   }

   public byte getPitch() {
      return this.pitch;
   }

   public int getEntityId() {
      return this.entityId;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityTeleport(this);
   }

   public byte getYaw() {
      return this.yaw;
   }

   public boolean getOnGround() {
      return this.onGround;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.posX = var1.readDouble();
      this.posY = var1.readDouble();
      this.posZ = var1.readDouble();
      this.yaw = var1.readByte();
      this.pitch = var1.readByte();
      this.onGround = var1.readBoolean();
   }

   static {
      I();
   }

   public SPacketEntityTeleport(Entity var1) {
      this.entityId = var1.getEntityId();
      this.posX = var1.posX;
      this.posY = var1.posY;
      this.posZ = var1.posZ;
      this.yaw = (byte)((int)(var1.rotationYaw * 256.0F / 360.0F));
      this.pitch = (byte)((int)(var1.rotationPitch * 256.0F / 360.0F));
      this.onGround = var1.onGround;
   }

   public SPacketEntityTeleport() {
   }
}

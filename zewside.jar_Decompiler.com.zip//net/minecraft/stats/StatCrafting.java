package net.minecraft.stats;

import net.minecraft.item.Item;
import net.minecraft.util.text.ITextComponent;

public class StatCrafting extends StatBase {
   // $FF: synthetic field
   private final Item item;

   public StatCrafting(String var1, String var2, ITextComponent var3, Item var4) {
      super(var1 + var2, var3);
      this.item = var4;
   }

   public Item getItem() {
      return this.item;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 0);

      throw null;
   }
}

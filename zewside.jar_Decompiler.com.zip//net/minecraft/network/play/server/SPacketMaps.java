package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.storage.MapData;
import net.minecraft.world.storage.MapDecoration;

public class SPacketMaps implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int minZ;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int columns;
   // $FF: synthetic field
   private boolean trackingPosition;
   // $FF: synthetic field
   private byte[] mapDataBytes;
   // $FF: synthetic field
   private int mapId;
   // $FF: synthetic field
   private int rows;
   // $FF: synthetic field
   private MapDecoration[] icons;
   // $FF: synthetic field
   private int minX;
   // $FF: synthetic field
   private byte mapScale;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.mapId);
      I[192 ^ 198].length();
      I[65 ^ 70].length();
      var1.writeByte(this.mapScale);
      I[108 ^ 100].length();
      I[15 ^ 6].length();
      var1.writeBoolean(this.trackingPosition);
      I[83 ^ 89].length();
      I[172 ^ 167].length();
      I[87 ^ 91].length();
      var1.writeVarIntToBuffer(this.icons.length);
      I[85 ^ 88].length();
      I[46 ^ 32].length();
      I[4 ^ 11].length();
      I[172 ^ 188].length();
      MapDecoration[] var2 = this.icons;
      int var3 = var2.length;
      int var4 = "".length();

      do {
         if (var4 >= var3) {
            var1.writeByte(this.columns);
            I[175 ^ 186].length();
            if (this.columns > 0) {
               var1.writeByte(this.rows);
               I[21 ^ 3].length();
               I[134 ^ 145].length();
               I[83 ^ 75].length();
               I[76 ^ 85].length();
               var1.writeByte(this.minX);
               I[70 ^ 92].length();
               I[128 ^ 155].length();
               var1.writeByte(this.minZ);
               I[64 ^ 92].length();
               var1.writeByteArray(this.mapDataBytes);
               I[176 ^ 173].length();
               I[153 ^ 135].length();
               I[42 ^ 53].length();
               I[77 ^ 109].length();
            }

            return;
         }

         MapDecoration var5 = var2[var4];
         var1.writeByte((var5.getType() & (29 ^ 18)) << (132 ^ 128) | var5.getRotation() & (4 ^ 11));
         I[87 ^ 70].length();
         I[80 ^ 66].length();
         var1.writeByte(var5.getX());
         I[5 ^ 22].length();
         var1.writeByte(var5.getY());
         I[191 ^ 171].length();
         ++var4;
         "".length();
      } while(-1 != 3);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 1);

      throw null;
   }

   public int getMapId() {
      return this.mapId;
   }

   static {
      I();
   }

   public SPacketMaps() {
   }

   public void setMapdataTo(MapData var1) {
      String var10000 = I[3 ^ 34];
      String var10001 = I[151 ^ 181];
      String var10002 = I[173 ^ 142];
      var10001 = I[97 ^ 69];
      var1.scale = this.mapScale;
      var1.trackingPosition = this.trackingPosition;
      var1.mapDecorations.clear();
      int var2 = "".length();

      while(var2 < this.icons.length) {
         MapDecoration var3 = this.icons[var2];
         Map var5 = var1.mapDecorations;
         I[190 ^ 155].length();
         var5.put(I[122 ^ 92] + var2, var3);
         I[135 ^ 160].length();
         I[163 ^ 139].length();
         ++var2;
         "".length();
         if (-1 >= 3) {
            throw null;
         }
      }

      var2 = "".length();

      do {
         if (var2 >= this.columns) {
            return;
         }

         int var4 = "".length();

         while(var4 < this.rows) {
            var1.colors[this.minX + var2 + (this.minZ + var4) * (89 + 109 - 100 + 30)] = this.mapDataBytes[var2 + var4 * this.columns];
            ++var4;
            "".length();
            if (4 < 0) {
               throw null;
            }
         }

         ++var2;
         "".length();
      } while(-1 != 1);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleMaps(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      this.mapId = var1.readVarIntFromBuffer();
      this.mapScale = var1.readByte();
      this.trackingPosition = var1.readBoolean();
      this.icons = new MapDecoration[var1.readVarIntFromBuffer()];
      int var2 = "".length();

      do {
         if (var2 >= this.icons.length) {
            this.columns = var1.readUnsignedByte();
            if (this.columns > 0) {
               this.rows = var1.readUnsignedByte();
               this.minX = var1.readUnsignedByte();
               this.minZ = var1.readUnsignedByte();
               this.mapDataBytes = var1.readByteArray();
            }

            return;
         }

         short var3 = (short)var1.readByte();
         MapDecoration[] var4 = this.icons;
         I[163 ^ 167].length();
         I[35 ^ 38].length();
         var4[var2] = new MapDecoration(MapDecoration.Type.func_191159_a((byte)(var3 >> (189 ^ 185) & (73 ^ 70))), var1.readByte(), var1.readByte(), (byte)(var3 & (173 ^ 162)));
         ++var2;
         "".length();
      } while(3 != 0);

      throw null;
   }

   private static void I() {
      I = new String[147 ^ 186];
      I["".length()] = I("墜拧", "AeYsU");
      I[" ".length()] = I("摞媋", "rpqTm");
      I["  ".length()] = I("瀼嶳", "DQiTe");
      I["   ".length()] = I("浓搔", "LVDws");
      I[129 ^ 133] = I("瀹", "CHyuG");
      I[182 ^ 179] = I("俅冠", "EMDiI");
      I[110 ^ 104] = I("棙傾", "tADHU");
      I[135 ^ 128] = I("歼曡捅", "fKnLg");
      I[130 ^ 138] = I("徴永供樊", "jiJYV");
      I[167 ^ 174] = I("匿惎僸培夀", "dXdsu");
      I[0 ^ 10] = I("潙库", "aSLod");
      I[93 ^ 86] = I("惃匳揶俺", "zJcPv");
      I[42 ^ 38] = I("偿瀷氼", "nERCv");
      I[186 ^ 183] = I("措氍亄", "mGJYW");
      I[77 ^ 67] = I("梇媥", "vxSKS");
      I[22 ^ 25] = I("囂姮", "sJwCs");
      I[42 ^ 58] = I("冷库", "ePGOm");
      I[124 ^ 109] = I("冑", "KQPEh");
      I[75 ^ 89] = I("柝囫", "IZeuZ");
      I[37 ^ 54] = I("嘆潳吖", "IExYI");
      I[78 ^ 90] = I("氉", "ZtZYa");
      I[86 ^ 67] = I("烆崭崮", "VEFZH");
      I[213 ^ 195] = I("昗最渪塴", "FRHAn");
      I[74 ^ 93] = I("摑尹槨", "gqKaR");
      I[139 ^ 147] = I("柂平丕灏", "LATqw");
      I[13 ^ 20] = I("枦灚什浳", "qPtGe");
      I[190 ^ 164] = I("擽亄澤炿", "lfFqo");
      I[39 ^ 60] = I("欰", "WwxeQ");
      I[13 ^ 17] = I("樜愴", "xGiIv");
      I[82 ^ 79] = I("捱暓岼垧", "GxcQD");
      I[181 ^ 171] = I("冡擒坈捈垱", "LRtFd");
      I[154 ^ 133] = I("摕奒洼杯", "TwREC");
      I[50 ^ 18] = I("淊洕", "UaJmt");
      I[82 ^ 115] = I("儭槨", "npyhU");
      I[104 ^ 74] = I("憹沵", "HzOpx");
      I[17 ^ 50] = I("楷湫", "AJlAH");
      I[47 ^ 11] = I("擆嫢", "vRxMg");
      I[38 ^ 3] = I("巤斦", "LIqWy");
      I[38 ^ 0] = I("!\u0006\u0000'd", "HeoII");
      I[3 ^ 36] = I("懩倓擁", "IYMYx");
      I[20 ^ 60] = I("泖", "HrGor");
   }

   public SPacketMaps(int var1, byte var2, boolean var3, Collection<MapDecoration> var4, byte[] var5, int var6, int var7, int var8, int var9) {
      this.mapId = var1;
      this.mapScale = var2;
      this.trackingPosition = var3;
      this.icons = (MapDecoration[])((MapDecoration[])var4.toArray(new MapDecoration[var4.size()]));
      this.minX = var6;
      this.minZ = var7;
      this.columns = var8;
      this.rows = var9;
      this.mapDataBytes = new byte[var8 * var9];
      int var10 = "".length();

      do {
         if (var10 >= var8) {
            return;
         }

         int var11 = "".length();

         while(var11 < var9) {
            this.mapDataBytes[var10 + var11 * var8] = var5[var6 + var10 + (var7 + var11) * (91 + 43 - 52 + 46)];
            ++var11;
            "".length();
            if (0 >= 3) {
               throw null;
            }
         }

         ++var10;
         "".length();
      } while(4 > 0);

      throw null;
   }
}

package net.minecraft.block;

import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRail extends BlockRailBase {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockRailBase.EnumRailDirection> SHAPE;

   public int getMetaFromState(IBlockState var1) {
      return ((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).getMetadata();
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(SHAPE, BlockRailBase.EnumRailDirection.byMetadata(var1));
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         }
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 9:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
         case 10:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH);
         }
      case 3:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 9:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
         case 10:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH);
         }
      default:
         return var1;
      }
   }

   static {
      I();
      SHAPE = PropertyEnum.create(I[40 ^ 59], BlockRailBase.EnumRailDirection.class);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[74 ^ 76];
      String var10001 = I[2 ^ 5];
      String var10002 = I[170 ^ 162];
      var10001 = I[34 ^ 43];
      var10000 = I[188 ^ 182];
      var10001 = I[104 ^ 99];
      var10002 = I[84 ^ 88];
      var10001 = I[78 ^ 67];
      I[60 ^ 50].length();
      I[140 ^ 131].length();
      I[65 ^ 81].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[16 ^ 1].length();
      I[164 ^ 182].length();
      var10003["".length()] = SHAPE;
      return new BlockStateContainer(this, var10003);
   }

   public IProperty<BlockRailBase.EnumRailDirection> getShapeProperty() {
      return SHAPE;
   }

   private static void I() {
      I = new String[128 ^ 148];
      I["".length()] = I("汨栅", "nXqBk");
      I[" ".length()] = I("捲啁", "cvzCI");
      I["  ".length()] = I("唔朠", "LxDre");
      I["   ".length()] = I("帶勋", "MhvIF");
      I[80 ^ 84] = I("濯", "DAEGF");
      I[176 ^ 181] = I("昽汑呢炖", "fRMTg");
      I[143 ^ 137] = I("煍嫡", "pqTQL");
      I[82 ^ 85] = I("橀煭", "XHvBd");
      I[25 ^ 17] = I("揤坃", "lngmm");
      I[55 ^ 62] = I("嬃撺", "jlwXT");
      I[151 ^ 157] = I("堨僞", "QQxds");
      I[173 ^ 166] = I("浀卫", "jHMxB");
      I[5 ^ 9] = I("昻崷", "tNKzw");
      I[36 ^ 41] = I("弌孆", "UrUEl");
      I[120 ^ 118] = I("暾嫝套塃", "cBrsx");
      I[94 ^ 81] = I("晱", "bgWqq");
      I[166 ^ 182] = I("椢帑湧憭刯", "oaaQO");
      I[156 ^ 141] = I("溝寄欻", "sDSmt");
      I[126 ^ 108] = I("歐啊", "UznoD");
      I[47 ^ 60] = I("\u0005\u00012\u0003\u0002", "viSsg");
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      BlockRailBase.EnumRailDirection var3 = (BlockRailBase.EnumRailDirection)var1.getValue(SHAPE);
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[var3.ordinal()]) {
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         default:
            return super.withMirror(var1, var2);
         }
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[var3.ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 3:
         case 4:
         default:
            "".length();
            if (-1 >= 4) {
               throw null;
            }
            break;
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         }
      default:
         return super.withMirror(var1, var2);
      }
   }

   protected BlockRail() {
      super((boolean)"".length());
      this.setDefaultState(this.blockState.getBaseState().withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH));
   }

   protected void updateState(IBlockState var1, World var2, BlockPos var3, Block var4) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (var4.getDefaultState().canProvidePower()) {
         I[143 ^ 139].length();
         if ((new BlockRailBase.Rail(var2, var3, var1)).countAdjacentRails() == "   ".length()) {
            this.updateDir(var2, var3, var1, (boolean)"".length());
            I[134 ^ 131].length();
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 != 4);

      throw null;
   }
}

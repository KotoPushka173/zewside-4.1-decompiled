package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.util.EnumHandSide;

public class CPacketClientSettings implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private int modelPartFlags;
   // $FF: synthetic field
   private boolean enableColors;
   // $FF: synthetic field
   private String lang;
   // $FF: synthetic field
   private EntityPlayer.EnumChatVisibility chatVisibility;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private EnumHandSide mainHand;
   // $FF: synthetic field
   private int view;

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.lang = var1.readStringFromBuffer(57 ^ 41);
      this.view = var1.readByte();
      this.chatVisibility = (EntityPlayer.EnumChatVisibility)var1.readEnumValue(EntityPlayer.EnumChatVisibility.class);
      this.enableColors = var1.readBoolean();
      this.modelPartFlags = var1.readUnsignedByte();
      this.mainHand = (EnumHandSide)var1.readEnumValue(EnumHandSide.class);
   }

   public int getModelPartFlags() {
      return this.modelPartFlags;
   }

   public EntityPlayer.EnumChatVisibility getChatVisibility() {
      return this.chatVisibility;
   }

   private static void I() {
      I = new String[101 ^ 106];
      I["".length()] = I("岞刵擲媏兝", "FWAKC");
      I[" ".length()] = I("兂溩氹煖", "dvnPy");
      I["  ".length()] = I("堒就奵廹", "SoBop");
      I["   ".length()] = I("图攳徯幌噊", "pcHww");
      I[86 ^ 82] = I("橲槖大婔", "kArDn");
      I[123 ^ 126] = I("檂櫛懹嗈儗", "Bcvkw");
      I[77 ^ 75] = I("晨", "PwdXq");
      I[192 ^ 199] = I("敳", "FCDLo");
      I[153 ^ 145] = I("榅刵塳廴", "LOXDA");
      I[9 ^ 0] = I("封屉棜匰", "olKza");
      I[143 ^ 133] = I("卛嶁叭梏", "oZbfe");
      I[108 ^ 103] = I("渱", "bsXms");
      I[40 ^ 36] = I("摵", "gZsgV");
      I[29 ^ 16] = I("桷囿櫔厱", "ZdNoT");
      I[154 ^ 148] = I("搾娺位炣惫", "aPikD");
   }

   public EnumHandSide getMainHand() {
      return this.mainHand;
   }

   static {
      I();
   }

   public String getLang() {
      return this.lang;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processClientSettings(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.lang);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeByte(this.view);
      I["   ".length()].length();
      I[0 ^ 4].length();
      var1.writeEnumValue(this.chatVisibility);
      I[94 ^ 91].length();
      I[196 ^ 194].length();
      I[188 ^ 187].length();
      var1.writeBoolean(this.enableColors);
      I[101 ^ 109].length();
      I[155 ^ 146].length();
      var1.writeByte(this.modelPartFlags);
      I[22 ^ 28].length();
      I[117 ^ 126].length();
      I[207 ^ 195].length();
      I[172 ^ 161].length();
      var1.writeEnumValue(this.mainHand);
      I[144 ^ 158].length();
   }

   public CPacketClientSettings(String var1, int var2, EntityPlayer.EnumChatVisibility var3, boolean var4, int var5, EnumHandSide var6) {
      this.lang = var1;
      this.view = var2;
      this.chatVisibility = var3;
      this.enableColors = var4;
      this.modelPartFlags = var5;
      this.mainHand = var6;
   }

   public boolean isColorsEnabled() {
      return this.enableColors;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 2);

      throw null;
   }

   public CPacketClientSettings() {
   }
}

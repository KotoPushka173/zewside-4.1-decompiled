package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityDaylightDetector;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockDaylightDetector extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB DAYLIGHT_DETECTOR_AABB;
   // $FF: synthetic field
   private final boolean inverted;
   // $FF: synthetic field
   public static final PropertyInteger POWER;

   public void updatePower(World var1, BlockPos var2) {
      if (var1.provider.isNether()) {
         IBlockState var3 = var1.getBlockState(var2);
         int var10000 = var1.getLightFor(EnumSkyBlock.SKY, var2);
         int var10001 = var1.getSkylightSubtracted();
         I[" ".length()].length();
         int var4 = var10000 - var10001;
         float var5 = var1.getCelestialAngleRadians(1.0F);
         if (this.inverted) {
            var10000 = 157 ^ 146;
            I["  ".length()].length();
            I["   ".length()].length();
            I[25 ^ 29].length();
            var4 = var10000 - var4;
         }

         if (var4 > 0 && !this.inverted) {
            float var7;
            if (var5 < 3.1415927F) {
               var7 = 0.0F;
               "".length();
               if (4 == 0) {
                  throw null;
               }
            } else {
               var7 = 6.2831855F;
            }

            float var6 = var7;
            I[66 ^ 71].length();
            I[7 ^ 1].length();
            var5 += (var6 - var5) * 0.2F;
            var4 = Math.round((float)var4 * MathHelper.cos(var5));
         }

         var4 = MathHelper.clamp(var4, "".length(), 184 ^ 183);
         if ((Integer)var3.getValue(POWER) != var4) {
            var1.setBlockState(var2, var3.withProperty(POWER, var4), "   ".length());
            I[121 ^ 126].length();
            I[69 ^ 77].length();
            I[185 ^ 176].length();
         }
      }

   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return DAYLIGHT_DETECTOR_AABB;
   }

   public boolean canProvidePower(IBlockState var1) {
      return (boolean)" ".length();
   }

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return (Integer)var1.getValue(POWER);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(POWER, var1);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[15 ^ 18];
      String var10001 = I[126 ^ 96];
      String var10002 = I[83 ^ 76];
      var10001 = I[99 ^ 67];
      var10000 = I[53 ^ 20];
      var10001 = I[43 ^ 9];
      var10002 = I[8 ^ 43];
      var10001 = I[79 ^ 107];
      I[57 ^ 28].length();
      I[5 ^ 35].length();
      I[60 ^ 27].length();
      I[118 ^ 94].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[42 ^ 3].length();
      I[161 ^ 139].length();
      I[141 ^ 166].length();
      var10003["".length()] = POWER;
      return new BlockStateContainer(this, var10003);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 4);

      throw null;
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.DAYLIGHT_DETECTOR);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[67 ^ 82];
      String var10001 = I[15 ^ 29];
      String var10002 = I[36 ^ 55];
      var10001 = I[37 ^ 49];
      I[19 ^ 6].length();
      I[213 ^ 195].length();
      return new ItemStack(Blocks.DAYLIGHT_DETECTOR);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var4.isAllowEdit()) {
         if (var1.isRemote) {
            return (boolean)" ".length();
         } else {
            if (this.inverted) {
               var1.setBlockState(var2, Blocks.DAYLIGHT_DETECTOR.getDefaultState().withProperty(POWER, var3.getValue(POWER)), 180 ^ 176);
               I[164 ^ 174].length();
               I[191 ^ 180].length();
               I[153 ^ 149].length();
               Blocks.DAYLIGHT_DETECTOR.updatePower(var1, var2);
               "".length();
               if (4 <= 3) {
                  throw null;
               }
            } else {
               var1.setBlockState(var2, Blocks.DAYLIGHT_DETECTOR_INVERTED.getDefaultState().withProperty(POWER, var3.getValue(POWER)), 161 ^ 165);
               I[180 ^ 185].length();
               I[54 ^ 56].length();
               I[169 ^ 166].length();
               I[17 ^ 1].length();
               Blocks.DAYLIGHT_DETECTOR_INVERTED.updatePower(var1, var2);
            }

            return (boolean)" ".length();
         }
      } else {
         return super.onBlockActivated(var1, var2, var3, var4, var5, var6, var7, var8, var9);
      }
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static void I() {
      I = new String[133 ^ 168];
      I["".length()] = I("/$*9&,-'\u0011*? 0! 9", "KESUO");
      I[" ".length()] = I("妧咰枒", "mXMjV");
      I["  ".length()] = I("咻", "aibBt");
      I["   ".length()] = I("恰侞峙惏", "dqTun");
      I[168 ^ 172] = I("嵣拹娬斿", "BHwrn");
      I[101 ^ 96] = I("服扐厅卫撳", "fDyQx");
      I[133 ^ 131] = I("凮拻呑换寍", "OcDeD");
      I[48 ^ 55] = I("栦殒滄布忣", "zPJFf");
      I[128 ^ 136] = I("咵", "CObQu");
      I[113 ^ 120] = I("吵", "MExOP");
      I[90 ^ 80] = I("煶", "TqiAY");
      I[139 ^ 128] = I("冝凲凿", "LnTKB");
      I[171 ^ 167] = I("振探櫛堆", "qqaOP");
      I[160 ^ 173] = I("橺氫掋抪", "sFzGZ");
      I[59 ^ 53] = I("囀", "heFKR");
      I[121 ^ 118] = I("慊", "Itdry");
      I[190 ^ 174] = I("渏嗟泇椛", "MKPPs");
      I[10 ^ 27] = I("抙点", "UiXHL");
      I[16 ^ 2] = I("俪漐", "dbTQk");
      I[39 ^ 52] = I("斫泛", "cQEfS");
      I[172 ^ 184] = I("埰匐", "oXxeO");
      I[77 ^ 88] = I("濼桗検懁", "cwaMx");
      I[139 ^ 157] = I("塾墽憗奈姉", "tNUbN");
      I[68 ^ 83] = I("婊壆", "GvRRB");
      I[89 ^ 65] = I("左僖", "uHycJ");
      I[39 ^ 62] = I("刦嫀", "fcyRd");
      I[148 ^ 142] = I("朑桧", "OSoSw");
      I[163 ^ 184] = I("澚檐嫹栂", "ccPRw");
      I[157 ^ 129] = I("忻氓", "KLkqv");
      I[138 ^ 151] = I("烄交", "gNDiU");
      I[136 ^ 150] = I("堾攮", "MiIIb");
      I[189 ^ 162] = I("攓栀", "Foyef");
      I[152 ^ 184] = I("叾呕", "mPJuT");
      I[190 ^ 159] = I("拥勛", "LBafF");
      I[37 ^ 7] = I("兝囈", "jYUES");
      I[18 ^ 49] = I("湿待", "hjosP");
      I[150 ^ 178] = I("欗滀", "OkBCB");
      I[230 ^ 195] = I("堏僤墎感", "kkFaO");
      I[97 ^ 71] = I("旤弫扭侄", "mQHVt");
      I[101 ^ 66] = I("楙", "yRCmQ");
      I[64 ^ 104] = I("寱咐冃斸匡", "sBnpa");
      I[110 ^ 71] = I("已湚", "QAFyT");
      I[45 ^ 7] = I("斿搀", "VNHKu");
      I[116 ^ 95] = I("泱仜杞氞欽", "BCQEQ");
      I[23 ^ 59] = I("1,>#?", "ACIFM");
   }

   static {
      I();
      POWER = PropertyInteger.create(I[66 ^ 110], "".length(), 167 ^ 168);
      DAYLIGHT_DETECTOR_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.375D, 1.0D);
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = BlockFaceShape.SOLID;
         "".length();
         if (0 <= -1) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[190 ^ 169];
      String var10001 = I[17 ^ 9];
      String var10002 = I[145 ^ 136];
      var10001 = I[161 ^ 187];
      I[32 ^ 59].length();
      I[59 ^ 39].length();
      return new TileEntityDaylightDetector();
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(POWER);
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      if (!this.inverted) {
         super.getSubBlocks(var1, var2);
      }

   }

   public BlockDaylightDetector(boolean var1) {
      super(Material.WOOD);
      this.inverted = var1;
      this.setDefaultState(this.blockState.getBaseState().withProperty(POWER, "".length()));
      this.setCreativeTab(CreativeTabs.REDSTONE);
      this.setHardness(0.2F);
      this.setSoundType(SoundType.WOOD);
      this.setUnlocalizedName(I["".length()]);
   }
}

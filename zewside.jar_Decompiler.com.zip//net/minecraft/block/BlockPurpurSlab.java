package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public abstract class BlockPurpurSlab extends BlockSlab {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockPurpurSlab.Variant> VARIANT;

   public Comparable<?> getTypeForItem(ItemStack var1) {
      return BlockPurpurSlab.Variant.DEFAULT;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      if (!this.isDouble() && var1.getValue(HALF) == BlockSlab.EnumBlockHalf.TOP) {
         var2 |= 58 ^ 50;
      }

      return var2;
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var2 = this.getDefaultState().withProperty(VARIANT, BlockPurpurSlab.Variant.DEFAULT);
      if (!this.isDouble()) {
         PropertyEnum var10001 = HALF;
         BlockSlab.EnumBlockHalf var10002;
         if ((var1 & (31 ^ 23)) == 0) {
            var10002 = BlockSlab.EnumBlockHalf.BOTTOM;
            "".length();
            if (2 >= 4) {
               throw null;
            }
         } else {
            var10002 = BlockSlab.EnumBlockHalf.TOP;
         }

         var2 = var2.withProperty(var10001, var10002);
      }

      return var2;
   }

   public BlockPurpurSlab() {
      super(Material.ROCK, MapColor.MAGENTA);
      IBlockState var1 = this.blockState.getBaseState();
      if (!this.isDouble()) {
         var1 = var1.withProperty(HALF, BlockSlab.EnumBlockHalf.BOTTOM);
      }

      this.setDefaultState(var1.withProperty(VARIANT, BlockPurpurSlab.Variant.DEFAULT));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[80 ^ 116], BlockPurpurSlab.Variant.class);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[4 ^ 3];
      String var10001 = I[149 ^ 157];
      String var10002 = I[155 ^ 146];
      var10001 = I[126 ^ 116];
      var10000 = I[31 ^ 20];
      var10001 = I[29 ^ 17];
      var10002 = I[151 ^ 154];
      var10001 = I[104 ^ 102];
      var10000 = I[182 ^ 185];
      var10001 = I[117 ^ 101];
      var10002 = I[34 ^ 51];
      var10001 = I[29 ^ 15];
      var10000 = I[109 ^ 126];
      var10001 = I[137 ^ 157];
      var10002 = I[131 ^ 150];
      var10001 = I[108 ^ 122];
      var10000 = I[189 ^ 170];
      var10001 = I[168 ^ 176];
      var10002 = I[43 ^ 50];
      var10001 = I[102 ^ 124];
      BlockStateContainer var1;
      IProperty[] var10003;
      if (this.isDouble()) {
         I[53 ^ 46].length();
         I[3 ^ 31].length();
         var10003 = new IProperty[" ".length()];
         I[163 ^ 190].length();
         I[167 ^ 185].length();
         var10003["".length()] = VARIANT;
         var1 = new BlockStateContainer(this, var10003);
         "".length();
         if (2 < 0) {
            throw null;
         }
      } else {
         I[25 ^ 6].length();
         var10003 = new IProperty["  ".length()];
         I[117 ^ 85].length();
         I[69 ^ 100].length();
         var10003["".length()] = HALF;
         I[65 ^ 99].length();
         I[153 ^ 186].length();
         var10003[" ".length()] = VARIANT;
         var1 = new BlockStateContainer(this, var10003);
      }

      return var1;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.PURPUR_SLAB);
   }

   private static void I() {
      I = new String[119 ^ 82];
      I["".length()] = I("劧嫒", "WUahZ");
      I[" ".length()] = I("伡惝", "WKHgT");
      I["  ".length()] = I("洝屋", "NbFPG");
      I["   ".length()] = I("右圲", "eJfDv");
      I[9 ^ 13] = I("棗傒", "ZINKl");
      I[155 ^ 158] = I("拄圗捋氌", "YzjeV");
      I[183 ^ 177] = I("伷札呀劄堢", "onEQs");
      I[77 ^ 74] = I("沆僸", "yHvna");
      I[34 ^ 42] = I("埖毀", "QYMfA");
      I[69 ^ 76] = I("咾喆", "qEcEN");
      I[204 ^ 198] = I("澂暰", "rHfeS");
      I[26 ^ 17] = I("婴所", "VVJMZ");
      I[153 ^ 149] = I("崱暓", "mUrTk");
      I[33 ^ 44] = I("瀍恫", "lyxvT");
      I[69 ^ 75] = I("吊氦", "cuxiI");
      I[179 ^ 188] = I("洮杳", "LStAz");
      I[124 ^ 108] = I("垏掬", "miRDW");
      I[211 ^ 194] = I("灖恓", "FxfpR");
      I[181 ^ 167] = I("忻僜", "YQTEh");
      I[141 ^ 158] = I("媝挓", "HlOZD");
      I[26 ^ 14] = I("娃嘿", "oSGXZ");
      I[0 ^ 21] = I("姈涠", "xVDOI");
      I[62 ^ 40] = I("滞滿", "eJaAq");
      I[161 ^ 182] = I("澯氷", "DDxzd");
      I[158 ^ 134] = I("浬淭", "lModw");
      I[89 ^ 64] = I("惸潴", "DTwqD");
      I[71 ^ 93] = I("歫四", "UzbIN");
      I[134 ^ 157] = I("摺卭唒发", "OqWcK");
      I[160 ^ 188] = I("条", "Bzapi");
      I[68 ^ 89] = I("怅摝叨墔氡", "NYlga");
      I[187 ^ 165] = I("徠揋堳傈抹", "cRxHH");
      I[153 ^ 134] = I("傰", "glbRU");
      I[38 ^ 6] = I("丘澞噱尫榴", "NZPHH");
      I[86 ^ 119] = I("敵慚", "xYGSA");
      I[4 ^ 38] = I("摇", "AVWJX");
      I[21 ^ 54] = I("杇烫塊毱", "jpdJv");
      I[228 ^ 192] = I("\u0006,\u0018/+\u001e9", "pMjFJ");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[195 ^ 199].length();
      I[141 ^ 136].length();
      I[67 ^ 69].length();
      return new ItemStack(Blocks.PURPUR_SLAB);
   }

   public String getUnlocalizedName(int var1) {
      return super.getUnlocalizedName();
   }

   public IProperty<?> getVariantProperty() {
      return VARIANT;
   }

   public static class Double extends BlockPurpurSlab {
      public boolean isDouble() {
         return (boolean)" ".length();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 != 4);

         throw null;
      }
   }

   public static class Half extends BlockPurpurSlab {
      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 > -1);

         throw null;
      }

      public boolean isDouble() {
         return (boolean)"".length();
      }
   }

   public static enum Variant implements IStringSerializable {
      // $FF: synthetic field
      DEFAULT;

      // $FF: synthetic field
      private static final String[] I;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 == -1);

         throw null;
      }

      static {
         I();
         DEFAULT = new BlockPurpurSlab.Variant(I[" ".length()], "".length());
         BlockPurpurSlab.Variant[] var10000 = new BlockPurpurSlab.Variant[" ".length()];
         var10000["".length()] = DEFAULT;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I("\u0007\u0006%\u000e\u0000\u000f\u0017", "ccCou");
         I[" ".length()] = I("=&\f3\u000257", "ycJrW");
      }

      public String getName() {
         return I["".length()];
      }
   }
}

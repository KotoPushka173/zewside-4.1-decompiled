package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockSoulSand extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB SOUL_SAND_AABB;

   public BlockSoulSand() {
      super(Material.SAND, MapColor.BROWN);
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   private static void I() {
      I = new String[141 ^ 131];
      I["".length()] = I("掋堆", "LZyzr");
      I[" ".length()] = I("媆汜", "JwXuN");
      I["  ".length()] = I("圲斫", "rMXdp");
      I["   ".length()] = I("岪搚", "KAJPT");
      I[127 ^ 123] = I("圹栂", "LtpbP");
      I[9 ^ 12] = I("沈泪", "PMTLK");
      I[196 ^ 194] = I("歘刴", "oXFyh");
      I[28 ^ 27] = I("向吚", "ElPoS");
      I[70 ^ 78] = I("溊杬已巐", "ZDklJ");
      I[40 ^ 33] = I("潮斁捻潞", "lgTAA");
      I[204 ^ 198] = I("刪懚", "tepiP");
      I[155 ^ 144] = I("屧僨媹宽棪", "csScF");
      I[84 ^ 88] = I("凙嘡", "BUSAs");
      I[72 ^ 69] = I("澣杝埔檱", "AKmMI");
   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[178 ^ 182];
      var10001 = I[94 ^ 91];
      var10002 = I[51 ^ 53];
      var10001 = I[181 ^ 178];
      I[1 ^ 9].length();
      I[16 ^ 25].length();
      var4.motionX *= 0.4D;
      I[167 ^ 173].length();
      I[62 ^ 53].length();
      I[72 ^ 68].length();
      I[181 ^ 184].length();
      var4.motionZ *= 0.4D;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != 2);

      throw null;
   }

   static {
      I();
      SOUL_SAND_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.875D, 1.0D);
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return SOUL_SAND_AABB;
   }
}

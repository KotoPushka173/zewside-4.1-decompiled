package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.EnumDifficulty;

public class SPacketServerDifficulty implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private boolean difficultyLocked;
   // $FF: synthetic field
   private EnumDifficulty difficulty;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 > -1);

      throw null;
   }

   public boolean isDifficultyLocked() {
      return this.difficultyLocked;
   }

   private static void I() {
      I = new String["  ".length()];
      I["".length()] = I("怋潑", "RQUkb");
      I[" ".length()] = I("搘壩昿惂", "dPCBI");
   }

   public EnumDifficulty getDifficulty() {
      return this.difficulty;
   }

   public SPacketServerDifficulty() {
   }

   public SPacketServerDifficulty(EnumDifficulty var1, boolean var2) {
      this.difficulty = var1;
      this.difficultyLocked = var2;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.difficulty.getDifficultyId());
      I["".length()].length();
      I[" ".length()].length();
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleServerDifficulty(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.difficulty = EnumDifficulty.getDifficultyEnum(var1.readUnsignedByte());
   }
}

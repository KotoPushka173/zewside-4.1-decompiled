package net.minecraft.network.play.client;

import java.io.IOException;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class CPacketUseEntity implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private CPacketUseEntity.Action action;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private Vec3d hitVec;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private EnumHand hand;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I[31 ^ 25].length();
      var1.writeEnumValue(this.action);
      I[71 ^ 64].length();
      I[24 ^ 16].length();
      if (this.action == CPacketUseEntity.Action.INTERACT_AT) {
         var1.writeFloat((float)this.hitVec.x);
         I[83 ^ 90].length();
         I[19 ^ 25].length();
         var1.writeFloat((float)this.hitVec.y);
         I[139 ^ 128].length();
         var1.writeFloat((float)this.hitVec.z);
         I[139 ^ 135].length();
         I[206 ^ 195].length();
      }

      if (this.action == CPacketUseEntity.Action.INTERACT || this.action == CPacketUseEntity.Action.INTERACT_AT) {
         var1.writeEnumValue(this.hand);
         I[26 ^ 20].length();
         I[126 ^ 113].length();
         I[125 ^ 109].length();
      }

   }

   public CPacketUseEntity(Entity var1) {
      this.entityId = var1.getEntityId();
      this.action = CPacketUseEntity.Action.ATTACK;
   }

   public CPacketUseEntity() {
   }

   static {
      I();
   }

   public Vec3d getHitVec() {
      return this.hitVec;
   }

   private static void I() {
      I = new String[41 ^ 56];
      I["".length()] = I("壍掾", "EoQfQ");
      I[" ".length()] = I("嬭品", "KTabp");
      I["  ".length()] = I("栻岳", "sjgSn");
      I["   ".length()] = I("朓乿", "jSvzX");
      I[128 ^ 132] = I("凅", "kzLpo");
      I[18 ^ 23] = I("彻渰潄", "GeNTf");
      I[133 ^ 131] = I("侇", "irERB");
      I[73 ^ 78] = I("埁", "FliNG");
      I[80 ^ 88] = I("姗各唼斃", "DdTpk");
      I[63 ^ 54] = I("擂湅嶗匌", "sHHYK");
      I[122 ^ 112] = I("壓埩嵨匏旛", "qbleM");
      I[36 ^ 47] = I("嶵偷厚烘", "HRDoR");
      I[1 ^ 13] = I("朻彃淜", "nJLeV");
      I[151 ^ 154] = I("揆橈梟屩漟", "RaAMm");
      I[132 ^ 138] = I("弛冒槊夺潏", "RuNki");
      I[67 ^ 76] = I("勦帞怐歆", "zlSBo");
      I[106 ^ 122] = I("抑壿", "hxaAM");
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processUseEntity(this);
   }

   public CPacketUseEntity.Action getAction() {
      return this.action;
   }

   @Nullable
   public Entity getEntityFromWorld(World var1) {
      return var1.getEntityByID(this.entityId);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 0);

      throw null;
   }

   public CPacketUseEntity(Entity var1, EnumHand var2, Vec3d var3) {
      this.entityId = var1.getEntityId();
      this.action = CPacketUseEntity.Action.INTERACT_AT;
      this.hand = var2;
      this.hitVec = var3;
   }

   public CPacketUseEntity(Entity var1, EnumHand var2) {
      this.entityId = var1.getEntityId();
      this.action = CPacketUseEntity.Action.INTERACT;
      this.hand = var2;
   }

   public EnumHand getHand() {
      return this.hand;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      this.entityId = var1.readVarIntFromBuffer();
      this.action = (CPacketUseEntity.Action)var1.readEnumValue(CPacketUseEntity.Action.class);
      if (this.action == CPacketUseEntity.Action.INTERACT_AT) {
         I[45 ^ 41].length();
         I[129 ^ 132].length();
         this.hitVec = new Vec3d((double)var1.readFloat(), (double)var1.readFloat(), (double)var1.readFloat());
      }

      if (this.action == CPacketUseEntity.Action.INTERACT || this.action == CPacketUseEntity.Action.INTERACT_AT) {
         this.hand = (EnumHand)var1.readEnumValue(EnumHand.class);
      }

   }

   public static enum Action {
      // $FF: synthetic field
      INTERACT_AT,
      // $FF: synthetic field
      ATTACK;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      INTERACT;

      private static void I() {
         I = new String["   ".length()];
         I["".length()] = I("3\b%\u000e+;\u0005%", "zFqKy");
         I[" ".length()] = I("8\u001b\u0000\t&2", "yOTHe");
         I["  ".length()] = I("\u0004\u0018'\u0016\u0001\f\u0015'\f\u0012\u0019", "MVsSS");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > 2);

         throw null;
      }

      static {
         I();
         INTERACT = new CPacketUseEntity.Action(I["".length()], "".length());
         ATTACK = new CPacketUseEntity.Action(I[" ".length()], " ".length());
         INTERACT_AT = new CPacketUseEntity.Action(I["  ".length()], "  ".length());
         CPacketUseEntity.Action[] var10000 = new CPacketUseEntity.Action["   ".length()];
         var10000["".length()] = INTERACT;
         var10000[" ".length()] = ATTACK;
         var10000["  ".length()] = INTERACT_AT;
      }
   }
}

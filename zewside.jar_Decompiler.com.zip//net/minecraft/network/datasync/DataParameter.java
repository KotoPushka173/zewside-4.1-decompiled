package net.minecraft.network.datasync;

public class DataParameter<T> {
   // $FF: synthetic field
   private final int id;
   // $FF: synthetic field
   private final DataSerializer<T> serializer;

   public int getId() {
      return this.id;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 > -1);

      throw null;
   }

   public DataSerializer<T> getSerializer() {
      return this.serializer;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)" ".length();
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         DataParameter var2 = (DataParameter)var1;
         int var10000;
         if (this.id == var2.id) {
            var10000 = " ".length();
            "".length();
            if (4 < 2) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      } else {
         return (boolean)"".length();
      }
   }

   public int hashCode() {
      return this.id;
   }

   public DataParameter(int var1, DataSerializer<T> var2) {
      this.id = var1;
      this.serializer = var2;
   }
}

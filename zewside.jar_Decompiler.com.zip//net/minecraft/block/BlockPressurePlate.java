package net.minecraft.block;

import java.util.Iterator;
import java.util.List;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockPressurePlate extends BlockBasePressurePlate {
   // $FF: synthetic field
   public static final PropertyBool POWERED;
   // $FF: synthetic field
   private final BlockPressurePlate.Sensitivity sensitivity;
   // $FF: synthetic field
   private static final String[] I;

   public int getMetaFromState(IBlockState var1) {
      int var10000;
      if ((Boolean)var1.getValue(POWERED)) {
         var10000 = " ".length();
         "".length();
         if (-1 != -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   private static void I() {
      I = new String[115 ^ 99];
      I["".length()] = I("岻卑", "CRjLl");
      I[" ".length()] = I("昜婚", "hpZVY");
      I["  ".length()] = I("溈攸", "leWid");
      I["   ".length()] = I("僉戺", "AWWpA");
      I[88 ^ 92] = I("奂嚓", "EYuje");
      I[34 ^ 39] = I("娌图", "tKyoU");
      I[152 ^ 158] = I("椲女", "kwcBp");
      I[104 ^ 111] = I("坢啧", "vzMux");
      I[52 ^ 60] = I("斜滑槛", "Ciilz");
      I[170 ^ 163] = I("巾偮崀僢", "cBBGD");
      I[42 ^ 32] = I("孺", "vNHla");
      I[207 ^ 196] = I("榨", "fCzCh");
      I[81 ^ 93] = I("乏椤敿媏叒", "qCPIE");
      I[121 ^ 116] = I("写", "LLhXf");
      I[135 ^ 137] = I("喫揯奦", "ibWgz");
      I[166 ^ 169] = I("\u0013\u001e\" (\u0006\u0015", "cqUEZ");
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[82 ^ 86];
      var10001 = I[102 ^ 99];
      var10002 = I[169 ^ 175];
      var10001 = I[185 ^ 190];
      I[62 ^ 54].length();
      I[13 ^ 4].length();
      I[83 ^ 89].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[157 ^ 150].length();
      I[94 ^ 82].length();
      I[89 ^ 84].length();
      I[91 ^ 85].length();
      var10003["".length()] = POWERED;
      return new BlockStateContainer(this, var10003);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   protected IBlockState setRedstoneStrength(IBlockState var1, int var2) {
      PropertyBool var10001 = POWERED;
      int var10002;
      if (var2 > 0) {
         var10002 = " ".length();
         "".length();
         if (-1 == 0) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var1.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   protected void playClickOnSound(World var1, BlockPos var2) {
      if (this.blockMaterial == Material.WOOD) {
         var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_WOOD_PRESSPLATE_CLICK_ON, SoundCategory.BLOCKS, 0.3F, 0.8F);
         "".length();
         if (-1 >= 2) {
            throw null;
         }
      } else {
         var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_STONE_PRESSPLATE_CLICK_ON, SoundCategory.BLOCKS, 0.3F, 0.6F);
      }

   }

   protected int computeRedstoneStrength(World var1, BlockPos var2) {
      AxisAlignedBB var3 = PRESSURE_AABB.offset(var2);
      List var4;
      switch(null.$SwitchMap$net$minecraft$block$BlockPressurePlate$Sensitivity[this.sensitivity.ordinal()]) {
      case 1:
         var4 = var1.getEntitiesWithinAABBExcludingEntity((Entity)null, var3);
         "".length();
         if (2 != 2) {
            throw null;
         }
         break;
      case 2:
         var4 = var1.getEntitiesWithinAABB(EntityLivingBase.class, var3);
         "".length();
         if (-1 == 3) {
            throw null;
         }
         break;
      default:
         return "".length();
      }

      if (!var4.isEmpty()) {
         Iterator var5 = var4.iterator();

         while(var5.hasNext()) {
            Entity var6 = (Entity)var5.next();
            if (!var6.doesEntityNotTriggerPressurePlate()) {
               return 83 ^ 92;
            }

            "".length();
            if (0 >= 2) {
               throw null;
            }
         }
      }

      return "".length();
   }

   static {
      I();
      POWERED = PropertyBool.create(I[99 ^ 108]);
   }

   protected int getRedstoneStrength(IBlockState var1) {
      int var10000;
      if ((Boolean)var1.getValue(POWERED)) {
         var10000 = 165 ^ 170;
         "".length();
         if (1 < -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState();
      PropertyBool var10001 = POWERED;
      int var10002;
      if (var1 == " ".length()) {
         var10002 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   protected void playClickOffSound(World var1, BlockPos var2) {
      if (this.blockMaterial == Material.WOOD) {
         var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_WOOD_PRESSPLATE_CLICK_OFF, SoundCategory.BLOCKS, 0.3F, 0.7F);
         "".length();
         if (4 == -1) {
            throw null;
         }
      } else {
         var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_STONE_PRESSPLATE_CLICK_OFF, SoundCategory.BLOCKS, 0.3F, 0.5F);
      }

   }

   protected BlockPressurePlate(Material var1, BlockPressurePlate.Sensitivity var2) {
      super(var1);
      this.setDefaultState(this.blockState.getBaseState().withProperty(POWERED, Boolean.valueOf((boolean)"".length())));
      this.sensitivity = var2;
   }

   public static enum Sensitivity {
      // $FF: synthetic field
      EVERYTHING,
      // $FF: synthetic field
      MOBS;

      // $FF: synthetic field
      private static final String[] I;

      static {
         I();
         EVERYTHING = new BlockPressurePlate.Sensitivity(I["".length()], "".length());
         MOBS = new BlockPressurePlate.Sensitivity(I[" ".length()], " ".length());
         BlockPressurePlate.Sensitivity[] var10000 = new BlockPressurePlate.Sensitivity["  ".length()];
         var10000["".length()] = EVERYTHING;
         var10000[" ".length()] = MOBS;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I("6<2\u0003\u001e'\">\u001f\u0000", "sjwQG");
         I[" ".length()] = I("\u001f7\u0001\u0005", "RxCVE");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 < 2);

         throw null;
      }
   }
}

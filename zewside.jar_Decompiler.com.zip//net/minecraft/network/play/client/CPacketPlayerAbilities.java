package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketPlayerAbilities implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private boolean creativeMode;
   // $FF: synthetic field
   private float walkSpeed;
   // $FF: synthetic field
   private float flySpeed;
   // $FF: synthetic field
   private boolean flying;
   // $FF: synthetic field
   private boolean allowFlying;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private boolean invulnerable;

   public void setCreativeMode(boolean var1) {
      this.creativeMode = var1;
   }

   public boolean isInvulnerable() {
      return this.invulnerable;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 2);

      throw null;
   }

   public void setInvulnerable(boolean var1) {
      this.invulnerable = var1;
   }

   public CPacketPlayerAbilities() {
   }

   static {
      I();
   }

   private static void I() {
      I = new String[55 ^ 63];
      I["".length()] = I("喅晲婒澍壼", "EafXX");
      I[" ".length()] = I("殷怮慿慅冨", "MVFSa");
      I["  ".length()] = I("冸", "LVThv");
      I["   ".length()] = I("曶冉捵", "leSGA");
      I[74 ^ 78] = I("悎夊楾偊嶕", "ZEKQl");
      I[37 ^ 32] = I("晞", "uGVPQ");
      I[18 ^ 20] = I("叿刘", "dgWKC");
      I[164 ^ 163] = I("恅借", "wlZrG");
   }

   public void setFlying(boolean var1) {
      this.flying = var1;
   }

   public CPacketPlayerAbilities(PlayerCapabilities var1) {
      this.setInvulnerable(var1.disableDamage);
      this.setFlying(var1.isFlying);
      this.setAllowFlying(var1.allowFlying);
      this.setCreativeMode(var1.isCreativeMode);
      this.setFlySpeed(var1.getFlySpeed());
      this.setWalkSpeed(var1.getWalkSpeed());
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processPlayerAbilities(this);
   }

   public boolean isFlying() {
      return this.flying;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      byte var2 = var1.readByte();
      int var10001;
      if ((var2 & " ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (2 < 0) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setInvulnerable((boolean)var10001);
      if ((var2 & "  ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (0 < 0) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setFlying((boolean)var10001);
      if ((var2 & (33 ^ 37)) > 0) {
         var10001 = " ".length();
         "".length();
         if (3 == 0) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setAllowFlying((boolean)var10001);
      if ((var2 & (123 ^ 115)) > 0) {
         var10001 = " ".length();
         "".length();
         if (4 == -1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setCreativeMode((boolean)var10001);
      this.setFlySpeed(var1.readFloat());
      this.setWalkSpeed(var1.readFloat());
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      int var2 = "".length();
      if (this.isInvulnerable()) {
         var2 = (byte)(var2 | " ".length());
      }

      if (this.isFlying()) {
         var2 = (byte)(var2 | "  ".length());
      }

      if (this.isAllowFlying()) {
         var2 = (byte)(var2 | 4 ^ 0);
      }

      if (this.isCreativeMode()) {
         var2 = (byte)(var2 | 37 ^ 45);
      }

      var1.writeByte(var2);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeFloat(this.flySpeed);
      I["  ".length()].length();
      I["   ".length()].length();
      I[22 ^ 18].length();
      var1.writeFloat(this.walkSpeed);
      I[82 ^ 87].length();
      I[191 ^ 185].length();
      I[118 ^ 113].length();
   }

   public boolean isCreativeMode() {
      return this.creativeMode;
   }

   public boolean isAllowFlying() {
      return this.allowFlying;
   }

   public void setFlySpeed(float var1) {
      this.flySpeed = var1;
   }

   public void setWalkSpeed(float var1) {
      this.walkSpeed = var1;
   }

   public void setAllowFlying(boolean var1) {
      this.allowFlying = var1;
   }
}

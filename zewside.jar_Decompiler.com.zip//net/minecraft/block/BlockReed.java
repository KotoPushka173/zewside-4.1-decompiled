package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockReed extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB REED_AABB;
   // $FF: synthetic field
   public static final PropertyInteger AGE;

   protected BlockStateContainer createBlockState() {
      String var10000 = I[160 ^ 178];
      String var10001 = I[84 ^ 71];
      String var10002 = I[151 ^ 131];
      var10001 = I[150 ^ 131];
      var10000 = I[46 ^ 56];
      var10001 = I[36 ^ 51];
      var10002 = I[13 ^ 21];
      var10001 = I[135 ^ 158];
      I[28 ^ 6].length();
      I[64 ^ 91].length();
      I[221 ^ 193].length();
      I[186 ^ 167].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[170 ^ 180].length();
      I[217 ^ 198].length();
      I[73 ^ 105].length();
      I[157 ^ 188].length();
      var10003["".length()] = AGE;
      return new BlockStateContainer(this, var10003);
   }

   static {
      I();
      AGE = PropertyInteger.create(I[17 ^ 51], "".length(), 55 ^ 56);
      REED_AABB = new AxisAlignedBB(0.125D, 0.0D, 0.125D, 0.875D, 1.0D, 0.875D);
   }

   public boolean canBlockStay(World var1, BlockPos var2) {
      return this.canPlaceBlockAt(var1, var2);
   }

   protected BlockReed() {
      super(Material.PLANTS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(AGE, "".length()));
      this.setTickRandomly((boolean)" ".length());
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(AGE);
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[164 ^ 175];
      String var10001 = I[48 ^ 60];
      String var10002 = I[112 ^ 125];
      var10001 = I[110 ^ 96];
      I[87 ^ 88].length();
      I[53 ^ 37].length();
      I[122 ^ 107].length();
      return new ItemStack(Items.REEDS);
   }

   private static void I() {
      I = new String[138 ^ 169];
      I["".length()] = I("枠沄徳孪嵭", "pMVOi");
      I[" ".length()] = I("惪", "xGIlU");
      I["  ".length()] = I("埥普", "oWzXn");
      I["   ".length()] = I("廦孮噳欸极", "MSolo");
      I[90 ^ 94] = I("嘼尓怾朥", "JMhYB");
      I[153 ^ 156] = I("涟煱寁", "tXVaE");
      I[169 ^ 175] = I("昐撠嗈尼撧", "FYjjN");
      I[31 ^ 24] = I("捶垾斚倘", "tDmWJ");
      I[59 ^ 51] = I("匱洴剮圾歪", "ZuVeD");
      I[13 ^ 4] = I("幒伷", "vmzrU");
      I[190 ^ 180] = I("染僆巡桗", "xCztF");
      I[98 ^ 105] = I("倰悔", "pPAyY");
      I[15 ^ 3] = I("忙濓", "VimoJ");
      I[74 ^ 71] = I("八噱", "AGKjZ");
      I[114 ^ 124] = I("沶喴", "vEGAt");
      I[90 ^ 85] = I("漩恰", "VXPyp");
      I[55 ^ 39] = I("烗惜", "THYTq");
      I[153 ^ 136] = I("囍", "jKCxJ");
      I[132 ^ 150] = I("埃塍", "rPLVm");
      I[109 ^ 126] = I("忌亢", "NUncM");
      I[49 ^ 37] = I("描枒", "TTSAO");
      I[143 ^ 154] = I("嘒泝", "MXqom");
      I[129 ^ 151] = I("幢桏", "jhbzP");
      I[157 ^ 138] = I("檹嗆", "bLOKz");
      I[128 ^ 152] = I("氆濕", "oOXbk");
      I[135 ^ 158] = I("伤岹", "hJSRU");
      I[163 ^ 185] = I("汀", "wQiwe");
      I[217 ^ 194] = I("怞炌劜毽樭", "uUTHB");
      I[217 ^ 197] = I("灛", "ZxtUa");
      I[63 ^ 34] = I("泈", "LdGKF");
      I[4 ^ 26] = I("嬲嗭", "rDfIs");
      I[40 ^ 55] = I("僈咚塪室槸", "zvPvk");
      I[56 ^ 24] = I("櫺", "jfZgt");
      I[11 ^ 42] = I("暵彦", "nCOVC");
      I[131 ^ 161] = I("\u0018#(", "yDMDY");
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return REED_AABB;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.REEDS;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if ((var1.getBlockState(var2.down()).getBlock() == Blocks.REEDS || this.checkForDrop(var1, var2, var3)) && var1.isAirBlock(var2.up())) {
         int var5 = " ".length();

         while(var1.getBlockState(var2.down(var5)).getBlock() == this) {
            ++var5;
            "".length();
            if (1 == 4) {
               throw null;
            }
         }

         if (var5 < "   ".length()) {
            int var6 = (Integer)var3.getValue(AGE);
            if (var6 == (71 ^ 72)) {
               var1.setBlockState(var2.up(), this.getDefaultState());
               I["".length()].length();
               I[" ".length()].length();
               var1.setBlockState(var2, var3.withProperty(AGE, "".length()), 38 ^ 34);
               I["  ".length()].length();
               I["   ".length()].length();
               "".length();
               if (-1 == 3) {
                  throw null;
               }
            } else {
               var1.setBlockState(var2, var3.withProperty(AGE, var6 + " ".length()), 182 ^ 178);
               I[136 ^ 140].length();
               I[186 ^ 191].length();
            }
         }
      }

   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      this.checkForDrop(var2, var3, var1);
      I[56 ^ 62].length();
      I[29 ^ 26].length();
      I[186 ^ 178].length();
   }

   protected final boolean checkForDrop(World var1, BlockPos var2, IBlockState var3) {
      if (this.canBlockStay(var1, var2)) {
         return (boolean)" ".length();
      } else {
         this.dropBlockAsItem(var1, var2, var3, "".length());
         var1.setBlockToAir(var2);
         I[141 ^ 132].length();
         I[129 ^ 139].length();
         return (boolean)"".length();
      }
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      Block var3 = var1.getBlockState(var2.down()).getBlock();
      if (var3 == this) {
         return (boolean)" ".length();
      } else if (var3 != Blocks.GRASS && var3 != Blocks.DIRT && var3 != Blocks.SAND) {
         return (boolean)"".length();
      } else {
         BlockPos var4 = var2.down();
         Iterator var5 = EnumFacing.Plane.HORIZONTAL.iterator();

         do {
            if (!var5.hasNext()) {
               return (boolean)"".length();
            }

            EnumFacing var6 = (EnumFacing)var5.next();
            IBlockState var7 = var1.getBlockState(var4.offset(var6));
            if (var7.getMaterial() == Material.WATER || var7.getBlock() == Blocks.FROSTED_ICE) {
               return (boolean)" ".length();
            }

            "".length();
         } while(2 != 1);

         throw null;
      }
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(AGE, var1);
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }
}

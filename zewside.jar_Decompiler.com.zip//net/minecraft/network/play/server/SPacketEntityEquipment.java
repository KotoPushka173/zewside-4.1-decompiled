package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketEntityEquipment implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private EntityEquipmentSlot equipmentSlot;
   // $FF: synthetic field
   private int entityID;
   // $FF: synthetic field
   private ItemStack itemStack;
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public SPacketEntityEquipment(int var1, EntityEquipmentSlot var2, ItemStack var3) {
      this.itemStack = ItemStack.field_190927_a;
      this.entityID = var1;
      this.equipmentSlot = var2;
      this.itemStack = var3.copy();
   }

   private static void I() {
      I = new String[129 ^ 137];
      I["".length()] = I("庇嫾滞", "IXZHV");
      I[" ".length()] = I("灒津檳", "WOzNz");
      I["  ".length()] = I("屬垒婄樭废", "jPUZz");
      I["   ".length()] = I("单湿勽", "cSqhZ");
      I[32 ^ 36] = I("媍唴椺", "tAkmO");
      I[199 ^ 194] = I("堔搨漍漸", "aGyxr");
      I[86 ^ 80] = I("刂彴", "fPIip");
      I[62 ^ 57] = I("巛庢瀑", "zbhGk");
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityID);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeEnumValue(this.equipmentSlot);
      I[73 ^ 77].length();
      var1.writeItemStackToBuffer(this.itemStack);
      I[46 ^ 43].length();
      I[79 ^ 73].length();
      I[126 ^ 121].length();
   }

   public EntityEquipmentSlot getEquipmentSlot() {
      return this.equipmentSlot;
   }

   public ItemStack getItemStack() {
      return this.itemStack;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityID = var1.readVarIntFromBuffer();
      this.equipmentSlot = (EntityEquipmentSlot)var1.readEnumValue(EntityEquipmentSlot.class);
      this.itemStack = var1.readItemStackFromBuffer();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityEquipment(this);
   }

   public int getEntityID() {
      return this.entityID;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > -1);

      throw null;
   }

   public SPacketEntityEquipment() {
      this.itemStack = ItemStack.field_190927_a;
   }
}

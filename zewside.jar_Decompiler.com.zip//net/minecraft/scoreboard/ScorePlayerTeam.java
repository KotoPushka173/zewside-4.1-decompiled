package net.minecraft.scoreboard;

import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.util.text.TextFormatting;

public class ScorePlayerTeam extends Team {
   // $FF: synthetic field
   private Team.EnumVisible deathMessageVisibility;
   // $FF: synthetic field
   private final Set<String> membershipSet = Sets.newHashSet();
   // $FF: synthetic field
   private boolean allowFriendlyFire;
   // $FF: synthetic field
   private String colorSuffix;
   // $FF: synthetic field
   private TextFormatting chatFormat;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private Team.EnumVisible nameTagVisibility;
   // $FF: synthetic field
   private final String registeredName;
   // $FF: synthetic field
   private final Scoreboard theScoreboard;
   // $FF: synthetic field
   private Team.CollisionRule collisionRule;
   // $FF: synthetic field
   private String namePrefixSPT;
   // $FF: synthetic field
   private boolean canSeeFriendlyInvisibles;
   // $FF: synthetic field
   private String teamNameSPT;

   public void setTeamName(String var1) {
      String var10000 = I["  ".length()];
      String var10001 = I["   ".length()];
      String var10002 = I[64 ^ 68];
      var10001 = I[150 ^ 147];
      if (var1 == null) {
         I[7 ^ 1].length();
         I[77 ^ 74].length();
         IllegalArgumentException var2 = new IllegalArgumentException(I[39 ^ 47]);
         I[47 ^ 38].length();
         I[110 ^ 100].length();
         throw var2;
      } else {
         this.teamNameSPT = var1;
         this.theScoreboard.broadcastTeamInfoUpdate(this);
      }
   }

   public int getFriendlyFlags() {
      int var1 = "".length();
      if (this.getAllowFriendlyFire()) {
         var1 |= " ".length();
      }

      if (this.getSeeFriendlyInvisiblesEnabled()) {
         var1 |= "  ".length();
      }

      return var1;
   }

   public Team.EnumVisible getDeathMessageVisibility() {
      return this.deathMessageVisibility;
   }

   public boolean getSeeFriendlyInvisiblesEnabled() {
      return this.canSeeFriendlyInvisibles;
   }

   public boolean getAllowFriendlyFire() {
      return this.allowFriendlyFire;
   }

   public void setNameSuffix(String var1) {
      this.colorSuffix = var1;
      this.theScoreboard.broadcastTeamInfoUpdate(this);
   }

   public void setSeeFriendlyInvisiblesEnabled(boolean var1) {
      this.canSeeFriendlyInvisibles = var1;
      this.theScoreboard.broadcastTeamInfoUpdate(this);
   }

   public static String formatPlayerName(@Nullable Team var0, String var1) {
      String var10000;
      if (var0 == null) {
         var10000 = var1;
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var10000 = var0.formatString(var1);
      }

      return var10000;
   }

   public String formatString(String var1) {
      String var10000 = I[130 ^ 154];
      String var10001 = I[88 ^ 65];
      String var10002 = I[160 ^ 186];
      var10001 = I[94 ^ 69];
      I[63 ^ 35].length();
      I[168 ^ 181].length();
      return this.getColorPrefix() + var1 + this.getColorSuffix();
   }

   public String getColorPrefix() {
      return this.namePrefixSPT;
   }

   public void setAllowFriendlyFire(boolean var1) {
      this.allowFriendlyFire = var1;
      this.theScoreboard.broadcastTeamInfoUpdate(this);
   }

   public String getColorSuffix() {
      return this.colorSuffix;
   }

   public void setNamePrefix(String var1) {
      String var10000 = I[87 ^ 92];
      String var10001 = I[169 ^ 165];
      String var10002 = I[12 ^ 1];
      var10001 = I[11 ^ 5];
      if (var1 == null) {
         I[16 ^ 31].length();
         I[163 ^ 179].length();
         I[173 ^ 188].length();
         I[51 ^ 33].length();
         I[26 ^ 9].length();
         IllegalArgumentException var2 = new IllegalArgumentException(I[72 ^ 92]);
         I[20 ^ 1].length();
         I[159 ^ 137].length();
         I[95 ^ 72].length();
         throw var2;
      } else {
         this.namePrefixSPT = var1;
         this.theScoreboard.broadcastTeamInfoUpdate(this);
      }
   }

   public TextFormatting getChatFormat() {
      return this.chatFormat;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 >= -1);

      throw null;
   }

   static {
      I();
   }

   private static void I() {
      I = new String[164 ^ 186];
      I["".length()] = I("", "roxRd");
      I[" ".length()] = I("", "yJKkv");
      I["  ".length()] = I("徆媒", "pGGlF");
      I["   ".length()] = I("挺漲", "fGHIX");
      I[18 ^ 22] = I("溢晌", "YbNUK");
      I[189 ^ 184] = I("烻棧", "oeFkE");
      I[160 ^ 166] = I("烛噖", "HKJWX");
      I[74 ^ 77] = I("匴巴", "JzrCR");
      I[33 ^ 41] = I("\f\u0000\u0018,L!\u0000\u001b'\u00036A\u0017,L,\u0014\u0019%", "BauIl");
      I[134 ^ 143] = I("撟", "WJYAw");
      I[171 ^ 161] = I("募咏塏", "ZuJXX");
      I[102 ^ 109] = I("姝揊", "TCJGZ");
      I[28 ^ 16] = I("斏奄", "jrYya");
      I[37 ^ 40] = I("瀷妚", "QXspf");
      I[189 ^ 179] = I("栛塘", "uRirz");
      I[15 ^ 0] = I("喺愍汏", "SoIBM");
      I[126 ^ 110] = I("撓喑", "ywHuZ");
      I[117 ^ 100] = I("嗓瀩懚", "oLypu");
      I[70 ^ 84] = I("屭涳浀客喟", "Fetdo");
      I[96 ^ 115] = I("婰手嚄", "DjDXu");
      I[208 ^ 196] = I("\u00189\u0004\u0015\u00070k\u0002\u0012\u0000&$\u0015S\f-k\u000f\u0006\u0002$", "HKasn");
      I[108 ^ 121] = I("寺", "xQwFa");
      I[133 ^ 147] = I("敟灝", "pCfoZ");
      I[130 ^ 149] = I("挧剠", "zKHYY");
      I[128 ^ 152] = I("偽折", "ePtph");
      I[163 ^ 186] = I("劐樊", "AqgIf");
      I[181 ^ 175] = I("斃咖", "NvdFZ");
      I[5 ^ 30] = I("炑湀", "fNuNm");
      I[22 ^ 10] = I("嗄愩卣瀸寏", "qpOAQ");
      I[22 ^ 11] = I("妾", "mMlqy");
   }

   public String getRegisteredName() {
      return this.registeredName;
   }

   public void setDeathMessageVisibility(Team.EnumVisible var1) {
      this.deathMessageVisibility = var1;
      this.theScoreboard.broadcastTeamInfoUpdate(this);
   }

   public void setCollisionRule(Team.CollisionRule var1) {
      this.collisionRule = var1;
      this.theScoreboard.broadcastTeamInfoUpdate(this);
   }

   public void setChatFormat(TextFormatting var1) {
      this.chatFormat = var1;
   }

   public void setNameTagVisibility(Team.EnumVisible var1) {
      this.nameTagVisibility = var1;
      this.theScoreboard.broadcastTeamInfoUpdate(this);
   }

   public Team.EnumVisible getNameTagVisibility() {
      return this.nameTagVisibility;
   }

   public void setFriendlyFlags(int var1) {
      int var10001;
      if ((var1 & " ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (2 >= 3) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setAllowFriendlyFire((boolean)var10001);
      if ((var1 & "  ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.setSeeFriendlyInvisiblesEnabled((boolean)var10001);
   }

   public Collection<String> getMembershipCollection() {
      return this.membershipSet;
   }

   public ScorePlayerTeam(Scoreboard var1, String var2) {
      this.namePrefixSPT = I["".length()];
      this.colorSuffix = I[" ".length()];
      this.allowFriendlyFire = (boolean)" ".length();
      this.canSeeFriendlyInvisibles = (boolean)" ".length();
      this.nameTagVisibility = Team.EnumVisible.ALWAYS;
      this.deathMessageVisibility = Team.EnumVisible.ALWAYS;
      this.chatFormat = TextFormatting.RESET;
      this.collisionRule = Team.CollisionRule.ALWAYS;
      this.theScoreboard = var1;
      this.registeredName = var2;
      this.teamNameSPT = var2;
   }

   public String getTeamName() {
      return this.teamNameSPT;
   }

   public Team.CollisionRule getCollisionRule() {
      return this.collisionRule;
   }
}

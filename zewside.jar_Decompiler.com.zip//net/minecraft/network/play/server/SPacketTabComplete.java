package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketTabComplete implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private String[] matches;

   public String[] getMatches() {
      return this.matches;
   }

   public SPacketTabComplete() {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != 2);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.matches = new String[var1.readVarIntFromBuffer()];
      int var2 = "".length();

      do {
         if (var2 >= this.matches.length) {
            return;
         }

         this.matches[var2] = var1.readStringFromBuffer(8494 + 9425 - 10041 + 24889);
         ++var2;
         "".length();
      } while(1 > -1);

      throw null;
   }

   private static void I() {
      I = new String[167 ^ 160];
      I["".length()] = I("啧侊堿", "esknU");
      I[" ".length()] = I("侐懀", "nHQyX");
      I["  ".length()] = I("忘弈汵", "GXKWG");
      I["   ".length()] = I("嗏拪", "fGpTm");
      I[128 ^ 132] = I("娌", "AxGIF");
      I[123 ^ 126] = I("栓娫炏", "uYZhC");
      I[77 ^ 75] = I("侹峘漄旜", "bXDJO");
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.matches.length);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      String[] var2 = this.matches;
      int var3 = var2.length;
      int var4 = "".length();

      do {
         if (var4 >= var3) {
            return;
         }

         String var5 = var2[var4];
         var1.writeString(var5);
         I[190 ^ 186].length();
         I[19 ^ 22].length();
         I[14 ^ 8].length();
         ++var4;
         "".length();
      } while(3 >= 3);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleTabComplete(this);
   }

   public SPacketTabComplete(String[] var1) {
      this.matches = var1;
   }
}

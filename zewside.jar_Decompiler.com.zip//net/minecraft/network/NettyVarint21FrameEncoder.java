package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.handler.codec.MessageToByteEncoder;

@Sharable
public class NettyVarint21FrameEncoder extends MessageToByteEncoder<ByteBuf> {
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   private static void I() {
      I = new String[229 ^ 199];
      I["".length()] = I("暪湣", "svwbK");
      I[" ".length()] = I("捖机", "GKBZa");
      I["  ".length()] = I("淌哠", "sQJDX");
      I["   ".length()] = I("囀涸", "hoKaq");
      I[183 ^ 179] = I("毹俵", "kergF");
      I[20 ^ 17] = I("呥妞", "tIXDm");
      I[62 ^ 56] = I("呏冭", "sRnBo");
      I[86 ^ 81] = I("奯捏", "fyxqZ");
      I[48 ^ 56] = I("植夗", "kLJBY");
      I[79 ^ 70] = I("主抁", "wFgSY");
      I[158 ^ 148] = I("彻仾", "qReCU");
      I[99 ^ 104] = I("亶宓", "nHysC");
      I[75 ^ 71] = I("埥忆旡", "PzSdt");
      I[40 ^ 37] = I("救尋", "rQPWa");
      I[76 ^ 66] = I("僠攭憸", "TPKDC");
      I[121 ^ 118] = I("濣", "rvFHS");
      I[41 ^ 57] = I("欨", "cOjKs");
      I[9 ^ 24] = I("漜怍", "ZueKO");
      I[106 ^ 120] = I("\u0012\u0018.7\u001e\u0002V;:R\u0001\u001f;u", "gvOUr");
      I[3 ^ 16] = I("U;?\u0007(U", "uRQsG");
      I[124 ^ 104] = I("嗐偽咋煃沰", "RVFIc");
      I[186 ^ 175] = I("欖", "bJNaA");
      I[191 ^ 169] = I("捊勞", "YLQOv");
      I[2 ^ 21] = I("炆宆恜濇彝", "gEggQ");
      I[55 ^ 47] = I("儑樠汊杈", "YtjOu");
      I[122 ^ 99] = I("嬹氐烕", "bjDBj");
      I[3 ^ 25] = I("守", "scDVf");
      I[222 ^ 197] = I("此扚旹", "WasJr");
      I[178 ^ 174] = I("昅棈抝", "WqemI");
      I[93 ^ 64] = I("敝氖姶淩梡", "nsoOX");
      I[222 ^ 192] = I("亖擜囌烢", "szbpU");
      I[177 ^ 174] = I("怵", "kqlgS");
      I[112 ^ 80] = I("殦", "TqEmo");
      I[169 ^ 136] = I("扬减咢劯沏", "vyCQh");
   }

   protected void encode(ChannelHandlerContext var1, ByteBuf var2, ByteBuf var3) throws Exception {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[96 ^ 100];
      var10001 = I[144 ^ 149];
      var10002 = I[15 ^ 9];
      var10001 = I[56 ^ 63];
      var10000 = I[8 ^ 0];
      var10001 = I[103 ^ 110];
      var10002 = I[9 ^ 3];
      var10001 = I[56 ^ 51];
      int var4 = var2.readableBytes();
      int var5 = PacketBuffer.getVarIntSize(var4);
      if (var5 > "   ".length()) {
         I[187 ^ 183].length();
         I[133 ^ 136].length();
         I[51 ^ 61].length();
         I[32 ^ 47].length();
         I[152 ^ 136].length();
         I[24 ^ 9].length();
         IllegalArgumentException var7 = new IllegalArgumentException(I[177 ^ 163] + var4 + I[51 ^ 32] + "   ".length());
         I[63 ^ 43].length();
         I[150 ^ 131].length();
         I[66 ^ 84].length();
         throw var7;
      } else {
         I[3 ^ 20].length();
         I[40 ^ 48].length();
         PacketBuffer var6 = new PacketBuffer(var3);
         var6.ensureWritable(var5 + var4);
         I[172 ^ 181].length();
         I[220 ^ 198].length();
         I[23 ^ 12].length();
         var6.writeVarIntToBuffer(var4);
         I[70 ^ 90].length();
         I[97 ^ 124].length();
         I[185 ^ 167].length();
         I[61 ^ 34].length();
         var6.writeBytes(var2, var2.readerIndex(), var4);
         I[43 ^ 11].length();
         I[64 ^ 97].length();
      }
   }

   static {
      I();
   }
}

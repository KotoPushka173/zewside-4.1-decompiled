package net.minecraft.scoreboard;

import net.minecraft.util.text.TextFormatting;

public class ScoreCriteriaColored implements IScoreCriteria {
   // $FF: synthetic field
   private final String goalName;

   public String getName() {
      return this.goalName;
   }

   public IScoreCriteria.EnumRenderType getRenderType() {
      return IScoreCriteria.EnumRenderType.INTEGER;
   }

   public boolean isReadOnly() {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 0);

      throw null;
   }

   public ScoreCriteriaColored(String var1, TextFormatting var2) {
      this.goalName = var1 + var2.getFriendlyName();
      IScoreCriteria.INSTANCES.put(this.goalName, this);
   }
}

package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.DimensionType;

public class ChangeDimensionTrigger implements ICriterionTrigger<ChangeDimensionTrigger.Instance> {
   // $FF: synthetic field
   private final Map<PlayerAdvancements, ChangeDimensionTrigger.Listeners> field_193145_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final ResourceLocation field_193144_a;

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193145_b.remove(var1);
      I[90 ^ 87].length();
      I[74 ^ 68].length();
      I[64 ^ 79].length();
   }

   public ResourceLocation func_192163_a() {
      return field_193144_a;
   }

   private static void I() {
      I = new String[94 ^ 67];
      I["".length()] = I("什煱", "sDXPf");
      I[" ".length()] = I("夢恆", "kjCWc");
      I["  ".length()] = I("啺垔", "pnpmM");
      I["   ".length()] = I("塸埾", "zPifQ");
      I[107 ^ 111] = I("斢撉噧嚤", "wSxrF");
      I[43 ^ 46] = I("淍没垠", "lhWis");
      I[93 ^ 91] = I("寅旿", "YUxyw");
      I[0 ^ 7] = I("吵吐峐岬", "uRFhc");
      I[157 ^ 149] = I("坑渨攟", "RQodg");
      I[151 ^ 158] = I("毺浯晢", "HvpHo");
      I[90 ^ 80] = I("厹", "zlWFF");
      I[107 ^ 96] = I("幋愈寸", "UIeYk");
      I[46 ^ 34] = I("凮嚠嘳凼柹", "dVNDm");
      I[118 ^ 123] = I("埐慴歴", "zpCLy");
      I[60 ^ 50] = I("桨", "sNOmH");
      I[33 ^ 46] = I("滐匜吱", "RtWvG");
      I[79 ^ 95] = I("小攩", "CWBAy");
      I[134 ^ 151] = I("洮楊", "pbaLo");
      I[74 ^ 88] = I("漽杋", "dyQtF");
      I[17 ^ 2] = I("敨俗", "UHGFG");
      I[17 ^ 5] = I("*\u0011\u001d\u001d", "Lcrpd");
      I[179 ^ 166] = I("#\u0000\u001e9", "ErqTe");
      I[75 ^ 93] = I("=>", "IQXDt");
      I[17 ^ 6] = I("\u0018\n", "leJLU");
      I[94 ^ 70] = I("埑", "KiZPf");
      I[152 ^ 129] = I("朄冇", "ytDyn");
      I[30 ^ 4] = I("櫠", "CWQOa");
      I[87 ^ 76] = I("晠亼煾擿妠", "vsxUU");
      I[53 ^ 41] = I("\u0000<\u0013\u0002#\u00060-\b-\u000e1\u001c\u001f-\f:", "cTrlD");
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<ChangeDimensionTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      ChangeDimensionTrigger.Listeners var3 = (ChangeDimensionTrigger.Listeners)this.field_193145_b.get(var1);
      if (var3 == null) {
         I[83 ^ 87].length();
         I[78 ^ 75].length();
         I[119 ^ 113].length();
         var3 = new ChangeDimensionTrigger.Listeners(var1);
         this.field_193145_b.put(var1, var3);
         I[166 ^ 161].length();
         I[81 ^ 89].length();
         I[118 ^ 127].length();
         I[149 ^ 159].length();
      }

      var3.func_193233_a(var2);
   }

   public ChangeDimensionTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[71 ^ 87];
      String var10001 = I[31 ^ 14];
      String var10002 = I[106 ^ 120];
      var10001 = I[136 ^ 155];
      DimensionType var5;
      if (var1.has(I[51 ^ 39])) {
         var5 = DimensionType.func_193417_a(JsonUtils.getString(var1, I[15 ^ 26]));
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var5 = null;
      }

      DimensionType var3 = var5;
      if (var1.has(I[31 ^ 9])) {
         var5 = DimensionType.func_193417_a(JsonUtils.getString(var1, I[151 ^ 128]));
         "".length();
         if (0 >= 4) {
            throw null;
         }
      } else {
         var5 = null;
      }

      DimensionType var4 = var5;
      I[53 ^ 45].length();
      I[98 ^ 123].length();
      I[79 ^ 85].length();
      I[22 ^ 13].length();
      return new ChangeDimensionTrigger.Instance(var3, var4);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 2);

      throw null;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<ChangeDimensionTrigger.Instance> var2) {
      ChangeDimensionTrigger.Listeners var3 = (ChangeDimensionTrigger.Listeners)this.field_193145_b.get(var1);
      if (var3 != null) {
         var3.func_193231_b(var2);
         if (var3.func_193232_a()) {
            this.field_193145_b.remove(var1);
            I[10 ^ 1].length();
            I[111 ^ 99].length();
         }
      }

   }

   static {
      I();
      field_193144_a = new ResourceLocation(I[101 ^ 121]);
   }

   public void func_193143_a(EntityPlayerMP var1, DimensionType var2, DimensionType var3) {
      ChangeDimensionTrigger.Listeners var4 = (ChangeDimensionTrigger.Listeners)this.field_193145_b.get(var1.func_192039_O());
      if (var4 != null) {
         var4.func_193234_a(var2, var3);
      }

   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      @Nullable
      private final DimensionType field_193192_b;
      // $FF: synthetic field
      @Nullable
      private final DimensionType field_193191_a;

      public boolean func_193190_a(DimensionType var1, DimensionType var2) {
         if (this.field_193191_a != null && this.field_193191_a != var1) {
            return (boolean)"".length();
         } else {
            int var10000;
            if (this.field_193192_b != null && this.field_193192_b != var2) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (-1 >= 0) {
                  throw null;
               }
            }

            return (boolean)var10000;
         }
      }

      public Instance(@Nullable DimensionType var1, @Nullable DimensionType var2) {
         super(ChangeDimensionTrigger.field_193144_a);
         this.field_193191_a = var1;
         this.field_193192_b = var2;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 > 0);

         throw null;
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final PlayerAdvancements field_193235_a;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<ChangeDimensionTrigger.Instance>> field_193236_b = Sets.newHashSet();

      public boolean func_193232_a() {
         return this.field_193236_b.isEmpty();
      }

      private static void I() {
         I = new String[207 ^ 199];
         I["".length()] = I("埈涡", "ybjmS");
         I[" ".length()] = I("嶢", "gigYn");
         I["  ".length()] = I("匈漹丣挅", "HnprX");
         I["   ".length()] = I("凁濘恭氅媙", "tZLQC");
         I[100 ^ 96] = I("昏泖", "zpWWn");
         I[134 ^ 131] = I("剆", "Tvtdy");
         I[57 ^ 63] = I("殺", "UprOW");
         I[42 ^ 45] = I("帤埍搁晼乞", "ebvva");
      }

      public void func_193231_b(ICriterionTrigger.Listener<ChangeDimensionTrigger.Instance> var1) {
         this.field_193236_b.remove(var1);
         I["  ".length()].length();
         I["   ".length()].length();
         I[45 ^ 41].length();
      }

      public void func_193233_a(ICriterionTrigger.Listener<ChangeDimensionTrigger.Instance> var1) {
         this.field_193236_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= 2);

         throw null;
      }

      public void func_193234_a(DimensionType var1, DimensionType var2) {
         ArrayList var3 = null;
         Iterator var4 = this.field_193236_b.iterator();

         ICriterionTrigger.Listener var5;
         while(var4.hasNext()) {
            var5 = (ICriterionTrigger.Listener)var4.next();
            if (((ChangeDimensionTrigger.Instance)var5.func_192158_a()).func_193190_a(var1, var2)) {
               if (var3 == null) {
                  var3 = Lists.newArrayList();
               }

               var3.add(var5);
               I[110 ^ 107].length();
               I[100 ^ 98].length();
               I[114 ^ 117].length();
            }

            "".length();
            if (4 == 2) {
               throw null;
            }
         }

         if (var3 != null) {
            var4 = var3.iterator();

            while(var4.hasNext()) {
               var5 = (ICriterionTrigger.Listener)var4.next();
               var5.func_192159_a(this.field_193235_a);
               "".length();
               if (0 < -1) {
                  throw null;
               }
            }
         }

      }

      static {
         I();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193235_a = var1;
      }
   }
}

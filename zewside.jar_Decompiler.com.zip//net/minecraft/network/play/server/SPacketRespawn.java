package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.GameType;
import net.minecraft.world.WorldType;

public class SPacketRespawn implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private WorldType worldType;
   // $FF: synthetic field
   private int dimensionID;
   // $FF: synthetic field
   private GameType gameType;
   // $FF: synthetic field
   private EnumDifficulty difficulty;

   public EnumDifficulty getDifficulty() {
      return this.difficulty;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeInt(this.dimensionID);
      I["".length()].length();
      var1.writeByte(this.difficulty.getDifficultyId());
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeByte(this.gameType.getID());
      I["   ".length()].length();
      I[143 ^ 139].length();
      var1.writeString(this.worldType.getWorldTypeName());
      I[50 ^ 55].length();
      I[4 ^ 2].length();
   }

   public WorldType getWorldType() {
      return this.worldType;
   }

   public SPacketRespawn() {
   }

   private static void I() {
      I = new String[79 ^ 72];
      I["".length()] = I("攥啳榰", "dTUlb");
      I[" ".length()] = I("湓栍", "uBNPh");
      I["  ".length()] = I("嚄涮", "VebPG");
      I["   ".length()] = I("军圈", "eWJNL");
      I[85 ^ 81] = I("幾", "GSjPV");
      I[184 ^ 189] = I("峵廭憂", "xuZoM");
      I[114 ^ 116] = I("嶦剞佒歮", "hBrDx");
   }

   static {
      I();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.dimensionID = var1.readInt();
      this.difficulty = EnumDifficulty.getDifficultyEnum(var1.readUnsignedByte());
      this.gameType = GameType.getByID(var1.readUnsignedByte());
      this.worldType = WorldType.parseWorldType(var1.readStringFromBuffer(75 ^ 91));
      if (this.worldType == null) {
         this.worldType = WorldType.DEFAULT;
      }

   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleRespawn(this);
   }

   public GameType getGameType() {
      return this.gameType;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 0);

      throw null;
   }

   public int getDimensionID() {
      return this.dimensionID;
   }

   public SPacketRespawn(int var1, EnumDifficulty var2, WorldType var3, GameType var4) {
      this.dimensionID = var1;
      this.difficulty = var2;
      this.gameType = var4;
      this.worldType = var3;
   }
}

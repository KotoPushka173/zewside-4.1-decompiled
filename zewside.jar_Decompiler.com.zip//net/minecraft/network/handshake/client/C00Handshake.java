package net.minecraft.network.handshake.client;

import java.io.IOException;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.handshake.INetHandlerHandshakeServer;

public class C00Handshake implements Packet<INetHandlerHandshakeServer> {
   // $FF: synthetic field
   private EnumConnectionState requestedState;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private String ip;
   // $FF: synthetic field
   private int port;
   // $FF: synthetic field
   private int protocolVersion;

   public EnumConnectionState getRequestedState() {
      return this.requestedState;
   }

   private static void I() {
      I = new String[49 ^ 56];
      I["".length()] = I("嬍埧泿梉", "EYynp");
      I[" ".length()] = I("浍弅潯徴", "bfXFC");
      I["  ".length()] = I("妭嶍悄廠", "WFDby");
      I["   ".length()] = I("渟", "ixaUw");
      I[142 ^ 138] = I("劮沊噮", "CBner");
      I[71 ^ 66] = I("搏徛", "gIExq");
      I[119 ^ 113] = I("孵仐", "uhMKM");
      I[151 ^ 144] = I("悬渟氁嬽暘", "uwSAM");
      I[76 ^ 68] = I("嚮幾悞梀", "NNUix");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 1);

      throw null;
   }

   public void processPacket(INetHandlerHandshakeServer var1) {
      var1.processHandshake(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.protocolVersion = var1.readVarIntFromBuffer();
      this.ip = var1.readStringFromBuffer(199 + 6 - -27 + 23);
      this.port = var1.readUnsignedShort();
      this.requestedState = EnumConnectionState.getById(var1.readVarIntFromBuffer());
   }

   public C00Handshake(String var1, int var2, EnumConnectionState var3) {
      this.protocolVersion = 264 + 58 - 282 + 300;
      this.ip = var1;
      this.port = var2;
      this.requestedState = var3;
   }

   public C00Handshake() {
   }

   static {
      I();
   }

   public int getProtocolVersion() {
      return this.protocolVersion;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.protocolVersion);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeString(this.ip);
      I["   ".length()].length();
      I[98 ^ 102].length();
      I[154 ^ 159].length();
      var1.writeShort(this.port);
      I[4 ^ 2].length();
      I[112 ^ 119].length();
      var1.writeVarIntToBuffer(this.requestedState.getId());
      I[106 ^ 98].length();
   }
}

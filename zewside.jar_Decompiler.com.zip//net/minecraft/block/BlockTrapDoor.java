package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockTrapDoor extends Block {
   // $FF: synthetic field
   protected static final AxisAlignedBB NORTH_OPEN_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockTrapDoor.DoorHalf> HALF;
   // $FF: synthetic field
   protected static final AxisAlignedBB TOP_AABB;
   // $FF: synthetic field
   public static final PropertyBool OPEN;
   // $FF: synthetic field
   protected static final AxisAlignedBB EAST_OPEN_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB SOUTH_OPEN_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB BOTTOM_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB WEST_OPEN_AABB;
   // $FF: synthetic field
   public static final PropertyDirection FACING;

   protected void playSound(@Nullable EntityPlayer var1, World var2, BlockPos var3, boolean var4) {
      int var10000;
      int var5;
      if (var4) {
         if (this.blockMaterial == Material.IRON) {
            var10000 = 916 + 289 - 300 + 132;
            "".length();
            if (4 == 2) {
               throw null;
            }
         } else {
            var10000 = 221 + 556 - 108 + 338;
         }

         var5 = var10000;
         var2.playEvent(var1, var5, var3, "".length());
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         if (this.blockMaterial == Material.IRON) {
            var10000 = 113 + 177 - 224 + 970;
            "".length();
            if (3 != 3) {
               throw null;
            }
         } else {
            var10000 = 668 + 212 - 156 + 289;
         }

         var5 = var10000;
         var2.playEvent(var1, var5, var3, "".length());
      }

   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[22 ^ 19];
      String var10001 = I[47 ^ 41];
      String var10002 = I[132 ^ 131];
      var10001 = I[153 ^ 145];
      var10000 = I[157 ^ 148];
      var10001 = I[155 ^ 145];
      var10002 = I[147 ^ 152];
      var10001 = I[5 ^ 9];
      var10000 = I[38 ^ 43];
      var10001 = I[150 ^ 152];
      var10002 = I[36 ^ 43];
      var10001 = I[5 ^ 21];
      var10000 = I[29 ^ 12];
      var10001 = I[32 ^ 50];
      var10002 = I[172 ^ 191];
      var10001 = I[208 ^ 196];
      I[57 ^ 44].length();
      I[1 ^ 23].length();
      I[155 ^ 140].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[82 ^ 74].length();
      var10003["".length()] = FACING;
      I[71 ^ 94].length();
      I[137 ^ 147].length();
      I[4 ^ 31].length();
      I[21 ^ 9].length();
      var10003[" ".length()] = OPEN;
      I[138 ^ 151].length();
      I[60 ^ 34].length();
      var10003["  ".length()] = HALF;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, getFacing(var1));
      PropertyBool var10001 = OPEN;
      int var10002;
      if ((var1 & (173 ^ 169)) != 0) {
         var10002 = " ".length();
         "".length();
         if (1 >= 3) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      PropertyEnum var2 = HALF;
      BlockTrapDoor.DoorHalf var3;
      if ((var1 & (85 ^ 93)) == 0) {
         var3 = BlockTrapDoor.DoorHalf.BOTTOM;
         "".length();
         if (1 < 0) {
            throw null;
         }
      } else {
         var3 = BlockTrapDoor.DoorHalf.TOP;
      }

      return var10000.withProperty(var2, var3);
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= getMetaForFacing((EnumFacing)var1.getValue(FACING));
      if ((Boolean)var1.getValue(OPEN)) {
         var2 |= 143 ^ 139;
      }

      if (var1.getValue(HALF) == BlockTrapDoor.DoorHalf.TOP) {
         var2 |= 119 ^ 127;
      }

      return var2;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if ((var4 == EnumFacing.UP && var2.getValue(HALF) == BlockTrapDoor.DoorHalf.TOP || var4 == EnumFacing.DOWN && var2.getValue(HALF) == BlockTrapDoor.DoorHalf.BOTTOM) && !(Boolean)var2.getValue(OPEN)) {
         var10000 = BlockFaceShape.SOLID;
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (this.blockMaterial == Material.IRON) {
         return (boolean)"".length();
      } else {
         var3 = var3.cycleProperty(OPEN);
         var1.setBlockState(var2, var3, "  ".length());
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         this.playSound(var4, var1, var2, (Boolean)var3.getValue(OPEN));
         return (boolean)" ".length();
      }
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public boolean canPlaceBlockOnSide(World var1, BlockPos var2, EnumFacing var3) {
      return (boolean)" ".length();
   }

   protected static int getMetaForFacing(EnumFacing var0) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var0.ordinal()]) {
      case 1:
         return "".length();
      case 2:
         return " ".length();
      case 3:
         return "  ".length();
      case 4:
      default:
         return "   ".length();
      }
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      int var10000;
      if (!(Boolean)var1.getBlockState(var2).getValue(OPEN)) {
         var10000 = " ".length();
         "".length();
         if (-1 == 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      IBlockState var9 = this.getDefaultState();
      PropertyEnum var10001;
      BlockTrapDoor.DoorHalf var10002;
      if (var3.getAxis().isHorizontal()) {
         var9 = var9.withProperty(FACING, var3).withProperty(OPEN, Boolean.valueOf((boolean)"".length()));
         var10001 = HALF;
         if (var5 > 0.5F) {
            var10002 = BlockTrapDoor.DoorHalf.TOP;
            "".length();
            if (0 >= 3) {
               throw null;
            }
         } else {
            var10002 = BlockTrapDoor.DoorHalf.BOTTOM;
         }

         var9 = var9.withProperty(var10001, var10002);
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var9 = var9.withProperty(FACING, var8.getHorizontalFacing().getOpposite()).withProperty(OPEN, Boolean.valueOf((boolean)"".length()));
         var10001 = HALF;
         if (var3 == EnumFacing.UP) {
            var10002 = BlockTrapDoor.DoorHalf.BOTTOM;
            "".length();
            if (2 != 2) {
               throw null;
            }
         } else {
            var10002 = BlockTrapDoor.DoorHalf.TOP;
         }

         var9 = var9.withProperty(var10001, var10002);
      }

      if (var1.isBlockPowered(var2)) {
         var9 = var9.withProperty(OPEN, Boolean.valueOf((boolean)" ".length()));
      }

      return var9;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      AxisAlignedBB var4;
      if ((Boolean)var1.getValue(OPEN)) {
         switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
         case 1:
         default:
            var4 = NORTH_OPEN_AABB;
            "".length();
            if (2 != 2) {
               throw null;
            }
            break;
         case 2:
            var4 = SOUTH_OPEN_AABB;
            "".length();
            if (-1 != -1) {
               throw null;
            }
            break;
         case 3:
            var4 = WEST_OPEN_AABB;
            "".length();
            if (4 == -1) {
               throw null;
            }
            break;
         case 4:
            var4 = EAST_OPEN_AABB;
            "".length();
            if (3 <= 2) {
               throw null;
            }
         }
      } else if (var1.getValue(HALF) == BlockTrapDoor.DoorHalf.TOP) {
         var4 = TOP_AABB;
         "".length();
         if (4 <= 0) {
            throw null;
         }
      } else {
         var4 = BOTTOM_AABB;
      }

      return var4;
   }

   private static void I() {
      I = new String[186 ^ 155];
      I["".length()] = I("怿任", "jCnYd");
      I[" ".length()] = I("摴瀰沷", "jTdRN");
      I["  ".length()] = I("栤", "yWgAI");
      I["   ".length()] = I("怔", "RSYWV");
      I[109 ^ 105] = I("掿嫏", "vumzC");
      I[146 ^ 151] = I("奋婫", "JcBwp");
      I[29 ^ 27] = I("掃枻", "vOVzE");
      I[93 ^ 90] = I("桷嫬", "ToqDo");
      I[24 ^ 16] = I("瀊宷", "UnlDf");
      I[58 ^ 51] = I("嫵捐", "rHJSH");
      I[65 ^ 75] = I("抍怍", "ZGERe");
      I[121 ^ 114] = I("伦滄", "ouGzN");
      I[151 ^ 155] = I("庠棄", "QgPqt");
      I[188 ^ 177] = I("澞涊", "tPgwv");
      I[7 ^ 9] = I("哼埇", "DQWva");
      I[94 ^ 81] = I("壎吅", "TJEuR");
      I[176 ^ 160] = I("墱柆", "cBEQc");
      I[132 ^ 149] = I("殿檂", "IrdwK");
      I[49 ^ 35] = I("俷暫", "PqkQO");
      I[211 ^ 192] = I("拉滁", "HZIrD");
      I[102 ^ 114] = I("夐叭", "NAjUh");
      I[189 ^ 168] = I("悈欏旣", "whjBY");
      I[52 ^ 34] = I("滟哾寱姎惿", "lJTti");
      I[176 ^ 167] = I("後捔", "BMtyH");
      I[12 ^ 20] = I("亿", "wOndF");
      I[175 ^ 182] = I("栔昌暰", "kDSzz");
      I[163 ^ 185] = I("匹六", "gEQja");
      I[74 ^ 81] = I("吵檧", "lvYit");
      I[150 ^ 138] = I("寗嫋憄潥", "PudMi");
      I[30 ^ 3] = I("挚润", "JrnTG");
      I[129 ^ 159] = I("抺槪", "CepGy");
      I[2 ^ 29] = I("\f\u0019\t:", "cilTO");
      I[33 ^ 1] = I("\u001c1\u001d.", "tPqHA");
   }

   protected BlockTrapDoor(Material var1) {
      super(var1);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(OPEN, Boolean.valueOf((boolean)"".length())).withProperty(HALF, BlockTrapDoor.DoorHalf.BOTTOM));
      this.setCreativeTab(CreativeTabs.REDSTONE);
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      OPEN = PropertyBool.create(I[32 ^ 63]);
      HALF = PropertyEnum.create(I[162 ^ 130], BlockTrapDoor.DoorHalf.class);
      EAST_OPEN_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.1875D, 1.0D, 1.0D);
      WEST_OPEN_AABB = new AxisAlignedBB(0.8125D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      SOUTH_OPEN_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.1875D);
      NORTH_OPEN_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.8125D, 1.0D, 1.0D, 1.0D);
      BOTTOM_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.1875D, 1.0D);
      TOP_AABB = new AxisAlignedBB(0.0D, 0.8125D, 0.0D, 1.0D, 1.0D, 1.0D);
   }

   protected static EnumFacing getFacing(int var0) {
      switch(var0 & "   ".length()) {
      case 0:
         return EnumFacing.NORTH;
      case 1:
         return EnumFacing.SOUTH;
      case 2:
         return EnumFacing.WEST;
      case 3:
      default:
         return EnumFacing.EAST;
      }
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote) {
         boolean var6 = var2.isBlockPowered(var3);
         if (var6 || var4.getDefaultState().canProvidePower()) {
            boolean var7 = (Boolean)var1.getValue(OPEN);
            if (var7 != var6) {
               var2.setBlockState(var3, var1.withProperty(OPEN, var6), "  ".length());
               I["   ".length()].length();
               I[33 ^ 37].length();
               this.playSound((EntityPlayer)null, var2, var3, var6);
            }
         }
      }

   }

   public static enum DoorHalf implements IStringSerializable {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      BOTTOM;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      TOP;

      static {
         I();
         TOP = new BlockTrapDoor.DoorHalf(I["".length()], "".length(), I[" ".length()]);
         BOTTOM = new BlockTrapDoor.DoorHalf(I["  ".length()], " ".length(), I["   ".length()]);
         BlockTrapDoor.DoorHalf[] var10000 = new BlockTrapDoor.DoorHalf["  ".length()];
         var10000["".length()] = TOP;
         var10000[" ".length()] = BOTTOM;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 != 0);

         throw null;
      }

      public String toString() {
         return this.name;
      }

      public String getName() {
         return this.name;
      }

      private DoorHalf(String var3) {
         this.name = var3;
      }

      private static void I() {
         I = new String[58 ^ 62];
         I["".length()] = I("\u0003&\u001a", "WiJCm");
         I[" ".length()] = I("'\f4", "ScDff");
         I["  ".length()] = I("8\u0007\u0002\u0005$7", "zHVQk");
         I["   ".length()] = I("-<\u0004 )\"", "OSpTF");
      }
   }
}

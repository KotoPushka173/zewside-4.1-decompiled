package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockGrassPath extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB GRASS_PATH_AABB;

   static {
      I();
      GRASS_PATH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.9375D, 1.0D);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return GRASS_PATH_AABB;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != 3);

      throw null;
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var4.ordinal()]) {
      case 1:
         return (boolean)" ".length();
      case 2:
      case 3:
      case 4:
      case 5:
         IBlockState var5 = var2.getBlockState(var3.offset(var4));
         Block var6 = var5.getBlock();
         int var10000;
         if (!var5.isOpaqueCube() && var6 != Blocks.FARMLAND && var6 != Blocks.GRASS_PATH) {
            var10000 = " ".length();
            "".length();
            if (0 >= 1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      default:
         return super.shouldSideBeRendered(var1, var2, var3, var4);
      }
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      super.neighborChanged(var1, var2, var3, var4, var5);
      this.func_190971_b(var2, var3);
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = BlockFaceShape.SOLID;
         "".length();
         if (4 < 2) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   private void func_190971_b(World var1, BlockPos var2) {
      if (var1.getBlockState(var2.up()).getMaterial().isSolid()) {
         BlockFarmland.func_190970_b(var1, var2);
      }

   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[102 ^ 98].length();
      I[24 ^ 29].length();
      return new ItemStack(this);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Blocks.DIRT.getItemDropped(Blocks.DIRT.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.DIRT), var2, var3);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockGrassPath() {
      super(Material.GROUND);
      this.setLightOpacity(12 + 170 - 112 + 185);
   }

   private static void I() {
      I = new String[184 ^ 190];
      I["".length()] = I("氡烂", "RkFTF");
      I[" ".length()] = I("檸后", "xAzak");
      I["  ".length()] = I("弚扵", "ioIWw");
      I["   ".length()] = I("棯濶", "oetqf");
      I[43 ^ 47] = I("共惖", "EQIuZ");
      I[66 ^ 71] = I("勺沧", "rzcqd");
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      super.onBlockAdded(var1, var2, var3);
      this.func_190971_b(var1, var2);
   }
}

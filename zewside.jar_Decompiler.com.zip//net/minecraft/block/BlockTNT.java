package net.minecraft.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class BlockTNT extends Block {
   // $FF: synthetic field
   public static final PropertyBool EXPLODE;
   // $FF: synthetic field
   private static final String[] I;

   public int getMetaFromState(IBlockState var1) {
      int var10000;
      if ((Boolean)var1.getValue(EXPLODE)) {
         var10000 = " ".length();
         "".length();
         if (0 >= 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   private static void I() {
      I = new String[147 ^ 184];
      I["".length()] = I("斈浜榁", "PExjb");
      I[" ".length()] = I("婤擦墚", "aKVhR");
      I["  ".length()] = I("扗僷峽娶", "mbqDj");
      I["   ".length()] = I("淑囝敉", "OEgYv");
      I[12 ^ 8] = I("嵬橜", "xWQmk");
      I[57 ^ 60] = I("漊儗", "kLhiH");
      I[168 ^ 174] = I("懫殶", "XBAIY");
      I[6 ^ 1] = I("溛嫟", "Dgpso");
      I[132 ^ 140] = I("妐垑", "CkLDi");
      I[69 ^ 76] = I("撦旱楰槈", "saofv");
      I[120 ^ 114] = I("懫咰慼", "TyyNC");
      I[98 ^ 105] = I("怲奍瀓忺", "Ttabg");
      I[48 ^ 60] = I("姎沽", "PzksS");
      I[171 ^ 166] = I("俾佟", "zoaBV");
      I[33 ^ 47] = I("偺卉", "CSYjV");
      I[95 ^ 80] = I("圞厍", "yaVSa");
      I[127 ^ 111] = I("拫梗推", "Zsees");
      I[183 ^ 166] = I("懁", "XJgGX");
      I[145 ^ 131] = I("瀱湁拸偬", "uZDHP");
      I[19 ^ 0] = I("凗徎", "CNiuf");
      I[172 ^ 184] = I("瀽泋", "RNLIE");
      I[77 ^ 88] = I("掱抗灺侾", "GOltM");
      I[215 ^ 193] = I("樛捨佸", "CIBmz");
      I[73 ^ 94] = I("氪嗂婹斦", "mzmtH");
      I[221 ^ 197] = I("媮", "OOBLA");
      I[142 ^ 151] = I("域", "Bpptk");
      I[180 ^ 174] = I("渧", "wsIpA");
      I[55 ^ 44] = I("埨漹掙婞樿", "VSyBn");
      I[42 ^ 54] = I("墴洷仞橲昁", "NwHWF");
      I[140 ^ 145] = I("撨嚣妍", "mPLrU");
      I[124 ^ 98] = I("愹墄", "fnCkQ");
      I[3 ^ 28] = I("樰哇", "TwbKD");
      I[111 ^ 79] = I("拊塐", "xuDLX");
      I[143 ^ 174] = I("湸匍", "BURVv");
      I[175 ^ 141] = I("即劺", "NuKsM");
      I[84 ^ 119] = I("氶恞", "FXbui");
      I[14 ^ 42] = I("嫑柹", "NPWxm");
      I[154 ^ 191] = I("哱煇", "wLlGw");
      I[10 ^ 44] = I("慞晏", "IExkf");
      I[11 ^ 44] = I("榞漛契埮仒", "RQBrV");
      I[188 ^ 148] = I("殅殄", "mYzQu");
      I[157 ^ 180] = I("墦", "ulIju");
      I[37 ^ 15] = I(" \u000b\u0002\b?!\u0016", "EsrdP");
   }

   public boolean canDropFromExplosion(Explosion var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[20 ^ 10];
      String var10001 = I[139 ^ 148];
      String var10002 = I[66 ^ 98];
      var10001 = I[110 ^ 79];
      var10000 = I[141 ^ 175];
      var10001 = I[90 ^ 121];
      var10002 = I[49 ^ 21];
      var10001 = I[4 ^ 33];
      I[77 ^ 107].length();
      I[107 ^ 76].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[161 ^ 137].length();
      I[55 ^ 30].length();
      var10003["".length()] = EXPLODE;
      return new BlockStateContainer(this, var10003);
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      super.onBlockAdded(var1, var2, var3);
      if (var1.isBlockPowered(var2)) {
         this.onBlockDestroyedByPlayer(var1, var2, var3.withProperty(EXPLODE, Boolean.valueOf((boolean)" ".length())));
         var1.setBlockToAir(var2);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }

   }

   static {
      I();
      EXPLODE = PropertyBool.create(I[178 ^ 152]);
   }

   public BlockTNT() {
      super(Material.TNT);
      this.setDefaultState(this.blockState.getBaseState().withProperty(EXPLODE, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.REDSTONE);
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState();
      PropertyBool var10001 = EXPLODE;
      int var10002;
      if ((var1 & " ".length()) > 0) {
         var10002 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (var2.isBlockPowered(var3)) {
         this.onBlockDestroyedByPlayer(var2, var3, var1.withProperty(EXPLODE, Boolean.valueOf((boolean)" ".length())));
         var2.setBlockToAir(var3);
         I[40 ^ 44].length();
      }

   }

   public void onBlockDestroyedByPlayer(World var1, BlockPos var2, IBlockState var3) {
      this.explode(var1, var2, var3, (EntityLivingBase)null);
   }

   public void onBlockDestroyedByExplosion(World var1, BlockPos var2, Explosion var3) {
      String var10000 = I[66 ^ 71];
      String var10001 = I[47 ^ 41];
      String var10002 = I[94 ^ 89];
      var10001 = I[174 ^ 166];
      if (!var1.isRemote) {
         I[81 ^ 88].length();
         I[118 ^ 124].length();
         EntityTNTPrimed var4 = new EntityTNTPrimed(var1, (double)((float)var2.getX() + 0.5F), (double)var2.getY(), (double)((float)var2.getZ() + 0.5F), var3.getExplosivePlacedBy());
         var4.setFuse((short)(var1.rand.nextInt(var4.getFuse() / (133 ^ 129)) + var4.getFuse() / (202 ^ 194)));
         var1.spawnEntityInWorld(var4);
         I[173 ^ 166].length();
      }

   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      ItemStack var10 = var4.getHeldItem(var5);
      if (var10.isEmpty() || var10.getItem() != Items.FLINT_AND_STEEL && var10.getItem() != Items.FIRE_CHARGE) {
         return super.onBlockActivated(var1, var2, var3, var4, var5, var6, var7, var8, var9);
      } else {
         this.explode(var1, var2, var3.withProperty(EXPLODE, Boolean.valueOf((boolean)" ".length())), var4);
         var1.setBlockState(var2, Blocks.AIR.getDefaultState(), 107 ^ 96);
         I[126 ^ 102].length();
         I[216 ^ 193].length();
         I[184 ^ 162].length();
         if (var10.getItem() == Items.FLINT_AND_STEEL) {
            var10.damageItem(" ".length(), var4);
            "".length();
            if (4 <= 1) {
               throw null;
            }
         } else if (!var4.capabilities.isCreativeMode) {
            var10.func_190918_g(" ".length());
         }

         return (boolean)" ".length();
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public void explode(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4) {
      String var10000 = I[33 ^ 45];
      String var10001 = I[13 ^ 0];
      String var10002 = I[190 ^ 176];
      var10001 = I[61 ^ 50];
      if (!var1.isRemote && (Boolean)var3.getValue(EXPLODE)) {
         I[32 ^ 48].length();
         I[161 ^ 176].length();
         I[1 ^ 19].length();
         I[46 ^ 61].length();
         EntityTNTPrimed var5 = new EntityTNTPrimed(var1, (double)((float)var2.getX() + 0.5F), (double)var2.getY(), (double)((float)var2.getZ() + 0.5F), var4);
         var1.spawnEntityInWorld(var5);
         I[151 ^ 131].length();
         I[9 ^ 28].length();
         I[19 ^ 5].length();
         I[75 ^ 92].length();
         var1.playSound((EntityPlayer)null, var5.posX, var5.posY, var5.posZ, SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
      }

   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      if (!var1.isRemote && var4 instanceof EntityArrow) {
         EntityArrow var5 = (EntityArrow)var4;
         if (var5.isBurning()) {
            IBlockState var10003 = var1.getBlockState(var2).withProperty(EXPLODE, Boolean.valueOf((boolean)" ".length()));
            EntityLivingBase var10004;
            if (var5.shootingEntity instanceof EntityLivingBase) {
               var10004 = (EntityLivingBase)var5.shootingEntity;
               "".length();
               if (4 <= 0) {
                  throw null;
               }
            } else {
               var10004 = null;
            }

            this.explode(var1, var2, var10003, var10004);
            var1.setBlockToAir(var2);
            I[20 ^ 15].length();
            I[89 ^ 69].length();
            I[20 ^ 9].length();
         }
      }

   }
}

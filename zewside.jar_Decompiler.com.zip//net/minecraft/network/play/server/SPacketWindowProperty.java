package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketWindowProperty implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int windowId;
   // $FF: synthetic field
   private int property;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int value;

   public SPacketWindowProperty(int var1, int var2, int var3) {
      this.windowId = var1;
      this.property = var2;
      this.value = var3;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.windowId);
      I["".length()].length();
      var1.writeShort(this.property);
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeShort(this.value);
      I["   ".length()].length();
      I[143 ^ 139].length();
   }

   public int getValue() {
      return this.value;
   }

   public int getProperty() {
      return this.property;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > -1);

      throw null;
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleWindowProperty(this);
   }

   private static void I() {
      I = new String[187 ^ 190];
      I["".length()] = I("淰櫽敫", "aMXwn");
      I[" ".length()] = I("溂搟偽灑旛", "TQcOe");
      I["  ".length()] = I("屆川朠偃", "OQYQZ");
      I["   ".length()] = I("椆哬挈庈怉", "GWAtP");
      I[75 ^ 79] = I("搜崁僋", "uNTVD");
   }

   public SPacketWindowProperty() {
   }

   public int getWindowId() {
      return this.windowId;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.windowId = var1.readUnsignedByte();
      this.property = var1.readShort();
      this.value = var1.readShort();
   }
}

package net.minecraft.scoreboard;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.util.text.TextFormatting;

public interface IScoreCriteria {
   // $FF: synthetic field
   IScoreCriteria TRIGGER = new ScoreCriteria("trigger");
   // $FF: synthetic field
   IScoreCriteria[] TEAM_KILL;
   // $FF: synthetic field
   IScoreCriteria HEALTH = new ScoreCriteriaHealth("health");
   // $FF: synthetic field
   IScoreCriteria DUMMY = new ScoreCriteria("dummy");
   // $FF: synthetic field
   IScoreCriteria XP = new ScoreCriteriaReadOnly("xp");
   // $FF: synthetic field
   IScoreCriteria PLAYER_KILL_COUNT = new ScoreCriteria("playerKillCount");
   // $FF: synthetic field
   IScoreCriteria AIR = new ScoreCriteriaReadOnly("air");
   // $FF: synthetic field
   IScoreCriteria DEATH_COUNT = new ScoreCriteria("deathCount");
   // $FF: synthetic field
   IScoreCriteria ARMOR = new ScoreCriteriaReadOnly("armor");
   // $FF: synthetic field
   IScoreCriteria TOTAL_KILL_COUNT = new ScoreCriteria("totalKillCount");
   // $FF: synthetic field
   IScoreCriteria LEVEL = new ScoreCriteriaReadOnly("level");
   // $FF: synthetic field
   Map<String, IScoreCriteria> INSTANCES = Maps.newHashMap();
   // $FF: synthetic field
   IScoreCriteria[] KILLED_BY_TEAM;
   // $FF: synthetic field
   IScoreCriteria FOOD = new ScoreCriteriaReadOnly("food");

   String getName();

   boolean isReadOnly();

   IScoreCriteria.EnumRenderType getRenderType();

   static {
      IScoreCriteria[] var10000 = new IScoreCriteria[164 ^ 180];
      var10000["".length()] = new ScoreCriteriaColored("teamkill.", TextFormatting.BLACK);
      var10000[" ".length()] = new ScoreCriteriaColored("teamkill.", TextFormatting.DARK_BLUE);
      var10000["  ".length()] = new ScoreCriteriaColored("teamkill.", TextFormatting.DARK_GREEN);
      var10000["   ".length()] = new ScoreCriteriaColored("teamkill.", TextFormatting.DARK_AQUA);
      var10000[103 ^ 99] = new ScoreCriteriaColored("teamkill.", TextFormatting.DARK_RED);
      var10000[59 ^ 62] = new ScoreCriteriaColored("teamkill.", TextFormatting.DARK_PURPLE);
      var10000[158 ^ 152] = new ScoreCriteriaColored("teamkill.", TextFormatting.GOLD);
      var10000[116 ^ 115] = new ScoreCriteriaColored("teamkill.", TextFormatting.GRAY);
      var10000[186 ^ 178] = new ScoreCriteriaColored("teamkill.", TextFormatting.DARK_GRAY);
      var10000[102 ^ 111] = new ScoreCriteriaColored("teamkill.", TextFormatting.BLUE);
      var10000[18 ^ 24] = new ScoreCriteriaColored("teamkill.", TextFormatting.GREEN);
      var10000[92 ^ 87] = new ScoreCriteriaColored("teamkill.", TextFormatting.AQUA);
      var10000[164 ^ 168] = new ScoreCriteriaColored("teamkill.", TextFormatting.RED);
      var10000[14 ^ 3] = new ScoreCriteriaColored("teamkill.", TextFormatting.LIGHT_PURPLE);
      var10000[62 ^ 48] = new ScoreCriteriaColored("teamkill.", TextFormatting.YELLOW);
      var10000[109 ^ 98] = new ScoreCriteriaColored("teamkill.", TextFormatting.WHITE);
      TEAM_KILL = var10000;
      var10000 = new IScoreCriteria[168 ^ 184];
      var10000["".length()] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.BLACK);
      var10000[" ".length()] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.DARK_BLUE);
      var10000["  ".length()] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.DARK_GREEN);
      var10000["   ".length()] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.DARK_AQUA);
      var10000[59 ^ 63] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.DARK_RED);
      var10000[92 ^ 89] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.DARK_PURPLE);
      var10000[198 ^ 192] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.GOLD);
      var10000[151 ^ 144] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.GRAY);
      var10000[82 ^ 90] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.DARK_GRAY);
      var10000[13 ^ 4] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.BLUE);
      var10000[144 ^ 154] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.GREEN);
      var10000[185 ^ 178] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.AQUA);
      var10000[187 ^ 183] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.RED);
      var10000[174 ^ 163] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.LIGHT_PURPLE);
      var10000[115 ^ 125] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.YELLOW);
      var10000[165 ^ 170] = new ScoreCriteriaColored("killedByTeam.", TextFormatting.WHITE);
      KILLED_BY_TEAM = var10000;
   }

   public static enum EnumRenderType {
      // $FF: synthetic field
      private final String renderType;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private static final Map<String, IScoreCriteria.EnumRenderType> BY_NAME;
      // $FF: synthetic field
      INTEGER,
      // $FF: synthetic field
      HEARTS;

      static {
         I();
         INTEGER = new IScoreCriteria.EnumRenderType(I["".length()], "".length(), I[" ".length()]);
         HEARTS = new IScoreCriteria.EnumRenderType(I["  ".length()], " ".length(), I["   ".length()]);
         IScoreCriteria.EnumRenderType[] var10000 = new IScoreCriteria.EnumRenderType["  ".length()];
         var10000["".length()] = INTEGER;
         var10000[" ".length()] = HEARTS;
         BY_NAME = Maps.newHashMap();
         IScoreCriteria.EnumRenderType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            IScoreCriteria.EnumRenderType var3 = var0[var2];
            BY_NAME.put(var3.getRenderType(), var3);
            ++var2;
            "".length();
         } while(1 != 4);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 >= -1);

         throw null;
      }

      public static IScoreCriteria.EnumRenderType getByName(String var0) {
         IScoreCriteria.EnumRenderType var1 = (IScoreCriteria.EnumRenderType)BY_NAME.get(var0);
         IScoreCriteria.EnumRenderType var10000;
         if (var1 == null) {
            var10000 = INTEGER;
            "".length();
            if (-1 >= 3) {
               throw null;
            }
         } else {
            var10000 = var1;
         }

         return var10000;
      }

      private EnumRenderType(String var3) {
         this.renderType = var3;
      }

      public String getRenderType() {
         return this.renderType;
      }

      private static void I() {
         I = new String[23 ^ 19];
         I["".length()] = I("\n\n\u0015\u0006\u0005\u0006\u0016", "CDACB");
         I[" ".length()] = I("\u0005\u00197?\f\t\u0005", "lwCZk");
         I["  ".length()] = I("\u0001\u000b,9\u0019\u001a", "INmkM");
         I["   ".length()] = I(",\u0017\u0006\u0019\u00197", "Drgkm");
      }
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.Locale;
import javax.annotation.Nullable;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.text.ITextComponent;

public class SPacketTitle implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int displayTime;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int fadeOutTime;
   // $FF: synthetic field
   private int fadeInTime;
   // $FF: synthetic field
   private SPacketTitle.Type type;
   // $FF: synthetic field
   private ITextComponent message;

   public SPacketTitle(SPacketTitle.Type var1, @Nullable ITextComponent var2, int var3, int var4, int var5) {
      this.type = var1;
      this.message = var2;
      this.fadeInTime = var3;
      this.displayTime = var4;
      this.fadeOutTime = var5;
   }

   public SPacketTitle(SPacketTitle.Type var1, ITextComponent var2) {
      this(var1, var2, -" ".length(), -" ".length(), -" ".length());
   }

   public ITextComponent getMessage() {
      return this.message;
   }

   public int getFadeInTime() {
      return this.fadeInTime;
   }

   public SPacketTitle(int var1, int var2, int var3) {
      this(SPacketTitle.Type.TIMES, (ITextComponent)null, var1, var2, var3);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.type = (SPacketTitle.Type)var1.readEnumValue(SPacketTitle.Type.class);
      if (this.type == SPacketTitle.Type.TITLE || this.type == SPacketTitle.Type.SUBTITLE || this.type == SPacketTitle.Type.ACTIONBAR) {
         this.message = var1.readTextComponent();
      }

      if (this.type == SPacketTitle.Type.TIMES) {
         this.fadeInTime = var1.readInt();
         this.displayTime = var1.readInt();
         this.fadeOutTime = var1.readInt();
      }

   }

   public int getDisplayTime() {
      return this.displayTime;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 1);

      throw null;
   }

   private static void I() {
      I = new String[19 ^ 29];
      I["".length()] = I("嶪梷榁包", "dsgAR");
      I[" ".length()] = I("姗", "ccUOj");
      I["  ".length()] = I("澛櫹潞懙劇", "EpsvY");
      I["   ".length()] = I("烨", "IXbDe");
      I[167 ^ 163] = I("瀕侇埝榘奋", "AcZVt");
      I[100 ^ 97] = I("扌", "GEXEd");
      I[55 ^ 49] = I("巊", "amiul");
      I[46 ^ 41] = I("孕", "PvoWI");
      I[60 ^ 52] = I("岞捰澇怓堨", "idcAq");
      I[17 ^ 24] = I("修朔洛勭凢", "mFcNO");
      I[87 ^ 93] = I("氉戃巺", "PdKrN");
      I[130 ^ 137] = I("墯嫀卄旐嬕", "SyqZd");
      I[135 ^ 139] = I("欵嚘侯滪", "knWON");
      I[105 ^ 100] = I("巎瀲傊壥", "uHXyV");
   }

   public SPacketTitle.Type getType() {
      return this.type;
   }

   static {
      I();
   }

   public SPacketTitle() {
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleTitle(this);
   }

   public int getFadeOutTime() {
      return this.fadeOutTime;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.type);
      I["".length()].length();
      I[" ".length()].length();
      if (this.type == SPacketTitle.Type.TITLE || this.type == SPacketTitle.Type.SUBTITLE || this.type == SPacketTitle.Type.ACTIONBAR) {
         var1.writeTextComponent(this.message);
         I["  ".length()].length();
         I["   ".length()].length();
         I[155 ^ 159].length();
         I[130 ^ 135].length();
      }

      if (this.type == SPacketTitle.Type.TIMES) {
         var1.writeInt(this.fadeInTime);
         I[7 ^ 1].length();
         I[158 ^ 153].length();
         I[152 ^ 144].length();
         I[82 ^ 91].length();
         var1.writeInt(this.displayTime);
         I[35 ^ 41].length();
         var1.writeInt(this.fadeOutTime);
         I[127 ^ 116].length();
         I[128 ^ 140].length();
         I[4 ^ 9].length();
      }

   }

   public static enum Type {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      SUBTITLE,
      // $FF: synthetic field
      CLEAR,
      // $FF: synthetic field
      TITLE,
      // $FF: synthetic field
      RESET,
      // $FF: synthetic field
      ACTIONBAR,
      // $FF: synthetic field
      TIMES;

      private static void I() {
         I = new String[184 ^ 190];
         I["".length()] = I("6\u001d.\u0018$", "bTzTa");
         I[" ".length()] = I("\u0005\u0001\u0015:\r\u0002\u0018\u0012", "VTWnD");
         I["  ".length()] = I("-0>0=\"1++", "lsjyr");
         I["   ".length()] = I("\u001d(7/+", "Iazjx");
         I[91 ^ 95] = I("\u0002\u0004\u0007\u0014\u001e", "AHBUL");
         I[29 ^ 24] = I("\u001d\u0011'.\u0013", "OTtkG");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 == -1);

         throw null;
      }

      static {
         I();
         TITLE = new SPacketTitle.Type(I["".length()], "".length());
         SUBTITLE = new SPacketTitle.Type(I[" ".length()], " ".length());
         ACTIONBAR = new SPacketTitle.Type(I["  ".length()], "  ".length());
         TIMES = new SPacketTitle.Type(I["   ".length()], "   ".length());
         CLEAR = new SPacketTitle.Type(I[123 ^ 127], 150 ^ 146);
         RESET = new SPacketTitle.Type(I[105 ^ 108], 26 ^ 31);
         SPacketTitle.Type[] var10000 = new SPacketTitle.Type[82 ^ 84];
         var10000["".length()] = TITLE;
         var10000[" ".length()] = SUBTITLE;
         var10000["  ".length()] = ACTIONBAR;
         var10000["   ".length()] = TIMES;
         var10000[112 ^ 116] = CLEAR;
         var10000[154 ^ 159] = RESET;
      }

      public static SPacketTitle.Type byName(String var0) {
         SPacketTitle.Type[] var1 = values();
         int var2 = var1.length;
         int var3 = "".length();

         do {
            if (var3 >= var2) {
               return TITLE;
            }

            SPacketTitle.Type var4 = var1[var3];
            if (var4.name().equalsIgnoreCase(var0)) {
               return var4;
            }

            ++var3;
            "".length();
         } while(3 != 0);

         throw null;
      }

      public static String[] getNames() {
         String[] var0 = new String[values().length];
         int var1 = "".length();
         SPacketTitle.Type[] var2 = values();
         int var3 = var2.length;
         int var4 = "".length();

         do {
            if (var4 >= var3) {
               return var0;
            }

            SPacketTitle.Type var5 = var2[var4];
            var0[var1++] = var5.name().toLowerCase(Locale.ROOT);
            ++var4;
            "".length();
         } while(3 >= 1);

         throw null;
      }
   }
}

package net.minecraft.block.material;

public class Material {
   // $FF: synthetic field
   public static final Material CRAFTED_SNOW;
   // $FF: synthetic field
   public static final Material BARRIER;
   // $FF: synthetic field
   public static final Material FIRE;
   // $FF: synthetic field
   public static final Material VINE;
   // $FF: synthetic field
   public static final Material WEB;
   // $FF: synthetic field
   public static final Material SNOW;
   // $FF: synthetic field
   public static final Material STRUCTURE_VOID;
   // $FF: synthetic field
   private boolean isAdventureModeExempt;
   // $FF: synthetic field
   public static final Material GRASS;
   // $FF: synthetic field
   public static final Material GLASS;
   // $FF: synthetic field
   public static final Material PISTON;
   // $FF: synthetic field
   public static final Material SPONGE;
   // $FF: synthetic field
   public static final Material CLAY;
   // $FF: synthetic field
   public static final Material AIR;
   // $FF: synthetic field
   private boolean requiresNoTool = " ".length();
   // $FF: synthetic field
   public static final Material PACKED_ICE;
   // $FF: synthetic field
   public static final Material LEAVES;
   // $FF: synthetic field
   public static final Material TNT;
   // $FF: synthetic field
   public static final Material CACTUS;
   // $FF: synthetic field
   public static final Material CORAL;
   // $FF: synthetic field
   public static final Material LAVA;
   // $FF: synthetic field
   public static final Material GOURD;
   // $FF: synthetic field
   public static final Material CIRCUITS;
   // $FF: synthetic field
   public static final Material CLOTH;
   // $FF: synthetic field
   public static final Material IRON;
   // $FF: synthetic field
   public static final Material SAND;
   // $FF: synthetic field
   public static final Material ROCK;
   // $FF: synthetic field
   private boolean replaceable;
   // $FF: synthetic field
   public static final Material REDSTONE_LIGHT;
   // $FF: synthetic field
   private final MapColor materialMapColor;
   // $FF: synthetic field
   public static final Material CARPET;
   // $FF: synthetic field
   private boolean canBurn;
   // $FF: synthetic field
   public static final Material ICE;
   // $FF: synthetic field
   public static final Material WOOD;
   // $FF: synthetic field
   public static final Material WATER;
   // $FF: synthetic field
   public static final Material GROUND;
   // $FF: synthetic field
   public static final Material PORTAL;
   // $FF: synthetic field
   public static final Material ANVIL;
   // $FF: synthetic field
   private boolean isTranslucent;
   // $FF: synthetic field
   private EnumPushReaction mobilityFlag;
   // $FF: synthetic field
   public static final Material PLANTS;
   // $FF: synthetic field
   public static final Material CAKE;
   // $FF: synthetic field
   public static final Material DRAGON_EGG;

   protected Material setBurning() {
      this.canBurn = (boolean)" ".length();
      return this;
   }

   public boolean isOpaque() {
      int var10000;
      if (this.isTranslucent) {
         var10000 = "".length();
         "".length();
         if (2 < 2) {
            throw null;
         }
      } else {
         var10000 = this.blocksMovement();
      }

      return (boolean)var10000;
   }

   protected Material setImmovableMobility() {
      this.mobilityFlag = EnumPushReaction.BLOCK;
      return this;
   }

   public boolean blocksLight() {
      return (boolean)" ".length();
   }

   static {
      AIR = new MaterialTransparent(MapColor.AIR);
      GRASS = new Material(MapColor.GRASS);
      GROUND = new Material(MapColor.DIRT);
      WOOD = (new Material(MapColor.WOOD)).setBurning();
      ROCK = (new Material(MapColor.STONE)).setRequiresTool();
      IRON = (new Material(MapColor.IRON)).setRequiresTool();
      ANVIL = (new Material(MapColor.IRON)).setRequiresTool().setImmovableMobility();
      WATER = (new MaterialLiquid(MapColor.WATER)).setNoPushMobility();
      LAVA = (new MaterialLiquid(MapColor.TNT)).setNoPushMobility();
      LEAVES = (new Material(MapColor.FOLIAGE)).setBurning().setTranslucent().setNoPushMobility();
      PLANTS = (new MaterialLogic(MapColor.FOLIAGE)).setNoPushMobility();
      VINE = (new MaterialLogic(MapColor.FOLIAGE)).setBurning().setNoPushMobility().setReplaceable();
      SPONGE = new Material(MapColor.YELLOW);
      CLOTH = (new Material(MapColor.CLOTH)).setBurning();
      FIRE = (new MaterialTransparent(MapColor.AIR)).setNoPushMobility();
      SAND = new Material(MapColor.SAND);
      CIRCUITS = (new MaterialLogic(MapColor.AIR)).setNoPushMobility();
      CARPET = (new MaterialLogic(MapColor.CLOTH)).setBurning();
      GLASS = (new Material(MapColor.AIR)).setTranslucent().setAdventureModeExempt();
      REDSTONE_LIGHT = (new Material(MapColor.AIR)).setAdventureModeExempt();
      TNT = (new Material(MapColor.TNT)).setBurning().setTranslucent();
      CORAL = (new Material(MapColor.FOLIAGE)).setNoPushMobility();
      ICE = (new Material(MapColor.ICE)).setTranslucent().setAdventureModeExempt();
      PACKED_ICE = (new Material(MapColor.ICE)).setAdventureModeExempt();
      SNOW = (new MaterialLogic(MapColor.SNOW)).setReplaceable().setTranslucent().setRequiresTool().setNoPushMobility();
      CRAFTED_SNOW = (new Material(MapColor.SNOW)).setRequiresTool();
      CACTUS = (new Material(MapColor.FOLIAGE)).setTranslucent().setNoPushMobility();
      CLAY = new Material(MapColor.CLAY);
      GOURD = (new Material(MapColor.FOLIAGE)).setNoPushMobility();
      DRAGON_EGG = (new Material(MapColor.FOLIAGE)).setNoPushMobility();
      PORTAL = (new MaterialPortal(MapColor.AIR)).setImmovableMobility();
      CAKE = (new Material(MapColor.AIR)).setNoPushMobility();
      WEB = (new Material(MapColor.CLOTH) {
         public boolean blocksMovement() {
            return (boolean)"".length();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 < 4);

            throw null;
         }
      }).setRequiresTool().setNoPushMobility();
      PISTON = (new Material(MapColor.STONE)).setImmovableMobility();
      BARRIER = (new Material(MapColor.AIR)).setRequiresTool().setImmovableMobility();
      STRUCTURE_VOID = new MaterialTransparent(MapColor.AIR);
   }

   protected Material setAdventureModeExempt() {
      this.isAdventureModeExempt = (boolean)" ".length();
      return this;
   }

   public Material(MapColor var1) {
      this.mobilityFlag = EnumPushReaction.NORMAL;
      this.materialMapColor = var1;
   }

   public MapColor getMaterialMapColor() {
      return this.materialMapColor;
   }

   protected Material setRequiresTool() {
      this.requiresNoTool = (boolean)"".length();
      return this;
   }

   public boolean getCanBurn() {
      return this.canBurn;
   }

   protected Material setNoPushMobility() {
      this.mobilityFlag = EnumPushReaction.DESTROY;
      return this;
   }

   public boolean blocksMovement() {
      return (boolean)" ".length();
   }

   public boolean isSolid() {
      return (boolean)" ".length();
   }

   private Material setTranslucent() {
      this.isTranslucent = (boolean)" ".length();
      return this;
   }

   public boolean isLiquid() {
      return (boolean)"".length();
   }

   public EnumPushReaction getMobilityFlag() {
      return this.mobilityFlag;
   }

   public boolean isToolNotRequired() {
      return this.requiresNoTool;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 1);

      throw null;
   }

   public boolean isReplaceable() {
      return this.replaceable;
   }

   public Material setReplaceable() {
      this.replaceable = (boolean)" ".length();
      return this;
   }
}

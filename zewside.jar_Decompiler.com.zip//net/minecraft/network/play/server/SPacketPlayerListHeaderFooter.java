package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.text.ITextComponent;

public class SPacketPlayerListHeaderFooter implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private ITextComponent footer;
   // $FF: synthetic field
   private ITextComponent header;
   // $FF: synthetic field
   private static final String[] I;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeTextComponent(this.header);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeTextComponent(this.footer);
      I["   ".length()].length();
      I[41 ^ 45].length();
      I[160 ^ 165].length();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handlePlayerListHeaderFooter(this);
   }

   static {
      I();
   }

   public ITextComponent getHeader() {
      return this.header;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.header = var1.readTextComponent();
      this.footer = var1.readTextComponent();
   }

   public ITextComponent getFooter() {
      return this.footer;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   private static void I() {
      I = new String[119 ^ 113];
      I["".length()] = I("壘旚沼", "OBqDT");
      I[" ".length()] = I("渮棽恫懺瀥", "sCGrY");
      I["  ".length()] = I("嗍楀塮凅", "HYvze");
      I["   ".length()] = I("婗孛泓岑", "ssYEj");
      I[3 ^ 7] = I("基幉勖", "fnrNp");
      I[28 ^ 25] = I("妓枨", "cZrtG");
   }
}

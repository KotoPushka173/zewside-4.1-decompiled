package net.minecraft.block;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockDynamicLiquid extends BlockLiquid {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   int adjacentSourceBlocks;

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (!this.checkForMixing(var1, var2, var3)) {
         var1.scheduleUpdate(var2, this, this.tickRate(var1));
      }

   }

   private boolean canFlowInto(World var1, BlockPos var2, IBlockState var3) {
      Material var4 = var3.getMaterial();
      int var10000;
      if (var4 != this.blockMaterial && var4 != Material.LAVA && !this.isBlocked(var1, var2, var3)) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private int getSlopeDistance(World var1, BlockPos var2, int var3, EnumFacing var4) {
      int var5 = 277 + 455 - 502 + 770;
      Iterator var6 = EnumFacing.Plane.HORIZONTAL.iterator();

      do {
         if (!var6.hasNext()) {
            return var5;
         }

         EnumFacing var7 = (EnumFacing)var6.next();
         if (var7 != var4) {
            BlockPos var8 = var2.offset(var7);
            IBlockState var9 = var1.getBlockState(var8);
            if (!this.isBlocked(var1, var8, var9) && (var9.getMaterial() != this.blockMaterial || (Integer)var9.getValue(LEVEL) > 0)) {
               if (!this.isBlocked(var1, var8.down(), var9)) {
                  return var3;
               }

               if (var3 < this.getSlopeFindDistance(var1)) {
                  int var10 = this.getSlopeDistance(var1, var8, var3 + " ".length(), var7.getOpposite());
                  if (var10 < var5) {
                     var5 = var10;
                  }
               }
            }
         }

         "".length();
      } while(true);

      throw null;
   }

   private void tryFlowInto(World var1, BlockPos var2, IBlockState var3, int var4) {
      if (this.canFlowInto(var1, var2, var3)) {
         if (var3.getMaterial() != Material.AIR) {
            if (this.blockMaterial == Material.LAVA) {
               this.triggerMixEffects(var1, var2);
               "".length();
               if (2 >= 3) {
                  throw null;
               }
            } else {
               var3.getBlock().dropBlockAsItem(var1, var2, var3, "".length());
            }
         }

         var1.setBlockState(var2, this.getDefaultState().withProperty(LEVEL, var4), "   ".length());
         I[167 ^ 173].length();
         I[204 ^ 199].length();
         I[170 ^ 166].length();
      }

   }

   static {
      I();
   }

   private boolean isBlocked(World var1, BlockPos var2, IBlockState var3) {
      Block var4 = var1.getBlockState(var2).getBlock();
      if (!(var4 instanceof BlockDoor) && var4 != Blocks.STANDING_SIGN && var4 != Blocks.LADDER && var4 != Blocks.REEDS) {
         int var10000;
         if (var4.blockMaterial != Material.PORTAL && var4.blockMaterial != Material.STRUCTURE_VOID) {
            var10000 = var4.blockMaterial.blocksMovement();
            "".length();
            if (1 >= 2) {
               throw null;
            }
         } else {
            var10000 = " ".length();
         }

         return (boolean)var10000;
      } else {
         return (boolean)" ".length();
      }
   }

   private void placeStaticBlock(World var1, BlockPos var2, IBlockState var3) {
      var1.setBlockState(var2, getStaticBlock(this.blockMaterial).getDefaultState().withProperty(LEVEL, var3.getValue(LEVEL)), "  ".length());
      I["".length()].length();
      I[" ".length()].length();
   }

   private Set<EnumFacing> getPossibleFlowDirections(World var1, BlockPos var2) {
      int var3 = 480 + 692 - 393 + 221;
      EnumSet var4 = EnumSet.noneOf(EnumFacing.class);
      Iterator var5 = EnumFacing.Plane.HORIZONTAL.iterator();

      do {
         if (!var5.hasNext()) {
            return var4;
         }

         EnumFacing var6 = (EnumFacing)var5.next();
         BlockPos var7 = var2.offset(var6);
         IBlockState var8 = var1.getBlockState(var7);
         if (!this.isBlocked(var1, var7, var8) && (var8.getMaterial() != this.blockMaterial || (Integer)var8.getValue(LEVEL) > 0)) {
            int var9;
            if (this.isBlocked(var1, var7.down(), var1.getBlockState(var7.down()))) {
               var9 = this.getSlopeDistance(var1, var7, " ".length(), var6.getOpposite());
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            } else {
               var9 = "".length();
            }

            if (var9 < var3) {
               var4.clear();
            }

            if (var9 <= var3) {
               var4.add(var6);
               I[186 ^ 183].length();
               I[19 ^ 29].length();
               I[28 ^ 19].length();
               var3 = var9;
            }
         }

         "".length();
      } while(4 > 2);

      throw null;
   }

   private int getSlopeFindDistance(World var1) {
      int var10000;
      if (this.blockMaterial == Material.LAVA && !var1.provider.doesWaterVaporize()) {
         var10000 = "  ".length();
         "".length();
         if (1 >= 2) {
            throw null;
         }
      } else {
         var10000 = 10 ^ 14;
      }

      return var10000;
   }

   protected BlockDynamicLiquid(Material var1) {
      super(var1);
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      int var5 = (Integer)var3.getValue(LEVEL);
      int var6 = " ".length();
      if (this.blockMaterial == Material.LAVA && !var1.provider.doesWaterVaporize()) {
         var6 = "  ".length();
      }

      int var7 = this.tickRate(var1);
      int var15;
      if (var5 > 0) {
         int var8 = -(9 ^ 109);
         this.adjacentSourceBlocks = "".length();
         Iterator var9 = EnumFacing.Plane.HORIZONTAL.iterator();

         while(var9.hasNext()) {
            EnumFacing var10 = (EnumFacing)var9.next();
            var8 = this.checkAdjacentBlock(var1, var2.offset(var10), var8);
            "".length();
            if (3 <= 0) {
               throw null;
            }
         }

         int var14 = var8 + var6;
         if (var14 >= (157 ^ 149) || var8 < 0) {
            var14 = -" ".length();
         }

         var15 = this.getDepth(var1.getBlockState(var2.up()));
         if (var15 >= 0) {
            if (var15 >= (77 ^ 69)) {
               var14 = var15;
               "".length();
               if (-1 >= 1) {
                  throw null;
               }
            } else {
               var14 = var15 + (17 ^ 25);
            }
         }

         if (this.adjacentSourceBlocks >= "  ".length() && this.blockMaterial == Material.WATER) {
            IBlockState var11 = var1.getBlockState(var2.down());
            if (var11.getMaterial().isSolid()) {
               var14 = "".length();
               "".length();
               if (4 <= 2) {
                  throw null;
               }
            } else if (var11.getMaterial() == this.blockMaterial && (Integer)var11.getValue(LEVEL) == 0) {
               var14 = "".length();
            }
         }

         if (this.blockMaterial == Material.LAVA && var5 < (96 ^ 104) && var14 < (93 ^ 85) && var14 > var5 && var4.nextInt(21 ^ 17) != 0) {
            var7 *= 1 ^ 5;
         }

         if (var14 == var5) {
            this.placeStaticBlock(var1, var2, var3);
            "".length();
            if (2 < -1) {
               throw null;
            }
         } else {
            var5 = var14;
            if (var14 < 0) {
               var1.setBlockToAir(var2);
               I["  ".length()].length();
               I["   ".length()].length();
               I[11 ^ 15].length();
               "".length();
               if (2 >= 4) {
                  throw null;
               }
            } else {
               var3 = var3.withProperty(LEVEL, var14);
               var1.setBlockState(var2, var3, "  ".length());
               I[177 ^ 180].length();
               I[44 ^ 42].length();
               var1.scheduleUpdate(var2, this, var7);
               var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
            }
         }

         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         this.placeStaticBlock(var1, var2, var3);
      }

      IBlockState var13 = var1.getBlockState(var2.down());
      if (this.canFlowInto(var1, var2.down(), var13)) {
         if (this.blockMaterial == Material.LAVA && var1.getBlockState(var2.down()).getMaterial() == Material.WATER) {
            var1.setBlockState(var2.down(), Blocks.STONE.getDefaultState());
            I[5 ^ 2].length();
            I[168 ^ 160].length();
            I[42 ^ 35].length();
            this.triggerMixEffects(var1, var2.down());
            return;
         }

         if (var5 >= (114 ^ 122)) {
            this.tryFlowInto(var1, var2.down(), var13, var5);
            "".length();
            if (0 <= -1) {
               throw null;
            }
         } else {
            this.tryFlowInto(var1, var2.down(), var13, var5 + (10 ^ 2));
            "".length();
            if (3 < -1) {
               throw null;
            }
         }
      } else if (var5 >= 0 && (var5 == 0 || this.isBlocked(var1, var2.down(), var13))) {
         Set var17 = this.getPossibleFlowDirections(var1, var2);
         var15 = var5 + var6;
         if (var5 >= (40 ^ 32)) {
            var15 = " ".length();
         }

         if (var15 >= (11 ^ 3)) {
            return;
         }

         Iterator var16 = var17.iterator();

         while(var16.hasNext()) {
            EnumFacing var12 = (EnumFacing)var16.next();
            this.tryFlowInto(var1, var2.offset(var12), var1.getBlockState(var2.offset(var12)), var15);
            "".length();
            if (false) {
               throw null;
            }
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   private static void I() {
      I = new String[90 ^ 76];
      I["".length()] = I("垐捣咼", "DgLFP");
      I[" ".length()] = I("氦吡", "AKjys");
      I["  ".length()] = I("匇智压姕", "dHgSE");
      I["   ".length()] = I("浂児押", "VQPlY");
      I[28 ^ 24] = I("湂", "ISdAE");
      I[11 ^ 14] = I("倪倠晣潼", "iPaiG");
      I[157 ^ 155] = I("嫮攃", "kmJaO");
      I[195 ^ 196] = I("全厃", "Cufym");
      I[10 ^ 2] = I("孲溕冻", "mcUEZ");
      I[55 ^ 62] = I("溍灒", "UTgJr");
      I[124 ^ 118] = I("叴樰嘧", "ySOwn");
      I[80 ^ 91] = I("匲涜偬棓", "BxaqI");
      I[96 ^ 108] = I("抃啼揾", "FTbMB");
      I[176 ^ 189] = I("劏掹", "DJFZp");
      I[13 ^ 3] = I("引殭", "eekoF");
      I[26 ^ 21] = I("堏俾淋呼", "oDxGD");
      I[208 ^ 192] = I("唟傩", "goyTK");
      I[172 ^ 189] = I("嬣梁", "DrRtC");
      I[33 ^ 51] = I("弹婰", "eyyKs");
      I[26 ^ 9] = I("澜愡", "bKtLt");
      I[215 ^ 195] = I("噚", "QKrwc");
      I[18 ^ 7] = I("殂媪", "SVitW");
   }

   protected int checkAdjacentBlock(World var1, BlockPos var2, int var3) {
      String var10000 = I[156 ^ 140];
      String var10001 = I[51 ^ 34];
      String var10002 = I[29 ^ 15];
      var10001 = I[179 ^ 160];
      int var4 = this.getDepth(var1.getBlockState(var2));
      if (var4 < 0) {
         return var3;
      } else {
         if (var4 == 0) {
            I[161 ^ 181].length();
            I[66 ^ 87].length();
            this.adjacentSourceBlocks += " ".length();
         }

         if (var4 >= (111 ^ 103)) {
            var4 = "".length();
         }

         int var5;
         if (var3 >= 0 && var4 >= var3) {
            var5 = var3;
            "".length();
            if (4 <= 1) {
               throw null;
            }
         } else {
            var5 = var4;
         }

         return var5;
      }
   }
}

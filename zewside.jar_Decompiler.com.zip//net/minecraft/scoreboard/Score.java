package net.minecraft.scoreboard;

import java.util.Comparator;

public class Score {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Scoreboard theScoreboard;
   // $FF: synthetic field
   private int scorePoints;
   // $FF: synthetic field
   private boolean forceUpdate;
   // $FF: synthetic field
   private boolean locked;
   // $FF: synthetic field
   public static final Comparator<Score> SCORE_COMPARATOR;
   // $FF: synthetic field
   private final String scorePlayerName;
   // $FF: synthetic field
   private final ScoreObjective theScoreObjective;

   public Score(Scoreboard var1, ScoreObjective var2, String var3) {
      this.theScoreboard = var1;
      this.theScoreObjective = var2;
      this.scorePlayerName = var3;
      this.forceUpdate = (boolean)" ".length();
   }

   public Scoreboard getScoreScoreboard() {
      return this.theScoreboard;
   }

   public void setLocked(boolean var1) {
      this.locked = var1;
   }

   public String getPlayerName() {
      return this.scorePlayerName;
   }

   public int getScorePoints() {
      return this.scorePoints;
   }

   public void incrementScore() {
      String var10000 = I[159 ^ 134];
      String var10001 = I[109 ^ 119];
      String var10002 = I[145 ^ 138];
      var10001 = I[157 ^ 129];
      if (this.theScoreObjective.getCriteria().isReadOnly()) {
         I[68 ^ 89].length();
         I[222 ^ 192].length();
         I[127 ^ 96].length();
         IllegalStateException var1 = new IllegalStateException(I[92 ^ 124]);
         I[48 ^ 17].length();
         I[105 ^ 75].length();
         I[70 ^ 101].length();
         I[64 ^ 100].length();
         throw var1;
      } else {
         this.increaseScore(" ".length());
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= -1);

      throw null;
   }

   static {
      I();
      SCORE_COMPARATOR = new Comparator<Score>() {
         public int compare(Score var1, Score var2) {
            if (var1.getScorePoints() > var2.getScorePoints()) {
               return " ".length();
            } else {
               int var10000;
               if (var1.getScorePoints() < var2.getScorePoints()) {
                  var10000 = -" ".length();
                  "".length();
                  if (3 <= 1) {
                     throw null;
                  }
               } else {
                  var10000 = var2.getPlayerName().compareToIgnoreCase(var1.getPlayerName());
               }

               return var10000;
            }
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 >= 0);

            throw null;
         }
      };
   }

   private static void I() {
      I = new String[165 ^ 128];
      I["".length()] = I("櫞昏", "GiwJc");
      I[" ".length()] = I("栘仴", "XrGaP");
      I["  ".length()] = I("渐栞", "xMMyy");
      I["   ".length()] = I("乃抚", "pEtCD");
      I[99 ^ 103] = I("汌戾扸", "JclkT");
      I[120 ^ 125] = I("检濜俓", "FAoGh");
      I[75 ^ 77] = I("勦滪", "gACXh");
      I[42 ^ 45] = I("慯仺嘞枪", "DMljI");
      I[112 ^ 120] = I("$\u00128\u0006\t\u0013S;\u0007\u0002\u000e\u0015/H\u0014\u0002\u00122E\t\t\u001f/H\u0015\u0004\u001c$\r", "gsVhf");
      I[162 ^ 171] = I("桪彝瀽潣", "UAnjI");
      I[10 ^ 0] = I("叙侰", "qoFYd");
      I[185 ^ 178] = I("尠旷伊廕", "gCoaR");
      I[111 ^ 99] = I("潸刺", "kqTRh");
      I[8 ^ 5] = I("浅匍偆众", "RGdSQ");
      I[171 ^ 165] = I("戒栨", "bKOyK");
      I[123 ^ 116] = I("岍否", "glgJE");
      I[59 ^ 43] = I("堜悩", "sKBEy");
      I[6 ^ 23] = I("洕渼", "fdLpP");
      I[89 ^ 75] = I("勜悋斷", "fnrPE");
      I[75 ^ 88] = I("'\r?&+\u0010L<' \r\n(h6\u0001\r5e+\n\u0000(h7\u0007\u0003#-", "dlQHD");
      I[136 ^ 156] = I("傱捳悼湏焔", "bZqaW");
      I[151 ^ 130] = I("圈", "fQhSD");
      I[189 ^ 171] = I("廖", "zWrbu");
      I[96 ^ 119] = I("晋暢卣塈", "CMbXM");
      I[133 ^ 157] = I("夔尊", "fSgrE");
      I[104 ^ 113] = I("榙渪", "tveVv");
      I[177 ^ 171] = I("楹嫴", "dyDYb");
      I[174 ^ 181] = I("朜敃", "ePFke");
      I[63 ^ 35] = I("宅殽", "AsMSA");
      I[117 ^ 104] = I("勣楸洰", "aNrSl");
      I[144 ^ 142] = I("敐仮嬬型妢", "uYYFU");
      I[179 ^ 172] = I("巼丆", "rzfca");
      I[96 ^ 64] = I("7(\u0018(=\u0000i\u001b)6\u001d/\u000ff \u0011(\u0012k=\u001a%\u000ff!\u0017&\u0004#", "tIvFR");
      I[11 ^ 42] = I("兴塐圈兖埒", "IwfxS");
      I[130 ^ 160] = I("伴", "mJBEK");
      I[91 ^ 120] = I("槟婅", "MsZfS");
      I[6 ^ 34] = I("弞叞", "hztHI");
   }

   public boolean isLocked() {
      return this.locked;
   }

   public void decreaseScore(int var1) {
      String var10000 = I[161 ^ 175];
      String var10001 = I[203 ^ 196];
      String var10002 = I[103 ^ 119];
      var10001 = I[72 ^ 89];
      if (this.theScoreObjective.getCriteria().isReadOnly()) {
         I[18 ^ 0].length();
         IllegalStateException var2 = new IllegalStateException(I[164 ^ 183]);
         I[34 ^ 54].length();
         I[171 ^ 190].length();
         throw var2;
      } else {
         int var3 = this.getScorePoints();
         I[183 ^ 161].length();
         I[40 ^ 63].length();
         I[64 ^ 88].length();
         this.setScorePoints(var3 - var1);
      }
   }

   public void setScorePoints(int var1) {
      int var2 = this.scorePoints;
      this.scorePoints = var1;
      if (var2 != var1 || this.forceUpdate) {
         this.forceUpdate = (boolean)"".length();
         this.getScoreScoreboard().onScoreUpdated(this);
      }

   }

   public void increaseScore(int var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (this.theScoreObjective.getCriteria().isReadOnly()) {
         I[122 ^ 126].length();
         I[98 ^ 103].length();
         I[164 ^ 162].length();
         I[4 ^ 3].length();
         IllegalStateException var2 = new IllegalStateException(I[49 ^ 57]);
         I[96 ^ 105].length();
         I[65 ^ 75].length();
         I[17 ^ 26].length();
         I[30 ^ 18].length();
         I[68 ^ 73].length();
         throw var2;
      } else {
         this.setScorePoints(this.getScorePoints() + var1);
      }
   }

   public ScoreObjective getObjective() {
      return this.theScoreObjective;
   }
}

package net.minecraft.advancements;

import com.google.common.collect.Maps;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class Criterion {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final ICriterionInstance field_192147_a;

   @Nullable
   public ICriterionInstance func_192143_a() {
      return this.field_192147_a;
   }

   public void func_192140_a(PacketBuffer var1) {
   }

   public Criterion() {
      this.field_192147_a = null;
   }

   public static Criterion func_192146_b(PacketBuffer var0) {
      String var10000 = I[77 ^ 107];
      String var10001 = I[76 ^ 107];
      String var10002 = I[65 ^ 105];
      var10001 = I[29 ^ 52];
      I[81 ^ 123].length();
      I[81 ^ 122].length();
      I[51 ^ 31].length();
      return new Criterion();
   }

   static {
      I();
   }

   private static void I() {
      I = new String[79 ^ 120];
      I["".length()] = I("姮啞", "iviVI");
      I[" ".length()] = I("恠搁", "YECnJ");
      I["  ".length()] = I("攕匜", "MiHkJ");
      I["   ".length()] = I("梣專", "fNkqS");
      I[101 ^ 97] = I("司浒", "uEMjx");
      I[139 ^ 142] = I("枩岧", "IKiIu");
      I[51 ^ 53] = I("倵抽", "gqTSs");
      I[47 ^ 40] = I("契势", "UBHqk");
      I[12 ^ 4] = I("搶慵", "nkqrr");
      I[129 ^ 136] = I("榜奾", "DUoqx");
      I[125 ^ 119] = I("慶屏", "nQrAb");
      I[149 ^ 158] = I("哮巁", "dofpc");
      I[151 ^ 155] = I("峪巇", "yCBHd");
      I[19 ^ 30] = I("泐冹", "HhuhM");
      I[130 ^ 140] = I("嬜榹", "dbmgn");
      I[203 ^ 196] = I("灒櫐", "xHKJi");
      I[74 ^ 90] = I("敺揜", "yPlsw");
      I[80 ^ 65] = I("媱庢", "ZQGnU");
      I[26 ^ 8] = I("檥怩", "TwipL");
      I[16 ^ 3] = I("昹提", "wgfFN");
      I[152 ^ 140] = I("励涚恰嘒櫘", "hdOeC");
      I[98 ^ 119] = I("吴啵哓惚瀮", "TNhoZ");
      I[76 ^ 90] = I("帵惐", "kqluM");
      I[77 ^ 90] = I("\u0015\u0004=$%\u0004\u0004", "avTCB");
      I[95 ^ 71] = I("撮旕侥涃湃", "BuSkg");
      I[41 ^ 48] = I("帄慣仓", "KuVXN");
      I[105 ^ 115] = I("岉姎昡櫩擗", "UEQuJ");
      I[26 ^ 1] = I("圊嶔噏剓", "uIajp");
      I[161 ^ 189] = I("9,\u0007\u0002\u0001\u0019&Q\u0000\u001f\u00196\u0014\u0011\u0004\u001f,Q\u0017\u001f\u0019%\u0016\u0006\u001fJb", "pBqcm");
      I[53 ^ 40] = I("庫毰呺洜呮", "SErQG");
      I[116 ^ 106] = I("墼憭沼工", "XuATY");
      I[182 ^ 169] = I("45\u001b\u0000$#3\u001a\n>", "WZudM");
      I[228 ^ 196] = I("妝愜", "sPaTH");
      I[4 ^ 37] = I("巸宀壃", "tVWEN");
      I[55 ^ 21] = I("偒", "ODfJP");
      I[120 ^ 91] = I("埜宠嚤壨", "TPCGV");
      I[155 ^ 191] = I("丧", "VLwSe");
      I[186 ^ 159] = I("漌梓伈尛兦", "lMTNP");
      I[60 ^ 26] = I("烫嵎", "NoxDM");
      I[158 ^ 185] = I("擑嫾", "yhYgf");
      I[86 ^ 126] = I("坓匆", "OTIld");
      I[15 ^ 38] = I("卄淥", "RPICf");
      I[142 ^ 164] = I("昰", "EJRpY");
      I[38 ^ 13] = I("攊宺憤卯昆", "lhViU");
      I[237 ^ 193] = I("桁", "KPpfM");
      I[80 ^ 125] = I("\u0002\u00020\u0015\b\u0013\u00196\u000f", "apYam");
      I[87 ^ 121] = I("澙槀澱", "jxdCv");
      I[171 ^ 132] = I("濐柮昜垸", "Zzytu");
      I[2 ^ 50] = I("洯擖厱", "lBMEl");
      I[155 ^ 170] = I("拪", "UcmDL");
      I[34 ^ 16] = I("巶樖慛潼捧", "yjima");
      I[245 ^ 198] = I("亗医", "VvAQn");
      I[155 ^ 175] = I("什峯憵", "jMFXz");
      I[155 ^ 174] = I("毝敟嵲活", "IJZij");
      I[70 ^ 112] = I("圁兆崥", "qBmgt");
   }

   public static void func_192141_a(Map<String, Criterion> var0, PacketBuffer var1) {
      var1.writeVarIntToBuffer(var0.size());
      I[125 ^ 76].length();
      I[47 ^ 29].length();
      I[87 ^ 100].length();
      I[241 ^ 197].length();
      Iterator var2 = var0.entrySet().iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         Entry var3 = (Entry)var2.next();
         var1.writeString((String)var3.getKey());
         I[17 ^ 36].length();
         I[73 ^ 127].length();
         ((Criterion)var3.getValue()).func_192140_a(var1);
         "".length();
      } while(3 == 3);

      throw null;
   }

   public static Map<String, Criterion> func_192144_b(JsonObject var0, JsonDeserializationContext var1) {
      HashMap var2 = Maps.newHashMap();
      Iterator var3 = var0.entrySet().iterator();

      do {
         if (!var3.hasNext()) {
            return var2;
         }

         Entry var4 = (Entry)var3.next();
         var2.put(var4.getKey(), func_192145_a(JsonUtils.getJsonObject((JsonElement)var4.getValue(), I[57 ^ 20]), var1));
         I[43 ^ 5].length();
         I[238 ^ 193].length();
         "".length();
      } while(-1 != 4);

      throw null;
   }

   public static Map<String, Criterion> func_192142_c(PacketBuffer var0) {
      HashMap var1 = Maps.newHashMap();
      int var2 = var0.readVarIntFromBuffer();
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            return var1;
         }

         var1.put(var0.readStringFromBuffer(16688 + 27018 - 23158 + 12219), func_192146_b(var0));
         I[8 ^ 56].length();
         ++var3;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public Criterion(ICriterionInstance var1) {
      this.field_192147_a = var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 0);

      throw null;
   }

   public static Criterion func_192145_a(JsonObject var0, JsonDeserializationContext var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[85 ^ 81];
      var10001 = I[129 ^ 132];
      var10002 = I[105 ^ 111];
      var10001 = I[142 ^ 137];
      var10000 = I[14 ^ 6];
      var10001 = I[161 ^ 168];
      var10002 = I[120 ^ 114];
      var10001 = I[109 ^ 102];
      var10000 = I[126 ^ 114];
      var10001 = I[145 ^ 156];
      var10002 = I[127 ^ 113];
      var10001 = I[166 ^ 169];
      var10000 = I[189 ^ 173];
      var10001 = I[118 ^ 103];
      var10002 = I[136 ^ 154];
      var10001 = I[1 ^ 18];
      I[108 ^ 120].length();
      I[3 ^ 22].length();
      I[170 ^ 188].length();
      ResourceLocation var2 = new ResourceLocation(JsonUtils.getString(var0, I[98 ^ 117]));
      ICriterionTrigger var3 = CriteriaTriggers.func_192119_a(var2);
      if (var3 == null) {
         I[24 ^ 0].length();
         I[157 ^ 132].length();
         I[180 ^ 174].length();
         I[72 ^ 83].length();
         JsonSyntaxException var5 = new JsonSyntaxException(I[134 ^ 154] + var2);
         I[98 ^ 127].length();
         I[188 ^ 162].length();
         throw var5;
      } else {
         var10002 = I[70 ^ 89];
         I[85 ^ 117].length();
         I[63 ^ 30].length();
         I[15 ^ 45].length();
         I[173 ^ 142].length();
         ICriterionInstance var4 = var3.func_192166_a(JsonUtils.getJsonObject(var0, var10002, new JsonObject()), var1);
         I[132 ^ 160].length();
         I[115 ^ 86].length();
         return new Criterion(var4);
      }
   }
}

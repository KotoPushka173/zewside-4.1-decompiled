package net.minecraft.block;

import com.google.common.base.Predicate;
import java.util.Iterator;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockMaterialMatcher;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.block.state.pattern.BlockStateMatcher;
import net.minecraft.block.state.pattern.FactoryBlockPattern;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockPumpkin extends BlockHorizontal {
   // $FF: synthetic field
   private BlockPattern snowmanBasePattern;
   // $FF: synthetic field
   private BlockPattern snowmanPattern;
   // $FF: synthetic field
   private BlockPattern golemBasePattern;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final Predicate<IBlockState> IS_PUMPKIN;
   // $FF: synthetic field
   private BlockPattern golemPattern;

   public boolean canDispenserPlace(World var1, BlockPos var2) {
      int var10000;
      if (this.getSnowmanBasePattern().match(var1, var2) == null && this.getGolemBasePattern().match(var1, var2) == null) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, var8.getHorizontalFacing().getOpposite());
   }

   private static void I() {
      I = new String[49 + 51 - 53 + 84];
      I["".length()] = I("恧壓", "npuxm");
      I[" ".length()] = I("兔栦", "czjok");
      I["  ".length()] = I("拾悏", "TjeTn");
      I["   ".length()] = I("气椵", "bvMcm");
      I[71 ^ 67] = I("幋寅", "zqtqi");
      I[27 ^ 30] = I("卞惺", "qOMCF");
      I[41 ^ 47] = I("倜毬", "XvMUj");
      I[124 ^ 123] = I("吨播", "kWsfa");
      I[143 ^ 135] = I("怼潥搕垷", "GyPGn");
      I[150 ^ 159] = I("炟", "tvRwX");
      I[104 ^ 98] = I("乚堉", "sxfZx");
      I[29 ^ 22] = I("岊擓拞棡", "KpWxj");
      I[206 ^ 194] = I("塡夆敞", "sQraS");
      I[19 ^ 30] = I("挻呑", "EqxXw");
      I[53 ^ 59] = I("倾", "MquKi");
      I[15 ^ 0] = I("歜朸煃", "qjHhC");
      I[43 ^ 59] = I("乷嚊殚俴", "JJKeD");
      I[85 ^ 68] = I("啾煩擤", "LtzcY");
      I[136 ^ 154] = I("宙岯榌杔屋", "ctHXN");
      I[11 ^ 24] = I("姄", "Wfuyf");
      I[133 ^ 145] = I("屾呒奻潸", "HAYsO");
      I[84 ^ 65] = I("懋壭喃", "BKGam");
      I[67 ^ 85] = I("倀尊櫞", "buKLo");
      I[133 ^ 146] = I("擴滚", "RkKps");
      I[57 ^ 33] = I("煲寲", "JtoJM");
      I[60 ^ 37] = I("兪川", "QnbhQ");
      I[94 ^ 68] = I("婒椸", "XAOIF");
      I[100 ^ 127] = I("栖冎", "NBHpb");
      I[48 ^ 44] = I("曙槼", "BSDNv");
      I[164 ^ 185] = I("嶚嶛", "gytOQ");
      I[171 ^ 181] = I("暤炟", "sFOLw");
      I[179 ^ 172] = I("庢兏", "IOEmS");
      I[143 ^ 175] = I("怲泘嚫", "yBJYc");
      I[226 ^ 195] = I("泔", "skQie");
      I[5 ^ 39] = I("仇僆旍", "PBAfO");
      I[86 ^ 117] = I("楁仟椽", "wcQqb");
      I[124 ^ 88] = I("堮僬擪庒", "ETDHF");
      I[11 ^ 46] = I("乀汭媣捯徂", "mMWif");
      I[59 ^ 29] = I("洽旬", "WFYql");
      I[85 ^ 114] = I("昋嚳", "BTHgZ");
      I[179 ^ 155] = I("滞漛", "HUmca");
      I[49 ^ 24] = I("凸儵", "NbRpY");
      I[19 ^ 57] = I("嵖樟", "CjbYq");
      I[116 ^ 95] = I("垀泩", "wlNwG");
      I[90 ^ 118] = I("嵤偽", "sszSh");
      I[80 ^ 125] = I("卶抒", "titin");
      I[111 ^ 65] = I("勅嵰", "Dojtc");
      I[109 ^ 66] = I("婅怱", "nkUUW");
      I[71 ^ 119] = I("圯掌", "qgNwe");
      I[25 ^ 40] = I("倵帯", "TtWpM");
      I[89 ^ 107] = I("啹区", "gVyps");
      I[61 ^ 14] = I("澖夠侌扖哅", "oziIU");
      I[188 ^ 136] = I("h", "Hvrph");
      I[71 ^ 114] = I("晃三", "UxqVT");
      I[87 ^ 97] = I("咄剈", "rWoSo");
      I[147 ^ 164] = I("僞公倝", "DJgsk");
      I[108 ^ 84] = I("曞埉咟", "HDRuj");
      I[178 ^ 139] = I("K", "huXEY");
      I[67 ^ 121] = I("嶧唧塗亍崻", "wISyN");
      I[98 ^ 89] = I("惇澆懴", "BbRPH");
      I[165 ^ 153] = I("叒仉剒徝", "hUxVp");
      I[144 ^ 173] = I("汜广倖瀆欇", "sJomH");
      I[2 ^ 60] = I("d", "GyWjG");
      I[29 ^ 34] = I("摉洮", "upDlP");
      I[50 ^ 114] = I("呻奿", "vjlTQ");
      I[224 ^ 161] = I("巹掅", "RJKEx");
      I[123 ^ 57] = I("峔斤", "MQKVe");
      I[208 ^ 147] = I("亝嬦", "zyWau");
      I[35 ^ 103] = I("寬嬧", "CgsEG");
      I[20 ^ 81] = I("搫囦", "QwVQF");
      I[35 ^ 101] = I("慖卸", "BkLIH");
      I[207 ^ 136] = I("冿晔", "FhlyS");
      I[51 ^ 123] = I("抾哌", "Efjtt");
      I[197 ^ 140] = I("揀伺", "AyJDn");
      I[75 ^ 1] = I("旷勾", "muknu");
      I[248 ^ 179] = I("嗍戈曦孒嘓", "iflxD");
      I[110 ^ 34] = I("哰尌", "hJJry");
      I[117 ^ 56] = I("'", "yCjQQ");
      I[201 ^ 135] = I("悛殠憐", "VYLAY");
      I[139 ^ 196] = I("捥廚堽", "oVDAB");
      I[253 ^ 173] = I("j", "IbeYV");
      I[192 ^ 145] = I("渙撻圗毷婇", "XkZRW");
      I[64 ^ 18] = I("枋汙户曖懅", "vLIEz");
      I[36 ^ 119] = I("掀增孵構彄", "ivRbh");
      I[80 ^ 4] = I("i", "JXzAd");
      I[205 ^ 152] = I("妕垱", "LUbgD");
      I[108 ^ 58] = I("劶刳", "VlSLB");
      I[209 ^ 134] = I("倜厬", "vcmuj");
      I[198 ^ 158] = I("勺冤", "IQmqY");
      I[254 ^ 167] = I("嶡檆", "mVfSq");
      I[99 ^ 57] = I("堰懹", "xjZSl");
      I[220 ^ 135] = I("櫺忐", "CagKW");
      I[28 ^ 64] = I("旣揘", "CMVkj");
      I[85 ^ 8] = I("洿幬", "mzwiW");
      I[11 ^ 85] = I("椐杏", "buHWQ");
      I[110 ^ 49] = I("搭挞", "rCnbR");
      I[216 ^ 184] = I("橛嫥", "WMUwQ");
      I[212 ^ 181] = I("囜棐烾夼", "FWqeQ");
      I[24 ^ 122] = I("嚦宠", "yiEGc");
      I[27 ^ 120] = I("\u000bC?", "ucAYq");
      I[208 ^ 180] = I("俗五漂歭拇", "KMklY");
      I[222 ^ 187] = I("潼憊喆啧媨", "MTrJL");
      I[117 ^ 19] = I("凾峟宎摕", "noBEs");
      I[47 ^ 72] = I("瀫歧圷", "ttItx");
      I[52 ^ 92] = I("GZD", "dygfN");
      I[33 ^ 72] = I("嬟儍", "VxvGi");
      I[223 ^ 181] = I("倡昿滿毡", "RvStp");
      I[173 ^ 198] = I("楰令妿殚", "cqrWi");
      I[109 ^ 1] = I("\u000ep\u0018", "pSfty");
      I[126 ^ 19] = I("捙捰", "JuaVK");
      I[23 ^ 121] = I("懒柚", "dijHh");
      I[86 ^ 57] = I("博六", "pShWX");
      I[104 ^ 24] = I("浵唁", "rsFlO");
      I[83 ^ 34] = I("櫕扄", "rBnyv");
      I[249 ^ 139] = I("劼涷", "NXkIR");
      I[20 ^ 103] = I("涁沔", "qVIJG");
      I[203 ^ 191] = I("坧梙", "DxnEs");
      I[19 ^ 102] = I("毺忝", "OQrbq");
      I[205 ^ 187] = I("故涭", "hbNsc");
      I[26 ^ 109] = I("湕揋", "MDrqn");
      I[11 ^ 115] = I("嗯啇", "GWVvb");
      I[5 ^ 124] = I("厩壑企", "orMqo");
      I[90 ^ 32] = I("報擵媳", "WaQfX");
      I[116 ^ 15] = I("櫂", "hUTxi");
      I[216 ^ 164] = I("\u001c\u0012\f", "bLrxy");
      I[200 ^ 181] = I("枉樥冏", "MGhxJ");
      I[250 ^ 132] = I("剎吋昢埁奸", "GyHWR");
      I[95 + 100 - 190 + 122] = I("毯妻", "iRIZk");
      I[107 + 10 - 25 + 36] = I("qKA", "RhbBL");
      I[28 + 10 - -69 + 22] = I("奬檿湵嘪減", "SgJPT");
      I[36 + 41 - 6 + 59] = I("\u0012`)", "lCWSj");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   protected BlockPattern getSnowmanBasePattern() {
      String var10000 = I[134 ^ 161];
      String var10001 = I[103 ^ 79];
      String var10002 = I[20 ^ 61];
      var10001 = I[175 ^ 133];
      var10000 = I[150 ^ 189];
      var10001 = I[114 ^ 94];
      var10002 = I[26 ^ 55];
      var10001 = I[103 ^ 73];
      var10000 = I[132 ^ 171];
      var10001 = I[244 ^ 196];
      var10002 = I[243 ^ 194];
      var10001 = I[25 ^ 43];
      if (this.snowmanBasePattern == null) {
         FactoryBlockPattern var1 = FactoryBlockPattern.start();
         String[] var2 = new String["   ".length()];
         I[246 ^ 197].length();
         var2["".length()] = I[155 ^ 175];
         I[137 ^ 188].length();
         I[84 ^ 98].length();
         I[53 ^ 2].length();
         I[116 ^ 76].length();
         var2[" ".length()] = I[11 ^ 50];
         I[50 ^ 8].length();
         I[80 ^ 107].length();
         I[54 ^ 10].length();
         I[185 ^ 132].length();
         var2["  ".length()] = I[94 ^ 96];
         this.snowmanBasePattern = var1.aisle(var2).where((char)('\u001a' ^ '9'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.SNOW))).build();
      }

      return this.snowmanBasePattern;
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      super.onBlockAdded(var1, var2, var3);
      this.trySpawnGolem(var1, var2);
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (var1.getBlockState(var2).getBlock().blockMaterial.isReplaceable() && var1.getBlockState(var2.down()).isFullyOpaque()) {
         var10000 = " ".length();
         "".length();
         if (1 >= 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
   }

   protected BlockPumpkin() {
      super(Material.GOURD, MapColor.ADOBE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.byHorizontalIndex(var1));
   }

   protected BlockPattern getGolemBasePattern() {
      String var10000 = I[102 ^ 51];
      String var10001 = I[209 ^ 135];
      String var10002 = I[57 ^ 110];
      var10001 = I[193 ^ 153];
      var10000 = I[158 ^ 199];
      var10001 = I[7 ^ 93];
      var10002 = I[44 ^ 119];
      var10001 = I[0 ^ 92];
      var10000 = I[241 ^ 172];
      var10001 = I[198 ^ 152];
      var10002 = I[103 ^ 56];
      var10001 = I[122 ^ 26];
      if (this.golemBasePattern == null) {
         FactoryBlockPattern var1 = FactoryBlockPattern.start();
         String[] var2 = new String["   ".length()];
         I[248 ^ 153].length();
         I[35 ^ 65].length();
         var2["".length()] = I[197 ^ 166];
         I[27 ^ 127].length();
         I[76 ^ 41].length();
         I[57 ^ 95].length();
         I[26 ^ 125].length();
         var2[" ".length()] = I[170 ^ 194];
         I[18 ^ 123].length();
         I[8 ^ 98].length();
         I[255 ^ 148].length();
         var2["  ".length()] = I[94 ^ 50];
         this.golemBasePattern = var1.aisle(var2).where((char)('2' ^ '\u0011'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.IRON_BLOCK))).where((char)('c' ^ '\u001d'), BlockWorldState.hasState(BlockMaterialMatcher.forMaterial(Material.AIR))).build();
      }

      return this.golemBasePattern;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[121 ^ 110];
      String var10001 = I[136 ^ 144];
      String var10002 = I[61 ^ 36];
      var10001 = I[29 ^ 7];
      var10000 = I[107 ^ 112];
      var10001 = I[123 ^ 103];
      var10002 = I[154 ^ 135];
      var10001 = I[78 ^ 80];
      I[85 ^ 74].length();
      I[27 ^ 59].length();
      I[167 ^ 134].length();
      I[70 ^ 100].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[34 ^ 1].length();
      I[180 ^ 144].length();
      I[188 ^ 153].length();
      I[179 ^ 149].length();
      var10003["".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   static {
      I();
      IS_PUMPKIN = new Predicate<IBlockState>() {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 >= 2);

            throw null;
         }

         public boolean apply(@Nullable IBlockState var1) {
            int var10000;
            if (var1 != null && (var1.getBlock() == Blocks.PUMPKIN || var1.getBlock() == Blocks.LIT_PUMPKIN)) {
               var10000 = " ".length();
               "".length();
               if (3 != 3) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      };
   }

   protected BlockPattern getSnowmanPattern() {
      String var10000 = I[67 ^ 124];
      String var10001 = I[228 ^ 164];
      String var10002 = I[128 ^ 193];
      var10001 = I[57 ^ 123];
      var10000 = I[82 ^ 17];
      var10001 = I[59 ^ 127];
      var10002 = I[225 ^ 164];
      var10001 = I[131 ^ 197];
      var10000 = I[117 ^ 50];
      var10001 = I[30 ^ 86];
      var10002 = I[31 ^ 86];
      var10001 = I[95 ^ 21];
      if (this.snowmanPattern == null) {
         FactoryBlockPattern var1 = FactoryBlockPattern.start();
         String[] var2 = new String["   ".length()];
         I[140 ^ 199].length();
         I[34 ^ 110].length();
         var2["".length()] = I[207 ^ 130];
         I[81 ^ 31].length();
         I[97 ^ 46].length();
         var2[" ".length()] = I[3 ^ 83];
         I[95 ^ 14].length();
         I[19 ^ 65].length();
         I[114 ^ 33].length();
         var2["  ".length()] = I[232 ^ 188];
         this.snowmanPattern = var1.aisle(var2).where((char)('Î' ^ '\u0090'), BlockWorldState.hasState(IS_PUMPKIN)).where((char)('k' ^ 'H'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.SNOW))).build();
      }

      return this.snowmanPattern;
   }

   protected BlockPattern getGolemPattern() {
      String var10000 = I[227 ^ 142];
      String var10001 = I[109 ^ 3];
      String var10002 = I[68 ^ 43];
      var10001 = I[193 ^ 177];
      var10000 = I[244 ^ 133];
      var10001 = I[44 ^ 94];
      var10002 = I[115 ^ 0];
      var10001 = I[234 ^ 158];
      var10000 = I[9 ^ 124];
      var10001 = I[8 ^ 126];
      var10002 = I[95 ^ 40];
      var10001 = I[28 ^ 100];
      if (this.golemPattern == null) {
         FactoryBlockPattern var1 = FactoryBlockPattern.start();
         String[] var2 = new String["   ".length()];
         I[0 ^ 121].length();
         I[221 ^ 167].length();
         I[3 ^ 120].length();
         var2["".length()] = I[116 ^ 8];
         I[232 ^ 149].length();
         I[223 ^ 161].length();
         I[112 + 83 - 182 + 114].length();
         var2[" ".length()] = I[107 + 79 - 100 + 42];
         I[21 + 92 - 63 + 79].length();
         var2["  ".length()] = I[60 + 123 - 127 + 74];
         this.golemPattern = var1.aisle(var2).where((char)('ô' ^ 'ª'), BlockWorldState.hasState(IS_PUMPKIN)).where((char)('\u0097' ^ '´'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.IRON_BLOCK))).where((char)('#' ^ ']'), BlockWorldState.hasState(BlockMaterialMatcher.forMaterial(Material.AIR))).build();
      }

      return this.golemPattern;
   }

   private void trySpawnGolem(World var1, BlockPos var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[16 ^ 20];
      var10001 = I[93 ^ 88];
      var10002 = I[86 ^ 80];
      var10001 = I[116 ^ 115];
      BlockPattern.PatternHelper var3 = this.getSnowmanPattern().match(var1, var2);
      int var4;
      Iterator var6;
      EntityPlayerMP var7;
      int var14;
      if (var3 != null) {
         var4 = "".length();

         while(var4 < this.getSnowmanPattern().getThumbLength()) {
            BlockWorldState var5 = var3.translateOffset("".length(), var4, "".length());
            var1.setBlockState(var5.getPos(), Blocks.AIR.getDefaultState(), "  ".length());
            I[38 ^ 46].length();
            I[108 ^ 101].length();
            I[71 ^ 77].length();
            ++var4;
            "".length();
            if (3 < 1) {
               throw null;
            }
         }

         I[3 ^ 8].length();
         I[83 ^ 95].length();
         I[122 ^ 119].length();
         EntitySnowman var9 = new EntitySnowman(var1);
         BlockPos var10 = var3.translateOffset("".length(), "  ".length(), "".length()).getPos();
         var9.setLocationAndAngles((double)var10.getX() + 0.5D, (double)var10.getY() + 0.05D, (double)var10.getZ() + 0.5D, 0.0F, 0.0F);
         var1.spawnEntityInWorld(var9);
         I[82 ^ 92].length();
         I[118 ^ 121].length();
         I[165 ^ 181].length();
         var6 = var1.getEntitiesWithinAABB(EntityPlayerMP.class, var9.getEntityBoundingBox().expandXyz(5.0D)).iterator();

         while(var6.hasNext()) {
            var7 = (EntityPlayerMP)var6.next();
            CriteriaTriggers.field_192133_m.func_192229_a(var7, var9);
            "".length();
            if (1 >= 4) {
               throw null;
            }
         }

         var14 = "".length();

         while(var14 < (209 ^ 169)) {
            var1.spawnParticle(EnumParticleTypes.SNOW_SHOVEL, (double)var10.getX() + var1.rand.nextDouble(), (double)var10.getY() + var1.rand.nextDouble() * 2.5D, (double)var10.getZ() + var1.rand.nextDouble(), 0.0D, 0.0D, 0.0D);
            ++var14;
            "".length();
            if (3 < 2) {
               throw null;
            }
         }

         var14 = "".length();

         while(var14 < this.getSnowmanPattern().getThumbLength()) {
            BlockWorldState var15 = var3.translateOffset("".length(), var14, "".length());
            var1.notifyNeighborsRespectDebug(var15.getPos(), Blocks.AIR, (boolean)"".length());
            ++var14;
            "".length();
            if (0 >= 1) {
               throw null;
            }
         }

         "".length();
         if (-1 != -1) {
            throw null;
         }
      } else {
         var3 = this.getGolemPattern().match(var1, var2);
         if (var3 != null) {
            var4 = "".length();

            while(var4 < this.getGolemPattern().getPalmLength()) {
               int var12 = "".length();

               while(var12 < this.getGolemPattern().getThumbLength()) {
                  var1.setBlockState(var3.translateOffset(var4, var12, "".length()).getPos(), Blocks.AIR.getDefaultState(), "  ".length());
                  I[78 ^ 95].length();
                  I[77 ^ 95].length();
                  ++var12;
                  "".length();
                  if (3 <= 1) {
                     throw null;
                  }
               }

               ++var4;
               "".length();
               if (2 != 2) {
                  throw null;
               }
            }

            BlockPos var11 = var3.translateOffset(" ".length(), "  ".length(), "".length()).getPos();
            I[124 ^ 111].length();
            EntityIronGolem var13 = new EntityIronGolem(var1);
            var13.setPlayerCreated((boolean)" ".length());
            var13.setLocationAndAngles((double)var11.getX() + 0.5D, (double)var11.getY() + 0.05D, (double)var11.getZ() + 0.5D, 0.0F, 0.0F);
            var1.spawnEntityInWorld(var13);
            I[40 ^ 60].length();
            I[20 ^ 1].length();
            I[152 ^ 142].length();
            var6 = var1.getEntitiesWithinAABB(EntityPlayerMP.class, var13.getEntityBoundingBox().expandXyz(5.0D)).iterator();

            while(var6.hasNext()) {
               var7 = (EntityPlayerMP)var6.next();
               CriteriaTriggers.field_192133_m.func_192229_a(var7, var13);
               "".length();
               if (0 < -1) {
                  throw null;
               }
            }

            var14 = "".length();

            while(var14 < (118 ^ 14)) {
               var1.spawnParticle(EnumParticleTypes.SNOWBALL, (double)var11.getX() + var1.rand.nextDouble(), (double)var11.getY() + var1.rand.nextDouble() * 3.9D, (double)var11.getZ() + var1.rand.nextDouble(), 0.0D, 0.0D, 0.0D);
               ++var14;
               "".length();
               if (-1 >= 4) {
                  throw null;
               }
            }

            var14 = "".length();

            while(var14 < this.getGolemPattern().getPalmLength()) {
               int var16 = "".length();

               while(var16 < this.getGolemPattern().getThumbLength()) {
                  BlockWorldState var8 = var3.translateOffset(var14, var16, "".length());
                  var1.notifyNeighborsRespectDebug(var8.getPos(), Blocks.AIR, (boolean)"".length());
                  ++var16;
                  "".length();
                  if (-1 >= 4) {
                     throw null;
                  }
               }

               ++var14;
               "".length();
               if (4 < 1) {
                  throw null;
               }
            }
         }
      }

   }
}

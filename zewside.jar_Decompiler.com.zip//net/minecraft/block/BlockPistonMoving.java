package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityPiston;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockPistonMoving extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   public static final PropertyEnum<BlockPistonExtension.EnumPistonType> TYPE;

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      TileEntityPiston var4 = this.getTilePistonAt(var2, var3);
      AxisAlignedBB var10000;
      if (var4 != null) {
         var10000 = var4.getAABB(var2, var3);
         "".length();
         if (4 <= 1) {
            throw null;
         }
      } else {
         var10000 = FULL_BLOCK_AABB;
      }

      return var10000;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      TileEntity var4 = var1.getTileEntity(var2);
      if (var4 instanceof TileEntityPiston) {
         ((TileEntityPiston)var4).clearPistonTileEntity();
         "".length();
         if (3 <= -1) {
            throw null;
         }
      } else {
         super.breakBlock(var1, var2, var3);
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 1);

      throw null;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   @Nullable
   private TileEntityPiston getTilePistonAt(IBlockAccess var1, BlockPos var2) {
      TileEntity var3 = var1.getTileEntity(var2);
      TileEntityPiston var10000;
      if (var3 instanceof TileEntityPiston) {
         var10000 = (TileEntityPiston)var3;
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public static TileEntity createTilePiston(IBlockState var0, EnumFacing var1, boolean var2, boolean var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[40 ^ 44].length();
      I[99 ^ 102].length();
      I[35 ^ 37].length();
      I[22 ^ 17].length();
      return new TileEntityPiston(var0, var1, var2, var3);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.field_190931_a;
   }

   public BlockPistonMoving() {
      super(Material.PISTON);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(TYPE, BlockPistonExtension.EnumPistonType.DEFAULT));
      this.setHardness(-1.0F);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   static {
      I();
      FACING = BlockPistonExtension.FACING;
      TYPE = BlockPistonExtension.TYPE;
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      TileEntityPiston var8 = this.getTilePistonAt(var2, var3);
      if (var8 != null) {
         var8.func_190609_a(var2, var3, var4, var5, var6);
      }

   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (!var1.isRemote && var1.getTileEntity(var2) == null) {
         var1.setBlockToAir(var2);
         I[183 ^ 187].length();
         I[4 ^ 9].length();
         I[29 ^ 19].length();
         return (boolean)" ".length();
      } else {
         return (boolean)"".length();
      }
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      TileEntityPiston var4 = this.getTilePistonAt(var2, var3);
      AxisAlignedBB var10000;
      if (var4 == null) {
         var10000 = null;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = var4.getAABB(var2, var3);
      }

      return var10000;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[170 ^ 184];
      String var10001 = I[14 ^ 29];
      String var10002 = I[22 ^ 2];
      var10001 = I[29 ^ 8];
      var10000 = I[169 ^ 191];
      var10001 = I[166 ^ 177];
      var10002 = I[150 ^ 142];
      var10001 = I[176 ^ 169];
      var10000 = I[134 ^ 156];
      var10001 = I[137 ^ 146];
      var10002 = I[149 ^ 137];
      var10001 = I[117 ^ 104];
      I[220 ^ 194].length();
      I[174 ^ 177].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[59 ^ 27].length();
      I[188 ^ 157].length();
      I[154 ^ 184].length();
      I[190 ^ 157].length();
      I[47 ^ 11].length();
      var10003["".length()] = FACING;
      I[31 ^ 58].length();
      I[24 ^ 62].length();
      I[50 ^ 21].length();
      I[111 ^ 71].length();
      I[44 ^ 5].length();
      var10003[" ".length()] = TYPE;
      return new BlockStateContainer(this, var10003);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, BlockPistonExtension.getFacing(var1));
      PropertyEnum var10001 = TYPE;
      BlockPistonExtension.EnumPistonType var10002;
      if ((var1 & (73 ^ 65)) > 0) {
         var10002 = BlockPistonExtension.EnumPistonType.STICKY;
         "".length();
         if (3 <= 1) {
            throw null;
         }
      } else {
         var10002 = BlockPistonExtension.EnumPistonType.DEFAULT;
      }

      return var10000.withProperty(var10001, var10002);
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      return ItemStack.field_190927_a;
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      return (boolean)"".length();
   }

   public boolean canPlaceBlockOnSide(World var1, BlockPos var2, EnumFacing var3) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   private static void I() {
      I = new String[28 ^ 54];
      I["".length()] = I("巍喛", "ZxChm");
      I[" ".length()] = I("倂沯", "ruyON");
      I["  ".length()] = I("冄宛", "FMjmI");
      I["   ".length()] = I("姽劒", "yiJuc");
      I[100 ^ 96] = I("占位伸沵", "YKkys");
      I[127 ^ 122] = I("潥娊", "WkHXA");
      I[51 ^ 53] = I("匨梳侜汯嚽", "RpXew");
      I[114 ^ 117] = I("嶄代唦", "XqMdt");
      I[80 ^ 88] = I("敃咹允榴備", "rfcjb");
      I[154 ^ 147] = I("噿", "HXbhn");
      I[126 ^ 116] = I("杝弸傢桚扃", "Uwdql");
      I[158 ^ 149] = I("構嚆淊抂", "UTssz");
      I[57 ^ 53] = I("乷憝戌毁湍", "AKGuK");
      I[179 ^ 190] = I("溻灦剖啋", "nMUok");
      I[85 ^ 91] = I("悆瀰劓毳幞", "UblCm");
      I[127 ^ 112] = I("剝炇婁旮", "GyTWS");
      I[14 ^ 30] = I("儀", "kQLDh");
      I[43 ^ 58] = I("汤叩哵", "rvjad");
      I[49 ^ 35] = I("咝头", "Gualp");
      I[96 ^ 115] = I("煵惴", "peIex");
      I[55 ^ 35] = I("劥刏", "ghWbC");
      I[99 ^ 118] = I("儫教", "SwnoT");
      I[89 ^ 79] = I("涨广", "ORTFa");
      I[82 ^ 69] = I("浳摼", "MRzOS");
      I[126 ^ 102] = I("價旁", "SUpNA");
      I[97 ^ 120] = I("佗栏", "qSxfc");
      I[130 ^ 152] = I("嚈妟", "bmJFL");
      I[73 ^ 82] = I("杘乌", "Vemtk");
      I[43 ^ 55] = I("嗔凵", "IlpDo");
      I[17 ^ 12] = I("圾溳", "pmHgv");
      I[126 ^ 96] = I("彿善庝漳", "aJenp");
      I[47 ^ 48] = I("呋", "mnUoW");
      I[71 ^ 103] = I("倈凎橝嫭", "KYjvY");
      I[84 ^ 117] = I("檝", "zzObT");
      I[189 ^ 159] = I("嶇埣濼", "OiLHI");
      I[150 ^ 181] = I("沒煝滻", "Bpqaj");
      I[88 ^ 124] = I("懡桹", "wcbQS");
      I[110 ^ 75] = I("国剷", "nPCne");
      I[154 ^ 188] = I("届怘欸嫜", "RBiDd");
      I[116 ^ 83] = I("僶揉尞咥乹", "UpsaG");
      I[147 ^ 187] = I("哴掕写果元", "LxyBZ");
      I[48 ^ 25] = I("海溬漢毠", "YEedd");
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote) {
         var2.getTileEntity(var3);
         I[83 ^ 92].length();
         I[9 ^ 25].length();
         I[54 ^ 39].length();
      }

   }

   @Nullable
   public RayTraceResult collisionRayTrace(IBlockState var1, World var2, BlockPos var3, Vec3d var4, Vec3d var5) {
      return null;
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      if (!var1.isRemote) {
         TileEntityPiston var6 = this.getTilePistonAt(var1, var2);
         if (var6 != null) {
            IBlockState var7 = var6.getPistonState();
            var7.getBlock().dropBlockAsItem(var1, var2, var7, "".length());
         }
      }

   }

   @Nullable
   public TileEntity createNewTileEntity(World var1, int var2) {
      return null;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getIndex();
      if (var1.getValue(TYPE) == BlockPistonExtension.EnumPistonType.STICKY) {
         var2 |= 172 ^ 164;
      }

      return var2;
   }

   public void onBlockDestroyedByPlayer(World var1, BlockPos var2, IBlockState var3) {
      BlockPos var4 = var2.offset(((EnumFacing)var3.getValue(FACING)).getOpposite());
      IBlockState var5 = var1.getBlockState(var4);
      if (var5.getBlock() instanceof BlockPistonBase && (Boolean)var5.getValue(BlockPistonBase.EXTENDED)) {
         var1.setBlockToAir(var4);
         I[185 ^ 177].length();
         I[101 ^ 108].length();
         I[82 ^ 88].length();
         I[138 ^ 129].length();
      }

   }
}

package net.minecraft.advancements;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.io.Files;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.play.server.SPacketAdvancementInfo;
import net.minecraft.network.play.server.SPacketSelectAdvancementsTab;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.PlayerList;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextComponentTranslation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PlayerAdvancements {
   // $FF: synthetic field
   private final Set<Advancement> field_192759_g = Sets.newLinkedHashSet();
   // $FF: synthetic field
   private static final Logger field_192753_a;
   // $FF: synthetic field
   private boolean field_192763_k = " ".length();
   // $FF: synthetic field
   private final Map<Advancement, AdvancementProgress> field_192758_f = Maps.newLinkedHashMap();
   // $FF: synthetic field
   private static final Gson field_192754_b;
   // $FF: synthetic field
   private final MinecraftServer field_192756_d;
   // $FF: synthetic field
   private final File field_192757_e;
   // $FF: synthetic field
   private final Set<Advancement> field_192761_i = Sets.newLinkedHashSet();
   // $FF: synthetic field
   private final Set<Advancement> field_192760_h = Sets.newLinkedHashSet();
   // $FF: synthetic field
   private static final TypeToken<Map<ResourceLocation, AdvancementProgress>> field_192755_c;
   // $FF: synthetic field
   @Nullable
   private Advancement field_194221_k;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private EntityPlayerMP field_192762_j;

   private static void I() {
      I = new String[36 + 89 - 16 + 35];
      I["".length()] = I("例侦号庩", "nTqxF");
      I[" ".length()] = I("披佼", "ADhXV");
      I["  ".length()] = I("掤浮圈噩孡", "QWydt");
      I["   ".length()] = I("嘌憃帍", "NeWVz");
      I[152 ^ 156] = I("慪浵嶛师", "HulMi");
      I[27 ^ 30] = I("圈仉", "wHUEk");
      I[14 ^ 8] = I("厖兩", "xQhIx");
      I[140 ^ 139] = I("", "Cburg");
      I[21 ^ 29] = I("崾洡檘扷", "OrRwk");
      I[16 ^ 25] = I("僇惼伕", "dPCSh");
      I[122 ^ 112] = I("喭垦樠", "COpXQ");
      I[204 ^ 199] = I("妱吮", "sbjri");
      I[12 ^ 0] = I("槖淽", "nOfxw");
      I[22 ^ 27] = I("摩塈", "CSIyn");
      I[92 ^ 82] = I("潰刅", "dbCPN");
      I[176 ^ 191] = I("屦冪", "YYVtw");
      I[211 ^ 195] = I("濬斗", "YLQUD");
      I[208 ^ 193] = I("巓椡", "xjGoW");
      I[58 ^ 40] = I("叾柑", "koBqa");
      I[164 ^ 183] = I("游常", "FDtZI");
      I[121 ^ 109] = I("悴會", "bwKll");
      I[64 ^ 85] = I("峏塅", "ywGrS");
      I[173 ^ 187] = I("嗣庪", "bvyAV");
      I[58 ^ 45] = I("慗岲", "Czanr");
      I[22 ^ 14] = I("朖堵", "pJunQ");
      I[179 ^ 170] = I("昈橘", "ZLsEl");
      I[58 ^ 32] = I("嵿极", "WNAVq");
      I[125 ^ 102] = I("屖恾", "ItWOS");
      I[156 ^ 128] = I("哜嚑杉昗呱", "DUXbG");
      I[37 ^ 56] = I("倸徴怘湐啥", "cPfXD");
      I[79 ^ 81] = I("巳嗡橤棏傈", "YpKsJ");
      I[63 ^ 32] = I("?*6\u001a+Y+6\u0018#Y#,\u0006o\u0018!5\u0015!\u001a .\u0011!\r6", "yECtO");
      I[54 ^ 22] = I("殪濨徫瀜喊", "VrBAc");
      I[138 ^ 171] = I("湧", "JEfnV");
      I[230 ^ 196] = I("峈殳梳塱煿", "TdGuc");
      I[97 ^ 66] = I("咙囆", "jlIAw");
      I[124 ^ 88] = I("怭溜偨専攆", "yLVBe");
      I[147 ^ 182] = I("\f\u001f\u0007+! \u001cI%73\u0019\u0007'6(\u001d\u00070sb", "ExiDS");
      I[60 ^ 26] = I("mY9\u0016I:\u000b?\u001f\u001b/\n#X\u000f#\u00155X", "JyPxi");
      I[175 ^ 136] = I("uFn\u0005\fu\u000f!\t\u000b;L:L\u001d-\u0002=\u0018X4\u00057\u0001\u0017'\u000eq", "UkNlx");
      I[184 ^ 144] = I("瀱廣", "DSnDk");
      I[172 ^ 133] = I("悢哺庣", "tUxre");
      I[92 ^ 118] = I("/\b\u0019\u001b\u0005\u0002@\u0018W\u0011\r\u0015\u001f\u0012A\u001c\u000b\r\u000e\u0004\u001eG\r\u0013\u0017\r\t\u000f\u0012\f\t\t\u0018\u0004A\u0005\tL", "lglwa");
      I[80 ^ 123] = I("檔漵", "LevGC");
      I[24 ^ 52] = I("庫", "XBOee");
      I[21 ^ 56] = I("\r\"\r#\u0013 j\fo\u0016-.\u001d<\u0004n=\u0014.\u000e+?X.\u00138,\u0016,\u0012#(\u0016;\u0004n$\u0016o", "NMxOw");
      I[65 ^ 111] = I("栧呫", "IoAFi");
      I[162 ^ 141] = I("晲扢", "DvRHs");
      I[128 ^ 176] = I("沉屙", "UIrgL");
      I[58 ^ 11] = I("噜柀", "XALif");
      I[118 ^ 68] = I("悥凖", "ofkix");
      I[185 ^ 138] = I("愩汬", "sdeeo");
      I[43 ^ 31] = I("斄慬浑", "wTqaQ");
      I[7 ^ 50] = I("忎", "PMhVt");
      I[29 ^ 43] = I("塭椴弣洙瀃", "TPbhl");
      I[109 ^ 90] = I("栩椏", "nEsnc");
      I[14 ^ 54] = I("&7=-)\u000b\u007f<a>\u0004.-a=\t91$?E9,7,\u000b;-,(\u000b,;a9\nx", "eXHAM");
      I[43 ^ 18] = I("崢澔", "yJqqA");
      I[61 ^ 7] = I("姐啻", "FohGq");
      I[121 ^ 66] = I("晆塡", "YpaqB");
      I[153 ^ 165] = I("殓婰", "tCJTx");
      I[254 ^ 195] = I("抈幥", "tWBMW");
      I[66 ^ 124] = I("敥灣", "mkhzw");
      I[20 ^ 43] = I("嘖搞", "RhdXS");
      I[75 ^ 11] = I("嘉幅", "PDahq");
      I[112 ^ 49] = I("漹坃", "ZBOQA");
      I[5 ^ 71] = I("健壎", "CZALv");
      I[201 ^ 138] = I("炽槐", "paIsD");
      I[105 ^ 45] = I("夂斢", "UaxGt");
      I[15 ^ 74] = I("櫌溔", "LVTiX");
      I[8 ^ 78] = I("斀啀", "edoId");
      I[81 ^ 22] = I("旔宖", "cVnjY");
      I[210 ^ 154] = I("仙棗", "ZwVaY");
      I[83 ^ 26] = I("亽嬒斦亿态", "Vhjar");
      I[211 ^ 153] = I("煵伃俐吘烎", "ZcubO");
      I[122 ^ 49] = I("叨涖所渠掹", "lwXLp");
      I[58 ^ 118] = I("氮歸惒", "Tjbfr");
      I[143 ^ 194] = I("\r=()\u0005\u00020#\u0007\u0014\u001a2(%\u0015\u00016(2\u0003", "lSFFp");
      I[114 ^ 60] = I("凾報", "jObtn");
      I[50 ^ 125] = I("悂岇", "SHAGa");
      I[105 ^ 57] = I("惦", "lxbRB");
      I[238 ^ 191] = I("佲拂搯悺懷", "yqfzM");
      I[65 ^ 19] = I("\n$+.G\u001d5:?G\b(<;\u0007\n)'?\u0007\u001db", "iLJZi");
      I[11 ^ 88] = I("唞", "wnoxe");
      I[80 ^ 4] = I("惰杞嚇", "CmpEX");
      I[19 ^ 70] = I("呱堢弯", "qJAFk");
      I[207 ^ 153] = I("忪淖", "raCpZ");
      I[245 ^ 162] = I("浞恽恜", "lqzMa");
      I[39 ^ 127] = I("垉澹歪径", "hBfqv");
      I[100 ^ 61] = I("泽勑卮擷呁", "zmEbA");
      I[246 ^ 172] = I("旡巪湇", "SelbK");
      I[192 ^ 155] = I("墎棿", "aNAtN");
      I[5 ^ 89] = I("掕块", "EsvPm");
      I[192 ^ 157] = I("堂剕", "laYHJ");
      I[246 ^ 168] = I("勣伒", "BDkhM");
      I[45 ^ 114] = I("啵攉", "KRPzz");
      I[253 ^ 157] = I("帋喘壶弹徠", "YpOuV");
      I[250 ^ 155] = I("伆氣剤", "QaAdk");
      I[92 ^ 62] = I("果唩凟", "sMyZn");
      I[43 ^ 72] = I("柝囝", "oBQUf");
      I[50 ^ 86] = I("婏濁", "rqUye");
      I[243 ^ 150] = I("捲敚", "WWBbF");
      I[79 ^ 41] = I("栓叮", "mluXX");
      I[77 ^ 42] = I("慗毬治枟", "wGgQJ");
      I[119 ^ 31] = I("咡営堙有", "nznhK");
      I[26 ^ 115] = I("吖杫呲", "CWjrW");
      I[12 ^ 102] = I("昺岈", "GpijW");
      I[174 ^ 197] = I("槄滀", "vEomm");
      I[205 ^ 161] = I("洝慑", "qiTdk");
      I[96 ^ 13] = I("刖槇", "mmEAN");
      I[59 ^ 85] = I("洍坰", "Anuzo");
      I[59 ^ 84] = I("埪儷", "hUQNn");
      I[202 ^ 186] = I("欗炫毸俷", "bcsPt");
      I[57 ^ 72] = I("恘凇槚炢", "jyWSx");
      I[242 ^ 128] = I("幢", "qqleh");
      I[238 ^ 157] = I("恥捞搇斌", "RPyLw");
      I[178 ^ 198] = I("勅嬯卙殄溼", "YYPAr");
      I[209 ^ 164] = I("北嘿", "WtPtH");
      I[201 ^ 191] = I("勣怋", "HHGIy");
      I[244 ^ 131] = I("汁倧", "ojYGv");
      I[69 ^ 61] = I("廊巌", "bWAnl");
      I[255 ^ 134] = I("澞傀坰涋", "Jlnkk");
      I[31 ^ 101] = I("澋", "fXtIR");
      I[47 ^ 84] = I("氽描凳", "tiTMU");
      I[213 ^ 169] = I("壜僌", "kbNww");
      I[79 ^ 50] = I("漸宦", "AIUcH");
      I[212 ^ 170] = I("崟埏", "GGVYq");
      I[74 + 71 - 83 + 65] = I("哤喂", "dgWeB");
      I[121 + 18 - 138 + 127] = I("溋奰倚", "ETsSn");
      I[55 + 108 - 55 + 21] = I("朰峼沑", "vpTXy");
      I[117 + 20 - 130 + 123] = I("墚橬", "DbpPX");
      I[22 + 12 - -57 + 40] = I("樦主溴", "zBDNU");
      I[122 + 94 - 147 + 63] = I("樋悇儖椭垶", "wrfuO");
      I[28 + 11 - -76 + 18] = I("檮夎挽枫烣", "GWSki");
      I[22 + 80 - -15 + 17] = I("卬曑弰悡", "hNeLs");
      I[129 + 107 - 226 + 125] = I("梀叾拻慚", "HHNcM");
      I[52 + 40 - 84 + 128] = I("戯廇揶張", "pYURh");
      I[51 + 7 - -78 + 1] = I("攼呉檇満", "LQOth");
      I[14 + 97 - 31 + 58] = I("拇憕槥僓", "TvktU");
      I[138 + 58 - 138 + 81] = I("仟", "pLYKh");
      I[131 + 71 - 172 + 110] = I("弗煼憾", "gtlIt");
      I[45 + 104 - 95 + 87] = I("乓挅", "oVqIc");
      I[62 + 82 - 12 + 10] = I("昡嘄斌", "lBCPB");
      I[62 + 119 - 61 + 23] = I("嵼", "tLpwa");
   }

   private void func_192752_d() {
      ArrayList var1 = Lists.newArrayList();
      Iterator var2 = this.field_192758_f.entrySet().iterator();

      do {
         if (!var2.hasNext()) {
            var2 = var1.iterator();

            do {
               if (!var2.hasNext()) {
                  return;
               }

               Advancement var4 = (Advancement)var2.next();
               this.func_192742_b(var4);
               "".length();
            } while(-1 < 1);

            throw null;
         }

         Entry var3 = (Entry)var2.next();
         if (((AdvancementProgress)var3.getValue()).func_192105_a()) {
            var1.add(var3.getKey());
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            this.field_192761_i.add(var3.getKey());
            I["   ".length()].length();
            I[191 ^ 187].length();
            I[110 ^ 107].length();
            I[174 ^ 168].length();
         }

         "".length();
      } while(1 < 2);

      throw null;
   }

   public boolean func_192750_a(Advancement var1, String var2) {
      String var10000 = I[44 ^ 21];
      String var10001 = I[130 ^ 184];
      String var10002 = I[249 ^ 194];
      var10001 = I[183 ^ 139];
      var10000 = I[254 ^ 195];
      var10001 = I[248 ^ 198];
      var10002 = I[23 ^ 40];
      var10001 = I[193 ^ 129];
      var10000 = I[20 ^ 85];
      var10001 = I[57 ^ 123];
      var10002 = I[216 ^ 155];
      var10001 = I[116 ^ 48];
      var10000 = I[128 ^ 197];
      var10001 = I[224 ^ 166];
      var10002 = I[128 ^ 199];
      var10001 = I[227 ^ 171];
      int var3 = "".length();
      AdvancementProgress var4 = this.func_192747_a(var1);
      boolean var5 = var4.func_192105_a();
      if (var4.func_192109_a(var2)) {
         this.func_193765_c(var1);
         this.field_192761_i.add(var1);
         I[95 ^ 22].length();
         I[12 ^ 70].length();
         I[12 ^ 71].length();
         I[216 ^ 148].length();
         var3 = " ".length();
         if (!var5 && var4.func_192105_a()) {
            var1.func_192072_d().func_192113_a(this.field_192762_j);
            if (var1.func_192068_c() != null && var1.func_192068_c().func_193220_i() && this.field_192762_j.world.getGameRules().getBoolean(I[234 ^ 167])) {
               PlayerList var6 = this.field_192756_d.getPlayerList();
               I[97 ^ 47].length();
               I[1 ^ 78].length();
               I[67 ^ 19].length();
               I[78 ^ 31].length();
               String var10003 = I[34 ^ 112] + var1.func_192068_c().func_192291_d().func_192307_a();
               Object[] var10004 = new Object["  ".length()];
               I[34 ^ 113].length();
               I[120 ^ 44].length();
               I[28 ^ 73].length();
               var10004["".length()] = this.field_192762_j.getDisplayName();
               I[78 ^ 24].length();
               I[12 ^ 91].length();
               var10004[" ".length()] = var1.func_193123_j();
               var6.sendChatMsg(new TextComponentTranslation(var10003, var10004));
            }
         }
      }

      if (var4.func_192105_a()) {
         this.func_192742_b(var1);
      }

      return (boolean)var3;
   }

   public void func_192741_b(EntityPlayerMP var1) {
      String var10000 = I[193 ^ 171];
      String var10001 = I[211 ^ 184];
      String var10002 = I[4 ^ 104];
      var10001 = I[58 ^ 87];
      if (!this.field_192760_h.isEmpty() || !this.field_192761_i.isEmpty()) {
         HashMap var2 = Maps.newHashMap();
         LinkedHashSet var3 = Sets.newLinkedHashSet();
         LinkedHashSet var4 = Sets.newLinkedHashSet();
         Iterator var5 = this.field_192761_i.iterator();

         Advancement var6;
         while(var5.hasNext()) {
            var6 = (Advancement)var5.next();
            if (this.field_192759_g.contains(var6)) {
               var2.put(var6.func_192067_g(), this.field_192758_f.get(var6));
               I[90 ^ 52].length();
            }

            "".length();
            if (false) {
               throw null;
            }
         }

         var5 = this.field_192760_h.iterator();

         while(var5.hasNext()) {
            var6 = (Advancement)var5.next();
            if (this.field_192759_g.contains(var6)) {
               var3.add(var6);
               I[229 ^ 138].length();
               "".length();
               if (2 != 2) {
                  throw null;
               }
            } else {
               var4.add(var6.func_192067_g());
               I[227 ^ 147].length();
               I[77 ^ 60].length();
            }

            "".length();
            if (4 < -1) {
               throw null;
            }
         }

         if (!var2.isEmpty() || !var3.isEmpty() || !var4.isEmpty()) {
            NetHandlerPlayServer var7 = var1.connection;
            I[205 ^ 191].length();
            I[248 ^ 139].length();
            I[4 ^ 112].length();
            var7.sendPacket(new SPacketAdvancementInfo(this.field_192763_k, var3, var4, var2));
            this.field_192760_h.clear();
            this.field_192761_i.clear();
         }
      }

      this.field_192763_k = (boolean)"".length();
   }

   public void func_193766_b() {
      this.func_192745_a();
      this.field_192758_f.clear();
      this.field_192759_g.clear();
      this.field_192760_h.clear();
      this.field_192761_i.clear();
      this.field_192763_k = (boolean)" ".length();
      this.field_194221_k = null;
      this.func_192740_f();
   }

   public AdvancementProgress func_192747_a(Advancement var1) {
      String var10000 = I[41 ^ 85];
      String var10001 = I[50 ^ 79];
      String var10002 = I[188 ^ 194];
      var10001 = I[126 + 0 - 82 + 83];
      AdvancementProgress var2 = (AdvancementProgress)this.field_192758_f.get(var1);
      if (var2 == null) {
         I[3 + 36 - -80 + 9].length();
         I[80 + 84 - 80 + 45].length();
         var2 = new AdvancementProgress();
         this.func_192743_a(var1, var2);
      }

      return var2;
   }

   private void func_193765_c(Advancement var1) {
      String var10000 = I[68 ^ 39];
      String var10001 = I[115 ^ 23];
      String var10002 = I[104 ^ 13];
      var10001 = I[228 ^ 130];
      AdvancementProgress var2 = this.func_192747_a(var1);
      Iterator var3 = var1.func_192073_f().entrySet().iterator();

      do {
         if (!var3.hasNext()) {
            return;
         }

         Entry var4 = (Entry)var3.next();
         CriterionProgress var5 = var2.func_192106_c((String)var4.getKey());
         if (var5 != null && (var5.func_192151_a() || var2.func_192105_a())) {
            ICriterionInstance var6 = ((Criterion)var4.getValue()).func_192143_a();
            if (var6 != null) {
               ICriterionTrigger var7 = CriteriaTriggers.func_192119_a(var6.func_192244_a());
               if (var7 != null) {
                  I[26 ^ 125].length();
                  I[106 ^ 2].length();
                  I[59 ^ 82].length();
                  var7.func_192164_b(this, new ICriterionTrigger.Listener(var6, var1, (String)var4.getKey()));
               }
            }
         }

         "".length();
      } while(1 >= -1);

      throw null;
   }

   private void func_192751_c() {
      Iterator var1 = this.field_192756_d.func_191949_aK().func_192780_b().iterator();

      do {
         if (!var1.hasNext()) {
            return;
         }

         Advancement var2 = (Advancement)var1.next();
         this.func_193764_b(var2);
         "".length();
      } while(2 == 2);

      throw null;
   }

   private void func_193764_b(Advancement var1) {
      String var10000 = I[207 ^ 148];
      String var10001 = I[99 ^ 63];
      String var10002 = I[247 ^ 170];
      var10001 = I[112 ^ 46];
      AdvancementProgress var2 = this.func_192747_a(var1);
      if (!var2.func_192105_a()) {
         Iterator var3 = var1.func_192073_f().entrySet().iterator();

         while(var3.hasNext()) {
            Entry var4 = (Entry)var3.next();
            CriterionProgress var5 = var2.func_192106_c((String)var4.getKey());
            if (var5 != null && !var5.func_192151_a()) {
               ICriterionInstance var6 = ((Criterion)var4.getValue()).func_192143_a();
               if (var6 != null) {
                  ICriterionTrigger var7 = CriteriaTriggers.func_192119_a(var6.func_192244_a());
                  if (var7 != null) {
                     I[240 ^ 175].length();
                     I[117 ^ 21].length();
                     I[74 ^ 43].length();
                     I[124 ^ 30].length();
                     var7.func_192165_a(this, new ICriterionTrigger.Listener(var6, var1, (String)var4.getKey()));
                  }
               }
            }

            "".length();
            if (2 != 2) {
               throw null;
            }
         }
      }

   }

   private boolean func_192746_d(Advancement var1) {
      AdvancementProgress var2 = this.func_192747_a(var1);
      if (var2.func_192105_a()) {
         return (boolean)" ".length();
      } else {
         Iterator var3 = var1.func_192069_e().iterator();

         do {
            if (!var3.hasNext()) {
               return (boolean)"".length();
            }

            Advancement var4 = (Advancement)var3.next();
            if (this.func_192746_d(var4)) {
               return (boolean)" ".length();
            }

            "".length();
         } while(4 != 1);

         throw null;
      }
   }

   public void func_192745_a() {
      Iterator var1 = CriteriaTriggers.func_192120_a().iterator();

      do {
         if (!var1.hasNext()) {
            return;
         }

         ICriterionTrigger var2 = (ICriterionTrigger)var1.next();
         var2.func_192167_a(this);
         "".length();
      } while(2 != 4);

      throw null;
   }

   private void func_192743_a(Advancement var1, AdvancementProgress var2) {
      var2.func_192099_a(var1.func_192073_f(), var1.func_192074_h());
      this.field_192758_f.put(var1, var2);
      I[119 + 66 - 139 + 84].length();
      I[4 + 97 - -8 + 22].length();
   }

   public boolean func_192744_b(Advancement var1, String var2) {
      int var3 = "".length();
      AdvancementProgress var4 = this.func_192747_a(var1);
      if (var4.func_192101_b(var2)) {
         this.func_193764_b(var1);
         this.field_192761_i.add(var1);
         I[22 ^ 78].length();
         I[229 ^ 188].length();
         I[99 ^ 57].length();
         var3 = " ".length();
      }

      if (!var4.func_192108_b()) {
         this.func_192742_b(var1);
      }

      return (boolean)var3;
   }

   public void func_194220_a(@Nullable Advancement var1) {
      String var10000 = I[209 ^ 164];
      String var10001 = I[125 ^ 11];
      String var10002 = I[194 ^ 181];
      var10001 = I[110 ^ 22];
      Advancement var2 = this.field_194221_k;
      if (var1 != null && var1.func_192070_b() == null && var1.func_192068_c() != null) {
         this.field_194221_k = var1;
         "".length();
         if (4 < 3) {
            throw null;
         }
      } else {
         this.field_194221_k = null;
      }

      if (var2 != this.field_194221_k) {
         NetHandlerPlayServer var3 = this.field_192762_j.connection;
         SPacketSelectAdvancementsTab var4 = new SPacketSelectAdvancementsTab;
         I[66 ^ 59].length();
         I[25 ^ 99].length();
         I[16 ^ 107].length();
         ResourceLocation var10003;
         if (this.field_194221_k == null) {
            var10003 = null;
            "".length();
            if (1 <= -1) {
               throw null;
            }
         } else {
            var10003 = this.field_194221_k.func_192067_g();
         }

         var4.<init>(var10003);
         var3.sendPacket(var4);
      }

   }

   private void func_192742_b(Advancement var1) {
      boolean var2 = this.func_192738_c(var1);
      boolean var3 = this.field_192759_g.contains(var1);
      if (var2 && !var3) {
         this.field_192759_g.add(var1);
         I[13 + 112 - 61 + 68].length();
         I[105 + 67 - 154 + 115].length();
         I[103 + 96 - 148 + 83].length();
         this.field_192760_h.add(var1);
         I[62 + 27 - -42 + 4].length();
         if (this.field_192758_f.containsKey(var1)) {
            this.field_192761_i.add(var1);
            I[106 + 115 - 158 + 73].length();
            I[71 + 9 - 21 + 78].length();
            I[78 + 116 - 189 + 133].length();
            "".length();
            if (false) {
               throw null;
            }
         }
      } else if (!var2 && var3) {
         this.field_192759_g.remove(var1);
         I[0 + 32 - 6 + 113].length();
         I[54 + 35 - -44 + 7].length();
         I[20 + 64 - 22 + 79].length();
         this.field_192760_h.add(var1);
         I[141 + 53 - 117 + 65].length();
         I[58 + 45 - -14 + 26].length();
      }

      if (var2 != var3 && var1.func_192070_b() != null) {
         this.func_192742_b(var1.func_192070_b());
      }

      Iterator var4 = var1.func_192069_e().iterator();

      do {
         if (!var4.hasNext()) {
            return;
         }

         Advancement var5 = (Advancement)var4.next();
         this.func_192742_b(var5);
         "".length();
      } while(3 >= 2);

      throw null;
   }

   static {
      I();
      field_192753_a = LogManager.getLogger();
      field_192754_b = (new GsonBuilder()).registerTypeAdapter(AdvancementProgress.class, new AdvancementProgress.Serializer()).registerTypeAdapter(ResourceLocation.class, new ResourceLocation.Serializer()).setPrettyPrinting().create();
      field_192755_c = new TypeToken<Map<ResourceLocation, AdvancementProgress>>() {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(1 >= 0);

            throw null;
         }
      };
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   private void func_192748_e() {
      Iterator var1 = this.field_192756_d.func_191949_aK().func_192780_b().iterator();

      do {
         if (!var1.hasNext()) {
            return;
         }

         Advancement var2 = (Advancement)var1.next();
         if (var2.func_192073_f().isEmpty()) {
            this.func_192750_a(var2, I[61 ^ 58]);
            I[96 ^ 104].length();
            I[14 ^ 7].length();
            I[15 ^ 5].length();
            var2.func_192072_d().func_192113_a(this.field_192762_j);
         }

         "".length();
      } while(2 >= -1);

      throw null;
   }

   public void func_192739_a(EntityPlayerMP var1) {
      this.field_192762_j = var1;
   }

   private void func_192740_f() {
      String var10000 = I[122 ^ 113];
      String var10001 = I[139 ^ 135];
      String var10002 = I[2 ^ 15];
      var10001 = I[71 ^ 73];
      var10000 = I[108 ^ 99];
      var10001 = I[63 ^ 47];
      var10002 = I[110 ^ 127];
      var10001 = I[7 ^ 21];
      var10000 = I[51 ^ 32];
      var10001 = I[70 ^ 82];
      var10002 = I[53 ^ 32];
      var10001 = I[149 ^ 131];
      var10000 = I[132 ^ 147];
      var10001 = I[78 ^ 86];
      var10002 = I[129 ^ 152];
      var10001 = I[110 ^ 116];
      if (this.field_192757_e.isFile()) {
         label48: {
            Logger var9;
            try {
               String var1 = Files.toString(this.field_192757_e, StandardCharsets.UTF_8);
               Map var2 = (Map)JsonUtils.func_193840_a(field_192754_b, var1, field_192755_c.getType());
               if (var2 == null) {
                  I[41 ^ 50].length();
                  I[57 ^ 37].length();
                  I[27 ^ 6].length();
                  I[54 ^ 40].length();
                  JsonParseException var10 = new JsonParseException(I[130 ^ 157]);
                  I[108 ^ 76].length();
                  I[185 ^ 152].length();
                  I[124 ^ 94].length();
                  throw var10;
               }

               Stream var3 = var2.entrySet().stream().sorted(Comparator.comparing(Entry::getValue));
               Iterator var4 = ((List)var3.collect(Collectors.toList())).iterator();

               while(var4.hasNext()) {
                  Entry var5 = (Entry)var4.next();
                  Advancement var6 = this.field_192756_d.func_191949_aK().func_192778_a((ResourceLocation)var5.getKey());
                  if (var6 == null) {
                     var9 = field_192753_a;
                     I[94 ^ 125].length();
                     I[36 ^ 0].length();
                     var9.warn(I[30 ^ 59] + var5.getKey() + I[146 ^ 180] + this.field_192757_e + I[101 ^ 66]);
                     "".length();
                     if (3 <= -1) {
                        throw null;
                     }
                  } else {
                     this.func_192743_a(var6, (AdvancementProgress)var5.getValue());
                  }

                  "".length();
                  if (-1 >= 3) {
                     throw null;
                  }
               }
            } catch (JsonParseException var7) {
               var9 = field_192753_a;
               I[20 ^ 60].length();
               I[127 ^ 86].length();
               var9.error(I[186 ^ 144] + this.field_192757_e, var7);
               "".length();
               if (1 < 2) {
                  break label48;
               }

               throw null;
            } catch (IOException var8) {
               var9 = field_192753_a;
               I[35 ^ 8].length();
               I[115 ^ 95].length();
               var9.error(I[105 ^ 68] + this.field_192757_e, var8);
               break label48;
            }

            "".length();
            if (4 <= 3) {
               throw null;
            }
         }
      }

      this.func_192748_e();
      this.func_192752_d();
      this.func_192751_c();
   }

   private boolean func_192738_c(Advancement var1) {
      int var2 = "".length();

      while(var1 != null && var2 <= "  ".length()) {
         if (var2 == 0 && this.func_192746_d(var1)) {
            return (boolean)" ".length();
         }

         if (var1.func_192068_c() == null) {
            return (boolean)"".length();
         }

         AdvancementProgress var3 = this.func_192747_a(var1);
         if (var3.func_192105_a()) {
            return (boolean)" ".length();
         }

         if (var1.func_192068_c().func_193224_j()) {
            return (boolean)"".length();
         }

         var1 = var1.func_192070_b();
         ++var2;
         "".length();
         if (1 < 1) {
            throw null;
         }
      }

      return (boolean)"".length();
   }

   public PlayerAdvancements(MinecraftServer var1, File var2, EntityPlayerMP var3) {
      this.field_192756_d = var1;
      this.field_192757_e = var2;
      this.field_192762_j = var3;
      this.func_192740_f();
   }

   public void func_192749_b() {
      String var10000 = I[2 ^ 44];
      String var10001 = I[32 ^ 15];
      String var10002 = I[123 ^ 75];
      var10001 = I[93 ^ 108];
      HashMap var1 = Maps.newHashMap();
      Iterator var2 = this.field_192758_f.entrySet().iterator();

      while(var2.hasNext()) {
         Entry var3 = (Entry)var2.next();
         AdvancementProgress var4 = (AdvancementProgress)var3.getValue();
         if (var4.func_192108_b()) {
            var1.put(((Advancement)var3.getKey()).func_192067_g(), var4);
            I[98 ^ 80].length();
         }

         "".length();
         if (3 <= 2) {
            throw null;
         }
      }

      if (this.field_192757_e.getParentFile() != null) {
         this.field_192757_e.getParentFile().mkdirs();
         I[61 ^ 14].length();
         I[172 ^ 152].length();
         I[27 ^ 46].length();
      }

      try {
         Files.write(field_192754_b.toJson(var1), this.field_192757_e, StandardCharsets.UTF_8);
      } catch (IOException var5) {
         Logger var6 = field_192753_a;
         I[156 ^ 170].length();
         I[155 ^ 172].length();
         var6.error(I[55 ^ 15] + this.field_192757_e, var5);
         return;
      }

      "".length();
      if (4 != 4) {
         throw null;
      }
   }
}

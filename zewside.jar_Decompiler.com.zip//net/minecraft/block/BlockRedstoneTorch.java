package net.minecraft.block;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockRedstoneTorch extends BlockTorch {
   // $FF: synthetic field
   private static final Map<World, List<BlockRedstoneTorch.Toggle>> toggles;
   // $FF: synthetic field
   private final boolean isOn;
   // $FF: synthetic field
   private static final String[] I;

   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = var1.getWeakPower(var2, var3, var4);
         "".length();
         if (4 < 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   public boolean canProvidePower(IBlockState var1) {
      return (boolean)" ".length();
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!this.onNeighborChangeInternal(var2, var3, var1) && this.isOn == this.shouldBeOff(var2, var3, var1)) {
         var2.scheduleUpdate(var3, this, this.tickRate(var2));
      }

   }

   static {
      I();
      toggles = Maps.newHashMap();
   }

   private boolean shouldBeOff(World var1, BlockPos var2, IBlockState var3) {
      EnumFacing var4 = ((EnumFacing)var3.getValue(FACING)).getOpposite();
      return var1.isSidePowered(var2.offset(var4), var4);
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (this.isOn) {
         EnumFacing[] var4 = EnumFacing.values();
         int var5 = var4.length;
         int var6 = "".length();

         while(var6 < var5) {
            EnumFacing var7 = var4[var6];
            var1.notifyNeighborsOfStateChange(var2.offset(var7), this, (boolean)"".length());
            ++var6;
            "".length();
            if (2 <= 0) {
               throw null;
            }
         }
      }

   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      if (this.isOn) {
         double var10000 = (double)var3.getX() + 0.5D;
         double var10001 = var4.nextDouble();
         I[167 ^ 179].length();
         I[159 ^ 138].length();
         double var5 = var10000 + (var10001 - 0.5D) * 0.2D;
         var10000 = (double)var3.getY() + 0.7D;
         var10001 = var4.nextDouble();
         I[53 ^ 35].length();
         I[59 ^ 44].length();
         double var7 = var10000 + (var10001 - 0.5D) * 0.2D;
         var10000 = (double)var3.getZ() + 0.5D;
         var10001 = var4.nextDouble();
         I[144 ^ 136].length();
         double var9 = var10000 + (var10001 - 0.5D) * 0.2D;
         EnumFacing var11 = (EnumFacing)var1.getValue(FACING);
         if (var11.getAxis().isHorizontal()) {
            EnumFacing var12 = var11.getOpposite();
            double var13 = 0.27D;
            var5 += 0.27D * (double)var12.getFrontOffsetX();
            var7 += 0.22D;
            var9 += 0.27D * (double)var12.getFrontOffsetZ();
         }

         var2.spawnParticle(EnumParticleTypes.REDSTONE, var5, var7, var9, 0.0D, 0.0D, 0.0D);
      }

   }

   protected BlockRedstoneTorch(boolean var1) {
      this.isOn = var1;
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab((CreativeTabs)null);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.REDSTONE_TORCH);
   }

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if (this.isOn && var1.getValue(FACING) != var4) {
         var10000 = 31 ^ 16;
         "".length();
         if (4 <= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   private boolean isBurnedOut(World var1, BlockPos var2, boolean var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (!toggles.containsKey(var1)) {
         toggles.put(var1, Lists.newArrayList());
         I[198 ^ 194].length();
         I[106 ^ 111].length();
      }

      List var4 = (List)toggles.get(var1);
      if (var3) {
         I[25 ^ 31].length();
         I[146 ^ 149].length();
         I[111 ^ 103].length();
         var4.add(new BlockRedstoneTorch.Toggle(var2, var1.getTotalWorldTime()));
         I[151 ^ 158].length();
         I[102 ^ 108].length();
         I[101 ^ 110].length();
      }

      int var5 = "".length();
      int var6 = "".length();

      do {
         if (var6 >= var4.size()) {
            return (boolean)"".length();
         }

         BlockRedstoneTorch.Toggle var7 = (BlockRedstoneTorch.Toggle)var4.get(var6);
         if (var7.pos.equals(var2)) {
            ++var5;
            if (var5 >= (54 ^ 62)) {
               return (boolean)" ".length();
            }
         }

         ++var6;
         "".length();
      } while(-1 >= -1);

      throw null;
   }

   private static void I() {
      I = new String[141 ^ 146];
      I["".length()] = I("幎溸", "uiZaX");
      I[" ".length()] = I("奠忮", "hBHxH");
      I["  ".length()] = I("廄噑", "ZTKxe");
      I["   ".length()] = I("泭揟", "ytjWR");
      I[47 ^ 43] = I("嵹瀭瀫", "ZJSPb");
      I[20 ^ 17] = I("儤儊", "aaOIr");
      I[75 ^ 77] = I("亡嶇惟巺劋", "pyTFF");
      I[171 ^ 172] = I("榄摑垜", "rElwS");
      I[206 ^ 198] = I("旋椏氜炳溂", "epfdL");
      I[64 ^ 73] = I("峪暕", "vEkiV");
      I[179 ^ 185] = I("孭崱副", "JVKoc");
      I[54 ^ 61] = I("毳囮", "ZKWdN");
      I[77 ^ 65] = I("啣惾撝", "BwNTg");
      I[124 ^ 113] = I("埂槞唼嘢峷", "qtYfW");
      I[96 ^ 110] = I("灔正揽彑擻", "nbBwp");
      I[79 ^ 64] = I("処惿偕", "xojSt");
      I[50 ^ 34] = I("噇湈", "pGjYQ");
      I[91 ^ 74] = I("俴檬", "GHFxD");
      I[99 ^ 113] = I("澴暶滈仾", "cCnpa");
      I[11 ^ 24] = I("墳嶛岳厏", "vyQuV");
      I[98 ^ 118] = I("恆仝塱", "ReMEt");
      I[159 ^ 138] = I("凊庇洆捋", "idOZP");
      I[123 ^ 109] = I("嫭淇庾泋剱", "oSGyA");
      I[41 ^ 62] = I("滠", "dzHfg");
      I[86 ^ 78] = I("巶幸噕扵淢", "TrinP");
      I[160 ^ 185] = I("堞侪", "niTkD");
      I[12 ^ 22] = I("偦呙", "LnpKU");
      I[172 ^ 183] = I("殃帳", "KGiGI");
      I[6 ^ 26] = I("溿喪", "VISOS");
      I[28 ^ 1] = I("擩烺児", "hWkms");
      I[156 ^ 130] = I("殥溰灍恳櫝", "keonw");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      boolean var5 = this.shouldBeOff(var1, var2, var3);
      List var6 = (List)toggles.get(var1);

      while(var6 != null && !var6.isEmpty() && var1.getTotalWorldTime() - ((BlockRedstoneTorch.Toggle)var6.get("".length())).time > 60L) {
         var6.remove("".length());
         I[19 ^ 31].length();
         I[6 ^ 11].length();
         "".length();
         if (2 <= -1) {
            throw null;
         }
      }

      if (this.isOn) {
         if (var5) {
            var1.setBlockState(var2, Blocks.UNLIT_REDSTONE_TORCH.getDefaultState().withProperty(FACING, var3.getValue(FACING)), "   ".length());
            I[114 ^ 124].length();
            if (this.isBurnedOut(var1, var2, (boolean)" ".length())) {
               EntityPlayer var10001 = (EntityPlayer)null;
               SoundEvent var10003 = SoundEvents.BLOCK_REDSTONE_TORCH_BURNOUT;
               SoundCategory var10004 = SoundCategory.BLOCKS;
               float var10007 = var1.rand.nextFloat();
               float var10008 = var1.rand.nextFloat();
               I[99 ^ 108].length();
               I[53 ^ 37].length();
               I[17 ^ 0].length();
               var1.playSound(var10001, var2, var10003, var10004, 0.5F, 2.6F + (var10007 - var10008) * 0.8F);
               int var7 = "".length();

               while(var7 < (45 ^ 40)) {
                  double var8 = (double)var2.getX() + var4.nextDouble() * 0.6D + 0.2D;
                  double var10 = (double)var2.getY() + var4.nextDouble() * 0.6D + 0.2D;
                  double var12 = (double)var2.getZ() + var4.nextDouble() * 0.6D + 0.2D;
                  var1.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, var8, var10, var12, 0.0D, 0.0D, 0.0D);
                  ++var7;
                  "".length();
                  if (3 < 2) {
                     throw null;
                  }
               }

               var1.scheduleUpdate(var2, var1.getBlockState(var2).getBlock(), 16 + 91 - 50 + 103);
               "".length();
               if (1 >= 4) {
                  throw null;
               }
            }
         }
      } else if (!var5 && !this.isBurnedOut(var1, var2, (boolean)"".length())) {
         var1.setBlockState(var2, Blocks.REDSTONE_TORCH.getDefaultState().withProperty(FACING, var3.getValue(FACING)), "   ".length());
         I[150 ^ 132].length();
         I[43 ^ 56].length();
      }

   }

   public void randomTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
   }

   public int tickRate(World var1) {
      return "  ".length();
   }

   public boolean isAssociatedBlock(Block var1) {
      int var10000;
      if (var1 != Blocks.UNLIT_REDSTONE_TORCH && var1 != Blocks.REDSTONE_TORCH) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (4 < -1) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      if (this.isOn) {
         EnumFacing[] var4 = EnumFacing.values();
         int var5 = var4.length;
         int var6 = "".length();

         while(var6 < var5) {
            EnumFacing var7 = var4[var6];
            var1.notifyNeighborsOfStateChange(var2.offset(var7), this, (boolean)"".length());
            ++var6;
            "".length();
            if (-1 >= 4) {
               throw null;
            }
         }
      }

   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[183 ^ 174];
      String var10001 = I[218 ^ 192];
      String var10002 = I[167 ^ 188];
      var10001 = I[117 ^ 105];
      I[115 ^ 110].length();
      I[9 ^ 23].length();
      return new ItemStack(Blocks.REDSTONE_TORCH);
   }

   static class Toggle {
      // $FF: synthetic field
      BlockPos pos;
      // $FF: synthetic field
      long time;

      public Toggle(BlockPos var1, long var2) {
         this.pos = var1;
         this.time = var2;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 < 2);

         throw null;
      }
   }
}

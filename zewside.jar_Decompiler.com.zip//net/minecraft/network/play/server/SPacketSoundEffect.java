package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import org.apache.commons.lang3.Validate;

public class SPacketSoundEffect implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private float soundVolume;
   // $FF: synthetic field
   private int posX;
   // $FF: synthetic field
   private SoundEvent sound;
   // $FF: synthetic field
   private float soundPitch;
   // $FF: synthetic field
   private SoundCategory category;
   // $FF: synthetic field
   private int posZ;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int posY;

   public float getPitch() {
      return this.soundPitch;
   }

   static {
      I();
   }

   public double getY() {
      return (double)((float)this.posY / 8.0F);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != -1);

      throw null;
   }

   public double getZ() {
      return (double)((float)this.posZ / 8.0F);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(SoundEvent.REGISTRY.getIDForObject(this.sound));
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeEnumValue(this.category);
      I["   ".length()].length();
      I[42 ^ 46].length();
      I[62 ^ 59].length();
      I[51 ^ 53].length();
      I[46 ^ 41].length();
      var1.writeInt(this.posX);
      I[52 ^ 60].length();
      I[119 ^ 126].length();
      var1.writeInt(this.posY);
      I[3 ^ 9].length();
      I[125 ^ 118].length();
      I[64 ^ 76].length();
      I[132 ^ 137].length();
      var1.writeInt(this.posZ);
      I[188 ^ 178].length();
      I[155 ^ 148].length();
      I[143 ^ 159].length();
      I[90 ^ 75].length();
      I[81 ^ 67].length();
      var1.writeFloat(this.soundVolume);
      I[179 ^ 160].length();
      var1.writeFloat(this.soundPitch);
      I[111 ^ 123].length();
      I[214 ^ 195].length();
      I[83 ^ 69].length();
   }

   public SoundEvent getSound() {
      return this.sound;
   }

   public SoundCategory getCategory() {
      return this.category;
   }

   private static void I() {
      I = new String[175 ^ 184];
      I["".length()] = I("\u0019\u0004?##", "jkJMG");
      I[" ".length()] = I("嘫歁伵嚾扁", "AhwTv");
      I["  ".length()] = I("儿圓吓捄", "bJadf");
      I["   ".length()] = I("夤刼垓", "JHkhr");
      I[127 ^ 123] = I("涥櫐塉倁烠", "pHKAr");
      I[34 ^ 39] = I("橑攩厴惵懌", "yMyxi");
      I[68 ^ 66] = I("氌埽", "hrtDV");
      I[148 ^ 147] = I("栅榦格咿", "rAOek");
      I[136 ^ 128] = I("懣妢棇嫔", "jIlsU");
      I[131 ^ 138] = I("冠橼仜", "dwOyI");
      I[94 ^ 84] = I("灸嗩榁枟亘", "ieqbo");
      I[55 ^ 60] = I("媕慄", "FKNiA");
      I[20 ^ 24] = I("嶝灹", "cdluB");
      I[172 ^ 161] = I("佸暍", "bUCsx");
      I[162 ^ 172] = I("冸", "hAzGA");
      I[54 ^ 57] = I("帾嬵初湁", "XViDE");
      I[21 ^ 5] = I("割", "NDByG");
      I[186 ^ 171] = I("栲儇搗樏丼", "mlNwr");
      I[213 ^ 199] = I("埕槱圖烒潾", "mZkCJ");
      I[141 ^ 158] = I("毃嚖", "UgSPA");
      I[141 ^ 153] = I("悓焠攰", "WgWof");
      I[70 ^ 83] = I("擕慛亘涱", "tbDEh");
      I[5 ^ 19] = I("嵚夤氺丯", "uWBkp");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.sound = (SoundEvent)SoundEvent.REGISTRY.getObjectById(var1.readVarIntFromBuffer());
      this.category = (SoundCategory)var1.readEnumValue(SoundCategory.class);
      this.posX = var1.readInt();
      this.posY = var1.readInt();
      this.posZ = var1.readInt();
      this.soundVolume = var1.readFloat();
      this.soundPitch = var1.readFloat();
   }

   public SPacketSoundEffect() {
   }

   public float getVolume() {
      return this.soundVolume;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSoundEffect(this);
   }

   public double getX() {
      return (double)((float)this.posX / 8.0F);
   }

   public SPacketSoundEffect(SoundEvent var1, SoundCategory var2, double var3, double var5, double var7, float var9, float var10) {
      Validate.notNull(var1, I["".length()], new Object["".length()]);
      this.sound = var1;
      this.category = var2;
      this.posX = (int)(var3 * 8.0D);
      this.posY = (int)(var5 * 8.0D);
      this.posZ = (int)(var7 * 8.0D);
      this.soundVolume = var9;
      this.soundPitch = var10;
   }
}

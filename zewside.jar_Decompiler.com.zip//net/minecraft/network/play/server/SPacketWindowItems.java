package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.NonNullList;

public class SPacketWindowItems implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private List<ItemStack> itemStacks;
   // $FF: synthetic field
   private int windowId;
   // $FF: synthetic field
   private static final String[] I;

   public List<ItemStack> getItemStacks() {
      return this.itemStacks;
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 1);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleWindowItems(this);
   }

   public int getWindowId() {
      return this.windowId;
   }

   private static void I() {
      I = new String[114 ^ 121];
      I["".length()] = I("啃楽呃最昌", "sfCnY");
      I[" ".length()] = I("傡啴妄", "OwFko");
      I["  ".length()] = I("廉戍椲弢", "MVpvH");
      I["   ".length()] = I("槚朾呆咚", "Nedhh");
      I[61 ^ 57] = I("坋濛栿儝淎", "eHHUL");
      I[67 ^ 70] = I("奘愵坌懋垕", "EbGrG");
      I[6 ^ 0] = I("屩淆掍", "XImXh");
      I[14 ^ 9] = I("妣槎", "gKjoA");
      I[151 ^ 159] = I("休栚悟", "vyBSD");
      I[71 ^ 78] = I("妶毾", "yNeqU");
      I[186 ^ 176] = I("汳哉瀓妥滿", "WsoUe");
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.windowId);
      I[143 ^ 139].length();
      var1.writeShort(this.itemStacks.size());
      I[62 ^ 59].length();
      I[13 ^ 11].length();
      I[29 ^ 26].length();
      Iterator var2 = this.itemStacks.iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         ItemStack var3 = (ItemStack)var2.next();
         var1.writeItemStackToBuffer(var3);
         I[24 ^ 16].length();
         I[84 ^ 93].length();
         I[57 ^ 51].length();
         "".length();
      } while(true);

      throw null;
   }

   public SPacketWindowItems(int var1, NonNullList<ItemStack> var2) {
      this.windowId = var1;
      this.itemStacks = NonNullList.func_191197_a(var2.size(), ItemStack.field_190927_a);
      int var3 = "".length();

      do {
         if (var3 >= this.itemStacks.size()) {
            return;
         }

         ItemStack var4 = (ItemStack)var2.get(var3);
         this.itemStacks.set(var3, var4.copy());
         ++var3;
         "".length();
      } while(4 > 0);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.windowId = var1.readUnsignedByte();
      short var2 = var1.readShort();
      this.itemStacks = NonNullList.func_191197_a(var2, ItemStack.field_190927_a);
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            return;
         }

         this.itemStacks.set(var3, var1.readItemStackFromBuffer());
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
         ++var3;
         "".length();
      } while(4 >= 2);

      throw null;
   }

   public SPacketWindowItems() {
   }
}

package net.minecraft.block.properties;

import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Collections2;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.util.IStringSerializable;

public class PropertyEnum<T extends Enum<T> & IStringSerializable> extends PropertyHelper<T> {
   // $FF: synthetic field
   private final Map<String, T> nameToValue = Maps.newHashMap();
   // $FF: synthetic field
   private final ImmutableSet<T> allowedValues;
   // $FF: synthetic field
   private static final String[] I;

   public Collection<T> getAllowedValues() {
      return this.allowedValues;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)" ".length();
      } else if (var1 instanceof PropertyEnum && super.equals(var1)) {
         PropertyEnum var2 = (PropertyEnum)var1;
         int var10000;
         if (this.allowedValues.equals(var2.allowedValues) && this.nameToValue.equals(var2.nameToValue)) {
            var10000 = " ".length();
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      } else {
         return (boolean)"".length();
      }
   }

   private static void I() {
      I = new String[200 ^ 192];
      I["".length()] = I("\b\u0000 <\u00045\u0019)h\u001b$\u00199-\u001ee\u001d->\be\u0001$-M6\u0014!-M+\u0014!-Mb", "EuLHm");
      I[" ".length()] = I("t", "SNKcw");
      I["  ".length()] = I("匵掷", "FnPnG");
      I["   ".length()] = I("岖涜", "fyvki");
      I[126 ^ 122] = I("渨濛", "shylg");
      I[81 ^ 84] = I("塶娍", "RlcGG");
      I[149 ^ 147] = I("斡忐嶇", "DlGns");
      I[79 ^ 72] = I("挆柩傐", "wzqKo");
   }

   static {
      I();
   }

   public static <T extends Enum<T> & IStringSerializable> PropertyEnum<T> create(String var0, Class<T> var1, Predicate<T> var2) {
      return create(var0, var1, Collections2.filter(Lists.newArrayList(var1.getEnumConstants()), var2));
   }

   public static <T extends Enum<T> & IStringSerializable> PropertyEnum<T> create(String var0, Class<T> var1) {
      return create(var0, var1, Predicates.alwaysTrue());
   }

   public int hashCode() {
      int var1 = super.hashCode();
      var1 = (158 ^ 129) * var1 + this.allowedValues.hashCode();
      var1 = (102 ^ 121) * var1 + this.nameToValue.hashCode();
      return var1;
   }

   public String getName(T var1) {
      return ((IStringSerializable)var1).getName();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public Optional<T> parseValue(String var1) {
      return Optional.fromNullable(this.nameToValue.get(var1));
   }

   public static <T extends Enum<T> & IStringSerializable> PropertyEnum<T> create(String var0, Class<T> var1, T... var2) {
      return create(var0, var1, (Collection)Lists.newArrayList(var2));
   }

   public static <T extends Enum<T> & IStringSerializable> PropertyEnum<T> create(String var0, Class<T> var1, Collection<T> var2) {
      String var10000 = I["  ".length()];
      String var10001 = I["   ".length()];
      String var10002 = I[60 ^ 56];
      var10001 = I[40 ^ 45];
      I[187 ^ 189].length();
      I[105 ^ 110].length();
      return new PropertyEnum(var0, var1, var2);
   }

   protected PropertyEnum(String var1, Class<T> var2, Collection<T> var3) {
      super(var1, var2);
      this.allowedValues = ImmutableSet.copyOf(var3);
      Iterator var4 = var3.iterator();

      do {
         if (!var4.hasNext()) {
            return;
         }

         Enum var5 = (Enum)var4.next();
         String var6 = ((IStringSerializable)var5).getName();
         if (this.nameToValue.containsKey(var6)) {
            throw new IllegalArgumentException(I["".length()] + var6 + I[" ".length()]);
         }

         this.nameToValue.put(var6, var5);
         "".length();
      } while(true);

      throw null;
   }
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockStainedGlass extends BlockBreakable {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<EnumDyeColor> COLOR;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 4);

      throw null;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.TRANSLUCENT;
   }

   protected boolean canSilkHarvest() {
      return (boolean)" ".length();
   }

   public BlockStainedGlass(Material var1) {
      super(var1, (boolean)"".length());
      this.setDefaultState(this.blockState.getBaseState().withProperty(COLOR, EnumDyeColor.WHITE));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      EnumDyeColor[] var3 = EnumDyeColor.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         EnumDyeColor var6 = var3[var5];
         I[21 ^ 17].length();
         I[39 ^ 34].length();
         I[76 ^ 74].length();
         I[134 ^ 129].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[37 ^ 45].length();
         I[60 ^ 53].length();
         ++var5;
         "".length();
      } while(4 > -1);

      throw null;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(COLOR, EnumDyeColor.byMetadata(var1));
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[138 ^ 128];
      String var10001 = I[109 ^ 102];
      String var10002 = I[182 ^ 186];
      var10001 = I[205 ^ 192];
      var10000 = I[17 ^ 31];
      var10001 = I[10 ^ 5];
      var10002 = I[108 ^ 124];
      var10001 = I[10 ^ 27];
      I[172 ^ 190].length();
      I[170 ^ 185].length();
      I[164 ^ 176].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[142 ^ 155].length();
      I[139 ^ 157].length();
      I[138 ^ 157].length();
      I[79 ^ 87].length();
      var10003["".length()] = COLOR;
      return new BlockStateContainer(this, var10003);
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.func_193558_a((EnumDyeColor)var1.getValue(COLOR));
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   static {
      I();
      COLOR = PropertyEnum.create(I[159 ^ 134], EnumDyeColor.class);
   }

   private static void I() {
      I = new String[60 ^ 38];
      I["".length()] = I("慯淣", "nirxB");
      I[" ".length()] = I("唆洨", "ETCHU");
      I["  ".length()] = I("戣宭", "kEvFp");
      I["   ".length()] = I("朹形", "AWNOl");
      I[85 ^ 81] = I("炋歊", "YUqkF");
      I[0 ^ 5] = I("埤妷枒廻搋", "issee");
      I[57 ^ 63] = I("屚匱杒岄坜", "yhIsd");
      I[105 ^ 110] = I("朒啳", "YKVso");
      I[65 ^ 73] = I("悄八洒徰", "GeTcN");
      I[138 ^ 131] = I("伖汃", "bVdgD");
      I[141 ^ 135] = I("傣屝", "VnQOe");
      I[25 ^ 18] = I("唟曧", "ZaGaa");
      I[174 ^ 162] = I("寵瀫", "gPJfw");
      I[189 ^ 176] = I("捉漟", "OUfXx");
      I[47 ^ 33] = I("幀刍", "AZatt");
      I[88 ^ 87] = I("忠时", "BxBfK");
      I[104 ^ 120] = I("再湁", "sPMYe");
      I[63 ^ 46] = I("潶忶", "JWrqi");
      I[213 ^ 199] = I("桷侳敊沘", "wISeg");
      I[57 ^ 42] = I("偫", "Igcfm");
      I[181 ^ 161] = I("囗旜", "EggNb");
      I[36 ^ 49] = I("寂涶", "CooBm");
      I[128 ^ 150] = I("欥欴噒", "MnSRe");
      I[25 ^ 14] = I("夅埡卺刽", "THMBB");
      I[16 ^ 8] = I("劲滩氆忹埅", "lYmxX");
      I[154 ^ 131] = I("\u0015\u0004'.\u0014", "vkKAf");
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         BlockBeacon.updateColorAsync(var1, var2);
      }

   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(COLOR)).getMetadata();
   }

   public int damageDropped(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(COLOR)).getMetadata();
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         BlockBeacon.updateColorAsync(var1, var2);
      }

   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.World;

public class SPacketEntityStatus implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private byte logicOpcode;

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityStatus(this);
   }

   public SPacketEntityStatus() {
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readInt();
      this.logicOpcode = var1.readByte();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeInt(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeByte(this.logicOpcode);
      I["   ".length()].length();
      I[111 ^ 107].length();
      I[98 ^ 103].length();
      I[142 ^ 136].length();
      I[79 ^ 72].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   private static void I() {
      I = new String[59 ^ 51];
      I["".length()] = I("凔待埋厶", "eizrL");
      I[" ".length()] = I("匇檕歶", "ENgiU");
      I["  ".length()] = I("棲枵卯挮", "AzRKS");
      I["   ".length()] = I("椏扴", "yJGEe");
      I[76 ^ 72] = I("殺", "DvqTI");
      I[118 ^ 115] = I("槚洙晈噹惃", "rIQnX");
      I[181 ^ 179] = I("椿凑", "ZLOfl");
      I[0 ^ 7] = I("愺梌潨坟", "hemGe");
   }

   static {
      I();
   }

   public byte getOpCode() {
      return this.logicOpcode;
   }

   public Entity getEntity(World var1) {
      return var1.getEntityByID(this.entityId);
   }

   public SPacketEntityStatus(Entity var1, byte var2) {
      this.entityId = var1.getEntityId();
      this.logicOpcode = var2;
   }
}

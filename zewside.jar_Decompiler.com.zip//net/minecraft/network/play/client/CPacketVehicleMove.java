package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketVehicleMove implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private float yaw;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private float pitch;
   // $FF: synthetic field
   private double z;
   // $FF: synthetic field
   private double y;
   // $FF: synthetic field
   private double x;

   private static void I() {
      I = new String[89 ^ 80];
      I["".length()] = I("烃嫢尜刜", "aPnei");
      I[" ".length()] = I("榩溟", "sdNJT");
      I["  ".length()] = I("怳呗枭概", "hISQz");
      I["   ".length()] = I("晒塀", "bvmpl");
      I[36 ^ 32] = I("堞炭", "Tlfpx");
      I[7 ^ 2] = I("劃厙叧", "TOQHm");
      I[162 ^ 164] = I("凼伱晉償咨", "JnVgF");
      I[9 ^ 14] = I("敘撒尼", "ZgVke");
      I[34 ^ 42] = I("恬櫣徚漀", "UKpTO");
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeDouble(this.x);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeDouble(this.y);
      I["   ".length()].length();
      var1.writeDouble(this.z);
      I[14 ^ 10].length();
      I[67 ^ 70].length();
      var1.writeFloat(this.yaw);
      I[147 ^ 149].length();
      var1.writeFloat(this.pitch);
      I[198 ^ 193].length();
      I[113 ^ 121].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 1);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.x = var1.readDouble();
      this.y = var1.readDouble();
      this.z = var1.readDouble();
      this.yaw = var1.readFloat();
      this.pitch = var1.readFloat();
   }

   public double getX() {
      return this.x;
   }

   public double getY() {
      return this.y;
   }

   public float getPitch() {
      return this.pitch;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processVehicleMove(this);
   }

   public CPacketVehicleMove(Entity var1) {
      this.x = var1.posX;
      this.y = var1.posY;
      this.z = var1.posZ;
      this.yaw = var1.rotationYaw;
      this.pitch = var1.rotationPitch;
   }

   public CPacketVehicleMove() {
   }

   public double getZ() {
      return this.z;
   }

   static {
      I();
   }

   public float getYaw() {
      return this.yaw;
   }
}

package net.minecraft.network.status.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.status.INetHandlerStatusClient;

public class SPacketPong implements Packet<INetHandlerStatusClient> {
   // $FF: synthetic field
   private long clientTime;
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public SPacketPong(long var1) {
      this.clientTime = var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 4);

      throw null;
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("揚仿", "kYddq");
      I[" ".length()] = I("勍再", "aQeeY");
      I["  ".length()] = I("哎", "yVZWT");
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeLong(this.clientTime);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.clientTime = var1.readLong();
   }

   public void processPacket(INetHandlerStatusClient var1) {
      var1.handlePong(this);
   }

   public SPacketPong() {
   }
}

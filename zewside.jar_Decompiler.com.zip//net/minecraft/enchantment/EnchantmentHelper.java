package net.minecraft.enchantment;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemEnchantedBook;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Util;
import net.minecraft.util.WeightedRandom;
import net.minecraft.util.math.MathHelper;

public class EnchantmentHelper {
   // $FF: synthetic field
   private static final EnchantmentHelper.ModifierLiving ENCHANTMENT_MODIFIER_LIVING;
   // $FF: synthetic field
   private static final EnchantmentHelper.HurtIterator ENCHANTMENT_ITERATOR_HURT;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final EnchantmentHelper.DamageIterator ENCHANTMENT_ITERATOR_DAMAGE;
   // $FF: synthetic field
   private static final EnchantmentHelper.ModifierDamage ENCHANTMENT_MODIFIER_DAMAGE;

   static {
      I();
      ENCHANTMENT_MODIFIER_DAMAGE = new EnchantmentHelper.ModifierDamage();
      ENCHANTMENT_MODIFIER_LIVING = new EnchantmentHelper.ModifierLiving();
      ENCHANTMENT_ITERATOR_HURT = new EnchantmentHelper.HurtIterator();
      ENCHANTMENT_ITERATOR_DAMAGE = new EnchantmentHelper.DamageIterator();
   }

   public static List<EnchantmentData> getEnchantmentDatas(int var0, ItemStack var1, boolean var2) {
      String var10000 = I[50 ^ 3];
      String var10001 = I[6 ^ 52];
      String var10002 = I[147 ^ 160];
      var10001 = I[101 ^ 81];
      ArrayList var3 = Lists.newArrayList();
      Item var4 = var1.getItem();
      int var9;
      if (var1.getItem() == Items.BOOK) {
         var9 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var9 = "".length();
      }

      int var5 = var9;
      Iterator var6 = Enchantment.REGISTRY.iterator();

      do {
         if (!var6.hasNext()) {
            return var3;
         }

         Enchantment var7 = (Enchantment)var6.next();
         if ((!var7.isTreasureEnchantment() || var2) && (var7.type.canEnchantItem(var4) || var5 != 0)) {
            int var8 = var7.getMaxLevel();

            while(true) {
               int var10 = var7.getMinLevel();
               int var11 = " ".length();
               I[162 ^ 151].length();
               I[36 ^ 18].length();
               I[65 ^ 118].length();
               I[21 ^ 45].length();
               if (var8 <= var10 - var11) {
                  break;
               }

               if (var0 >= var7.getMinEnchantability(var8) && var0 <= var7.getMaxEnchantability(var8)) {
                  I[55 ^ 14].length();
                  I[34 ^ 24].length();
                  I[158 ^ 165].length();
                  var3.add(new EnchantmentData(var7, var8));
                  I[151 ^ 171].length();
                  I[161 ^ 156].length();
                  I[154 ^ 164].length();
                  I[44 ^ 19].length();
                  I[14 ^ 78].length();
                  "".length();
                  if (2 >= 4) {
                     throw null;
                  }
                  break;
               }

               --var8;
               "".length();
               if (3 < 2) {
                  throw null;
               }
            }
         }

         "".length();
      } while(1 > -1);

      throw null;
   }

   public static boolean hasFrostWalkerEnchantment(EntityLivingBase var0) {
      int var10000;
      if (getMaxEnchantmentLevel(Enchantments.FROST_WALKER, var0) > 0) {
         var10000 = " ".length();
         "".length();
         if (-1 < -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static int getFireAspectModifier(EntityLivingBase var0) {
      return getMaxEnchantmentLevel(Enchantments.FIRE_ASPECT, var0);
   }

   public static void applyThornEnchantments(EntityLivingBase var0, Entity var1) {
      ENCHANTMENT_ITERATOR_HURT.attacker = var1;
      ENCHANTMENT_ITERATOR_HURT.user = var0;
      if (var0 != null) {
         applyEnchantmentModifierArray(ENCHANTMENT_ITERATOR_HURT, var0.getEquipmentAndArmor());
      }

      if (var1 instanceof EntityPlayer) {
         applyEnchantmentModifier(ENCHANTMENT_ITERATOR_HURT, var0.getHeldItemMainhand());
      }

   }

   public static int func_191529_b(ItemStack var0) {
      return getEnchantmentLevel(Enchantments.LUCK_OF_THE_SEA, var0);
   }

   public static boolean func_190939_c(ItemStack var0) {
      int var10000;
      if (getEnchantmentLevel(Enchantments.field_190940_C, var0) > 0) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static int getEnchantmentModifierDamage(Iterable<ItemStack> var0, DamageSource var1) {
      ENCHANTMENT_MODIFIER_DAMAGE.damageModifier = "".length();
      ENCHANTMENT_MODIFIER_DAMAGE.source = var1;
      applyEnchantmentModifierArray(ENCHANTMENT_MODIFIER_DAMAGE, var0);
      return ENCHANTMENT_MODIFIER_DAMAGE.damageModifier;
   }

   public static float func_191527_a(EntityLivingBase var0) {
      int var1 = getMaxEnchantmentLevel(Enchantments.field_191530_r, var0);
      float var10000;
      if (var1 > 0) {
         var10000 = EnchantmentSweepingEdge.func_191526_e(var1);
         "".length();
         if (-1 >= 1) {
            throw null;
         }
      } else {
         var10000 = 0.0F;
      }

      return var10000;
   }

   public static boolean getAquaAffinityModifier(EntityLivingBase var0) {
      int var10000;
      if (getMaxEnchantmentLevel(Enchantments.AQUA_AFFINITY, var0) > 0) {
         var10000 = " ".length();
         "".length();
         if (1 <= -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static int getEnchantmentLevel(Enchantment var0, ItemStack var1) {
      if (var1.isEmpty()) {
         return "".length();
      } else {
         NBTTagList var2 = var1.getEnchantmentTagList();
         int var3 = "".length();

         do {
            if (var3 >= var2.tagCount()) {
               return "".length();
            }

            NBTTagCompound var4 = var2.getCompoundTagAt(var3);
            Enchantment var5 = Enchantment.getEnchantmentByID(var4.getShort(I["".length()]));
            short var6 = var4.getShort(I[" ".length()]);
            if (var5 == var0) {
               return var6;
            }

            ++var3;
            "".length();
         } while(3 > -1);

         throw null;
      }
   }

   public static int calcItemStackEnchantability(Random var0, int var1, int var2, ItemStack var3) {
      Item var4 = var3.getItem();
      int var5 = var4.getItemEnchantability();
      if (var5 <= 0) {
         return "".length();
      } else {
         if (var2 > (72 ^ 71)) {
            var2 = 176 ^ 191;
         }

         int var6 = var0.nextInt(161 ^ 169) + " ".length() + (var2 >> " ".length()) + var0.nextInt(var2 + " ".length());
         if (var1 == 0) {
            return Math.max(var6 / "   ".length(), " ".length());
         } else {
            int var10000;
            if (var1 == " ".length()) {
               var10000 = var6 * "  ".length() / "   ".length() + " ".length();
               "".length();
               if (2 != 2) {
                  throw null;
               }
            } else {
               var10000 = Math.max(var6, var2 * "  ".length());
            }

            return var10000;
         }
      }
   }

   public static void setEnchantments(Map<Enchantment, Integer> var0, ItemStack var1) {
      String var10000 = I[11 ^ 12];
      String var10001 = I[26 ^ 18];
      String var10002 = I[53 ^ 60];
      var10001 = I[53 ^ 63];
      var10000 = I[180 ^ 191];
      var10001 = I[61 ^ 49];
      var10002 = I[118 ^ 123];
      var10001 = I[106 ^ 100];
      var10000 = I[187 ^ 180];
      var10001 = I[140 ^ 156];
      var10002 = I[141 ^ 156];
      var10001 = I[191 ^ 173];
      I[117 ^ 102].length();
      I[94 ^ 74].length();
      I[36 ^ 49].length();
      I[62 ^ 40].length();
      I[107 ^ 124].length();
      NBTTagList var2 = new NBTTagList();
      Iterator var3 = var0.entrySet().iterator();

      do {
         if (!var3.hasNext()) {
            if (var2.hasNoTags()) {
               if (var1.hasTagCompound()) {
                  var1.getTagCompound().removeTag(I[84 ^ 75]);
                  "".length();
                  if (2 >= 3) {
                     throw null;
                  }
               }
            } else if (var1.getItem() != Items.ENCHANTED_BOOK) {
               var1.setTagInfo(I[97 ^ 65], var2);
            }

            return;
         }

         Entry var4 = (Entry)var3.next();
         Enchantment var5 = (Enchantment)var4.getKey();
         if (var5 != null) {
            int var6 = (Integer)var4.getValue();
            I[191 ^ 167].length();
            I[163 ^ 186].length();
            NBTTagCompound var7 = new NBTTagCompound();
            var7.setShort(I[101 ^ 127], (short)Enchantment.getEnchantmentID(var5));
            var7.setShort(I[38 ^ 61], (short)var6);
            var2.appendTag(var7);
            if (var1.getItem() == Items.ENCHANTED_BOOK) {
               I[216 ^ 196].length();
               I[183 ^ 170].length();
               I[132 ^ 154].length();
               ItemEnchantedBook.addEnchantment(var1, new EnchantmentData(var5, var6));
            }
         }

         "".length();
      } while(-1 >= -1);

      throw null;
   }

   public static ItemStack addRandomEnchantment(Random var0, ItemStack var1, int var2, boolean var3) {
      String var10000 = I[178 ^ 150];
      String var10001 = I[159 ^ 186];
      String var10002 = I[116 ^ 82];
      var10001 = I[187 ^ 156];
      List var4 = buildEnchantmentList(var0, var1, var2, var3);
      int var8;
      if (var1.getItem() == Items.BOOK) {
         var8 = " ".length();
         "".length();
         if (1 <= -1) {
            throw null;
         }
      } else {
         var8 = "".length();
      }

      int var5 = var8;
      if (var5 != 0) {
         I[27 ^ 51].length();
         I[21 ^ 60].length();
         var1 = new ItemStack(Items.ENCHANTED_BOOK);
      }

      Iterator var6 = var4.iterator();

      do {
         if (!var6.hasNext()) {
            return var1;
         }

         EnchantmentData var7 = (EnchantmentData)var6.next();
         if (var5 != 0) {
            ItemEnchantedBook.addEnchantment(var1, var7);
            "".length();
            if (3 != 3) {
               throw null;
            }
         } else {
            var1.addEnchantment(var7.enchantmentobj, var7.enchantmentLevel);
         }

         "".length();
      } while(2 >= 0);

      throw null;
   }

   public static int getKnockbackModifier(EntityLivingBase var0) {
      return getMaxEnchantmentLevel(Enchantments.KNOCKBACK, var0);
   }

   public static int getLootingModifier(EntityLivingBase var0) {
      return getMaxEnchantmentLevel(Enchantments.LOOTING, var0);
   }

   public static int func_191528_c(ItemStack var0) {
      return getEnchantmentLevel(Enchantments.LURE, var0);
   }

   public static int getRespirationModifier(EntityLivingBase var0) {
      return getMaxEnchantmentLevel(Enchantments.RESPIRATION, var0);
   }

   public static int getEfficiencyModifier(EntityLivingBase var0) {
      return getMaxEnchantmentLevel(Enchantments.EFFICIENCY, var0);
   }

   public static int getDepthStriderModifier(EntityLivingBase var0) {
      return getMaxEnchantmentLevel(Enchantments.DEPTH_STRIDER, var0);
   }

   public static ItemStack getEnchantedItem(Enchantment var0, EntityLivingBase var1) {
      List var2 = var0.getEntityEquipment(var1);
      if (var2.isEmpty()) {
         return ItemStack.field_190927_a;
      } else {
         ArrayList var3 = Lists.newArrayList();
         Iterator var4 = var2.iterator();

         do {
            if (!var4.hasNext()) {
               ItemStack var10000;
               if (var3.isEmpty()) {
                  var10000 = ItemStack.field_190927_a;
                  "".length();
                  if (-1 >= 3) {
                     throw null;
                  }
               } else {
                  var10000 = (ItemStack)var3.get(var1.getRNG().nextInt(var3.size()));
               }

               return var10000;
            }

            ItemStack var5 = (ItemStack)var4.next();
            if (!var5.isEmpty() && getEnchantmentLevel(var0, var5) > 0) {
               var3.add(var5);
               I[5 ^ 38].length();
            }

            "".length();
         } while(true);

         throw null;
      }
   }

   public static Map<Enchantment, Integer> getEnchantments(ItemStack var0) {
      LinkedHashMap var1 = Maps.newLinkedHashMap();
      NBTTagList var10000;
      if (var0.getItem() == Items.ENCHANTED_BOOK) {
         var10000 = ItemEnchantedBook.getEnchantments(var0);
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var10000 = var0.getEnchantmentTagList();
      }

      NBTTagList var2 = var10000;
      int var3 = "".length();

      do {
         if (var3 >= var2.tagCount()) {
            return var1;
         }

         NBTTagCompound var4 = var2.getCompoundTagAt(var3);
         Enchantment var5 = Enchantment.getEnchantmentByID(var4.getShort(I["  ".length()]));
         short var6 = var4.getShort(I["   ".length()]);
         var1.put(var5, Integer.valueOf(var6));
         I[1 ^ 5].length();
         I[186 ^ 191].length();
         I[84 ^ 82].length();
         ++var3;
         "".length();
      } while(1 > -1);

      throw null;
   }

   private static void I() {
      I = new String[62 ^ 127];
      I["".length()] = I(";\u0016", "RrVfI");
      I[" ".length()] = I("\u001d<\u0004", "qJhSp");
      I["  ".length()] = I(": ", "SDzUz");
      I["   ".length()] = I("=\u0015;", "QcWrn");
      I[142 ^ 138] = I("圃唯", "XWhFf");
      I[126 ^ 123] = I("奥栆", "caDOQ");
      I[1 ^ 7] = I("佽", "FZqAz");
      I[161 ^ 166] = I("佖哐", "ImPqX");
      I[47 ^ 39] = I("弁沨", "AfxtI");
      I[143 ^ 134] = I("娱洏", "kpbPn");
      I[107 ^ 97] = I("暂嚦", "Jhheb");
      I[181 ^ 190] = I("漴副", "Egefe");
      I[172 ^ 160] = I("杧湰", "rrLKn");
      I[187 ^ 182] = I("染埫", "HPzyi");
      I[131 ^ 141] = I("或瀞", "qwdmF");
      I[55 ^ 56] = I("嵼哩", "uIPLa");
      I[61 ^ 45] = I("傏崱", "mgjXn");
      I[99 ^ 114] = I("歖煋", "AmjPw");
      I[13 ^ 31] = I("曚崍", "xCrun");
      I[93 ^ 78] = I("峮枍囂塉巓", "kSSjx");
      I[4 ^ 16] = I("並楻炑", "CtSTn");
      I[214 ^ 195] = I("朞煟", "zwHqf");
      I[146 ^ 132] = I("徝伎出坬厒", "ZUvXv");
      I[11 ^ 28] = I("嬤", "Bcqbn");
      I[76 ^ 84] = I("刜栐", "wxiME");
      I[159 ^ 134] = I("梛敓搨", "dtrlW");
      I[13 ^ 23] = I("/=", "FYZGJ");
      I[48 ^ 43] = I("&\u001d\u001d", "JkqFK");
      I[0 ^ 28] = I("梓林拣榜", "DKFOw");
      I[15 ^ 18] = I("圉", "xzzEf");
      I[88 ^ 70] = I("揤墑坼樽弋", "eYCvo");
      I[111 ^ 112] = I("&\u001b*\u001a", "CuIrQ");
      I[114 ^ 82] = I("6>\u0004*", "SPgBE");
      I[96 ^ 65] = I("#-", "JIhBr");
      I[191 ^ 157] = I("\u000f<\u001d", "cJqIZ");
      I[119 ^ 84] = I("渢", "ruWON");
      I[84 ^ 112] = I("唠来", "YQOJr");
      I[190 ^ 155] = I("京傼", "otObs");
      I[137 ^ 175] = I("姷卓", "ffThX");
      I[27 ^ 60] = I("慇樥", "lpsPk");
      I[126 ^ 86] = I("滺改侲", "SBSew");
      I[68 ^ 109] = I("姟屈浂塴", "Dqget");
      I[135 ^ 173] = I("伌嘃扆偰", "QvTLQ");
      I[170 ^ 129] = I("杈唬", "qyRvz");
      I[140 ^ 160] = I("喿挴", "CRNra");
      I[52 ^ 25] = I("怙潲", "sZmYV");
      I[123 ^ 85] = I("咵拶枆彁", "BBfqt");
      I[5 ^ 42] = I("挺嘓殩", "jkpjd");
      I[131 ^ 179] = I("檲", "SQlZK");
      I[134 ^ 183] = I("棿巛", "iMAWR");
      I[37 ^ 23] = I("丄欹", "xcYRO");
      I[70 ^ 117] = I("搟煣", "Rcfvi");
      I[153 ^ 173] = I("媧廩", "UfXls");
      I[100 ^ 81] = I("毉恧", "ArrmZ");
      I[128 ^ 182] = I("呋怷", "BhDJN");
      I[50 ^ 5] = I("咭擇俢", "bUMdD");
      I[142 ^ 182] = I("栏", "oeArH");
      I[84 ^ 109] = I("劂敎俓", "Kmttr");
      I[32 ^ 26] = I("懑憱", "SDBTR");
      I[55 ^ 12] = I("堼", "XVMOt");
      I[179 ^ 143] = I("妱", "vzoMt");
      I[142 ^ 179] = I("俫剕倇埯", "BgZNS");
      I[72 ^ 118] = I("橺叔抺亀濇", "MKdOq");
      I[5 ^ 58] = I("椫哪嶤", "bjrVB");
      I[101 ^ 37] = I("妪揤", "BcnXb");
   }

   private static void applyEnchantmentModifierArray(EnchantmentHelper.IModifier var0, Iterable<ItemStack> var1) {
      Iterator var2 = var1.iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         ItemStack var3 = (ItemStack)var2.next();
         applyEnchantmentModifier(var0, var3);
         "".length();
      } while(3 != 2);

      throw null;
   }

   public static float getModifierForCreature(ItemStack var0, EnumCreatureAttribute var1) {
      ENCHANTMENT_MODIFIER_LIVING.livingModifier = 0.0F;
      ENCHANTMENT_MODIFIER_LIVING.entityLiving = var1;
      applyEnchantmentModifier(ENCHANTMENT_MODIFIER_LIVING, var0);
      return ENCHANTMENT_MODIFIER_LIVING.livingModifier;
   }

   public static int getMaxEnchantmentLevel(Enchantment var0, EntityLivingBase var1) {
      List var2 = var0.getEntityEquipment(var1);
      if (var2 == null) {
         return "".length();
      } else {
         int var3 = "".length();
         Iterator var4 = var2.iterator();

         do {
            if (!var4.hasNext()) {
               return var3;
            }

            ItemStack var5 = (ItemStack)var4.next();
            int var6 = getEnchantmentLevel(var0, var5);
            if (var6 > var3) {
               var3 = var6;
            }

            "".length();
         } while(1 < 4);

         throw null;
      }
   }

   public static void applyArthropodEnchantments(EntityLivingBase var0, Entity var1) {
      ENCHANTMENT_ITERATOR_DAMAGE.user = var0;
      ENCHANTMENT_ITERATOR_DAMAGE.target = var1;
      if (var0 != null) {
         applyEnchantmentModifierArray(ENCHANTMENT_ITERATOR_DAMAGE, var0.getEquipmentAndArmor());
      }

      if (var0 instanceof EntityPlayer) {
         applyEnchantmentModifier(ENCHANTMENT_ITERATOR_DAMAGE, var0.getHeldItemMainhand());
      }

   }

   public static boolean func_190938_b(ItemStack var0) {
      int var10000;
      if (getEnchantmentLevel(Enchantments.field_190941_k, var0) > 0) {
         var10000 = " ".length();
         "".length();
         if (-1 == 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static List<EnchantmentData> buildEnchantmentList(Random var0, ItemStack var1, int var2, boolean var3) {
      ArrayList var4 = Lists.newArrayList();
      Item var5 = var1.getItem();
      int var6 = var5.getItemEnchantability();
      if (var6 <= 0) {
         return var4;
      } else {
         var2 = var2 + " ".length() + var0.nextInt(var6 / (184 ^ 188) + " ".length()) + var0.nextInt(var6 / (46 ^ 42) + " ".length());
         float var10000 = var0.nextFloat() + var0.nextFloat();
         I[102 ^ 76].length();
         I[86 ^ 125].length();
         float var7 = (var10000 - 1.0F) * 0.15F;
         var2 = MathHelper.clamp(Math.round((float)var2 + (float)var2 * var7), " ".length(), 179923581 + 697739222 - 850767407 + 2120588251);
         List var8 = getEnchantmentDatas(var2, var1, var3);
         if (!var8.isEmpty()) {
            var4.add(WeightedRandom.getRandomItem(var0, var8));
            I[1 ^ 45].length();
            I[149 ^ 184].length();
            I[62 ^ 16].length();

            while(var0.nextInt(120 ^ 74) <= var2) {
               removeIncompatible(var8, (EnchantmentData)Util.getLastElement(var4));
               if (var8.isEmpty()) {
                  "".length();
                  if (1 >= 4) {
                     throw null;
                  }
                  break;
               }

               var4.add(WeightedRandom.getRandomItem(var0, var8));
               I[51 ^ 28].length();
               I[164 ^ 148].length();
               var2 /= "  ".length();
               "".length();
               if (1 == 4) {
                  throw null;
               }
            }
         }

         return var4;
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   private static void applyEnchantmentModifier(EnchantmentHelper.IModifier var0, ItemStack var1) {
      if (!var1.isEmpty()) {
         NBTTagList var2 = var1.getEnchantmentTagList();
         int var3 = "".length();

         while(var3 < var2.tagCount()) {
            short var4 = var2.getCompoundTagAt(var3).getShort(I[120 ^ 89]);
            short var5 = var2.getCompoundTagAt(var3).getShort(I[104 ^ 74]);
            if (Enchantment.getEnchantmentByID(var4) != null) {
               var0.calculateModifier(Enchantment.getEnchantmentByID(var4), var5);
            }

            ++var3;
            "".length();
            if (false) {
               throw null;
            }
         }
      }

   }

   public static void removeIncompatible(List<EnchantmentData> var0, EnchantmentData var1) {
      Iterator var2 = var0.iterator();

      while(var2.hasNext()) {
         if (!var1.enchantmentobj.func_191560_c(((EnchantmentData)var2.next()).enchantmentobj)) {
            var2.remove();
            "".length();
            if (4 < 1) {
               throw null;
            }
         }
      }

   }

   static final class DamageIterator implements EnchantmentHelper.IModifier {
      // $FF: synthetic field
      public Entity target;
      // $FF: synthetic field
      public EntityLivingBase user;

      public void calculateModifier(Enchantment var1, int var2) {
         var1.onEntityDamaged(this.user, this.target, var2);
      }

      // $FF: synthetic method
      DamageIterator(Object var1) {
         this();
      }

      private DamageIterator() {
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 > 2);

         throw null;
      }
   }

   static final class ModifierLiving implements EnchantmentHelper.IModifier {
      // $FF: synthetic field
      public EnumCreatureAttribute entityLiving;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      public float livingModifier;

      // $FF: synthetic method
      ModifierLiving(Object var1) {
         this();
      }

      private ModifierLiving() {
      }

      public void calculateModifier(Enchantment var1, int var2) {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         I[81 ^ 85].length();
         I[77 ^ 72].length();
         this.livingModifier += var1.calcDamageByCreature(var2, this.entityLiving);
      }

      static {
         I();
      }

      private static void I() {
         I = new String[131 ^ 133];
         I["".length()] = I("沧昸", "ArJFD");
         I[" ".length()] = I("弽埍", "dOonY");
         I["  ".length()] = I("湦夯", "bbHJy");
         I["   ".length()] = I("坈徕", "BMjnD");
         I[31 ^ 27] = I("嵁樘徥俛", "NOYvZ");
         I[45 ^ 40] = I("桜", "SzYuE");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 >= 0);

         throw null;
      }
   }

   static final class ModifierDamage implements EnchantmentHelper.IModifier {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      public DamageSource source;
      // $FF: synthetic field
      public int damageModifier;

      private static void I() {
         I = new String[36 ^ 34];
         I["".length()] = I("岴夘", "Qiehk");
         I[" ".length()] = I("储丿", "lwdHs");
         I["  ".length()] = I("傏佥", "mochO");
         I["   ".length()] = I("澋汍", "xOkOL");
         I[155 ^ 159] = I("宴改巔嶪", "lgWhd");
         I[54 ^ 51] = I("垽前", "lOkrx");
      }

      static {
         I();
      }

      // $FF: synthetic method
      ModifierDamage(Object var1) {
         this();
      }

      private ModifierDamage() {
      }

      public void calculateModifier(Enchantment var1, int var2) {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         I[18 ^ 22].length();
         I[115 ^ 118].length();
         this.damageModifier += var1.calcModifierDamage(var2, this.source);
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > 2);

         throw null;
      }
   }

   interface IModifier {
      void calculateModifier(Enchantment var1, int var2);
   }

   static final class HurtIterator implements EnchantmentHelper.IModifier {
      // $FF: synthetic field
      public Entity attacker;
      // $FF: synthetic field
      public EntityLivingBase user;

      // $FF: synthetic method
      HurtIterator(Object var1) {
         this();
      }

      private HurtIterator() {
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 >= -1);

         throw null;
      }

      public void calculateModifier(Enchantment var1, int var2) {
         var1.onUserHurt(this.user, this.attacker, var2);
      }
   }
}

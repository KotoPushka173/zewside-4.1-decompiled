package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class RecipeUnlockedTrigger implements ICriterionTrigger<RecipeUnlockedTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_192227_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, RecipeUnlockedTrigger.Listeners> field_192228_b = Maps.newHashMap();

   public void func_192225_a(EntityPlayerMP var1, IRecipe var2) {
      RecipeUnlockedTrigger.Listeners var3 = (RecipeUnlockedTrigger.Listeners)this.field_192228_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_193493_a(var2);
      }

   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<RecipeUnlockedTrigger.Instance> var2) {
      RecipeUnlockedTrigger.Listeners var3 = (RecipeUnlockedTrigger.Listeners)this.field_192228_b.get(var1);
      if (var3 != null) {
         var3.func_192525_b(var2);
         if (var3.func_192527_a()) {
            this.field_192228_b.remove(var1);
            I[120 ^ 127].length();
            I[33 ^ 41].length();
         }
      }

   }

   public RecipeUnlockedTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[132 ^ 142];
      String var10001 = I[168 ^ 163];
      String var10002 = I[14 ^ 2];
      var10001 = I[90 ^ 87];
      var10000 = I[124 ^ 114];
      var10001 = I[51 ^ 60];
      var10002 = I[56 ^ 40];
      var10001 = I[133 ^ 148];
      var10000 = I[114 ^ 96];
      var10001 = I[133 ^ 150];
      var10002 = I[40 ^ 60];
      var10001 = I[101 ^ 112];
      var10000 = I[50 ^ 36];
      var10001 = I[82 ^ 69];
      var10002 = I[79 ^ 87];
      var10001 = I[37 ^ 60];
      I[114 ^ 104].length();
      I[164 ^ 191].length();
      I[75 ^ 87].length();
      ResourceLocation var3 = new ResourceLocation(JsonUtils.getString(var1, I[175 ^ 178]));
      IRecipe var4 = CraftingManager.func_193373_a(var3);
      if (var4 == null) {
         I[160 ^ 190].length();
         I[181 ^ 170].length();
         I[121 ^ 89].length();
         I[104 ^ 73].length();
         I[134 ^ 164].length();
         JsonSyntaxException var5 = new JsonSyntaxException(I[56 ^ 27] + var3 + I[44 ^ 8]);
         I[83 ^ 118].length();
         I[51 ^ 21].length();
         I[227 ^ 196].length();
         throw var5;
      } else {
         I[163 ^ 139].length();
         I[141 ^ 164].length();
         I[9 ^ 35].length();
         I[26 ^ 49].length();
         return new RecipeUnlockedTrigger.Instance(var4);
      }
   }

   static {
      I();
      field_192227_a = new ResourceLocation(I[65 ^ 109]);
   }

   private static void I() {
      I = new String[92 ^ 113];
      I["".length()] = I("極奟", "TVSeQ");
      I[" ".length()] = I("構干", "KHsZj");
      I["  ".length()] = I("憆洞", "CPgOl");
      I["   ".length()] = I("周嵹", "NTbQW");
      I[167 ^ 163] = I("挈掬倿檷囏", "MNVfp");
      I[69 ^ 64] = I("橛", "pHotN");
      I[32 ^ 38] = I("毆壒息岈", "croOV");
      I[75 ^ 76] = I("嘳婩嚱儢", "mXGbF");
      I[169 ^ 161] = I("瀴戊", "sFkkB");
      I[107 ^ 98] = I("嗙壘娬歽", "JtMXN");
      I[189 ^ 183] = I("氡波", "Sdfvq");
      I[53 ^ 62] = I("灃偾", "JgBOA");
      I[118 ^ 122] = I("嚊啋", "xNlrv");
      I[127 ^ 114] = I("匃弻", "KrAKv");
      I[13 ^ 3] = I("椝冨", "zMpEq");
      I[35 ^ 44] = I("岽曺", "gPHCH");
      I[9 ^ 25] = I("媨愿", "OocQc");
      I[88 ^ 73] = I("悧滁", "KzXNS");
      I[170 ^ 184] = I("偏夰", "qeQkN");
      I[69 ^ 86] = I("枆屭", "ikdDZ");
      I[149 ^ 129] = I("嫦潉", "SaYGu");
      I[49 ^ 36] = I("枣漊", "SScYr");
      I[3 ^ 21] = I("厫喉", "mNCAn");
      I[191 ^ 168] = I("挏撋", "DUfua");
      I[145 ^ 137] = I("敉妯", "zWElu");
      I[130 ^ 155] = I("姶撡", "pdNTW");
      I[52 ^ 46] = I("煑瀛德厲", "xUPmm");
      I[1 ^ 26] = I("曧梑入主妽", "HSgeT");
      I[121 ^ 101] = I("憳敼", "yDbje");
      I[115 ^ 110] = I("8\u0004+\u0018?/", "JaHqO");
      I[188 ^ 162] = I("因板扢擏掔", "EiKEA");
      I[154 ^ 133] = I("枋儔", "lUFBn");
      I[9 ^ 41] = I("双炧榪", "ojKhQ");
      I[159 ^ 190] = I("婒", "VpDNW");
      I[76 ^ 110] = I("冉杨剅宖嶱", "yuRDj");
      I[158 ^ 189] = I("\u0017%\u0001\u001675%J\n=!\"\u001a\u001dxe", "BKjxX");
      I[172 ^ 136] = I("k", "LCNrm");
      I[112 ^ 85] = I("匊潸擻廾", "sYmiL");
      I[60 ^ 26] = I("歹摮亩", "sHMLJ");
      I[33 ^ 6] = I("栤", "kKrBS");
      I[67 ^ 107] = I("憗", "bRNzO");
      I[170 ^ 131] = I("揶廊桠", "wQTim");
      I[35 ^ 9] = I("敛岧", "drDIV");
      I[183 ^ 156] = I("嚗", "oLquZ");
      I[170 ^ 134] = I("\u0011\u000b:(\"\u00061,/>\f\r2$6", "cnYAR");
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<RecipeUnlockedTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      RecipeUnlockedTrigger.Listeners var3 = (RecipeUnlockedTrigger.Listeners)this.field_192228_b.get(var1);
      if (var3 == null) {
         I[35 ^ 39].length();
         var3 = new RecipeUnlockedTrigger.Listeners(var1);
         this.field_192228_b.put(var1, var3);
         I[68 ^ 65].length();
         I[22 ^ 16].length();
      }

      var3.func_192528_a(var2);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 3);

      throw null;
   }

   public ResourceLocation func_192163_a() {
      return field_192227_a;
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192228_b.remove(var1);
      I[81 ^ 88].length();
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final IRecipe field_192282_a;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 < 4);

         throw null;
      }

      public boolean func_193215_a(IRecipe var1) {
         int var10000;
         if (this.field_192282_a == var1) {
            var10000 = " ".length();
            "".length();
            if (1 >= 2) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }

      public Instance(IRecipe var1) {
         super(RecipeUnlockedTrigger.field_192227_a);
         this.field_192282_a = var1;
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<RecipeUnlockedTrigger.Instance>> field_192530_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_192529_a;

      private static void I() {
         I = new String[140 ^ 132];
         I["".length()] = I("塸僧", "QGYMA");
         I[" ".length()] = I("櫷恍椏噓傲", "RtxIB");
         I["  ".length()] = I("为洅梾渲庐", "LhmRD");
         I["   ".length()] = I("帗嶫灾朇", "hZxwM");
         I[70 ^ 66] = I("束渟孼埼寘", "SnZyd");
         I[194 ^ 199] = I("槤樾", "cwVke");
         I[24 ^ 30] = I("栩", "gAMFe");
         I[83 ^ 84] = I("拙悱梭", "bkJgQ");
      }

      public void func_193493_a(IRecipe var1) {
         ArrayList var2 = null;
         Iterator var3 = this.field_192530_b.iterator();

         ICriterionTrigger.Listener var4;
         while(var3.hasNext()) {
            var4 = (ICriterionTrigger.Listener)var3.next();
            if (((RecipeUnlockedTrigger.Instance)var4.func_192158_a()).func_193215_a(var1)) {
               if (var2 == null) {
                  var2 = Lists.newArrayList();
               }

               var2.add(var4);
               I[7 ^ 1].length();
               I[143 ^ 136].length();
            }

            "".length();
            if (2 < 1) {
               throw null;
            }
         }

         if (var2 != null) {
            var3 = var2.iterator();

            while(var3.hasNext()) {
               var4 = (ICriterionTrigger.Listener)var3.next();
               var4.func_192159_a(this.field_192529_a);
               "".length();
               if (2 == -1) {
                  throw null;
               }
            }
         }

      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 != 2);

         throw null;
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192529_a = var1;
      }

      public boolean func_192527_a() {
         return this.field_192530_b.isEmpty();
      }

      static {
         I();
      }

      public void func_192525_b(ICriterionTrigger.Listener<RecipeUnlockedTrigger.Instance> var1) {
         this.field_192530_b.remove(var1);
         I["   ".length()].length();
         I[127 ^ 123].length();
         I[163 ^ 166].length();
      }

      public void func_192528_a(ICriterionTrigger.Listener<RecipeUnlockedTrigger.Instance> var1) {
         this.field_192530_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }
   }
}

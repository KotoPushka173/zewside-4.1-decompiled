package net.minecraft.stats;

public interface IStatType {
   String format(int var1);
}

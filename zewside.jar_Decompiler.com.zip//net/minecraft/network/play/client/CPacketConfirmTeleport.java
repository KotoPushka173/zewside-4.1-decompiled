package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketConfirmTeleport implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private int telportId;
   // $FF: synthetic field
   private static final String[] I;

   public CPacketConfirmTeleport() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.telportId);
      I["".length()].length();
      I[" ".length()].length();
   }

   public CPacketConfirmTeleport(int var1) {
      this.telportId = var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 1);

      throw null;
   }

   static {
      I();
   }

   private static void I() {
      I = new String["  ".length()];
      I["".length()] = I("儕", "SCvLt");
      I[" ".length()] = I("俷歉唎櫺", "CprbQ");
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processConfirmTeleport(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.telportId = var1.readVarIntFromBuffer();
   }

   public int getTeleportId() {
      return this.telportId;
   }
}

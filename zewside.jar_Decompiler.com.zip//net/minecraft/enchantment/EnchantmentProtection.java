package net.minecraft.enchantment;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.MathHelper;

public class EnchantmentProtection extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public final EnchantmentProtection.Type protectionType;

   public int calcModifierDamage(int var1, DamageSource var2) {
      if (var2.canHarmInCreative()) {
         return "".length();
      } else if (this.protectionType == EnchantmentProtection.Type.ALL) {
         return var1;
      } else if (this.protectionType == EnchantmentProtection.Type.FIRE && var2.isFireDamage()) {
         return var1 * "  ".length();
      } else if (this.protectionType == EnchantmentProtection.Type.FALL && var2 == DamageSource.fall) {
         return var1 * "   ".length();
      } else if (this.protectionType == EnchantmentProtection.Type.EXPLOSION && var2.isExplosion()) {
         return var1 * "  ".length();
      } else {
         int var10000;
         if (this.protectionType == EnchantmentProtection.Type.PROJECTILE && var2.isProjectile()) {
            var10000 = var1 * "  ".length();
            "".length();
            if (1 <= 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return var10000;
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 4);

      throw null;
   }

   public boolean canApplyTogether(Enchantment var1) {
      if (var1 instanceof EnchantmentProtection) {
         EnchantmentProtection var2 = (EnchantmentProtection)var1;
         if (this.protectionType == var2.protectionType) {
            return (boolean)"".length();
         } else {
            int var10000;
            if (this.protectionType != EnchantmentProtection.Type.FALL && var2.protectionType != EnchantmentProtection.Type.FALL) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            }

            return (boolean)var10000;
         }
      } else {
         return super.canApplyTogether(var1);
      }
   }

   private static void I() {
      I = new String[39 ^ 55];
      I["".length()] = I("兵朂圸", "RcyYa");
      I[" ".length()] = I("歰壦", "FWlDd");
      I["  ".length()] = I("弦峢", "CBkHT");
      I["   ".length()] = I("塨槝", "OBlsh");
      I[10 ^ 14] = I("帞濠", "lAbbR");
      I[36 ^ 33] = I("嘩氒巧", "NAUbI");
      I[84 ^ 82] = I("哦捷塨", "SeWHC");
      I[98 ^ 101] = I(",'6%\u0002'=8(\r=g%?\f=,69M", "IIUMc");
      I[67 ^ 75] = I("剜挚泓岺", "sQRTz");
      I[55 ^ 62] = I("凜嶵桧", "CAHxo");
      I[13 ^ 7] = I("渂哌涩", "hjoAP");
      I[23 ^ 28] = I("澡劑槼欭嵂", "XoKqf");
      I[9 ^ 5] = I("崉劻噬婌歃", "wuovO");
      I[54 ^ 59] = I("峟儡", "aKpiX");
      I[155 ^ 149] = I("崧勮柆昗欚", "LvHJW");
      I[61 ^ 50] = I("姱勓慐泡亄", "aqsJV");
   }

   public static int getFireTimeForEntity(EntityLivingBase var0, int var1) {
      int var2 = EnchantmentHelper.getMaxEnchantmentLevel(Enchantments.FIRE_PROTECTION, var0);
      if (var2 > 0) {
         int var10001 = MathHelper.floor((float)var1 * (float)var2 * 0.15F);
         I[44 ^ 36].length();
         I[202 ^ 195].length();
         I[118 ^ 124].length();
         I[177 ^ 186].length();
         I[62 ^ 50].length();
         var1 -= var10001;
      }

      return var1;
   }

   public static double getBlastDamageReduction(EntityLivingBase var0, double var1) {
      int var3 = EnchantmentHelper.getMaxEnchantmentLevel(Enchantments.BLAST_PROTECTION, var0);
      if (var3 > 0) {
         double var10001 = (double)MathHelper.floor(var1 * (double)((float)var3 * 0.15F));
         I[17 ^ 28].length();
         I[150 ^ 152].length();
         I[204 ^ 195].length();
         var1 -= var10001;
      }

      return var1;
   }

   public int getMaxLevel() {
      return 124 ^ 120;
   }

   public String getName() {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[168 ^ 172];
      I[5 ^ 0].length();
      I[154 ^ 156].length();
      return I[85 ^ 82] + this.protectionType.getTypeName();
   }

   public int getMinEnchantability(int var1) {
      int var10000 = this.protectionType.getMinimalEnchantability();
      int var10002 = " ".length();
      I["".length()].length();
      return var10000 + (var1 - var10002) * this.protectionType.getEnchantIncreasePerLevel();
   }

   public int getMaxEnchantability(int var1) {
      return this.getMinEnchantability(var1) + this.protectionType.getEnchantIncreasePerLevel();
   }

   static {
      I();
   }

   public EnchantmentProtection(Enchantment.Rarity var1, EnchantmentProtection.Type var2, EntityEquipmentSlot... var3) {
      super(var1, EnumEnchantmentType.ARMOR, var3);
      this.protectionType = var2;
      if (var2 == EnchantmentProtection.Type.FALL) {
         this.type = EnumEnchantmentType.ARMOR_FEET;
      }

   }

   public static enum Type {
      // $FF: synthetic field
      FIRE,
      // $FF: synthetic field
      EXPLOSION,
      // $FF: synthetic field
      FALL;

      // $FF: synthetic field
      private final String typeName;
      // $FF: synthetic field
      private final int levelCost;
      // $FF: synthetic field
      PROJECTILE;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      ALL;

      // $FF: synthetic field
      private final int minEnchantability;
      // $FF: synthetic field
      private final int levelCostSpan;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 > -1);

         throw null;
      }

      private static void I() {
         I = new String[155 ^ 145];
         I["".length()] = I("\u0016;<", "WwpLp");
         I[" ".length()] = I("0\u000e8", "QbTtZ");
         I["  ".length()] = I("\u0015\u0013\u000b\u001f", "SZYZE");
         I["   ".length()] = I("\u000f8:&", "iQHCC");
         I[119 ^ 115] = I("\u0011&+6", "WggzE");
         I[144 ^ 149] = I(")\u0012!\u001e", "OsMri");
         I[28 ^ 26] = I("!!\u0006\u0003\u000770\u0019\u0001", "dyVOH");
         I[59 ^ 60] = I("<\u000f#\r>*\u001e<\u000f", "YwSaQ");
         I[94 ^ 86] = I("4(\u0001\u000e\u0017'.\u0007\b\u0017", "dzNDR");
         I[135 ^ 142] = I("&%\u000e\u0003\u00175#\b\u0005\u0017", "VWair");
      }

      public int getEnchantIncreasePerLevel() {
         return this.levelCost;
      }

      public String getTypeName() {
         return this.typeName;
      }

      static {
         I();
         ALL = new EnchantmentProtection.Type(I["".length()], "".length(), I[" ".length()], " ".length(), 161 ^ 170, 189 ^ 169);
         FIRE = new EnchantmentProtection.Type(I["  ".length()], " ".length(), I["   ".length()], 49 ^ 59, 48 ^ 56, 52 ^ 56);
         FALL = new EnchantmentProtection.Type(I[1 ^ 5], "  ".length(), I[26 ^ 31], 186 ^ 191, 38 ^ 32, 89 ^ 83);
         EXPLOSION = new EnchantmentProtection.Type(I[6 ^ 0], "   ".length(), I[92 ^ 91], 93 ^ 88, 159 ^ 151, 139 ^ 135);
         PROJECTILE = new EnchantmentProtection.Type(I[191 ^ 183], 80 ^ 84, I[115 ^ 122], "   ".length(), 40 ^ 46, 46 ^ 33);
         EnchantmentProtection.Type[] var10000 = new EnchantmentProtection.Type[96 ^ 101];
         var10000["".length()] = ALL;
         var10000[" ".length()] = FIRE;
         var10000["  ".length()] = FALL;
         var10000["   ".length()] = EXPLOSION;
         var10000[65 ^ 69] = PROJECTILE;
      }

      private Type(String var3, int var4, int var5, int var6) {
         this.typeName = var3;
         this.minEnchantability = var4;
         this.levelCost = var5;
         this.levelCostSpan = var6;
      }

      public int getMinimalEnchantability() {
         return this.minEnchantability;
      }
   }
}

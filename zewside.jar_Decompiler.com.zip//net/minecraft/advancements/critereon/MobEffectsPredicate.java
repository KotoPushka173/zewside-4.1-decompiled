package net.minecraft.advancements.critereon;

import com.google.common.collect.Maps;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class MobEffectsPredicate {
   // $FF: synthetic field
   public static final MobEffectsPredicate field_193473_a;
   // $FF: synthetic field
   private final Map<Potion, MobEffectsPredicate.InstancePredicate> field_193474_b;
   // $FF: synthetic field
   private static final String[] I;

   public static MobEffectsPredicate func_193471_a(@Nullable JsonElement var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[162 ^ 166];
      var10001 = I[8 ^ 13];
      var10002 = I[50 ^ 52];
      var10001 = I[8 ^ 15];
      var10000 = I[137 ^ 129];
      var10001 = I[41 ^ 32];
      var10002 = I[191 ^ 181];
      var10001 = I[125 ^ 118];
      var10000 = I[121 ^ 117];
      var10001 = I[99 ^ 110];
      var10002 = I[17 ^ 31];
      var10001 = I[134 ^ 137];
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = JsonUtils.getJsonObject(var0, I[104 ^ 120]);
         HashMap var2 = Maps.newHashMap();
         Iterator var3 = var1.entrySet().iterator();

         do {
            if (!var3.hasNext()) {
               I[99 ^ 124].length();
               I[63 ^ 31].length();
               I[101 ^ 68].length();
               return new MobEffectsPredicate(var2);
            }

            Entry var4 = (Entry)var3.next();
            I[189 ^ 172].length();
            I[8 ^ 26].length();
            I[122 ^ 105].length();
            ResourceLocation var5 = new ResourceLocation((String)var4.getKey());
            Potion var6 = (Potion)Potion.REGISTRY.getObject(var5);
            if (var6 == null) {
               I[131 ^ 151].length();
               I[22 ^ 3].length();
               I[135 ^ 145].length();
               I[2 ^ 21].length();
               I[74 ^ 82].length();
               JsonSyntaxException var8 = new JsonSyntaxException(I[218 ^ 195] + var5 + I[77 ^ 87]);
               I[70 ^ 93].length();
               throw var8;
            }

            MobEffectsPredicate.InstancePredicate var7 = MobEffectsPredicate.InstancePredicate.func_193464_a(JsonUtils.getJsonObject((JsonElement)var4.getValue(), (String)var4.getKey()));
            var2.put(var6, var7);
            I[40 ^ 52].length();
            I[34 ^ 63].length();
            I[7 ^ 25].length();
            "".length();
         } while(2 > -1);

         throw null;
      } else {
         return field_193473_a;
      }
   }

   public boolean func_193470_a(Map<Potion, PotionEffect> var1) {
      if (this == field_193473_a) {
         return (boolean)" ".length();
      } else {
         Iterator var2 = this.field_193474_b.entrySet().iterator();

         do {
            if (!var2.hasNext()) {
               return (boolean)" ".length();
            }

            Entry var3 = (Entry)var2.next();
            PotionEffect var4 = (PotionEffect)var1.get(var3.getKey());
            if (!((MobEffectsPredicate.InstancePredicate)var3.getValue()).func_193463_a(var4)) {
               return (boolean)"".length();
            }

            "".length();
         } while(2 < 3);

         throw null;
      }
   }

   public boolean func_193469_a(Entity var1) {
      if (this == field_193473_a) {
         return (boolean)" ".length();
      } else {
         int var10000;
         if (var1 instanceof EntityLivingBase) {
            var10000 = this.func_193470_a(((EntityLivingBase)var1).func_193076_bZ());
            "".length();
            if (-1 >= 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public MobEffectsPredicate(Map<Potion, MobEffectsPredicate.InstancePredicate> var1) {
      this.field_193474_b = var1;
   }

   public boolean func_193472_a(EntityLivingBase var1) {
      int var10000;
      if (this == field_193473_a) {
         var10000 = " ".length();
         "".length();
         if (-1 == 3) {
            throw null;
         }
      } else {
         var10000 = this.func_193470_a(var1.func_193076_bZ());
      }

      return (boolean)var10000;
   }

   private static void I() {
      I = new String[100 ^ 70];
      I["".length()] = I("洽淞", "FBsTJ");
      I[" ".length()] = I("戺与", "jtEri");
      I["  ".length()] = I("偄桃", "OIufn");
      I["   ".length()] = I("欃儨", "TSMPY");
      I[87 ^ 83] = I("剐廵", "XdjUx");
      I[161 ^ 164] = I("澕嬩", "PvGdx");
      I[185 ^ 191] = I("娣忸", "pcyyJ");
      I[59 ^ 60] = I("橛杅", "eDFFG");
      I[182 ^ 190] = I("摇妏", "tBstV");
      I[9 ^ 0] = I("刣喾", "kQiCW");
      I[145 ^ 155] = I("扱喋", "CFNaq");
      I[39 ^ 44] = I("嗊煏", "SqRPv");
      I[106 ^ 102] = I("戇嵎", "wENcy");
      I[175 ^ 162] = I("揾儰", "KyPJj");
      I[141 ^ 131] = I("柆坍", "gMqrp");
      I[82 ^ 93] = I("氱洫", "IUKFR");
      I[170 ^ 186] = I("\u0017/ ?\u0010\u0006:", "rIFZs");
      I[129 ^ 144] = I("幵垡咢栐", "ipFpN");
      I[56 ^ 42] = I("劝", "jYxfo");
      I[181 ^ 166] = I("券扝崐", "fdMMc");
      I[158 ^ 138] = I("儿溵倥", "iNWOD");
      I[55 ^ 34] = I("仌澯敞峈", "dOMEu");
      I[34 ^ 52] = I("殮枇", "CUtfc");
      I[98 ^ 117] = I("枔愖扢", "sAUCx");
      I[90 ^ 66] = I("宣壩嗇澣樚", "WetBx");
      I[39 ^ 62] = I("0+\u0001\f\u0000\u0012+J\u0007\t\u0003 \t\u0016OB", "eEjbo");
      I[131 ^ 153] = I("i", "NRTJG");
      I[38 ^ 61] = I("授召攇擰岉", "WNqiW");
      I[76 ^ 80] = I("炊崌剚炫", "oAHnQ");
      I[87 ^ 74] = I("滯損乣勴", "abFjC");
      I[152 ^ 134] = I("峆嚔", "vPVlg");
      I[19 ^ 12] = I("敭", "tLsiK");
      I[226 ^ 194] = I("嘐毈惶汰", "wjcPs");
      I[112 ^ 81] = I("埛塯提娍", "WBJGH");
   }

   static {
      I();
      field_193473_a = new MobEffectsPredicate(Collections.emptyMap());
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 4);

      throw null;
   }

   public static class InstancePredicate {
      // $FF: synthetic field
      @Nullable
      private final Boolean field_193468_d;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final MinMaxBounds field_193465_a;
      // $FF: synthetic field
      @Nullable
      private final Boolean field_193467_c;
      // $FF: synthetic field
      private final MinMaxBounds field_193466_b;

      public boolean func_193463_a(@Nullable PotionEffect var1) {
         if (var1 == null) {
            return (boolean)"".length();
         } else if (!this.field_193465_a.func_192514_a((float)var1.getAmplifier())) {
            return (boolean)"".length();
         } else if (!this.field_193466_b.func_192514_a((float)var1.getDuration())) {
            return (boolean)"".length();
         } else if (this.field_193467_c != null && this.field_193467_c != var1.getIsAmbient()) {
            return (boolean)"".length();
         } else {
            int var10000;
            if (this.field_193468_d != null && this.field_193468_d != var1.doesShowParticles()) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (4 <= 1) {
                  throw null;
               }
            }

            return (boolean)var10000;
         }
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 > 2);

         throw null;
      }

      static {
         I();
      }

      public InstancePredicate(MinMaxBounds var1, MinMaxBounds var2, @Nullable Boolean var3, @Nullable Boolean var4) {
         this.field_193465_a = var1;
         this.field_193466_b = var2;
         this.field_193467_c = var3;
         this.field_193468_d = var4;
      }

      private static void I() {
         I = new String[157 ^ 144];
         I["".length()] = I("澥僉", "xXarK");
         I[" ".length()] = I("何婘", "qzjvk");
         I["  ".length()] = I("侅吁", "aPcHx");
         I["   ".length()] = I("槇娍", "ghokn");
         I[83 ^ 87] = I("1\u001b\u0001*\u000e6\u001f\u00144", "PvqFg");
         I[197 ^ 192] = I("1$\u0017\"\u0002<>\u000b", "UQeCv");
         I[99 ^ 101] = I("\f\n\u00073=\u0003\u0013", "mgeZX");
         I[72 ^ 79] = I(",8\u0013-\u0006#!", "MUqDc");
         I[75 ^ 67] = I(":\u001e\u0018\u000e\u0010 \u0012", "Lwkgr");
         I[120 ^ 113] = I("=<;\u00001'0", "KUHiS");
         I[79 ^ 69] = I("濏壞", "XDVhd");
         I[23 ^ 28] = I("滈息孺巧婛", "lgbQa");
         I[19 ^ 31] = I("僩怕总炦屍", "Bkrld");
      }

      public static MobEffectsPredicate.InstancePredicate func_193464_a(JsonObject var0) {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         MinMaxBounds var1 = MinMaxBounds.func_192515_a(var0.get(I[194 ^ 198]));
         MinMaxBounds var2 = MinMaxBounds.func_192515_a(var0.get(I[8 ^ 13]));
         Boolean var5;
         if (var0.has(I[27 ^ 29])) {
            var5 = JsonUtils.getBoolean(var0, I[108 ^ 107]);
            "".length();
            if (-1 != -1) {
               throw null;
            }
         } else {
            var5 = null;
         }

         Boolean var3 = var5;
         if (var0.has(I[94 ^ 86])) {
            var5 = JsonUtils.getBoolean(var0, I[126 ^ 119]);
            "".length();
            if (4 <= -1) {
               throw null;
            }
         } else {
            var5 = null;
         }

         Boolean var4 = var5;
         I[140 ^ 134].length();
         I[107 ^ 96].length();
         I[76 ^ 64].length();
         return new MobEffectsPredicate.InstancePredicate(var1, var2, var3, var4);
      }
   }
}

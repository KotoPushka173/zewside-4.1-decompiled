package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketEntityAction implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private CPacketEntityAction.Action action;
   // $FF: synthetic field
   private int auxData;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int entityID;

   public CPacketEntityAction.Action getAction() {
      return this.action;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityID = var1.readVarIntFromBuffer();
      this.action = (CPacketEntityAction.Action)var1.readEnumValue(CPacketEntityAction.Action.class);
      this.auxData = var1.readVarIntFromBuffer();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   private static void I() {
      I = new String[72 ^ 76];
      I["".length()] = I("擎枲洛娥", "GXYCd");
      I[" ".length()] = I("摩奀掤捄卾", "IdWIS");
      I["  ".length()] = I("圶", "dLQOx");
      I["   ".length()] = I("嵰機垨廕", "LjpSH");
   }

   public CPacketEntityAction() {
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processEntityAction(this);
   }

   public CPacketEntityAction(Entity var1, CPacketEntityAction.Action var2, int var3) {
      this.entityID = var1.getEntityId();
      this.action = var2;
      this.auxData = var3;
   }

   public CPacketEntityAction(Entity var1, CPacketEntityAction.Action var2) {
      this(var1, var2, "".length());
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityID);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeEnumValue(this.action);
      I["  ".length()].length();
      var1.writeVarIntToBuffer(this.auxData);
      I["   ".length()].length();
   }

   public int getAuxData() {
      return this.auxData;
   }

   public static enum Action {
      // $FF: synthetic field
      STOP_SLEEPING,
      // $FF: synthetic field
      STOP_SPRINTING,
      // $FF: synthetic field
      START_RIDING_JUMP,
      // $FF: synthetic field
      START_SNEAKING;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      START_FALL_FLYING,
      // $FF: synthetic field
      OPEN_INVENTORY,
      // $FF: synthetic field
      START_SPRINTING,
      // $FF: synthetic field
      STOP_RIDING_JUMP,
      // $FF: synthetic field
      STOP_SNEAKING;

      private static void I() {
         I = new String[4 ^ 13];
         I["".length()] = I("17$<>=0+++)*+)", "bcenj");
         I[" ".length()] = I("*\u0001*\u00119*\u001b \u0000-0\u001b\"", "yUeAf");
         I["  ".length()] = I("&\u0000 \u0001:&\u0018*\u00145<\u001a(", "uToQe");
         I["   ".length()] = I("?..\u000b03)?\u000b-\".&\u0017#", "lzoYd");
         I[178 ^ 182] = I(":<\u0004'\u0018:8\u0019>\t=!\u00050", "ihKwG");
         I[66 ^ 71] = I("\u0000\r\u000b&\u0017\f\u000b\u00030\n\u001d\u001e\u0015>\u0016\u001e\t", "SYJtC");
         I[137 ^ 143] = I("\n\u0017*\u00165\u000b\n!\u000f$\u001e\u001c/\u0013'\t", "YCeFj");
         I[197 ^ 194] = I("'\u00032\f)!\u001d!\u00078<\u001c%\u001b", "hSwBv");
         I[123 ^ 115] = I("\u000b.\u0016\u001e\u0001\u0007<\u0016\u0000\u0019\u0007<\u001b\u0015\u001c\u0016=", "XzWLU");
      }

      static {
         I();
         START_SNEAKING = new CPacketEntityAction.Action(I["".length()], "".length());
         STOP_SNEAKING = new CPacketEntityAction.Action(I[" ".length()], " ".length());
         STOP_SLEEPING = new CPacketEntityAction.Action(I["  ".length()], "  ".length());
         START_SPRINTING = new CPacketEntityAction.Action(I["   ".length()], "   ".length());
         STOP_SPRINTING = new CPacketEntityAction.Action(I[21 ^ 17], 184 ^ 188);
         START_RIDING_JUMP = new CPacketEntityAction.Action(I[51 ^ 54], 87 ^ 82);
         STOP_RIDING_JUMP = new CPacketEntityAction.Action(I[148 ^ 146], 111 ^ 105);
         OPEN_INVENTORY = new CPacketEntityAction.Action(I[137 ^ 142], 155 ^ 156);
         START_FALL_FLYING = new CPacketEntityAction.Action(I[78 ^ 70], 116 ^ 124);
         CPacketEntityAction.Action[] var10000 = new CPacketEntityAction.Action[29 ^ 20];
         var10000["".length()] = START_SNEAKING;
         var10000[" ".length()] = STOP_SNEAKING;
         var10000["  ".length()] = STOP_SLEEPING;
         var10000["   ".length()] = START_SPRINTING;
         var10000[130 ^ 134] = STOP_SPRINTING;
         var10000[85 ^ 80] = START_RIDING_JUMP;
         var10000[157 ^ 155] = STOP_RIDING_JUMP;
         var10000[63 ^ 56] = OPEN_INVENTORY;
         var10000[16 ^ 24] = START_FALL_FLYING;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 >= 1);

         throw null;
      }
   }
}

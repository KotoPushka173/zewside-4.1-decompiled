package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import java.util.zip.Deflater;

public class NettyCompressionEncoder extends MessageToByteEncoder<ByteBuf> {
   // $FF: synthetic field
   private final Deflater deflater;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int threshold;
   // $FF: synthetic field
   private final byte[] buffer = new byte[3839 + 4005 - 7830 + 8178];

   public NettyCompressionEncoder(int var1) {
      this.threshold = var1;
      this.deflater = new Deflater();
   }

   protected void encode(ChannelHandlerContext var1, ByteBuf var2, ByteBuf var3) throws Exception {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      int var4 = var2.readableBytes();
      I[33 ^ 37].length();
      I[61 ^ 56].length();
      I[153 ^ 159].length();
      PacketBuffer var5 = new PacketBuffer(var3);
      if (var4 < this.threshold) {
         var5.writeVarIntToBuffer("".length());
         I[10 ^ 13].length();
         var5.writeBytes(var2);
         I[134 ^ 142].length();
         "".length();
         if (4 == -1) {
            throw null;
         }
      } else {
         byte[] var6 = new byte[var4];
         var2.readBytes(var6);
         I[93 ^ 84].length();
         I[128 ^ 138].length();
         I[98 ^ 105].length();
         var5.writeVarIntToBuffer(var6.length);
         I[10 ^ 6].length();
         this.deflater.setInput(var6, "".length(), var4);
         this.deflater.finish();

         while(!this.deflater.finished()) {
            int var7 = this.deflater.deflate(this.buffer);
            var5.writeBytes(this.buffer, "".length(), var7);
            I[113 ^ 124].length();
            I[175 ^ 161].length();
            I[155 ^ 148].length();
            "".length();
            if (4 < 2) {
               throw null;
            }
         }

         this.deflater.reset();
      }

   }

   private static void I() {
      I = new String[93 ^ 77];
      I["".length()] = I("瀮巀", "wGItR");
      I[" ".length()] = I("態涶", "HijEf");
      I["  ".length()] = I("叺旂", "KgGuI");
      I["   ".length()] = I("屒始", "wVNWQ");
      I[94 ^ 90] = I("倿", "rGRCc");
      I[87 ^ 82] = I("垍", "TTWzu");
      I[0 ^ 6] = I("拾櫯", "Owuiw");
      I[27 ^ 28] = I("旆搅桛厾", "RzFTx");
      I[155 ^ 147] = I("懅寂嵖島", "axvYk");
      I[70 ^ 79] = I("洘", "maeQR");
      I[81 ^ 91] = I("桄嚊", "DyrfE");
      I[140 ^ 135] = I("枇嵡曽测", "Svqfs");
      I[175 ^ 163] = I("俖堻忓嶟极", "tphEI");
      I[110 ^ 99] = I("怺", "QfWNK");
      I[5 ^ 11] = I("潗凮", "NUeOk");
      I[101 ^ 106] = I("檭峨", "pfeat");
   }

   public void setCompressionThreshold(int var1) {
      this.threshold = var1;
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 4);

      throw null;
   }
}

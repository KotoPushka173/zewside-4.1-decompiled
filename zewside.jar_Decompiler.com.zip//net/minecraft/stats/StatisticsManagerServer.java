package net.minecraft.stats;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.play.server.SPacketStatistics;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.IJsonSerializable;
import net.minecraft.util.TupleIntJsonSerializable;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class StatisticsManagerServer extends StatisticsManager {
   // $FF: synthetic field
   private final File statsFile;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final Logger LOGGER;
   // $FF: synthetic field
   private int lastStatRequest = -(219 + 163 - 317 + 235);
   // $FF: synthetic field
   private final Set<StatBase> dirty = Sets.newHashSet();
   // $FF: synthetic field
   private final MinecraftServer mcServer;

   public StatisticsManagerServer(MinecraftServer var1, File var2) {
      this.mcServer = var1;
      this.statsFile = var2;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 0);

      throw null;
   }

   public static String dumpJson(Map<StatBase, TupleIntJsonSerializable> var0) {
      String var10000 = I[122 ^ 97];
      String var10001 = I[221 ^ 193];
      String var10002 = I[93 ^ 64];
      var10001 = I[136 ^ 150];
      var10000 = I[71 ^ 88];
      var10001 = I[13 ^ 45];
      var10002 = I[153 ^ 184];
      var10001 = I[111 ^ 77];
      I[137 ^ 170].length();
      I[11 ^ 47].length();
      I[179 ^ 150].length();
      I[140 ^ 170].length();
      I[189 ^ 154].length();
      JsonObject var1 = new JsonObject();
      Iterator var2 = var0.entrySet().iterator();

      do {
         if (!var2.hasNext()) {
            return var1.toString();
         }

         Entry var3 = (Entry)var2.next();
         if (((TupleIntJsonSerializable)var3.getValue()).getJsonSerializableValue() != null) {
            I[10 ^ 34].length();
            I[144 ^ 185].length();
            I[11 ^ 33].length();
            I[189 ^ 150].length();
            JsonObject var4 = new JsonObject();
            var4.addProperty(I[100 ^ 72], ((TupleIntJsonSerializable)var3.getValue()).getIntegerValue());

            label27: {
               try {
                  var4.add(I[26 ^ 55], ((TupleIntJsonSerializable)var3.getValue()).getJsonSerializableValue().getSerializableElement());
               } catch (Throwable var6) {
                  LOGGER.warn(I[30 ^ 48], ((StatBase)var3.getKey()).getStatName(), var6);
                  break label27;
               }

               "".length();
               if (1 >= 4) {
                  throw null;
               }
            }

            var1.add(((StatBase)var3.getKey()).statId, var4);
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var1.addProperty(((StatBase)var3.getKey()).statId, ((TupleIntJsonSerializable)var3.getValue()).getIntegerValue());
         }

         "".length();
      } while(3 != 2);

      throw null;
   }

   static {
      I();
      LOGGER = LogManager.getLogger();
   }

   public Map<StatBase, TupleIntJsonSerializable> parseJson(String var1) {
      String var10000 = I[133 ^ 129];
      String var10001 = I[59 ^ 62];
      String var10002 = I[38 ^ 32];
      var10001 = I[12 ^ 11];
      var10000 = I[125 ^ 117];
      var10001 = I[169 ^ 160];
      var10002 = I[19 ^ 25];
      var10001 = I[54 ^ 61];
      I[98 ^ 110].length();
      JsonElement var2 = (new JsonParser()).parse(var1);
      if (!var2.isJsonObject()) {
         return Maps.newHashMap();
      } else {
         JsonObject var3 = var2.getAsJsonObject();
         HashMap var4 = Maps.newHashMap();
         Iterator var5 = var3.entrySet().iterator();

         do {
            if (!var5.hasNext()) {
               return var4;
            }

            Entry var6 = (Entry)var5.next();
            StatBase var7 = StatList.getOneShotStat((String)var6.getKey());
            if (var7 == null) {
               LOGGER.warn(I[173 ^ 183], this.statsFile, var6.getKey());
            } else {
               I[92 ^ 81].length();
               I[33 ^ 47].length();
               I[49 ^ 62].length();
               TupleIntJsonSerializable var8 = new TupleIntJsonSerializable();
               if (((JsonElement)var6.getValue()).isJsonPrimitive() && ((JsonElement)var6.getValue()).getAsJsonPrimitive().isNumber()) {
                  var8.setIntegerValue(((JsonElement)var6.getValue()).getAsInt());
                  "".length();
                  if (2 == 3) {
                     throw null;
                  }
               } else if (((JsonElement)var6.getValue()).isJsonObject()) {
                  JsonObject var9 = ((JsonElement)var6.getValue()).getAsJsonObject();
                  if (var9.has(I[187 ^ 171]) && var9.get(I[188 ^ 173]).isJsonPrimitive() && var9.get(I[50 ^ 32]).getAsJsonPrimitive().isNumber()) {
                     var8.setIntegerValue(var9.getAsJsonPrimitive(I[112 ^ 99]).getAsInt());
                  }

                  if (var9.has(I[172 ^ 184]) && var7.getSerializableClazz() != null) {
                     label47: {
                        try {
                           Constructor var10 = var7.getSerializableClazz().getConstructor();
                           IJsonSerializable var11 = (IJsonSerializable)var10.newInstance();
                           var11.fromJson(var9.get(I[119 ^ 98]));
                           var8.setJsonSerializableValue(var11);
                        } catch (Throwable var12) {
                           LOGGER.warn(I[28 ^ 10], this.statsFile, var12);
                           break label47;
                        }

                        "".length();
                        if (2 < -1) {
                           throw null;
                        }
                     }
                  }
               }

               var4.put(var7, var8);
               I[162 ^ 181].length();
               I[183 ^ 175].length();
               I[184 ^ 161].length();
               "".length();
               if (3 < 2) {
                  throw null;
               }
            }

            "".length();
         } while(-1 == -1);

         throw null;
      }
   }

   public void readStatFile() {
      if (this.statsFile.isFile()) {
         try {
            this.statsData.clear();
            this.statsData.putAll(this.parseJson(FileUtils.readFileToString(this.statsFile)));
         } catch (IOException var2) {
            LOGGER.error(I["".length()], this.statsFile, var2);
            "".length();
            if (0 != 3) {
               return;
            }

            throw null;
         } catch (JsonParseException var3) {
            LOGGER.error(I[" ".length()], this.statsFile, var3);
            return;
         }

         "".length();
         if (4 < 2) {
            throw null;
         }
      }

   }

   public void saveStatFile() {
      try {
         FileUtils.writeStringToFile(this.statsFile, dumpJson(this.statsData));
      } catch (IOException var2) {
         LOGGER.error(I["  ".length()], var2);
         return;
      }

      "".length();
      if (0 < -1) {
         throw null;
      }
   }

   private static void I() {
      I = new String[102 ^ 90];
      I["".length()] = I("3,:(\u0011\u001ed;d\u0007\u0015\"+d\u0006\u0004\";-\u0006\u0004*,7U\u0016*#!U\u000b>", "pCODu");
      I[" ".length()] = I("6\u00168!\u0014\u001b^9m\u0000\u0014\u000b>(P\u0006\r,9\u0019\u0006\r$.\u0003U\u001f$!\u0015U\u00020", "uyMMp");
      I["  ".length()] = I("\u0010)=\b\u0005=a<D\u001220-D\u0012''<\u0017", "SFHda");
      I["   ".length()] = I("烵仴搬枹", "vggRJ");
      I[69 ^ 65] = I("囷旙", "qdLce");
      I[61 ^ 56] = I("倾亗", "rzXyJ");
      I[157 ^ 155] = I("擲上", "XXjPO");
      I[173 ^ 170] = I("桝曟", "ftMaA");
      I[2 ^ 10] = I("濵沊", "mlFsq");
      I[60 ^ 53] = I("巎愑", "VCNzx");
      I[42 ^ 32] = I("勾坊", "mQRzC");
      I[142 ^ 133] = I("忈囎", "TvYRN");
      I[47 ^ 35] = I("敢", "cZmmV");
      I[123 ^ 118] = I("協嬐", "keMUs");
      I[124 ^ 114] = I("愿", "EIFhe");
      I[146 ^ 157] = I("壳人扛", "xpQuC");
      I[72 ^ 88] = I("/0\u001d12", "YQqDW");
      I[185 ^ 168] = I("\u0007'\u000b63", "qFgCV");
      I[55 ^ 37] = I("1\u0004'2.", "GeKGK");
      I[6 ^ 21] = I("\u0000\b\t<3", "vieIV");
      I[17 ^ 5] = I("85\f4\u0013-4\u0010", "HGcSa");
      I[215 ^ 194] = I("$\u001b\u0001\u0002\u00011\u001a\u001d", "Tines");
      I[75 ^ 93] = I("+\u0018>\u0011\u001d\u000b\u0012h\u0003\u0005\u0003\u0002!\u0003\u0005\u000b\u0015h\u0000\u0003\r\u0011:\u0015\u0002\u0011V!\u001eQ\u0019\u000b", "bvHpq");
      I[22 ^ 1] = I("列掼嶩嵁", "nYevZ");
      I[23 ^ 15] = I("凒椼", "sZomP");
      I[61 ^ 36] = I("昘壯憺喜", "FSqkP");
      I[53 ^ 47] = I("0=\u00109\u0004\u00107F+\u001c\u0018'\u000f+\u001c\u00100F1\u0006Y(\u001bbH=<\b\u007f\u001cY8\b7\u001fY$\u000e9\u001cY(\u001bx\u0001\n", "ySfXh");
      I[170 ^ 177] = I("殙嘏", "YOpjP");
      I[39 ^ 59] = I("漋惤", "JHrEw");
      I[181 ^ 168] = I("惞尋", "sYTWa");
      I[167 ^ 185] = I("懽湢", "IMFbW");
      I[115 ^ 108] = I("唓毠", "eEJru");
      I[146 ^ 178] = I("溦檱", "hpuAC");
      I[41 ^ 8] = I("依惰", "nsosZ");
      I[152 ^ 186] = I("泫愧", "uYYSi");
      I[181 ^ 150] = I("廔剪姹愰", "GOdyg");
      I[226 ^ 198] = I("扔州忱帍", "JbZvJ");
      I[17 ^ 52] = I("儘", "pMlrn");
      I[146 ^ 180] = I("斣巣厐庇", "VdOXC");
      I[135 ^ 160] = I("洮巯哄杤伬", "OryMT");
      I[126 ^ 86] = I("掠奆么憶湤", "jWkeN");
      I[12 ^ 37] = I("呧渱喘搘", "QDLrF");
      I[68 ^ 110] = I("剞濭殊壉", "fQDMx");
      I[178 ^ 153] = I("亲", "ffrKY");
      I[145 ^ 189] = I("55\u0002#2", "CTnVW");
      I[238 ^ 195] = I("\u0000\u0001\u001b\u0005\u001c\u0015\u0000\u0007", "pstbn");
      I[128 ^ 174] = I("&\u001b\u0018*\u0012\u000bS\u0019f\u0005\u0004\u0002\bf\u0005\u0011\u0015\u0019/\u0005\u0011\u001d\u000ef\r\u0018NM#\u0004\u0017\u001b\u001ff\u0005\u0000\u0006\u0004'\u001a\f\u000e\u0004(\u0011E\u0004\u001f)\u0011\u0017\u0011\u001e5", "etmFv");
      I[105 ^ 70] = I("櫠奘漄", "GLOzo");
      I[1 ^ 49] = I("旓", "tnSSb");
      I[9 ^ 56] = I("楸柩潹丳囙", "KNcwr");
      I[118 ^ 68] = I("橃普", "IyhoR");
      I[144 ^ 163] = I("嬎樐", "wLXiQ");
      I[188 ^ 136] = I("友儸", "APdiq");
      I[90 ^ 111] = I("揠嗺", "EFffs");
      I[55 ^ 1] = I("揍尚仢", "NgdWl");
      I[145 ^ 166] = I("塹", "DtFZi");
      I[148 ^ 172] = I("壐", "Yuiku");
      I[157 ^ 164] = I("漦怇", "PQIrK");
      I[156 ^ 166] = I("寷伏", "mPduC");
      I[175 ^ 148] = I("巄崜", "ynUkK");
   }

   private Set<StatBase> getDirty() {
      HashSet var1 = Sets.newHashSet(this.dirty);
      this.dirty.clear();
      return var1;
   }

   public void unlockAchievement(EntityPlayer var1, StatBase var2, int var3) {
      super.unlockAchievement(var1, var2, var3);
      this.dirty.add(var2);
      I["   ".length()].length();
   }

   public void sendStats(EntityPlayerMP var1) {
      String var10000 = I[188 ^ 142];
      String var10001 = I[78 ^ 125];
      String var10002 = I[120 ^ 76];
      var10001 = I[138 ^ 191];
      int var2 = this.mcServer.getTickCounter();
      HashMap var3 = Maps.newHashMap();
      int var7 = this.lastStatRequest;
      I[108 ^ 90].length();
      if (var2 - var7 > 16 + 265 - 147 + 166) {
         this.lastStatRequest = var2;
         Iterator var4 = this.getDirty().iterator();

         while(var4.hasNext()) {
            StatBase var5 = (StatBase)var4.next();
            var3.put(var5, this.readStat(var5));
            I[24 ^ 47].length();
            I[74 ^ 114].length();
            "".length();
            if (1 >= 3) {
               throw null;
            }
         }
      }

      NetHandlerPlayServer var6 = var1.connection;
      I[71 ^ 126].length();
      I[68 ^ 126].length();
      I[110 ^ 85].length();
      var6.sendPacket(new SPacketStatistics(var3));
   }

   public void markAllDirty() {
      this.dirty.addAll(this.statsData.keySet());
      I[58 ^ 21].length();
      I[101 ^ 85].length();
      I[154 ^ 171].length();
   }
}

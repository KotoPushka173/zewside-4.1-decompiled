package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.Set;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketPlayerPosLook implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private Set<SPacketPlayerPosLook.EnumFlags> flags;
   // $FF: synthetic field
   private double x;
   // $FF: synthetic field
   public float pitch;
   // $FF: synthetic field
   private int teleportId;
   // $FF: synthetic field
   private double z;
   // $FF: synthetic field
   private double y;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public float yaw;

   public float getYaw() {
      return this.yaw;
   }

   public SPacketPlayerPosLook(double var1, double var3, double var5, float var7, float var8, Set<SPacketPlayerPosLook.EnumFlags> var9, int var10) {
      this.x = var1;
      this.y = var3;
      this.z = var5;
      this.yaw = var7;
      this.pitch = var8;
      this.flags = var9;
      this.teleportId = var10;
   }

   public double getZ() {
      return this.z;
   }

   public SPacketPlayerPosLook() {
   }

   public int getTeleportId() {
      return this.teleportId;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeDouble(this.x);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeDouble(this.y);
      I["   ".length()].length();
      I[75 ^ 79].length();
      I[159 ^ 154].length();
      I[141 ^ 139].length();
      var1.writeDouble(this.z);
      I[44 ^ 43].length();
      var1.writeFloat(this.yaw);
      I[99 ^ 107].length();
      I[27 ^ 18].length();
      I[179 ^ 185].length();
      var1.writeFloat(this.pitch);
      I[84 ^ 95].length();
      I[106 ^ 102].length();
      I[169 ^ 164].length();
      I[66 ^ 76].length();
      I[36 ^ 43].length();
      var1.writeByte(SPacketPlayerPosLook.EnumFlags.pack(this.flags));
      I[136 ^ 152].length();
      I[100 ^ 117].length();
      var1.writeVarIntToBuffer(this.teleportId);
      I[36 ^ 54].length();
      I[178 ^ 161].length();
      I[209 ^ 197].length();
      I[104 ^ 125].length();
   }

   private static void I() {
      I = new String[90 ^ 76];
      I["".length()] = I("槌拖彔栻淀", "RxDCK");
      I[" ".length()] = I("漻", "tlsyR");
      I["  ".length()] = I("屯慱小堑曣", "ZWwVy");
      I["   ".length()] = I("忰勳了剹擸", "OGdOd");
      I[29 ^ 25] = I("堁", "dkUvc");
      I[17 ^ 20] = I("嶀婟淑憳屚", "FEAAP");
      I[17 ^ 23] = I("泩函枫汹凜", "FWqWL");
      I[21 ^ 18] = I("歍刾奘檪瀁", "eZsHW");
      I[112 ^ 120] = I("余暬溛", "uflxq");
      I[19 ^ 26] = I("杬樌宾坡揔", "YRHLw");
      I[204 ^ 198] = I("恪渰噬恀", "JhDAv");
      I[119 ^ 124] = I("噜悹", "NeemP");
      I[46 ^ 34] = I("欑沔", "oUTmY");
      I[13 ^ 0] = I("咊炇奔", "tjmze");
      I[156 ^ 146] = I("泴梮傜灝愆", "IUAgq");
      I[80 ^ 95] = I("価卮李厭弾", "Jgbjx");
      I[162 ^ 178] = I("咱帿瀎掖", "fxGGz");
      I[71 ^ 86] = I("剺暢炀婢", "dlplx");
      I[120 ^ 106] = I("攙愐彍泫", "SEeLq");
      I[17 ^ 2] = I("恨", "OqcCK");
      I[71 ^ 83] = I("攒攔娈", "JYmHs");
      I[143 ^ 154] = I("嘮弙养匝停", "aTCjr");
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handlePlayerPosLook(this);
   }

   public double getX() {
      return this.x;
   }

   public double getY() {
      return this.y;
   }

   static {
      I();
   }

   public float getPitch() {
      return this.pitch;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.x = var1.readDouble();
      this.y = var1.readDouble();
      this.z = var1.readDouble();
      this.yaw = var1.readFloat();
      this.pitch = var1.readFloat();
      this.flags = SPacketPlayerPosLook.EnumFlags.unpack(var1.readUnsignedByte());
      this.teleportId = var1.readVarIntFromBuffer();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public Set<SPacketPlayerPosLook.EnumFlags> getFlags() {
      return this.flags;
   }

   public static enum EnumFlags {
      // $FF: synthetic field
      Z,
      // $FF: synthetic field
      X_ROT,
      // $FF: synthetic field
      Y_ROT,
      // $FF: synthetic field
      Y;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      X;

      // $FF: synthetic field
      private final int bit;

      private EnumFlags(int var3) {
         this.bit = var3;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 > 0);

         throw null;
      }

      public static int pack(Set<SPacketPlayerPosLook.EnumFlags> var0) {
         int var1 = "".length();
         Iterator var2 = var0.iterator();

         do {
            if (!var2.hasNext()) {
               return var1;
            }

            SPacketPlayerPosLook.EnumFlags var3 = (SPacketPlayerPosLook.EnumFlags)var2.next();
            var1 |= var3.getMask();
            "".length();
         } while(1 >= -1);

         throw null;
      }

      public static Set<SPacketPlayerPosLook.EnumFlags> unpack(int var0) {
         EnumSet var1 = EnumSet.noneOf(SPacketPlayerPosLook.EnumFlags.class);
         SPacketPlayerPosLook.EnumFlags[] var2 = values();
         int var3 = var2.length;
         int var4 = "".length();

         do {
            if (var4 >= var3) {
               return var1;
            }

            SPacketPlayerPosLook.EnumFlags var5 = var2[var4];
            if (var5.isSet(var0)) {
               var1.add(var5);
               I["".length()].length();
            }

            ++var4;
            "".length();
         } while(0 < 4);

         throw null;
      }

      static {
         I();
         X = new SPacketPlayerPosLook.EnumFlags(I[" ".length()], "".length(), "".length());
         Y = new SPacketPlayerPosLook.EnumFlags(I["  ".length()], " ".length(), " ".length());
         Z = new SPacketPlayerPosLook.EnumFlags(I["   ".length()], "  ".length(), "  ".length());
         Y_ROT = new SPacketPlayerPosLook.EnumFlags(I[47 ^ 43], "   ".length(), "   ".length());
         X_ROT = new SPacketPlayerPosLook.EnumFlags(I[56 ^ 61], 122 ^ 126, 156 ^ 152);
         SPacketPlayerPosLook.EnumFlags[] var10000 = new SPacketPlayerPosLook.EnumFlags[82 ^ 87];
         var10000["".length()] = X;
         var10000[" ".length()] = Y;
         var10000["  ".length()] = Z;
         var10000["   ".length()] = Y_ROT;
         var10000[60 ^ 56] = X_ROT;
      }

      private boolean isSet(int var1) {
         int var10000;
         if ((var1 & this.getMask()) == this.getMask()) {
            var10000 = " ".length();
            "".length();
            if (2 != 2) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }

      private static void I() {
         I = new String[120 ^ 126];
         I["".length()] = I("慳旪低", "GWxlt");
         I[" ".length()] = I("-", "uTyBi");
         I["  ".length()] = I("\u0015", "LXViZ");
         I["   ".length()] = I("\u001d", "GjssE");
         I[13 ^ 9] = I("\u0013\u001a\"=\u0013", "JEprG");
         I[20 ^ 17] = I(")\u00137\u001c;", "qLeSo");
      }

      private int getMask() {
         return " ".length() << this.bit;
      }
   }
}

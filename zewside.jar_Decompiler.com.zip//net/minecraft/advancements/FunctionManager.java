package net.minecraft.advancements;

import com.google.common.collect.Maps;
import com.google.common.io.Files;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.command.FunctionObject;
import net.minecraft.command.ICommandManager;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ITickable;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FunctionManager implements ITickable {
   // $FF: synthetic field
   private final MinecraftServer field_193069_c;
   // $FF: synthetic field
   private final ArrayDeque<FunctionManager.QueuedCommand> field_194020_g;
   // $FF: synthetic field
   private final ICommandSender field_193073_g;
   // $FF: synthetic field
   private String field_193071_e;
   // $FF: synthetic field
   private boolean field_194021_h;
   // $FF: synthetic field
   private final Map<ResourceLocation, FunctionObject> field_193070_d = Maps.newHashMap();
   // $FF: synthetic field
   private final File field_193068_b;
   // $FF: synthetic field
   private static final Logger field_193067_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private FunctionObject field_193072_f;

   public ICommandManager func_193062_a() {
      return this.field_193069_c.getCommandManager();
   }

   private static void I() {
      I = new String[207 ^ 140];
      I["".length()] = I("\u007f", "RmLMy");
      I[" ".length()] = I("7\u0003!.67\u000f8\u0003=\u0019\n8\u00047\u0016\u00077\n-2", "ZbYmY");
      I["  ".length()] = I("槭斉", "wLbAQ");
      I["   ".length()] = I("妬兴", "kZesa");
      I[67 ^ 71] = I("滌澹", "tMJYg");
      I[167 ^ 162] = I("捓澲", "RyAtE");
      I[191 ^ 185] = I("$\u0013/\t\u0006,\u001d2*?-\u00116\u0005%-", "CrBlJ");
      I[91 ^ 92] = I("凭常", "jYcxB");
      I[7 ^ 15] = I("唇噮栝注", "JKvqC");
      I[65 ^ 72] = I("晾", "qNrmB");
      I[136 ^ 130] = I("咭喯", "XtkLi");
      I[66 ^ 73] = I("擻帜", "XsTRS");
      I[27 ^ 23] = I("汌帲", "GtSRj");
      I[66 ^ 79] = I("彺庼", "yVvso");
      I[163 ^ 173] = I("懕咃", "UXDpX");
      I[105 ^ 102] = I("俳奓", "olTBi");
      I[125 ^ 109] = I("一捥", "GuoMa");
      I[215 ^ 198] = I("丠巇", "ypvFT");
      I[19 ^ 1] = I("悻歈", "bAjKG");
      I[112 ^ 99] = I("澍吧", "GObdJ");
      I[214 ^ 194] = I("暇冸", "HuJPb");
      I[127 ^ 106] = I("妯杰", "fhkmS");
      I[96 ^ 118] = I("惢偄橗", "exRjt");
      I[113 ^ 102] = I("亦嶀丂悒", "xhEox");
      I[98 ^ 122] = I("彎昘呉", "hhuue");
      I[144 ^ 137] = I("傌帒嫣宪湼", "UKuDq");
      I[179 ^ 169] = I("曅澋", "ejrdj");
      I[105 ^ 114] = I("悕栩壥乷櫙", "wNCNS");
      I[133 ^ 153] = I("引昲愫烚", "rEuWA");
      I[88 ^ 69] = I("沧", "eMyER");
      I[41 ^ 55] = I("廤仇澟娠", "ixDcw");
      I[78 ^ 81] = I("{", "VhXDE");
      I[65 ^ 97] = I("戎揎", "hxILd");
      I[118 ^ 87] = I("垀并", "SCAmQ");
      I[100 ^ 70] = I("塻匥", "zOiEU");
      I[103 ^ 68] = I("毣戾", "vedxG");
      I[44 ^ 8] = I("榑椾", "HComl");
      I[33 ^ 4] = I("撦刽", "ySEGu");
      I[225 ^ 199] = I("嗤弒", "kRdKj");
      I[108 ^ 75] = I("椧嵨", "kWEfc");
      I[150 ^ 190] = I("幏弰", "qSXYh");
      I[0 ^ 41] = I("幌佐", "CRhUh");
      I[106 ^ 64] = I("圙呼", "SVOmY");
      I[0 ^ 43] = I("殁澫", "ZzmMP");
      I[81 ^ 125] = I("澙匶", "TNphu");
      I[19 ^ 62] = I("壇倀", "SeOwr");
      I[80 ^ 126] = I("庝卜", "tXUQk");
      I[172 ^ 131] = I("墙呕", "BuDkf");
      I[97 ^ 81] = I("姒", "GyJrN");
      I[99 ^ 82] = I("湧俆殭", "qAKKD");
      I[69 ^ 119] = I("勴", "iKmIe");
      I[97 ^ 82] = I("55<!(;\"3;(", "XVZTF");
      I[242 ^ 198] = I("y", "VwgiR");
      I[153 ^ 172] = I("暥漛抒悬怑", "qrcPn");
      I[160 ^ 150] = I("冲", "VGfYT");
      I[101 ^ 82] = I("桹汱岿旞", "gQVIx");
      I[113 ^ 73] = I("忎", "eenNu");
      I[81 ^ 104] = I("亙抝峪", "YskVP");
      I[109 ^ 87] = I("毡", "smHGE");
      I[2 ^ 57] = I("\t98==$q9q+/7)q:?%9>4j08?:>?\"?y", "JVMQY");
      I[27 ^ 39] = I("R\u0005\u0015\u0002%R", "rcgmH");
      I[131 ^ 190] = I("枸尉渐席", "jgBzr");
      I[100 ^ 90] = I("勮灣", "qRWUx");
      I[181 ^ 138] = I("嶢慊嚏", "QmFiP");
      I[33 ^ 97] = I("昑佇欗", "rYeXw");
      I[218 ^ 155] = I("\u001b(\u0017\u0015\u001d3g", "WGvqx");
      I[134 ^ 196] = I("s;7\u0010\u0005<5b\u0000\u001e>5#\r\u0015s>7\r\u0012'1-\r\u0002", "SXBcq");
   }

   public int func_193065_c() {
      return this.field_193069_c.worldServers["".length()].getGameRules().getInt(I[" ".length()]);
   }

   public void update() {
      String var10000 = I["  ".length()];
      String var10001 = I["   ".length()];
      String var10002 = I[185 ^ 189];
      var10001 = I[43 ^ 46];
      String var1 = this.field_193069_c.worldServers["".length()].getGameRules().getString(I[40 ^ 46]);
      if (!var1.equals(this.field_193071_e)) {
         this.field_193071_e = var1;
         I[48 ^ 55].length();
         this.field_193072_f = this.func_193058_a(new ResourceLocation(var1));
      }

      if (this.field_193072_f != null) {
         this.func_194019_a(this.field_193072_f, this.field_193073_g);
         I[105 ^ 97].length();
         I[106 ^ 99].length();
      }

   }

   public FunctionManager(@Nullable File var1, MinecraftServer var2) {
      this.field_193071_e = I["".length()];
      this.field_194020_g = new ArrayDeque();
      this.field_194021_h = (boolean)"".length();
      this.field_193073_g = new ICommandSender() {
         public MinecraftServer getServer() {
            return FunctionManager.this.field_193069_c;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 > -1);

            throw null;
         }

         public World getEntityWorld() {
            return FunctionManager.this.field_193069_c.worldServers["".length()];
         }

         public boolean canCommandSenderUseCommand(int var1, String var2) {
            int var10000;
            if (var1 <= "  ".length()) {
               var10000 = " ".length();
               "".length();
               if (1 <= 0) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }

         public String getName() {
            return FunctionManager.this.field_193071_e;
         }
      };
      this.field_193068_b = var1;
      this.field_193069_c = var2;
      this.func_193059_f();
   }

   private void func_193061_h() {
      String var10000 = I[170 ^ 138];
      String var10001 = I[41 ^ 8];
      String var10002 = I[97 ^ 67];
      var10001 = I[112 ^ 83];
      var10000 = I[166 ^ 130];
      var10001 = I[147 ^ 182];
      var10002 = I[180 ^ 146];
      var10001 = I[0 ^ 39];
      var10000 = I[156 ^ 180];
      var10001 = I[237 ^ 196];
      var10002 = I[37 ^ 15];
      var10001 = I[72 ^ 99];
      var10000 = I[98 ^ 78];
      var10001 = I[158 ^ 179];
      var10002 = I[131 ^ 173];
      var10001 = I[48 ^ 31];
      if (this.field_193068_b != null) {
         this.field_193068_b.mkdirs();
         I[126 ^ 78].length();
         File var8 = this.field_193068_b;
         String[] var10 = new String[" ".length()];
         I[79 ^ 126].length();
         I[106 ^ 88].length();
         var10["".length()] = I[93 ^ 110];
         Iterator var1 = FileUtils.listFiles(var8, var10, (boolean)" ".length()).iterator();

         Logger var9;
         while(var1.hasNext()) {
            File var2 = (File)var1.next();
            String var3 = FilenameUtils.removeExtension(this.field_193068_b.toURI().relativize(var2.toURI()).toString());
            String[] var4 = var3.split(I[183 ^ 131], "  ".length());
            if (var4.length == "  ".length()) {
               label41: {
                  I[188 ^ 137].length();
                  I[46 ^ 24].length();
                  ResourceLocation var5 = new ResourceLocation(var4["".length()], var4[" ".length()]);

                  try {
                     this.field_193070_d.put(var5, FunctionObject.func_193527_a(this, Files.readLines(var2, StandardCharsets.UTF_8)));
                     I[72 ^ 127].length();
                  } catch (Throwable var7) {
                     var9 = field_193067_a;
                     I[33 ^ 25].length();
                     I[136 ^ 177].length();
                     I[171 ^ 145].length();
                     var9.error(I[26 ^ 33] + var5 + I[134 ^ 186] + var2, var7);
                     break label41;
                  }

                  "".length();
                  if (4 <= 2) {
                     throw null;
                  }
               }
            }

            "".length();
            if (4 != 4) {
               throw null;
            }
         }

         if (!this.field_193070_d.isEmpty()) {
            var9 = field_193067_a;
            I[159 ^ 162].length();
            I[1 ^ 63].length();
            I[173 ^ 146].length();
            I[16 ^ 80].length();
            var9.info(I[78 ^ 15] + this.field_193070_d.size() + I[85 ^ 23]);
         }
      }

   }

   @Nullable
   public FunctionObject func_193058_a(ResourceLocation var1) {
      return (FunctionObject)this.field_193070_d.get(var1);
   }

   static {
      I();
      field_193067_a = LogManager.getLogger();
   }

   public int func_194019_a(FunctionObject var1, ICommandSender var2) {
      String var10000 = I[158 ^ 148];
      String var10001 = I[174 ^ 165];
      String var10002 = I[99 ^ 111];
      var10001 = I[204 ^ 193];
      var10000 = I[190 ^ 176];
      var10001 = I[92 ^ 83];
      var10002 = I[16 ^ 0];
      var10001 = I[181 ^ 164];
      var10000 = I[21 ^ 7];
      var10001 = I[134 ^ 149];
      var10002 = I[123 ^ 111];
      var10001 = I[59 ^ 46];
      int var3 = this.func_193065_c();
      ArrayDeque var12;
      if (this.field_194021_h) {
         if (this.field_194020_g.size() < var3) {
            var12 = this.field_194020_g;
            I[129 ^ 151].length();
            I[128 ^ 151].length();
            I[18 ^ 10].length();
            I[175 ^ 182].length();
            var12.addFirst(new FunctionManager.QueuedCommand(this, var2, new FunctionObject.FunctionEntry(var1)));
         }

         return "".length();
      } else {
         int var4;
         label102: {
            int var7;
            try {
               this.field_194021_h = (boolean)" ".length();
               int var5 = "".length();
               FunctionObject.Entry[] var6 = var1.func_193528_a();
               int var11 = var6.length;
               int var13 = " ".length();
               I[145 ^ 139].length();
               var7 = var11 - var13;

               while(var7 >= 0) {
                  var12 = this.field_194020_g;
                  I[122 ^ 97].length();
                  I[139 ^ 151].length();
                  I[4 ^ 25].length();
                  var12.push(new FunctionManager.QueuedCommand(this, var2, var6[var7]));
                  --var7;
                  "".length();
                  if (1 >= 3) {
                     throw null;
                  }
               }

               while(!this.field_194020_g.isEmpty()) {
                  ((FunctionManager.QueuedCommand)this.field_194020_g.removeFirst()).func_194222_a(this.field_194020_g, var3);
                  ++var5;
                  if (var5 >= var3) {
                     "".length();
                     if (1 >= 3) {
                        throw null;
                     }

                     var4 = var5;
                     break label102;
                  }
               }

               var7 = var5;
            } catch (Throwable var10) {
               this.field_194020_g.clear();
               this.field_194021_h = (boolean)"".length();
               I[115 ^ 109].length();
               throw var10;
            }

            this.field_194020_g.clear();
            this.field_194021_h = (boolean)"".length();
            return var7;
         }

         this.field_194020_g.clear();
         this.field_194021_h = (boolean)"".length();
         "".length();
         if (2 != 2) {
            throw null;
         } else {
            return var4;
         }
      }
   }

   public void func_193059_f() {
      this.field_193070_d.clear();
      this.field_193072_f = null;
      this.field_193071_e = I[112 ^ 111];
      this.func_193061_h();
   }

   public Map<ResourceLocation, FunctionObject> func_193066_d() {
      return this.field_193070_d;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= -1);

      throw null;
   }

   public static class QueuedCommand {
      // $FF: synthetic field
      private final FunctionObject.Entry field_194225_c;
      // $FF: synthetic field
      private final ICommandSender field_194224_b;
      // $FF: synthetic field
      private final FunctionManager field_194223_a;

      public QueuedCommand(FunctionManager var1, ICommandSender var2, FunctionObject.Entry var3) {
         this.field_194223_a = var1;
         this.field_194224_b = var2;
         this.field_194225_c = var3;
      }

      public String toString() {
         return this.field_194225_c.toString();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > 2);

         throw null;
      }

      public void func_194222_a(ArrayDeque<FunctionManager.QueuedCommand> var1, int var2) {
         this.field_194225_c.func_194145_a(this.field_194223_a, this.field_194224_b, var1, var2);
      }
   }
}

package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class ItemDurabilityTrigger implements ICriterionTrigger<ItemDurabilityTrigger.Instance> {
   // $FF: synthetic field
   private final Map<PlayerAdvancements, ItemDurabilityTrigger.Listeners> field_193160_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final ResourceLocation field_193159_a;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<ItemDurabilityTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      ItemDurabilityTrigger.Listeners var3 = (ItemDurabilityTrigger.Listeners)this.field_193160_b.get(var1);
      if (var3 == null) {
         I[93 ^ 89].length();
         I[81 ^ 84].length();
         I[198 ^ 192].length();
         I[142 ^ 137].length();
         var3 = new ItemDurabilityTrigger.Listeners(var1);
         this.field_193160_b.put(var1, var3);
         I[116 ^ 124].length();
         I[91 ^ 82].length();
         I[32 ^ 42].length();
      }

      var3.func_193440_a(var2);
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193160_b.remove(var1);
      I[190 ^ 177].length();
      I[62 ^ 46].length();
   }

   public ResourceLocation func_192163_a() {
      return field_193159_a;
   }

   private static void I() {
      I = new String[19 ^ 15];
      I["".length()] = I("勊宨", "qaclk");
      I[" ".length()] = I("桥溤", "sfiaw");
      I["  ".length()] = I("夼澯", "GoeAJ");
      I["   ".length()] = I("扂傚", "JMJjS");
      I[65 ^ 69] = I("曃妢", "EvFDe");
      I[75 ^ 78] = I("挪", "TeoHT");
      I[112 ^ 118] = I("嗾凧凂媁", "crMFq");
      I[80 ^ 87] = I("嬾兠", "sMIdm");
      I[97 ^ 105] = I("徛欍姒", "wMapa");
      I[178 ^ 187] = I("倶孞旍柈", "FKlQW");
      I[102 ^ 108] = I("刅掿丹", "BvGbk");
      I[123 ^ 112] = I("擿偈压感", "mGSaS");
      I[84 ^ 88] = I("堯咇潂", "BPjNT");
      I[92 ^ 81] = I("忨乒姦", "gsyFJ");
      I[68 ^ 74] = I("暘栢", "LOnXK");
      I[202 ^ 197] = I("圷櫓烎", "VEgbv");
      I[215 ^ 199] = I("塿孱媩潜", "WAThX");
      I[25 ^ 8] = I("咄瀻", "zCslj");
      I[111 ^ 125] = I("刘摦", "UNLsY");
      I[67 ^ 80] = I("毫愅", "Otvdo");
      I[144 ^ 132] = I("刋娥", "TwJar");
      I[149 ^ 128] = I("8\u000e=)", "QzXDb");
      I[26 ^ 12] = I(">\u001d4-/3\u0004/84", "ZhFLM");
      I[166 ^ 177] = I("+\u001c\u001a\f(", "OyvxI");
      I[178 ^ 170] = I("埣姻廐凶", "TjcsB");
      I[27 ^ 2] = I("殭彀囌斘", "FIPHU");
      I[86 ^ 76] = I("姢滸巶崂攨", "ZlVZC");
      I[56 ^ 35] = I("%-4\u000b0(,#\u0007\r%58\u0012\u0016\u0013:9\u0007\u0001+<5", "LYQfo");
   }

   public ItemDurabilityTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[101 ^ 116];
      String var10001 = I[149 ^ 135];
      String var10002 = I[21 ^ 6];
      var10001 = I[153 ^ 141];
      ItemPredicate var3 = ItemPredicate.func_192492_a(var1.get(I[144 ^ 133]));
      MinMaxBounds var4 = MinMaxBounds.func_192515_a(var1.get(I[27 ^ 13]));
      MinMaxBounds var5 = MinMaxBounds.func_192515_a(var1.get(I[90 ^ 77]));
      I[48 ^ 40].length();
      I[150 ^ 143].length();
      I[6 ^ 28].length();
      return new ItemDurabilityTrigger.Instance(var3, var4, var5);
   }

   static {
      I();
      field_193159_a = new ResourceLocation(I[103 ^ 124]);
   }

   public void func_193158_a(EntityPlayerMP var1, ItemStack var2, int var3) {
      ItemDurabilityTrigger.Listeners var4 = (ItemDurabilityTrigger.Listeners)this.field_193160_b.get(var1.func_192039_O());
      if (var4 != null) {
         var4.func_193441_a(var2, var3);
      }

   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<ItemDurabilityTrigger.Instance> var2) {
      ItemDurabilityTrigger.Listeners var3 = (ItemDurabilityTrigger.Listeners)this.field_193160_b.get(var1);
      if (var3 != null) {
         var3.func_193438_b(var2);
         if (var3.func_193439_a()) {
            this.field_193160_b.remove(var1);
            I[1 ^ 10].length();
            I[118 ^ 122].length();
            I[174 ^ 163].length();
            I[78 ^ 64].length();
         }
      }

   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<ItemDurabilityTrigger.Instance>> field_193443_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_193442_a;
      // $FF: synthetic field
      private static final String[] I;

      private static void I() {
         I = new String[158 ^ 151];
         I["".length()] = I("瀾", "cbfNz");
         I[" ".length()] = I("濶佄浥僇壌", "fTtgd");
         I["  ".length()] = I("漻伍", "zNyEV");
         I["   ".length()] = I("棲揓攄偈", "GYggR");
         I[52 ^ 48] = I("曝椀仒楨", "sxHGW");
         I[106 ^ 111] = I("偆卒嫁彘", "yBCOu");
         I[5 ^ 3] = I("峞姬傑僇", "yTJBb");
         I[156 ^ 155] = I("劚彃椷挘", "xUKtC");
         I[42 ^ 34] = I("氮毲慷", "EiyAu");
      }

      public void func_193438_b(ICriterionTrigger.Listener<ItemDurabilityTrigger.Instance> var1) {
         this.field_193443_b.remove(var1);
         I[194 ^ 198].length();
         I[112 ^ 117].length();
      }

      public void func_193440_a(ICriterionTrigger.Listener<ItemDurabilityTrigger.Instance> var1) {
         this.field_193443_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }

      public boolean func_193439_a() {
         return this.field_193443_b.isEmpty();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 != 1);

         throw null;
      }

      public void func_193441_a(ItemStack var1, int var2) {
         ArrayList var3 = null;
         Iterator var4 = this.field_193443_b.iterator();

         ICriterionTrigger.Listener var5;
         while(var4.hasNext()) {
            var5 = (ICriterionTrigger.Listener)var4.next();
            if (((ItemDurabilityTrigger.Instance)var5.func_192158_a()).func_193197_a(var1, var2)) {
               if (var3 == null) {
                  var3 = Lists.newArrayList();
               }

               var3.add(var5);
               I[131 ^ 133].length();
               I[184 ^ 191].length();
               I[179 ^ 187].length();
            }

            "".length();
            if (-1 < -1) {
               throw null;
            }
         }

         if (var3 != null) {
            var4 = var3.iterator();

            while(var4.hasNext()) {
               var5 = (ICriterionTrigger.Listener)var4.next();
               var5.func_192159_a(this.field_193442_a);
               "".length();
               if (-1 >= 0) {
                  throw null;
               }
            }
         }

      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193442_a = var1;
      }

      static {
         I();
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final MinMaxBounds field_193199_b;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final MinMaxBounds field_193200_c;
      // $FF: synthetic field
      private final ItemPredicate field_193198_a;

      public boolean func_193197_a(ItemStack var1, int var2) {
         if (!this.field_193198_a.func_192493_a(var1)) {
            return (boolean)"".length();
         } else {
            MinMaxBounds var10000 = this.field_193199_b;
            int var10001 = var1.getMaxDamage();
            I["".length()].length();
            I[" ".length()].length();
            if (!var10000.func_192514_a((float)(var10001 - var2))) {
               return (boolean)"".length();
            } else {
               var10000 = this.field_193200_c;
               var10001 = var1.getItemDamage();
               I["  ".length()].length();
               I["   ".length()].length();
               return var10000.func_192514_a((float)(var10001 - var2));
            }
         }
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 == 3);

         throw null;
      }

      public Instance(ItemPredicate var1, MinMaxBounds var2, MinMaxBounds var3) {
         super(ItemDurabilityTrigger.field_193159_a);
         this.field_193198_a = var1;
         this.field_193199_b = var2;
         this.field_193200_c = var3;
      }

      static {
         I();
      }

      private static void I() {
         I = new String[82 ^ 86];
         I["".length()] = I("母", "KRhfd");
         I[" ".length()] = I("悒杁柙", "qgLPV");
         I["  ".length()] = I("儬娕", "rVWHA");
         I["   ".length()] = I("溒佳峂", "kfwqN");
      }
   }
}

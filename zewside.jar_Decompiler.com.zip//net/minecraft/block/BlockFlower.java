package net.minecraft.block;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import java.util.Collection;
import javax.annotation.Nullable;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public abstract class BlockFlower extends BlockBush {
   // $FF: synthetic field
   protected PropertyEnum<BlockFlower.EnumFlowerType> type;
   // $FF: synthetic field
   private static final String[] I;

   public Block.EnumOffsetType getOffsetType() {
      return Block.EnumOffsetType.XZ;
   }

   public abstract BlockFlower.EnumFlowerColor getBlockType();

   protected BlockFlower() {
      IBlockState var10001 = this.blockState.getBaseState();
      IProperty var10002 = this.getTypeProperty();
      BlockFlower.EnumFlowerType var10003;
      if (this.getBlockType() == BlockFlower.EnumFlowerColor.RED) {
         var10003 = BlockFlower.EnumFlowerType.POPPY;
         "".length();
         if (4 == 1) {
            throw null;
         }
      } else {
         var10003 = BlockFlower.EnumFlowerType.DANDELION;
      }

      this.setDefaultState(var10001.withProperty(var10002, var10003));
   }

   private static void I() {
      I = new String[32 ^ 58];
      I["".length()] = I("沍古", "xQKlg");
      I[" ".length()] = I("炈前", "xnCzR");
      I["  ".length()] = I("拃攚", "uQOFT");
      I["   ".length()] = I("冗卷", "xGBhG");
      I[54 ^ 50] = I("樅歹嬟侪楎", "eHuXR");
      I[185 ^ 188] = I("侉汴厢", "faLHN");
      I[182 ^ 176] = I("堫榃凵", "KvWhz");
      I[124 ^ 123] = I("塵媕", "jOQOe");
      I[57 ^ 49] = I("丵洖", "SjWWK");
      I[156 ^ 149] = I("挰塊", "dmfGb");
      I[115 ^ 121] = I("伭朹", "oyjkD");
      I[174 ^ 165] = I("涍囄", "clbeV");
      I[206 ^ 194] = I("\"=\u0015\u000f", "VDejW");
      I[49 ^ 60] = I("寇並囂寧", "NCKsK");
      I[30 ^ 16] = I("楃桓", "yFISJ");
      I[76 ^ 67] = I("氻欜", "EfGLZ");
      I[79 ^ 95] = I("屭婕", "GysyH");
      I[59 ^ 42] = I("歶擆", "RrdGR");
      I[181 ^ 167] = I("掐撳", "EUnIS");
      I[149 ^ 134] = I("懄恅", "ogwUU");
      I[43 ^ 63] = I("浿揼", "CUuOm");
      I[41 ^ 60] = I("啂沆", "MfdGI");
      I[54 ^ 32] = I("悋淭攖", "rrqug");
      I[147 ^ 132] = I("摤椬奙", "fFIOX");
      I[113 ^ 105] = I("澡搊僌殤傔", "VJEwk");
      I[82 ^ 75] = I("俥岖捭", "DxLgC");
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockFlower.EnumFlowerType)var1.getValue(this.getTypeProperty())).getMeta();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockFlower.EnumFlowerType)var1.getValue(this.getTypeProperty())).getMeta();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[157 ^ 147];
      String var10001 = I[160 ^ 175];
      String var10002 = I[90 ^ 74];
      var10001 = I[111 ^ 126];
      var10000 = I[190 ^ 172];
      var10001 = I[44 ^ 63];
      var10002 = I[7 ^ 19];
      var10001 = I[214 ^ 195];
      I[58 ^ 44].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[154 ^ 141].length();
      I[143 ^ 151].length();
      I[102 ^ 127].length();
      var10003["".length()] = this.getTypeProperty();
      return new BlockStateContainer(this, var10003);
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      BlockFlower.EnumFlowerType[] var3 = BlockFlower.EnumFlowerType.getTypes(this.getBlockType());
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockFlower.EnumFlowerType var6 = var3[var5];
         I[20 ^ 16].length();
         I[23 ^ 18].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMeta()));
         I[90 ^ 92].length();
         I[94 ^ 89].length();
         ++var5;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return super.getBoundingBox(var1, var2, var3).func_191194_a(var1.func_191059_e(var2, var3));
   }

   public IProperty<BlockFlower.EnumFlowerType> getTypeProperty() {
      String var10000 = I[60 ^ 52];
      String var10001 = I[155 ^ 146];
      String var10002 = I[64 ^ 74];
      var10001 = I[207 ^ 196];
      if (this.type == null) {
         var10001 = I[85 ^ 89];
         I[113 ^ 124].length();
         this.type = PropertyEnum.create(var10001, BlockFlower.EnumFlowerType.class, new Predicate<BlockFlower.EnumFlowerType>() {
            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(4 > 3);

               throw null;
            }

            public boolean apply(@Nullable BlockFlower.EnumFlowerType var1) {
               int var10000;
               if (var1.getBlockType() == BlockFlower.this.getBlockType()) {
                  var10000 = " ".length();
                  "".length();
                  if (2 == 0) {
                     throw null;
                  }
               } else {
                  var10000 = "".length();
               }

               return (boolean)var10000;
            }
         });
      }

      return this.type;
   }

   static {
      I();
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(this.getTypeProperty(), BlockFlower.EnumFlowerType.getType(this.getBlockType(), var1));
   }

   public static enum EnumFlowerType implements IStringSerializable {
      // $FF: synthetic field
      RED_TULIP;

      // $FF: synthetic field
      private final BlockFlower.EnumFlowerColor blockType;
      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      BLUE_ORCHID,
      // $FF: synthetic field
      DANDELION,
      // $FF: synthetic field
      ORANGE_TULIP,
      // $FF: synthetic field
      POPPY;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      WHITE_TULIP,
      // $FF: synthetic field
      HOUSTONIA;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private static final BlockFlower.EnumFlowerType[][] TYPES_FOR_BLOCK;
      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      PINK_TULIP,
      // $FF: synthetic field
      ALLIUM,
      // $FF: synthetic field
      OXEYE_DAISY;

      public String getName() {
         return this.name;
      }

      public int getMeta() {
         return this.meta;
      }

      public String toString() {
         return this.name;
      }

      static {
         I();
         DANDELION = new BlockFlower.EnumFlowerType(I["".length()], "".length(), BlockFlower.EnumFlowerColor.YELLOW, "".length(), I[" ".length()]);
         POPPY = new BlockFlower.EnumFlowerType(I["  ".length()], " ".length(), BlockFlower.EnumFlowerColor.RED, "".length(), I["   ".length()]);
         BLUE_ORCHID = new BlockFlower.EnumFlowerType(I[163 ^ 167], "  ".length(), BlockFlower.EnumFlowerColor.RED, " ".length(), I[183 ^ 178], I[184 ^ 190]);
         ALLIUM = new BlockFlower.EnumFlowerType(I[4 ^ 3], "   ".length(), BlockFlower.EnumFlowerColor.RED, "  ".length(), I[51 ^ 59]);
         HOUSTONIA = new BlockFlower.EnumFlowerType(I[35 ^ 42], 13 ^ 9, BlockFlower.EnumFlowerColor.RED, "   ".length(), I[171 ^ 161]);
         RED_TULIP = new BlockFlower.EnumFlowerType(I[76 ^ 71], 76 ^ 73, BlockFlower.EnumFlowerColor.RED, 149 ^ 145, I[142 ^ 130], I[126 ^ 115]);
         ORANGE_TULIP = new BlockFlower.EnumFlowerType(I[56 ^ 54], 31 ^ 25, BlockFlower.EnumFlowerColor.RED, 133 ^ 128, I[166 ^ 169], I[47 ^ 63]);
         WHITE_TULIP = new BlockFlower.EnumFlowerType(I[137 ^ 152], 18 ^ 21, BlockFlower.EnumFlowerColor.RED, 26 ^ 28, I[0 ^ 18], I[94 ^ 77]);
         PINK_TULIP = new BlockFlower.EnumFlowerType(I[68 ^ 80], 39 ^ 47, BlockFlower.EnumFlowerColor.RED, 34 ^ 37, I[132 ^ 145], I[149 ^ 131]);
         OXEYE_DAISY = new BlockFlower.EnumFlowerType(I[1 ^ 22], 17 ^ 24, BlockFlower.EnumFlowerColor.RED, 169 ^ 161, I[16 ^ 8], I[172 ^ 181]);
         BlockFlower.EnumFlowerType[] var10000 = new BlockFlower.EnumFlowerType[130 ^ 136];
         var10000["".length()] = DANDELION;
         var10000[" ".length()] = POPPY;
         var10000["  ".length()] = BLUE_ORCHID;
         var10000["   ".length()] = ALLIUM;
         var10000[131 ^ 135] = HOUSTONIA;
         var10000[63 ^ 58] = RED_TULIP;
         var10000[154 ^ 156] = ORANGE_TULIP;
         var10000[152 ^ 159] = WHITE_TULIP;
         var10000[28 ^ 20] = PINK_TULIP;
         var10000[142 ^ 135] = OXEYE_DAISY;
         TYPES_FOR_BLOCK = new BlockFlower.EnumFlowerType[BlockFlower.EnumFlowerColor.values().length][];
         BlockFlower.EnumFlowerColor[] var0 = BlockFlower.EnumFlowerColor.values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            final BlockFlower.EnumFlowerColor var3 = var0[var2];
            Collection var4 = Collections2.filter(Lists.newArrayList(values()), new Predicate<BlockFlower.EnumFlowerType>() {
               public boolean apply(@Nullable BlockFlower.EnumFlowerType var1) {
                  int var10000;
                  if (var1.getBlockType() == var3) {
                     var10000 = " ".length();
                     "".length();
                     if (3 < 0) {
                        throw null;
                     }
                  } else {
                     var10000 = "".length();
                  }

                  return (boolean)var10000;
               }

               private static String I(String s, String s1) {
                  StringBuilder sb = new StringBuilder();
                  char[] key = s1.toCharArray();
                  int i = "".length();
                  char[] var5 = s.toCharArray();
                  int var6 = var5.length;
                  int var7 = "".length();

                  do {
                     if (var7 >= var6) {
                        return sb.toString();
                     }

                     char c = var5[var7];
                     sb.append((char)(c ^ key[i % key.length]));
                     ++i;
                     ++var7;
                     "".length();
                  } while(4 >= 4);

                  throw null;
               }
            });
            TYPES_FOR_BLOCK[var3.ordinal()] = (BlockFlower.EnumFlowerType[])((BlockFlower.EnumFlowerType[])var4.toArray(new BlockFlower.EnumFlowerType[var4.size()]));
            ++var2;
            "".length();
         } while(true);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 >= -1);

         throw null;
      }

      private static void I() {
         I = new String[161 ^ 187];
         I["".length()] = I("\b\u0012?1\u000e\u0000\u001a>;", "LSquK");
         I[" ".length()] = I("6+!(\u0011># \"", "RJOLt");
         I["  ".length()] = I("5(\u0018\u0013>", "egHCg");
         I["   ".length()] = I("<\b6 \u0018", "LgFPa");
         I[171 ^ 175] = I("2\u001e12\u001c?\u0000'?\n4", "pRdwC");
         I[161 ^ 164] = I(")\u001b\u001a1)$\u0005\f<\u001f/", "KwoTv");
         I[157 ^ 155] = I("0\u001b,7\u0018 \u00141;3", "RwYRW");
         I[111 ^ 104] = I(",\u0000*\u0019\u0013 ", "mLfPF");
         I[62 ^ 54] = I("\"&\u0015\u001e\u001b.", "CJywn");
         I[143 ^ 134] = I("\u000e\b>\u0004\u000e\t\t\"\u0016", "FGkWZ");
         I[82 ^ 88] = I("\u000f-2\n\u0001\b,.\u0018", "gBGyu");
         I[177 ^ 186] = I("\u0016\f\u0000\u0006;\u0011\u0005\r\t", "DIDYo");
         I[150 ^ 154] = I("<\u0011\u000f\u001d0;\u0018\u00022", "NtkBD");
         I[67 ^ 78] = I("\u0016\u0011?,\u00160\u00017", "bdSEf");
         I[23 ^ 25] = I("#\n\u0014\u0007\u0016)\u0007\u0001\u001c\u001d%\b", "lXUIQ");
         I[79 ^ 64] = I("9\u0005\u000b4\u00013(\u001e/\n?\u0007", "VwjZf");
         I[133 ^ 149] = I("5\u0019-?*\u000e\u001e 8=$", "AlAVZ");
         I[137 ^ 152] = I("\u001f\u0006'\u0018\u000f\u0017\u001a;\u0000\u0003\u0018", "HNnLJ");
         I[148 ^ 134] = I("\u000f \u0013\u0018&'<\u000f\u0000*\b", "xHzlC");
         I[64 ^ 83] = I("\u0015\r \u0004\u00136\u0010%\u0019\u0006", "axLmc");
         I[96 ^ 116] = I("\u0004 \b:\u0011\u0000<\n8\u001e", "TiFqN");
         I[30 ^ 11] = I("\u0005$\u0003>6\u00018\u0001<\u0019", "uMmUi");
         I[212 ^ 194] = I("<\u0018'\u0000\u0001\u0018\u0004%\u0002", "HmKiq");
         I[114 ^ 101] = I("=\f--\u000b-\u0010)=\u001d+", "rThtN");
         I[50 ^ 42] = I("*5' \u001d\u001a)#0\u000b<", "EMBYx");
         I[169 ^ 176] = I("\u000e(7#\t%1;)\u0015", "aPRZl");
      }

      private EnumFlowerType(BlockFlower.EnumFlowerColor var3, int var4, String var5) {
         this(var3, var4, var5, var5);
      }

      public static BlockFlower.EnumFlowerType[] getTypes(BlockFlower.EnumFlowerColor var0) {
         return TYPES_FOR_BLOCK[var0.ordinal()];
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      public static BlockFlower.EnumFlowerType getType(BlockFlower.EnumFlowerColor var0, int var1) {
         BlockFlower.EnumFlowerType[] var2 = TYPES_FOR_BLOCK[var0.ordinal()];
         if (var1 < 0 || var1 >= var2.length) {
            var1 = "".length();
         }

         return var2[var1];
      }

      private EnumFlowerType(BlockFlower.EnumFlowerColor var3, int var4, String var5, String var6) {
         this.blockType = var3;
         this.meta = var4;
         this.name = var5;
         this.unlocalizedName = var6;
      }

      public BlockFlower.EnumFlowerColor getBlockType() {
         return this.blockType;
      }
   }

   public static enum EnumFlowerColor {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      RED,
      // $FF: synthetic field
      YELLOW;

      static {
         I();
         YELLOW = new BlockFlower.EnumFlowerColor(I["".length()], "".length());
         RED = new BlockFlower.EnumFlowerColor(I[" ".length()], " ".length());
         BlockFlower.EnumFlowerColor[] var10000 = new BlockFlower.EnumFlowerColor["  ".length()];
         var10000["".length()] = YELLOW;
         var10000[" ".length()] = RED;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I("\u001d\b-\t:\u0013", "DMaEu");
         I[" ".length()] = I("&\u0013\u001c", "tVXOB");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(true);

         throw null;
      }

      public BlockFlower getBlock() {
         BlockFlower var10000;
         if (this == YELLOW) {
            var10000 = Blocks.YELLOW_FLOWER;
            "".length();
            if (0 <= -1) {
               throw null;
            }
         } else {
            var10000 = Blocks.RED_FLOWER;
         }

         return var10000;
      }
   }
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;

public class BlockStone extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockStone.EnumType> VARIANT;

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return ((BlockStone.EnumType)var1.getValue(VARIANT)).getMapColor();
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockStone.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockStone.EnumType.byMetadata(var1));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != 2);

      throw null;
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockStone.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[154 ^ 146];
      String var10001 = I[54 ^ 63];
      String var10002 = I[5 ^ 15];
      var10001 = I[0 ^ 11];
      BlockStone.EnumType[] var3 = BlockStone.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockStone.EnumType var6 = var3[var5];
         I[20 ^ 24].length();
         I[91 ^ 86].length();
         I[125 ^ 115].length();
         I[86 ^ 89].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[117 ^ 101].length();
         I[109 ^ 124].length();
         I[130 ^ 144].length();
         I[176 ^ 163].length();
         ++var5;
         "".length();
      } while(3 > 1);

      throw null;
   }

   public BlockStone() {
      super(Material.ROCK);
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockStone.EnumType.STONE));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[168 ^ 137], BlockStone.EnumType.class);
   }

   public String getLocalizedName() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[92 ^ 88].length();
      I[72 ^ 77].length();
      return I18n.translateToLocal(this.getUnlocalizedName() + I[182 ^ 176] + BlockStone.EnumType.STONE.getUnlocalizedName() + I[102 ^ 97]);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[37 ^ 49];
      String var10001 = I[167 ^ 178];
      String var10002 = I[141 ^ 155];
      var10001 = I[87 ^ 64];
      var10000 = I[151 ^ 143];
      var10001 = I[12 ^ 21];
      var10002 = I[153 ^ 131];
      var10001 = I[23 ^ 12];
      I[186 ^ 166].length();
      I[148 ^ 137].length();
      I[2 ^ 28].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[172 ^ 179].length();
      I[130 ^ 162].length();
      var10003["".length()] = VARIANT;
      return new BlockStateContainer(this, var10003);
   }

   private static void I() {
      I = new String[67 ^ 97];
      I["".length()] = I("婊晷", "imrVh");
      I[" ".length()] = I("涩娇", "AriZA");
      I["  ".length()] = I("坢忸", "KvOTk");
      I["   ".length()] = I("撼刾", "GHlrm");
      I[0 ^ 4] = I("潵併夳揎岁", "eeOVp");
      I[67 ^ 70] = I("伫掑峝", "yPlCo");
      I[167 ^ 161] = I("D", "jGAnM");
      I[185 ^ 190] = I("B62\u0015'", "lXSxB");
      I[32 ^ 40] = I("栵淀", "JUOCY");
      I[65 ^ 72] = I("嗧撇", "YHTlY");
      I[9 ^ 3] = I("坌嫷", "cxeKT");
      I[36 ^ 47] = I("抹暣", "fbJiJ");
      I[118 ^ 122] = I("樰揄減拙澦", "aUzZS");
      I[71 ^ 74] = I("嗽杝液搏", "sCJIt");
      I[19 ^ 29] = I("是恎媅", "WKmDo");
      I[31 ^ 16] = I("夰挎徬", "vMYxF");
      I[9 ^ 25] = I("櫬", "oZrbl");
      I[41 ^ 56] = I("扟", "mIflL");
      I[142 ^ 156] = I("幖懛撥屡", "gMglU");
      I[114 ^ 97] = I("亾搧戇", "PlLAN");
      I[52 ^ 32] = I("墳喈", "sZBTp");
      I[94 ^ 75] = I("勺怆", "fTlZv");
      I[84 ^ 66] = I("奨摊", "DJSeF");
      I[81 ^ 70] = I("攪僸", "TeUrq");
      I[22 ^ 14] = I("椲庰", "lStWk");
      I[32 ^ 57] = I("婀媧", "KEKrG");
      I[16 ^ 10] = I("嵁屜", "KeuXz");
      I[66 ^ 89] = I("割杊", "ZxZIM");
      I[21 ^ 9] = I("唗滳噓", "ZoFyP");
      I[187 ^ 166] = I("坒氢剨塣椿", "pBhPb");
      I[115 ^ 109] = I("坂噀孷", "iENtm");
      I[139 ^ 148] = I("曯椾妇枑恅", "vRoec");
      I[30 ^ 62] = I("妇涯壂晩", "mfZaT");
      I[154 ^ 187] = I("\u0000'\u0018&\u0014\u00182", "vFjOu");
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      Item var10000;
      if (var1.getValue(VARIANT) == BlockStone.EnumType.STONE) {
         var10000 = Item.getItemFromBlock(Blocks.COBBLESTONE);
         "".length();
         if (3 <= 1) {
            throw null;
         }
      } else {
         var10000 = Item.getItemFromBlock(Blocks.STONE);
      }

      return var10000;
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      GRANITE_SMOOTH,
      // $FF: synthetic field
      STONE,
      // $FF: synthetic field
      GRANITE,
      // $FF: synthetic field
      ANDESITE_SMOOTH,
      // $FF: synthetic field
      DIORITE_SMOOTH,
      // $FF: synthetic field
      ANDESITE;

      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      DIORITE;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final boolean field_190913_m;
      // $FF: synthetic field
      private final MapColor mapColor;

      public static BlockStone.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      private static void I() {
         I = new String[169 ^ 184];
         I["".length()] = I("\u0004\r!\u001c\t", "WYnRL");
         I[" ".length()] = I("\u0011\u0015\t#&", "bafMC");
         I["  ".length()] = I("\u001d\u0015\u0016)\u0011\u000e\u0002", "ZGWgX");
         I["   ".length()] = I("\u00147.\u0006;\u0007 ", "sEOhR");
         I[41 ^ 45] = I(".#5\u001e>=4+\u0003:&> \u0018", "iqtPw");
         I[150 ^ 147] = I("6\u000b\u0006)\u0016-9\u000e4\u0003+\u000f\u001d#", "EfiFb");
         I[80 ^ 86] = I("\u000e!)\u0002-\u001d6\u001b\u0001+\u0006' ", "iSHlD");
         I[140 ^ 139] = I("\u0011 !\u0015\u001e\u0001,", "UinGW");
         I[34 ^ 42] = I("\u00038(=1\u00134", "gQGOX");
         I[99 ^ 106] = I(",;\u0005\u001a;<7\u0015\u001b?'=\u001e\u0000", "hrJHr");
         I[7 ^ 13] = I("7'\b\u000b>,\u0015\u0003\r%6#\u0013\u0001", "DJgdJ");
         I[205 ^ 198] = I(".!\"\u0010\b>-\u001e\u000f\u000e%<%", "JHMba");
         I[89 ^ 85] = I("5!\u000f\u001f?=;\u000e", "toKZl");
         I[58 ^ 55] = I("\u0010+ )5\u00181!", "qEDLF");
         I[83 ^ 93] = I("\u0010)\u0014 +\u00183\u0015:+\u001c(\u001f10", "QgPex");
         I[134 ^ 137] = I("\u0011=.\u000b<\n\u000f \n,\u0007#(\u0010-", "bPAdH");
         I[53 ^ 37] = I("#/\u000b\u0002\u001b+5\n4\u0005-.\u001b\u000f", "BAogh");
      }

      static {
         I();
         STONE = new BlockStone.EnumType(I["".length()], "".length(), "".length(), MapColor.STONE, I[" ".length()], (boolean)" ".length());
         GRANITE = new BlockStone.EnumType(I["  ".length()], " ".length(), " ".length(), MapColor.DIRT, I["   ".length()], (boolean)" ".length());
         GRANITE_SMOOTH = new BlockStone.EnumType(I[151 ^ 147], "  ".length(), "  ".length(), MapColor.DIRT, I[65 ^ 68], I[48 ^ 54], (boolean)"".length());
         DIORITE = new BlockStone.EnumType(I[175 ^ 168], "   ".length(), "   ".length(), MapColor.QUARTZ, I[128 ^ 136], (boolean)" ".length());
         DIORITE_SMOOTH = new BlockStone.EnumType(I[153 ^ 144], 161 ^ 165, 155 ^ 159, MapColor.QUARTZ, I[21 ^ 31], I[37 ^ 46], (boolean)"".length());
         ANDESITE = new BlockStone.EnumType(I[173 ^ 161], 178 ^ 183, 45 ^ 40, MapColor.STONE, I[174 ^ 163], (boolean)" ".length());
         ANDESITE_SMOOTH = new BlockStone.EnumType(I[35 ^ 45], 195 ^ 197, 191 ^ 185, MapColor.STONE, I[205 ^ 194], I[86 ^ 70], (boolean)"".length());
         BlockStone.EnumType[] var10000 = new BlockStone.EnumType[125 ^ 122];
         var10000["".length()] = STONE;
         var10000[" ".length()] = GRANITE;
         var10000["  ".length()] = GRANITE_SMOOTH;
         var10000["   ".length()] = DIORITE;
         var10000[191 ^ 187] = DIORITE_SMOOTH;
         var10000[171 ^ 174] = ANDESITE;
         var10000[20 ^ 18] = ANDESITE_SMOOTH;
         BlockStone.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockStone.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(1 < 3);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 == 3);

         throw null;
      }

      private EnumType(int var3, MapColor var4, String var5, boolean var6) {
         this(var3, var4, var5, var5, var6);
      }

      public MapColor getMapColor() {
         return this.mapColor;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      public boolean func_190912_e() {
         return this.field_190913_m;
      }

      public int getMetadata() {
         return this.meta;
      }

      public String getName() {
         return this.name;
      }

      private EnumType(int var3, MapColor var4, String var5, String var6, boolean var7) {
         this.meta = var3;
         this.name = var5;
         this.unlocalizedName = var6;
         this.mapColor = var4;
         this.field_190913_m = var7;
      }

      public String toString() {
         return this.name;
      }
   }
}

package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;

public class TickTrigger implements ICriterionTrigger<TickTrigger.Instance> {
   // $FF: synthetic field
   public static final ResourceLocation field_193183_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, TickTrigger.Listeners> field_193184_b = Maps.newHashMap();

   public ResourceLocation func_192163_a() {
      return field_193183_a;
   }

   static {
      I();
      field_193183_a = new ResourceLocation(I[209 ^ 198]);
   }

   public void func_193182_a(EntityPlayerMP var1) {
      TickTrigger.Listeners var2 = (TickTrigger.Listeners)this.field_193184_b.get(var1.func_192039_O());
      if (var2 != null) {
         var2.func_193503_b();
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 >= -1);

      throw null;
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193184_b.remove(var1);
      I[145 ^ 154].length();
      I[48 ^ 60].length();
      I[99 ^ 110].length();
      I[38 ^ 40].length();
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<TickTrigger.Instance> var2) {
      TickTrigger.Listeners var3 = (TickTrigger.Listeners)this.field_193184_b.get(var1);
      if (var3 != null) {
         var3.func_193500_b(var2);
         if (var3.func_193501_a()) {
            this.field_193184_b.remove(var1);
            I[178 ^ 184].length();
         }
      }

   }

   private static void I() {
      I = new String[4 ^ 28];
      I["".length()] = I("檖器", "GrWow");
      I[" ".length()] = I("控拤", "cktEw");
      I["  ".length()] = I("恘汤", "HGBpW");
      I["   ".length()] = I("煣彡", "REKeE");
      I[120 ^ 124] = I("悇嫕", "xjNhK");
      I[127 ^ 122] = I("捠", "iTDul");
      I[127 ^ 121] = I("捙澝廁", "wkngG");
      I[58 ^ 61] = I("氬櫮", "ZygFX");
      I[40 ^ 32] = I("塥深拭", "ECImL");
      I[148 ^ 157] = I("杣", "eaLJg");
      I[166 ^ 172] = I("嚧揪棪侠晳", "jQpMS");
      I[101 ^ 110] = I("榰俚到乫嗣", "llKML");
      I[22 ^ 26] = I("嶢噧欸擞嶙", "VhPYa");
      I[121 ^ 116] = I("柊孮孝椐", "hZKyA");
      I[57 ^ 55] = I("庐庐崬", "LsPee");
      I[156 ^ 147] = I("幜湇", "zLhdr");
      I[115 ^ 99] = I("彈婨", "sEpKe");
      I[99 ^ 114] = I("撌嘺", "MDmGh");
      I[108 ^ 126] = I("噴漜", "UOAEn");
      I[167 ^ 180] = I("愤捪寠", "PVufV");
      I[5 ^ 17] = I("奅宆", "ThPyD");
      I[69 ^ 80] = I("憫", "CpUSW");
      I[6 ^ 16] = I("旸叵", "zvsCp");
      I[20 ^ 3] = I(":+3\u0019", "NBPrh");
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<TickTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      TickTrigger.Listeners var3 = (TickTrigger.Listeners)this.field_193184_b.get(var1);
      if (var3 == null) {
         I[56 ^ 60].length();
         I[116 ^ 113].length();
         I[169 ^ 175].length();
         I[60 ^ 59].length();
         var3 = new TickTrigger.Listeners(var1);
         this.field_193184_b.put(var1, var3);
         I[170 ^ 162].length();
         I[179 ^ 186].length();
      }

      var3.func_193502_a(var2);
   }

   public TickTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[30 ^ 17];
      String var10001 = I[132 ^ 148];
      String var10002 = I[40 ^ 57];
      var10001 = I[123 ^ 105];
      I[119 ^ 100].length();
      I[126 ^ 106].length();
      I[96 ^ 117].length();
      I[214 ^ 192].length();
      return new TickTrigger.Instance();
   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_193504_a;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<TickTrigger.Instance>> field_193505_b = Sets.newHashSet();
      // $FF: synthetic field
      private static final String[] I;

      static {
         I();
      }

      public void func_193503_b() {
         Iterator var1 = Lists.newArrayList(this.field_193505_b).iterator();

         do {
            if (!var1.hasNext()) {
               return;
            }

            ICriterionTrigger.Listener var2 = (ICriterionTrigger.Listener)var1.next();
            var2.func_192159_a(this.field_193504_a);
            "".length();
         } while(3 < 4);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(true);

         throw null;
      }

      private static void I() {
         I = new String[86 ^ 82];
         I["".length()] = I("孿曢廵桅", "VhUVI");
         I[" ".length()] = I("呻幒汕倭晜", "XgqWj");
         I["  ".length()] = I("抠墺彆暵", "LrGsT");
         I["   ".length()] = I("施央呟", "AgtFW");
      }

      public void func_193502_a(ICriterionTrigger.Listener<TickTrigger.Instance> var1) {
         this.field_193505_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      public boolean func_193501_a() {
         return this.field_193505_b.isEmpty();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193504_a = var1;
      }

      public void func_193500_b(ICriterionTrigger.Listener<TickTrigger.Instance> var1) {
         this.field_193505_b.remove(var1);
         I["  ".length()].length();
         I["   ".length()].length();
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      public Instance() {
         super(TickTrigger.field_193183_a);
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 != -1);

         throw null;
      }
   }
}

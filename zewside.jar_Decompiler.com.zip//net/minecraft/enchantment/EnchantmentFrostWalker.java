package net.minecraft.enchantment;

import java.util.Iterator;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class EnchantmentFrostWalker extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   private static void I() {
      I = new String[120 ^ 117];
      I["".length()] = I("<\b\u0017\u0001\f\r\u001b\u0014\u0019\u001d(", "Zzxrx");
      I[" ".length()] = I("渖淆", "ZrzMQ");
      I["  ".length()] = I("呬亹", "ChLok");
      I["   ".length()] = I("嫛椺", "hGKcL");
      I[124 ^ 120] = I("塸拱", "xsRay");
      I[4 ^ 1] = I("垉榣杣", "usEQA");
      I[40 ^ 46] = I("使", "xmFmY");
      I[169 ^ 174] = I("幅両旓摥", "DPrUn");
      I[165 ^ 173] = I("囐", "VClzQ");
      I[89 ^ 80] = I("斝寢擭咈", "xMHub");
      I[85 ^ 95] = I("平灟嬃掛澇", "PhIUs");
      I[183 ^ 188] = I("媦楣", "ZLdCO");
      I[27 ^ 23] = I("氧", "RVbhi");
   }

   public int getMaxLevel() {
      return "  ".length();
   }

   public boolean isTreasureEnchantment() {
      return (boolean)" ".length();
   }

   public EnchantmentFrostWalker(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.ARMOR_FEET, var2);
      this.setName(I["".length()]);
   }

   public boolean canApplyTogether(Enchantment var1) {
      int var10000;
      if (super.canApplyTogether(var1) && var1 != Enchantments.DEPTH_STRIDER) {
         var10000 = " ".length();
         "".length();
         if (3 <= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int getMinEnchantability(int var1) {
      return var1 * (36 ^ 46);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 > -1);

      throw null;
   }

   public int getMaxEnchantability(int var1) {
      return this.getMinEnchantability(var1) + (185 ^ 182);
   }

   static {
      I();
   }

   public static void freezeNearby(EntityLivingBase var0, World var1, BlockPos var2, int var3) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[31 ^ 27];
      if (var0.onGround) {
         float var4 = (float)Math.min(41 ^ 57, "  ".length() + var3);
         I[191 ^ 186].length();
         I[64 ^ 70].length();
         BlockPos.MutableBlockPos var5 = new BlockPos.MutableBlockPos("".length(), "".length(), "".length());
         Iterator var6 = BlockPos.getAllInBoxMutable(var2.add((double)(-var4), -1.0D, (double)(-var4)), var2.add((double)var4, -1.0D, (double)var4)).iterator();

         while(var6.hasNext()) {
            BlockPos.MutableBlockPos var7 = (BlockPos.MutableBlockPos)var6.next();
            if (var7.distanceSqToCenter(var0.posX, var0.posY, var0.posZ) <= (double)(var4 * var4)) {
               var5.setPos(var7.getX(), var7.getY() + " ".length(), var7.getZ());
               I[173 ^ 170].length();
               I[59 ^ 51].length();
               I[89 ^ 80].length();
               IBlockState var8 = var1.getBlockState(var5);
               if (var8.getMaterial() == Material.AIR) {
                  IBlockState var9 = var1.getBlockState(var7);
                  if (var9.getMaterial() == Material.WATER && (Integer)var9.getValue(BlockLiquid.LEVEL) == 0 && var1.mayPlace(Blocks.FROSTED_ICE, var7, (boolean)"".length(), EnumFacing.DOWN, (Entity)null)) {
                     var1.setBlockState(var7, Blocks.FROSTED_ICE.getDefaultState());
                     I[24 ^ 18].length();
                     I[94 ^ 85].length();
                     I[105 ^ 101].length();
                     var1.scheduleUpdate(var7.toImmutable(), Blocks.FROSTED_ICE, MathHelper.getInt(var0.getRNG(), 137 ^ 181, 28 ^ 100));
                  }
               }
            }

            "".length();
            if (4 <= 3) {
               throw null;
            }
         }
      }

   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.CombatTracker;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

public class SPacketCombatEvent implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   public int entityId;
   // $FF: synthetic field
   public ITextComponent deathMessage;
   // $FF: synthetic field
   public int playerId;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public SPacketCombatEvent.Event eventType;
   // $FF: synthetic field
   public int duration;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.eventType);
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      if (this.eventType == SPacketCombatEvent.Event.END_COMBAT) {
         var1.writeVarIntToBuffer(this.duration);
         I[152 ^ 156].length();
         I[95 ^ 90].length();
         var1.writeInt(this.entityId);
         I[73 ^ 79].length();
         I[113 ^ 118].length();
         "".length();
         if (false) {
            throw null;
         }
      } else if (this.eventType == SPacketCombatEvent.Event.ENTITY_DIED) {
         var1.writeVarIntToBuffer(this.playerId);
         I[55 ^ 63].length();
         I[149 ^ 156].length();
         I[41 ^ 35].length();
         var1.writeInt(this.entityId);
         I[66 ^ 73].length();
         I[61 ^ 49].length();
         I[123 ^ 118].length();
         var1.writeTextComponent(this.deathMessage);
         I[108 ^ 98].length();
      }

   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != 2);

      throw null;
   }

   public SPacketCombatEvent(CombatTracker var1, SPacketCombatEvent.Event var2, boolean var3) {
      this.eventType = var2;
      EntityLivingBase var4 = var1.getBestAttacker();
      int var10001;
      switch(null.$SwitchMap$net$minecraft$network$play$server$SPacketCombatEvent$Event[var2.ordinal()]) {
      case 1:
         this.duration = var1.getCombatDuration();
         if (var4 == null) {
            var10001 = -" ".length();
            "".length();
            if (1 >= 4) {
               throw null;
            }
         } else {
            var10001 = var4.getEntityId();
         }

         this.entityId = var10001;
         "".length();
         if (-1 >= 2) {
            throw null;
         }
         break;
      case 2:
         this.playerId = var1.getFighter().getEntityId();
         if (var4 == null) {
            var10001 = -" ".length();
            "".length();
            if (-1 < -1) {
               throw null;
            }
         } else {
            var10001 = var4.getEntityId();
         }

         this.entityId = var10001;
         if (var3) {
            this.deathMessage = var1.getDeathMessage();
            "".length();
            if (-1 != -1) {
               throw null;
            }
         } else {
            this.deathMessage = new TextComponentString(I["".length()]);
         }
      }

   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.eventType = (SPacketCombatEvent.Event)var1.readEnumValue(SPacketCombatEvent.Event.class);
      if (this.eventType == SPacketCombatEvent.Event.END_COMBAT) {
         this.duration = var1.readVarIntFromBuffer();
         this.entityId = var1.readInt();
         "".length();
         if (0 >= 4) {
            throw null;
         }
      } else if (this.eventType == SPacketCombatEvent.Event.ENTITY_DIED) {
         this.playerId = var1.readVarIntFromBuffer();
         this.entityId = var1.readInt();
         this.deathMessage = var1.readTextComponent();
      }

   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleCombatEvent(this);
   }

   private static void I() {
      I = new String[91 ^ 84];
      I["".length()] = I("", "WTJtX");
      I[" ".length()] = I("假澋嘸帷堟", "vVrsP");
      I["  ".length()] = I("嶬倪棴亦毵", "cHCLv");
      I["   ".length()] = I("槓招汱屿昶", "eVGEu");
      I[170 ^ 174] = I("俠宛", "QruPl");
      I[105 ^ 108] = I("咽", "MuNzC");
      I[185 ^ 191] = I("汣櫐憯嗠", "KLWoo");
      I[176 ^ 183] = I("景岭昙暫惗", "vAuoT");
      I[49 ^ 57] = I("汷", "RRPqu");
      I[64 ^ 73] = I("橌", "yALIB");
      I[31 ^ 21] = I("暯", "sTHNL");
      I[115 ^ 120] = I("养兂橚晘惍", "nOTvT");
      I[171 ^ 167] = I("怒", "JfBOa");
      I[0 ^ 13] = I("孭冣", "CHKil");
      I[141 ^ 131] = I("摔尯嚗壍儆", "nHvCD");
   }

   public SPacketCombatEvent(CombatTracker var1, SPacketCombatEvent.Event var2) {
      this(var1, var2, (boolean)" ".length());
   }

   public SPacketCombatEvent() {
   }

   public static enum Event {
      // $FF: synthetic field
      ENTITY_DIED,
      // $FF: synthetic field
      END_COMBAT,
      // $FF: synthetic field
      ENTER_COMBAT;

      // $FF: synthetic field
      private static final String[] I;

      private static void I() {
         I = new String["   ".length()];
         I["".length()] = I("!:8\u0001\u0017;7#\t\u0007% ", "dtlDE");
         I[" ".length()] = I("\u0002\u000b\u001e% \b\b\u0018;7", "GEZzc");
         I["  ".length()] = I(" \u0002\u001c\b\u0012<\u0013\f\b\u0003!", "eLHAF");
      }

      static {
         I();
         ENTER_COMBAT = new SPacketCombatEvent.Event(I["".length()], "".length());
         END_COMBAT = new SPacketCombatEvent.Event(I[" ".length()], " ".length());
         ENTITY_DIED = new SPacketCombatEvent.Event(I["  ".length()], "  ".length());
         SPacketCombatEvent.Event[] var10000 = new SPacketCombatEvent.Event["   ".length()];
         var10000["".length()] = ENTER_COMBAT;
         var10000[" ".length()] = END_COMBAT;
         var10000["  ".length()] = ENTITY_DIED;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 > 2);

         throw null;
      }
   }
}

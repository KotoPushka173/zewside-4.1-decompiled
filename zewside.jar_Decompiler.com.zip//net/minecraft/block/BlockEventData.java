package net.minecraft.block;

import net.minecraft.util.math.BlockPos;

public class BlockEventData {
   // $FF: synthetic field
   private final Block blockType;
   // $FF: synthetic field
   private final int eventParameter;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final int eventID;
   // $FF: synthetic field
   private final BlockPos position;

   public Block getBlock() {
      return this.blockType;
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof BlockEventData)) {
         return (boolean)"".length();
      } else {
         BlockEventData var2 = (BlockEventData)var1;
         int var10000;
         if (this.position.equals(var2.position) && this.eventID == var2.eventID && this.eventParameter == var2.eventParameter && this.blockType == var2.blockType) {
            var10000 = " ".length();
            "".length();
            if (2 <= 1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   static {
      I();
   }

   private static void I() {
      I = new String[68 ^ 77];
      I["".length()] = I("会朔", "Dkqly");
      I[" ".length()] = I("放槩", "pJBFu");
      I["  ".length()] = I("惜厨", "rGPTE");
      I["   ".length()] = I("烉淙", "EKcCd");
      I[31 ^ 27] = I("壅烣嗲俑", "gXrsh");
      I[47 ^ 42] = I("?\u000eR", "kKzDN");
      I[10 ^ 12] = I("oU", "FyhQz");
      I[100 ^ 99] = I("v", "ZWPHM");
      I[8 ^ 0] = I("H", "dGtim");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 0);

      throw null;
   }

   public int getEventParameter() {
      return this.eventParameter;
   }

   public BlockEventData(BlockPos var1, Block var2, int var3, int var4) {
      this.position = var1;
      this.eventID = var3;
      this.eventParameter = var4;
      this.blockType = var2;
   }

   public int getEventID() {
      return this.eventID;
   }

   public BlockPos getPosition() {
      return this.position;
   }

   public String toString() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[121 ^ 125].length();
      return I[68 ^ 65] + this.position + I[60 ^ 58] + this.eventID + I[111 ^ 104] + this.eventParameter + I[66 ^ 74] + this.blockType;
   }
}

package net.minecraft.block.state.pattern;

import javax.annotation.ParametersAreNonnullByDefault;
import mcp.MethodsReturnNonnullByDefault;

// $FF: synthetic class
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
interface package-info {
}

package net.minecraft.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BlockAnvil extends BlockFalling {
   // $FF: synthetic field
   protected static final AxisAlignedBB X_AXIS_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB Z_AXIS_AABB;
   // $FF: synthetic field
   protected static final Logger LOGGER;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   public static final PropertyInteger DAMAGE;

   protected BlockAnvil() {
      super(Material.ANVIL);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(DAMAGE, "".length()));
      this.setLightOpacity("".length());
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[67 ^ 71];
      var10001 = I[194 ^ 199];
      var10002 = I[13 ^ 11];
      var10001 = I[172 ^ 171];
      var10000 = I[116 ^ 124];
      var10001 = I[118 ^ 127];
      var10002 = I[132 ^ 142];
      var10001 = I[130 ^ 137];
      EnumFacing var9 = var8.getHorizontalFacing().rotateY();

      try {
         return super.getStateForPlacement(var1, var2, var3, var4, var5, var6, var7, var8).withProperty(FACING, var9).withProperty(DAMAGE, var7 >> "  ".length());
      } catch (IllegalArgumentException var11) {
         if (!var1.isRemote) {
            Logger var12 = LOGGER;
            var10001 = I[90 ^ 86];
            Object[] var13 = new Object["  ".length()];
            I[66 ^ 79].length();
            I[37 ^ 43].length();
            I[15 ^ 0].length();
            var13["".length()] = var2;
            I[123 ^ 107].length();
            I[6 ^ 23].length();
            var13[" ".length()] = var7 >> "  ".length();
            var12.warn(String.format(var10001, var13));
            if (var8 instanceof EntityPlayer) {
               I[51 ^ 33].length();
               I[113 ^ 98].length();
               I[157 ^ 137].length();
               var8.addChatMessage(new TextComponentTranslation(I[66 ^ 87], new Object["".length()]));
            }
         }

         return super.getStateForPlacement(var1, var2, var3, var4, var5, var6, "".length(), var8).withProperty(FACING, var9).withProperty(DAMAGE, "".length());
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      IBlockState var10000;
      if (var1.getBlock() != this) {
         var10000 = var1;
         "".length();
         if (-1 == 0) {
            throw null;
         }
      } else {
         var10000 = var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
      }

      return var10000;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
      var2 |= (Integer)var1.getValue(DAMAGE) << "  ".length();
      return var2;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      EnumFacing var4 = (EnumFacing)var1.getValue(FACING);
      AxisAlignedBB var10000;
      if (var4.getAxis() == EnumFacing.Axis.X) {
         var10000 = X_AXIS_AABB;
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         var10000 = Z_AXIS_AABB;
      }

      return var10000;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.byHorizontalIndex(var1 & "   ".length())).withProperty(DAMAGE, (var1 & (33 ^ 46)) >> "  ".length());
   }

   public int damageDropped(IBlockState var1) {
      return (Integer)var1.getValue(DAMAGE);
   }

   private static void I() {
      I = new String[100 ^ 40];
      I["".length()] = I("櫈圶", "saSDm");
      I[" ".length()] = I("寤棊", "CZUeY");
      I["  ".length()] = I("往垄", "BLCsd");
      I["   ".length()] = I("嶐橥", "FSNEi");
      I[125 ^ 121] = I("剴哌", "tnOOG");
      I[130 ^ 135] = I("圄捫", "rTTmg");
      I[37 ^ 35] = I("们歋", "ijEGJ");
      I[131 ^ 132] = I("夊湳", "GqCGB");
      I[37 ^ 45] = I("崁惖", "kaxLc");
      I[60 ^ 53] = I("搗伧", "rhxPh");
      I[70 ^ 76] = I("瀵冶", "qWPGR");
      I[1 ^ 10] = I("拑吜", "kebYC");
      I[45 ^ 33] = I("?7\u0019\u00179\u001f=O\u00124\u001b8\b\u0013u\u0006+\u0000\u00060\u0004-\u0016V3\u0019+O\u0017;\u00000\u0003V4\u0002yJ\u0005{V\u001f\u0000\u0003;\u0012yJ\u0012yV4\u001a\u0005!V;\nV<\u0018y4FyVhCVg+", "vYovU");
      I[93 ^ 80] = I("寘倈姝", "PPITx");
      I[94 ^ 80] = I("垢偎族溁", "ESnNr");
      I[68 ^ 75] = I("槠別槯崌凜", "nUSLP");
      I[48 ^ 32] = I("沅", "IIWfg");
      I[5 ^ 20] = I("吩榊伈旲", "uHxiD");
      I[15 ^ 29] = I("劜悫", "bvIqK");
      I[212 ^ 199] = I("七昊佌", "bOpCg");
      I[64 ^ 84] = I("浨氧欢妐乹", "GLzxB");
      I[143 ^ 154] = I("(4%-6\b>s(;\f;4)z\u0011(<<?\u0013.*bz166-)\u0004z#%9\nz:\"z:j\u007flkMza\u0011", "aZSLZ");
      I[60 ^ 42] = I("旛煎", "zHMJN");
      I[39 ^ 48] = I("慟吳", "IJHQe");
      I[3 ^ 27] = I("榠啅", "aieiO");
      I[88 ^ 65] = I("櫺潧", "zEUpD");
      I[17 ^ 11] = I("坘", "eoLgi");
      I[143 ^ 148] = I("夿", "AEINR");
      I[183 ^ 171] = I("啙櫭刿嘉殎", "IXMJm");
      I[33 ^ 60] = I("瀔", "cmOyE");
      I[189 ^ 163] = I("俧巐", "HOack");
      I[79 ^ 80] = I("岭朸", "WkFqx");
      I[166 ^ 134] = I("漡樂", "BZBZY");
      I[132 ^ 165] = I("樄揨", "vbZmb");
      I[132 ^ 166] = I("決廙", "jAUmz");
      I[28 ^ 63] = I("傛棒", "FoSlJ");
      I[150 ^ 178] = I("攸旻", "aHlJa");
      I[3 ^ 38] = I("柪数", "lmkml");
      I[174 ^ 136] = I("浲吋", "cFJbF");
      I[125 ^ 90] = I("崈嚰", "CAiEv");
      I[56 ^ 16] = I("楅汅", "CgVGX");
      I[169 ^ 128] = I("崈毨", "MkAZL");
      I[183 ^ 157] = I("扸", "iomrG");
      I[2 ^ 41] = I("弬瀫", "nWjis");
      I[26 ^ 54] = I("烙冴届乛", "iDdej");
      I[65 ^ 108] = I("圦亻戤", "CdFFf");
      I[8 ^ 38] = I("彊刊", "OCTnZ");
      I[175 ^ 128] = I("妄伃偵恗嬚", "YkPnI");
      I[67 ^ 115] = I("涖卺涥", "VpucZ");
      I[70 ^ 119] = I("侺崬侕毨桓", "DmMWT");
      I[143 ^ 189] = I("楈澜", "iZpSO");
      I[119 ^ 68] = I("欠劍敷殬徯", "Uqaiz");
      I[75 ^ 127] = I("櫑庠岬", "LckLn");
      I[1 ^ 52] = I("槼捣孈彉", "yKufV");
      I[59 ^ 13] = I("啶掱榞搔烔", "fvPnE");
      I[170 ^ 157] = I("娚", "poEhw");
      I[157 ^ 165] = I("嬚柫欻样堏", "TLxkK");
      I[176 ^ 137] = I("柢歴湵呔坱", "Avlqe");
      I[58 ^ 0] = I("呏卟", "OnHjg");
      I[53 ^ 14] = I("勦唫", "UxjdH");
      I[177 ^ 141] = I("兀滷", "xbOsh");
      I[119 ^ 74] = I("厣埛", "WMWyH");
      I[9 ^ 55] = I("沭涠", "iszSA");
      I[104 ^ 87] = I("槣婦", "lGgEe");
      I[210 ^ 146] = I("測栵", "TqHLB");
      I[237 ^ 172] = I("喨湅", "JMLJG");
      I[234 ^ 168] = I("庠囍", "oMaBm");
      I[87 ^ 20] = I("咏戡", "jiEbI");
      I[249 ^ 189] = I("檉撧", "AuCHb");
      I[247 ^ 178] = I("榔歯", "RmLgZ");
      I[57 ^ 127] = I("沧妩", "YkZHA");
      I[105 ^ 46] = I("傃", "EYzNa");
      I[204 ^ 132] = I("唰妊", "ySlxl");
      I[93 ^ 20] = I("剤溚", "nQgyQ");
      I[241 ^ 187] = I("奝佊檻", "MjBux");
      I[76 ^ 7] = I("\u0014-)-?\u0015", "pLDLX");
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      DAMAGE = PropertyInteger.create(I[56 ^ 115], "".length(), "  ".length());
      X_AXIS_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.125D, 1.0D, 1.0D, 0.875D);
      Z_AXIS_AABB = new AxisAlignedBB(0.125D, 0.0D, 0.0D, 0.875D, 1.0D, 1.0D);
      LOGGER = LogManager.getLogger();
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[5 ^ 63];
      String var10001 = I[65 ^ 122];
      String var10002 = I[145 ^ 173];
      var10001 = I[100 ^ 89];
      var10000 = I[146 ^ 172];
      var10001 = I[81 ^ 110];
      var10002 = I[8 ^ 72];
      var10001 = I[40 ^ 105];
      var10000 = I[243 ^ 177];
      var10001 = I[131 ^ 192];
      var10002 = I[202 ^ 142];
      var10001 = I[243 ^ 182];
      I[47 ^ 105].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[130 ^ 197].length();
      I[78 ^ 6].length();
      I[255 ^ 182].length();
      var10003["".length()] = FACING;
      I[15 ^ 69].length();
      var10003[" ".length()] = DAMAGE;
      return new BlockStateContainer(this, var10003);
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return (boolean)" ".length();
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      String var10000 = I[139 ^ 157];
      String var10001 = I[69 ^ 82];
      String var10002 = I[59 ^ 35];
      var10001 = I[75 ^ 82];
      if (!var1.isRemote) {
         I[161 ^ 187].length();
         I[220 ^ 199].length();
         I[146 ^ 142].length();
         I[100 ^ 121].length();
         var4.displayGui(new BlockAnvil.Anvil(var1, var2));
      }

      return (boolean)" ".length();
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[19 ^ 13];
      String var10001 = I[143 ^ 144];
      String var10002 = I[116 ^ 84];
      var10001 = I[132 ^ 165];
      var10000 = I[77 ^ 111];
      var10001 = I[137 ^ 170];
      var10002 = I[48 ^ 20];
      var10001 = I[89 ^ 124];
      var10000 = I[163 ^ 133];
      var10001 = I[24 ^ 63];
      var10002 = I[27 ^ 51];
      var10001 = I[149 ^ 188];
      I[176 ^ 154].length();
      I[130 ^ 169].length();
      var2.add(new ItemStack(this));
      I[151 ^ 187].length();
      I[91 ^ 118].length();
      I[152 ^ 182].length();
      I[234 ^ 197].length();
      I[174 ^ 158].length();
      I[179 ^ 130].length();
      var2.add(new ItemStack(this, " ".length(), " ".length()));
      I[120 ^ 74].length();
      I[89 ^ 106].length();
      I[28 ^ 40].length();
      I[117 ^ 64].length();
      I[157 ^ 171].length();
      I[39 ^ 16].length();
      var2.add(new ItemStack(this, " ".length(), "  ".length()));
      I[119 ^ 79].length();
      I[94 ^ 103].length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public void onEndFalling(World var1, BlockPos var2, IBlockState var3, IBlockState var4) {
      var1.playEvent(355 + 11 - 9 + 674, var2, "".length());
   }

   public void func_190974_b(World var1, BlockPos var2) {
      var1.playEvent(407 + 397 - -163 + 62, var2, "".length());
   }

   protected void onStartFalling(EntityFallingBlock var1) {
      var1.setHurtEntities((boolean)" ".length());
   }

   public static class Anvil implements IInteractionObject {
      // $FF: synthetic field
      private final BlockPos position;
      // $FF: synthetic field
      private final World world;
      // $FF: synthetic field
      private static final String[] I;

      public String getGuiID() {
         return I[89 ^ 78];
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 != -1);

         throw null;
      }

      static {
         I();
      }

      public String getName() {
         return I["".length()];
      }

      public Container createContainer(InventoryPlayer var1, EntityPlayer var2) {
         String var10000 = I[77 ^ 93];
         String var10001 = I[137 ^ 152];
         String var10002 = I[140 ^ 158];
         var10001 = I[213 ^ 198];
         I[151 ^ 131].length();
         I[175 ^ 186].length();
         I[57 ^ 47].length();
         return new ContainerRepair(var1, this.world, this.position, var2);
      }

      private static void I() {
         I = new String[186 ^ 162];
         I["".length()] = I("\u0011'\u0015.:", "pIcGV");
         I[" ".length()] = I("戉排", "ryKrn");
         I["  ".length()] = I("憠擄", "CnAMn");
         I["   ".length()] = I("剓氟", "bYshj");
         I[133 ^ 129] = I("侂嶎", "rHXpt");
         I[145 ^ 148] = I("晑旭", "aLpTL");
         I[157 ^ 155] = I("攷哝", "tGSwS");
         I[77 ^ 74] = I("憖卷", "zPmEn");
         I[18 ^ 26] = I("怚亻", "OhqSh");
         I[24 ^ 17] = I("嫔偋怾", "TQiNF");
         I[179 ^ 185] = I("倅愧", "xDnFz");
         I[59 ^ 48] = I("滩", "zgOuO");
         I[36 ^ 40] = I("汼旪", "iTmZk");
         I[108 ^ 97] = I("淼", "UNSCf");
         I[190 ^ 176] = I("假仡槣棤瀜", "HgyaE");
         I[55 ^ 56] = I("J\u0001\u0012?)", "dosRL");
         I[190 ^ 174] = I("契桛", "ojdzV");
         I[170 ^ 187] = I("埾枺", "SLJOt");
         I[9 ^ 27] = I("厓屾", "EIamD");
         I[45 ^ 62] = I("汒灊", "NuWCw");
         I[157 ^ 137] = I("欮嫏墼晣槄", "uVsfw");
         I[64 ^ 85] = I("壪右", "mwpMj");
         I[6 ^ 16] = I("娤", "NyBas");
         I[98 ^ 117] = I("<1\u001b\u001f\n#9\u0013\u000eS06\u0003\u0013\u0005", "QXuzi");
      }

      public Anvil(World var1, BlockPos var2) {
         this.world = var1;
         this.position = var2;
      }

      public ITextComponent getDisplayName() {
         String var10000 = I[" ".length()];
         String var10001 = I["  ".length()];
         String var10002 = I["   ".length()];
         var10001 = I[124 ^ 120];
         var10000 = I[84 ^ 81];
         var10001 = I[24 ^ 30];
         var10002 = I[89 ^ 94];
         var10001 = I[35 ^ 43];
         I[53 ^ 60].length();
         I[37 ^ 47].length();
         I[6 ^ 13].length();
         I[202 ^ 198].length();
         I[140 ^ 129].length();
         I[99 ^ 109].length();
         return new TextComponentTranslation(Blocks.ANVIL.getUnlocalizedName() + I[11 ^ 4], new Object["".length()]);
      }

      public boolean hasCustomName() {
         return (boolean)"".length();
      }
   }
}

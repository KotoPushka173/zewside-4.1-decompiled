package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockStoneSlabNew extends BlockSlab {
   // $FF: synthetic field
   public static final PropertyEnum<BlockStoneSlabNew.EnumType> VARIANT;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool SEAMLESS;

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.STONE_SLAB2);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public Comparable<?> getTypeForItem(ItemStack var1) {
      return BlockStoneSlabNew.EnumType.byMetadata(var1.getMetadata() & (43 ^ 44));
   }

   public BlockStoneSlabNew() {
      super(Material.ROCK);
      IBlockState var1 = this.blockState.getBaseState();
      if (this.isDouble()) {
         var1 = var1.withProperty(SEAMLESS, Boolean.valueOf((boolean)"".length()));
         "".length();
         if (3 < -1) {
            throw null;
         }
      } else {
         var1 = var1.withProperty(HALF, BlockSlab.EnumBlockHalf.BOTTOM);
      }

      this.setDefaultState(var1.withProperty(VARIANT, BlockStoneSlabNew.EnumType.RED_SANDSTONE));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockStoneSlabNew.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[184 ^ 165];
      String var10001 = I[97 ^ 127];
      String var10002 = I[94 ^ 65];
      var10001 = I[4 ^ 36];
      var10000 = I[25 ^ 56];
      var10001 = I[11 ^ 41];
      var10002 = I[188 ^ 159];
      var10001 = I[95 ^ 123];
      var10000 = I[177 ^ 148];
      var10001 = I[86 ^ 112];
      var10002 = I[180 ^ 147];
      var10001 = I[116 ^ 92];
      var10000 = I[99 ^ 74];
      var10001 = I[83 ^ 121];
      var10002 = I[86 ^ 125];
      var10001 = I[169 ^ 133];
      var10000 = I[7 ^ 42];
      var10001 = I[72 ^ 102];
      var10002 = I[116 ^ 91];
      var10001 = I[138 ^ 186];
      var10000 = I[102 ^ 87];
      var10001 = I[166 ^ 148];
      var10002 = I[145 ^ 162];
      var10001 = I[49 ^ 5];
      BlockStateContainer var1;
      IProperty[] var10003;
      if (this.isDouble()) {
         I[66 ^ 119].length();
         I[188 ^ 138].length();
         var10003 = new IProperty["  ".length()];
         I[22 ^ 33].length();
         var10003["".length()] = SEAMLESS;
         I[128 ^ 184].length();
         I[4 ^ 61].length();
         I[95 ^ 101].length();
         I[85 ^ 110].length();
         var10003[" ".length()] = VARIANT;
         var1 = new BlockStateContainer(this, var10003);
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         I[122 ^ 70].length();
         I[1 ^ 60].length();
         I[174 ^ 144].length();
         I[255 ^ 192].length();
         var10003 = new IProperty["  ".length()];
         I[247 ^ 183].length();
         var10003["".length()] = HALF;
         I[43 ^ 106].length();
         I[227 ^ 161].length();
         var10003[" ".length()] = VARIANT;
         var1 = new BlockStateContainer(this, var10003);
      }

      return var1;
   }

   private static void I() {
      I = new String[107 ^ 46];
      I["".length()] = I("天淚", "ohJWI");
      I[" ".length()] = I("垹炿", "pXLYe");
      I["  ".length()] = I("丑煎", "hqnwY");
      I["   ".length()] = I("晰婷", "wbuJY");
      I[11 ^ 15] = I("挽戝", "DebqB");
      I[192 ^ 197] = I("正", "EcrTL");
      I[99 ^ 101] = I("k8\"=%6+)=\t1%)<T++*<", "EJGYz");
      I[15 ^ 8] = I("戊嫀", "vVoRd");
      I[183 ^ 191] = I("惉噿", "cShiw");
      I[90 ^ 83] = I("巎惻", "IjJwo");
      I[130 ^ 136] = I("婢氍", "XiPnm");
      I[15 ^ 4] = I("尨", "CxpkL");
      I[82 ^ 94] = I("圬濵", "oKhXv");
      I[106 ^ 103] = I("廿揕", "ZuXSE");
      I[129 ^ 143] = I("廢嫯", "PdRVy");
      I[36 ^ 43] = I("歛帥", "DwkHy");
      I[97 ^ 113] = I("潬攚曍", "USXeK");
      I[88 ^ 73] = I("}", "SMXJG");
      I[116 ^ 102] = I("步柡", "LOytd");
      I[101 ^ 118] = I("暄堧", "QSMAU");
      I[100 ^ 112] = I("捷汩", "YrdHA");
      I[211 ^ 198] = I("朢僮", "vMRFm");
      I[113 ^ 103] = I("氢何匆厢", "EeGzB");
      I[144 ^ 135] = I("挪瀬昙瀥", "NxHso");
      I[89 ^ 65] = I("毮涞梮斌", "oBFQU");
      I[65 ^ 88] = I("此攅炈", "LMxYR");
      I[164 ^ 190] = I("勾敹满卵", "WCQog");
      I[61 ^ 38] = I("殕兓", "AtrqQ");
      I[68 ^ 88] = I("报围晵滿撀", "EOery");
      I[176 ^ 173] = I("仝殤", "BUxSb");
      I[160 ^ 190] = I("废殯", "qWXxB");
      I[115 ^ 108] = I("儽主", "aKhHN");
      I[164 ^ 132] = I("悟啩", "MUoXw");
      I[80 ^ 113] = I("柆梙", "kTsLv");
      I[167 ^ 133] = I("帉夿", "JYVui");
      I[227 ^ 192] = I("椬渶", "CZqFE");
      I[81 ^ 117] = I("格匫", "PBDNx");
      I[148 ^ 177] = I("棟吕", "VseEW");
      I[28 ^ 58] = I("浨校", "piIVJ");
      I[75 ^ 108] = I("僟淏", "oqBTH");
      I[10 ^ 34] = I("俏宾", "vReKl");
      I[31 ^ 54] = I("橖刦", "pjqbb");
      I[5 ^ 47] = I("抔炻", "EdqyC");
      I[104 ^ 67] = I("沼灮", "dviyK");
      I[123 ^ 87] = I("厮忎", "CCits");
      I[188 ^ 145] = I("圻浻", "gDOMr");
      I[111 ^ 65] = I("淍敀", "aIQPW");
      I[54 ^ 25] = I("亓催", "tKIFd");
      I[163 ^ 147] = I("埋浭", "XdZAh");
      I[128 ^ 177] = I("液剑", "ZbdVh");
      I[54 ^ 4] = I("儴席", "bpriS");
      I[29 ^ 46] = I("殆宰", "ZVIEA");
      I[139 ^ 191] = I("劧搤", "IAqkn");
      I[99 ^ 86] = I("抢摔映士", "LwRuV");
      I[114 ^ 68] = I("壐檭", "NnyKT");
      I[190 ^ 137] = I("烫滳", "SaDfx");
      I[107 ^ 83] = I("愷栔欫", "KEnTl");
      I[40 ^ 17] = I("抱嵐嶒滓", "ZOTuj");
      I[188 ^ 134] = I("札婷嚺告加", "lmcPq");
      I[53 ^ 14] = I("炊捴", "nbGLm");
      I[135 ^ 187] = I("沲昑", "HESWL");
      I[63 ^ 2] = I("冘伧倓壚", "DwhDH");
      I[27 ^ 37] = I("滟徴殛嚊", "xvOIF");
      I[164 ^ 155] = I("嬅嵟悂", "wnEZT");
      I[102 ^ 38] = I("杦", "MzNMa");
      I[220 ^ 157] = I("棼檻挲", "tHcRs");
      I[42 ^ 104] = I("柬滎", "KMvss");
      I[70 ^ 5] = I("&\u0017\u0002\u001c40\u0001\u0010", "UrcqX");
      I[251 ^ 191] = I(":#<3\b\"6", "LBNZi");
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((BlockStoneSlabNew.EnumType)var1.getValue(VARIANT)).getMetadata();
      if (this.isDouble()) {
         if ((Boolean)var1.getValue(SEAMLESS)) {
            var2 |= 95 ^ 87;
            "".length();
            if (4 < 0) {
               throw null;
            }
         }
      } else if (var1.getValue(HALF) == BlockSlab.EnumBlockHalf.TOP) {
         var2 |= 17 ^ 25;
      }

      return var2;
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var2 = this.getDefaultState().withProperty(VARIANT, BlockStoneSlabNew.EnumType.byMetadata(var1 & (179 ^ 180)));
      if (this.isDouble()) {
         PropertyBool var10001 = SEAMLESS;
         int var10002;
         if ((var1 & (78 ^ 70)) != 0) {
            var10002 = " ".length();
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10002 = "".length();
         }

         var2 = var2.withProperty(var10001, Boolean.valueOf((boolean)var10002));
         "".length();
         if (4 < 4) {
            throw null;
         }
      } else {
         PropertyEnum var3 = HALF;
         BlockSlab.EnumBlockHalf var4;
         if ((var1 & (99 ^ 107)) == 0) {
            var4 = BlockSlab.EnumBlockHalf.BOTTOM;
            "".length();
            if (4 <= 0) {
               throw null;
            }
         } else {
            var4 = BlockSlab.EnumBlockHalf.TOP;
         }

         var2 = var2.withProperty(var3, var4);
      }

      return var2;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[179 ^ 180];
      String var10001 = I[127 ^ 119];
      String var10002 = I[72 ^ 65];
      var10001 = I[103 ^ 109];
      I[29 ^ 22].length();
      return new ItemStack(Blocks.STONE_SLAB2, " ".length(), ((BlockStoneSlabNew.EnumType)var3.getValue(VARIANT)).getMetadata());
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return ((BlockStoneSlabNew.EnumType)var1.getValue(VARIANT)).getMapColor();
   }

   public String getUnlocalizedName(int var1) {
      String var10000 = I[1 ^ 13];
      String var10001 = I[138 ^ 135];
      String var10002 = I[2 ^ 12];
      var10001 = I[153 ^ 150];
      I[26 ^ 10].length();
      return super.getUnlocalizedName() + I[183 ^ 166] + BlockStoneSlabNew.EnumType.byMetadata(var1).getUnlocalizedName();
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[163 ^ 177];
      String var10001 = I[185 ^ 170];
      String var10002 = I[174 ^ 186];
      var10001 = I[106 ^ 127];
      BlockStoneSlabNew.EnumType[] var3 = BlockStoneSlabNew.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockStoneSlabNew.EnumType var6 = var3[var5];
         I[133 ^ 147].length();
         I[103 ^ 112].length();
         I[1 ^ 25].length();
         I[190 ^ 167].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[151 ^ 141].length();
         I[74 ^ 81].length();
         I[41 ^ 53].length();
         ++var5;
         "".length();
      } while(4 == 4);

      throw null;
   }

   public String getLocalizedName() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[19 ^ 23].length();
      I[183 ^ 178].length();
      return I18n.translateToLocal(this.getUnlocalizedName() + I[6 ^ 0]);
   }

   public IProperty<?> getVariantProperty() {
      return VARIANT;
   }

   static {
      I();
      SEAMLESS = PropertyBool.create(I[250 ^ 185]);
      VARIANT = PropertyEnum.create(I[206 ^ 138], BlockStoneSlabNew.EnumType.class);
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      RED_SANDSTONE;

      // $FF: synthetic field
      private final MapColor mapColor;
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private static final String[] I;

      public String getUnlocalizedName() {
         return this.name;
      }

      public int getMetadata() {
         return this.meta;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I("\u0017'=\u001b\u0001\u0004,=\u0017\u0006\n,<", "EbyDR");
         I[" ".length()] = I("(\u0017%7\n;\u001c%\u001b\r5\u001c$", "ZrAhy");
      }

      public MapColor getMapColor() {
         return this.mapColor;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= 2);

         throw null;
      }

      private EnumType(int var3, String var4, MapColor var5) {
         this.meta = var3;
         this.name = var4;
         this.mapColor = var5;
      }

      public String toString() {
         return this.name;
      }

      static {
         I();
         RED_SANDSTONE = new BlockStoneSlabNew.EnumType(I["".length()], "".length(), "".length(), I[" ".length()], BlockSand.EnumType.RED_SAND.getMapColor());
         BlockStoneSlabNew.EnumType[] var10000 = new BlockStoneSlabNew.EnumType[" ".length()];
         var10000["".length()] = RED_SANDSTONE;
         BlockStoneSlabNew.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockStoneSlabNew.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(3 >= -1);

         throw null;
      }

      public String getName() {
         return this.name;
      }

      public static BlockStoneSlabNew.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }
   }
}

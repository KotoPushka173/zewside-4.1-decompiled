package net.minecraft.advancements;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import javax.annotation.Nullable;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;

public class DisplayInfo {
   // $FF: synthetic field
   private final ITextComponent field_192300_a;
   // $FF: synthetic field
   private float field_192305_f;
   // $FF: synthetic field
   private final ItemStack field_192301_b;
   // $FF: synthetic field
   private final boolean field_193227_g;
   // $FF: synthetic field
   private final boolean field_193228_h;
   // $FF: synthetic field
   private float field_192304_e;
   // $FF: synthetic field
   private final FrameType field_192303_d;
   // $FF: synthetic field
   private final boolean field_193226_f;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final ITextComponent field_193225_b;
   // $FF: synthetic field
   private final ResourceLocation field_192302_c;

   public ITextComponent func_192297_a() {
      return this.field_192300_a;
   }

   public ITextComponent func_193222_b() {
      return this.field_193225_b;
   }

   public DisplayInfo(ItemStack var1, ITextComponent var2, ITextComponent var3, @Nullable ResourceLocation var4, FrameType var5, boolean var6, boolean var7, boolean var8) {
      this.field_192300_a = var2;
      this.field_193225_b = var3;
      this.field_192301_b = var1;
      this.field_192302_c = var4;
      this.field_192303_d = var5;
      this.field_193226_f = var6;
      this.field_193227_g = var7;
      this.field_193228_h = var8;
   }

   private static ItemStack func_193221_a(JsonObject var0) {
      String var10000 = I[25 ^ 6];
      String var10001 = I[130 ^ 162];
      String var10002 = I[114 ^ 83];
      var10001 = I[79 ^ 109];
      var10000 = I[79 ^ 108];
      var10001 = I[103 ^ 67];
      var10002 = I[41 ^ 12];
      var10001 = I[2 ^ 36];
      if (!var0.has(I[95 ^ 120])) {
         I[146 ^ 186].length();
         I[34 ^ 11].length();
         I[83 ^ 121].length();
         JsonSyntaxException var3 = new JsonSyntaxException(I[176 ^ 155]);
         I[234 ^ 198].length();
         throw var3;
      } else {
         Item var1 = JsonUtils.getItem(var0, I[145 ^ 188]);
         int var2 = JsonUtils.getInt(var0, I[90 ^ 116], "".length());
         I[112 ^ 95].length();
         I[128 ^ 176].length();
         return new ItemStack(var1, " ".length(), var2);
      }
   }

   @Nullable
   public ResourceLocation func_192293_c() {
      return this.field_192302_c;
   }

   public void func_192292_a(float var1, float var2) {
      this.field_192304_e = var1;
      this.field_192305_f = var2;
   }

   private static void I() {
      I = new String[39 ^ 111];
      I["".length()] = I("欩品", "FrsPo");
      I[" ".length()] = I("惭摥", "KtYUU");
      I["  ".length()] = I("彥惗", "yIRgG");
      I["   ".length()] = I("忹斩", "QPzBT");
      I[175 ^ 171] = I("倉桞", "rzoIQ");
      I[196 ^ 193] = I("侖意", "bQivy");
      I[106 ^ 108] = I("廿尮", "GPmam");
      I[28 ^ 27] = I("溽崥", "BNMuV");
      I[56 ^ 48] = I("炓擸", "Hqdfe");
      I[44 ^ 37] = I("亠妃", "GWsQn");
      I[3 ^ 9] = I("滎屛", "bPqvY");
      I[167 ^ 172] = I("悓剀", "GliaI");
      I[55 ^ 59] = I("\u0012\u0019\u001f9 ", "fpkUE");
      I[187 ^ 182] = I("4\u0011=7=9\u0004:= >", "PtNTO");
      I[155 ^ 149] = I("\u0004\u000b\f\u0004", "mhcjT");
      I[185 ^ 182] = I("\u0006 \u0019\u000e\u0011\u0016.\u000f\u000b\u0012", "dAzev");
      I[6 ^ 22] = I("奫", "oSNLr");
      I[190 ^ 175] = I("堝勹摽朊暫", "Peobi");
      I[28 ^ 14] = I("76\u0011 \u0004'8\u0007%\u0007", "UWrKc");
      I[31 ^ 12] = I("\u00165\u0010\u0004\b", "pGqim");
      I[24 ^ 12] = I("7\u0013\u0018> ", "QaySE");
      I[118 ^ 99] = I("\t1-8\u0016\u000e6#<=", "zYBOI");
      I[62 ^ 40] = I("\u0016?\u0004,\u0000\u00192\u000f\u001c\u0001\u0018\u000e\t+\u0014\u0003", "wQjCu");
      I[139 ^ 156] = I("/;4#\u001d)", "GRPGx");
      I[57 ^ 33] = I("埈喥懸", "tzrhN");
      I[169 ^ 176] = I("昨浳", "AgwPr");
      I[104 ^ 114] = I("濍悸", "AEpEn");
      I[180 ^ 175] = I("欇偬", "yFSGL");
      I[46 ^ 50] = I(":=#9D\f;#=\u0001X395D\u001c7$2\u0016\u0011\"#8\u000b\u0016r:$\u0017\fr54D\u000b7#", "xRWQd");
      I[5 ^ 24] = I("掃幏曢俏", "hKsWg");
      I[67 ^ 93] = I("垢俱劕", "nbfFL");
      I[76 ^ 83] = I("前厜", "glMij");
      I[188 ^ 156] = I("嵁彼", "IyPzR");
      I[39 ^ 6] = I("晿瀙", "hjqxV");
      I[79 ^ 109] = I("嶳些", "rbRlN");
      I[164 ^ 135] = I("删噷", "zKZiq");
      I[20 ^ 48] = I("倿摟", "XKTYp");
      I[119 ^ 82] = I("毘洣", "BSLpN");
      I[62 ^ 24] = I("嚧悜", "rPiDQ");
      I[148 ^ 179] = I("0?\u0006\u000b", "YKcfl");
      I[12 ^ 36] = I("浂", "babaR");
      I[184 ^ 145] = I("它姃", "NyBOp");
      I[142 ^ 164] = I("歉潄", "ZPbsV");
      I[105 ^ 66] = I("\u0007#%:?\"\"$;*6m?, <m\"6?7av,: ?3!;>4v !>4v&;7 %o. (v<:\"=9=;7)vg.6)vh&&(;ho9(/f", "RMVOO");
      I[120 ^ 84] = I("沍傉倳", "vcHHG");
      I[113 ^ 92] = I("\u0018\u0006\u0000\u0019", "qrete");
      I[112 ^ 94] = I(",\u0010\u001d\u0018", "HqiyY");
      I[50 ^ 29] = I("估匓", "rKgzS");
      I[7 ^ 55] = I("囇槝摄暊巰", "KcUXs");
      I[243 ^ 194] = I("噙", "nguSe");
      I[110 ^ 92] = I("摟刎噜儜姆", "bivdu");
      I[174 ^ 157] = I("丗", "dGLXa");
      I[107 ^ 95] = I("嬱榊榙柋", "RPvYF");
      I[152 ^ 173] = I("啃", "JBeLX");
      I[77 ^ 123] = I("奾彤嵟庼兖", "tVFAC");
      I[35 ^ 20] = I("具漭", "SLSBv");
      I[248 ^ 192] = I("墋濛", "BQIez");
      I[135 ^ 190] = I("椾楽", "bYjov");
      I[182 ^ 140] = I("栻", "giIGO");
      I[187 ^ 128] = I("張悱宓", "ExIjY");
      I[181 ^ 137] = I("傔寄弼嵜婁", "xRnHf");
      I[19 ^ 46] = I("卋殮冲勻嬝", "IDdbS");
      I[140 ^ 178] = I("峁媃圥", "VLXYd");
      I[10 ^ 53] = I("嬓坈奁", "CpuVa");
      I[224 ^ 160] = I("枏泟椣", "HYmMf");
      I[202 ^ 139] = I("沇楏儴担溓", "remnZ");
      I[221 ^ 159] = I("位峰", "woEHT");
      I[221 ^ 158] = I("仪漃", "gsjgT");
      I[52 ^ 112] = I("悱嶝", "Feqou");
      I[6 ^ 67] = I("灿攸", "cXiRv");
      I[242 ^ 180] = I("戧歀", "hSnTe");
      I[135 ^ 192] = I("嶷漼壪", "XZnuJ");
   }

   public static DisplayInfo func_192294_a(JsonObject var0, JsonDeserializationContext var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[56 ^ 60];
      var10001 = I[82 ^ 87];
      var10002 = I[144 ^ 150];
      var10001 = I[30 ^ 25];
      var10000 = I[11 ^ 3];
      var10001 = I[99 ^ 106];
      var10002 = I[56 ^ 50];
      var10001 = I[165 ^ 174];
      ITextComponent var2 = (ITextComponent)JsonUtils.deserializeClass(var0, I[70 ^ 74], var1, ITextComponent.class);
      ITextComponent var3 = (ITextComponent)JsonUtils.deserializeClass(var0, I[150 ^ 155], var1, ITextComponent.class);
      if (var2 != null && var3 != null) {
         ItemStack var4 = func_193221_a(JsonUtils.getJsonObject(var0, I[36 ^ 42]));
         ResourceLocation var11;
         if (var0.has(I[58 ^ 53])) {
            I[191 ^ 175].length();
            I[18 ^ 3].length();
            var11 = new ResourceLocation(JsonUtils.getString(var0, I[72 ^ 90]));
            "".length();
            if (2 >= 3) {
               throw null;
            }
         } else {
            var11 = null;
         }

         ResourceLocation var5 = var11;
         FrameType var12;
         if (var0.has(I[170 ^ 185])) {
            var12 = FrameType.func_192308_a(JsonUtils.getString(var0, I[15 ^ 27]));
            "".length();
            if (2 >= 4) {
               throw null;
            }
         } else {
            var12 = FrameType.TASK;
         }

         FrameType var6 = var12;
         boolean var7 = JsonUtils.getBoolean(var0, I[8 ^ 29], (boolean)" ".length());
         boolean var8 = JsonUtils.getBoolean(var0, I[171 ^ 189], (boolean)" ".length());
         boolean var9 = JsonUtils.getBoolean(var0, I[108 ^ 123], (boolean)"".length());
         I[88 ^ 64].length();
         return new DisplayInfo(var4, var2, var3, var5, var6, var7, var8, var9);
      } else {
         I[55 ^ 46].length();
         I[105 ^ 115].length();
         I[46 ^ 53].length();
         JsonSyntaxException var10 = new JsonSyntaxException(I[146 ^ 142]);
         I[19 ^ 14].length();
         I[71 ^ 89].length();
         throw var10;
      }
   }

   public ItemStack func_192298_b() {
      return this.field_192301_b;
   }

   public boolean func_193224_j() {
      return this.field_193228_h;
   }

   public boolean func_193223_h() {
      return this.field_193226_f;
   }

   public float func_192299_e() {
      return this.field_192304_e;
   }

   public void func_192290_a(PacketBuffer var1) {
      var1.writeTextComponent(this.field_192300_a);
      I[67 ^ 114].length();
      I[132 ^ 182].length();
      var1.writeTextComponent(this.field_193225_b);
      I[147 ^ 160].length();
      I[190 ^ 138].length();
      I[156 ^ 169].length();
      I[74 ^ 124].length();
      var1.writeItemStackToBuffer(this.field_192301_b);
      I[22 ^ 33].length();
      I[55 ^ 15].length();
      var1.writeEnumValue(this.field_192303_d);
      I[127 ^ 70].length();
      int var2 = "".length();
      if (this.field_192302_c != null) {
         var2 |= " ".length();
      }

      if (this.field_193226_f) {
         var2 |= "  ".length();
      }

      if (this.field_193228_h) {
         var2 |= 91 ^ 95;
      }

      var1.writeInt(var2);
      I[249 ^ 195].length();
      I[252 ^ 199].length();
      I[6 ^ 58].length();
      if (this.field_192302_c != null) {
         var1.func_192572_a(this.field_192302_c);
         I[50 ^ 15].length();
      }

      var1.writeFloat(this.field_192304_e);
      I[137 ^ 183].length();
      var1.writeFloat(this.field_192305_f);
      I[93 ^ 98].length();
      I[213 ^ 149].length();
      I[38 ^ 103].length();
   }

   public boolean func_193220_i() {
      return this.field_193227_g;
   }

   static {
      I();
   }

   public float func_192296_f() {
      return this.field_192305_f;
   }

   public static DisplayInfo func_192295_b(PacketBuffer var0) throws IOException {
      String var10000 = I[31 ^ 93];
      String var10001 = I[109 ^ 46];
      String var10002 = I[204 ^ 136];
      var10001 = I[12 ^ 73];
      ITextComponent var1 = var0.readTextComponent();
      ITextComponent var2 = var0.readTextComponent();
      ItemStack var3 = var0.readItemStackFromBuffer();
      FrameType var4 = (FrameType)var0.readEnumValue(FrameType.class);
      int var5 = var0.readInt();
      ResourceLocation var10;
      if ((var5 & " ".length()) != 0) {
         var10 = var0.func_192575_l();
         "".length();
         if (-1 >= 1) {
            throw null;
         }
      } else {
         var10 = null;
      }

      ResourceLocation var6 = var10;
      int var11;
      if ((var5 & "  ".length()) != 0) {
         var11 = " ".length();
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var11 = "".length();
      }

      int var7 = var11;
      if ((var5 & (105 ^ 109)) != 0) {
         var11 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var11 = "".length();
      }

      int var8 = var11;
      I[225 ^ 167].length();
      I[196 ^ 131].length();
      DisplayInfo var9 = new DisplayInfo(var3, var1, var2, var6, var4, (boolean)var7, (boolean)"".length(), (boolean)var8);
      var9.func_192292_a(var0.readFloat(), var0.readFloat());
      return var9;
   }

   public FrameType func_192291_d() {
      return this.field_192303_d;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 2);

      throw null;
   }
}

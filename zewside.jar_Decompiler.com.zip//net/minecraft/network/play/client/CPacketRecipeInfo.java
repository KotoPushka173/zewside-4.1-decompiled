package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketRecipeInfo implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private boolean field_192632_f;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private boolean field_192631_e;
   // $FF: synthetic field
   private IRecipe field_193649_d;
   // $FF: synthetic field
   private CPacketRecipeInfo.Purpose field_194157_a;

   public CPacketRecipeInfo(boolean var1, boolean var2) {
      this.field_194157_a = CPacketRecipeInfo.Purpose.SETTINGS;
      this.field_192631_e = var1;
      this.field_192632_f = var2;
   }

   public IRecipe func_193648_b() {
      return this.field_193649_d;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.func_191984_a(this);
   }

   public CPacketRecipeInfo.Purpose func_194156_a() {
      return this.field_194157_a;
   }

   public CPacketRecipeInfo() {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 < 4);

      throw null;
   }

   public boolean func_192624_c() {
      return this.field_192631_e;
   }

   public boolean func_192625_d() {
      return this.field_192632_f;
   }

   private static void I() {
      I = new String[94 ^ 87];
      I["".length()] = I("涞帙瀿", "dNwmA");
      I[" ".length()] = I("尢垻姨", "igVuL");
      I["  ".length()] = I("泆僀漲", "Arsdc");
      I["   ".length()] = I("揻匚泮崸", "XGlpf");
      I[109 ^ 105] = I("煠伋拪槠攳", "oEBhQ");
      I[143 ^ 138] = I("憊偷伲洎捃", "QKYRA");
      I[65 ^ 71] = I("坥浻湟桒悒", "raMIP");
      I[83 ^ 84] = I("椗", "HIoYE");
      I[29 ^ 21] = I("叜吚", "wiMXE");
   }

   static {
      I();
   }

   public CPacketRecipeInfo(IRecipe var1) {
      this.field_194157_a = CPacketRecipeInfo.Purpose.SHOWN;
      this.field_193649_d = var1;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.field_194157_a = (CPacketRecipeInfo.Purpose)var1.readEnumValue(CPacketRecipeInfo.Purpose.class);
      if (this.field_194157_a == CPacketRecipeInfo.Purpose.SHOWN) {
         this.field_193649_d = CraftingManager.func_193374_a(var1.readInt());
         "".length();
         if (3 <= -1) {
            throw null;
         }
      } else if (this.field_194157_a == CPacketRecipeInfo.Purpose.SETTINGS) {
         this.field_192631_e = var1.readBoolean();
         this.field_192632_f = var1.readBoolean();
      }

   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.field_194157_a);
      I["".length()].length();
      I[" ".length()].length();
      if (this.field_194157_a == CPacketRecipeInfo.Purpose.SHOWN) {
         var1.writeInt(CraftingManager.func_193375_a(this.field_193649_d));
         I["  ".length()].length();
         I["   ".length()].length();
         I[124 ^ 120].length();
         I[85 ^ 80].length();
         "".length();
         if (false) {
            throw null;
         }
      } else if (this.field_194157_a == CPacketRecipeInfo.Purpose.SETTINGS) {
         var1.writeBoolean(this.field_192631_e);
         I[130 ^ 132].length();
         I[29 ^ 26].length();
         var1.writeBoolean(this.field_192632_f);
         I[84 ^ 92].length();
      }

   }

   public static enum Purpose {
      // $FF: synthetic field
      SETTINGS;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      SHOWN;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 == 3);

         throw null;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I("=\u00105\r&", "nXzZh");
         I[" ".length()] = I("\u0014=\u0003\u001e\n\t?\u0004", "GxWJC");
      }

      static {
         I();
         SHOWN = new CPacketRecipeInfo.Purpose(I["".length()], "".length());
         SETTINGS = new CPacketRecipeInfo.Purpose(I[" ".length()], " ".length());
         CPacketRecipeInfo.Purpose[] var10000 = new CPacketRecipeInfo.Purpose["  ".length()];
         var10000["".length()] = SHOWN;
         var10000[" ".length()] = SETTINGS;
      }
   }
}

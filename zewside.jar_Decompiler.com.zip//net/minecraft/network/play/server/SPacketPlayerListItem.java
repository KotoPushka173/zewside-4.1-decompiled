package net.minecraft.network.play.server;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.GameType;

public class SPacketPlayerListItem implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private SPacketPlayerListItem.Action action;
   // $FF: synthetic field
   private final List<SPacketPlayerListItem.AddPlayerData> players = Lists.newArrayList();

   public String toString() {
      return MoreObjects.toStringHelper(this).add(I[63 ^ 71], this.action).add(I[23 ^ 110], this.players).toString();
   }

   public SPacketPlayerListItem.Action getAction() {
      return this.action;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[135 ^ 131];
      var10001 = I[70 ^ 67];
      var10002 = I[14 ^ 8];
      var10001 = I[10 ^ 13];
      var10000 = I[6 ^ 14];
      var10001 = I[115 ^ 122];
      var10002 = I[44 ^ 38];
      var10001 = I[89 ^ 82];
      var10000 = I[183 ^ 187];
      var10001 = I[51 ^ 62];
      var10002 = I[104 ^ 102];
      var10001 = I[6 ^ 9];
      var10000 = I[54 ^ 38];
      var10001 = I[160 ^ 177];
      var10002 = I[212 ^ 198];
      var10001 = I[114 ^ 97];
      var10000 = I[154 ^ 142];
      var10001 = I[81 ^ 68];
      var10002 = I[183 ^ 161];
      var10001 = I[96 ^ 119];
      var10000 = I[73 ^ 81];
      var10001 = I[90 ^ 67];
      var10002 = I[1 ^ 27];
      var10001 = I[220 ^ 199];
      var10000 = I[2 ^ 30];
      var10001 = I[74 ^ 87];
      var10002 = I[54 ^ 40];
      var10001 = I[130 ^ 157];
      this.action = (SPacketPlayerListItem.Action)var1.readEnumValue(SPacketPlayerListItem.Action.class);
      int var2 = var1.readVarIntFromBuffer();
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            return;
         }

         GameProfile var4 = null;
         int var5 = "".length();
         GameType var6 = null;
         ITextComponent var7 = null;
         switch(null.$SwitchMap$net$minecraft$network$play$server$SPacketPlayerListItem$Action[this.action.ordinal()]) {
         case 1:
            I[46 ^ 14].length();
            I[159 ^ 190].length();
            I[163 ^ 129].length();
            var4 = new GameProfile(var1.readUuid(), var1.readStringFromBuffer(185 ^ 169));
            int var8 = var1.readVarIntFromBuffer();
            int var9 = "".length();

            while(var9 < var8) {
               String var10 = var1.readStringFromBuffer(18645 + 1350 - -4189 + 8583);
               String var11 = var1.readStringFromBuffer(28275 + 32309 - '风' + 11301);
               PropertyMap var12;
               if (var1.readBoolean()) {
                  var12 = var4.getProperties();
                  I[148 ^ 183].length();
                  var12.put(var10, new Property(var10, var11, var1.readStringFromBuffer(30158 + 7062 - 30446 + 25993)));
                  I[116 ^ 80].length();
                  I[46 ^ 11].length();
                  I[97 ^ 71].length();
                  "".length();
                  if (false) {
                     throw null;
                  }
               } else {
                  var12 = var4.getProperties();
                  I[46 ^ 9].length();
                  I[108 ^ 68].length();
                  var12.put(var10, new Property(var10, var11));
                  I[93 ^ 116].length();
                  I[7 ^ 45].length();
               }

               ++var9;
               "".length();
               if (-1 != -1) {
                  throw null;
               }
            }

            var6 = GameType.getByID(var1.readVarIntFromBuffer());
            var5 = var1.readVarIntFromBuffer();
            if (var1.readBoolean()) {
               var7 = var1.readTextComponent();
               "".length();
               if (2 == -1) {
                  throw null;
               }
            }
            break;
         case 2:
            I[32 ^ 11].length();
            I[22 ^ 58].length();
            var4 = new GameProfile(var1.readUuid(), (String)null);
            var6 = GameType.getByID(var1.readVarIntFromBuffer());
            "".length();
            if (3 < 0) {
               throw null;
            }
            break;
         case 3:
            I[117 ^ 88].length();
            I[171 ^ 133].length();
            I[139 ^ 164].length();
            I[59 ^ 11].length();
            var4 = new GameProfile(var1.readUuid(), (String)null);
            var5 = var1.readVarIntFromBuffer();
            "".length();
            if (4 <= 2) {
               throw null;
            }
            break;
         case 4:
            I[18 ^ 35].length();
            I[135 ^ 181].length();
            I[164 ^ 151].length();
            I[117 ^ 65].length();
            var4 = new GameProfile(var1.readUuid(), (String)null);
            if (var1.readBoolean()) {
               var7 = var1.readTextComponent();
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            }
            break;
         case 5:
            I[129 ^ 180].length();
            var4 = new GameProfile(var1.readUuid(), (String)null);
         }

         List var13 = this.players;
         I[63 ^ 9].length();
         I[46 ^ 25].length();
         I[65 ^ 121].length();
         var13.add(new SPacketPlayerListItem.AddPlayerData(var4, var5, var6, var7));
         I[26 ^ 35].length();
         I[20 ^ 46].length();
         I[32 ^ 27].length();
         I[130 ^ 190].length();
         I[162 ^ 159].length();
         ++var3;
         "".length();
      } while(4 >= -1);

      throw null;
   }

   private static void I() {
      I = new String[93 ^ 39];
      I["".length()] = I("于寇", "hDDij");
      I[" ".length()] = I("搱妟", "WsaQS");
      I["  ".length()] = I("暾憈", "rKzVR");
      I["   ".length()] = I("潡佦", "RVISk");
      I[192 ^ 196] = I("林浬", "FZosF");
      I[144 ^ 149] = I("悀掘", "eQxrk");
      I[142 ^ 136] = I("卂桥", "hMOFW");
      I[181 ^ 178] = I("杊戣", "dfgBg");
      I[132 ^ 140] = I("澤伮", "QSfdg");
      I[186 ^ 179] = I("呭潒", "riQCQ");
      I[165 ^ 175] = I("悍幽", "eoMzP");
      I[127 ^ 116] = I("弌幞", "UcBoO");
      I[80 ^ 92] = I("桴亞", "WPzkD");
      I[173 ^ 160] = I("支戔", "ARSnA");
      I[50 ^ 60] = I("孆楝", "FCrhX");
      I[29 ^ 18] = I("奂族", "pCkOu");
      I[32 ^ 48] = I("愤姕", "uLcIW");
      I[23 ^ 6] = I("弱椴", "iHBTU");
      I[9 ^ 27] = I("濽弚", "bFkPN");
      I[99 ^ 112] = I("摎坒", "WDYfl");
      I[11 ^ 31] = I("柜図", "HCavH");
      I[49 ^ 36] = I("呛傗", "qFwtE");
      I[114 ^ 100] = I("妔坩", "toFRs");
      I[15 ^ 24] = I("枺曷", "wBInH");
      I[89 ^ 65] = I("帧录", "eAQxd");
      I[155 ^ 130] = I("尨注", "jGmLi");
      I[156 ^ 134] = I("徽歷", "BoThN");
      I[94 ^ 69] = I("徜噴", "bbOTK");
      I[174 ^ 178] = I("摨俘", "FyHzw");
      I[148 ^ 137] = I("啐亝", "PtNye");
      I[189 ^ 163] = I("摡殺", "fGeYQ");
      I[161 ^ 190] = I("漐妝", "jthfs");
      I[59 ^ 27] = I("姎姈卵浒媯", "KsHYy");
      I[156 ^ 189] = I("朂妘", "GXKcg");
      I[37 ^ 7] = I("楰仅伂烐懙", "FMeDk");
      I[1 ^ 34] = I("峒恘县忡", "dakQC");
      I[52 ^ 16] = I("专幧仧擴", "xjImb");
      I[172 ^ 137] = I("囙旵啍", "ZCucf");
      I[124 ^ 90] = I("埡渾峪", "RAVps");
      I[123 ^ 92] = I("昞煨澒", "QalvY");
      I[131 ^ 171] = I("巘", "sEwlY");
      I[164 ^ 141] = I("渵啑瀳嚴", "nRsEI");
      I[47 ^ 5] = I("嶊弛歘", "hYaNk");
      I[239 ^ 196] = I("暔巖亚枎", "LrtzX");
      I[155 ^ 183] = I("懒", "RaZOq");
      I[168 ^ 133] = I("浣倦冬", "WxFti");
      I[167 ^ 137] = I("沇滈嶦丮浪", "NOLiw");
      I[0 ^ 47] = I("槰幞", "OKyMG");
      I[65 ^ 113] = I("恏啷屧", "dznbl");
      I[8 ^ 57] = I("劻", "GFRMC");
      I[105 ^ 91] = I("澀滙乣嚥槀", "PRCqW");
      I[110 ^ 93] = I("惮", "qQkFW");
      I[21 ^ 33] = I("殖摐", "ZxBuv");
      I[104 ^ 93] = I("炿岎晦", "OFfWM");
      I[165 ^ 147] = I("攉僤", "jVySj");
      I[74 ^ 125] = I("瀾", "eGXxY");
      I[55 ^ 15] = I("擁奡潮", "qDFVR");
      I[77 ^ 116] = I("匿姛侔", "uXUMI");
      I[62 ^ 4] = I("昹儰", "xIcJf");
      I[44 ^ 23] = I("合培傚", "hTJCH");
      I[59 ^ 7] = I("屣冠", "GEZze");
      I[107 ^ 86] = I("勾二", "YURZz");
      I[112 ^ 78] = I("剙", "yooVi");
      I[2 ^ 61] = I("佄捱丶", "qcLCc");
      I[15 ^ 79] = I("幇", "leZmb");
      I[18 ^ 83] = I("呑哃湵擃", "jUrIS");
      I[213 ^ 151] = I("倲", "cvAEe");
      I[92 ^ 31] = I("奔嘻", "qZZfu");
      I[60 ^ 120] = I("乪无咺嘩垃", "OkndW");
      I[103 ^ 34] = I("啍淋榯叴炧", "bOtNZ");
      I[118 ^ 48] = I("歟", "Xmcot");
      I[61 ^ 122] = I("垚垔墦撐勏", "KrrKs");
      I[23 ^ 95] = I("嚧侊俭", "AuHqC");
      I[138 ^ 195] = I("墒勔", "OScQG");
      I[209 ^ 155] = I("撬愭", "sWkAE");
      I[223 ^ 148] = I("嬴坉哌掩弰", "oBJQV");
      I[84 ^ 24] = I("剰拁", "Fcwik");
      I[59 ^ 118] = I("剗愣", "MYIKd");
      I[205 ^ 131] = I("潮", "zofsq");
      I[201 ^ 134] = I("吢奃崍", "ExueP");
      I[104 ^ 56] = I("俻濞卮汗", "OWPfB");
      I[255 ^ 174] = I("様啒採烓", "wWDsz");
      I[110 ^ 60] = I("劦洣凘", "tPUwG");
      I[93 ^ 14] = I("橍娼揾宅", "odhzV");
      I[53 ^ 97] = I("晟憂汑嚗", "tEawo");
      I[240 ^ 165] = I("咧撒壒怸勌", "XiXxC");
      I[87 ^ 1] = I("垠姂", "UCIhb");
      I[71 ^ 16] = I("彄", "dLQHD");
      I[227 ^ 187] = I("庇沦撳咟擿", "AahDG");
      I[45 ^ 116] = I("丷僿埪坆", "YGkMj");
      I[38 ^ 124] = I("檞庭瀤嶽塏", "lgLNj");
      I[18 ^ 73] = I("悪侁", "ujOuQ");
      I[73 ^ 21] = I("傑妧墆幵捐", "yIeoJ");
      I[66 ^ 31] = I("嶢憴夦", "QJbQY");
      I[121 ^ 39] = I("搒", "dRUwr");
      I[39 ^ 120] = I("暏嗓攈演", "InGDa");
      I[74 ^ 42] = I("卄撑灦氯扢", "wPzWy");
      I[213 ^ 180] = I("嚻偧涫", "UKPwC");
      I[248 ^ 154] = I("嵤榺桷梔氦", "TygNj");
      I[25 ^ 122] = I("令", "XZBkG");
      I[76 ^ 40] = I("櫽冁挽", "qTTnY");
      I[59 ^ 94] = I("娩槌椛惄", "Ioufw");
      I[40 ^ 78] = I("涥", "RzOUF");
      I[119 ^ 16] = I("憼攂", "PhhUU");
      I[53 ^ 93] = I("嬇哢", "RtxGv");
      I[251 ^ 146] = I("崄廯撂", "FnmJa");
      I[44 ^ 70] = I("泜", "hJqrN");
      I[21 ^ 126] = I("埞攂昝攈厄", "SFrMS");
      I[254 ^ 146] = I("彗湝厫湾嚃", "ayMxF");
      I[48 ^ 93] = I("壜媰戇彂烤", "mSKDI");
      I[99 ^ 13] = I("嬫愼欥櫀", "HDnew");
      I[13 ^ 98] = I("嶵匛", "jCUCJ");
      I[33 ^ 81] = I("嗠尺機噓伔", "cTIlQ");
      I[241 ^ 128] = I("嗪淇婕烞媚", "ezTaz");
      I[232 ^ 154] = I("七想櫦", "KgLSM");
      I[228 ^ 151] = I("娒", "Rttgs");
      I[199 ^ 179] = I("夙", "WMxCE");
      I[28 ^ 105] = I("操橺", "GfLXR");
      I[54 ^ 64] = I("灷冉斘唪", "FDvSY");
      I[1 ^ 118] = I("婢瀡漟妳忁", "agAZw");
      I[50 ^ 74] = I(")\u0001\u0016\u0013.&", "HbbzA");
      I[6 ^ 127] = I("\f\u001b\u0007\u0014.\f\u0006", "iusfG");
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handlePlayerListItem(this);
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 4);

      throw null;
   }

   public SPacketPlayerListItem(SPacketPlayerListItem.Action var1, EntityPlayerMP... var2) {
      this.action = var1;
      EntityPlayerMP[] var3 = var2;
      int var4 = var2.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         EntityPlayerMP var6 = var3[var5];
         this.players.add(new SPacketPlayerListItem.AddPlayerData(var6.getGameProfile(), var6.ping, var6.interactionManager.getGameType(), var6.getTabListDisplayName()));
         ++var5;
         "".length();
      } while(0 > -1);

      throw null;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.action);
      I[114 ^ 76].length();
      var1.writeVarIntToBuffer(this.players.size());
      I[122 ^ 69].length();
      I[220 ^ 156].length();
      Iterator var2 = this.players.iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         SPacketPlayerListItem.AddPlayerData var3 = (SPacketPlayerListItem.AddPlayerData)var2.next();
         switch(null.$SwitchMap$net$minecraft$network$play$server$SPacketPlayerListItem$Action[this.action.ordinal()]) {
         case 1:
            var1.writeUuid(var3.getProfile().getId());
            I[229 ^ 164].length();
            I[52 ^ 118].length();
            I[5 ^ 70].length();
            I[225 ^ 165].length();
            I[212 ^ 145].length();
            var1.writeString(var3.getProfile().getName());
            I[100 ^ 34].length();
            var1.writeVarIntToBuffer(var3.getProfile().getProperties().size());
            I[215 ^ 144].length();
            I[107 ^ 35].length();
            I[9 ^ 64].length();
            I[197 ^ 143].length();
            Iterator var4 = var3.getProfile().getProperties().values().iterator();

            while(var4.hasNext()) {
               Property var5 = (Property)var4.next();
               var1.writeString(var5.getName());
               I[50 ^ 121].length();
               var1.writeString(var5.getValue());
               I[207 ^ 131].length();
               I[11 ^ 70].length();
               I[214 ^ 152].length();
               if (var5.hasSignature()) {
                  var1.writeBoolean((boolean)" ".length());
                  I[91 ^ 20].length();
                  I[218 ^ 138].length();
                  I[59 ^ 106].length();
                  var1.writeString(var5.getSignature());
                  I[214 ^ 132].length();
                  I[62 ^ 109].length();
                  I[51 ^ 103].length();
                  I[199 ^ 146].length();
                  "".length();
                  if (-1 != -1) {
                     throw null;
                  }
               } else {
                  var1.writeBoolean((boolean)"".length());
                  I[97 ^ 55].length();
                  I[203 ^ 156].length();
                  I[84 ^ 12].length();
               }

               "".length();
               if (3 == 1) {
                  throw null;
               }
            }

            var1.writeVarIntToBuffer(var3.getGameMode().getID());
            I[96 ^ 57].length();
            var1.writeVarIntToBuffer(var3.getPing());
            I[11 ^ 81].length();
            I[194 ^ 153].length();
            if (var3.getDisplayName() == null) {
               var1.writeBoolean((boolean)"".length());
               I[31 ^ 67].length();
               I[251 ^ 166].length();
               I[15 ^ 81].length();
               I[17 ^ 78].length();
               I[65 ^ 33].length();
               "".length();
               if (0 == 2) {
                  throw null;
               }
            } else {
               var1.writeBoolean((boolean)" ".length());
               I[212 ^ 181].length();
               var1.writeTextComponent(var3.getDisplayName());
               I[220 ^ 190].length();
               I[97 ^ 2].length();
               "".length();
               if (2 == 0) {
                  throw null;
               }
            }
            break;
         case 2:
            var1.writeUuid(var3.getProfile().getId());
            I[165 ^ 193].length();
            I[69 ^ 32].length();
            I[7 ^ 97].length();
            I[22 ^ 113].length();
            var1.writeVarIntToBuffer(var3.getGameMode().getID());
            I[208 ^ 184].length();
            I[40 ^ 65].length();
            I[232 ^ 130].length();
            "".length();
            if (4 == -1) {
               throw null;
            }
            break;
         case 3:
            var1.writeUuid(var3.getProfile().getId());
            I[18 ^ 121].length();
            I[36 ^ 72].length();
            var1.writeVarIntToBuffer(var3.getPing());
            I[75 ^ 38].length();
            I[43 ^ 69].length();
            "".length();
            if (4 != 4) {
               throw null;
            }
            break;
         case 4:
            var1.writeUuid(var3.getProfile().getId());
            I[48 ^ 95].length();
            I[235 ^ 155].length();
            I[54 ^ 71].length();
            I[35 ^ 81].length();
            if (var3.getDisplayName() == null) {
               var1.writeBoolean((boolean)"".length());
               I[67 ^ 48].length();
               I[18 ^ 102].length();
               "".length();
               if (0 >= 3) {
                  throw null;
               }
            } else {
               var1.writeBoolean((boolean)" ".length());
               I[222 ^ 171].length();
               var1.writeTextComponent(var3.getDisplayName());
               I[75 ^ 61].length();
               "".length();
               if (-1 != -1) {
                  throw null;
               }
            }
            break;
         case 5:
            var1.writeUuid(var3.getProfile().getId());
            I[179 ^ 196].length();
         }

         "".length();
      } while(4 >= 2);

      throw null;
   }

   public SPacketPlayerListItem() {
   }

   public SPacketPlayerListItem(SPacketPlayerListItem.Action var1, Iterable<EntityPlayerMP> var2) {
      this.action = var1;
      Iterator var3 = var2.iterator();

      do {
         if (!var3.hasNext()) {
            return;
         }

         EntityPlayerMP var4 = (EntityPlayerMP)var3.next();
         this.players.add(new SPacketPlayerListItem.AddPlayerData(var4.getGameProfile(), var4.ping, var4.interactionManager.getGameType(), var4.getTabListDisplayName()));
         "".length();
      } while(3 != 1);

      throw null;
   }

   public List<SPacketPlayerListItem.AddPlayerData> getEntries() {
      return this.players;
   }

   public class AddPlayerData {
      // $FF: synthetic field
      private final ITextComponent displayName;
      // $FF: synthetic field
      private final GameType gamemode;
      // $FF: synthetic field
      private final int ping;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final GameProfile profile;

      private static void I() {
         I = new String[124 ^ 120];
         I["".length()] = I("\u000b\u0018\u0010=\b\u0004\u0000", "gydXf");
         I[" ".length()] = I("\u0000 \u0004\b(\b%\f", "gAime");
         I["  ".length()] = I("\u0004\u0003\f\u0015\r\u0018\u0014", "tqcsd");
         I["   ".length()] = I("\u0001\"=\u001a\r\u00042\u0000\u000b\f\u0000", "eKNja");
      }

      static {
         I();
      }

      public AddPlayerData(GameProfile var2, int var3, GameType var4, @Nullable ITextComponent var5) {
         this.profile = var2;
         this.ping = var3;
         this.gamemode = var4;
         this.displayName = var5;
      }

      public GameProfile getProfile() {
         return this.profile;
      }

      public String toString() {
         ToStringHelper var10000 = MoreObjects.toStringHelper(this).add(I["".length()], this.ping).add(I[" ".length()], this.gamemode).add(I["  ".length()], this.profile);
         String var10001 = I["   ".length()];
         String var10002;
         if (this.displayName == null) {
            var10002 = null;
            "".length();
            if (-1 >= 3) {
               throw null;
            }
         } else {
            var10002 = ITextComponent.Serializer.componentToJson(this.displayName);
         }

         return var10000.add(var10001, var10002).toString();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 < 4);

         throw null;
      }

      public int getPing() {
         return this.ping;
      }

      public GameType getGameMode() {
         return this.gamemode;
      }

      @Nullable
      public ITextComponent getDisplayName() {
         return this.displayName;
      }
   }

   public static enum Action {
      // $FF: synthetic field
      UPDATE_DISPLAY_NAME;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      ADD_PLAYER,
      // $FF: synthetic field
      UPDATE_LATENCY,
      // $FF: synthetic field
      UPDATE_GAME_MODE,
      // $FF: synthetic field
      REMOVE_PLAYER;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(true);

         throw null;
      }

      private static void I() {
         I = new String[177 ^ 180];
         I["".length()] = I("%%\u000b\r\t( \u0016\u0017\u000b", "daORY");
         I[" ".length()] = I(";5\u0011\u0006\u0011+:\u0012\u0006\b+:\u0018\b\u0001+", "neUGE");
         I["  ".length()] = I("<\u001a'26,\u0015/26,\u0004 *", "iJcsb");
         I["   ".length()] = I("\u0018?\u0001\u0007\u0005\b0\u0001\u000f\u0002\u001d#\u0004\u001f\u000e\u0003.\b\u0003", "MoEFQ");
         I[51 ^ 55] = I("\"\u0002=# 5\u0018  7)\u0002\"", "pGplv");
      }

      static {
         I();
         ADD_PLAYER = new SPacketPlayerListItem.Action(I["".length()], "".length());
         UPDATE_GAME_MODE = new SPacketPlayerListItem.Action(I[" ".length()], " ".length());
         UPDATE_LATENCY = new SPacketPlayerListItem.Action(I["  ".length()], "  ".length());
         UPDATE_DISPLAY_NAME = new SPacketPlayerListItem.Action(I["   ".length()], "   ".length());
         REMOVE_PLAYER = new SPacketPlayerListItem.Action(I[28 ^ 24], 136 ^ 140);
         SPacketPlayerListItem.Action[] var10000 = new SPacketPlayerListItem.Action[38 ^ 35];
         var10000["".length()] = ADD_PLAYER;
         var10000[" ".length()] = UPDATE_GAME_MODE;
         var10000["  ".length()] = UPDATE_LATENCY;
         var10000["   ".length()] = UPDATE_DISPLAY_NAME;
         var10000[9 ^ 13] = REMOVE_PLAYER;
      }
   }
}

package net.minecraft.block.material;

import net.minecraft.item.EnumDyeColor;

public class MapColor {
   // $FF: synthetic field
   public static final MapColor PINK;
   // $FF: synthetic field
   public static final MapColor FOLIAGE;
   // $FF: synthetic field
   public static final MapColor SAND;
   // $FF: synthetic field
   public static final MapColor ICE;
   // $FF: synthetic field
   public static final MapColor CYAN;
   // $FF: synthetic field
   public static final MapColor field_193573_Y;
   // $FF: synthetic field
   public static final MapColor QUARTZ;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final MapColor TNT;
   // $FF: synthetic field
   public static final MapColor GRASS;
   // $FF: synthetic field
   public static final MapColor field_193564_P;
   // $FF: synthetic field
   public static final MapColor BLUE;
   // $FF: synthetic field
   public static final MapColor OBSIDIAN;
   // $FF: synthetic field
   public static final MapColor LIME;
   // $FF: synthetic field
   public static final MapColor CLOTH;
   // $FF: synthetic field
   public static final MapColor field_193574_Z;
   // $FF: synthetic field
   public static final MapColor GREEN;
   // $FF: synthetic field
   public static final MapColor YELLOW;
   // $FF: synthetic field
   public static final MapColor LAPIS;
   // $FF: synthetic field
   public static final MapColor field_193565_Q;
   // $FF: synthetic field
   public static final MapColor CLAY;
   // $FF: synthetic field
   public static final MapColor field_193562_N;
   // $FF: synthetic field
   public static final MapColor field_193570_V;
   // $FF: synthetic field
   public static final MapColor GRAY;
   // $FF: synthetic field
   public static final MapColor BLACK;
   // $FF: synthetic field
   public static final MapColor GOLD;
   // $FF: synthetic field
   public static final MapColor[] field_193575_b;
   // $FF: synthetic field
   public static final MapColor NETHERRACK;
   // $FF: synthetic field
   public static final MapColor DIAMOND;
   // $FF: synthetic field
   public static final MapColor BROWN;
   // $FF: synthetic field
   public static final MapColor field_193560_ab;
   // $FF: synthetic field
   public static final MapColor field_193568_T;
   // $FF: synthetic field
   public static final MapColor SILVER;
   // $FF: synthetic field
   public static final MapColor field_193572_X;
   // $FF: synthetic field
   public static final MapColor WOOD;
   // $FF: synthetic field
   public static final MapColor field_193566_R;
   // $FF: synthetic field
   public static final MapColor ADOBE;
   // $FF: synthetic field
   public static final MapColor field_193563_O;
   // $FF: synthetic field
   public static final MapColor field_193567_S;
   // $FF: synthetic field
   public static final MapColor field_193559_aa;
   // $FF: synthetic field
   public int colorValue;
   // $FF: synthetic field
   public static final MapColor IRON;
   // $FF: synthetic field
   public static final MapColor[] COLORS;
   // $FF: synthetic field
   public static final MapColor SNOW;
   // $FF: synthetic field
   public static final MapColor PURPLE;
   // $FF: synthetic field
   public static final MapColor AIR;
   // $FF: synthetic field
   public static final MapColor LIGHT_BLUE;
   // $FF: synthetic field
   public static final MapColor RED;
   // $FF: synthetic field
   public static final MapColor STONE;
   // $FF: synthetic field
   public static final MapColor DIRT;
   // $FF: synthetic field
   public static final MapColor field_193569_U;
   // $FF: synthetic field
   public static final MapColor MAGENTA;
   // $FF: synthetic field
   public final int colorIndex;
   // $FF: synthetic field
   public static final MapColor EMERALD;
   // $FF: synthetic field
   public static final MapColor field_193561_M;
   // $FF: synthetic field
   public static final MapColor field_193571_W;
   // $FF: synthetic field
   public static final MapColor WATER;

   static {
      I();
      COLORS = new MapColor[200 ^ 136];
      field_193575_b = new MapColor[38 ^ 54];
      AIR = new MapColor("".length(), "".length());
      GRASS = new MapColor(" ".length(), 3017552 + 4883284 - -231534 + 236326);
      SAND = new MapColor("  ".length(), 7479733 + 9936363 - 14251457 + 13082564);
      CLOTH = new MapColor("   ".length(), 835399 + 7576790 - 4158023 + 8838641);
      TNT = new MapColor(24 ^ 28, 1960083 + 14604515 - 13897495 + 14044577);
      ICE = new MapColor(172 ^ 169, 5925732 + 4975790 - 2704921 + 2330374);
      IRON = new MapColor(105 ^ 111, 2551453 + 7359240 - 5608920 + 6685658);
      FOLIAGE = new MapColor(119 ^ 112, 4171 + 1494 - -4955 + 21124);
      SNOW = new MapColor(181 ^ 189, 4725584 + 5462015 - -6130371 + 459245);
      CLAY = new MapColor(21 ^ 28, 844570 + 7178546 - -850397 + 1917583);
      DIRT = new MapColor(85 ^ 95, 8071894 + 9119509 - 11009618 + 3742132);
      STONE = new MapColor(83 ^ 88, 5575109 + 4878558 - 4259738 + 1174887);
      WATER = new MapColor(108 ^ 96, 1729739 + 625869 - -1761729 + 93606);
      WOOD = new MapColor(34 ^ 47, 5089470 + 6041213 - 7855600 + 6127101);
      QUARTZ = new MapColor(83 ^ 93, 16445955 + 16369072 - 28304383 + 12265793);
      ADOBE = new MapColor(176 ^ 191, 9362897 + 2461316 - -498769 + 1865357);
      MAGENTA = new MapColor(77 ^ 93, 4709413 + 10860923 - 6044804 + 2159548);
      LIGHT_BLUE = new MapColor(24 ^ 9, 5068760 + 4726504 - 7031309 + 3960101);
      YELLOW = new MapColor(56 ^ 42, 12306792 + 12312613 - 21629920 + 12076934);
      LIME = new MapColor(101 ^ 118, 842385 + 799552 - -1211073 + 5522311);
      PINK = new MapColor(114 ^ 102, 6796954 + 12052782 - 4689294 + 1731947);
      GRAY = new MapColor(22 ^ 3, 1796957 + 1975569 - -872916 + 354826);
      SILVER = new MapColor(48 ^ 38, 1154579 + 9757584 - 5237879 + 4392045);
      CYAN = new MapColor(130 ^ 149, 3719235 + 2275108 - 4457542 + 3476600);
      PURPLE = new MapColor(98 ^ 122, 5334755 + 858502 - 1666300 + 3812421);
      BLUE = new MapColor(4 ^ 29, 3315590 + 1762467 - 4826569 + 3110482);
      BROWN = new MapColor(8 ^ 18, 5419320 + 1668108 - 6213243 + 5829994);
      GREEN = new MapColor(78 ^ 85, 1270976 + 5555233 - 5466096 + 5357122);
      RED = new MapColor(110 ^ 114, 4810471 + 1498001 - 2058237 + 5789880);
      BLACK = new MapColor(100 ^ 121, 1100938 + 1024953 - 1738833 + 1257767);
      GOLD = new MapColor(72 ^ 86, 12835449 + 15412253 - 22730339 + 10927642);
      DIAMOND = new MapColor(8 ^ 23, 3021485 + 543056 - 3031862 + 5552910);
      LAPIS = new MapColor(110 ^ 78, 3131815 + 991969 - 116304 + 875207);
      EMERALD = new MapColor(79 ^ 110, 19178 + 3600 - -26442 + 6390);
      OBSIDIAN = new MapColor(113 ^ 83, 961398 + 2859732 - 3703502 + 8358581);
      NETHERRACK = new MapColor(225 ^ 194, 7205115 + 6436417 - 7698002 + 1397014);
      field_193561_M = new MapColor(67 ^ 103, 9242473 + 7183475 - 11590307 + 8906856);
      field_193562_N = new MapColor(139 ^ 174, 3366967 + 872580 - -5845175 + 356530);
      field_193563_O = new MapColor(79 ^ 105, 878996 + 951983 - -6194450 + 1761815);
      field_193564_P = new MapColor(231 ^ 192, 4127583 + 5904085 - 2877975 + 214125);
      field_193565_Q = new MapColor(238 ^ 198, 3059068 + 8307886 - 4643040 + 5499866);
      field_193566_R = new MapColor(121 ^ 80, 3392794 + 1225911 - 2363005 + 4524513);
      field_193567_S = new MapColor(130 ^ 168, 7794511 + 2163088 - 8110807 + 8658758);
      field_193568_T = new MapColor(155 ^ 176, 3503229 + 927859 - 2737142 + 2052137);
      field_193569_U = new MapColor(79 ^ 99, 751882 + 2763529 - 228146 + 5587585);
      field_193570_V = new MapColor(104 ^ 69, 2807099 + 4572287 - 4447180 + 2793070);
      field_193571_W = new MapColor(156 ^ 178, 2098466 + 4626577 - -1238522 + '얫');
      field_193572_X = new MapColor(147 ^ 188, 2084734 + 961573 - 1896784 + 3847177);
      field_193573_Y = new MapColor(86 ^ 102, 3250614 + 1002636 - 1700190 + 2440511);
      field_193574_Z = new MapColor(12 ^ 61, 1962287 + 469806 - -2156033 + 413644);
      field_193559_aa = new MapColor(61 ^ 15, 1427118 + 8707380 - 1444468 + 631488);
      field_193560_ab = new MapColor(88 ^ 107, 803412 + 675466 - 861009 + 1812611);
      field_193575_b[EnumDyeColor.WHITE.getMetadata()] = SNOW;
      field_193575_b[EnumDyeColor.ORANGE.getMetadata()] = ADOBE;
      field_193575_b[EnumDyeColor.MAGENTA.getMetadata()] = MAGENTA;
      field_193575_b[EnumDyeColor.LIGHT_BLUE.getMetadata()] = LIGHT_BLUE;
      field_193575_b[EnumDyeColor.YELLOW.getMetadata()] = YELLOW;
      field_193575_b[EnumDyeColor.LIME.getMetadata()] = LIME;
      field_193575_b[EnumDyeColor.PINK.getMetadata()] = PINK;
      field_193575_b[EnumDyeColor.GRAY.getMetadata()] = GRAY;
      field_193575_b[EnumDyeColor.SILVER.getMetadata()] = SILVER;
      field_193575_b[EnumDyeColor.CYAN.getMetadata()] = CYAN;
      field_193575_b[EnumDyeColor.PURPLE.getMetadata()] = PURPLE;
      field_193575_b[EnumDyeColor.BLUE.getMetadata()] = BLUE;
      field_193575_b[EnumDyeColor.BROWN.getMetadata()] = BROWN;
      field_193575_b[EnumDyeColor.GREEN.getMetadata()] = GREEN;
      field_193575_b[EnumDyeColor.RED.getMetadata()] = RED;
      field_193575_b[EnumDyeColor.BLACK.getMetadata()] = BLACK;
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("*%\u001de\u0010\b(\u00020\u0001G\r)e\u001e\u00127\u0019e\u0011\u0002d\u000f \u0007\u0010!\b+SWd\f+\u0017Gr^e[\u000e*\u000e)\u0006\u0014-\u001b Z", "gDmEs");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 0);

      throw null;
   }

   public static MapColor func_193558_a(EnumDyeColor var0) {
      return field_193575_b[var0.getMetadata()];
   }

   private MapColor(int var1, int var2) {
      if (var1 >= 0 && var1 <= (167 ^ 152)) {
         this.colorIndex = var1;
         this.colorValue = var2;
         COLORS[var1] = this;
         "".length();
         if (2 <= -1) {
            throw null;
         }
      } else {
         throw new IndexOutOfBoundsException(I["".length()]);
      }
   }

   public int getMapColor(int var1) {
      int var2 = 168 + 83 - 107 + 76;
      if (var1 == "   ".length()) {
         var2 = 45 + 1 - 33 + 122;
      }

      if (var1 == "  ".length()) {
         var2 = 83 + 30 - 72 + 214;
      }

      if (var1 == " ".length()) {
         var2 = 51 + 143 - 105 + 131;
      }

      if (var1 == 0) {
         var2 = 30 + 175 - 104 + 79;
      }

      int var3 = (this.colorValue >> (167 ^ 183) & 244 + 173 - 384 + 222) * var2 / (70 + 27 - 55 + 213);
      int var4 = (this.colorValue >> (112 ^ 120) & 88 + 28 - -74 + 65) * var2 / (206 + 0 - -33 + 16);
      int var5 = (this.colorValue & 193 + 102 - 231 + 191) * var2 / (127 + 80 - 21 + 69);
      return -(14147695 + 13872480 - 15146754 + 3903795) | var3 << (215 ^ 199) | var4 << (188 ^ 180) | var5;
   }
}

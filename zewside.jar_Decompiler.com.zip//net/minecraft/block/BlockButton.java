package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockButton extends BlockDirectional {
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_SOUTH_ON;
   // $FF: synthetic field
   private final boolean wooden;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_UP_OFF;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_WEST_ON;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_EAST_ON;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_EAST_OFF;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_DOWN_OFF;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_DOWN_ON;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_SOUTH_OFF;
   // $FF: synthetic field
   public static final PropertyBool POWERED;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_NORTH_ON;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_UP_ON;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_WEST_OFF;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_NORTH_OFF;
   // $FF: synthetic field
   private static final String[] I;

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if ((Boolean)var1.getValue(POWERED)) {
         var10000 = 79 ^ 64;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   public int tickRate(World var1) {
      int var10000;
      if (this.wooden) {
         var10000 = 78 ^ 80;
         "".length();
         if (0 >= 3) {
            throw null;
         }
      } else {
         var10000 = 60 ^ 40;
      }

      return var10000;
   }

   private void checkPressed(IBlockState var1, World var2, BlockPos var3) {
      String var10000 = I[165 ^ 174];
      String var10001 = I[70 ^ 74];
      String var10002 = I[32 ^ 45];
      var10001 = I[173 ^ 163];
      List var4 = var2.getEntitiesWithinAABB(EntityArrow.class, var1.getBoundingBox(var2, var3).offset(var3));
      int var7;
      if (!var4.isEmpty()) {
         var7 = " ".length();
         "".length();
         if (0 < 0) {
            throw null;
         }
      } else {
         var7 = "".length();
      }

      int var5 = var7;
      boolean var6 = (Boolean)var1.getValue(POWERED);
      if (var5 != 0 && !var6) {
         var2.setBlockState(var3, var1.withProperty(POWERED, Boolean.valueOf((boolean)" ".length())));
         I[147 ^ 156].length();
         I[161 ^ 177].length();
         this.notifyNeighbors(var2, var3, (EnumFacing)var1.getValue(FACING));
         var2.markBlockRangeForRenderUpdate(var3, var3);
         this.playClickSound((EntityPlayer)null, var2, var3);
      }

      if (var5 == 0 && var6) {
         var2.setBlockState(var3, var1.withProperty(POWERED, Boolean.valueOf((boolean)"".length())));
         I[72 ^ 89].length();
         I[40 ^ 58].length();
         I[90 ^ 73].length();
         this.notifyNeighbors(var2, var3, (EnumFacing)var1.getValue(FACING));
         var2.markBlockRangeForRenderUpdate(var3, var3);
         this.playReleaseSound(var2, var3);
      }

      if (var5 != 0) {
         I[164 ^ 176].length();
         I[96 ^ 117].length();
         I[189 ^ 171].length();
         var2.scheduleUpdate(new BlockPos(var3), this, this.tickRate(var2));
      }

   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      if (!var1.isRemote && this.wooden && !(Boolean)var3.getValue(POWERED)) {
         this.checkPressed(var3, var1, var2);
      }

   }

   protected static boolean canPlaceBlock(World var0, BlockPos var1, EnumFacing var2) {
      BlockPos var3 = var1.offset(var2.getOpposite());
      IBlockState var4 = var0.getBlockState(var3);
      int var10000;
      if (var4.func_193401_d(var0, var3, var2) == BlockFaceShape.SOLID) {
         var10000 = " ".length();
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var5 = var10000;
      Block var6 = var4.getBlock();
      if (var2 == EnumFacing.UP) {
         if (var6 != Blocks.HOPPER && (func_193384_b(var6) || var5 == 0)) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (0 == 3) {
               throw null;
            }
         }

         return (boolean)var10000;
      } else {
         if (!func_193382_c(var6) && var5 != 0) {
            var10000 = " ".length();
            "".length();
            if (3 < 1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   protected BlockButton(boolean var1) {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(POWERED, Boolean.valueOf((boolean)"".length())));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.REDSTONE);
      this.wooden = var1;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      EnumFacing var4 = (EnumFacing)var1.getValue(FACING);
      boolean var5 = (Boolean)var1.getValue(POWERED);
      AxisAlignedBB var10000;
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var4.ordinal()]) {
      case 1:
         if (var5) {
            var10000 = AABB_EAST_ON;
            "".length();
            if (2 <= 0) {
               throw null;
            }
         } else {
            var10000 = AABB_EAST_OFF;
         }

         return var10000;
      case 2:
         if (var5) {
            var10000 = AABB_WEST_ON;
            "".length();
            if (1 == -1) {
               throw null;
            }
         } else {
            var10000 = AABB_WEST_OFF;
         }

         return var10000;
      case 3:
         if (var5) {
            var10000 = AABB_SOUTH_ON;
            "".length();
            if (3 < 0) {
               throw null;
            }
         } else {
            var10000 = AABB_SOUTH_OFF;
         }

         return var10000;
      case 4:
      default:
         if (var5) {
            var10000 = AABB_NORTH_ON;
            "".length();
            if (2 != 2) {
               throw null;
            }
         } else {
            var10000 = AABB_NORTH_OFF;
         }

         return var10000;
      case 5:
         if (var5) {
            var10000 = AABB_UP_ON;
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10000 = AABB_UP_OFF;
         }

         return var10000;
      case 6:
         if (var5) {
            var10000 = AABB_DOWN_ON;
            "".length();
            if (1 >= 2) {
               throw null;
            }
         } else {
            var10000 = AABB_DOWN_OFF;
         }

         return var10000;
      }
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      IBlockState var10000;
      if (canPlaceBlock(var1, var2, var3)) {
         var10000 = this.getDefaultState().withProperty(FACING, var3).withProperty(POWERED, Boolean.valueOf((boolean)"".length()));
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10000 = this.getDefaultState().withProperty(FACING, EnumFacing.DOWN).withProperty(POWERED, Boolean.valueOf((boolean)"".length()));
      }

      return var10000;
   }

   protected abstract void playReleaseSound(World var1, BlockPos var2);

   protected BlockStateContainer createBlockState() {
      String var10000 = I[79 ^ 88];
      String var10001 = I[66 ^ 90];
      String var10002 = I[177 ^ 168];
      var10001 = I[172 ^ 182];
      var10000 = I[109 ^ 118];
      var10001 = I[109 ^ 113];
      var10002 = I[148 ^ 137];
      var10001 = I[28 ^ 2];
      var10000 = I[61 ^ 34];
      var10001 = I[64 ^ 96];
      var10002 = I[141 ^ 172];
      var10001 = I[80 ^ 114];
      I[177 ^ 146].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[46 ^ 10].length();
      I[173 ^ 136].length();
      I[113 ^ 87].length();
      var10003["".length()] = FACING;
      I[97 ^ 70].length();
      I[40 ^ 0].length();
      I[89 ^ 112].length();
      I[174 ^ 132].length();
      var10003[" ".length()] = POWERED;
      return new BlockStateContainer(this, var10003);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (this.checkForDrop(var2, var3, var1) && !canPlaceBlock(var2, var3, (EnumFacing)var1.getValue(FACING))) {
         this.dropBlockAsItem(var2, var3, var1, "".length());
         var2.setBlockToAir(var3);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }

   }

   private void notifyNeighbors(World var1, BlockPos var2, EnumFacing var3) {
      var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
      var1.notifyNeighborsOfStateChange(var2.offset(var3.getOpposite()), this, (boolean)"".length());
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void randomTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
   }

   public boolean canProvidePower(IBlockState var1) {
      return (boolean)" ".length();
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 2);

      throw null;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public boolean canPlaceBlockOnSide(World var1, BlockPos var2, EnumFacing var3) {
      return canPlaceBlock(var1, var2, var3);
   }

   static {
      I();
      POWERED = PropertyBool.create(I[147 ^ 184]);
      AABB_DOWN_OFF = new AxisAlignedBB(0.3125D, 0.875D, 0.375D, 0.6875D, 1.0D, 0.625D);
      AABB_UP_OFF = new AxisAlignedBB(0.3125D, 0.0D, 0.375D, 0.6875D, 0.125D, 0.625D);
      AABB_NORTH_OFF = new AxisAlignedBB(0.3125D, 0.375D, 0.875D, 0.6875D, 0.625D, 1.0D);
      AABB_SOUTH_OFF = new AxisAlignedBB(0.3125D, 0.375D, 0.0D, 0.6875D, 0.625D, 0.125D);
      AABB_WEST_OFF = new AxisAlignedBB(0.875D, 0.375D, 0.3125D, 1.0D, 0.625D, 0.6875D);
      AABB_EAST_OFF = new AxisAlignedBB(0.0D, 0.375D, 0.3125D, 0.125D, 0.625D, 0.6875D);
      AABB_DOWN_ON = new AxisAlignedBB(0.3125D, 0.9375D, 0.375D, 0.6875D, 1.0D, 0.625D);
      AABB_UP_ON = new AxisAlignedBB(0.3125D, 0.0D, 0.375D, 0.6875D, 0.0625D, 0.625D);
      AABB_NORTH_ON = new AxisAlignedBB(0.3125D, 0.375D, 0.9375D, 0.6875D, 0.625D, 1.0D);
      AABB_SOUTH_ON = new AxisAlignedBB(0.3125D, 0.375D, 0.0D, 0.6875D, 0.625D, 0.0625D);
      AABB_WEST_ON = new AxisAlignedBB(0.9375D, 0.375D, 0.3125D, 1.0D, 0.625D, 0.6875D);
      AABB_EAST_ON = new AxisAlignedBB(0.0D, 0.375D, 0.3125D, 0.0625D, 0.625D, 0.6875D);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if ((Boolean)var3.getValue(POWERED)) {
         return (boolean)" ".length();
      } else {
         var1.setBlockState(var2, var3.withProperty(POWERED, Boolean.valueOf((boolean)" ".length())), "   ".length());
         I[124 ^ 122].length();
         I[40 ^ 47].length();
         I[171 ^ 163].length();
         var1.markBlockRangeForRenderUpdate(var2, var2);
         this.playClickSound(var4, var1, var2);
         this.notifyNeighbors(var1, var2, (EnumFacing)var3.getValue(FACING));
         var1.scheduleUpdate(var2, this, this.tickRate(var1));
         return (boolean)" ".length();
      }
   }

   private static void I() {
      I = new String[155 ^ 183];
      I["".length()] = I("泉柩嵖", "Vfrup");
      I[" ".length()] = I("庋棻", "XAfIk");
      I["  ".length()] = I("囓幖杙嘧", "JDfrB");
      I["   ".length()] = I("仴濅廢帰泷", "SFYfH");
      I[99 ^ 103] = I("惬侂洋", "bLVYl");
      I[36 ^ 33] = I("擻杅", "cIOnS");
      I[158 ^ 152] = I("佨佐", "zUdSt");
      I[174 ^ 169] = I("劃焴名懥椁", "ftHUH");
      I[38 ^ 46] = I("櫢", "AWddc");
      I[29 ^ 20] = I("尡侧", "uheNa");
      I[109 ^ 103] = I("偾峁叕", "vMmDs");
      I[42 ^ 33] = I("樜奚", "JvpUU");
      I[100 ^ 104] = I("孜婺", "iXsBf");
      I[204 ^ 193] = I("暔斲", "HnlQg");
      I[64 ^ 78] = I("棗淎", "bXGud");
      I[95 ^ 80] = I("忧唉", "lWdJu");
      I[7 ^ 23] = I("喡洫廷", "UuVaH");
      I[67 ^ 82] = I("嗗", "DvoCO");
      I[121 ^ 107] = I("愱寵昜", "GEjUS");
      I[175 ^ 188] = I("兞傃", "lJcpa");
      I[169 ^ 189] = I("檍唹变", "EwYNi");
      I[79 ^ 90] = I("斐漍基", "NJegu");
      I[56 ^ 46] = I("戁侒椋杠", "HGnGU");
      I[79 ^ 88] = I("坯漥", "gKbjD");
      I[128 ^ 152] = I("媍殞", "xvCaw");
      I[117 ^ 108] = I("嘚剋", "SGWSP");
      I[20 ^ 14] = I("焩揻", "iOLsr");
      I[164 ^ 191] = I("彑屩", "PJmLa");
      I[150 ^ 138] = I("潓冨", "gChyO");
      I[116 ^ 105] = I("櫄嬱", "poaau");
      I[125 ^ 99] = I("埳怵", "eAIZe");
      I[13 ^ 18] = I("墆民", "pfRTJ");
      I[228 ^ 196] = I("桒庍", "nUgYW");
      I[180 ^ 149] = I("冄橦", "TQryB");
      I[178 ^ 144] = I("孎掶", "RxMVi");
      I[122 ^ 89] = I("樢櫽夔叨摃", "KUgvt");
      I[171 ^ 143] = I("劚手摊", "thqRQ");
      I[174 ^ 139] = I("毚渀佶嶖廫", "XYKFl");
      I[33 ^ 7] = I("噺", "xXWdc");
      I[97 ^ 70] = I("涎橝", "dtcff");
      I[63 ^ 23] = I("患岀拢助", "VvwoZ");
      I[110 ^ 71] = I("悼", "qKFxV");
      I[98 ^ 72] = I("俣帒修", "LgeMy");
      I[182 ^ 157] = I("%\u000454?0\u000f", "UkBQM");
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      if ((Boolean)var3.getValue(POWERED)) {
         this.notifyNeighbors(var1, var2, (EnumFacing)var3.getValue(FACING));
      }

      super.breakBlock(var1, var2, var3);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState getStateFromMeta(int var1) {
      EnumFacing var2;
      switch(var1 & (181 ^ 178)) {
      case 0:
         var2 = EnumFacing.DOWN;
         "".length();
         if (4 <= 3) {
            throw null;
         }
         break;
      case 1:
         var2 = EnumFacing.EAST;
         "".length();
         if (2 != 2) {
            throw null;
         }
         break;
      case 2:
         var2 = EnumFacing.WEST;
         "".length();
         if (1 == -1) {
            throw null;
         }
         break;
      case 3:
         var2 = EnumFacing.SOUTH;
         "".length();
         if (2 == 1) {
            throw null;
         }
         break;
      case 4:
         var2 = EnumFacing.NORTH;
         "".length();
         if (4 <= 0) {
            throw null;
         }
         break;
      case 5:
      default:
         var2 = EnumFacing.UP;
      }

      IBlockState var10000 = this.getDefaultState().withProperty(FACING, var2);
      PropertyBool var10001 = POWERED;
      int var10002;
      if ((var1 & (124 ^ 116)) > 0) {
         var10002 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public int getMetaFromState(IBlockState var1) {
      int var2;
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
         var2 = " ".length();
         "".length();
         if (2 <= -1) {
            throw null;
         }
         break;
      case 2:
         var2 = "  ".length();
         "".length();
         if (2 <= 0) {
            throw null;
         }
         break;
      case 3:
         var2 = "   ".length();
         "".length();
         if (3 <= 2) {
            throw null;
         }
         break;
      case 4:
         var2 = 119 ^ 115;
         "".length();
         if (4 <= -1) {
            throw null;
         }
         break;
      case 5:
      default:
         var2 = 126 ^ 123;
         "".length();
         if (-1 != -1) {
            throw null;
         }
         break;
      case 6:
         var2 = "".length();
      }

      if ((Boolean)var1.getValue(POWERED)) {
         var2 |= 36 ^ 44;
      }

      return var2;
   }

   protected abstract void playClickSound(EntityPlayer var1, World var2, BlockPos var3);

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      EnumFacing[] var3 = EnumFacing.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return (boolean)"".length();
         }

         EnumFacing var6 = var3[var5];
         if (canPlaceBlock(var1, var2, var6)) {
            return (boolean)" ".length();
         }

         ++var5;
         "".length();
      } while(-1 != 1);

      throw null;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   private boolean checkForDrop(World var1, BlockPos var2, IBlockState var3) {
      if (this.canPlaceBlockAt(var1, var2)) {
         return (boolean)" ".length();
      } else {
         this.dropBlockAsItem(var1, var2, var3, "".length());
         var1.setBlockToAir(var2);
         I["   ".length()].length();
         I[161 ^ 165].length();
         I[36 ^ 33].length();
         return (boolean)"".length();
      }
   }

   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (!(Boolean)var1.getValue(POWERED)) {
         return "".length();
      } else {
         int var10000;
         if (var1.getValue(FACING) == var4) {
            var10000 = 173 ^ 162;
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return var10000;
      }
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote && (Boolean)var3.getValue(POWERED)) {
         if (this.wooden) {
            this.checkPressed(var3, var1, var2);
            "".length();
            if (1 >= 2) {
               throw null;
            }
         } else {
            var1.setBlockState(var2, var3.withProperty(POWERED, Boolean.valueOf((boolean)"".length())));
            I[200 ^ 193].length();
            I[153 ^ 147].length();
            this.notifyNeighbors(var1, var2, (EnumFacing)var3.getValue(FACING));
            this.playReleaseSound(var1, var2);
            var1.markBlockRangeForRenderUpdate(var2, var2);
         }
      }

   }
}

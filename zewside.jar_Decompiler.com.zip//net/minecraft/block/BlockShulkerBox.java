package net.minecraft.block;

import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.NonNullList;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockShulkerBox extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<EnumFacing> field_190957_a;
   // $FF: synthetic field
   private final EnumDyeColor field_190958_b;

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[179 ^ 180];
      String var10001 = I[68 ^ 76];
      String var10002 = I[161 ^ 168];
      var10001 = I[187 ^ 177];
      var10000 = I[78 ^ 69];
      var10001 = I[121 ^ 117];
      var10002 = I[136 ^ 133];
      var10001 = I[17 ^ 31];
      I[126 ^ 113].length();
      I[160 ^ 176].length();
      I[175 ^ 190].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[139 ^ 153].length();
      I[112 ^ 99].length();
      I[52 ^ 32].length();
      var10003["".length()] = field_190957_a;
      return new BlockStateContainer(this, var10003);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 3);

      throw null;
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public void onBlockHarvested(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      if (var1.getTileEntity(var2) instanceof TileEntityShulkerBox) {
         TileEntityShulkerBox var5 = (TileEntityShulkerBox)var1.getTileEntity(var2);
         var5.func_190579_a(var4.capabilities.isCreativeMode);
         var5.fillWithLoot(var4);
      }

   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      TileEntity var4 = var2.getTileEntity(var3);
      AxisAlignedBB var10000;
      if (var4 instanceof TileEntityShulkerBox) {
         var10000 = ((TileEntityShulkerBox)var4).func_190584_a(var1);
         "".length();
         if (1 == 2) {
            throw null;
         }
      } else {
         var10000 = FULL_BLOCK_AABB;
      }

      return var10000;
   }

   public void func_190948_a(ItemStack var1, @Nullable World var2, List<String> var3, ITooltipFlag var4) {
      String var10000 = I[135 ^ 170];
      String var10001 = I[8 ^ 38];
      String var10002 = I[138 ^ 165];
      var10001 = I[31 ^ 47];
      var10000 = I[169 ^ 152];
      var10001 = I[43 ^ 25];
      var10002 = I[100 ^ 87];
      var10001 = I[175 ^ 155];
      var10000 = I[168 ^ 157];
      var10001 = I[159 ^ 169];
      var10002 = I[186 ^ 141];
      var10001 = I[140 ^ 180];
      var10000 = I[19 ^ 42];
      var10001 = I[176 ^ 138];
      var10002 = I[147 ^ 168];
      var10001 = I[177 ^ 141];
      super.func_190948_a(var1, var2, var3, var4);
      NBTTagCompound var5 = var1.getTagCompound();
      if (var5 != null && var5.hasKey(I[91 ^ 102], 164 ^ 174)) {
         NBTTagCompound var6 = var5.getCompoundTag(I[34 ^ 28]);
         if (var6.hasKey(I[3 ^ 60], 159 ^ 151)) {
            var3.add(I[62 ^ 126]);
            I[97 ^ 32].length();
            I[200 ^ 138].length();
         }

         if (var6.hasKey(I[116 ^ 55], 28 ^ 21)) {
            NonNullList var7 = NonNullList.func_191197_a(102 ^ 125, ItemStack.field_190927_a);
            ItemStackHelper.func_191283_b(var6, var7);
            int var8 = "".length();
            int var9 = "".length();
            Iterator var10 = var7.iterator();

            Object[] var12;
            while(var10.hasNext()) {
               ItemStack var11 = (ItemStack)var10.next();
               if (!var11.isEmpty()) {
                  ++var9;
                  if (var8 <= (162 ^ 166)) {
                     ++var8;
                     var10001 = I[205 ^ 137];
                     var12 = new Object["  ".length()];
                     I[117 ^ 48].length();
                     I[255 ^ 185].length();
                     var12["".length()] = var11.getDisplayName();
                     I[22 ^ 81].length();
                     I[198 ^ 142].length();
                     I[51 ^ 122].length();
                     var12[" ".length()] = var11.func_190916_E();
                     var3.add(String.format(var10001, var12));
                     I[116 ^ 62].length();
                     I[47 ^ 100].length();
                     I[141 ^ 193].length();
                  }
               }

               "".length();
               if (0 >= 3) {
                  throw null;
               }
            }

            I[209 ^ 156].length();
            I[221 ^ 147].length();
            I[194 ^ 141].length();
            if (var9 - var8 > 0) {
               I[43 ^ 123].length();
               I[211 ^ 130].length();
               var10001 = TextFormatting.ITALIC + I18n.translateToLocal(I[229 ^ 183]);
               var12 = new Object[" ".length()];
               I[90 ^ 9].length();
               I[39 ^ 115].length();
               I[53 ^ 96].length();
               int var10004 = "".length();
               I[227 ^ 181].length();
               I[36 ^ 115].length();
               var12[var10004] = var9 - var8;
               var3.add(String.format(var10001, var12));
               I[206 ^ 150].length();
            }
         }
      }

   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else if (var4.isSpectator()) {
         return (boolean)" ".length();
      } else {
         TileEntity var10 = var1.getTileEntity(var2);
         if (var10 instanceof TileEntityShulkerBox) {
            EnumFacing var11 = (EnumFacing)var3.getValue(field_190957_a);
            int var12;
            if (((TileEntityShulkerBox)var10).func_190591_p() == TileEntityShulkerBox.AnimationStatus.CLOSED) {
               AxisAlignedBB var13 = FULL_BLOCK_AABB.addCoord((double)(0.5F * (float)var11.getFrontOffsetX()), (double)(0.5F * (float)var11.getFrontOffsetY()), (double)(0.5F * (float)var11.getFrontOffsetZ())).func_191195_a((double)var11.getFrontOffsetX(), (double)var11.getFrontOffsetY(), (double)var11.getFrontOffsetZ());
               int var10000;
               if (!var1.collidesWithAnyBlock(var13.offset(var2.offset(var11)))) {
                  var10000 = " ".length();
                  "".length();
                  if (false) {
                     throw null;
                  }
               } else {
                  var10000 = "".length();
               }

               var12 = var10000;
               "".length();
               if (false) {
                  throw null;
               }
            } else {
               var12 = " ".length();
            }

            if (var12 != 0) {
               var4.addStat(StatList.field_191272_ae);
               var4.displayGUIChest((IInventory)var10);
            }

            return (boolean)" ".length();
         } else {
            return (boolean)"".length();
         }
      }
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public static EnumDyeColor func_190955_b(Item var0) {
      return func_190954_c(Block.getBlockFromItem(var0));
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(field_190957_a)));
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(field_190957_a, var2.rotate((EnumFacing)var1.getValue(field_190957_a)));
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      var2 = this.getActualState(var2, var1, var3);
      EnumFacing var5 = (EnumFacing)var2.getValue(field_190957_a);
      TileEntityShulkerBox.AnimationStatus var6 = ((TileEntityShulkerBox)var1.getTileEntity(var3)).func_190591_p();
      BlockFaceShape var10000;
      if (var6 != TileEntityShulkerBox.AnimationStatus.CLOSED && (var6 != TileEntityShulkerBox.AnimationStatus.OPENED || var5 != var4.getOpposite() && var5 != var4)) {
         var10000 = BlockFaceShape.UNDEFINED;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.SOLID;
      }

      return var10000;
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[79 ^ 75].length();
      I[12 ^ 9].length();
      I[15 ^ 9].length();
      return new TileEntityShulkerBox(this.field_190958_b);
   }

   static {
      I();
      field_190957_a = PropertyDirection.create(I[10 ^ 108]);
   }

   public BlockShulkerBox(EnumDyeColor var1) {
      super(Material.ROCK, MapColor.AIR);
      this.field_190958_b = var1;
      this.setCreativeTab(CreativeTabs.DECORATIONS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(field_190957_a, EnumFacing.UP));
   }

   public static Block func_190952_a(EnumDyeColor var0) {
      switch(null.$SwitchMap$net$minecraft$item$EnumDyeColor[var0.ordinal()]) {
      case 1:
         return Blocks.WHITE_SHULKER_BOX;
      case 2:
         return Blocks.ORANGE_SHULKER_BOX;
      case 3:
         return Blocks.MAGENTA_SHULKER_BOX;
      case 4:
         return Blocks.LIGHT_BLUE_SHULKER_BOX;
      case 5:
         return Blocks.YELLOW_SHULKER_BOX;
      case 6:
         return Blocks.LIME_SHULKER_BOX;
      case 7:
         return Blocks.PINK_SHULKER_BOX;
      case 8:
         return Blocks.GRAY_SHULKER_BOX;
      case 9:
         return Blocks.SILVER_SHULKER_BOX;
      case 10:
         return Blocks.CYAN_SHULKER_BOX;
      case 11:
      default:
         return Blocks.PURPLE_SHULKER_BOX;
      case 12:
         return Blocks.BLUE_SHULKER_BOX;
      case 13:
         return Blocks.BROWN_SHULKER_BOX;
      case 14:
         return Blocks.GREEN_SHULKER_BOX;
      case 15:
         return Blocks.RED_SHULKER_BOX;
      case 16:
         return Blocks.BLACK_SHULKER_BOX;
      }
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[209 ^ 196];
      String var10001 = I[97 ^ 119];
      String var10002 = I[80 ^ 71];
      var10001 = I[55 ^ 47];
      var10000 = I[189 ^ 164];
      var10001 = I[173 ^ 183];
      var10002 = I[154 ^ 129];
      var10001 = I[164 ^ 184];
      var10000 = I[133 ^ 152];
      var10001 = I[103 ^ 121];
      var10002 = I[127 ^ 96];
      var10001 = I[87 ^ 119];
      TileEntity var4 = var1.getTileEntity(var2);
      if (var4 instanceof TileEntityShulkerBox) {
         TileEntityShulkerBox var5 = (TileEntityShulkerBox)var4;
         if (!var5.func_190590_r() && var5.func_190582_F()) {
            I[168 ^ 137].length();
            I[55 ^ 21].length();
            I[108 ^ 79].length();
            ItemStack var6 = new ItemStack(Item.getItemFromBlock(this));
            I[48 ^ 20].length();
            NBTTagCompound var7 = new NBTTagCompound();
            I[47 ^ 10].length();
            I[67 ^ 101].length();
            I[95 ^ 120].length();
            I[102 ^ 78].length();
            NBTTagCompound var8 = new NBTTagCompound();
            var7.setTag(I[101 ^ 76], ((TileEntityShulkerBox)var4).func_190580_f(var8));
            var6.setTagCompound(var7);
            if (var5.hasCustomName()) {
               var6.setStackDisplayName(var5.getName());
               I[6 ^ 44].length();
               I[22 ^ 61].length();
               var5.func_190575_a(I[176 ^ 156]);
            }

            spawnAsEntity(var1, var2, var6);
         }

         var1.updateComparatorOutputLevel(var2, var3.getBlock());
      }

      super.breakBlock(var1, var2, var3);
   }

   public EnumPushReaction getMobilityFlag(IBlockState var1) {
      return EnumPushReaction.DESTROY;
   }

   private static void I() {
      I = new String[78 ^ 41];
      I["".length()] = I("嚀欭", "MPqBg");
      I[" ".length()] = I("梌唲", "qsTcx");
      I["  ".length()] = I("嶸歏", "OhgRI");
      I["   ".length()] = I("沗嗜", "RSaxP");
      I[195 ^ 199] = I("囼庩炲枭橰", "OxBMW");
      I[20 ^ 17] = I("汏凲泡湲", "IufNL");
      I[84 ^ 82] = I("咂拸淽烖樜", "EPvKM");
      I[155 ^ 156] = I("棌徲", "EQCrW");
      I[148 ^ 156] = I("廻帊", "KOodL");
      I[31 ^ 22] = I("叠僔", "YTHQA");
      I[22 ^ 28] = I("浌忚", "jNfhr");
      I[56 ^ 51] = I("凩敟", "pbyZk");
      I[85 ^ 89] = I("俪媑", "txHFt");
      I[120 ^ 117] = I("喟旈", "geyow");
      I[33 ^ 47] = I("扣愗", "dnATY");
      I[125 ^ 114] = I("哬", "BypYA");
      I[20 ^ 4] = I("廌丗敘搒", "zguZm");
      I[15 ^ 30] = I("憔抷弡", "hbXbX");
      I[73 ^ 91] = I("嗒", "issHK");
      I[213 ^ 198] = I("朦揻櫎", "dhpsU");
      I[120 ^ 108] = I("愸瀟忊姩沃", "aHZiq");
      I[25 ^ 12] = I("噈援", "dUBJB");
      I[167 ^ 177] = I("伵夹", "Kbiwj");
      I[161 ^ 182] = I("拙崕", "mJJmc");
      I[106 ^ 114] = I("棅桘", "kinnR");
      I[99 ^ 122] = I("亡廂", "KAZNO");
      I[154 ^ 128] = I("媥烬", "GpIMN");
      I[60 ^ 39] = I("巿慽", "rYWmm");
      I[125 ^ 97] = I("毽檟", "gAqqS");
      I[40 ^ 53] = I("嘤啱", "iTsOo");
      I[189 ^ 163] = I("劃唐", "YunPG");
      I[94 ^ 65] = I("忐嗩", "bXVyL");
      I[191 ^ 159] = I("擘婁", "TWLNd");
      I[100 ^ 69] = I("惍", "jRuRs");
      I[0 ^ 34] = I("呏榢杏烫栝", "QUsJH");
      I[172 ^ 143] = I("拨", "vTgYT");
      I[115 ^ 87] = I("瀌厓", "VbYbn");
      I[224 ^ 197] = I("庝忎妧瀌慠", "WpiRR");
      I[18 ^ 52] = I("剉橐愍旦卪", "MlPZR");
      I[155 ^ 188] = I("汁", "tqISn");
      I[141 ^ 165] = I("潡嫠噇浮杝", "iVIij");
      I[128 ^ 169] = I("6\b\u0019)\f1\n\u0002#\u0013\r0\u0017-", "tdvJg");
      I[164 ^ 142] = I("憗", "QEgWz");
      I[146 ^ 185] = I("寙", "sSbyQ");
      I[57 ^ 21] = I("", "sOVUL");
      I[58 ^ 23] = I("嫚枇", "mvIle");
      I[181 ^ 155] = I("僑尳", "DdDXs");
      I[148 ^ 187] = I("嫻淙", "UAzCe");
      I[64 ^ 112] = I("捡滩", "nZxLd");
      I[102 ^ 87] = I("擨仢", "BoVWb");
      I[173 ^ 159] = I("洤炽", "PMKsJ");
      I[242 ^ 193] = I("朓檏", "MlExT");
      I[64 ^ 116] = I("唅彅", "ERhaM");
      I[145 ^ 164] = I("欬慎", "Bqesx");
      I[87 ^ 97] = I("文亩", "nMqId");
      I[52 ^ 3] = I("噫彈", "zrbYm");
      I[6 ^ 62] = I("寈嫱", "UlSae");
      I[37 ^ 28] = I("困枠", "eZVWU");
      I[103 ^ 93] = I("瀆瀢", "vhfrM");
      I[54 ^ 13] = I("愁旪", "YYLlR");
      I[187 ^ 135] = I("剞俗", "lNrVu");
      I[105 ^ 84] = I("0\t>7\b7\u000b%=\u0017\u000b103", "reQTc");
      I[146 ^ 172] = I("\u0015<\u0000\"1\u0012>\u001b(..\u0004\u000e&", "WPoAZ");
      I[44 ^ 19] = I("\b\u0018&\u0018\u0018%\u0015%\t", "DwIlL");
      I[216 ^ 152] = I("tsuFjts", "KLJyU");
      I[20 ^ 85] = I("宲妼", "iDggS");
      I[91 ^ 25] = I("垽抈", "shSrQ");
      I[84 ^ 23] = I("\u000f\u001a\u0012>+", "FnwSX");
      I[47 ^ 107] = I("m\u001at\u001aL,", "HiTbi");
      I[222 ^ 155] = I("懫搰归浙滅", "mfmhc");
      I[110 ^ 40] = I("傲汬冫嘞涑", "QCNKT");
      I[1 ^ 70] = I("墯帒嵁", "rVizW");
      I[120 ^ 48] = I("浢", "ooptj");
      I[18 ^ 91] = I("们剗剒嵯中", "IKwtN");
      I[198 ^ 140] = I("岲儐潬性崘", "XXpnG");
      I[2 ^ 73] = I("儜氵樻案庅", "kBqrn");
      I[13 ^ 65] = I("挫", "MwSOX");
      I[41 ^ 100] = I("拥", "kFHhJ");
      I[203 ^ 133] = I("惐", "DjkLD");
      I[143 ^ 192] = I("塪墶囅刔", "RNAWq");
      I[211 ^ 131] = I("澊橦", "fgzAV");
      I[14 ^ 95] = I("扅满刃", "nMhSd");
      I[255 ^ 173] = I("3\u0015\u0002\u0003#9\u0014\t\u0005l#\u0012\u0019\u001b)5\b.\u0018:~\u0017\u0003\u0005'", "PzlwB");
      I[107 ^ 56] = I("唱杨欈", "WnFYj");
      I[221 ^ 137] = I("埝巣婰媀", "UdDZs");
      I[52 ^ 97] = I("潾仍壆", "aKOmX");
      I[16 ^ 70] = I("有冗吨卾揨", "XCSsY");
      I[219 ^ 140] = I("娑戦啫", "bdABt");
      I[54 ^ 110] = I("旄弃戇", "NlWyZ");
      I[214 ^ 143] = I("斥弅", "KSgOx");
      I[248 ^ 162] = I("昼惫", "OavOd");
      I[250 ^ 161] = I("塄廎", "wblRj");
      I[195 ^ 159] = I("匞濒", "kISyO");
      I[109 ^ 48] = I("槫惸瀘淿", "xcjvX");
      I[35 ^ 125] = I("捓", "ARaAM");
      I[59 ^ 100] = I("0\u0019\f*(7\u001b\u0017 7\u000b!\u0002.", "rucIC");
      I[219 ^ 187] = I("煕垤", "kEUxx");
      I[255 ^ 158] = I("浣垬", "GKWOI");
      I[97 ^ 3] = I("揸夈", "CEXsT");
      I[84 ^ 55] = I("喫愩", "sTUyF");
      I[236 ^ 136] = I("忕棈撆恴嚠", "OrxWF");
      I[59 ^ 94] = I("斊坽湝浍擃", "wVGSC");
      I[116 ^ 18] = I("\u0001\u0000*\u0018)\u0000", "gaIqG");
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      return Container.calcRedstoneFromInventory((IInventory)var2.getTileEntity(var3));
   }

   public IBlockState getStateFromMeta(int var1) {
      EnumFacing var2 = EnumFacing.getFront(var1);
      return this.getDefaultState().withProperty(field_190957_a, var2);
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(field_190957_a, var3);
   }

   public static ItemStack func_190953_b(EnumDyeColor var0) {
      String var10000 = I[11 ^ 107];
      String var10001 = I[206 ^ 175];
      String var10002 = I[250 ^ 152];
      var10001 = I[42 ^ 73];
      I[103 ^ 3].length();
      I[79 ^ 42].length();
      return new ItemStack(func_190952_a(var0));
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumFacing)var1.getValue(field_190957_a)).getIndex();
   }

   public static EnumDyeColor func_190954_c(Block var0) {
      EnumDyeColor var10000;
      if (var0 instanceof BlockShulkerBox) {
         var10000 = ((BlockShulkerBox)var0).func_190956_e();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      } else {
         var10000 = EnumDyeColor.PURPLE;
      }

      return var10000;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[234 ^ 179];
      String var10001 = I[67 ^ 25];
      String var10002 = I[208 ^ 139];
      var10001 = I[115 ^ 47];
      ItemStack var4 = super.getItem(var1, var2, var3);
      TileEntityShulkerBox var5 = (TileEntityShulkerBox)var1.getTileEntity(var2);
      I[73 ^ 20].length();
      I[219 ^ 133].length();
      NBTTagCompound var6 = var5.func_190580_f(new NBTTagCompound());
      if (!var6.hasNoTags()) {
         var4.setTagInfo(I[197 ^ 154], var6);
      }

      return var4;
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      if (var5.hasDisplayName()) {
         TileEntity var6 = var1.getTileEntity(var2);
         if (var6 instanceof TileEntityShulkerBox) {
            ((TileEntityShulkerBox)var6).func_190575_a(var5.getDisplayName());
         }
      }

   }

   public boolean func_190946_v(IBlockState var1) {
      return (boolean)" ".length();
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.ENTITYBLOCK_ANIMATED;
   }

   public boolean causesSuffocation(IBlockState var1) {
      return (boolean)" ".length();
   }

   public EnumDyeColor func_190956_e() {
      return this.field_190958_b;
   }
}

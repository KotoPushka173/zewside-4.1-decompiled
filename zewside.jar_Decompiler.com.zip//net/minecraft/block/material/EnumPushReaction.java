package net.minecraft.block.material;

public enum EnumPushReaction {
   // $FF: synthetic field
   IGNORE,
   // $FF: synthetic field
   PUSH_ONLY;

   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   NORMAL,
   // $FF: synthetic field
   DESTROY,
   // $FF: synthetic field
   BLOCK;

   private static void I() {
      I = new String[72 ^ 77];
      I["".length()] = I("=\u001f\u001a\u0014\u0010?", "sPHYQ");
      I[" ".length()] = I("\u000b\b43\u001f\u0000\u0014", "OMggM");
      I["  ".length()] = I("6 \f1\u001d", "tlCrV");
      I["   ".length()] = I("(!4->$", "afzbl");
      I[13 ^ 9] = I("\u001b\u000f\u001a#\f\u0004\u0014\u00052", "KZIkS");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   static {
      I();
      NORMAL = new EnumPushReaction(I["".length()], "".length());
      DESTROY = new EnumPushReaction(I[" ".length()], " ".length());
      BLOCK = new EnumPushReaction(I["  ".length()], "  ".length());
      IGNORE = new EnumPushReaction(I["   ".length()], "   ".length());
      PUSH_ONLY = new EnumPushReaction(I[158 ^ 154], 83 ^ 87);
      EnumPushReaction[] var10000 = new EnumPushReaction[14 ^ 11];
      var10000["".length()] = NORMAL;
      var10000[" ".length()] = DESTROY;
      var10000["  ".length()] = BLOCK;
      var10000["   ".length()] = IGNORE;
      var10000[161 ^ 165] = PUSH_ONLY;
   }
}

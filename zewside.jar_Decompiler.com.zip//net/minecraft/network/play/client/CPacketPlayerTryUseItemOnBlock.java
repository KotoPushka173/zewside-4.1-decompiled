package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class CPacketPlayerTryUseItemOnBlock implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private float facingZ;
   // $FF: synthetic field
   private EnumFacing placedBlockDirection;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private float facingX;
   // $FF: synthetic field
   private BlockPos position;
   // $FF: synthetic field
   private EnumHand hand;
   // $FF: synthetic field
   private float facingY;

   static {
      I();
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processRightClickBlock(this);
   }

   public EnumHand getHand() {
      return this.hand;
   }

   public CPacketPlayerTryUseItemOnBlock(BlockPos var1, EnumFacing var2, EnumHand var3, float var4, float var5, float var6) {
      this.position = var1;
      this.placedBlockDirection = var2;
      this.hand = var3;
      this.facingX = var4;
      this.facingY = var5;
      this.facingZ = var6;
   }

   public CPacketPlayerTryUseItemOnBlock() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeBlockPos(this.position);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeEnumValue(this.placedBlockDirection);
      I["   ".length()].length();
      I[53 ^ 49].length();
      I[13 ^ 8].length();
      I[145 ^ 151].length();
      var1.writeEnumValue(this.hand);
      I[185 ^ 190].length();
      I[203 ^ 195].length();
      I[123 ^ 114].length();
      I[130 ^ 136].length();
      var1.writeFloat(this.facingX);
      I[0 ^ 11].length();
      I[175 ^ 163].length();
      I[100 ^ 105].length();
      var1.writeFloat(this.facingY);
      I[39 ^ 41].length();
      I[83 ^ 92].length();
      var1.writeFloat(this.facingZ);
      I[58 ^ 42].length();
      I[102 ^ 119].length();
   }

   private static void I() {
      I = new String[23 ^ 5];
      I["".length()] = I("侎嫸嫑凣", "qqjLb");
      I[" ".length()] = I("抄櫁撐", "kkOHA");
      I["  ".length()] = I("塎条", "qpOxq");
      I["   ".length()] = I("崡怟烫灟", "wdmgv");
      I[50 ^ 54] = I("壦劺亞報滌", "LQfbv");
      I[49 ^ 52] = I("咖儐涵楒", "dlmJm");
      I[136 ^ 142] = I("淫扽凢", "DGVRa");
      I[199 ^ 192] = I("橓元擽岛", "UvrBX");
      I[79 ^ 71] = I("棶", "mNDAE");
      I[15 ^ 6] = I("劫枖匳旂", "TcSQe");
      I[50 ^ 56] = I("挘商俀淜弊", "gfTQU");
      I[28 ^ 23] = I("撖浟媛测剋", "SXayx");
      I[56 ^ 52] = I("煮咺局炶", "OFHPH");
      I[125 ^ 112] = I("岷奖塣敍", "eoxUw");
      I[84 ^ 90] = I("徤", "aGRoU");
      I[137 ^ 134] = I("坨噛", "MEYQn");
      I[33 ^ 49] = I("呖池", "HmxHu");
      I[128 ^ 145] = I("澱仺杇搘僑", "zUlRQ");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 0);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.position = var1.readBlockPos();
      this.placedBlockDirection = (EnumFacing)var1.readEnumValue(EnumFacing.class);
      this.hand = (EnumHand)var1.readEnumValue(EnumHand.class);
      this.facingX = var1.readFloat();
      this.facingY = var1.readFloat();
      this.facingZ = var1.readFloat();
   }

   public float getFacingY() {
      return this.facingY;
   }

   public float getFacingZ() {
      return this.facingZ;
   }

   public BlockPos getPos() {
      return this.position;
   }

   public EnumFacing getDirection() {
      return this.placedBlockDirection;
   }

   public float getFacingX() {
      return this.facingX;
   }
}

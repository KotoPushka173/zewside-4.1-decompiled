package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockSand extends BlockFalling {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockSand.EnumType> VARIANT;

   public int getDustColor(IBlockState var1) {
      BlockSand.EnumType var2 = (BlockSand.EnumType)var1.getValue(VARIANT);
      return var2.getDustColor();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[100 ^ 109];
      String var10001 = I[116 ^ 126];
      String var10002 = I[142 ^ 133];
      var10001 = I[176 ^ 188];
      var10000 = I[132 ^ 137];
      var10001 = I[31 ^ 17];
      var10002 = I[117 ^ 122];
      var10001 = I[7 ^ 23];
      I[124 ^ 109].length();
      I[68 ^ 86].length();
      I[103 ^ 116].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[156 ^ 136].length();
      var10003["".length()] = VARIANT;
      return new BlockStateContainer(this, var10003);
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockSand.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockSand.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return ((BlockSand.EnumType)var1.getValue(VARIANT)).getMapColor();
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      BlockSand.EnumType[] var3 = BlockSand.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockSand.EnumType var6 = var3[var5];
         I[163 ^ 167].length();
         I[77 ^ 72].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[197 ^ 195].length();
         I[81 ^ 86].length();
         I[95 ^ 87].length();
         ++var5;
         "".length();
      } while(1 > 0);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   private static void I() {
      I = new String[13 ^ 27];
      I["".length()] = I("棪慳", "hjeHL");
      I[" ".length()] = I("掼栰", "udIjL");
      I["  ".length()] = I("妌峙", "DVBBP");
      I["   ".length()] = I("氍梹", "kHFOY");
      I[151 ^ 147] = I("氩囨尷念", "sSnOT");
      I[10 ^ 15] = I("弌", "kvijs");
      I[79 ^ 73] = I("仓垻掷泊", "nAJdm");
      I[93 ^ 90] = I("汧將", "yKxnA");
      I[177 ^ 185] = I("庾堇壬勺", "gDjEA");
      I[127 ^ 118] = I("庪梯", "ZDzVw");
      I[110 ^ 100] = I("濱宔", "rsknP");
      I[38 ^ 45] = I("捸掩", "TIdXP");
      I[177 ^ 189] = I("妓婻", "NbfBK");
      I[110 ^ 99] = I("唘呓", "VQWge");
      I[46 ^ 32] = I("漏务", "CrqHP");
      I[168 ^ 167] = I("怏浑", "HzJBj");
      I[52 ^ 36] = I("咃將", "jDkLO");
      I[115 ^ 98] = I("巺", "WfOZA");
      I[142 ^ 156] = I("滇妷嘎", "BKOQs");
      I[166 ^ 181] = I("劊娺幪掄", "qtBad");
      I[208 ^ 196] = I("匜幕匄", "WLgEP");
      I[147 ^ 134] = I("\u0007(7%\r\u001f=", "qIELl");
   }

   public BlockSand() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockSand.EnumType.SAND));
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockSand.EnumType.byMetadata(var1));
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[161 ^ 180], BlockSand.EnumType.class);
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private final int dustColor;
      // $FF: synthetic field
      SAND,
      // $FF: synthetic field
      RED_SAND;

      // $FF: synthetic field
      private final MapColor mapColor;
      // $FF: synthetic field
      private final String unlocalizedName;

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      public static BlockSand.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      public int getDustColor() {
         return this.dustColor;
      }

      public MapColor getMapColor() {
         return this.mapColor;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 > 0);

         throw null;
      }

      public String toString() {
         return this.name;
      }

      public String getName() {
         return this.name;
      }

      public int getMetadata() {
         return this.meta;
      }

      private EnumType(int var3, String var4, String var5, MapColor var6, int var7) {
         this.meta = var3;
         this.name = var4;
         this.mapColor = var6;
         this.unlocalizedName = var5;
         this.dustColor = var7;
      }

      private static void I() {
         I = new String[128 ^ 134];
         I["".length()] = I("\u0018\u0017*(", "KVdlp");
         I[" ".length()] = I("\u000b%/'", "xDACf");
         I["  ".length()] = I("\u0003?\u0011.\u0005\u000b.", "gZwOp");
         I["   ".length()] = I("\u000443\u000e)\u0017?3", "VqwQz");
         I[179 ^ 183] = I("$\u001d1'97\u00161", "VxUxJ");
         I[148 ^ 145] = I("*\t<", "XlXUB");
      }

      static {
         I();
         SAND = new BlockSand.EnumType(I["".length()], "".length(), "".length(), I[" ".length()], I["  ".length()], MapColor.SAND, -(120898 + 2243551 - 1518753 + 1524960));
         RED_SAND = new BlockSand.EnumType(I["   ".length()], " ".length(), " ".length(), I[156 ^ 152], I[3 ^ 6], MapColor.ADOBE, -(1310728 + 2953548 - 921431 + 2336226));
         BlockSand.EnumType[] var10000 = new BlockSand.EnumType["  ".length()];
         var10000["".length()] = SAND;
         var10000[" ".length()] = RED_SAND;
         BlockSand.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockSand.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(-1 >= -1);

         throw null;
      }
   }
}

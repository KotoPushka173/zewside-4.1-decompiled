package net.minecraft.block;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockNewLog extends BlockLog {
   // $FF: synthetic field
   public static final PropertyEnum<BlockPlanks.EnumType> VARIANT;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 1);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      int var10001 = ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
      int var10002 = 79 ^ 75;
      I[81 ^ 69].length();
      I[89 ^ 76].length();
      var2 |= var10001 - var10002;
      switch(null.$SwitchMap$net$minecraft$block$BlockLog$EnumAxis[((BlockLog.EnumAxis)var1.getValue(LOG_AXIS)).ordinal()]) {
      case 1:
         var2 |= 101 ^ 97;
         "".length();
         if (false) {
            throw null;
         }
         break;
      case 2:
         var2 |= 167 ^ 175;
         "".length();
         if (2 >= 4) {
            throw null;
         }
         break;
      case 3:
         var2 |= 131 ^ 143;
      }

      return var2;
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      BlockPlanks.EnumType var4 = (BlockPlanks.EnumType)var1.getValue(VARIANT);
      switch(null.$SwitchMap$net$minecraft$block$BlockLog$EnumAxis[((BlockLog.EnumAxis)var1.getValue(LOG_AXIS)).ordinal()]) {
      case 1:
      case 2:
      case 3:
      default:
         switch(null.$SwitchMap$net$minecraft$block$BlockPlanks$EnumType[var4.ordinal()]) {
         case 1:
         default:
            return MapColor.STONE;
         case 2:
            return BlockPlanks.EnumType.DARK_OAK.getMapColor();
         }
      case 4:
         return var4.getMapColor();
      }
   }

   private static void I() {
      I = new String[63 ^ 8];
      I["".length()] = I("洚叞", "sbvDx");
      I[" ".length()] = I("橶凒", "DabCp");
      I["  ".length()] = I("凜栭", "dfPaP");
      I["   ".length()] = I("汰峎", "oClpd");
      I[46 ^ 42] = I("丱效", "Ogbsh");
      I[161 ^ 164] = I("咍僪", "tEkMf");
      I[48 ^ 54] = I("堷寣", "sJdRm");
      I[157 ^ 154] = I("慵烿", "HjdbS");
      I[18 ^ 26] = I("惫浩买序", "XfWLq");
      I[139 ^ 130] = I("櫐氵", "dVBwD");
      I[125 ^ 119] = I("暘揯尋澖悅", "ZXbAC");
      I[9 ^ 2] = I("弦", "qBPxX");
      I[86 ^ 90] = I("奻", "wxfBM");
      I[54 ^ 59] = I("嵖淈嬇尲", "wjpQs");
      I[7 ^ 9] = I("持叮僁戫", "JbRSI");
      I[56 ^ 55] = I("慉僺", "mZuhl");
      I[123 ^ 107] = I("埙忼", "HPRZd");
      I[215 ^ 198] = I("仑殍", "jcvLx");
      I[139 ^ 153] = I("朝囨噟峥", "YaTWe");
      I[142 ^ 157] = I("刓佰檉楅攡", "mmCYk");
      I[37 ^ 49] = I("殠", "oIEah");
      I[215 ^ 194] = I("塱囤儂", "jNvos");
      I[118 ^ 96] = I("匝曒", "AUuGm");
      I[99 ^ 116] = I("墥娔", "iUsdA");
      I[44 ^ 52] = I("堊塤", "Ntcyf");
      I[98 ^ 123] = I("冯凉", "XxAdd");
      I[176 ^ 170] = I("欈咙", "eNPoA");
      I[30 ^ 5] = I("埄浗", "neUZn");
      I[108 ^ 112] = I("惿妪", "XlBuS");
      I[157 ^ 128] = I("椤撼", "WnHsx");
      I[90 ^ 68] = I("刢娬", "tKSZu");
      I[59 ^ 36] = I("帊未", "qRfMT");
      I[156 ^ 188] = I("偢嘆", "wpczN");
      I[136 ^ 169] = I("温娑", "lmqgE");
      I[16 ^ 50] = I("临定", "tZpLD");
      I[11 ^ 40] = I("堟", "bRdWg");
      I[88 ^ 124] = I("涑拏昦楡", "JodDn");
      I[66 ^ 103] = I("康嬣卖", "sSrFo");
      I[180 ^ 146] = I("弑別呢", "kvEcw");
      I[127 ^ 88] = I("吔", "SCDgb");
      I[171 ^ 131] = I("槏", "MAZKw");
      I[26 ^ 51] = I("栙慪", "qcrDX");
      I[98 ^ 72] = I("冡櫈", "dsWRH");
      I[35 ^ 8] = I("噾摎", "pzTDl");
      I[29 ^ 49] = I("淟佣", "bUngE");
      I[53 ^ 24] = I("俴捦", "QTUdS");
      I[121 ^ 87] = I("圫姟柸", "EKitV");
      I[102 ^ 73] = I("愅录幆呧塆", "Jmkom");
      I[133 ^ 181] = I("娸劃尾楲", "aWszJ");
      I[125 ^ 76] = I("净呬嵤惮", "mRiDJ");
      I[75 ^ 121] = I("棅懔", "ePvYT");
      I[77 ^ 126] = I("摲慢", "aVdgz");
      I[91 ^ 111] = I("椸吲榊", "gCRjY");
      I[68 ^ 113] = I("壨奡", "cAzIT");
      I[173 ^ 155] = I(",7\n,04\"", "ZVxEQ");
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[79 ^ 121], BlockPlanks.EnumType.class, new Predicate<BlockPlanks.EnumType>() {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 == -1);

            throw null;
         }

         public boolean apply(@Nullable BlockPlanks.EnumType var1) {
            int var10000;
            if (var1.getMetadata() >= (18 ^ 22)) {
               var10000 = " ".length();
               "".length();
               if (2 == 1) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      });
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var2 = this.getDefaultState().withProperty(VARIANT, BlockPlanks.EnumType.byMetadata((var1 & "   ".length()) + (51 ^ 55)));
      switch(var1 & (134 ^ 138)) {
      case 0:
         var2 = var2.withProperty(LOG_AXIS, BlockLog.EnumAxis.Y);
         "".length();
         if (0 == 4) {
            throw null;
         }
         break;
      case 4:
         var2 = var2.withProperty(LOG_AXIS, BlockLog.EnumAxis.X);
         "".length();
         if (0 >= 1) {
            throw null;
         }
         break;
      case 8:
         var2 = var2.withProperty(LOG_AXIS, BlockLog.EnumAxis.Z);
         "".length();
         if (-1 == 2) {
            throw null;
         }
         break;
      default:
         var2 = var2.withProperty(LOG_AXIS, BlockLog.EnumAxis.NONE);
      }

      return var2;
   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I[189 ^ 148];
      String var10001 = I[69 ^ 111];
      String var10002 = I[57 ^ 18];
      var10001 = I[155 ^ 183];
      I[56 ^ 21].length();
      I[176 ^ 158].length();
      I[168 ^ 135].length();
      I[98 ^ 82].length();
      I[50 ^ 3].length();
      Item var2 = Item.getItemFromBlock(this);
      int var10003 = " ".length();
      int var10004 = ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
      int var10005 = 167 ^ 163;
      I[21 ^ 39].length();
      I[187 ^ 136].length();
      I[171 ^ 159].length();
      return new ItemStack(var2, var10003, var10004 - var10005);
   }

   public BlockNewLog() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockPlanks.EnumType.ACACIA).withProperty(LOG_AXIS, BlockLog.EnumAxis.Y));
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[97 ^ 119];
      String var10001 = I[167 ^ 176];
      String var10002 = I[54 ^ 46];
      var10001 = I[141 ^ 148];
      var10000 = I[150 ^ 140];
      var10001 = I[134 ^ 157];
      var10002 = I[160 ^ 188];
      var10001 = I[119 ^ 106];
      var10000 = I[181 ^ 171];
      var10001 = I[173 ^ 178];
      var10002 = I[26 ^ 58];
      var10001 = I[34 ^ 3];
      I[64 ^ 98].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[135 ^ 164].length();
      I[181 ^ 145].length();
      I[112 ^ 85].length();
      I[65 ^ 103].length();
      var10003["".length()] = VARIANT;
      I[21 ^ 50].length();
      I[66 ^ 106].length();
      var10003[" ".length()] = LOG_AXIS;
      return new BlockStateContainer(this, var10003);
   }

   public int damageDropped(IBlockState var1) {
      int var10000 = ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
      int var10001 = 179 ^ 183;
      I[76 ^ 121].length();
      return var10000 - var10001;
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[107 ^ 111];
      var10001 = I[193 ^ 196];
      var10002 = I[63 ^ 57];
      var10001 = I[56 ^ 63];
      I[117 ^ 125].length();
      I[79 ^ 70].length();
      int var10004 = " ".length();
      int var10005 = BlockPlanks.EnumType.ACACIA.getMetadata();
      int var10006 = 2 ^ 6;
      I[205 ^ 199].length();
      var2.add(new ItemStack(this, var10004, var10005 - var10006));
      I[15 ^ 4].length();
      I[122 ^ 118].length();
      I[120 ^ 117].length();
      I[66 ^ 76].length();
      I[0 ^ 15].length();
      I[214 ^ 198].length();
      var10004 = " ".length();
      var10005 = BlockPlanks.EnumType.DARK_OAK.getMetadata();
      var10006 = 18 ^ 22;
      I[68 ^ 85].length();
      var2.add(new ItemStack(this, var10004, var10005 - var10006));
      I[124 ^ 110].length();
      I[168 ^ 187].length();
   }
}

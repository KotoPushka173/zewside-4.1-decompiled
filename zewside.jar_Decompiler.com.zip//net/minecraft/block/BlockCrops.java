package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockCrops extends BlockBush implements IGrowable {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyInteger AGE;
   // $FF: synthetic field
   private static final AxisAlignedBB[] CROPS_AABB;

   public IBlockState getStateFromMeta(int var1) {
      return this.withAge(var1);
   }

   public IBlockState withAge(int var1) {
      return this.getDefaultState().withProperty(this.getAgeProperty(), var1);
   }

   protected int getAge(IBlockState var1) {
      return (Integer)var1.getValue(this.getAgeProperty());
   }

   protected static float getGrowthChance(Block var0, World var1, BlockPos var2) {
      float var3 = 1.0F;
      BlockPos var4 = var2.down();
      int var5 = -" ".length();

      do {
         if (var5 > " ".length()) {
            BlockPos var12 = var2.north();
            BlockPos var13 = var2.south();
            BlockPos var15 = var2.west();
            BlockPos var14 = var2.east();
            int var10000;
            if (var0 != var1.getBlockState(var15).getBlock() && var0 != var1.getBlockState(var14).getBlock()) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (false) {
                  throw null;
               }
            }

            int var9 = var10000;
            if (var0 != var1.getBlockState(var12).getBlock() && var0 != var1.getBlockState(var13).getBlock()) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (2 != 2) {
                  throw null;
               }
            }

            int var10 = var10000;
            if (var9 != 0 && var10 != 0) {
               var3 /= 2.0F;
               "".length();
               if (3 <= -1) {
                  throw null;
               }
            } else {
               if (var0 != var1.getBlockState(var15.north()).getBlock() && var0 != var1.getBlockState(var14.north()).getBlock() && var0 != var1.getBlockState(var14.south()).getBlock() && var0 != var1.getBlockState(var15.south()).getBlock()) {
                  var10000 = "".length();
               } else {
                  var10000 = " ".length();
                  "".length();
                  if (3 < 1) {
                     throw null;
                  }
               }

               int var11 = var10000;
               if (var11 != 0) {
                  var3 /= 2.0F;
               }
            }

            return var3;
         }

         int var6 = -" ".length();

         while(var6 <= " ".length()) {
            float var7 = 0.0F;
            IBlockState var8 = var1.getBlockState(var4.add(var5, "".length(), var6));
            if (var8.getBlock() == Blocks.FARMLAND) {
               var7 = 1.0F;
               if ((Integer)var8.getValue(BlockFarmland.MOISTURE) > 0) {
                  var7 = 3.0F;
               }
            }

            if (var5 != 0 || var6 != 0) {
               var7 /= 4.0F;
            }

            var3 += var7;
            ++var6;
            "".length();
            if (2 == 0) {
               throw null;
            }
         }

         ++var5;
         "".length();
      } while(3 >= -1);

      throw null;
   }

   protected Item getSeed() {
      return Items.WHEAT_SEEDS;
   }

   public int getMetaFromState(IBlockState var1) {
      return this.getAge(var1);
   }

   protected PropertyInteger getAgeProperty() {
      return AGE;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      super.updateTick(var1, var2, var3, var4);
      if (var1.getLightFromNeighbors(var2.up()) >= (130 ^ 139)) {
         int var5 = this.getAge(var3);
         if (var5 < this.getMaxAge()) {
            float var6 = getGrowthChance(this, var1, var2);
            if (var4.nextInt((int)(25.0F / var6) + " ".length()) == 0) {
               var1.setBlockState(var2, this.withAge(var5 + " ".length()), "  ".length());
               I["".length()].length();
               I[" ".length()].length();
            }
         }
      }

   }

   public boolean canGrow(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      int var10000;
      if (!this.isMaxAge(var3)) {
         var10000 = " ".length();
         "".length();
         if (2 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   static {
      I();
      AGE = PropertyInteger.create(I[157 ^ 130], "".length(), 179 ^ 180);
      AxisAlignedBB[] var10000 = new AxisAlignedBB[162 ^ 170];
      var10000["".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.125D, 1.0D);
      var10000[" ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.25D, 1.0D);
      var10000["  ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.375D, 1.0D);
      var10000["   ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
      var10000[122 ^ 126] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.625D, 1.0D);
      var10000[32 ^ 37] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.75D, 1.0D);
      var10000[120 ^ 126] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.875D, 1.0D);
      var10000[123 ^ 124] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      CROPS_AABB = var10000;
   }

   public boolean canBlockStay(World var1, BlockPos var2, IBlockState var3) {
      int var10000;
      if ((var1.getLight(var2) >= (26 ^ 18) || var1.canSeeSky(var2)) && this.canSustainBush(var1.getBlockState(var2.down()))) {
         var10000 = " ".length();
         "".length();
         if (4 == 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private static void I() {
      I = new String[35 ^ 3];
      I["".length()] = I("冯毳潇", "qIcJI");
      I[" ".length()] = I("匧偟俉", "itWXn");
      I["  ".length()] = I("亥", "QGeFs");
      I["   ".length()] = I("丆", "DhDUG");
      I[2 ^ 6] = I("殅憋慗曶", "ACyUi");
      I[59 ^ 62] = I("杼伻", "AdQQJ");
      I[79 ^ 73] = I("攄垈", "nimDz");
      I[126 ^ 121] = I("檦慧", "fPBCX");
      I[49 ^ 57] = I("圻岕", "ModIa");
      I[53 ^ 60] = I("恄樶元擐", "jflpJ");
      I[40 ^ 34] = I("唺塄彅咩摒", "cvyFE");
      I[102 ^ 109] = I("昹仿剶丬叆", "vFivL");
      I[49 ^ 61] = I("呦湉", "cZbfD");
      I[157 ^ 144] = I("塊校", "glFAt");
      I[34 ^ 44] = I("枴懲", "CVpwh");
      I[54 ^ 57] = I("帑樋", "NqeaU");
      I[69 ^ 85] = I("夥", "NvBJc");
      I[9 ^ 24] = I("潄戠焝涔呍", "LgZUN");
      I[73 ^ 91] = I("伯戼炈", "LbMAm");
      I[72 ^ 91] = I("劝歑", "ZGoys");
      I[94 ^ 74] = I("杹傋", "UVyrk");
      I[122 ^ 111] = I("厲愎", "MmdZH");
      I[44 ^ 58] = I("埖庯", "RxYlz");
      I[174 ^ 185] = I("况樃", "QeHZu");
      I[95 ^ 71] = I("汣昆", "deBFb");
      I[51 ^ 42] = I("寳旕", "snjHO");
      I[39 ^ 61] = I("嫰冠", "SCSLW");
      I[164 ^ 191] = I("沉嵯旽怓", "TmiqJ");
      I[148 ^ 136] = I("洕旲幏杘倰", "HRZgA");
      I[150 ^ 139] = I("嫡", "ISWlq");
      I[157 ^ 131] = I("澉撌烲浞咚", "wOeTl");
      I[150 ^ 137] = I("(\n\u0004", "ImaDI");
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return CROPS_AABB[(Integer)var1.getValue(this.getAgeProperty())];
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 2);

      throw null;
   }

   public void grow(World var1, Random var2, BlockPos var3, IBlockState var4) {
      this.grow(var1, var3, var4);
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[100 ^ 104];
      String var10001 = I[206 ^ 195];
      String var10002 = I[101 ^ 107];
      var10001 = I[168 ^ 167];
      I[60 ^ 44].length();
      I[114 ^ 99].length();
      I[178 ^ 160].length();
      return new ItemStack(this.getSeed());
   }

   public boolean isMaxAge(IBlockState var1) {
      int var10000;
      if ((Integer)var1.getValue(this.getAgeProperty()) >= this.getMaxAge()) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   protected BlockCrops() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(this.getAgeProperty(), "".length()));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab((CreativeTabs)null);
      this.setHardness(0.0F);
      this.setSoundType(SoundType.PLANT);
      this.disableStats();
   }

   public void grow(World var1, BlockPos var2, IBlockState var3) {
      int var4 = this.getAge(var3) + this.getBonemealAgeIncrease(var1);
      int var5 = this.getMaxAge();
      if (var4 > var5) {
         var4 = var5;
      }

      var1.setBlockState(var2, this.withAge(var4), "  ".length());
      I["  ".length()].length();
      I["   ".length()].length();
      I[65 ^ 69].length();
   }

   protected boolean canSustainBush(IBlockState var1) {
      int var10000;
      if (var1.getBlock() == Blocks.FARMLAND) {
         var10000 = " ".length();
         "".length();
         if (3 < 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      Item var10000;
      if (this.isMaxAge(var1)) {
         var10000 = this.getCrop();
         "".length();
         if (0 < -1) {
            throw null;
         }
      } else {
         var10000 = this.getSeed();
      }

      return var10000;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[124 ^ 111];
      String var10001 = I[178 ^ 166];
      String var10002 = I[70 ^ 83];
      var10001 = I[52 ^ 34];
      var10000 = I[182 ^ 161];
      var10001 = I[142 ^ 150];
      var10002 = I[165 ^ 188];
      var10001 = I[191 ^ 165];
      I[9 ^ 18].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[78 ^ 82].length();
      I[63 ^ 34].length();
      I[32 ^ 62].length();
      var10003["".length()] = AGE;
      return new BlockStateContainer(this, var10003);
   }

   public int getMaxAge() {
      return 13 ^ 10;
   }

   protected Item getCrop() {
      return Items.WHEAT;
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      String var10000 = I[107 ^ 110];
      String var10001 = I[54 ^ 48];
      String var10002 = I[17 ^ 22];
      var10001 = I[140 ^ 132];
      super.dropBlockAsItemWithChance(var1, var2, var3, var4, "".length());
      if (!var1.isRemote) {
         int var6 = this.getAge(var3);
         if (var6 >= this.getMaxAge()) {
            int var7 = "   ".length() + var5;
            int var8 = "".length();

            while(var8 < var7) {
               if (var1.rand.nextInt("  ".length() * this.getMaxAge()) <= var6) {
                  I[62 ^ 55].length();
                  I[127 ^ 117].length();
                  I[184 ^ 179].length();
                  spawnAsEntity(var1, var2, new ItemStack(this.getSeed()));
               }

               ++var8;
               "".length();
               if (false) {
                  throw null;
               }
            }
         }
      }

   }

   public boolean canUseBonemeal(World var1, Random var2, BlockPos var3, IBlockState var4) {
      return (boolean)" ".length();
   }

   protected int getBonemealAgeIncrease(World var1) {
      return MathHelper.getInt(var1.rand, "  ".length(), 195 ^ 198);
   }
}

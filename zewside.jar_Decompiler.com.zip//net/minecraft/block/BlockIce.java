package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;

public class BlockIce extends BlockBreakable {
   // $FF: synthetic field
   private static final String[] I;

   private static void I() {
      I = new String[111 ^ 98];
      I["".length()] = I("卍囨堉", "rEbah");
      I[" ".length()] = I("哞", "LpOQP");
      I["  ".length()] = I("榘槭晘渚", "ioJgG");
      I["   ".length()] = I("挳屔湒泰力", "prGGb");
      I[154 ^ 158] = I("淳壟瀱俋", "gfCyT");
      I[33 ^ 36] = I("妜揑", "fKgyW");
      I[64 ^ 70] = I("楟姗匴榮", "voQdZ");
      I[5 ^ 2] = I("嵸", "HhKXu");
      I[203 ^ 195] = I("勜", "LCQVy");
      I[159 ^ 150] = I("炋", "jvkOX");
      I[180 ^ 190] = I("嚔攊勪垔", "JLwuU");
      I[10 ^ 1] = I("榐噦椇漇", "ojccC");
      I[205 ^ 193] = I("伊僲沫氰", "qrsOk");
   }

   public EnumPushReaction getMobilityFlag(IBlockState var1) {
      return EnumPushReaction.NORMAL;
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      var2.addStat(StatList.getBlockStats(this));
      var2.addExhaustion(0.005F);
      if (this.canSilkHarvest() && EnchantmentHelper.getEnchantmentLevel(Enchantments.SILK_TOUCH, var6) > 0) {
         spawnAsEntity(var1, var3, this.getSilkTouchDrop(var4));
         "".length();
         if (0 < 0) {
            throw null;
         }
      } else {
         if (var1.provider.doesWaterVaporize()) {
            var1.setBlockToAir(var3);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            return;
         }

         int var7 = EnchantmentHelper.getEnchantmentLevel(Enchantments.FORTUNE, var6);
         this.dropBlockAsItem(var1, var3, var4, var7);
         Material var8 = var1.getBlockState(var3.down()).getMaterial();
         if (var8.blocksMovement() || var8.isLiquid()) {
            var1.setBlockState(var3, Blocks.FLOWING_WATER.getDefaultState());
            I["   ".length()].length();
            I[75 ^ 79].length();
            I[114 ^ 119].length();
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > -1);

      throw null;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.TRANSLUCENT;
   }

   protected void turnIntoWater(World var1, BlockPos var2) {
      if (var1.provider.doesWaterVaporize()) {
         var1.setBlockToAir(var2);
         I[130 ^ 138].length();
         I[123 ^ 114].length();
         "".length();
         if (-1 >= 3) {
            throw null;
         }
      } else {
         this.dropBlockAsItem(var1, var2, var1.getBlockState(var2), "".length());
         var1.setBlockState(var2, Blocks.WATER.getDefaultState());
         I[140 ^ 134].length();
         I[8 ^ 3].length();
         I[205 ^ 193].length();
         var1.func_190524_a(var2, Blocks.WATER, var2);
      }

   }

   public BlockIce() {
      super(Material.ICE, (boolean)"".length());
      this.slipperiness = 0.98F;
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      int var10000 = var1.getLightFor(EnumSkyBlock.BLOCK, var2);
      int var10001 = 57 ^ 50;
      int var10002 = this.getDefaultState().getLightOpacity();
      I[85 ^ 83].length();
      I[73 ^ 78].length();
      if (var10000 > var10001 - var10002) {
         this.turnIntoWater(var1, var2);
      }

   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   static {
      I();
   }
}

package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentOxygen extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   public int getMaxLevel() {
      return "   ".length();
   }

   public int getMinEnchantability(int var1) {
      return (9 ^ 3) * var1;
   }

   public EnchantmentOxygen(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.ARMOR_HEAD, var2);
      this.setName(I["".length()]);
   }

   public int getMaxEnchantability(int var1) {
      return this.getMinEnchantability(var1) + (91 ^ 69);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("\u001b4\u001d#&\u001a", "tLdDC");
   }

   static {
      I();
   }
}

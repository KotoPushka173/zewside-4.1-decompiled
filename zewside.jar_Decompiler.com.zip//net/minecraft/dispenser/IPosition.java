package net.minecraft.dispenser;

public interface IPosition {
   double getZ();

   double getY();

   double getX();
}

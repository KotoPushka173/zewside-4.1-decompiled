package net.minecraft.stats;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
import net.minecraft.scoreboard.IScoreCriteria;
import net.minecraft.scoreboard.ScoreCriteriaStat;
import net.minecraft.util.IJsonSerializable;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;

public class StatBase {
   // $FF: synthetic field
   private static final DecimalFormat decimalFormat;
   // $FF: synthetic field
   private final ITextComponent statName;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public final String statId;
   // $FF: synthetic field
   public boolean isIndependent;
   // $FF: synthetic field
   private Class<? extends IJsonSerializable> serializableClazz;
   // $FF: synthetic field
   public static IStatType divideByTen;
   // $FF: synthetic field
   private final IScoreCriteria objectiveCriteria;
   // $FF: synthetic field
   private static final NumberFormat numberFormat;
   // $FF: synthetic field
   public static IStatType distanceStatType;
   // $FF: synthetic field
   public static IStatType timeStatType;
   // $FF: synthetic field
   public static IStatType simpleStatType;
   // $FF: synthetic field
   private final IStatType formatter;

   public IScoreCriteria getCriteria() {
      return this.objectiveCriteria;
   }

   private static void I() {
      I = new String[30 ^ 59];
      I["".length()] = I("媽亟", "tiDxG");
      I[" ".length()] = I("壃桨", "kpQiS");
      I["  ".length()] = I("劘嚴", "hYkei");
      I["   ".length()] = I("宺扰", "vBXaY");
      I[167 ^ 163] = I("攨挹", "BcOWF");
      I[61 ^ 56] = I("枞坙", "ANcMz");
      I[165 ^ 163] = I("尋嬝", "KqFoq");
      I[165 ^ 162] = I("愲峻", "MdSUo");
      I[21 ^ 29] = I("厀嚜", "TeLSk");
      I[22 ^ 31] = I("戾懃", "MWpyK");
      I[153 ^ 147] = I("嚅推戓娥槉", "rRFfT");
      I[202 ^ 193] = I("啊", "pUzPL");
      I[31 ^ 19] = I("炸凨宭佘尋", "Pcfih");
      I[14 ^ 3] = I("憱彦总歪憻", "pzkNX");
      I[32 ^ 46] = I("\u0000\u0016'\u001d?'\u0002#\u0014v7\u00176\u0005v-\u0007mQt", "DcWqV");
      I[120 ^ 119] = I("Lh\u00009\u0007Nj", "nHaWc");
      I[62 ^ 46] = I("qB\b\u0000v:\u0006I", "SbitV");
      I[62 ^ 47] = I("冿崔汻大押", "iVLrV");
      I[54 ^ 36] = I("炼慀烗", "TOhTY");
      I[187 ^ 168] = I("岐戍", "FZegR");
      I[23 ^ 3] = I("元", "JlCQJ");
      I[126 ^ 107] = I("洊", "fUmyK");
      I[149 ^ 131] = I("抷嵰", "YcbRK");
      I[60 ^ 43] = I("槝毤嗫", "dCFlG");
      I[29 ^ 5] = I("死嚀", "BqNSf");
      I[138 ^ 147] = I("匳坙", "eDzpi");
      I[31 ^ 5] = I("刻圸", "pRFuk");
      I[3 ^ 24] = I("傒掎", "gCwGI");
      I[45 ^ 49] = I("姝宂", "ABetD");
      I[75 ^ 86] = I("婄埤撘澟", "wsprz");
      I[109 ^ 115] = I("煉丽斜渋", "PUFYh");
      I[56 ^ 39] = I("\u001f:6:1%*j", "LNWNJ");
      I[38 ^ 6] = I("zL\u0019\u0004%3%\u0013X", "VlweH");
      I[155 ^ 186] = I("aE/\"3?\u0001\u0002:1,\t\",\u001d#\t7h", "MeNUR");
      I[228 ^ 198] = I("@H\u0010\t$\u0001\t\u0002\u00123\u001eU", "lhvfV");
      I[104 ^ 75] = I("KG\u0007\u0007\u0019\u0002\u0004\u001c\f\u0005\u0002$\u001a\f\u0007\u0002\u0015\u0001\u0004N", "gghes");
      I[163 ^ 135] = I("p`ILap`I_lcs", "SCjoB");
   }

   public ITextComponent getStatName() {
      ITextComponent var1 = this.statName.createCopy();
      var1.getStyle().setColor(TextFormatting.GRAY);
      I[171 ^ 189].length();
      I[135 ^ 144].length();
      I[10 ^ 18].length();
      return var1;
   }

   public String toString() {
      String var10000 = I[122 ^ 99];
      String var10001 = I[105 ^ 115];
      String var10002 = I[69 ^ 94];
      var10001 = I[11 ^ 23];
      I[19 ^ 14].length();
      I[46 ^ 48].length();
      return I[50 ^ 45] + this.statId + I[230 ^ 198] + this.statName + I[30 ^ 63] + this.isIndependent + I[191 ^ 157] + this.formatter + I[100 ^ 71] + this.objectiveCriteria + ('h' ^ '\u0015');
   }

   public String format(int var1) {
      return this.formatter.format(var1);
   }

   public StatBase registerStat() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[42 ^ 46];
      var10001 = I[130 ^ 135];
      var10002 = I[106 ^ 108];
      var10001 = I[12 ^ 11];
      if (StatList.ID_TO_STAT_MAP.containsKey(this.statId)) {
         I[66 ^ 74].length();
         I[201 ^ 192].length();
         I[94 ^ 84].length();
         I[177 ^ 186].length();
         I[66 ^ 78].length();
         I[113 ^ 124].length();
         RuntimeException var1 = new RuntimeException(I[200 ^ 198] + ((StatBase)StatList.ID_TO_STAT_MAP.get(this.statId)).statName + I[126 ^ 113] + this.statName + I[155 ^ 139] + this.statId);
         I[11 ^ 26].length();
         I[98 ^ 112].length();
         throw var1;
      } else {
         StatList.ALL_STATS.add(this);
         I[152 ^ 139].length();
         I[165 ^ 177].length();
         StatList.ID_TO_STAT_MAP.put(this.statId, this);
         I[33 ^ 52].length();
         return this;
      }
   }

   public Class<? extends IJsonSerializable> getSerializableClazz() {
      return this.serializableClazz;
   }

   public StatBase(String var1, ITextComponent var2) {
      this(var1, var2, simpleStatType);
   }

   public StatBase(String var1, ITextComponent var2, IStatType var3) {
      this.statId = var1;
      this.statName = var2;
      this.formatter = var3;
      this.objectiveCriteria = new ScoreCriteriaStat(this);
      IScoreCriteria.INSTANCES.put(this.objectiveCriteria.getName(), this.objectiveCriteria);
   }

   static {
      I();
      numberFormat = NumberFormat.getIntegerInstance(Locale.US);
      simpleStatType = new IStatType() {
         public String format(int var1) {
            return StatBase.numberFormat.format((long)var1);
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 > 1);

            throw null;
         }
      };
      decimalFormat = new DecimalFormat(I[78 ^ 106]);
      timeStatType = new IStatType() {
         // $FF: synthetic field
         private static final String[] I;

         public String format(int var1) {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[45 ^ 41];
            var10001 = I[141 ^ 136];
            var10002 = I[91 ^ 93];
            var10001 = I[7 ^ 0];
            var10000 = I[66 ^ 74];
            var10001 = I[74 ^ 67];
            var10002 = I[156 ^ 150];
            var10001 = I[54 ^ 61];
            var10000 = I[121 ^ 117];
            var10001 = I[45 ^ 32];
            var10002 = I[83 ^ 93];
            var10001 = I[48 ^ 63];
            var10000 = I[115 ^ 99];
            var10001 = I[77 ^ 92];
            var10002 = I[64 ^ 82];
            var10001 = I[110 ^ 125];
            double var2 = (double)var1 / 20.0D;
            double var4 = var2 / 60.0D;
            double var6 = var4 / 60.0D;
            double var8 = var6 / 24.0D;
            double var10 = var8 / 365.0D;
            if (var10 > 0.5D) {
               I[88 ^ 76].length();
               I[16 ^ 5].length();
               I[157 ^ 139].length();
               I[37 ^ 50].length();
               return StatBase.decimalFormat.format(var10) + I[144 ^ 136];
            } else if (var8 > 0.5D) {
               I[150 ^ 143].length();
               return StatBase.decimalFormat.format(var8) + I[81 ^ 75];
            } else if (var6 > 0.5D) {
               I[183 ^ 172].length();
               I[39 ^ 59].length();
               return StatBase.decimalFormat.format(var6) + I[100 ^ 121];
            } else {
               if (var4 > 0.5D) {
                  I[76 ^ 82].length();
                  var10000 = StatBase.decimalFormat.format(var4) + I[44 ^ 51];
                  "".length();
                  if (4 != 4) {
                     throw null;
                  }
               } else {
                  I[123 ^ 91].length();
                  var10000 = var2 + I[167 ^ 134];
               }

               return var10000;
            }
         }

         private static void I() {
            I = new String[28 ^ 62];
            I["".length()] = I("槛坯", "TkWze");
            I[" ".length()] = I("丆拙", "nfuUi");
            I["  ".length()] = I("搈昆", "ylBJP");
            I["   ".length()] = I("撄暞", "fJDQX");
            I[115 ^ 119] = I("漚媹", "MhfbA");
            I[4 ^ 1] = I("昫侕", "ZLULR");
            I[54 ^ 48] = I("朩斔", "RZSOs");
            I[33 ^ 38] = I("毵昘", "QJSYs");
            I[90 ^ 82] = I("櫺儨", "cIbSA");
            I[43 ^ 34] = I("媁幁", "iFDkH");
            I[165 ^ 175] = I("哱揜", "rJHdX");
            I[156 ^ 151] = I("亝樇", "WzfDW");
            I[112 ^ 124] = I("侸噿", "rLcHK");
            I[180 ^ 185] = I("敐佌", "tyARD");
            I[160 ^ 174] = I("摞塸", "PijJU");
            I[34 ^ 45] = I("桝寁", "tbCfq");
            I[77 ^ 93] = I("撏湝", "mWTQg");
            I[98 ^ 115] = I("夭椘", "QuLfA");
            I[140 ^ 158] = I("焈妄", "HtaKh");
            I[163 ^ 176] = I("坴濋", "mcJLm");
            I[90 ^ 78] = I("扙", "Udwio");
            I[34 ^ 55] = I("檛瀫橥", "NilDl");
            I[42 ^ 60] = I("徢浍濙", "QOMte");
            I[87 ^ 64] = I("桤栍", "THPec");
            I[144 ^ 136] = I("A.", "aWRKR");
            I[185 ^ 160] = I("咨", "Fzoff");
            I[100 ^ 126] = I("d(", "DLjKT");
            I[157 ^ 134] = I("奭暘", "ageVY");
            I[74 ^ 86] = I("濇倂丷挪歸", "lnEmu");
            I[61 ^ 32] = I("x\u0011", "XyKLS");
            I[18 ^ 12] = I("佾儛", "uLXsp");
            I[183 ^ 168] = I("K\u0000", "kmeub");
            I[103 ^ 71] = I("懂曹儫", "fFgGq");
            I[179 ^ 146] = I("m9", "MJYmG");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 == 4);

            throw null;
         }

         static {
            I();
         }
      };
      distanceStatType = new IStatType() {
         // $FF: synthetic field
         private static final String[] I;

         public String format(int var1) {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[10 ^ 14];
            var10001 = I[8 ^ 13];
            var10002 = I[89 ^ 95];
            var10001 = I[196 ^ 195];
            var10000 = I[70 ^ 78];
            var10001 = I[161 ^ 168];
            var10002 = I[119 ^ 125];
            var10001 = I[205 ^ 198];
            double var2 = (double)var1 / 100.0D;
            double var4 = var2 / 1000.0D;
            if (var4 > 0.5D) {
               I[4 ^ 8].length();
               return StatBase.decimalFormat.format(var4) + I[77 ^ 64];
            } else {
               if (var2 > 0.5D) {
                  I[91 ^ 85].length();
                  I[65 ^ 78].length();
                  var10000 = StatBase.decimalFormat.format(var2) + I[212 ^ 196];
                  "".length();
                  if (0 <= -1) {
                     throw null;
                  }
               } else {
                  I[72 ^ 89].length();
                  I[147 ^ 129].length();
                  var10000 = var1 + I[163 ^ 176];
               }

               return var10000;
            }
         }

         static {
            I();
         }

         private static void I() {
            I = new String[97 ^ 117];
            I["".length()] = I("欪哯", "Jtomc");
            I[" ".length()] = I("吂忺", "UVKqL");
            I["  ".length()] = I("扡嫜", "zbSWf");
            I["   ".length()] = I("撳丝", "ufOoS");
            I[149 ^ 145] = I("媰只", "WvqiF");
            I[158 ^ 155] = I("歒凗", "lOykE");
            I[28 ^ 26] = I("慐僲", "LUitf");
            I[123 ^ 124] = I("点寋", "NeaaF");
            I[5 ^ 13] = I("孀倪", "IxlxH");
            I[83 ^ 90] = I("剖农", "AvPMY");
            I[177 ^ 187] = I("按峾", "LnxnJ");
            I[177 ^ 186] = I("攮橸", "oxumz");
            I[45 ^ 33] = I("家宾惇搏朡", "ilvZx");
            I[29 ^ 16] = I("x=\u0015", "XVxch");
            I[201 ^ 199] = I("櫿榘悯櫾播", "JoUGb");
            I[158 ^ 145] = I("侩", "Viphp");
            I[119 ^ 103] = I("U>", "uSSjE");
            I[38 ^ 55] = I("宁斑", "QwuYn");
            I[5 ^ 23] = I("垧拂", "fIDfw");
            I[171 ^ 184] = I("t\u0001\b", "TbeOm");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(0 > -1);

            throw null;
         }
      };
      divideByTen = new IStatType() {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 < 0);

            throw null;
         }

         public String format(int var1) {
            return StatBase.decimalFormat.format((double)var1 * 0.1D);
         }
      };
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)" ".length();
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         StatBase var2 = (StatBase)var1;
         return this.statId.equals(var2.statId);
      } else {
         return (boolean)"".length();
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   public StatBase initIndependentStat() {
      this.isIndependent = (boolean)" ".length();
      return this;
   }

   public int hashCode() {
      return this.statId.hashCode();
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketTimeUpdate implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private long worldTime;
   // $FF: synthetic field
   private long totalWorldTime;

   private static void I() {
      I = new String[35 ^ 38];
      I["".length()] = I("枣", "nVRfl");
      I[" ".length()] = I("僧", "Ybydv");
      I["  ".length()] = I("煞交徊嫢渞", "UUuem");
      I["   ".length()] = I("擌椟噝堡廿", "sJcey");
      I[62 ^ 58] = I("湭旣仭擌棣", "tXwaY");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.totalWorldTime = var1.readLong();
      this.worldTime = var1.readLong();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeLong(this.totalWorldTime);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeLong(this.worldTime);
      I["  ".length()].length();
      I["   ".length()].length();
      I[122 ^ 126].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public long getTotalWorldTime() {
      return this.totalWorldTime;
   }

   public long getWorldTime() {
      return this.worldTime;
   }

   public SPacketTimeUpdate(long var1, long var3, boolean var5) {
      this.totalWorldTime = var1;
      this.worldTime = var3;
      if (!var5) {
         this.worldTime = -this.worldTime;
         if (this.worldTime == 0L) {
            this.worldTime = -1L;
         }
      }

   }

   public SPacketTimeUpdate() {
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleTimeUpdate(this);
   }
}

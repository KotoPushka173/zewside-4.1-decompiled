package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;

public class SPacketSpawnPosition implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private BlockPos spawnBlockPos;

   static {
      I();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.spawnBlockPos = var1.readBlockPos();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeBlockPos(this.spawnBlockPos);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
   }

   public SPacketSpawnPosition() {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSpawnPosition(this);
   }

   private static void I() {
      I = new String[179 ^ 183];
      I["".length()] = I("櫖囑嫱娏", "rHRsw");
      I[" ".length()] = I("煃攙怱岻捦", "ZhSbB");
      I["  ".length()] = I("樮够啨", "YKXbM");
      I["   ".length()] = I("櫡", "XQyEG");
   }

   public BlockPos getSpawnPos() {
      return this.spawnBlockPos;
   }

   public SPacketSpawnPosition(BlockPos var1) {
      this.spawnBlockPos = var1;
   }
}

package net.minecraftforge.common.model;

import net.minecraft.client.renderer.Matrix4f;
import org.apache.commons.lang3.NotImplementedException;

public class TRSRTransformation {
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   public TRSRTransformation(Matrix4f var1) {
      throw new NotImplementedException(I["".length()]);
   }

   private static void I() {
      I = new String[0 ^ 11];
      I["".length()] = I("\u0013\u0007\u0011,\u0004u\f\u0016&\f,H\u0000'\u0000&\u001b", "UhcKa");
      I[" ".length()] = I("朄懾", "bUZvy");
      I["  ".length()] = I("愭哈", "usdOx");
      I["   ".length()] = I("嵸冇", "pzRed");
      I[89 ^ 93] = I("惹啺", "WEiVi");
      I[22 ^ 19] = I("尶娑潊", "sfkXz");
      I[106 ^ 108] = I("洓桰梮", "mTcrV");
      I[86 ^ 81] = I("摴晚", "xrmGS");
      I[11 ^ 3] = I("娏捙旙壬", "PzsKc");
      I[6 ^ 15] = I("\u0014(;\u0002/r#<\b'+g*\t+!4", "RGIeJ");
      I[179 ^ 185] = I("憡朘娫", "Alpoa");
   }

   public static boolean isInteger(javax.vecmath.Matrix4f var0) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[20 ^ 16];
      I[52 ^ 49].length();
      I[106 ^ 108].length();
      I[33 ^ 38].length();
      I[129 ^ 137].length();
      NotImplementedException var1 = new NotImplementedException(I[179 ^ 186]);
      I[4 ^ 14].length();
      throw var1;
   }
}

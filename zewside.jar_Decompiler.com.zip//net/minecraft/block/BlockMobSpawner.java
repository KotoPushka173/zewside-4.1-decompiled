package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityMobSpawner;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockMobSpawner extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      return ItemStack.field_190927_a;
   }

   static {
      I();
   }

   private static void I() {
      I = new String[147 ^ 149];
      I["".length()] = I("寘咪", "qJdGM");
      I[" ".length()] = I("洚俪", "eSqvF");
      I["  ".length()] = I("冓潿", "KmdEn");
      I["   ".length()] = I("嚭束", "MXgFL");
      I[53 ^ 49] = I("溓伲濥", "KkqlZ");
      I[46 ^ 43] = I("厑", "MqPFN");
   }

   protected BlockMobSpawner() {
      super(Material.ROCK);
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[92 ^ 88].length();
      I[193 ^ 196].length();
      return new TileEntityMobSpawner();
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 2);

      throw null;
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      super.dropBlockAsItemWithChance(var1, var2, var3, var4, var5);
      int var6 = (60 ^ 51) + var1.rand.nextInt(129 ^ 142) + var1.rand.nextInt(28 ^ 19);
      this.dropXpOnBlockBreak(var1, var2, var6);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.field_190931_a;
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }
}

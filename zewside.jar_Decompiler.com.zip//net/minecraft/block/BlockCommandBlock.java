package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.CommandBlockBaseLogic;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityCommandBlock;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.StringUtils;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BlockCommandBlock extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   private static final Logger field_193388_c;
   // $FF: synthetic field
   public static final PropertyBool CONDITIONAL;

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[179 ^ 163];
      String var10001 = I[149 ^ 132];
      String var10002 = I[124 ^ 110];
      var10001 = I[170 ^ 185];
      var10000 = I[39 ^ 51];
      var10001 = I[182 ^ 163];
      var10002 = I[182 ^ 160];
      var10001 = I[167 ^ 176];
      var10000 = I[222 ^ 198];
      var10001 = I[108 ^ 117];
      var10002 = I[110 ^ 116];
      var10001 = I[125 ^ 102];
      I[222 ^ 194].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[141 ^ 144].length();
      I[93 ^ 67].length();
      var10003["".length()] = FACING;
      I[114 ^ 109].length();
      I[65 ^ 97].length();
      var10003[" ".length()] = CONDITIONAL;
      return new BlockStateContainer(this, var10003);
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[149 ^ 145].length();
      I[35 ^ 38].length();
      I[23 ^ 17].length();
      TileEntityCommandBlock var3 = new TileEntityCommandBlock();
      int var4;
      if (this == Blocks.CHAIN_COMMAND_BLOCK) {
         var4 = " ".length();
         "".length();
         if (0 < -1) {
            throw null;
         }
      } else {
         var4 = "".length();
      }

      var3.setAuto((boolean)var4);
      return var3;
   }

   private static void I() {
      I = new String[247 ^ 193];
      I["".length()] = I("栎乏", "VkCvG");
      I[" ".length()] = I("嶂婤", "LoTgA");
      I["  ".length()] = I("椡咃", "yBqcX");
      I["   ".length()] = I("悑探", "hGvUJ");
      I[73 ^ 77] = I("明快刮晁瀸", "qskVt");
      I[32 ^ 37] = I("妹俀愶涖浗", "bDshO");
      I[132 ^ 130] = I("凂溜傽屖", "xsCmL");
      I[130 ^ 133] = I("漍煍汨屏", "owyZv");
      I[81 ^ 89] = I("兞", "SkHZG");
      I[108 ^ 101] = I("劫嗀倐次", "Ubiaz");
      I[164 ^ 174] = I("块旝", "hjyoj");
      I[90 ^ 81] = I("塞", "ZszOK");
      I[104 ^ 100] = I("巴", "aLBvZ");
      I[148 ^ 153] = I("洹慖毥剧", "GhcLA");
      I[79 ^ 65] = I("3'7\"$4%,(;\b\u001f9&", "qKXAO");
      I[176 ^ 191] = I("\u00067\u0014-(\u001a?\u0017(\u0005\u0011\u0014\u001f,\u000f\u00173\u0019\"", "uRzIk");
      I[157 ^ 141] = I("倲壪", "aLxDZ");
      I[137 ^ 152] = I("岾煄", "JjEot");
      I[20 ^ 6] = I("晴墾", "VKCeT");
      I[26 ^ 9] = I("室弤", "VDEbs");
      I[171 ^ 191] = I("淋咎", "HZGhT");
      I[23 ^ 2] = I("冉埌", "MLbVq");
      I[71 ^ 81] = I("儳伵", "lnvwj");
      I[151 ^ 128] = I("妀景", "UvbAZ");
      I[137 ^ 145] = I("涴义", "qzEmz");
      I[158 ^ 135] = I("塡慼", "ioyTA");
      I[161 ^ 187] = I("嗒咱", "SrcYN");
      I[18 ^ 9] = I("戭扖", "VfKZZ");
      I[169 ^ 181] = I("掖孷渴淆", "bNmbQ");
      I[86 ^ 75] = I("埧灑澭", "NweIx");
      I[107 ^ 117] = I("堈垄僳", "qMdXX");
      I[13 ^ 18] = I("嶧", "zIAHO");
      I[179 ^ 147] = I("侳", "OnCeO");
      I[63 ^ 30] = I("栌份", "LMIiU");
      I[1 ^ 35] = I("揘嶍", "lcrkv");
      I[33 ^ 2] = I("怲帿", "oJDPX");
      I[117 ^ 81] = I("掖囝", "EBlxy");
      I[146 ^ 183] = I("渨圳", "Epnhw");
      I[38 ^ 0] = I("揆漪", "fdzMe");
      I[89 ^ 126] = I("刡廫", "pxMlv");
      I[49 ^ 25] = I("堔残", "liCvG");
      I[105 ^ 64] = I("枴戆剔开恒", "WxiLg");
      I[109 ^ 71] = I("刻測愞", "NAPcu");
      I[180 ^ 159] = I("渞", "ksOrq");
      I[115 ^ 95] = I("\t\u0010\t1 \t\u001c\u0010\u001c+'\u0019\u0010\u001b!(\u0014\u001f\u0015;\f", "dqqrO");
      I[41 ^ 4] = I("嶃", "HDXME");
      I[74 ^ 100] = I("欓埴梜戶濑", "CjPSS");
      I[166 ^ 137] = I("&\u0018):%&\u00140\u0017.\b\u00110\u0010$\u0007\u001c?\u001e>#", "KyQyJ");
      I[189 ^ 141] = I("匪幆擨椴", "hSSog");
      I[140 ^ 189] = I("垝", "xAhry");
      I[34 ^ 16] = I("冲崲", "VTtOw");
      I[92 ^ 111] = I("0\"\u0005< \u001d)\n=.\u0010&H2)\u0012$\u0006q5\u0001$\r5a\u0007\"H49\u0016.\u001d#$S \u0007#$S9\u00000/S", "sMhQA");
      I[74 ^ 126] = I("b<#\u0010:1n", "BOWuJ");
      I[86 ^ 99] = I("\u000e\u000e!\u0016\u0004\u0019\b \u001c\f\u0001", "maOrm");
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      TileEntity var10 = var1.getTileEntity(var2);
      if (var10 instanceof TileEntityCommandBlock && var4.canUseCommandBlock()) {
         var4.displayGuiCommandBlock((TileEntityCommandBlock)var10);
         return (boolean)" ".length();
      } else {
         return (boolean)"".length();
      }
   }

   public int tickRate(World var1) {
      return " ".length();
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote) {
         TileEntity var6 = var2.getTileEntity(var3);
         if (var6 instanceof TileEntityCommandBlock) {
            TileEntityCommandBlock var7 = (TileEntityCommandBlock)var6;
            boolean var8 = var2.isBlockPowered(var3);
            boolean var9 = var7.isPowered();
            var7.setPowered(var8);
            if (!var9 && !var7.isAuto() && var7.getMode() != TileEntityCommandBlock.Mode.SEQUENCE && var8) {
               var7.setConditionMet();
               I[81 ^ 86].length();
               I[90 ^ 82].length();
               var2.scheduleUpdate(var3, this, this.tickRate(var2));
            }
         }
      }

   }

   static {
      I();
      field_193388_c = LogManager.getLogger();
      FACING = BlockDirectional.FACING;
      CONDITIONAL = PropertyBool.create(I[5 ^ 48]);
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      TileEntity var6 = var1.getTileEntity(var2);
      if (var6 instanceof TileEntityCommandBlock) {
         TileEntityCommandBlock var7 = (TileEntityCommandBlock)var6;
         CommandBlockBaseLogic var8 = var7.getCommandBlockLogic();
         if (var5.hasDisplayName()) {
            var8.setName(var5.getDisplayName());
         }

         if (!var1.isRemote) {
            NBTTagCompound var9 = var5.getTagCompound();
            if (var9 == null || !var9.hasKey(I[99 ^ 109], 140 ^ 134)) {
               var8.setTrackOutput(var1.getGameRules().getBoolean(I[16 ^ 31]));
               int var10001;
               if (this == Blocks.CHAIN_COMMAND_BLOCK) {
                  var10001 = " ".length();
                  "".length();
                  if (3 != 3) {
                     throw null;
                  }
               } else {
                  var10001 = "".length();
               }

               var7.setAuto((boolean)var10001);
            }

            if (var7.getMode() == TileEntityCommandBlock.Mode.SEQUENCE) {
               boolean var10 = var1.isBlockPowered(var2);
               var7.setPowered(var10);
            }
         }
      }

   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   private void func_193387_a(IBlockState var1, World var2, BlockPos var3, CommandBlockBaseLogic var4, boolean var5) {
      if (var5) {
         var4.trigger(var2);
         I[166 ^ 170].length();
         I[14 ^ 3].length();
         "".length();
         if (3 == 4) {
            throw null;
         }
      } else {
         var4.setSuccessCount("".length());
      }

      func_193386_c(var2, var3, (EnumFacing)var1.getValue(FACING));
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.func_190914_a(var2, var8)).withProperty(CONDITIONAL, Boolean.valueOf((boolean)"".length()));
   }

   public BlockCommandBlock(MapColor var1) {
      super(Material.IRON, var1);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(CONDITIONAL, Boolean.valueOf((boolean)"".length())));
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, EnumFacing.getFront(var1 & (53 ^ 50)));
      PropertyBool var10001 = CONDITIONAL;
      int var10002;
      if ((var1 & (132 ^ 140)) != 0) {
         var10002 = " ".length();
         "".length();
         if (-1 >= 3) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      TileEntity var4 = var2.getTileEntity(var3);
      int var10000;
      if (var4 instanceof TileEntityCommandBlock) {
         var10000 = ((TileEntityCommandBlock)var4).getCommandBlockLogic().getSuccessCount();
         "".length();
         if (0 >= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   public int getMetaFromState(IBlockState var1) {
      int var10000 = ((EnumFacing)var1.getValue(FACING)).getIndex();
      int var10001;
      if ((Boolean)var1.getValue(CONDITIONAL)) {
         var10001 = 106 ^ 98;
         "".length();
         if (2 >= 4) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      return var10000 | var10001;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote) {
         TileEntity var5 = var1.getTileEntity(var2);
         if (var5 instanceof TileEntityCommandBlock) {
            TileEntityCommandBlock var6 = (TileEntityCommandBlock)var5;
            CommandBlockBaseLogic var7 = var6.getCommandBlockLogic();
            int var10000;
            if (!StringUtils.isNullOrEmpty(var7.getCommand())) {
               var10000 = " ".length();
               "".length();
               if (2 <= 0) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            int var8 = var10000;
            TileEntityCommandBlock.Mode var9 = var6.getMode();
            boolean var10 = var6.isConditionMet();
            if (var9 == TileEntityCommandBlock.Mode.AUTO) {
               var6.setConditionMet();
               I[135 ^ 142].length();
               I[79 ^ 69].length();
               I[84 ^ 95].length();
               if (var10) {
                  this.func_193387_a(var3, var1, var2, var7, (boolean)var8);
                  "".length();
                  if (0 >= 3) {
                     throw null;
                  }
               } else if (var6.isConditional()) {
                  var7.setSuccessCount("".length());
               }

               if (var6.isPowered() || var6.isAuto()) {
                  var1.scheduleUpdate(var2, this, this.tickRate(var1));
                  "".length();
                  if (1 == 2) {
                     throw null;
                  }
               }
            } else if (var9 == TileEntityCommandBlock.Mode.REDSTONE) {
               if (var10) {
                  this.func_193387_a(var3, var1, var2, var7, (boolean)var8);
                  "".length();
                  if (4 == -1) {
                     throw null;
                  }
               } else if (var6.isConditional()) {
                  var7.setSuccessCount("".length());
               }
            }

            var1.updateComparatorOutputLevel(var2, this);
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 1);

      throw null;
   }

   private static void func_193386_c(World var0, BlockPos var1, EnumFacing var2) {
      String var10000 = I[226 ^ 195];
      String var10001 = I[188 ^ 158];
      String var10002 = I[101 ^ 70];
      var10001 = I[143 ^ 171];
      var10000 = I[49 ^ 20];
      var10001 = I[91 ^ 125];
      var10002 = I[46 ^ 9];
      var10001 = I[118 ^ 94];
      I[130 ^ 171].length();
      I[162 ^ 136].length();
      I[29 ^ 54].length();
      BlockPos.MutableBlockPos var3 = new BlockPos.MutableBlockPos(var1);
      GameRules var4 = var0.getGameRules();
      int var5 = var4.getInt(I[173 ^ 129]);

      while(var5-- > 0) {
         var3.move(var2);
         I[63 ^ 18].length();
         I[146 ^ 188].length();
         IBlockState var6 = var0.getBlockState(var3);
         Block var7 = var6.getBlock();
         if (var7 != Blocks.CHAIN_COMMAND_BLOCK) {
            "".length();
            if (-1 >= 0) {
               throw null;
            }
            break;
         }

         TileEntity var8 = var0.getTileEntity(var3);
         if (!(var8 instanceof TileEntityCommandBlock)) {
            "".length();
            if (2 != 2) {
               throw null;
            }
            break;
         }

         TileEntityCommandBlock var9 = (TileEntityCommandBlock)var8;
         if (var9.getMode() != TileEntityCommandBlock.Mode.SEQUENCE) {
            "".length();
            if (1 == 2) {
               throw null;
            }
            break;
         }

         if (var9.isPowered() || var9.isAuto()) {
            CommandBlockBaseLogic var10 = var9.getCommandBlockLogic();
            if (var9.setConditionMet()) {
               if (!var10.trigger(var0)) {
                  "".length();
                  if (4 == -1) {
                     throw null;
                  }
                  break;
               }

               var0.updateComparatorOutputLevel(var3, var7);
               "".length();
               if (4 != 4) {
                  throw null;
               }
            } else if (var9.isConditional()) {
               var10.setSuccessCount("".length());
            }
         }

         var2 = (EnumFacing)var6.getValue(FACING);
         "".length();
         if (1 >= 2) {
            throw null;
         }
      }

      if (var5 <= 0) {
         int var11 = Math.max(var4.getInt(I[84 ^ 123]), "".length());
         Logger var13 = field_193388_c;
         I[22 ^ 38].length();
         I[110 ^ 95].length();
         I[150 ^ 164].length();
         var13.warn(I[89 ^ 106] + var11 + I[185 ^ 141]);
      }

   }
}

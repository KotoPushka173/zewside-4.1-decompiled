package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;

public class CuredZombieVillagerTrigger implements ICriterionTrigger<CuredZombieVillagerTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_192186_a;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, CuredZombieVillagerTrigger.Listeners> field_192187_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
      field_192186_a = new ResourceLocation(I[123 ^ 99]);
   }

   private static void I() {
      I = new String[186 ^ 163];
      I["".length()] = I("嚑捚", "Tresh");
      I[" ".length()] = I("搤澅", "FmXJk");
      I["  ".length()] = I("抗敌", "KoCrd");
      I["   ".length()] = I("娸兡", "ijbhj");
      I[60 ^ 56] = I("俷溙", "KeSJo");
      I[199 ^ 194] = I("峎櫵技", "wcidw");
      I[144 ^ 150] = I("勜沤或廤庤", "IaxBy");
      I[78 ^ 73] = I("敺劘", "ckIGA");
      I[92 ^ 84] = I("構戰煌朠", "UfJmh");
      I[35 ^ 42] = I("浣吷棶弰", "soYfA");
      I[69 ^ 79] = I("懬", "xfEQh");
      I[11 ^ 0] = I("橄沈橹瀓", "iIWCX");
      I[88 ^ 84] = I("擇曈枌楓抗", "xdBVT");
      I[127 ^ 114] = I("瀺", "ebAiv");
      I[13 ^ 3] = I("垳拣扌垵", "aMFmX");
      I[60 ^ 51] = I("性梑", "PQjAN");
      I[213 ^ 197] = I("掙洡寮嗹坱", "hvALX");
      I[190 ^ 175] = I("淼汣", "hOCzj");
      I[52 ^ 38] = I("嘩渌", "bOYac");
      I[53 ^ 38] = I("厎侻", "WyDNy");
      I[97 ^ 117] = I("沥渖", "EetfM");
      I[129 ^ 148] = I("4</&\u0003+", "NSBDj");
      I[14 ^ 24] = I("3\u000b?\u001e\u0004\"\u0007!", "EbSre");
      I[76 ^ 91] = I("弡宿劆", "ozXwK");
      I[94 ^ 70] = I("0\u0018$\u0017.\f\u00179\u001f(:\b\t\u0004#?\u00017\u0015/!", "SmVrJ");
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192187_b.remove(var1);
      I[13 ^ 2].length();
      I[40 ^ 56].length();
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<CuredZombieVillagerTrigger.Instance> var2) {
      CuredZombieVillagerTrigger.Listeners var3 = (CuredZombieVillagerTrigger.Listeners)this.field_192187_b.get(var1);
      if (var3 != null) {
         var3.func_192358_b(var2);
         if (var3.func_192359_a()) {
            this.field_192187_b.remove(var1);
            I[15 ^ 4].length();
            I[146 ^ 158].length();
            I[59 ^ 54].length();
            I[164 ^ 170].length();
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 2);

      throw null;
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<CuredZombieVillagerTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      CuredZombieVillagerTrigger.Listeners var3 = (CuredZombieVillagerTrigger.Listeners)this.field_192187_b.get(var1);
      if (var3 == null) {
         I[4 ^ 0].length();
         I[112 ^ 117].length();
         I[172 ^ 170].length();
         var3 = new CuredZombieVillagerTrigger.Listeners(var1);
         this.field_192187_b.put(var1, var3);
         I[153 ^ 158].length();
         I[132 ^ 140].length();
         I[96 ^ 105].length();
         I[11 ^ 1].length();
      }

      var3.func_192360_a(var2);
   }

   public ResourceLocation func_192163_a() {
      return field_192186_a;
   }

   public CuredZombieVillagerTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[55 ^ 38];
      String var10001 = I[113 ^ 99];
      String var10002 = I[127 ^ 108];
      var10001 = I[93 ^ 73];
      EntityPredicate var3 = EntityPredicate.func_192481_a(var1.get(I[59 ^ 46]));
      EntityPredicate var4 = EntityPredicate.func_192481_a(var1.get(I[146 ^ 132]));
      I[124 ^ 107].length();
      return new CuredZombieVillagerTrigger.Instance(var3, var4);
   }

   public void func_192183_a(EntityPlayerMP var1, EntityZombie var2, EntityVillager var3) {
      CuredZombieVillagerTrigger.Listeners var4 = (CuredZombieVillagerTrigger.Listeners)this.field_192187_b.get(var1.func_192039_O());
      if (var4 != null) {
         var4.func_192361_a(var1, var2, var3);
      }

   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final EntityPredicate field_192256_b;
      // $FF: synthetic field
      private final EntityPredicate field_192255_a;

      public boolean func_192254_a(EntityPlayerMP var1, EntityZombie var2, EntityVillager var3) {
         return (boolean)(!this.field_192255_a.func_192482_a(var1, var2) ? "".length() : this.field_192256_b.func_192482_a(var1, var3));
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 < 2);

         throw null;
      }

      public Instance(EntityPredicate var1, EntityPredicate var2) {
         super(CuredZombieVillagerTrigger.field_192186_a);
         this.field_192255_a = var1;
         this.field_192256_b = var2;
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<CuredZombieVillagerTrigger.Instance>> field_192363_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_192362_a;
      // $FF: synthetic field
      private static final String[] I;

      public void func_192358_b(ICriterionTrigger.Listener<CuredZombieVillagerTrigger.Instance> var1) {
         this.field_192363_b.remove(var1);
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }

      private static void I() {
         I = new String[124 ^ 121];
         I["".length()] = I("庛波烕擵城", "YQfGO");
         I[" ".length()] = I("摪池儁店", "qCfgR");
         I["  ".length()] = I("梘", "ffFJC");
         I["   ".length()] = I("吪夛帐", "pnrBS");
         I[22 ^ 18] = I("亙榻烓戅", "nnlWG");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(true);

         throw null;
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192362_a = var1;
      }

      public boolean func_192359_a() {
         return this.field_192363_b.isEmpty();
      }

      static {
         I();
      }

      public void func_192361_a(EntityPlayerMP var1, EntityZombie var2, EntityVillager var3) {
         ArrayList var4 = null;
         Iterator var5 = this.field_192363_b.iterator();

         ICriterionTrigger.Listener var6;
         while(var5.hasNext()) {
            var6 = (ICriterionTrigger.Listener)var5.next();
            if (((CuredZombieVillagerTrigger.Instance)var6.func_192158_a()).func_192254_a(var1, var2, var3)) {
               if (var4 == null) {
                  var4 = Lists.newArrayList();
               }

               var4.add(var6);
               I[76 ^ 72].length();
            }

            "".length();
            if (-1 < -1) {
               throw null;
            }
         }

         if (var4 != null) {
            var5 = var4.iterator();

            while(var5.hasNext()) {
               var6 = (ICriterionTrigger.Listener)var5.next();
               var6.func_192159_a(this.field_192362_a);
               "".length();
               if (1 < -1) {
                  throw null;
               }
            }
         }

      }

      public void func_192360_a(ICriterionTrigger.Listener<CuredZombieVillagerTrigger.Instance> var1) {
         this.field_192363_b.add(var1);
         I["".length()].length();
      }
   }
}

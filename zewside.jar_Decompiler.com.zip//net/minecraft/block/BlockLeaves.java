package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockLeaves extends Block {
   // $FF: synthetic field
   protected boolean leavesFancy;
   // $FF: synthetic field
   public static final PropertyBool CHECK_DECAY;
   // $FF: synthetic field
   int[] surroundings;
   // $FF: synthetic field
   public static final PropertyBool DECAYABLE;
   // $FF: synthetic field
   private static final String[] I;

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.SAPLING);
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      if (var2.isRainingAt(var3.up()) && !var2.getBlockState(var3.down()).isFullyOpaque() && var4.nextInt(59 ^ 52) == " ".length()) {
         double var5 = (double)((float)var3.getX() + var4.nextFloat());
         double var10000 = (double)var3.getY();
         I[63 ^ 122].length();
         I[121 ^ 63].length();
         double var7 = var10000 - 0.05D;
         double var9 = (double)((float)var3.getZ() + var4.nextFloat());
         var2.spawnParticle(EnumParticleTypes.DRIP_WATER, var5, var7, var9, 0.0D, 0.0D, 0.0D);
      }

   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[10 ^ 14];
      var10001 = I[50 ^ 55];
      var10002 = I[31 ^ 25];
      var10001 = I[155 ^ 156];
      int var4 = " ".length();
      int var5 = "  ".length();
      int var6 = var2.getX();
      int var7 = var2.getY();
      int var8 = var2.getZ();
      I[18 ^ 26].length();
      int var10004 = "  ".length();
      I[201 ^ 192].length();
      I[139 ^ 129].length();
      I[111 ^ 100].length();
      I[143 ^ 131].length();
      int var10003 = var6 - var10004;
      int var10005 = "  ".length();
      I[105 ^ 100].length();
      var10004 = var7 - var10005;
      int var10006 = "  ".length();
      I[189 ^ 179].length();
      I[138 ^ 133].length();
      I[139 ^ 155].length();
      BlockPos var14 = new BlockPos(var10003, var10004, var8 - var10006);
      I[112 ^ 97].length();
      I[47 ^ 61].length();
      I[21 ^ 6].length();
      I[146 ^ 134].length();
      if (var1.isAreaLoaded(var14, new BlockPos(var6 + "  ".length(), var7 + "  ".length(), var8 + "  ".length()))) {
         int var9 = -" ".length();

         while(var9 <= " ".length()) {
            int var10 = -" ".length();

            while(var10 <= " ".length()) {
               int var11 = -" ".length();

               while(var11 <= " ".length()) {
                  BlockPos var12 = var2.add(var9, var10, var11);
                  IBlockState var13 = var1.getBlockState(var12);
                  if (var13.getMaterial() == Material.LEAVES && !(Boolean)var13.getValue(CHECK_DECAY)) {
                     var1.setBlockState(var12, var13.withProperty(CHECK_DECAY, Boolean.valueOf((boolean)" ".length())), 83 ^ 87);
                     I[92 ^ 73].length();
                     I[7 ^ 17].length();
                  }

                  ++var11;
                  "".length();
                  if (-1 != -1) {
                     throw null;
                  }
               }

               ++var10;
               "".length();
               if (-1 == 0) {
                  throw null;
               }
            }

            ++var9;
            "".length();
            if (4 != 4) {
               throw null;
            }
         }
      }

   }

   protected int getSaplingDropChance(IBlockState var1) {
      return 105 ^ 125;
   }

   public BlockLeaves() {
      super(Material.LEAVES);
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.DECORATIONS);
      this.setHardness(0.2F);
      this.setLightOpacity(" ".length());
      this.setSoundType(SoundType.PLANT);
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if (!this.leavesFancy && var2.getBlockState(var3.offset(var4)).getBlock() == this) {
         var10000 = "".length();
         "".length();
         if (1 <= 0) {
            throw null;
         }
      } else {
         var10000 = super.shouldSideBeRendered(var1, var2, var3, var4);
      }

      return (boolean)var10000;
   }

   protected void dropApple(World var1, BlockPos var2, IBlockState var3, int var4) {
   }

   public void setGraphicsLevel(boolean var1) {
      this.leavesFancy = var1;
   }

   public int quantityDropped(Random var1) {
      int var10000;
      if (var1.nextInt(142 ^ 154) == 0) {
         var10000 = " ".length();
         "".length();
         if (3 <= 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   private void destroy(World var1, BlockPos var2) {
      this.dropBlockAsItem(var1, var2, var1.getBlockState(var2), "".length());
      var1.setBlockToAir(var2);
      I[192 ^ 135].length();
      I[233 ^ 161].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 1);

      throw null;
   }

   public BlockRenderLayer getBlockLayer() {
      BlockRenderLayer var10000;
      if (this.leavesFancy) {
         var10000 = BlockRenderLayer.CUTOUT_MIPPED;
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var10000 = BlockRenderLayer.SOLID;
      }

      return var10000;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      String var10000 = I[171 ^ 188];
      String var10001 = I[191 ^ 167];
      String var10002 = I[123 ^ 98];
      var10001 = I[180 ^ 174];
      var10000 = I[173 ^ 182];
      var10001 = I[117 ^ 105];
      var10002 = I[80 ^ 77];
      var10001 = I[19 ^ 13];
      var10000 = I[29 ^ 2];
      var10001 = I[119 ^ 87];
      var10002 = I[124 ^ 93];
      var10001 = I[167 ^ 133];
      if (!var1.isRemote && (Boolean)var3.getValue(CHECK_DECAY) && (Boolean)var3.getValue(DECAYABLE)) {
         int var5 = 54 ^ 50;
         int var6 = 121 ^ 124;
         int var7 = var2.getX();
         int var8 = var2.getY();
         int var9 = var2.getZ();
         int var10 = 166 ^ 134;
         int var11 = 169 + 52 - -685 + 118;
         int var12 = 187 ^ 171;
         if (this.surroundings == null) {
            this.surroundings = new int[2344 + 16753 - 14401 + 28072];
         }

         I[167 ^ 132].length();
         I[129 ^ 165].length();
         I[63 ^ 26].length();
         I[108 ^ 74].length();
         int var10004 = 138 ^ 143;
         I[133 ^ 162].length();
         int var10003 = var7 - var10004;
         int var10005 = 132 ^ 129;
         I[154 ^ 178].length();
         I[39 ^ 14].length();
         I[191 ^ 149].length();
         I[10 ^ 33].length();
         var10004 = var8 - var10005;
         int var10006 = 37 ^ 32;
         I[21 ^ 57].length();
         I[150 ^ 187].length();
         I[27 ^ 53].length();
         BlockPos var23 = new BlockPos(var10003, var10004, var9 - var10006);
         I[163 ^ 140].length();
         if (var1.isAreaLoaded(var23, new BlockPos(var7 + (95 ^ 90), var8 + (132 ^ 129), var9 + (134 ^ 131)))) {
            I[113 ^ 65].length();
            I[86 ^ 103].length();
            BlockPos.MutableBlockPos var13 = new BlockPos.MutableBlockPos();
            int var14 = -(9 ^ 13);

            label134:
            while(true) {
               int var15;
               int var16;
               if (var14 > (97 ^ 101)) {
                  var14 = " ".length();

                  do {
                     if (var14 > (23 ^ 19)) {
                        break label134;
                     }

                     var15 = -(57 ^ 61);

                     while(var15 <= (191 ^ 187)) {
                        var16 = -(16 ^ 20);

                        while(var16 <= (194 ^ 198)) {
                           int var20 = -(142 ^ 138);

                           while(var20 <= (160 ^ 164)) {
                              int var21 = this.surroundings[(var15 + (147 ^ 131)) * (924 + 781 - 1385 + 704) + (var16 + (105 ^ 121)) * (153 ^ 185) + var20 + (40 ^ 56)];
                              int var24 = " ".length();
                              I[180 ^ 134].length();
                              I[33 ^ 18].length();
                              I[91 ^ 111].length();
                              if (var21 == var14 - var24) {
                                 int[] var22 = this.surroundings;
                                 int var25 = var15 + (98 ^ 114);
                                 var24 = " ".length();
                                 I[142 ^ 187].length();
                                 I[112 ^ 70].length();
                                 I[98 ^ 85].length();
                                 I[121 ^ 65].length();
                                 I[57 ^ 0].length();
                                 if (var22[(var25 - var24) * (582 + 913 - 1278 + 807) + (var16 + (75 ^ 91)) * (62 ^ 30) + var20 + (117 ^ 101)] == -"  ".length()) {
                                    var22 = this.surroundings;
                                    var25 = var15 + (131 ^ 147);
                                    var24 = " ".length();
                                    I[85 ^ 111].length();
                                    I[49 ^ 10].length();
                                    var22[(var25 - var24) * (175 + 561 - 695 + 983) + (var16 + (110 ^ 126)) * (29 ^ 61) + var20 + (65 ^ 81)] = var14;
                                 }

                                 if (this.surroundings[(var15 + (211 ^ 195) + " ".length()) * (22 + 429 - -535 + 38) + (var16 + (163 ^ 179)) * (100 ^ 68) + var20 + (28 ^ 12)] == -"  ".length()) {
                                    this.surroundings[(var15 + (77 ^ 93) + " ".length()) * (824 + 639 - 488 + 49) + (var16 + (63 ^ 47)) * (53 ^ 21) + var20 + (186 ^ 170)] = var14;
                                 }

                                 var22 = this.surroundings;
                                 var25 = (var15 + (114 ^ 98)) * (491 + 675 - 1058 + 916);
                                 var24 = var16 + (130 ^ 146);
                                 var10003 = " ".length();
                                 I[107 ^ 87].length();
                                 if (var22[var25 + (var24 - var10003) * (143 ^ 175) + var20 + (98 ^ 114)] == -"  ".length()) {
                                    var22 = this.surroundings;
                                    var25 = (var15 + (138 ^ 154)) * (870 + 186 - 423 + 391);
                                    var24 = var16 + (10 ^ 26);
                                    var10003 = " ".length();
                                    I[110 ^ 83].length();
                                    var22[var25 + (var24 - var10003) * (0 ^ 32) + var20 + (105 ^ 121)] = var14;
                                 }

                                 if (this.surroundings[(var15 + (104 ^ 120)) * (463 + 983 - 815 + 393) + (var16 + (39 ^ 55) + " ".length()) * (186 ^ 154) + var20 + (80 ^ 64)] == -"  ".length()) {
                                    this.surroundings[(var15 + (85 ^ 69)) * (796 + 927 - 1354 + 655) + (var16 + (15 ^ 31) + " ".length()) * (66 ^ 98) + var20 + (148 ^ 132)] = var14;
                                 }

                                 var22 = this.surroundings;
                                 var25 = (var15 + (8 ^ 24)) * (231 + 31 - 84 + 846) + (var16 + (38 ^ 54)) * (51 ^ 19);
                                 var24 = var20 + (19 ^ 3);
                                 var10003 = " ".length();
                                 I[42 ^ 20].length();
                                 I[9 ^ 54].length();
                                 if (var22[var25 + (var24 - var10003)] == -"  ".length()) {
                                    var22 = this.surroundings;
                                    var25 = (var15 + (150 ^ 134)) * (712 + 663 - 627 + 276) + (var16 + (133 ^ 149)) * (167 ^ 135);
                                    var24 = var20 + (157 ^ 141);
                                    var10003 = " ".length();
                                    I[22 ^ 86].length();
                                    I[88 ^ 25].length();
                                    var22[var25 + (var24 - var10003)] = var14;
                                 }

                                 if (this.surroundings[(var15 + (181 ^ 165)) * (241 + 184 - -262 + 337) + (var16 + (122 ^ 106)) * (22 ^ 54) + var20 + (137 ^ 153) + " ".length()] == -"  ".length()) {
                                    this.surroundings[(var15 + (114 ^ 98)) * (86 + 210 - 182 + 910) + (var16 + (143 ^ 159)) * (37 ^ 5) + var20 + (152 ^ 136) + " ".length()] = var14;
                                 }
                              }

                              ++var20;
                              "".length();
                              if (4 <= -1) {
                                 throw null;
                              }
                           }

                           ++var16;
                           "".length();
                           if (0 >= 2) {
                              throw null;
                           }
                        }

                        ++var15;
                        "".length();
                        if (-1 >= 4) {
                           throw null;
                        }
                     }

                     ++var14;
                     "".length();
                  } while(4 >= 3);

                  throw null;
               }

               var15 = -(37 ^ 33);

               while(var15 <= (153 ^ 157)) {
                  var16 = -(21 ^ 17);

                  while(var16 <= (146 ^ 150)) {
                     IBlockState var17 = var1.getBlockState(var13.setPos(var7 + var14, var8 + var15, var9 + var16));
                     Block var18 = var17.getBlock();
                     if (var18 != Blocks.LOG && var18 != Blocks.LOG2) {
                        if (var17.getMaterial() == Material.LEAVES) {
                           this.surroundings[(var14 + (129 ^ 145)) * (400 + 112 - 119 + 631) + (var15 + (118 ^ 102)) * (62 ^ 30) + var16 + (27 ^ 11)] = -"  ".length();
                           "".length();
                           if (3 <= 2) {
                              throw null;
                           }
                        } else {
                           this.surroundings[(var14 + (78 ^ 94)) * (146 + 802 - 388 + 464) + (var15 + (70 ^ 86)) * (103 ^ 71) + var16 + (111 ^ 127)] = -" ".length();
                           "".length();
                           if (0 >= 1) {
                              throw null;
                           }
                        }
                     } else {
                        this.surroundings[(var14 + (155 ^ 139)) * (307 + 1003 - 1264 + 978) + (var15 + (169 ^ 185)) * (55 ^ 23) + var16 + (46 ^ 62)] = "".length();
                     }

                     ++var16;
                     "".length();
                     if (2 < 0) {
                        throw null;
                     }
                  }

                  ++var15;
                  "".length();
                  if (-1 >= 4) {
                     throw null;
                  }
               }

               ++var14;
               "".length();
               if (4 != 4) {
                  throw null;
               }
            }
         }

         int var19 = this.surroundings[12001 + 14664 - 14428 + 4675];
         if (var19 >= 0) {
            var1.setBlockState(var2, var3.withProperty(CHECK_DECAY, Boolean.valueOf((boolean)"".length())), 179 ^ 183);
            I[192 ^ 130].length();
            I[51 ^ 112].length();
            I[44 ^ 104].length();
            "".length();
            if (3 <= 2) {
               throw null;
            }
         } else {
            this.destroy(var1, var2);
         }
      }

   }

   static {
      I();
      DECAYABLE = PropertyBool.create(I[46 ^ 124]);
      CHECK_DECAY = PropertyBool.create(I[0 ^ 83]);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      int var10000;
      if (!this.leavesFancy) {
         var10000 = " ".length();
         "".length();
         if (4 < -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public abstract BlockPlanks.EnumType getWoodType(int var1);

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      String var10000 = I[45 ^ 100];
      String var10001 = I[90 ^ 16];
      String var10002 = I[116 ^ 63];
      var10001 = I[87 ^ 27];
      if (!var1.isRemote) {
         int var6 = this.getSaplingDropChance(var3);
         int var8;
         if (var5 > 0) {
            var8 = "  ".length() << var5;
            I[6 ^ 75].length();
            var6 -= var8;
            if (var6 < (143 ^ 133)) {
               var6 = 64 ^ 74;
            }
         }

         if (var1.rand.nextInt(var6) == 0) {
            Item var7 = this.getItemDropped(var3, var1.rand, var5);
            I[0 ^ 78].length();
            I[213 ^ 154].length();
            spawnAsEntity(var1, var2, new ItemStack(var7, " ".length(), this.damageDropped(var3)));
         }

         var6 = 82 + 127 - 99 + 90;
         if (var5 > 0) {
            var8 = (110 ^ 100) << var5;
            I[37 ^ 117].length();
            I[237 ^ 188].length();
            var6 -= var8;
            if (var6 < (8 ^ 32)) {
               var6 = 41 ^ 1;
            }
         }

         this.dropApple(var1, var2, var3, var6);
      }

   }

   public boolean causesSuffocation(IBlockState var1) {
      return (boolean)"".length();
   }

   private static void I() {
      I = new String[119 ^ 35];
      I["".length()] = I("怟灀", "TwMbA");
      I[" ".length()] = I("棬棐", "YcQpw");
      I["  ".length()] = I("滎戛", "WJyTh");
      I["   ".length()] = I("抗器", "lBfoJ");
      I[44 ^ 40] = I("俓刂", "yicqi");
      I[34 ^ 39] = I("洎洘", "WeYZb");
      I[50 ^ 52] = I("昁坍", "UWULH");
      I[67 ^ 68] = I("体幹", "VYpzm");
      I[68 ^ 76] = I("嵡勢", "pLEPm");
      I[3 ^ 10] = I("冬拈", "xqVmx");
      I[99 ^ 105] = I("嚗", "Tpopx");
      I[170 ^ 161] = I("挛僦歪", "jUxDl");
      I[178 ^ 190] = I("常摑墰樫廔", "rbxNh");
      I[50 ^ 63] = I("啀烀", "KwYua");
      I[43 ^ 37] = I("农", "TDOuN");
      I[138 ^ 133] = I("春", "nuEct");
      I[25 ^ 9] = I("劌滒", "ROQZb");
      I[157 ^ 140] = I("槼侧圾乆懯", "mFgar");
      I[41 ^ 59] = I("慈役侏沸", "FyeHO");
      I[88 ^ 75] = I("叭戮圣", "SPWsJ");
      I[107 ^ 127] = I("墡潉柾", "ncotV");
      I[117 ^ 96] = I("囎櫡愠昞", "AqSyl");
      I[34 ^ 52] = I("悋匑揋滎", "RgWRp");
      I[122 ^ 109] = I("敤彶", "UDKkp");
      I[147 ^ 139] = I("櫌卤", "zUuvg");
      I[217 ^ 192] = I("滭楁", "ijrVd");
      I[66 ^ 88] = I("杳事", "DfXzv");
      I[25 ^ 2] = I("冼楛", "uJSvL");
      I[162 ^ 190] = I("弊柀", "GAclG");
      I[16 ^ 13] = I("垿滮", "ryOYl");
      I[143 ^ 145] = I("崗惐", "SmbJc");
      I[8 ^ 23] = I("嘇枽", "dHypC");
      I[80 ^ 112] = I("濧匕", "PpxvW");
      I[95 ^ 126] = I("业儷", "DCsra");
      I[33 ^ 3] = I("劼唦", "jvaUR");
      I[126 ^ 93] = I("濴吐", "aUWVg");
      I[139 ^ 175] = I("婕摴槅嬵", "SnATj");
      I[191 ^ 154] = I("槞垼", "NrYEt");
      I[25 ^ 63] = I("斒", "GiGaV");
      I[181 ^ 146] = I("孙温咖友", "IDsTp");
      I[91 ^ 115] = I("楢", "CPjJp");
      I[107 ^ 66] = I("溥", "nIaQk");
      I[141 ^ 167] = I("崚", "gaFjB");
      I[84 ^ 127] = I("権傼", "giQVz");
      I[94 ^ 114] = I("廗", "boQWR");
      I[74 ^ 103] = I("洭攻山帣", "KEzot");
      I[170 ^ 132] = I("傹摟嫀", "dXSNr");
      I[97 ^ 78] = I("氈榨惮", "yBzZo");
      I[127 ^ 79] = I("濕", "PAAzE");
      I[25 ^ 40] = I("徘煗", "aNKdm");
      I[73 ^ 123] = I("梡儑", "gfwae");
      I[70 ^ 117] = I("炡囈", "gBftn");
      I[48 ^ 4] = I("卑店", "YvgMA");
      I[240 ^ 197] = I("娧", "cGqgd");
      I[152 ^ 174] = I("教", "YmFjg");
      I[172 ^ 155] = I("劆泶焢", "Yxgsb");
      I[129 ^ 185] = I("哂尮", "HEcvn");
      I[20 ^ 45] = I("亢亖", "MobVc");
      I[180 ^ 142] = I("扪擢仐傩坖", "mVCWU");
      I[117 ^ 78] = I("吳抉潴攧", "LIlRs");
      I[161 ^ 157] = I("宨暶昀描", "EViHJ");
      I[21 ^ 40] = I("浭朑", "kZUel");
      I[128 ^ 190] = I("憋嚋炿潍另", "OQohT");
      I[120 ^ 71] = I("毦啼憷氹", "YILuf");
      I[25 ^ 89] = I("則嚛掕檏尥", "ueMxE");
      I[75 ^ 10] = I("徐烿搹吐", "mFTMH");
      I[89 ^ 27] = I("嶎", "Qkjiy");
      I[128 ^ 195] = I("嫍外愤煋煏", "TnHbs");
      I[240 ^ 180] = I("婨幰潳漎囄", "FhkpN");
      I[40 ^ 109] = I("晓情孪座俔", "VeVrR");
      I[198 ^ 128] = I("匦塮叏嗁", "sQSne");
      I[25 ^ 94] = I("剖嗮", "ageQG");
      I[41 ^ 97] = I("殖泪涎坴嶀", "yPija");
      I[224 ^ 169] = I("渺埨", "Ksuzs");
      I[36 ^ 110] = I("喖唵", "pHUfM");
      I[213 ^ 158] = I("歮櫇", "KitgD");
      I[17 ^ 93] = I("氬娮", "zSDeU");
      I[94 ^ 19] = I("山宁", "RmcHc");
      I[143 ^ 193] = I("栵塑", "jnSPg");
      I[222 ^ 145] = I("渋", "hNfcg");
      I[220 ^ 140] = I("梫炄常", "yvwSc");
      I[217 ^ 136] = I("呢嵍崝冂伕", "oUkJL");
      I[39 ^ 117] = I("\u0012?(\n\u0001\u00178'\u000e", "vZKkx");
      I[23 ^ 68] = I("-&\u0013\u000f\f\u0011*\u0013\u000f\u00067", "NNvlg");
   }
}

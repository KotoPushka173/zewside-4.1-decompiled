package net.minecraft.block;

public class BlockYellowFlower extends BlockFlower {
   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public BlockFlower.EnumFlowerColor getBlockType() {
      return BlockFlower.EnumFlowerColor.YELLOW;
   }
}

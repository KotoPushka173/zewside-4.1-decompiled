package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRedstoneOre extends Block {
   // $FF: synthetic field
   private final boolean isOn;
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   private static void I() {
      I = new String[91 ^ 68];
      I["".length()] = I("漉", "ChNEg");
      I[" ".length()] = I("暯憯喻則岭", "SYLMI");
      I["  ".length()] = I("悡啔", "ADZrn");
      I["   ".length()] = I("傩床昡淯", "bxKAx");
      I[88 ^ 92] = I("槺", "zsLej");
      I[84 ^ 81] = I("懡廵", "uMNcJ");
      I[36 ^ 34] = I("炜厥旦拌", "cqygJ");
      I[134 ^ 129] = I("塅煪欛晹", "sJDAl");
      I[39 ^ 47] = I("堀倂唱屃扙", "irSOh");
      I[191 ^ 182] = I("懜澪", "mEvrL");
      I[41 ^ 35] = I("洅書岹仈", "JzHvz");
      I[84 ^ 95] = I("吟壝", "oZXEW");
      I[46 ^ 34] = I("峸啅崀抒槤", "fGrGY");
      I[73 ^ 68] = I("恵梾淹樍", "HuoZo");
      I[116 ^ 122] = I("涬", "xUWnq");
      I[82 ^ 93] = I("棾惎倬", "qrSrV");
      I[93 ^ 77] = I("伆泲嶾", "lSxmF");
      I[162 ^ 179] = I("夳寪", "sZsIr");
      I[150 ^ 132] = I("汦智", "qCxrC");
      I[39 ^ 52] = I("帞淙", "JLvKB");
      I[169 ^ 189] = I("棔壹", "aXBbJ");
      I[174 ^ 187] = I("塅僭瀗", "UxzOc");
      I[114 ^ 100] = I("旿峦殧掶", "zrPwV");
      I[115 ^ 100] = I("嬇塬亘婥", "EaZBj");
      I[87 ^ 79] = I("漆噪借凷壊", "crkVy");
      I[25 ^ 0] = I("憐暒", "QAEQc");
      I[13 ^ 23] = I("楃漣", "EczbD");
      I[3 ^ 24] = I("奷件", "WXgQc");
      I[217 ^ 197] = I("旍戦", "KxkTg");
      I[2 ^ 31] = I("椦于儦", "sVbcU");
      I[149 ^ 139] = I("晖仈換嗈寬", "IkEbz");
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.REDSTONE;
   }

   public int tickRate(World var1) {
      return 188 ^ 162;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (this == Blocks.LIT_REDSTONE_ORE) {
         var1.setBlockState(var2, Blocks.REDSTONE_ORE.getDefaultState());
         I["   ".length()].length();
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[117 ^ 108];
      String var10001 = I[182 ^ 172];
      String var10002 = I[41 ^ 50];
      var10001 = I[114 ^ 110];
      I[181 ^ 168].length();
      I[143 ^ 145].length();
      return new ItemStack(Item.getItemFromBlock(Blocks.REDSTONE_ORE), " ".length(), this.damageDropped(var3));
   }

   public int quantityDropped(Random var1) {
      return (59 ^ 63) + var1.nextInt("  ".length());
   }

   private void spawnParticles(World var1, BlockPos var2) {
      Random var3 = var1.rand;
      double var4 = 0.0625D;
      int var6 = "".length();

      do {
         if (var6 >= (160 ^ 166)) {
            return;
         }

         double var7 = (double)((float)var2.getX() + var3.nextFloat());
         double var9 = (double)((float)var2.getY() + var3.nextFloat());
         double var11 = (double)((float)var2.getZ() + var3.nextFloat());
         if (var6 == 0 && !var1.getBlockState(var2.up()).isOpaqueCube()) {
            var9 = (double)var2.getY() + 0.0625D + 1.0D;
         }

         double var10000;
         if (var6 == " ".length() && !var1.getBlockState(var2.down()).isOpaqueCube()) {
            var10000 = (double)var2.getY();
            I[128 ^ 132].length();
            I[55 ^ 50].length();
            I[176 ^ 182].length();
            I[75 ^ 76].length();
            I[46 ^ 38].length();
            var9 = var10000 - 0.0625D;
         }

         if (var6 == "  ".length() && !var1.getBlockState(var2.south()).isOpaqueCube()) {
            var11 = (double)var2.getZ() + 0.0625D + 1.0D;
         }

         if (var6 == "   ".length() && !var1.getBlockState(var2.north()).isOpaqueCube()) {
            var10000 = (double)var2.getZ();
            I[5 ^ 12].length();
            I[105 ^ 99].length();
            I[39 ^ 44].length();
            I[100 ^ 104].length();
            var11 = var10000 - 0.0625D;
         }

         if (var6 == (93 ^ 89) && !var1.getBlockState(var2.east()).isOpaqueCube()) {
            var7 = (double)var2.getX() + 0.0625D + 1.0D;
         }

         if (var6 == (101 ^ 96) && !var1.getBlockState(var2.west()).isOpaqueCube()) {
            var10000 = (double)var2.getX();
            I[44 ^ 33].length();
            I[45 ^ 35].length();
            I[69 ^ 74].length();
            I[131 ^ 147].length();
            var7 = var10000 - 0.0625D;
         }

         if (var7 < (double)var2.getX() || var7 > (double)(var2.getX() + " ".length()) || var9 < 0.0D || var9 > (double)(var2.getY() + " ".length()) || var11 < (double)var2.getZ() || var11 > (double)(var2.getZ() + " ".length())) {
            var1.spawnParticle(EnumParticleTypes.REDSTONE, var7, var9, var11, 0.0D, 0.0D, 0.0D);
         }

         ++var6;
         "".length();
      } while(0 >= -1);

      throw null;
   }

   public BlockRedstoneOre(boolean var1) {
      super(Material.ROCK);
      if (var1) {
         this.setTickRandomly((boolean)" ".length());
      }

      this.isOn = var1;
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      super.dropBlockAsItemWithChance(var1, var2, var3, var4, var5);
      if (this.getItemDropped(var3, var1.rand, var5) != Item.getItemFromBlock(this)) {
         int var6 = " ".length() + var1.rand.nextInt(72 ^ 77);
         this.dropXpOnBlockBreak(var1, var2, var6);
      }

   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I[169 ^ 184];
      String var10001 = I[128 ^ 146];
      String var10002 = I[80 ^ 67];
      var10001 = I[164 ^ 176];
      I[19 ^ 6].length();
      I[110 ^ 120].length();
      I[93 ^ 74].length();
      I[22 ^ 14].length();
      return new ItemStack(Blocks.REDSTONE_ORE);
   }

   private void activate(World var1, BlockPos var2) {
      this.spawnParticles(var1, var2);
      if (this == Blocks.REDSTONE_ORE) {
         var1.setBlockState(var2, Blocks.LIT_REDSTONE_ORE.getDefaultState());
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
      }

   }

   public void onBlockClicked(World var1, BlockPos var2, EntityPlayer var3) {
      this.activate(var1, var2);
      super.onBlockClicked(var1, var2, var3);
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      if (this.isOn) {
         this.spawnParticles(var2, var3);
      }

   }

   public int quantityDroppedWithBonus(int var1, Random var2) {
      return this.quantityDropped(var2) + var2.nextInt(var1 + " ".length());
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      this.activate(var1, var2);
      return super.onBlockActivated(var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   public void onEntityWalk(World var1, BlockPos var2, Entity var3) {
      this.activate(var1, var2);
      super.onEntityWalk(var1, var2, var3);
   }
}

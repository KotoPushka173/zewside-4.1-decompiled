package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockHugeMushroom extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockHugeMushroom.EnumType> VARIANT;
   // $FF: synthetic field
   private final Block smallBlock;

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState();
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         switch(null.$SwitchMap$net$minecraft$block$BlockHugeMushroom$EnumType[((BlockHugeMushroom.EnumType)var1.getValue(VARIANT)).ordinal()]) {
         case 3:
            "".length();
            if (0 >= 3) {
               throw null;
            }
            break;
         case 4:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_EAST);
         case 5:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH);
         case 6:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_WEST);
         case 7:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.EAST);
         case 8:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.WEST);
         case 9:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_EAST);
         case 10:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH);
         case 11:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_WEST);
         default:
            return var1;
         }
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockHugeMushroom$EnumType[((BlockHugeMushroom.EnumType)var1.getValue(VARIANT)).ordinal()]) {
         case 3:
            "".length();
            if (false) {
               throw null;
            }
            break;
         case 4:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_WEST);
         case 5:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.WEST);
         case 6:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_WEST);
         case 7:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH);
         case 8:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH);
         case 9:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_EAST);
         case 10:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.EAST);
         case 11:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_EAST);
         default:
            return var1;
         }
      case 3:
         switch(null.$SwitchMap$net$minecraft$block$BlockHugeMushroom$EnumType[((BlockHugeMushroom.EnumType)var1.getValue(VARIANT)).ordinal()]) {
         case 3:
            "".length();
            if (4 <= 1) {
               throw null;
            }
            break;
         case 4:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_EAST);
         case 5:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.EAST);
         case 6:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_EAST);
         case 7:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH);
         case 8:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH);
         case 9:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_WEST);
         case 10:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.WEST);
         case 11:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_WEST);
         default:
            return var1;
         }
      default:
         return var1;
      }
   }

   private static void I() {
      I = new String[157 ^ 138];
      I["".length()] = I("俴", "ldQsP");
      I[" ".length()] = I("扵偩", "pGiSz");
      I["  ".length()] = I("奝倴", "ANKwY");
      I["   ".length()] = I("恷浳", "OAiQB");
      I[184 ^ 188] = I("嶾尗", "aciiM");
      I[132 ^ 129] = I("擿儵暆", "PIxOj");
      I[73 ^ 79] = I("妝欲", "NiqYT");
      I[165 ^ 162] = I("圊撋岩煃伩", "lOcgw");
      I[203 ^ 195] = I("檻弉煎", "zqsjJ");
      I[48 ^ 57] = I("呯柘", "cVUvq");
      I[132 ^ 142] = I("凩帺", "mJnIG");
      I[6 ^ 13] = I("橕寻", "LLmBl");
      I[44 ^ 32] = I("忛瀴", "LLYWb");
      I[174 ^ 163] = I("噻昼", "HWoWZ");
      I[75 ^ 69] = I("圸濗", "HiZWN");
      I[155 ^ 148] = I("喦暧", "JhMXn");
      I[155 ^ 139] = I("曛娍", "Yoqoz");
      I[101 ^ 116] = I("浂厡幨垚幋", "DQidD");
      I[120 ^ 106] = I("櫦", "TdQPS");
      I[179 ^ 160] = I("暆劥渣", "hUBjh");
      I[83 ^ 71] = I("任曤梹徇撥", "GUBsw");
      I[93 ^ 72] = I("惗嚳墖", "CWRfK");
      I[80 ^ 70] = I("=)\u0003\u000b\u000b%<", "KHqbj");
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$block$BlockHugeMushroom$EnumType[((BlockHugeMushroom.EnumType)var1.getValue(VARIANT)).ordinal()]) {
      case 1:
         return MapColor.CLOTH;
      case 2:
         return MapColor.SAND;
      case 3:
         return MapColor.SAND;
      default:
         return super.getMapColor(var1, var2, var3);
      }
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      BlockHugeMushroom.EnumType var3 = (BlockHugeMushroom.EnumType)var1.getValue(VARIANT);
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         switch(null.$SwitchMap$net$minecraft$block$BlockHugeMushroom$EnumType[var3.ordinal()]) {
         case 4:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_WEST);
         case 5:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH);
         case 6:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_EAST);
         case 7:
         case 8:
         default:
            return super.withMirror(var1, var2);
         case 9:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_WEST);
         case 10:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH);
         case 11:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_EAST);
         }
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockHugeMushroom$EnumType[var3.ordinal()]) {
         case 4:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_EAST);
         case 5:
         case 10:
         default:
            "".length();
            if (3 == 1) {
               throw null;
            }
            break;
         case 6:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.NORTH_WEST);
         case 7:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.EAST);
         case 8:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.WEST);
         case 9:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_EAST);
         case 11:
            return var1.withProperty(VARIANT, BlockHugeMushroom.EnumType.SOUTH_WEST);
         }
      default:
         return super.withMirror(var1, var2);
      }
   }

   public BlockHugeMushroom(Material var1, MapColor var2, Block var3) {
      super(var1, var2);
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockHugeMushroom.EnumType.ALL_OUTSIDE));
      this.smallBlock = var3;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 0);

      throw null;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[196 ^ 192];
      I[49 ^ 52].length();
      I[106 ^ 108].length();
      I[100 ^ 99].length();
      I[61 ^ 53].length();
      return new ItemStack(this.smallBlock);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(this.smallBlock);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[67 ^ 74];
      String var10001 = I[165 ^ 175];
      String var10002 = I[174 ^ 165];
      var10001 = I[15 ^ 3];
      var10000 = I[130 ^ 143];
      var10001 = I[35 ^ 45];
      var10002 = I[172 ^ 163];
      var10001 = I[2 ^ 18];
      I[86 ^ 71].length();
      I[211 ^ 193].length();
      I[159 ^ 140].length();
      I[31 ^ 11].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[174 ^ 187].length();
      var10003["".length()] = VARIANT;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockHugeMushroom.EnumType.byMetadata(var1));
   }

   public int quantityDropped(Random var1) {
      int var10000 = "".length();
      int var10001 = var1.nextInt(51 ^ 57);
      int var10002 = 3 ^ 4;
      I["".length()].length();
      return Math.max(var10000, var10001 - var10002);
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockHugeMushroom.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[162 ^ 180], BlockHugeMushroom.EnumType.class);
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      SOUTH_WEST,
      // $FF: synthetic field
      SOUTH;

      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      ALL_INSIDE,
      // $FF: synthetic field
      EAST,
      // $FF: synthetic field
      WEST,
      // $FF: synthetic field
      NORTH_EAST,
      // $FF: synthetic field
      SOUTH_EAST,
      // $FF: synthetic field
      ALL_OUTSIDE,
      // $FF: synthetic field
      NORTH_WEST;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      STEM,
      // $FF: synthetic field
      CENTER,
      // $FF: synthetic field
      ALL_STEM,
      // $FF: synthetic field
      NORTH;

      private static void I() {
         I = new String[151 ^ 141];
         I["".length()] = I("&\u00158\u000e\u001c7\r/\t\u0000", "hZjZT");
         I[" ".length()] = I("!;\u0000<.\u0010#\u0017;2", "OTrHF");
         I["  ".length()] = I("\u0016\u0016*#.", "XYxwf");
         I["   ".length()] = I("\n7\"\u00012", "dXPuZ");
         I[83 ^ 87] = I(">\b\u001e9\u0000/\u0002\r>\u001c", "pGLmH");
         I[126 ^ 123] = I("7#\u001e2\u001a\u0006)\r5\u0006", "YLlFr");
         I[22 ^ 16] = I("6\u001c?7", "aYlca");
         I[148 ^ 147] = I("'\u00032:", "PfANS");
         I[144 ^ 152] = I("\r44\"?\u001c", "Nqzvz");
         I[2 ^ 11] = I("!)*\u0000.0", "BLDtK");
         I[56 ^ 50] = I("\u0007\b\u0012\u001d", "BIAIG");
         I[79 ^ 68] = I("5)\u0002\u001b", "PHqoD");
         I[35 ^ 47] = I("\u0004\u0019\u0018%-\b\u0001\b\"1", "WVMqe");
         I[97 ^ 108] = I("\u001091\f\u0001<!!\u000b\u001d", "cVDxi");
         I[178 ^ 188] = I("\u0007:9;,", "Tulod");
         I[1 ^ 14] = I("1>\u0000\u001d\u001e", "BQuiv");
         I[94 ^ 78] = I("\u0014\u00060\"\u000f\u0018\f$%\u0013", "GIevG");
         I[67 ^ 82] = I(" -%1\u0003\f'16\u001f", "SBPEk");
         I[61 ^ 47] = I("\u0002!\u0014(", "QuQeT");
         I[45 ^ 62] = I("1%\u0016<", "BQsQK");
         I[46 ^ 58] = I("\u0018)\u0014)\u0001\u00176\u00112\r", "YeXvH");
         I[21 ^ 0] = I("%\"$\u000b(*=!0$", "DNHTA");
         I[106 ^ 124] = I("0!-9#$92/(4", "qmafl");
         I[181 ^ 162] = I("%)\b\f$11\u0017:/!", "DEdSK");
         I[73 ^ 81] = I("\b!\u0004,\u001c\u001d(\u0005", "ImHsO");
         I[45 ^ 52] = I("\u0015/\u001f<\u0000\u0000&\u001e", "tCscs");
      }

      public int getMetadata() {
         return this.meta;
      }

      public String getName() {
         return this.name;
      }

      public String toString() {
         return this.name;
      }

      public static BlockHugeMushroom.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         BlockHugeMushroom.EnumType var1 = META_LOOKUP[var0];
         BlockHugeMushroom.EnumType var10000;
         if (var1 == null) {
            var10000 = META_LOOKUP["".length()];
            "".length();
            if (1 <= -1) {
               throw null;
            }
         } else {
            var10000 = var1;
         }

         return var10000;
      }

      static {
         I();
         NORTH_WEST = new BlockHugeMushroom.EnumType(I["".length()], "".length(), " ".length(), I[" ".length()]);
         NORTH = new BlockHugeMushroom.EnumType(I["  ".length()], " ".length(), "  ".length(), I["   ".length()]);
         NORTH_EAST = new BlockHugeMushroom.EnumType(I[61 ^ 57], "  ".length(), "   ".length(), I[8 ^ 13]);
         WEST = new BlockHugeMushroom.EnumType(I[173 ^ 171], "   ".length(), 138 ^ 142, I[20 ^ 19]);
         CENTER = new BlockHugeMushroom.EnumType(I[183 ^ 191], 42 ^ 46, 170 ^ 175, I[125 ^ 116]);
         EAST = new BlockHugeMushroom.EnumType(I[17 ^ 27], 161 ^ 164, 107 ^ 109, I[109 ^ 102]);
         SOUTH_WEST = new BlockHugeMushroom.EnumType(I[180 ^ 184], 57 ^ 63, 124 ^ 123, I[37 ^ 40]);
         SOUTH = new BlockHugeMushroom.EnumType(I[90 ^ 84], 72 ^ 79, 5 ^ 13, I[133 ^ 138]);
         SOUTH_EAST = new BlockHugeMushroom.EnumType(I[163 ^ 179], 15 ^ 7, 151 ^ 158, I[209 ^ 192]);
         STEM = new BlockHugeMushroom.EnumType(I[21 ^ 7], 108 ^ 101, 101 ^ 111, I[122 ^ 105]);
         ALL_INSIDE = new BlockHugeMushroom.EnumType(I[213 ^ 193], 94 ^ 84, "".length(), I[134 ^ 147]);
         ALL_OUTSIDE = new BlockHugeMushroom.EnumType(I[37 ^ 51], 45 ^ 38, 70 ^ 72, I[24 ^ 15]);
         ALL_STEM = new BlockHugeMushroom.EnumType(I[180 ^ 172], 106 ^ 102, 34 ^ 45, I[86 ^ 79]);
         BlockHugeMushroom.EnumType[] var10000 = new BlockHugeMushroom.EnumType[10 ^ 7];
         var10000["".length()] = NORTH_WEST;
         var10000[" ".length()] = NORTH;
         var10000["  ".length()] = NORTH_EAST;
         var10000["   ".length()] = WEST;
         var10000[65 ^ 69] = CENTER;
         var10000[118 ^ 115] = EAST;
         var10000[181 ^ 179] = SOUTH_WEST;
         var10000[5 ^ 2] = SOUTH;
         var10000[36 ^ 44] = SOUTH_EAST;
         var10000[123 ^ 114] = STEM;
         var10000[99 ^ 105] = ALL_INSIDE;
         var10000[107 ^ 96] = ALL_OUTSIDE;
         var10000[78 ^ 66] = ALL_STEM;
         BlockHugeMushroom.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockHugeMushroom.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(3 >= 3);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 == 4);

         throw null;
      }

      private EnumType(int var3, String var4) {
         this.meta = var3;
         this.name = var4;
      }
   }
}

package net.minecraft.network.play.server;

import com.google.common.collect.Lists;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;

public class SPacketChunkData implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private List<NBTTagCompound> tileEntityTags;
   // $FF: synthetic field
   private int availableSections;
   // $FF: synthetic field
   private boolean loadChunk;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int chunkZ;
   // $FF: synthetic field
   private int chunkX;
   // $FF: synthetic field
   private byte[] buffer;

   private static void I() {
      I = new String[16 ^ 36];
      I["".length()] = I("忶愘", "cBVQH");
      I[" ".length()] = I("匫槿", "tdBPH");
      I["  ".length()] = I("掲灱", "NgfoQ");
      I["   ".length()] = I("姇欯", "gHFsH");
      I[1 ^ 5] = I("巙", "QEdIL");
      I[185 ^ 188] = I("根侾", "cmMUB");
      I[91 ^ 93] = I("%'4\u00142F\u001f \u00192\u0003;a\u000e+\u001f&/\u001dy\u0012 a\u001b5\n \"\u001b-\u0003o5\u00156F\"4\u00191F\"$\u00176\u00146a\u00157F=$\u001b=H", "fOAzY");
      I[186 ^ 189] = I("晱唪兀", "FswWR");
      I[95 ^ 87] = I("婰巸劲栙庯", "Lskhi");
      I[137 ^ 128] = I("串懵枻", "hOUGF");
      I[86 ^ 92] = I("毆埁浟", "RLmjm");
      I[19 ^ 24] = I("垒様檃澉", "XwMWQ");
      I[202 ^ 198] = I("孠撳哸", "ruulo");
      I[106 ^ 103] = I("僵旴儒揓", "ClBhE");
      I[123 ^ 117] = I("彄", "jXaTJ");
      I[58 ^ 53] = I("涫", "uTAMn");
      I[210 ^ 194] = I("帚", "fHWDU");
      I[98 ^ 115] = I("娱圕乽", "WRKXr");
      I[38 ^ 52] = I("塓勨柜", "OGHYo");
      I[151 ^ 132] = I("亰檛", "eGqHi");
      I[111 ^ 123] = I("椫潮峙可塖", "kOkcR");
      I[169 ^ 188] = I("溠巴", "rhBCa");
      I[113 ^ 103] = I("喎恩伖", "rSoVi");
      I[159 ^ 136] = I("哔妧", "PBoRx");
      I[101 ^ 125] = I("揄", "zStlj");
      I[130 ^ 155] = I("揞时倱", "KJUXG");
      I[163 ^ 185] = I("慾", "iuxwI");
      I[51 ^ 40] = I("撚來兒摓怜", "DkKig");
      I[85 ^ 73] = I("帇佨愞瀠", "AiKNG");
      I[89 ^ 68] = I("檯敛", "tljqp");
      I[30 ^ 0] = I("摪懂庄孽", "aNWAl");
      I[120 ^ 103] = I("瀣剼斌懏塔", "YMVgg");
      I[184 ^ 152] = I("灞濸", "PDyPH");
      I[167 ^ 134] = I("斴", "slpba");
      I[76 ^ 110] = I("仢嶲幰媸", "iioAK");
      I[117 ^ 86] = I("源冶", "LNFwL");
      I[116 ^ 80] = I("枝浥", "apCKS");
      I[4 ^ 33] = I("刱憺", "juhpP");
      I[74 ^ 108] = I("派哨", "SByRo");
      I[92 ^ 123] = I("殃劜", "DWuwh");
      I[25 ^ 49] = I("嘳啮", "aAYGT");
      I[155 ^ 178] = I("湥", "sDkhm");
      I[72 ^ 98] = I("侟彊", "ZLZcT");
      I[50 ^ 25] = I("尕", "rAFqa");
      I[189 ^ 145] = I("涕煤拲嵜瀏", "qWPsE");
      I[8 ^ 37] = I("動孱", "UakKJ");
      I[74 ^ 100] = I("揶吝倴凙", "MYsTE");
      I[4 ^ 43] = I("杄俅懍懊朲", "CQDAB");
      I[27 ^ 43] = I("榖涕", "KTeDk");
      I[73 ^ 120] = I("壴圆気", "XNNlD");
      I[109 ^ 95] = I("匎歔", "rlYuW");
      I[149 ^ 166] = I("嘄", "MlsqY");
   }

   public SPacketChunkData(Chunk var1, int var2) {
      this.chunkX = var1.x;
      this.chunkZ = var1.z;
      int var10001;
      if (var2 == '\uebb6' + 'ꠃ' - 'ﰲ' + 26744) {
         var10001 = " ".length();
         "".length();
         if (4 <= 1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.loadChunk = (boolean)var10001;
      boolean var3 = var1.getWorld().provider.isNether();
      this.buffer = new byte[this.calculateChunkSize(var1, var3, var2)];
      this.availableSections = this.extractChunkData(new PacketBuffer(this.getWriteBuffer()), var1, var3, var2);
      this.tileEntityTags = Lists.newArrayList();
      Iterator var4 = var1.getTileEntityMap().entrySet().iterator();

      do {
         if (!var4.hasNext()) {
            return;
         }

         Entry var5 = (Entry)var4.next();
         BlockPos var6 = (BlockPos)var5.getKey();
         TileEntity var7 = (TileEntity)var5.getValue();
         int var8 = var6.getY() >> (2 ^ 6);
         if (this.doChunkLoad() || (var2 & " ".length() << var8) != 0) {
            NBTTagCompound var9 = var7.getUpdateTag();
            this.tileEntityTags.add(var9);
         }

         "".length();
      } while(2 == 2);

      throw null;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeInt(this.chunkX);
      I[50 ^ 61].length();
      I[122 ^ 106].length();
      I[86 ^ 71].length();
      var1.writeInt(this.chunkZ);
      I[36 ^ 54].length();
      I[118 ^ 101].length();
      I[73 ^ 93].length();
      var1.writeBoolean(this.loadChunk);
      I[175 ^ 186].length();
      I[86 ^ 64].length();
      I[32 ^ 55].length();
      I[38 ^ 62].length();
      var1.writeVarIntToBuffer(this.availableSections);
      I[219 ^ 194].length();
      I[18 ^ 8].length();
      var1.writeVarIntToBuffer(this.buffer.length);
      I[12 ^ 23].length();
      var1.writeBytes(this.buffer);
      I[82 ^ 78].length();
      I[158 ^ 131].length();
      I[179 ^ 173].length();
      var1.writeVarIntToBuffer(this.tileEntityTags.size());
      I[175 ^ 176].length();
      I[53 ^ 21].length();
      I[167 ^ 134].length();
      I[151 ^ 181].length();
      Iterator var2 = this.tileEntityTags.iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         NBTTagCompound var3 = (NBTTagCompound)var2.next();
         var1.writeNBTTagCompoundToBuffer(var3);
         I[119 ^ 84].length();
         I[74 ^ 110].length();
         "".length();
      } while(0 < 2);

      throw null;
   }

   public int getChunkZ() {
      return this.chunkZ;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      this.chunkX = var1.readInt();
      this.chunkZ = var1.readInt();
      this.loadChunk = var1.readBoolean();
      this.availableSections = var1.readVarIntFromBuffer();
      int var2 = var1.readVarIntFromBuffer();
      if (var2 > 838886 + 497947 - 1050817 + 1811136) {
         I[36 ^ 32].length();
         I[169 ^ 172].length();
         RuntimeException var5 = new RuntimeException(I[176 ^ 182]);
         I[189 ^ 186].length();
         I[86 ^ 94].length();
         I[35 ^ 42].length();
         throw var5;
      } else {
         this.buffer = new byte[var2];
         var1.readBytes(this.buffer);
         I[164 ^ 174].length();
         int var3 = var1.readVarIntFromBuffer();
         this.tileEntityTags = Lists.newArrayList();
         int var4 = "".length();

         do {
            if (var4 >= var3) {
               return;
            }

            this.tileEntityTags.add(var1.readNBTTagCompoundFromBuffer());
            I[13 ^ 6].length();
            I[11 ^ 7].length();
            I[182 ^ 187].length();
            I[170 ^ 164].length();
            ++var4;
            "".length();
         } while(2 > 1);

         throw null;
      }
   }

   public List<NBTTagCompound> getTileEntityTags() {
      return this.tileEntityTags;
   }

   protected int calculateChunkSize(Chunk var1, boolean var2, int var3) {
      int var4 = "".length();
      ExtendedBlockStorage[] var5 = var1.getBlockStorageArray();
      int var6 = "".length();
      int var7 = var5.length;

      do {
         if (var6 >= var7) {
            if (this.doChunkLoad()) {
               var4 += var1.getBiomeArray().length;
            }

            return var4;
         }

         ExtendedBlockStorage var8 = var5[var6];
         if (var8 != Chunk.NULL_BLOCK_STORAGE && (!this.doChunkLoad() || !var8.isEmpty()) && (var3 & " ".length() << var6) != 0) {
            var4 += var8.getData().getSerializedSize();
            var4 += var8.getBlocklightArray().getData().length;
            if (var2) {
               var4 += var8.getSkylightArray().getData().length;
            }
         }

         ++var6;
         "".length();
      } while(-1 < 2);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleChunkData(this);
   }

   public SPacketChunkData() {
   }

   public int getChunkX() {
      return this.chunkX;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   static {
      I();
   }

   private ByteBuf getWriteBuffer() {
      ByteBuf var1 = Unpooled.wrappedBuffer(this.buffer);
      var1.writerIndex("".length());
      I[116 ^ 95].length();
      I[73 ^ 101].length();
      I[234 ^ 199].length();
      return var1;
   }

   public boolean doChunkLoad() {
      return this.loadChunk;
   }

   public int getExtractedSize() {
      return this.availableSections;
   }

   public PacketBuffer getReadBuffer() {
      String var10000 = I[125 ^ 88];
      String var10001 = I[4 ^ 34];
      String var10002 = I[230 ^ 193];
      var10001 = I[40 ^ 0];
      I[31 ^ 54].length();
      I[122 ^ 80].length();
      return new PacketBuffer(Unpooled.wrappedBuffer(this.buffer));
   }

   public int extractChunkData(PacketBuffer var1, Chunk var2, boolean var3, int var4) {
      int var5 = "".length();
      ExtendedBlockStorage[] var6 = var2.getBlockStorageArray();
      int var7 = "".length();
      int var8 = var6.length;

      do {
         if (var7 >= var8) {
            if (this.doChunkLoad()) {
               var1.writeBytes(var2.getBiomeArray());
               I[149 ^ 167].length();
               I[14 ^ 61].length();
            }

            return var5;
         }

         ExtendedBlockStorage var9 = var6[var7];
         if (var9 != Chunk.NULL_BLOCK_STORAGE && (!this.doChunkLoad() || !var9.isEmpty()) && (var4 & " ".length() << var7) != 0) {
            var5 |= " ".length() << var7;
            var9.getData().write(var1);
            var1.writeBytes(var9.getBlocklightArray().getData());
            I[128 ^ 174].length();
            if (var3) {
               var1.writeBytes(var9.getSkylightArray().getData());
               I[89 ^ 118].length();
               I[27 ^ 43].length();
               I[187 ^ 138].length();
            }
         }

         ++var7;
         "".length();
      } while(3 < 4);

      throw null;
   }
}

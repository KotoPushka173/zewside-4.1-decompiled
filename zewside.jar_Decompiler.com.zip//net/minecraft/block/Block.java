package net.minecraft.block;

import com.google.common.collect.Sets;
import com.google.common.collect.UnmodifiableIterator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import javax.annotation.Nullable;
import me.zewside.client.ZewSide;
import me.zewside.client.feature.impl.player.AutoTool;
import me.zewside.client.feature.impl.player.NoInteract;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ObjectIntIdentityMap;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.registry.RegistryNamespacedDefaultedByKey;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.Explosion;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class Block {
   // $FF: synthetic field
   protected boolean enableStats;
   // $FF: synthetic field
   private static final ResourceLocation AIR_ID;
   // $FF: synthetic field
   protected boolean isBlockContainer;
   // $FF: synthetic field
   private CreativeTabs displayOnCreativeTab;
   // $FF: synthetic field
   public float slipperiness;
   // $FF: synthetic field
   protected final BlockStateContainer blockState;
   // $FF: synthetic field
   protected int lightOpacity;
   // $FF: synthetic field
   protected boolean needsRandomTick;
   // $FF: synthetic field
   protected float blockHardness;
   // $FF: synthetic field
   protected SoundType blockSoundType;
   // $FF: synthetic field
   public float blockParticleGravity;
   // $FF: synthetic field
   public static final ObjectIntIdentityMap<IBlockState> BLOCK_STATE_IDS;
   // $FF: synthetic field
   protected boolean useNeighborBrightness;
   // $FF: synthetic field
   protected boolean fullBlock;
   // $FF: synthetic field
   public static final RegistryNamespacedDefaultedByKey<ResourceLocation, Block> REGISTRY;
   // $FF: synthetic field
   protected final MapColor blockMapColor;
   // $FF: synthetic field
   protected int lightValue;
   // $FF: synthetic field
   private IBlockState defaultBlockState;
   // $FF: synthetic field
   protected final Material blockMaterial;
   // $FF: synthetic field
   @Nullable
   public static final AxisAlignedBB NULL_AABB;
   // $FF: synthetic field
   protected boolean translucent;
   // $FF: synthetic field
   protected float blockResistance;
   // $FF: synthetic field
   private String unlocalizedName;
   // $FF: synthetic field
   public static final AxisAlignedBB FULL_BLOCK_AABB;
   // $FF: synthetic field
   private static final String[] I;

   private static void I() {
      I = new String[718 + 713 - 664 + 1512];
      I["".length()] = I("棈姈", "JIYBw");
      I[" ".length()] = I("浱殛", "xVdEO");
      I["  ".length()] = I("朁拼", "hqEtq");
      I["   ".length()] = I("屳淭", "VLtav");
      I[102 ^ 98] = I("无漳幺撷", "JQSeH");
      I[37 ^ 32] = I("渽圜孯", "bhgfB");
      I[193 ^ 199] = I("恽他溱嶧澆", "JfqQA");
      I[189 ^ 186] = I("攲毠咥", "WJFKT");
      I[201 ^ 193] = I("堑娘", "McdGT");
      I[34 ^ 43] = I("屆寺", "ZkBnK");
      I[104 ^ 98] = I("潻坻", "hmbJA");
      I[65 ^ 74] = I("昣井", "PoIMt");
      I[105 ^ 101] = I("埠圫", "ksoNo");
      I[7 ^ 10] = I("椦恵", "jkQSE");
      I[135 ^ 137] = I("敂櫫", "XFcGl");
      I[18 ^ 29] = I("偬弐", "AnAKm");
      I[117 ^ 101] = I("灷埒娲潐孈", "gEmcx");
      I[140 ^ 157] = I("旓惆湱幙嬢", "KxaVs");
      I[154 ^ 136] = I("喍歭", "yDFIn");
      I[75 ^ 88] = I("涺憇朓", "yumTv");
      I[99 ^ 119] = I("咏媯咽曥", "cMETS");
      I[12 ^ 25] = I("(,-}\u001dL(-5\u001eL+,-I\u0018,c9\u0006\u00025&(\u001dL", "lCCZi");
      I[11 ^ 29] = I("w\u0011\u0006\u0010\u001cw\u001a\t\u0007\u0018w\u0017\u0006\u0007\u0016y]I", "Wsgsw");
      I[26 ^ 13] = I("嚧殴", "nITLc");
      I[7 ^ 31] = I("剰", "FKqhd");
      I[116 ^ 109] = I("偦淟妣", "dwacQ");
      I[36 ^ 62] = I("嘣滇", "JNDPB");
      I[97 ^ 122] = I("慓亴嶞浵", "NNojm");
      I[186 ^ 166] = I("敁", "wnqnl");
      I[97 ^ 124] = I("普楅婪嶐拒", "ZbgrD");
      I[146 ^ 140] = I("府濉柕刕住", "icnLQ");
      I[167 ^ 184] = I("恙嫃", "DkDwy");
      I[54 ^ 22] = I("彨偫", "iCzYW");
      I[22 ^ 55] = I("坱毺", "fVrYr");
      I[174 ^ 140] = I("哧烰", "kEhnf");
      I[58 ^ 25] = I("渧剖呑泻柄", "wpYEm");
      I[61 ^ 25] = I("孉澩岎冉", "sAUSh");
      I[57 ^ 28] = I("洒叺娎", "mtXXu");
      I[225 ^ 199] = I("勱匍毟捄孇", "uQoWU");
      I[0 ^ 39] = I("濺攤", "clBdS");
      I[74 ^ 98] = I("亂堰", "tvpdk");
      I[38 ^ 15] = I("揷刀", "WIeGc");
      I[181 ^ 159] = I("嗀灵", "qDLhv");
      I[77 ^ 102] = I("/\u0006384.-\u0015>(8", "KigQX");
      I[135 ^ 171] = I("垀墑渮匹卸", "OOgyb");
      I[94 ^ 115] = I("淨欰", "TkvpF");
      I[44 ^ 2] = I("噾", "hFTDS");
      I[82 ^ 125] = I("孓擋", "ZPfKl");
      I[85 ^ 101] = I("弘渎", "mRNrZ");
      I[5 ^ 52] = I("圩栀", "phUlg");
      I[25 ^ 43] = I("灉株", "FDsKk");
      I[21 ^ 38] = I("\u0006)=\u0013\u0002\u0007\u0002\u001b\u0015\u001e\u0011", "bFizn");
      I[170 ^ 158] = I("嶆潿弮槴垳", "iDszO");
      I[105 ^ 92] = I("妈洦娠幺", "wowZk");
      I[85 ^ 99] = I("処濴媁", "GJMcm");
      I[32 ^ 23] = I("啋", "PJmgJ");
      I[117 ^ 77] = I("涉涘妘柜煏", "AyEhO");
      I[104 ^ 81] = I("叩樋", "wXTvl");
      I[101 ^ 95] = I("柭奖", "iMHPg");
      I[7 ^ 60] = I("亖榼", "aFdCd");
      I[45 ^ 17] = I("滀憷", "wsOuL");
      I[5 ^ 56] = I("懂噵嚔", "sEjki");
      I[5 ^ 59] = I("夋屺彚柬", "QLSrq");
      I[180 ^ 139] = I("涃曀", "fzmVH");
      I[7 ^ 71] = I("宧圹圷", "poMAh");
      I[249 ^ 184] = I("朗僼", "ljuyi");
      I[246 ^ 180] = I("梤唺", "lhQCG");
      I[135 ^ 196] = I("屈坉", "Adunv");
      I[14 ^ 74] = I("匎庶", "qSzAr");
      I[248 ^ 189] = I("忎漋", "qaxQm");
      I[133 ^ 195] = I("夅棎嵜唂憧", "GtrSl");
      I[116 ^ 51] = I("奐扒", "FXNGF");
      I[85 ^ 29] = I("暙烝屲樳", "scLby");
      I[214 ^ 159] = I("嚡攂", "vwIRd");
      I[244 ^ 190] = I("溟杔", "zeKXn");
      I[64 ^ 11] = I("捗澒", "XjPRN");
      I[200 ^ 132] = I("弲涱", "QWZWy");
      I[51 ^ 126] = I("楋", "TuDqO");
      I[6 ^ 72] = I("廏", "wwLmW");
      I[46 ^ 97] = I("察凔恛", "segGk");
      I[41 ^ 121] = I("y\u000f\u0011'4", "WapJQ");
      I[60 ^ 109] = I("垸泔", "ztYev");
      I[67 ^ 17] = I("扼侑", "pxUzz");
      I[121 ^ 42] = I("厫俜", "XMgpD");
      I[214 ^ 130] = I("庠垅", "hyPMv");
      I[69 ^ 16] = I("墊双喺恃推", "FCgvX");
      I[62 ^ 104] = I("\u0010\u0004#0I", "dmOUg");
      I[69 ^ 18] = I("樓枊", "kBjpn");
      I[87 ^ 15] = I("抣杏", "DCMRr");
      I[18 ^ 75] = I("啿朑", "hYnyU");
      I[214 ^ 140] = I("涏厔", "chJDx");
      I[65 ^ 26] = I("喸帤棍涑", "koAVr");
      I[221 ^ 129] = I("居澭唳智汍", "ixFlw");
      I[229 ^ 184] = I("戕巕", "rgSlL");
      I[20 ^ 74] = I("渡媨", "PQczR");
      I[122 ^ 37] = I("搠捪", "HaEsW");
      I[6 ^ 102] = I("圾娰", "ZbfVK");
      I[237 ^ 140] = I("摎", "HPkmQ");
      I[35 ^ 65] = I("榖", "RYuSS");
      I[4 ^ 103] = I("孟受工", "RUwqs");
      I[221 ^ 185] = I("撑椭津価", "jaOgI");
      I[114 ^ 23] = I("勺", "yRZtE");
      I[31 ^ 121] = I("喫匣", "KonqU");
      I[84 ^ 51] = I("根柂", "GXglw");
      I[15 ^ 103] = I("歺梼", "ZQJYn");
      I[110 ^ 7] = I("歁栙", "VPSGW");
      I[96 ^ 10] = I("巬奜愯", "QKQCg");
      I[4 ^ 111] = I("惷溯桷潔", "SXfWP");
      I[0 ^ 108] = I("哯吡", "rlkGx");
      I[29 ^ 112] = I("困弘", "xBZsj");
      I[95 ^ 49] = I("仡愠", "HsJMd");
      I[121 ^ 22] = I("搚佱", "CHMZd");
      I[252 ^ 140] = I("娣媯", "itwzP");
      I[203 ^ 186] = I("抐吶", "KLJSX");
      I[31 ^ 109] = I("廁氥劫枧", "yakSQ");
      I[49 ^ 66] = I("倧憉", "KMSGO");
      I[58 ^ 78] = I("櫽匂屘场婆", "CwckG");
      I[235 ^ 158] = I("唕哷倞帒", "BCTrm");
      I[38 ^ 80] = I("浬摩戧氮", "YMcqO");
      I[244 ^ 131] = I("勉埋", "MxFDj");
      I[50 ^ 74] = I("椌寄", "fWJyZ");
      I[247 ^ 142] = I("摔偌", "RbGun");
      I[83 ^ 41] = I("彁檃", "tUcTx");
      I[58 ^ 65] = I("憾孵", "dQGLf");
      I[30 ^ 98] = I("乄寸", "umEBQ");
      I[221 ^ 160] = I("此塒妫", "pkYlN");
      I[232 ^ 150] = I("嬅図嬒", "ekzPl");
      I[73 + 48 - 11 + 17] = I("囆", "DyhgB");
      I[107 + 33 - 129 + 117] = I("\u0010\u0007:*3)", "RkUIX");
      I[120 + 90 - 110 + 29] = I("$", "YKCDj");
      I[119 + 103 - 194 + 102] = I("敠五", "oVxuk");
      I[3 + 28 - 0 + 100] = I("制烠", "TaMYs");
      I[56 + 95 - 58 + 39] = I("忍僜", "kIuaK");
      I[6 + 105 - 66 + 88] = I("潒搣", "CMoud");
      I[9 + 110 - -12 + 3] = I("嬄怕", "NOLEW");
      I[68 + 75 - 37 + 29] = I("橑忋", "BrzHP");
      I[1 + 35 - -3 + 97] = I("唏殭", "btuqv");
      I[61 + 136 - 155 + 95] = I("捝毩", "UGCOx");
      I[31 + 137 - 106 + 76] = I("濝嚂", "lwlfU");
      I[119 + 1 - 4 + 23] = I("潃庒", "iAXdS");
      I[65 + 133 - 136 + 78] = I("棔毅", "ZqQIS");
      I[53 + 48 - -6 + 34] = I("咝瀾", "HjAvj");
      I[68 + 51 - 37 + 60] = I("咢擫", "XENPX");
      I[83 + 87 - 33 + 6] = I("乳儮", "GCikC");
      I[99 + 66 - 114 + 93] = I("溊沌", "UUoEF");
      I[19 + 56 - 45 + 115] = I("厡哲", "eItpT");
      I[99 + 34 - 91 + 104] = I("呹幘", "tVwpe");
      I[30 + 57 - -55 + 5] = I("戧幠", "QIuQd");
      I[50 + 119 - 137 + 116] = I("慴忻", "IOEpv");
      I[88 + 129 - 178 + 110] = I("廹擻", "etomW");
      I[15 + 35 - 49 + 149] = I("慱啉", "zzsEI");
      I[140 + 127 - 151 + 35] = I("嬿捁", "bkpCG");
      I[18 + 144 - 25 + 15] = I("晿噮", "ieOwf");
      I[127 + 121 - 194 + 99] = I("奶尶", "kjDbg");
      I[127 + 32 - 85 + 80] = I("咫毊", "YIJjI");
      I[143 + 17 - 24 + 19] = I("季汔", "KOZIl");
      I[124 + 117 - 98 + 13] = I("椑弯", "gJGmK");
      I[23 + 89 - 32 + 77] = I("官慐", "lxuYo");
      I[101 + 47 - -6 + 4] = I("斷勯", "BVVnK");
      I[80 + 22 - 22 + 79] = I("刎漥", "gxsCO");
      I[155 + 65 - 158 + 98] = I("値溼", "mGToL");
      I[54 + 131 - 169 + 145] = I("姓壱", "tIcel");
      I[38 + 112 - 78 + 90] = I("冞僕", "OhTXT");
      I[53 + 155 - 163 + 118] = I("嶦寡", "myUDc");
      I[160 + 136 - 244 + 112] = I("卲坹", "AfHmP");
      I[59 + 163 - 102 + 45] = I("晎劵", "GVYjl");
      I[85 + 129 - 108 + 60] = I("櫚嚟", "FUozh");
      I[81 + 158 - 98 + 26] = I("嬮柆", "RxBvd");
      I[42 + 148 - 96 + 74] = I("惦潋", "oppvg");
      I[96 + 38 - 29 + 64] = I("湋啇", "Ekydc");
      I[120 + 104 - 142 + 88] = I("媂旁", "fyqSK");
      I[118 + 118 - 159 + 94] = I("治炽", "xcgxV");
      I[159 + 141 - 275 + 147] = I("拦倂", "MXmFD");
      I[28 + 102 - 62 + 105] = I("斮毂", "fzJUD");
      I[55 + 43 - 36 + 112] = I("朧埕", "vXetx");
      I[161 + 72 - 89 + 31] = I("妮攼", "MboWM");
      I[174 + 35 - 125 + 92] = I("嗛沐", "tabom");
      I[148 + 17 - 97 + 109] = I("濅瀪", "BnKZs");
      I[63 + 120 - 109 + 104] = I("敌垩", "ojdpR");
      I[164 + 70 - 99 + 44] = I("例仏", "VGnIC");
      I[164 + 49 - 209 + 176] = I("瀡朻", "LkCZN");
      I[23 + 45 - -22 + 91] = I("姖咉", "CgUze");
      I[65 + 85 - 22 + 54] = I("剿侴", "xkHNe");
      I[165 + 37 - 144 + 125] = I("凛孂", "huflG");
      I[134 + 136 - 160 + 74] = I("俫櫃", "MypRp");
      I[85 + 75 - 43 + 68] = I("幃恑", "hIURm");
      I[181 + 99 - 155 + 61] = I("咿喜", "UdjmZ");
      I[149 + 111 - 182 + 109] = I("姲戮", "HmTEC");
      I[78 + 85 - 12 + 37] = I("淈囯", "pAwoH");
      I[7 + 65 - -47 + 70] = I("偰椧", "VFbbS");
      I[122 + 174 - 113 + 7] = I("暧吿", "ywjfs");
      I[73 + 19 - 49 + 148] = I("棺渒", "lJGay");
      I[167 + 40 - 115 + 100] = I("欖嬬", "UNcFP");
      I[115 + 127 - 66 + 17] = I("枡垪", "CIhHl");
      I[73 + 176 - 230 + 175] = I("彅倥", "wvotl");
      I[84 + 114 - 172 + 169] = I("唲愼", "tOner");
      I[148 + 178 - 223 + 93] = I("澻拾", "fggDo");
      I[55 + 180 - 87 + 49] = I("嶢刡", "aWYVT");
      I[8 + 158 - 83 + 115] = I("丷喒", "GcqrL");
      I[45 + 163 - 124 + 115] = I("嚹喙", "bMDiE");
      I[141 + 51 - 176 + 184] = I("慘摹", "qHcrI");
      I[86 + 46 - 118 + 187] = I("噽嘙", "kiMCa");
      I[141 + 156 - 189 + 94] = I("氩亂", "YgGiI");
      I[57 + 127 - 103 + 122] = I("曔尕", "dJEuB");
      I[64 + 69 - 15 + 86] = I("惊樂", "nyxgx");
      I[179 + 72 - 231 + 185] = I("烾旋", "cxHZf");
      I[108 + 25 - -30 + 43] = I("厒嶒", "FqZtp");
      I[104 + 147 - 206 + 162] = I("亦屯", "JqWAY");
      I[86 + 80 - 10 + 52] = I("灝壊", "IrvMH");
      I[87 + 123 - 139 + 138] = I("楆堼", "YlqsY");
      I[182 + 84 - 264 + 208] = I("估漍", "sOOJX");
      I[87 + 152 - 208 + 180] = I("刉崥", "UsZek");
      I[81 + 207 - 161 + 85] = I("沸澤", "nlTRK");
      I[141 + 49 - 81 + 104] = I("榷拭", "YtmiA");
      I[177 + 206 - 294 + 125] = I("湸乹", "WJFpI");
      I[195 + 13 - 170 + 177] = I("嘺噒", "LzLxg");
      I[51 + 204 - 230 + 191] = I("呄実", "rzhAc");
      I[42 + 118 - 27 + 84] = I("冯湂", "lvvzp");
      I[96 + 66 - 83 + 139] = I("旇枺", "LbyQR");
      I[28 + 196 - 87 + 82] = I("咊吟", "ofXPO");
      I[93 + 80 - 107 + 154] = I("埤你", "PQCXn");
      I[87 + 203 - 91 + 22] = I("嫻斔", "khjZF");
      I[35 + 106 - -42 + 39] = I("妎润", "KUQQU");
      I[87 + 193 - 272 + 215] = I("怶册", "CxiTx");
      I[134 + 154 - 165 + 101] = I("層俭", "qhncl");
      I[21 + 14 - -24 + 166] = I("欇榻", "mSHOP");
      I[93 + 201 - 119 + 51] = I("戢朎", "cUSDe");
      I[216 + 0 - 145 + 156] = I("扮悎", "OIJBi");
      I[124 + 26 - -72 + 6] = I("烸劊", "KOxjV");
      I[9 + 136 - -54 + 30] = I("浱倩", "nppmo");
      I[136 + 63 - 125 + 156] = I("咫塤", "VjhIS");
      I[104 + 55 - 43 + 115] = I("圍澠", "HItwS");
      I[197 + 146 - 263 + 152] = I("墸屉", "KfOVa");
      I[39 + 96 - -91 + 7] = I("墸姡", "FXWqX");
      I[111 + 37 - 14 + 100] = I("檷攒", "RtdgO");
      I[6 + 37 - -68 + 124] = I("泼峑", "otpQZ");
      I[116 + 34 - 57 + 143] = I("怟享", "zPKDQ");
      I[172 + 39 - 2 + 28] = I("斁懪", "OlPAa");
      I[186 + 181 - 246 + 117] = I("噳咚", "tSSPs");
      I[16 + 119 - -71 + 33] = I("棌卹", "oUGVI");
      I[71 + 85 - -36 + 48] = I("梴幙", "XzHPL");
      I[36 + 207 - 240 + 238] = I("埝佨", "OFnjl");
      I[74 + 77 - 71 + 162] = I("梩掹", "idjvZ");
      I[8 + 236 - 23 + 22] = I("暍奻", "Hjcro");
      I[96 + 4 - -79 + 65] = I("幵楻", "RCKtg");
      I[122 + 3 - -37 + 83] = I("昌洢", "oOSot");
      I[226 + 189 - 307 + 138] = I("拒囘", "XWpkq");
      I[45 + 104 - 31 + 129] = I("庖囬", "JTgRg");
      I[83 + 238 - 269 + 196] = I("嘹氳", "BLSKP");
      I[95 + 129 - -14 + 11] = I("匬土", "IcFWh");
      I[54 + 159 - 162 + 199] = I("呩便", "sUuTH");
      I[7 + 65 - -148 + 31] = I("扰份", "lTFJn");
      I[6 + 14 - -181 + 51] = I("导曾", "tAjGe");
      I[191 + 142 - 285 + 205] = I("娄可", "DKPuJ");
      I[190 + 93 - 248 + 219] = I("憊嶰", "PnKcM");
      I[252 + 107 - 308 + 204] = I("俾溡", "cuFNP");
      I[51 + 39 - -6 + 160] = I("暔嫝", "Nyccg");
      I[210 + 151 - 164 + 60] = I("吰灤", "ynJrP");
      I[228 + 72 - 98 + 56] = I("潅岜", "rHTKz");
      I[237 + 207 - 232 + 47] = I("峫潕", "vtyfE");
      I[158 + 136 - 257 + 223] = I("幢咣", "UnPBm");
      I[189 + 238 - 384 + 218] = I("敂峕", "UMqAE");
      I[196 + 52 - 51 + 65] = I("歾卛", "dFZOs");
      I[178 + 146 - 298 + 237] = I("傃殔", "XSvwJ");
      I[72 + 111 - 76 + 157] = I("朞儠", "vxHZn");
      I[162 + 162 - 104 + 45] = I("埂岽", "GcpJQ");
      I[112 + 21 - -89 + 44] = I("咙柇", "udocF");
      I[127 + 66 - 144 + 218] = I("档夾", "gkBvF");
      I[64 + 180 - 84 + 108] = I("毶唶", "vrEdc");
      I[44 + 92 - -63 + 70] = I("刏啸", "GrTFp");
      I[45 + 28 - -45 + 152] = I("涮智", "ERRfu");
      I[165 + 79 - 4 + 31] = I("挪側", "OMWad");
      I[45 + 159 - 104 + 172] = I("桼吞", "cKKVu");
      I[204 + 187 - 279 + 161] = I("潈椲", "xpWyB");
      I[267 + 24 - 69 + 52] = I("椓嶗", "gBAEy");
      I[104 + 157 - -14 + 0] = I("暪吝", "ErVlp");
      I[174 + 122 - 106 + 86] = I("滍栛", "smgNM");
      I[243 + 40 - 24 + 18] = I("浫潠", "autPY");
      I[228 + 230 - 254 + 74] = I("嶃佾", "MxtjI");
      I[37 + 29 - 32 + 245] = I("娜棈", "ajmyC");
      I[99 + 181 - 132 + 132] = I("厝嫅", "DULBW");
      I[20 + 229 - 45 + 77] = I("泱啛", "ROHGr");
      I[40 + 120 - 19 + 141] = I("廛洨", "TVwxj");
      I[49 + 120 - 0 + 114] = I("撾旙", "GYZOz");
      I[200 + 267 - 361 + 178] = I("垣昶", "MJnDo");
      I[114 + 72 - 176 + 275] = I("军圾", "YyCPM");
      I[20 + 49 - 21 + 238] = I("弋捵", "ZILlt");
      I[241 + 178 - 370 + 238] = I("泘俸", "yfjVs");
      I[270 + 141 - 331 + 208] = I("匔代", "OlTeA");
      I[110 + 145 - 111 + 145] = I("啽旔", "BzOhJ");
      I[178 + 241 - 149 + 20] = I("仈浾", "mcmxf");
      I[228 + 118 - 98 + 43] = I("滈垘", "ugDWd");
      I[35 + 45 - 11 + 223] = I("偧会", "lFKMy");
      I[11 + 247 - 3 + 38] = I("漞尭", "odoTO");
      I[68 + 17 - -36 + 173] = I("妑弐", "bxNuT");
      I[48 + 127 - 166 + 286] = I("吷哿", "NFger");
      I[17 + 254 - 210 + 235] = I("敵汅", "bxOoy");
      I[93 + 166 - 39 + 77] = I("汲堄", "EMaDD");
      I[214 + 83 - 240 + 241] = I("伀嚣", "McdpF");
      I[241 + 66 - 112 + 104] = I("吪廡", "GkOjK");
      I[52 + 83 - -126 + 39] = I("僡咰", "ricxQ");
      I[233 + 107 - 318 + 279] = I("吓摒", "irKyk");
      I[83 + 217 - 193 + 195] = I("橚啛", "lweuj");
      I[268 + 161 - 220 + 94] = I("僊嵰", "Onumr");
      I[52 + 218 - 51 + 85] = I("妘榡", "URGHR");
      I[46 + 243 - 139 + 155] = I("仒仔", "Shzhq");
      I[211 + 117 - 178 + 156] = I("丼堲", "zFiPX");
      I[228 + 18 - 13 + 74] = I("歵俽", "AQWxk");
      I[82 + 268 - 323 + 281] = I("懐槙", "EGgVS");
      I[136 + 201 - 211 + 183] = I("戄桕", "vADRf");
      I[217 + 102 - 128 + 119] = I("姉泵", "MZHIG");
      I[193 + 67 - 125 + 176] = I("擏撂", "mqjHe");
      I[7 + 99 - 22 + 228] = I("囁煘", "BxKBt");
      I[9 + 182 - -83 + 39] = I("叿恻", "NyHjR");
      I[73 + 31 - -83 + 127] = I("呂亭", "fkXWL");
      I[268 + 263 - 448 + 232] = I("楙嬋", "aTcCy");
      I[212 + 107 - 108 + 105] = I("旀岪", "CPIIs");
      I[115 + 260 - 342 + 284] = I("抴恩", "dvgOI");
      I[42 + 196 - 169 + 249] = I("摦櫬", "DqgSj");
      I[91 + 307 - 82 + 3] = I("嚚嘮", "FgYbo");
      I[206 + 198 - 359 + 275] = I("孩兄", "yQBtC");
      I[70 + 259 - 193 + 185] = I("幇敊", "ddoFK");
      I[157 + 244 - 153 + 74] = I("峄婉", "PoDKL");
      I[310 + 192 - 313 + 134] = I("恣棳", "VTzJe");
      I[153 + 279 - 371 + 263] = I("涱歅", "dsVdu");
      I[130 + 39 - -27 + 129] = I("挮夤", "RSWer");
      I[167 + 132 - 66 + 93] = I("扫厕", "zdOap");
      I[125 + 276 - 400 + 326] = I("倳嶎", "plRzl");
      I[124 + 186 - 21 + 39] = I("冖姂", "IEZZz");
      I[33 + 124 - -168 + 4] = I("嗕悫", "jIPkW");
      I[56 + 272 - 136 + 138] = I("叽瀩", "dQiQp");
      I[158 + 242 - 306 + 237] = I("烦埈", "DznEv");
      I[35 + 123 - -173 + 1] = I("彖暔", "fcJRF");
      I[145 + 84 - 121 + 225] = I("彲橺", "spNtm");
      I[245 + 318 - 547 + 318] = I("嵬昫", "xbkSX");
      I[168 + 126 - 154 + 195] = I("怑乢", "oLESa");
      I[40 + 144 - 45 + 197] = I("攝侩", "HryVu");
      I[298 + 294 - 458 + 203] = I("擻宄", "NGqXf");
      I[237 + 42 - 121 + 180] = I("炋弅", "ImEJv");
      I[140 + 79 - -93 + 27] = I("修炻", "sRpwE");
      I[181 + 153 - 219 + 225] = I("揽倁", "yKnNh");
      I[17 + 228 - 72 + 168] = I("俽湃", "Feaan");
      I[1 + 324 - 85 + 102] = I("壍墾", "seABM");
      I[192 + 158 - 61 + 54] = I("撩廕", "SFRxT");
      I[84 + 180 - 215 + 295] = I("嶞彶", "PaGJp");
      I[165 + 232 - 111 + 59] = I("坧摠", "crKNt");
      I[93 + 269 - 257 + 241] = I("圩妖", "CcjUo");
      I[49 + 139 - -113 + 46] = I("彫嵋", "TYklb");
      I[102 + 258 - 353 + 341] = I("幃攲", "qpPfH");
      I[143 + 91 - 111 + 226] = I("杒擩", "UfmNl");
      I[210 + 34 - 109 + 215] = I("潡漨", "mLFHS");
      I[127 + 123 - -55 + 46] = I("从檠", "EJrWT");
      I[17 + 217 - -49 + 69] = I("烉伣", "gBAWJ");
      I[138 + 195 - 254 + 274] = I("堅橱", "jWtTM");
      I[146 + 328 - 405 + 285] = I("栿垎", "wOfqP");
      I[252 + 337 - 349 + 115] = I("弬区", "VcdMq");
      I[108 + 214 - 181 + 215] = I("佩梆", "RhddO");
      I[181 + 110 - 246 + 312] = I("漗景", "eZUxz");
      I[156 + 15 - 27 + 214] = I("榫喪", "kkcop");
      I[138 + 181 - 88 + 128] = I("嵣冃", "xXFfc");
      I[221 + 167 - 248 + 220] = I("嫰戍", "vQLkS");
      I[96 + 227 - 219 + 257] = I("澱巽", "bEdvg");
      I[42 + 333 - 326 + 313] = I("俽桁", "CejZJ");
      I[223 + 1 - -65 + 74] = I("焨匯", "lGEaV");
      I[86 + 207 - 223 + 294] = I("传勩", "kQwTv");
      I[272 + 229 - 217 + 81] = I("兒櫆", "bhLxE");
      I[259 + 68 - 86 + 125] = I("亊濜", "geshb");
      I[162 + 6 - 116 + 315] = I("暓拜", "xiGZZ");
      I[165 + 111 - 78 + 170] = I("橳刃", "ZXhdr");
      I[307 + 92 - 67 + 37] = I("伮如", "lnnyx");
      I[254 + 208 - 96 + 4] = I("楜咜", "lDXaL");
      I[248 + 79 - 98 + 142] = I("灲浝", "KDVUJ");
      I[335 + 206 - 393 + 224] = I("傝垛", "VSUZb");
      I[184 + 10 - 91 + 270] = I("僁呔", "WfUIL");
      I[276 + 162 - 190 + 126] = I("岳侚", "PPwRm");
      I[177 + 241 - 88 + 45] = I("孭岨", "dKNvD");
      I[372 + 220 - 512 + 296] = I("泠梗", "UPTJZ");
      I[138 + 141 - -33 + 65] = I("嘉泾", "lRkvS");
      I[90 + 177 - -96 + 15] = I("歶両", "niUNp");
      I[42 + 71 - 110 + 376] = I("洣徹", "EaPjy");
      I[121 + 27 - 126 + 358] = I("愥涿", "woeGN");
      I[172 + 334 - 268 + 143] = I("堏垐", "LsroE");
      I[359 + 180 - 264 + 107] = I("妺埫", "Blxwj");
      I[294 + 276 - 457 + 270] = I("嚰島", "EPxyJ");
      I[227 + 323 - 534 + 368] = I("岼歸", "ffVgZ");
      I[253 + 22 - 18 + 128] = I("囘厠", "KFHKF");
      I[380 + 251 - 412 + 167] = I("儖嵈", "TPxoC");
      I[332 + 88 - 219 + 186] = I("廉欴", "ukDLC");
      I[15 + 120 - -150 + 103] = I("冧咍", "gQFiK");
      I[355 + 277 - 487 + 244] = I("帯沬", "AFfIV");
      I[97 + 150 - -88 + 55] = I("濝佯", "OpyHu");
      I[111 + 339 - 358 + 299] = I("撩炞", "QCRBq");
      I[127 + 114 - 95 + 246] = I("捘夯", "wDIOg");
      I[265 + 35 - 140 + 233] = I("漏凉", "nfgOZ");
      I[4 + 303 - -59 + 28] = I("勬浓", "wYavm");
      I[70 + 122 - -192 + 11] = I("帷堾", "dFuRr");
      I[376 + 29 - 387 + 378] = I("槙囑", "BrQAK");
      I[365 + 28 - 62 + 66] = I("楿摙", "DTdje");
      I[196 + 64 - 141 + 279] = I("夞忘", "JRiCF");
      I[340 + 245 - 502 + 316] = I("潜揠", "EksYu");
      I[72 + 323 - 267 + 272] = I("曤儫", "VPJWc");
      I[241 + 270 - 191 + 81] = I("圤培", "XltgG");
      I[168 + 282 - 345 + 297] = I("嗐淃", "gotNq");
      I[91 + 309 - 122 + 125] = I("媱刏", "PuuPs");
      I[79 + 108 - 171 + 388] = I("喿憃", "BlYMq");
      I[72 + 203 - -128 + 2] = I("幽手", "lmZZV");
      I[186 + 359 - 527 + 388] = I("伂焣", "eauQY");
      I[12 + 37 - -206 + 152] = I("椂壷", "rHyaM");
      I[388 + 104 - 482 + 398] = I("煃涾", "tBJtt");
      I[364 + 364 - 426 + 107] = I("帧氒", "ZONCA");
      I[207 + 19 - 193 + 377] = I("巓凔", "Ghzqk");
      I[370 + 217 - 540 + 364] = I("搖槂", "kqUgE");
      I[141 + 228 - 80 + 123] = I("嘶澚", "RQxmG");
      I[25 + 404 - 244 + 228] = I("岙壑", "thYpR");
      I[403 + 405 - 788 + 394] = I("悖嬓", "Jeees");
      I[137 + 155 - 256 + 379] = I("僴嫊", "skVBJ");
      I[368 + 319 - 593 + 322] = I("挖困", "iqwPO");
      I[353 + 220 - 511 + 355] = I("澎差", "cncMU");
      I[303 + 409 - 347 + 53] = I("暐滎", "iCtWt");
      I[187 + 18 - 125 + 339] = I("匲湲", "ETMGd");
      I[407 + 220 - 278 + 71] = I("演喍", "iYlpB");
      I[316 + 404 - 683 + 384] = I("嶨刺", "NaaTq");
      I[243 + 11 - -133 + 35] = I("拣噵", "qhqbi");
      I[118 + 286 - 345 + 364] = I("湹慲", "fCxuU");
      I[264 + 222 - 447 + 385] = I("嶐搈", "KksfH");
      I[109 + 103 - -103 + 110] = I("昨塡", "nRLbR");
      I[293 + 215 - 124 + 42] = I("瀣崳", "pZtPY");
      I[189 + 159 - 77 + 156] = I("柠徏", "Sgzxi");
      I[330 + 80 - 134 + 152] = I("弣棾", "GwqZC");
      I[144 + 278 - 145 + 152] = I("殖晙", "UrhaH");
      I[421 + 58 - 143 + 94] = I("廋剉", "QMWVW");
      I[26 + 18 - -283 + 104] = I("彴湋", "yrbyY");
      I[283 + 391 - 259 + 17] = I("拴埓", "Mvldz");
      I[329 + 337 - 659 + 426] = I("檗委", "aYqpf");
      I[25 + 206 - 0 + 203] = I("櫄崕", "jysPq");
      I[241 + 25 - -97 + 72] = I("垝喎", "ryMjo");
      I[269 + 425 - 420 + 162] = I("嫗嗭", "aMvQP");
      I[378 + 14 - 86 + 131] = I("棻囩", "edglm");
      I[298 + 320 - 578 + 398] = I("慃尋", "YlkSW");
      I[304 + 354 - 555 + 336] = I("杵徍", "pzpeU");
      I[193 + 43 - 78 + 282] = I("宂姄", "eGQCR");
      I[81 + 272 - 350 + 438] = I("湊啉", "bMsqH");
      I[52 + 373 - 280 + 297] = I("唼枓", "TxzyV");
      I[422 + 401 - 643 + 263] = I("士漫", "AwbAE");
      I[123 + 403 - 396 + 314] = I("尽奿", "fAzrp");
      I[318 + 242 - 316 + 201] = I("哑柞", "WdkSg");
      I[379 + 220 - 336 + 183] = I("嬢僕", "lgqzq");
      I[247 + 371 - 599 + 428] = I("媤啍", "oLYsZ");
      I[357 + 266 - 342 + 167] = I("峚孬", "mmSgR");
      I[445 + 301 - 655 + 358] = I("棪兤", "CDZjZ");
      I[316 + 411 - 589 + 312] = I("渑伡", "Hkglb");
      I[420 + 346 - 637 + 322] = I("二噉", "TNIFL");
      I[75 + 286 - -37 + 54] = I("楐娥", "UrfGo");
      I[126 + 452 - 504 + 379] = I("姫偪", "PXKva");
      I[303 + 423 - 691 + 419] = I("儚憗", "oduoM");
      I[35 + 161 - 80 + 339] = I("廀嫸", "sTUtJ");
      I[411 + 336 - 549 + 258] = I("嗈叜", "vLXhq");
      I[183 + 269 - 134 + 139] = I("橷敺", "VnIWM");
      I[78 + 364 - 222 + 238] = I("庻捭", "SGQNO");
      I[348 + 380 - 413 + 144] = I("伱儰", "yGZeN");
      I[87 + 255 - 271 + 389] = I("灓嗵", "PcSkC");
      I[330 + 255 - 407 + 283] = I("厢殳", "CZamQ");
      I[120 + 395 - 66 + 13] = I("嶮娎", "yGbGj");
      I[168 + 71 - -69 + 155] = I("仫工", "WJHwe");
      I[11 + 231 - -3 + 219] = I("旊夭", "mNNQa");
      I[67 + 276 - 328 + 450] = I("忽浔", "YfBLl");
      I[148 + 101 - 148 + 365] = I("显將", "sAnYD");
      I[272 + 78 - -67 + 50] = I("捋克", "GOjKO");
      I[158 + 38 - -166 + 106] = I("漫奮", "RKMPF");
      I[0 + 417 - 4 + 56] = I("棚峏", "lHlmR");
      I[241 + 368 - 220 + 81] = I("槄廇", "ytgbh");
      I[26 + 277 - -11 + 157] = I("漓啭", "yPOyp");
      I[61 + 162 - 217 + 466] = I("僃瀌", "PsMMW");
      I[382 + 104 - 485 + 472] = I("濭墧", "oXDaX");
      I[50 + 235 - 60 + 249] = I("卛惢", "ebdyx");
      I[305 + 6 - 264 + 428] = I("拻扰", "Igkzr");
      I[195 + 246 - 146 + 181] = I("擣槳", "sVxuL");
      I[52 + 98 - 37 + 364] = I("孧借", "jaAGQ");
      I[78 + 252 - 7 + 155] = I("核樰", "GkChy");
      I[367 + 147 - 455 + 420] = I("啑涡", "FhqFL");
      I[12 + 127 - 84 + 425] = I("仲榸", "fvdiR");
      I[60 + 195 - 209 + 435] = I("您涉", "EqmYo");
      I[173 + 97 - -174 + 38] = I("忄晨", "YbYhN");
      I[149 + 62 - -218 + 54] = I("嗇僊", "HlIsd");
      I[312 + 41 - 122 + 253] = I("俔彥", "wGctg");
      I[458 + 402 - 845 + 470] = I("崚曮", "FiCjU");
      I[63 + 430 - 205 + 198] = I("咤歏", "fLvDQ");
      I[42 + 443 - 342 + 344] = I("凣佫", "nmjrH");
      I[332 + 83 - 331 + 404] = I("杅欧", "RYBLK");
      I[445 + 173 - 200 + 71] = I("庠寏", "vlSxO");
      I[359 + 103 - 146 + 174] = I("悸嵠", "MKRsV");
      I[341 + 438 - 342 + 54] = I("廓嶰", "cMrdY");
      I[352 + 359 - 588 + 369] = I("怢伊", "tzXeH");
      I[360 + 232 - 401 + 302] = I("儤晦", "BtdXh");
      I[126 + 34 - -221 + 113] = I("橓澤", "bJztC");
      I[201 + 405 - 210 + 99] = I("淊卂", "kNIWx");
      I[100 + 256 - 205 + 345] = I("孻娼", "jKZzE");
      I[62 + 379 - 100 + 156] = I("円丿", "yWlcP");
      I[487 + 14 - 382 + 379] = I("敺剅", "ejivi");
      I[53 + 495 - 517 + 468] = I("唢孆", "cwLGN");
      I[78 + 55 - 36 + 403] = I("徉毤", "tojzK");
      I[95 + 280 - 348 + 474] = I("溰媝", "CIZyk");
      I[130 + 163 - 59 + 268] = I("拳堽", "QCyUH");
      I[45 + 117 - 160 + 501] = I("晻匀", "DmMyw");
      I[198 + 456 - 543 + 393] = I("悐洊", "LaNGf");
      I[92 + 409 - 208 + 212] = I("堹夳", "oMVoJ");
      I[413 + 161 - 213 + 145] = I("汊傞", "ffDVn");
      I[356 + 100 - 388 + 439] = I("怖沅", "RmUlo");
      I[168 + 403 - 248 + 185] = I("挈殢", "MfKEA");
      I[210 + 35 - 240 + 504] = I("唐嚄", "qXjGW");
      I[318 + 185 - 358 + 365] = I("捴弹", "ACFnW");
      I[1 + 174 - 122 + 458] = I("彵扖", "WsKEd");
      I[396 + 96 - 261 + 281] = I("煳敦", "AOPWO");
      I[218 + 173 - 83 + 205] = I("娏壊", "VDbDC");
      I[508 + 465 - 559 + 100] = I("歓渑", "gmAJK");
      I[139 + 188 - -187 + 1] = I("從攣", "MoSry");
      I[61 + 250 - -181 + 24] = I("弔僁", "REDae");
      I[96 + 124 - 24 + 321] = I("丒侫", "eCKMZ");
      I[409 + 382 - 408 + 135] = I("侉尿", "PQlGx");
      I[422 + 418 - 606 + 285] = I("潛搵", "bWOXp");
      I[63 + 251 - 101 + 307] = I("殶儋", "hgmmR");
      I[133 + 459 - 242 + 171] = I("湊朒", "CWwmM");
      I[116 + 21 - 112 + 497] = I("俌嗒", "xGOFc");
      I[92 + 145 - -42 + 244] = I("唟懥", "TmEYU");
      I[216 + 317 - 65 + 56] = I("嬻厈", "PNyfN");
      I[161 + 383 - 59 + 40] = I("榧殥", "yAtyt");
      I[293 + 111 - -107 + 15] = I("澌城", "OjQXR");
      I[247 + 481 - 724 + 523] = I("欖務", "pzdPi");
      I[115 + 493 - 184 + 104] = I("梏忡", "iPNAy");
      I[376 + 513 - 390 + 30] = I("俹敝", "nLreV");
      I[20 + 210 - -58 + 242] = I("关彁", "UmOJq");
      I[76 + 7 - -50 + 398] = I("提掇", "UCNZt");
      I[48 + 348 - 115 + 251] = I("懘为", "qGdWU");
      I[187 + 17 - -57 + 272] = I("僗嫂", "SjLII");
      I[495 + 359 - 852 + 532] = I("洀柋", "xkonF");
      I[366 + 526 - 645 + 288] = I("掕塣", "LoknK");
      I[382 + 226 - 596 + 524] = I("忿呐", "kobQN");
      I[39 + 311 - -176 + 11] = I("榫澙", "HudGk");
      I[503 + 263 - 552 + 324] = I("揹佐", "ijrBk");
      I[326 + 260 - 581 + 534] = I("徜侀", "JtVrL");
      I[186 + 331 - 406 + 429] = I("囊抪", "CVPQo");
      I[514 + 531 - 701 + 197] = I("困殀", "BfFVC");
      I[1 + 335 - 80 + 286] = I("弩嗧", "mCRJs");
      I[239 + 184 - 125 + 245] = I("卨嵀", "rvpgp");
      I[100 + 504 - 213 + 153] = I("普吿", "zOCbJ");
      I[292 + 198 - 203 + 258] = I("摖偧", "uLAPx");
      I[424 + 156 - 124 + 90] = I("嗀李", "aydmW");
      I[32 + 250 - 7 + 272] = I("朔湐", "ZWYaL");
      I[171 + 350 - 516 + 543] = I("檆宄", "sXeYl");
      I[96 + 397 - 185 + 241] = I("檯屪", "xHPod");
      I[18 + 414 - 398 + 516] = I("偩旅", "KcvHt");
      I[64 + 5 - 6 + 488] = I("媱婶", "ADUmz");
      I[56 + 549 - 441 + 388] = I("据喧", "eJeUm");
      I[431 + 298 - 308 + 132] = I("弊憆", "pfomh");
      I[418 + 201 - 165 + 100] = I("唳坩", "XsCUA");
      I[383 + 488 - 399 + 83] = I("忣枼", "lkvgM");
      I[60 + 135 - -11 + 350] = I("槐洨", "ShiKY");
      I[417 + 452 - 591 + 279] = I("佑搸", "AMHJN");
      I[404 + 191 - 62 + 25] = I("烃卪", "ISvuu");
      I[462 + 111 - 484 + 470] = I("歅煜", "AUPLT");
      I[546 + 154 - 543 + 403] = I("兞挜", "EjtqG");
      I[320 + 171 - 345 + 415] = I("嫂溣", "NLUub");
      I[118 + 243 - 23 + 224] = I("乂烱", "cBmSg");
      I[123 + 390 - 381 + 431] = I("呄戇", "UsgCH");
      I[64 + 344 - 336 + 492] = I("媹挜", "ZnGJE");
      I[200 + 5 - -292 + 68] = I("崫叁", "TajAs");
      I[36 + 265 - 27 + 292] = I("徭渰", "FTpyY");
      I[230 + 89 - 262 + 510] = I("娤梡", "uNyxV");
      I[411 + 67 - 91 + 181] = I("唘埄", "AmaHa");
      I[333 + 181 - 289 + 344] = I("嘆嘶", "MGAhP");
      I[179 + 442 - 116 + 65] = I("洍峂", "bxwUk");
      I[144 + 71 - 38 + 394] = I("抳梐", "hmtrF");
      I[522 + 306 - 687 + 431] = I("沞桖", "iAUxf");
      I[6 + 345 - 31 + 253] = I("炆惇", "HQXzz");
      I[128 + 544 - 632 + 534] = I("岵灋", "YMUXS");
      I[509 + 255 - 415 + 226] = I("庥四", "xifmw");
      I[492 + 372 - 510 + 222] = I("榪烻", "qiTRx");
      I[560 + 380 - 531 + 168] = I("哬棧", "aGUmH");
      I[181 + 498 - 199 + 98] = I("忆刡", "EhVnz");
      I[168 + 272 - -111 + 28] = I("婔欨", "cHBGz");
      I[505 + 347 - 586 + 314] = I("夝懨", "TMtZz");
      I[230 + 284 - 459 + 526] = I("囂恄", "blEZX");
      I[197 + 437 - 264 + 212] = I("楀侞", "ZLXZv");
      I[385 + 191 - 30 + 37] = I("潏湕", "XRKTU");
      I[27 + 348 - 153 + 362] = I("埧嗄", "mhpAl");
      I[80 + 229 - -202 + 74] = I("悍咆", "tHYZU");
      I[363 + 380 - 416 + 259] = I("尅泛", "kDdQs");
      I[407 + 233 - 180 + 127] = I("婰朓", "UyhhI");
      I[155 + 490 - 183 + 126] = I("剻昤", "oEDtb");
      I[396 + 220 - 77 + 50] = I("涠伝", "zqCvg");
      I[428 + 39 - 348 + 471] = I("仚培", "IEbse");
      I[419 + 358 - 387 + 201] = I("梑徫", "KHWzh");
      I[591 + 292 - 313 + 22] = I("傀戋", "hNNGG");
      I[221 + 387 - 290 + 275] = I("岀朏", "ZICTR");
      I[314 + 17 - 23 + 286] = I("掟嬠", "NlKlE");
      I[225 + 399 - 70 + 41] = I("岙欥", "mAMYz");
      I[11 + 181 - -317 + 87] = I("橰棾", "Mstgy");
      I[96 + 120 - 114 + 495] = I("曔樑", "bcmHJ");
      I[373 + 1 - 9 + 233] = I("捲嬤", "NXQkO");
      I[344 + 488 - 441 + 208] = I("枩氶", "BSpHq");
      I[575 + 551 - 1080 + 554] = I("瀝囬", "IkCaA");
      I[181 + 560 - 485 + 345] = I("枞凮", "sXrpU");
      I[460 + 371 - 427 + 198] = I("毝涍", "yJPCm");
      I[319 + 495 - 351 + 140] = I("妪偒", "YBbCV");
      I[260 + 137 - 274 + 481] = I("比柖", "QUnvI");
      I[438 + 541 - 948 + 574] = I("媯呎", "IlQgy");
      I[510 + 480 - 560 + 176] = I("厠峉", "zTfxG");
      I[541 + 378 - 566 + 254] = I("嫰尫", "cKzOG");
      I[279 + 299 - 532 + 562] = I("佪弊", "mgHFm");
      I[81 + 12 - -342 + 174] = I("滫嬀", "aORav");
      I[36 + 73 - -348 + 153] = I("彖彵", "hPaZT");
      I[248 + 492 - 629 + 500] = I("伹撟", "fWhJu");
      I[388 + 62 - 270 + 432] = I("墛乿", "JGZTa");
      I[555 + 342 - 500 + 216] = I("峢摳", "JoqbQ");
      I[182 + 515 - 554 + 471] = I("剐替", "fpnwD");
      I[398 + 126 - 489 + 580] = I("圊栎", "TpgrZ");
      I[4 + 437 - -30 + 145] = I("债容", "HDHTz");
      I[123 + 541 - 557 + 510] = I("椠涞", "iGtTQ");
      I[213 + 347 - 229 + 287] = I("嚮摜", "qYwaR");
      I[251 + 3 - 239 + 604] = I("敐楗", "uzjEN");
      I[254 + 434 - 133 + 65] = I("宜垡", "bZmzU");
      I[269 + 242 - 234 + 344] = I("柜唿", "rueNU");
      I[571 + 241 - 220 + 30] = I("揎沂", "DyWUS");
      I[109 + 220 - -8 + 286] = I("嫋再", "igxPQ");
      I[372 + 166 - 311 + 397] = I("嶣徛", "RspaJ");
      I[363 + 99 - -14 + 149] = I("卝慃", "CSOsQ");
      I[354 + 96 - 437 + 613] = I("凌烉", "WpvDR");
      I[433 + 346 - 527 + 375] = I("墛擴", "EMdlb");
      I[129 + 266 - 74 + 307] = I("檄堮", "FFbzR");
      I[181 + 195 - -106 + 147] = I("歔瀉", "JtUkT");
      I[595 + 171 - 308 + 172] = I("烷崆", "JsOlY");
      I[505 + 27 - 440 + 539] = I("捕悙", "EiChQ");
      I[328 + 131 - -150 + 23] = I("攣巆", "vPzhq");
      I[111 + 521 - 439 + 440] = I("炨亃", "eCEtq");
      I[566 + 204 - 144 + 8] = I("卨嫀", "fuGNy");
      I[437 + 227 - 382 + 353] = I("崳快", "wqHhM");
      I[455 + 397 - 276 + 60] = I("侖描", "gwzxU");
      I[341 + 396 - 273 + 173] = I("冪泔", "ICRYi");
      I[59 + 357 - 46 + 268] = I("棄洟", "ipeQi");
      I[453 + 57 - 174 + 303] = I("宾士", "WGvez");
      I[562 + 472 - 810 + 416] = I("懦兔", "GbECw");
      I[242 + 568 - 718 + 549] = I("凲淮", "SiZwJ");
      I[484 + 511 - 544 + 191] = I("椔没", "wfvYC");
      I[235 + 194 - -111 + 103] = I("哜溕", "AVkwF");
      I[188 + 187 - 349 + 618] = I("姝傶", "ymRgc");
      I[525 + 492 - 997 + 625] = I("悮昨", "kkcYj");
      I[623 + 453 - 616 + 186] = I("日劰", "daIYN");
      I[124 + 66 - -298 + 159] = I("内幇", "ouRZv");
      I[559 + 323 - 391 + 157] = I("湟場", "erccS");
      I[323 + 535 - 529 + 320] = I("咍掹", "DuHDq");
      I[415 + 153 - 118 + 200] = I("労嘻", "EyeKy");
      I[207 + 647 - 213 + 10] = I("朻氀", "FsKvm");
      I[116 + 299 - 206 + 443] = I("淝彁", "uBfDp");
      I[279 + 635 - 550 + 289] = I("灙俣", "whYVi");
      I[577 + 164 - 186 + 99] = I("悐攈", "oUuCR");
      I[491 + 80 - 289 + 373] = I("擹瀞", "JkVeo");
      I[542 + 141 - 48 + 21] = I("椱烚", "oRBeU");
      I[542 + 231 - 635 + 519] = I("淤沾", "WQkwW");
      I[438 + 435 - 454 + 239] = I("沮旀", "xKsYs");
      I[12 + 240 - 225 + 632] = I("伨彚", "wiPUV");
      I[133 + 10 - -271 + 246] = I("泯摘", "cabuL");
      I[361 + 583 - 350 + 67] = I("俽呋", "lBErh");
      I[9 + 303 - 98 + 448] = I("拳嗢", "YyCpL");
      I[490 + 526 - 787 + 434] = I("妋堦", "lpNFZ");
      I[400 + 306 - 240 + 198] = I("嘚澕", "LJNtV");
      I[184 + 285 - 62 + 258] = I("屹濍", "kfUzK");
      I[541 + 577 - 783 + 331] = I("尔拏", "KQUHa");
      I[409 + 353 - 474 + 379] = I("嶛従", "sMBeV");
      I[336 + 397 - 249 + 184] = I("代愎", "XNqdL");
      I[225 + 383 - 370 + 431] = I("几圊", "jihEB");
      I[256 + 585 - 690 + 519] = I("汙亵", "XdUPk");
      I[20 + 213 - -123 + 315] = I("搏炶", "SqYJL");
      I[519 + 439 - 530 + 244] = I("浦暢", "gwwVI");
      I[138 + 505 - 238 + 268] = I("坔敌", "xIirR");
      I[209 + 263 - 267 + 469] = I("啷榈", "ThhIl");
      I[239 + 323 - 310 + 423] = I("勱党", "VaOvU");
      I[108 + 358 - -62 + 148] = I("漹媶", "eAqWp");
      I[627 + 509 - 506 + 47] = I("孭喐", "eUDuC");
      I[35 + 318 - 256 + 581] = I("岚曭", "OdVVd");
      I[240 + 303 - 265 + 401] = I("昺澷", "noqGU");
      I[616 + 562 - 741 + 243] = I("浯圱", "zRQsp");
      I[243 + 567 - 132 + 3] = I("毜拵", "FwCHz");
      I[356 + 408 - 127 + 45] = I("炣侶", "taPfs");
      I[139 + 100 - 49 + 493] = I("剔温", "WpZsQ");
      I[454 + 105 - -21 + 104] = I("匾漤", "ectHe");
      I[558 + 386 - 613 + 354] = I("墟涰", "ONnSF");
      I[35 + 69 - -131 + 451] = I("刕曽", "gCkeO");
      I[53 + 221 - 179 + 592] = I("咏潒", "OStld");
      I[218 + 244 - -26 + 200] = I("撞巬", "BJZYi");
      I[135 + 224 - 45 + 375] = I("枣瀛", "KLcQx");
      I[681 + 366 - 487 + 130] = I("徕埧", "FzdPo");
      I[571 + 326 - 522 + 316] = I("樲噚", "bIGZd");
      I[672 + 295 - 889 + 614] = I("坮毀", "rKulu");
      I[373 + 15 - 6 + 311] = I("氥姃", "gcCAZ");
      I[2 + 671 - 51 + 72] = I("榛冼", "CEidh");
      I[486 + 432 - 752 + 529] = I("伥円", "Kzhsk");
      I[517 + 385 - 891 + 685] = I("坰掌", "WoIxg");
      I[255 + 0 - -106 + 336] = I("唼冿", "nBXBW");
      I[378 + 394 - 153 + 79] = I("懣囗", "bMicL");
      I[238 + 122 - 81 + 420] = I("朜楛", "LBdOQ");
      I[286 + 172 - -150 + 92] = I("敐喪", "MjUph");
      I[396 + 356 - 685 + 634] = I("揍倿", "qnoDc");
      I[258 + 77 - -290 + 77] = I("撤扵", "DKLlK");
      I[522 + 510 - 550 + 221] = I("丈嬹", "dihNW");
      I[420 + 581 - 548 + 251] = I("搴唙", "WtWVR");
      I[336 + 643 - 643 + 369] = I("啻柈", "NoKlr");
      I[349 + 474 - 266 + 149] = I("澭埬", "tuqsX");
      I[520 + 301 - 526 + 412] = I("嶪剾", "DaoDh");
      I[20 + 595 - 392 + 485] = I("慍嚲", "CnYaP");
      I[180 + 142 - -102 + 285] = I("尣摓", "pLVQb");
      I[121 + 261 - 141 + 469] = I("惷澐", "wsMkr");
      I[536 + 576 - 465 + 64] = I("朥志", "vUneh");
      I[43 + 527 - -112 + 30] = I("杠沸", "KOQiN");
      I[581 + 235 - 633 + 530] = I("侭傆", "ULeFU");
      I[160 + 208 - -244 + 102] = I("枆嚢", "DyTWq");
      I[244 + 710 - 700 + 461] = I("烨姄", "FafJy");
      I[676 + 415 - 786 + 411] = I("撍型", "tBJtZ");
      I[13 + 335 - 287 + 656] = I("榢匛", "mMoIH");
      I[644 + 364 - 663 + 373] = I("咱哞", "WgEVn");
      I[263 + 166 - -136 + 154] = I("孁帷", "tyuXq");
      I[146 + 360 - -65 + 149] = I("僘咃", "ZtVTX");
      I[590 + 123 - 168 + 176] = I("擌奂", "tOiks");
      I[411 + 583 - 314 + 42] = I("榎戆", "iQOpN");
      I[133 + 172 - -371 + 47] = I("嫩妕", "JaTjy");
      I[501 + 31 - -128 + 64] = I("峎嚣", "YFPHr");
      I[272 + 99 - 49 + 403] = I("擗潟", "caaYk");
      I[428 + 441 - 504 + 361] = I("毳歼", "AsALk");
      I[102 + 120 - -450 + 55] = I("懃忋", "LNLww");
      I[642 + 307 - 940 + 719] = I("敘檟", "xDNOn");
      I[635 + 402 - 435 + 127] = I("栛攓", "OQlUc");
      I[217 + 700 - 849 + 662] = I("瀸朥", "fZhBP");
      I[106 + 120 - -419 + 86] = I("嵬榽", "DDISO");
      I[386 + 722 - 762 + 386] = I("擫嚝", "QRCmd");
      I[120 + 507 - 565 + 671] = I("凅懼", "XgLCa");
      I[303 + 357 - 569 + 643] = I("夣挵", "kZdAa");
      I[27 + 283 - 1 + 426] = I("协溰", "RfYKn");
      I[179 + 733 - 815 + 639] = I("愡溳", "RURqr");
      I[177 + 567 - 69 + 62] = I("柙宀", "DceQE");
      I[80 + 383 - -172 + 103] = I("密撵", "CtZAh");
      I[259 + 673 - 864 + 671] = I("攀懶", "qUACG");
      I[645 + 170 - 650 + 575] = I("朼汴", "RgiAk");
      I[402 + 144 - 362 + 557] = I("壔拑", "UyFui");
      I[465 + 127 - 158 + 308] = I("束宦", "fNPTj");
      I[34 + 162 - -47 + 500] = I("倮懳", "NdXvy");
      I[197 + 45 - -212 + 290] = I("尢橉", "OQGac");
      I[269 + 527 - 74 + 23] = I("導殰", "LBjND");
      I[19 + 726 - 343 + 344] = I("殥泋", "NNrnl");
      I[31 + 302 - 99 + 513] = I("丨撿", "uiqTZ");
      I[337 + 539 - 473 + 345] = I("哌擒", "tmmqw");
      I[437 + 193 - 102 + 221] = I("侶傌", "SwqQt");
      I[334 + 268 - 351 + 499] = I("嗇叵", "PmhpW");
      I[418 + 42 - 206 + 497] = I("南墹", "jcwhZ");
      I[452 + 164 - 45 + 181] = I("憽堧", "cvBIz");
      I[665 + 457 - 989 + 620] = I("俓汊", "JmhXr");
      I[255 + 365 - 91 + 225] = I("剦枴", "ACcuR");
      I[444 + 194 - 328 + 445] = I("沱潋", "SytkU");
      I[725 + 651 - 880 + 260] = I("淥侩", "fRfKN");
      I[468 + 585 - 758 + 462] = I("岆埽", "vPxel");
      I[505 + 127 - -56 + 70] = I("権煢", "iYJJu");
      I[223 + 455 - 132 + 213] = I("渗嫰", "XSrtb");
      I[690 + 316 - 982 + 736] = I("岢压", "wuSHy");
      I[393 + 44 - -191 + 133] = I("漟嫭", "viaga");
      I[447 + 699 - 519 + 135] = I("意嘺", "swOuS");
      I[417 + 239 - 486 + 593] = I("潐烿", "ifwcX");
      I[263 + 486 - 169 + 184] = I("丈啩", "FUMdd");
      I[610 + 633 - 1006 + 528] = I("愠到", "wJRcV");
      I[291 + 477 - 460 + 458] = I("叒歀", "SLDEP");
      I[393 + 456 - 213 + 131] = I("冊嶳", "dghVw");
      I[610 + 220 - 781 + 719] = I("济恕", "pYTVC");
      I[34 + 160 - -146 + 429] = I("僆檚", "mZvNy");
      I[97 + 172 - -314 + 187] = I("弃娙", "mvOeu");
      I[735 + 163 - 463 + 336] = I("偦囹", "KuMBD");
      I[439 + 274 - 241 + 300] = I("孴梸", "XzgZl");
      I[709 + 419 - 657 + 302] = I("泙呒", "DmcBw");
      I[460 + 374 - 251 + 191] = I("捛啢", "EafYB");
      I[456 + 264 - 360 + 415] = I("几沔", "sDHoX");
      I[664 + 105 - 437 + 444] = I("淬唩", "QBXBx");
      I[655 + 162 - 629 + 589] = I("椥唘", "TCVFq");
      I[334 + 722 - 399 + 121] = I("傪滙", "Woehx");
      I[217 + 216 - 306 + 652] = I("呙憼", "BaijQ");
      I[730 + 619 - 735 + 166] = I("哯怃", "ycNWd");
      I[388 + 660 - 371 + 104] = I("凜旌", "walEK");
      I[544 + 382 - 787 + 643] = I("唫孂", "fotQp");
      I[30 + 369 - 384 + 768] = I("榑渺", "ThLap");
      I[411 + 628 - 693 + 438] = I("攺怗", "GBpJn");
      I[296 + 553 - 100 + 36] = I("樱嚇", "bLvXm");
      I[784 + 270 - 801 + 533] = I("泮姷", "GUapN");
      I[266 + 471 - 179 + 229] = I("潲屖", "eWYnD");
      I[135 + 443 - -9 + 201] = I("欚帚", "aQxBO");
      I[476 + 295 - 397 + 415] = I("墚槈", "DvLGy");
      I[49 + 253 - 202 + 690] = I("娵厩", "fexKl");
      I[696 + 615 - 883 + 363] = I("勰灇", "GGsmT");
      I[283 + 449 - 473 + 533] = I("渘區", "uBAFO");
      I[443 + 296 - 381 + 435] = I("樜忙", "bQxge");
      I[288 + 533 - 303 + 276] = I("淅悲", "bYQff");
      I[770 + 496 - 504 + 33] = I("揲涆", "hAPSF");
      I[266 + 202 - -293 + 35] = I("摻毑", "ZTNcX");
      I[616 + 388 - 375 + 168] = I("嶸撣", "cCzMu");
      I[111 + 132 - -174 + 381] = I("伾涱", "wqpfo");
      I[67 + 373 - 152 + 511] = I("坕槠", "mJaKP");
      I[604 + 509 - 685 + 372] = I("彡欈", "SNipn");
      I[402 + 481 - 520 + 438] = I("扴揭", "MhzkH");
      I[750 + 581 - 542 + 13] = I("偍梊", "UnGEf");
      I[208 + 386 - 213 + 422] = I("偡淽", "Lundf");
      I[41 + 297 - -417 + 49] = I("嘘晈", "NnHea");
      I[166 + 658 - 353 + 334] = I("灈形", "nPUsJ");
      I[601 + 626 - 1019 + 598] = I("栃匛", "iRcSN");
      I[266 + 721 - 838 + 658] = I("擵佮", "lLjfE");
      I[41 + 86 - -675 + 6] = I("嫺廷", "cQQSc");
      I[250 + 699 - 631 + 491] = I("桖主", "wDfjs");
      I[127 + 481 - 493 + 695] = I("朋拤", "IOAxN");
      I[17 + 20 - -70 + 704] = I("儬抾", "xLRbX");
      I[142 + 553 - 69 + 186] = I("敢侫", "GmtBV");
      I[50 + 124 - -539 + 100] = I("侑廌", "nbiis");
      I[47 + 249 - 268 + 786] = I("廜固", "ddKln");
      I[507 + 32 - 463 + 739] = I("孩傥", "ZzSnF");
      I[642 + 69 - -22 + 83] = I("瀶刡", "belyK");
      I[799 + 218 - 223 + 23] = I("枆栌", "qMOGW");
      I[728 + 98 - 432 + 424] = I("丙壂", "aTYno");
      I[29 + 104 - -292 + 394] = I("倆倒", "RfkQR");
      I[616 + 535 - 868 + 537] = I("沒挶", "nmGjM");
      I[352 + 126 - 363 + 706] = I("否溔", "Gyalr");
      I[490 + 373 - 317 + 276] = I("浡烚", "EkMCI");
      I[363 + 373 - -28 + 59] = I("尰塀", "NaPoy");
      I[408 + 381 - 478 + 513] = I("懐婋", "BhcbG");
      I[280 + 550 - 22 + 17] = I("擲摉", "VAwVf");
      I[52 + 785 - 705 + 694] = I("洛图", "ANIjH");
      I[782 + 763 - 1202 + 484] = I("淁寂", "JwAGO");
      I[502 + 788 - 580 + 118] = I("嘶庣", "Hkhsv");
      I[794 + 688 - 1291 + 638] = I("榶幖", "XzUZk");
      I[512 + 15 - 211 + 514] = I("埸哣", "vjuGj");
      I[237 + 259 - 141 + 476] = I("昴滒", "rXhYO");
      I[76 + 380 - 67 + 443] = I("氘勤", "XjkzV");
      I[545 + 542 - 463 + 209] = I("溭巩", "akTIq");
      I[509 + 338 - 237 + 224] = I("搊泐", "WZwLk");
      I[786 + 390 - 753 + 412] = I("曉孺", "JZhIi");
      I[119 + 501 - -166 + 50] = I("晿哓", "CZLOb");
      I[293 + 298 - -222 + 24] = I("摴姑", "iddXp");
      I[286 + 544 - 234 + 242] = I("凪澶", "evpxT");
      I[619 + 166 - 182 + 236] = I("渟炔", "DXCFh");
      I[516 + 584 - 826 + 566] = I("戞俦", "yNjWZ");
      I[729 + 540 - 959 + 531] = I("比嬡", "NDvIl");
      I[709 + 509 - 772 + 396] = I("仠噬", "aAqyx");
      I[489 + 719 - 633 + 268] = I("垾冺", "cmsxj");
      I[9 + 743 - -35 + 57] = I("惎壳", "XuPXb");
      I[608 + 461 - 664 + 440] = I("徤幹", "PJouA");
      I[353 + 838 - 1128 + 783] = I("匣宊", "dbJwA");
      I[498 + 401 - 128 + 76] = I("汸安", "OJGbK");
      I[807 + 834 - 1313 + 520] = I("戴屶", "imCmY");
      I[98 + 765 - 342 + 328] = I("彥娃", "nVQVJ");
      I[451 + 499 - 746 + 646] = I("厮唇", "vWrkT");
      I[191 + 829 - 297 + 128] = I("湏曎", "nZBrT");
      I[764 + 787 - 1053 + 354] = I("刣櫏", "RBhpo");
      I[474 + 811 - 1193 + 761] = I("懺傌", "fdlda");
      I[760 + 125 - 301 + 270] = I("伡喵", "gPVlu");
      I[822 + 63 - 286 + 256] = I("倝揰", "rpofy");
      I[461 + 181 - -70 + 144] = I("嫠榖", "jAIZG");
      I[734 + 582 - 658 + 199] = I("嵄湬", "OSJPi");
      I[336 + 415 - 522 + 629] = I("愛擧", "AwpHZ");
      I[152 + 106 - 172 + 773] = I("朵扌", "cljqK");
      I[448 + 125 - 128 + 415] = I("嵇坸", "Ecedf");
      I[771 + 341 - 568 + 317] = I("伯咡", "twQII");
      I[420 + 333 - 332 + 441] = I("孥懇", "OaDyP");
      I[253 + 542 - 258 + 326] = I("晻冹", "BEObH");
      I[512 + 86 - -57 + 209] = I("刄幦", "ByYKt");
      I[320 + 292 - 474 + 727] = I("櫸晓", "jBunj");
      I[360 + 470 - 354 + 390] = I("围叅", "bGQiY");
      I[633 + 249 - 251 + 236] = I("姺峃", "PvmLx");
      I[475 + 412 - 881 + 862] = I("冬垹", "yVTsr");
      I[539 + 305 - 206 + 231] = I("戤妟", "yYOHz");
      I[368 + 775 - 1037 + 764] = I("梋挻", "QQMSL");
      I[48 + 222 - -498 + 103] = I("刊殻", "OllRd");
      I[478 + 276 - 498 + 616] = I("坧濚", "NUJUN");
      I[29 + 829 - 410 + 425] = I("摜因", "vjXQN");
      I[432 + 834 - 1168 + 776] = I("侪濰", "AtHNW");
      I[539 + 506 - 857 + 687] = I("帨媨", "dOAnH");
      I[424 + 426 - 176 + 202] = I("您堉", "gELoa");
      I[36 + 765 - 772 + 848] = I("奯塗", "JaQDl");
      I[12 + 15 - -384 + 467] = I("撣恾", "wIZxr");
      I[14 + 877 - 638 + 626] = I("昿嗯", "lsmDl");
      I[101 + 680 - 526 + 625] = I("厌恧", "UyCtK");
      I[101 + 556 - 333 + 557] = I("意圍", "CfXwN");
      I[719 + 880 - 1580 + 863] = I("懤咋", "BVpnZ");
      I[309 + 195 - -371 + 8] = I("洒滕", "XcTAH");
      I[366 + 167 - 318 + 669] = I("泭慪", "IDzXm");
      I[123 + 3 - -464 + 295] = I("傦凕", "yWBFd");
      I[204 + 159 - 244 + 767] = I("攁桒", "cHWbl");
      I[421 + 359 - 395 + 502] = I("左有", "UnetA");
      I[509 + 452 - 792 + 719] = I("炧丞", "NIlUq");
      I[148 + 644 - 670 + 767] = I("擲淫", "elOyB");
      I[736 + 201 - 888 + 841] = I("橣勖", "tETSi");
      I[542 + 732 - 414 + 31] = I("摸慬", "vIgoE");
      I[192 + 614 - 722 + 808] = I("挷峱", "riBiB");
      I[618 + 190 - 225 + 310] = I("徭嫴", "aZcfq");
      I[280 + 154 - -441 + 19] = I("帪堏", "unQao");
      I[576 + 383 - 774 + 710] = I("唐梸", "bCyRD");
      I[451 + 774 - 555 + 226] = I("揚斒", "sqWft");
      I[42 + 559 - 45 + 341] = I("啽瀨", "glKTb");
      I[403 + 86 - -195 + 214] = I("坏朆", "rFSqY");
      I[608 + 133 - 724 + 882] = I("悘春", "zLznL");
      I[810 + 804 - 1029 + 315] = I("摱搭", "yOgIf");
      I[668 + 139 - 204 + 298] = I("槀搨", "qcHuE");
      I[537 + 162 - 238 + 441] = I("嘡泪", "jcnnh");
      I[64 + 363 - -278 + 198] = I("嶯仿", "rxsza");
      I[745 + 301 - 1004 + 862] = I("峱嬕", "vFzpL");
      I[114 + 790 - 611 + 612] = I("戗氻", "NzxXh");
      I[728 + 868 - 1419 + 729] = I("災影", "CZLCo");
      I[767 + 793 - 907 + 254] = I("刬煎", "fFoHI");
      I[251 + 411 - 216 + 462] = I("浇妽", "SCwkZ");
      I[770 + 812 - 945 + 272] = I("炬抢", "vxdwJ");
      I[53 + 550 - 125 + 432] = I("抬埂", "Wiocu");
      I[613 + 843 - 705 + 160] = I("梭凓", "HKfyQ");
      I[743 + 610 - 1188 + 747] = I("兂泟", "FsOgW");
      I[328 + 114 - 27 + 498] = I("搊殟", "iJMiB");
      I[817 + 376 - 851 + 572] = I("噚娫", "YpZJP");
      I[183 + 415 - 274 + 591] = I("呫格", "rHDfI");
      I[682 + 575 - 1126 + 785] = I("兾僴", "BgwKy");
      I[351 + 53 - -465 + 48] = I("奥嫞", "cqoOM");
      I[813 + 223 - 543 + 425] = I("嗟戣", "TsRFY");
      I[611 + 64 - 658 + 902] = I("梯氄", "NtKJw");
      I[758 + 295 - 1013 + 880] = I("揢唣", "mMoTT");
      I[663 + 872 - 878 + 264] = I("擘巖", "lWJGp");
      I[687 + 741 - 1154 + 648] = I("帰楔", "hqueF");
      I[651 + 364 - 698 + 606] = I("湱埢", "mVwSc");
      I[553 + 593 - 816 + 594] = I("浗憻", "AIwJz");
      I[795 + 838 - 1471 + 763] = I("嘖湈", "Luvxy");
      I[825 + 61 - 167 + 207] = I("曦椰", "SqFKt");
      I[14 + 354 - -304 + 255] = I("奲彧", "allHu");
      I[480 + 681 - 1089 + 856] = I("捶孾", "MMJMb");
      I[278 + 326 - -18 + 307] = I("澎俌", "VXOtw");
      I[264 + 601 - 537 + 602] = I("岀坪", "iCbzz");
      I[513 + 790 - 469 + 97] = I("暭壺", "ErymQ");
      I[38 + 14 - -721 + 159] = I("乨埥", "QVlFD");
      I[434 + 647 - 171 + 23] = I("沅乣", "qFVeH");
      I[527 + 882 - 825 + 350] = I("奷列", "vXvVu");
      I[461 + 286 - -106 + 82] = I("庍抺", "xhScm");
      I[434 + 8 - -192 + 302] = I("漤晏", "OprnQ");
      I[310 + 841 - 441 + 227] = I("厘煥", "JWHZT");
      I[822 + 821 - 1584 + 879] = I("巀壇", "IRSVO");
      I[588 + 47 - -261 + 43] = I("海奄", "DcQYN");
      I[9 + 340 - -18 + 573] = I("悎拝", "LyCXx");
      I[650 + 573 - 1046 + 764] = I("欜框", "bRDYl");
      I[383 + 768 - 1102 + 893] = I("俜榳", "SfoiU");
      I[117 + 664 - 338 + 500] = I("槍旂", "HypBw");
      I[267 + 204 - -328 + 145] = I("杕徜", "VaSim");
      I[222 + 141 - -405 + 177] = I("姻噄", "wkXtl");
      I[877 + 824 - 1543 + 788] = I("昭漆", "YpMFI");
      I[249 + 110 - 339 + 927] = I("炝匛", "psHov");
      I[369 + 134 - -209 + 236] = I("棎敂", "rqTcP");
      I[495 + 416 - 737 + 775] = I("享呁", "LlGGV");
      I[735 + 357 - 333 + 191] = I("删柌", "eefJy");
      I[567 + 111 - 649 + 922] = I("娼執", "SdktO");
      I[259 + 720 - 532 + 505] = I("峖俸", "AMHek");
      I[46 + 950 - 717 + 674] = I("嵜庬", "eMPmv");
      I[576 + 752 - 1153 + 779] = I("弖渊", "Swmor");
      I[939 + 853 - 1644 + 807] = I("岮揞", "MDdjr");
      I[751 + 835 - 1107 + 477] = I("恕尞", "DjrRT");
      I[452 + 518 - 968 + 955] = I("峷洖", "bTerr");
      I[803 + 237 - 619 + 537] = I("橸战", "fmiaM");
      I[75 + 587 - -190 + 107] = I("埀浑", "sMjjB");
      I[741 + 26 - 544 + 737] = I("屹氧", "NmHUq");
      I[838 + 772 - 1491 + 842] = I("欍枭", "xAaMA");
      I[48 + 787 - 549 + 676] = I("廋憜", "kGqIJ");
      I[217 + 482 - -239 + 25] = I("厁嬢", "pJhKh");
      I[451 + 294 - 716 + 935] = I("忖専", "SuXpj");
      I[81 + 356 - 168 + 696] = I("凴唛", "yMnPx");
      I[922 + 569 - 739 + 214] = I("无没", "ZJPRs");
      I[486 + 927 - 1089 + 643] = I("瀮岣", "wjgIb");
      I[54 + 752 - 778 + 940] = I("忐橅", "LWHhy");
      I[640 + 225 - -101 + 3] = I("扰依", "AMuht");
      I[247 + 928 - 461 + 256] = I("搄嚝", "CUZVU");
      I[524 + 794 - 897 + 550] = I("剔哆", "Crkla");
      I[711 + 842 - 1484 + 903] = I("悩汐", "pMiQS");
      I[4 + 457 - -494 + 18] = I("墡澻", "rgfAs");
      I[684 + 850 - 1341 + 781] = I("云却", "EsKZl");
      I[800 + 495 - 938 + 618] = I("喪欹", "GkEMh");
      I[44 + 355 - -417 + 160] = I("單撔", "fvLXi");
      I[30 + 168 - -734 + 45] = I("撊凜", "sExLd");
      I[193 + 282 - -162 + 341] = I("尲壿", "xabcC");
      I[617 + 258 - 51 + 155] = I("严婛", "TBNvT");
      I[794 + 642 - 1056 + 600] = I("塜斕", "SvwyG");
      I[111 + 772 - 872 + 970] = I("惽嬛", "pjNka");
      I[940 + 469 - 1176 + 749] = I("惥嶆", "ElvVh");
      I[391 + 734 - 491 + 349] = I("庪灚", "KxbZC");
      I[48 + 726 - 348 + 558] = I("宻唵", "tEkal");
      I[20 + 727 - 503 + 741] = I("业帐", "BUNvK");
      I[256 + 838 - 720 + 612] = I("摕梣", "VRcLE");
      I[556 + 553 - 745 + 623] = I("恹奔", "jXZiM");
      I[131 + 948 - 139 + 48] = I("殿呶", "tqtJR");
      I[759 + 178 - 579 + 631] = I("偝懖", "lBIfW");
      I[674 + 926 - 851 + 241] = I("姊掁", "klCiQ");
      I[609 + 565 - 942 + 759] = I("侊搖", "UmfVt");
      I[29 + 182 - -101 + 680] = I("崔奆", "SuLgj");
      I[231 + 66 - 64 + 760] = I("毯刓", "JTJGx");
      I[349 + 742 - 996 + 899] = I("命扺", "SFrin");
      I[463 + 449 - 240 + 323] = I("揭佳", "bKDlV");
      I[208 + 984 - 674 + 478] = I("晿崚", "cgVuL");
      I[330 + 896 - 393 + 164] = I("棄丬", "mPJfi");
      I[636 + 35 - 389 + 716] = I("椠梽", "Bxdis");
      I[63 + 455 - -239 + 242] = I("懠奝", "BOxaj");
      I[951 + 185 - 602 + 466] = I("時湍", "NexoX");
      I[322 + 878 - 754 + 555] = I("崪嵿", "FOWMi");
      I[951 + 882 - 1541 + 710] = I("嫟槫", "wrXvA");
      I[747 + 524 - 683 + 415] = I("攃泟", "iecUc");
      I[24 + 944 - 499 + 535] = I("念枔", "UuEZj");
      I[634 + 672 - 702 + 401] = I("庴晗", "NEgmz");
      I[645 + 819 - 1073 + 615] = I("全桓", "BxCrB");
      I[667 + 223 - 889 + 1006] = I("敮惴", "jNnav");
      I[390 + 610 - 970 + 978] = I("攙搒", "ouPoE");
      I[6 + 202 - -709 + 92] = I("掃姲", "Fkbct");
      I[389 + 264 - -299 + 58] = I("剓叅", "znXeR");
      I[236 + 394 - 376 + 757] = I("旓枚", "LSckF");
      I[987 + 493 - 1106 + 638] = I("噶俎", "mjMvD");
      I[173 + 585 - 611 + 866] = I("健澝", "JJgwL");
      I[131 + 135 - -632 + 116] = I("嬄榮", "CUOgM");
      I[926 + 206 - 863 + 746] = I("儮挻", "NxMWH");
      I[113 + 426 - -196 + 281] = I("廏榘", "ydBfD");
      I[1012 + 781 - 1453 + 677] = I("奌悱", "odpRi");
      I[906 + 943 - 1065 + 234] = I("媒含", "rzLRT");
      I[262 + 1013 - 1246 + 990] = I("嚭後", "uOLVz");
      I[257 + 583 - 421 + 601] = I("洪弖", "Nfjfv");
      I[393 + 530 - 893 + 991] = I("擝呁", "jSpTa");
      I[645 + 195 - -104 + 78] = I("杄朒", "GpeKp");
      I[103 + 426 - -365 + 129] = I("瀌滫", "nKOQd");
      I[118 + 820 - 426 + 512] = I("巿慥", "krJKZ");
      I[932 + 1002 - 952 + 43] = I("嶧峘", "xtMtB");
      I[677 + 618 - 1266 + 997] = I("旣妈", "SFHpd");
      I[793 + 336 - 829 + 727] = I("便妷", "fhIdV");
      I[426 + 392 - 16 + 226] = I("媫寎", "ccUGe");
      I[77 + 268 - -391 + 293] = I("婢歨", "uvoQN");
      I[177 + 541 - 670 + 982] = I("搔妓", "WpHsq");
      I[537 + 842 - 1204 + 856] = I("巛制", "YLCvT");
      I[811 + 504 - 841 + 558] = I("歜囜", "CAfmS");
      I[520 + 765 - 1041 + 789] = I("弁欢", "aUXKe");
      I[534 + 125 - -83 + 292] = I("捐渴", "mFYqH");
      I[950 + 531 - 768 + 322] = I("嘩憭", "MRlMq");
      I[385 + 444 - 27 + 234] = I("摰殏", "uirEm");
      I[762 + 92 - -10 + 173] = I("杗撋", "MjTpW");
      I[230 + 814 - 171 + 165] = I("扏堚", "dSvjM");
      I[695 + 436 - 723 + 631] = I("廴揨", "ycaLi");
      I[981 + 646 - 992 + 405] = I("橙二", "QeXYW");
      I[746 + 268 - 423 + 450] = I("孛攃", "EtUSO");
      I[389 + 248 - 136 + 541] = I("榩媿", "rBsXC");
      I[121 + 469 - -268 + 185] = I("擷嬤", "SxsvE");
      I[1017 + 797 - 852 + 82] = I("桱昮", "Yfvti");
      I[507 + 542 - 750 + 746] = I("坽促", "DRoqB");
      I[821 + 324 - 848 + 749] = I("嫲懸", "UFpaT");
      I[690 + 644 - 434 + 147] = I("攓恧", "PLSwD");
      I[618 + 642 - 620 + 408] = I("儙弉", "zZwMN");
      I[974 + 536 - 1238 + 777] = I("匒戈", "lkEAP");
      I[527 + 16 - 16 + 523] = I("檒唈", "iaEbE");
      I[736 + 231 - -30 + 54] = I("沼格", "EJbvh");
      I[988 + 10 - 100 + 154] = I("扮庆", "Lfptn");
      I[897 + 654 - 836 + 338] = I("垼啯", "pDiiM");
      I[397 + 143 - 529 + 1043] = I("幘揻", "RwaTD");
      I[564 + 416 - 277 + 352] = I("孙撍", "jRkRA");
      I[470 + 380 - 467 + 673] = I("叴捧", "fSJmE");
      I[820 + 133 - 726 + 830] = I("楌垡", "IBAGn");
      I[745 + 231 - 89 + 171] = I("嵔澪", "JphgW");
      I[529 + 445 - 782 + 867] = I("棲匏", "DoYZk");
      I[917 + 294 - 844 + 693] = I("晈挼", "YOfDR");
      I[140 + 633 - 162 + 450] = I("汕啽", "nxwts");
      I[42 + 15 - -724 + 281] = I("揺堉", "xoWfv");
      I[559 + 1005 - 732 + 231] = I("歉恕", "MwLCT");
      I[884 + 193 - 616 + 603] = I("了別", "MIPHA");
      I[514 + 340 - 476 + 687] = I("昒喳", "wxVOx");
      I[99 + 1045 - 356 + 278] = I("嫨浍", "wGJzM");
      I[746 + 434 - 1128 + 1015] = I("刟旀", "szpFJ");
      I[58 + 241 - -592 + 177] = I("巳洉", "hMjex");
      I[394 + 183 - 76 + 568] = I("溶姛", "loDtA");
      I[21 + 787 - 639 + 901] = I("枒啉", "TTzJa");
      I[797 + 210 - 382 + 446] = I("捚喽", "wNHIF");
      I[948 + 970 - 867 + 21] = I("嬧塒", "XoEsL");
      I[842 + 408 - 1080 + 903] = I("旷嗞", "FynUq");
      I[757 + 263 - 624 + 678] = I("湵忐", "zSAqt");
      I[635 + 226 - 363 + 577] = I("懿堭", "UAFkM");
      I[614 + 648 - 958 + 772] = I("汳伜", "TTkHC");
      I[171 + 841 - 218 + 283] = I("潓印", "HcLTg");
      I[603 + 159 - -207 + 109] = I("昵嬝", "hyGgd");
      I[882 + 291 - 988 + 894] = I("巂渌", "tVGmg");
      I[1031 + 546 - 1408 + 911] = I("娸埖", "DWDtP");
      I[177 + 101 - 263 + 1066] = I("棙埬", "tJRXJ");
      I[733 + 563 - 391 + 177] = I("烧揠", "UXVAU");
      I[430 + 1069 - 1224 + 808] = I("歧力", "nXRkd");
      I[852 + 764 - 1032 + 500] = I("橵洁", "vdxQa");
      I[2 + 859 - 747 + 971] = I("涓傷", "hUOJQ");
      I[254 + 759 - 358 + 431] = I("咒瀞", "csCXW");
      I[558 + 1071 - 787 + 245] = I("斞扙", "klgbS");
      I[1007 + 543 - 633 + 171] = I("倇嬒", "rNTLI");
      I[683 + 542 - 876 + 740] = I("帄掹", "DEbNH");
      I[749 + 126 - 801 + 1016] = I("庾唥", "TmJAb");
      I[657 + 553 - 237 + 118] = I("妴儽", "AVoYL");
      I[703 + 118 - 13 + 284] = I("巴渦", "XhPqY");
      I[544 + 588 - 569 + 530] = I("悤抅", "sDnzo");
      I[184 + 383 - 386 + 913] = I("啽坽", "hNyQJ");
      I[967 + 915 - 1237 + 450] = I("桥槫", "RbUEf");
      I[128 + 774 - 795 + 989] = I("櫤伒", "kSHyA");
      I[733 + 185 - 189 + 368] = I("圳搟", "DKYeI");
      I[962 + 868 - 981 + 249] = I("帜棻", "aLISY");
      I[892 + 517 - 935 + 625] = I("湲滯", "qxCWc");
      I[661 + 454 - 772 + 757] = I("嶏唘", "MupEd");
      I[1019 + 873 - 1448 + 657] = I("樿暐", "unEfS");
      I[712 + 538 - 1100 + 952] = I("剐涒", "Iccuz");
      I[387 + 521 - 563 + 758] = I("渦淆", "kgwNy");
      I[209 + 906 - 1095 + 1084] = I("亵歀", "cBobY");
      I[752 + 675 - 1337 + 1015] = I("僿七", "PDIpH");
      I[126 + 58 - 162 + 1084] = I("楄仹", "MtpcF");
      I[4 + 312 - -361 + 430] = I("娡佇", "BMcnO");
      I[330 + 843 - 212 + 147] = I("俔仦", "jfTgV");
      I[135 + 716 - -258 + 0] = I("憝攏", "ZfFOs");
      I[593 + 814 - 1298 + 1001] = I("婏堬", "RBFwI");
      I[31 + 889 - -18 + 173] = I("咔杻", "PKAYI");
      I[1076 + 165 - 801 + 672] = I("庣櫰", "srgKx");
      I[384 + 198 - -281 + 250] = I("揖拊", "TvGQF");
      I[542 + 293 - -206 + 73] = I("寿坲", "YlkBv");
      I[518 + 126 - 606 + 1077] = I("椿叫", "hbBLY");
      I[314 + 232 - -559 + 11] = I("濆炐", "aPqlw");
      I[383 + 1025 - 1067 + 776] = I("榸氥", "Umyzt");
      I[360 + 439 - 793 + 1112] = I("丌巊", "XOOgC");
      I[598 + 233 - -171 + 117] = I("懍悸", "ZpHfG");
      I[330 + 1116 - 713 + 387] = I("殨拍", "fFfVO");
      I[993 + 712 - 1662 + 1078] = I("帎圸", "KOWqS");
      I[789 + 220 - 905 + 1018] = I("崷喹", "QCzpT");
      I[355 + 601 - 248 + 415] = I("溎撅", "Gpekt");
      I[639 + 348 - 242 + 379] = I("匢殅", "eKPbX");
      I[300 + 431 - 487 + 881] = I("挂基", "gyQAM");
      I[1007 + 807 - 863 + 175] = I("浾枯", "jlmBG");
      I[790 + 417 - 159 + 79] = I("埡妓", "LUcNv");
      I[545 + 269 - 727 + 1041] = I("忦圤", "mzxTC");
      I[321 + 764 - 318 + 362] = I("炾属", "yioAd");
      I[456 + 152 - -291 + 231] = I("崃嵌", "YrkLO");
      I[640 + 961 - 962 + 492] = I("梯涃", "VDLlX");
      I[465 + 377 - -61 + 229] = I("怅憬", "LWpsG");
      I[312 + 185 - -113 + 523] = I("搯洢", "ZPHes");
      I[1131 + 334 - 822 + 491] = I("凎坬", "HUvgr");
      I[840 + 80 - 902 + 1117] = I("椽呠", "mGSNT");
      I[727 + 819 - 1266 + 856] = I("出樘", "FCxyQ");
      I[520 + 687 - 708 + 638] = I("栴埾", "bummw");
      I[868 + 888 - 999 + 381] = I("彄僇", "OveIe");
      I[850 + 541 - 808 + 556] = I("敒咅", "dpbNF");
      I[448 + 142 - 182 + 732] = I("兯斎", "hGuid");
      I[740 + 1109 - 1473 + 765] = I("尲廮", "Wopws");
      I[93 + 14 - -715 + 320] = I("兺倪", "FsQEj");
      I[1052 + 906 - 1287 + 472] = I("嘘抑", "rCwPN");
      I[1117 + 47 - 637 + 617] = I("欔洵", "IXNgs");
      I[616 + 762 - 277 + 44] = I("幍搰", "EmOpN");
      I[562 + 668 - 483 + 399] = I("挾旉", "JABmI");
      I[434 + 799 - 444 + 358] = I("侑曗", "fswOV");
      I[250 + 348 - 232 + 782] = I("揥剻", "viCqR");
      I[988 + 691 - 1006 + 476] = I("櫣樆", "LzZgc");
      I[804 + 863 - 1254 + 737] = I("放傋", "vGdZL");
      I[737 + 785 - 930 + 559] = I("涡埫", "eBUFe");
      I[789 + 847 - 1433 + 949] = I("嚯渄", "wTxNF");
      I[515 + 1088 - 931 + 481] = I("劃岥", "wOhsS");
      I[759 + 64 - 507 + 838] = I("刬幩", "EBoyn");
      I[272 + 328 - 359 + 914] = I("慿姐櫶嵃", "IUoUu");
      I[111 + 1063 - 967 + 949] = I("悞尚尉", "cQwmZ");
      I[803 + 236 - 504 + 622] = I("嚕曧泳噣", "ODQia");
      I[635 + 982 - 494 + 35] = I("\b/'", "iFUcI");
      I[949 + 655 - 622 + 177] = I("\u0015\u001c\u0004\u0000\u0013", "fhknv");
      I[525 + 994 - 521 + 162] = I("劃", "VpnLW");
      I[731 + 294 - 874 + 1010] = I("呞", "SGVhG");
      I[125 + 332 - 26 + 731] = I(" \u001a\u000680", "SniVU");
      I[623 + 465 - 1020 + 1095] = I("\r\u0019\u0012\u0017'", "jksdT");
      I[292 + 8 - 55 + 919] = I("昶垿", "joubj");
      I[427 + 758 - 28 + 8] = I("湗", "AuMal");
      I[16 + 477 - -348 + 325] = I("时侄惊丽污", "ZVvxq");
      I[1135 + 886 - 1912 + 1058] = I("僩枖揄扆", "vWAZu");
      I[978 + 976 - 1558 + 772] = I("\u0010\u0002+\u0019\u001d", "wpJjn");
      I[515 + 513 - 156 + 297] = I(">8\u0004\u0012", "ZQvfd");
      I[815 + 303 - -44 + 8] = I("忲渗写", "NHLHp");
      I[493 + 421 - 43 + 300] = I("帮", "QjYQh");
      I[565 + 525 - 369 + 451] = I("劣愺", "sFyfD");
      I[316 + 777 - 744 + 824] = I("\u0003#\u0000\u001a", "gJrnx");
      I[278 + 531 - 740 + 1105] = I("渫啅捡朩", "xQlOy");
      I[624 + 351 - 540 + 740] = I("栄侕尰墹捬", "Eilzl");
      I[942 + 493 - 1192 + 933] = I("\u0010\f*\u001c\u000f\u0001\n,\u0011\u0001", "cxErj");
      I[790 + 914 - 1533 + 1006] = I("\f+\u0001\u00048\n7\u0017\t:\n", "oDcfT");
      I[1105 + 976 - 1801 + 898] = I("屜恤巆揅彋", "plyDT");
      I[220 + 1121 - 950 + 788] = I("氾弴晇", "CjUUp");
      I[283 + 34 - -689 + 174] = I("僋末橤徘", "OVdwQ");
      I[1029 + 117 - 1050 + 1085] = I("啫", "JgvYB");
      I[739 + 888 - 1559 + 1114] = I("溥悝壱", "Uwsqh");
      I[453 + 726 - 330 + 334] = I("68!)", "AWNMk");
      I[795 + 1109 - 1150 + 430] = I("\u0001\u0015;-1\u0002", "qyZCZ");
      I[604 + 497 - 347 + 431] = I("\u00020\u001f-3\u001f6", "qQoAZ");
      I[1153 + 1172 - 1356 + 217] = I("叝洱歅", "YZrML");
      I[43 + 550 - -12 + 582] = I("媲啌", "YBFgz");
      I[11 + 641 - 580 + 1116] = I("攆尳", "ZheTf");
      I[391 + 98 - -496 + 204] = I("' 2\"\u001f:&", "TABNv");
      I[128 + 417 - -11 + 634] = I("&=#'\u0004'3", "DXGUk");
      I[516 + 445 - 723 + 953] = I("恝湚", "VgzxT");
      I[1071 + 544 - 1555 + 1132] = I("-\u0014%\u001e!,\u001a", "OqAlN");
      I[984 + 747 - 968 + 430] = I("5\b\u0006%\u0000=\u00036%\b'\u0001\u001b", "SdiRi");
      I[81 + 210 - -54 + 849] = I("幵烶", "ACMwi");
      I[329 + 902 - 1129 + 1093] = I("#\b\"\"\b", "TiVGz");
      I[474 + 81 - -632 + 9] = I("\u0019\u0011&+\u0003", "npRNq");
      I[502 + 870 - 886 + 711] = I("搂松", "xTVoX");
      I[225 + 1067 - 1017 + 923] = I("=/\r)3", "JNyLA");
      I[1189 + 734 - 1653 + 929] = I("6!'\"?>*\u001797&,", "PMHUV");
      I[398 + 1166 - 1480 + 1116] = I("怶弜喩", "WwiZZ");
      I[782 + 512 - 963 + 870] = I("涇刦捬", "ggtXC");
      I[951 + 973 - 1921 + 1199] = I("摋", "CSlhG");
      I[886 + 957 - 834 + 194] = I("\t\u0011\u0013\r", "epelj");
      I[1076 + 984 - 1004 + 148] = I("\u0003\u00061\n", "ogGkS");
      I[174 + 574 - 134 + 591] = I("冶晶懟", "ZoblH");
      I[781 + 252 - -164 + 9] = I("\u0007\r\u0006\u0002", "klpcx");
      I[624 + 270 - -220 + 93] = I("7\u0015/\u0002", "DtAfS");
      I[83 + 922 - 205 + 408] = I("惂捣檊媮", "HawVO");
      I[530 + 1158 - 1332 + 853] = I("墌斶", "yiGJO");
      I[437 + 939 - 779 + 613] = I("\u0016\u001784", "evVPa");
      I[525 + 510 - 418 + 594] = I("\b;\u000f8-\u0003", "oInNH");
      I[774 + 219 - 588 + 807] = I("匵", "cFomO");
      I[890 + 810 - 1395 + 908] = I("\u0006\u001b+\u00051\r", "aiJsT");
      I[878 + 940 - 1506 + 902] = I("%\u001c\u001e=\u0012-\u0001\u0017", "BsrYM");
      I[931 + 87 - -188 + 9] = I("偾卞唦彄", "unrEl");
      I[872 + 521 - 394 + 217] = I("捶徙", "pOXUm");
      I[638 + 334 - -14 + 231] = I("檪呠兴", "EhTiC");
      I[271 + 944 - 1208 + 1211] = I(",\n\u000e!\u001a/\u001c", "Cxkfu");
      I[649 + 778 - 993 + 785] = I("#\u0007!&1%\u0007+", "JuNHn");
      I[732 + 1168 - 1550 + 870] = I("擌", "RrgdJ");
      I[95 + 719 - 313 + 720] = I("暲发揖", "gXuzi");
      I[680 + 863 - 395 + 74] = I("歛攸", "Vgppf");
      I[363 + 51 - -724 + 85] = I("孹", "sweZq");
      I[250 + 899 - 248 + 323] = I("$\u001a\u001399$\u0006", "KhvpK");
      I[323 + 826 - 434 + 510] = I(";\"\u0015\u0006\u00117?\u0011", "XMtjN");
      I[667 + 227 - -104 + 228] = I("凖", "yociN");
      I[791 + 165 - -139 + 132] = I("沖晃暼僝灁", "Yrzko");
      I[556 + 550 - 254 + 376] = I("\t(77\u001f\u00076", "fZRtp");
      I[852 + 517 - 162 + 22] = I("\u0016\u0016\f", "zykHj");
      I[78 + 954 - 912 + 1110] = I("喍唝忎寋", "YuCQF");
      I[826 + 1113 - 1685 + 977] = I("杒岾剀", "VBHXF");
      I[791 + 696 - 812 + 557] = I("憭溙摽杰", "mubKn");
      I[231 + 1093 - 1166 + 1075] = I("\u0000\b)", "lgNvk");
      I[905 + 1038 - 1401 + 692] = I("46-\u001b,+", "XSLmI");
      I[1073 + 579 - 1143 + 726] = I("橹單", "uJZgf");
      I[890 + 1047 - 1860 + 1159] = I("不", "NGzWk");
      I[296 + 1193 - 769 + 517] = I("噆憆", "MjWlt");
      I[580 + 1000 - 849 + 507] = I("奬境", "iXQVE");
      I[503 + 629 - 431 + 538] = I("#\u000f\u0016\u0001\u0015<", "Ojwwp");
      I[233 + 1034 - 354 + 327] = I("\t -\u0016\u0012\u001f", "zPBxu");
      I[971 + 1203 - 1709 + 776] = I("划悒", "zGuZu");
      I[148 + 1007 - 321 + 408] = I("橦湮曔", "iDlqW");
      I[81 + 951 - 1021 + 1232] = I("偢櫭", "yywFz");
      I[1118 + 1103 - 1694 + 717] = I("烈岦宊悞卮", "oenWz");
      I[203 + 215 - -96 + 731] = I("棨兄档", "efbPr");
      I[1215 + 719 - 1919 + 1231] = I(" \u0005\u000e8\u00106", "SuaVw");
      I[149 + 16 - -714 + 368] = I("\f\u0007\u0019<\u0003", "kkxOp");
      I[744 + 1064 - 1330 + 770] = I("咮堢儨", "BPnAp");
      I[1102 + 492 - 1062 + 717] = I("炘削", "htqih");
      I[308 + 428 - -162 + 352] = I("3\u0005(0\u0014", "TiICg");
      I[63 + 1154 - 824 + 858] = I("\u0019'1\u001f\u0005*)3\u0013", "uFAvv");
      I[778 + 201 - 803 + 1076] = I("仯濔基", "ESOeX");
      I[1127 + 215 - 1146 + 1057] = I(",5\u0016\u0007\u00023.\u0000", "CGsKc");
      I[667 + 236 - 285 + 636] = I("*\u000e\u001c\u0013\u0001\u0019\r\u0000\u0015\u0011-", "Folzr");
      I[525 + 41 - 95 + 784] = I("勞剁呮", "UJpry");
      I[988 + 520 - 648 + 396] = I("叺歎朗暑灻", "mOWop");
      I[899 + 717 - 1071 + 712] = I("屋", "dSIcr");
      I[581 + 187 - -143 + 347] = I("4\r\u001f\u000f\u0000\u001a\u0000\u0000\u0005\u0018", "Vaplk");
      I[1053 + 1078 - 1428 + 556] = I("\u00078:('\r\",*", "cQIXB");
      I[910 + 244 - -63 + 43] = I("刜全楱噎烋", "IsrpV");
      I[162 + 70 - -284 + 745] = I("'\u001f94\u0012-\u0005/6", "CvJDw");
      I[43 + 337 - 237 + 1119] = I("昞嗼沎唏嵦", "yaUXJ");
      I[826 + 811 - 409 + 35] = I("曱悡", "hIzJW");
      I[329 + 1242 - 597 + 290] = I("48\u0018\u0005\u000236\u0018\u0004", "GYvaQ");
      I[1255 + 788 - 1831 + 1053] = I(": \u001d%\u000b=.\u001d$", "IAsAx");
      I[560 + 112 - 281 + 875] = I("\u0002 &\r\u0011\u0000 1\u0003", "lORhs");
      I[76 + 753 - -272 + 166] = I("攓潦兇杇", "uVFSL");
      I[1066 + 142 - 1035 + 1095] = I("\u001e\u0002*-\u00051\u001b6'\r", "swYDf");
      I[104 + 639 - 421 + 947] = I("4$\u0003", "VAgQQ");
      I[255 + 986 - 1151 + 1180] = I("垬渏偽", "wGpyH");
      I[389 + 520 - 205 + 567] = I("构夆", "VZuNe");
      I[730 + 1018 - 825 + 349] = I("渉", "aZeoh");
      I[197 + 1035 - 356 + 397] = I("\u0017\u000b3", "unWxz");
      I[1087 + 897 - 1196 + 486] = I("*\u0018#//#(=*#!", "MwOKJ");
      I[828 + 443 - 226 + 230] = I("咜溾", "fjzom");
      I[948 + 159 - 663 + 832] = I("\n#\u0014\u0012\u0013\u0003\u001e\u0019\u001f\u001a", "mLxvv");
      I[795 + 998 - 1638 + 1122] = I("\f <'5\u001c*:\u001d$\t,$", "hEHBV");
      I[404 + 871 - 7 + 10] = I("慖佂", "kawTS");
      I[1242 + 785 - 1999 + 1251] = I("梬咂戸捊嶦", "POtRR");
      I[8 + 109 - -533 + 630] = I("*/\"*\u000f:%$\u001d\r'&", "NJVOl");
      I[712 + 71 - 164 + 662] = I("4 (38>\u000b19 3;/", "GTAPS");
      I[272 + 451 - 505 + 1064] = I("暷", "Yulyu");
      I[179 + 783 - 373 + 694] = I("映", "xvuLi");
      I[1120 + 228 - 461 + 397] = I("<-=55\"\u0017:(9'=\f ))", "LDNAZ");
      I[995 + 126 - 979 + 1143] = I("\u001d\u0017\u0007", "jreZh");
      I[1064 + 323 - 133 + 32] = I("垾侞暽", "fDNSO");
      I[1153 + 1170 - 1359 + 323] = I("彷幖怴嬬婬", "Vggcd");
      I[544 + 858 - 1100 + 986] = I("%7+", "RRIWW");
      I[1093 + 418 - 408 + 186] = I("\u0017\u0016\u0003%&\u0011\u0016\u001c:", "cwoIA");
      I[1000 + 688 - 1432 + 1034] = I("惔搛季", "XUoqQ");
      I[9 + 866 - -27 + 389] = I("慠喔戜峝墇", "phWDW");
      I[1247 + 939 - 1159 + 265] = I("滅忋栏", "VdGsR");
      I[971 + 5 - -288 + 29] = I("\u001e\u0004 9\u0014\u0018\u0004?&", "jeLUs");
      I[1071 + 239 - 1176 + 1160] = I("\u0000\u0010$\u00077\u0011\u0006-", "duEcU");
      I[972 + 129 - 618 + 812] = I("橈", "vVsLw");
      I[528 + 385 - 808 + 1191] = I("漓潛丵欁杁", "YQQlg");
      I[903 + 258 - 576 + 712] = I("外姺潋偤", "wNsfP");
      I[1112 + 94 - 730 + 822] = I("炽免汲求昁", "FvrHV");
      I[445 + 678 - 456 + 632] = I("5'5\u0000\u0017$1<", "QBTdu");
      I[933 + 440 - 678 + 605] = I("5\u0011\u0002\u0013>+", "ExqgQ");
      I[1155 + 801 - 1864 + 1209] = I("庥浙民崥奒", "MZgBv");
      I[63 + 1059 - 29 + 209] = I("焲妎漪", "uKidm");
      I[785 + 974 - 1231 + 775] = I("洪娡剡丑", "CSWjl");
      I[827 + 1118 - 1543 + 902] = I("\u0014\u001f)-8\n4;*2", "dvZYW");
      I[330 + 1250 - 1414 + 1139] = I(":\b\u0018\u0015\u001e$>\u0003\u0004\u0010.", "Jakaq");
      I[112 + 454 - -620 + 120] = I("填办浾俱撊", "Iaxxn");
      I[506 + 235 - 415 + 981] = I("檰", "RtdGn");
      I[1307 + 161 - 1443 + 1283] = I("枤捨啃巑印", "KuWVO");
      I[179 + 426 - -361 + 343] = I("4.\u0011#\b*\u0005\u0003$\u0002", "DGbWg");
      I[730 + 329 - 625 + 876] = I("'&,\"", "PICNs");
      I[1027 + 1282 - 1703 + 705] = I("婟嫘濂懸摙", "Cfsfn");
      I[18 + 501 - 327 + 1120] = I("摞毼", "aZtcy");
      I[1164 + 684 - 1526 + 991] = I("漏柯啕榜", "eIrvx");
      I[283 + 1114 - 484 + 401] = I("喷涎凞姱", "XVhTL");
      I[679 + 214 - 84 + 506] = I(".<\u00050\u001b", "MPjDs");
      I[386 + 177 - 98 + 851] = I("\u0004:5\u0010 \u001a\f#\u001c;\u0011=5\r \u001a", "tSFdO");
      I[627 + 520 - 11 + 181] = I("即恞廍涄", "tdhNc");
      I[235 + 1255 - 661 + 489] = I("憭墼嵯", "ZYOLb");
      I[356 + 930 - 873 + 906] = I(" 0\u0001\u000f\u000b.\n\u000b\u000f\u000b.0\u001f", "YUmcd");
      I[577 + 637 - 519 + 625] = I("歌", "uOFJO");
      I[418 + 1090 - 1202 + 1015] = I("掊", "nBpjN");
      I[405 + 499 - 535 + 953] = I("\u0002\u00037\u0000\r\u0016^", "doXwh");
      I[1233 + 1302 - 2444 + 1232] = I("?\r\u0003<3!\u0007\u0010\u0006'", "MhgcU");
      I[55 + 1299 - 523 + 493] = I("楷庅撖", "eVLdT");
      I[1213 + 354 - 1155 + 913] = I("下", "wHuTL");
      I[694 + 381 - 496 + 747] = I("柴咕慄嫜厤", "IXxYy");
      I[1247 + 535 - 625 + 170] = I("\u0005\u000b\u001a2)\u0011U", "cguEL");
      I[329 + 1000 - 570 + 569] = I("匘唟歪", "VjxMH");
      I[222 + 1264 - 802 + 645] = I("淔嚱崑執", "uWyrV");
      I[434 + 415 - -204 + 277] = I("巯尫婎掶榏", "JMKnQ");
      I[392 + 388 - -139 + 412] = I(":\u000f9<\u00028\u0015'", "WzJTp");
      I[1090 + 131 - 1106 + 1217] = I("$\u0017*->\u0019\b0)84\n*7", "FeEZP");
      I[537 + 1285 - 651 + 162] = I("槬槆冯濎扙", "OlmcX");
      I[101 + 973 - 365 + 625] = I("柮劜", "nHxgV");
      I[754 + 84 - 86 + 583] = I("凴棚叮泟", "YKntV");
      I[176 + 1280 - 1174 + 1054] = I("兂拖厌唅", "cdNZK");
      I[338 + 1291 - 610 + 318] = I("*\u001f\u0007,\u0016(\u0005\u0019", "GjtDd");
      I[903 + 1008 - 1015 + 442] = I("4\u0004*\u0016\u00033\u0012&;\u0001)\f", "FaNIn");
      I[145 + 229 - -536 + 429] = I("?\u00075 \u0017:\u00046'#", "XhYDH");
      I[496 + 661 - -44 + 139] = I("灻", "Fonjn");
      I[1237 + 1269 - 1380 + 215] = I("滄", "JHnfh");
      I[946 + 1082 - 2010 + 1324] = I("灋咔煼攚", "GLAnf");
      I[1241 + 175 - 479 + 406] = I("呂拃湅", "GFJxD");
      I[531 + 859 - 90 + 44] = I("76*9\u001f\u00125)>", "UZEZt");
      I[887 + 123 - 552 + 887] = I("1*=\r-:4=\u0000\u0019", "XXRcr");
      I[1047 + 792 - 1213 + 720] = I("屇劣瀰", "qiQQs");
      I[106 + 1144 - 798 + 895] = I("热烋呗", "hfkPK");
      I[97 + 432 - -247 + 572] = I(":\u00065\u0015\u0019\u0011\u00185\u0018", "XjZvr");
      I[1186 + 738 - 720 + 145] = I("\u0016\u0015\u001a\u0015\u0019\u0017%\u001c\u0003\u001a\u001c\u001f0\u0004\u0019\u0013\u0018", "rzowu");
      I[1287 + 338 - 459 + 184] = I("氶", "WNwYF");
      I[485 + 1154 - 1378 + 1090] = I("!\u0000:%4\u0001\u00184)", "RtUKQ");
      I[1021 + 1134 - 1673 + 870] = I(":#>\b \u0016$=\u0007'", "IWQfE");
      I[1180 + 988 - 1738 + 923] = I("判价", "uOvtk");
      I[908 + 927 - 957 + 476] = I("侐氍啓坾仭", "DYFEK");
      I[860 + 386 - 824 + 933] = I("欫混呸曳烞", "pViaG");
      I[984 + 788 - 744 + 328] = I("性怢坐溍", "PoeGB");
      I[1165 + 730 - 985 + 447] = I("7'79\u0010\u0017?95", "DSXWu");
      I[1175 + 451 - 397 + 129] = I("唧", "djhdw");
      I[775 + 8 - 737 + 1313] = I("儜伋妖", "wigxH");
      I[494 + 1244 - 1004 + 626] = I("嗸偀掊怴俓", "tulGq");
      I[1266 + 983 - 1246 + 358] = I(",\u0005>7\u001d", "NwWTv");
      I[1302 + 515 - 1408 + 953] = I("*\u0007',\"\u0017\u0017\" *#", "HuNOI");
      I[9 + 569 - -615 + 170] = I("\u0001\u0006\"", "uhVSG");
      I[1002 + 677 - 625 + 310] = I("枹悬", "kTMNP");
      I[314 + 1308 - 884 + 627] = I(">\"\u001e", "JLjBc");
      I[1007 + 980 - 1178 + 557] = I("'\u0000\t%\u001c-\n\n(", "EofNo");
      I[21 + 1192 - 866 + 1020] = I("掳", "QZXwA");
      I[261 + 1359 - 990 + 738] = I("檷冓兺傴", "bXKmX");
      I[851 + 1052 - 1367 + 833] = I(" \u00035\u0006\u0012*\t6\u000b", "BlZma");
      I[487 + 181 - -594 + 108] = I("\u001d\u001d\n4./\u0011\u0016%5\u001c\u0017\n38\u001e\u0017", "pryGW");
      I[544 + 429 - 916 + 1314] = I("圄", "kqKjV");
      I[1275 + 125 - 1272 + 1244] = I("揩佖梠勒垆", "CEEGr");
      I[72 + 1033 - -12 + 256] = I("丩焕僘", "GRazM");
      I[1275 + 507 - 639 + 231] = I(" \u0004\u0002<\u0013\u001e\u001f\u001e!", "SpmRv");
      I[294 + 508 - 307 + 880] = I("8+0?\u001e>(-", "WICVz");
      I[1175 + 859 - 1848 + 1190] = I("慖灷槊炢", "LXYyJ");
      I[260 + 1251 - 524 + 390] = I("(\u0005>\f+.\u0006#", "GgMeO");
      I[863 + 447 - 728 + 796] = I("\u001a9'\u001a\f", "nVUyd");
      I[662 + 343 - 170 + 544] = I("灣揱", "WNYbH");
      I[429 + 141 - -213 + 597] = I("焒渢", "PxqEA");
      I[1077 + 908 - 1635 + 1031] = I("彴抭港", "xDHMr");
      I[19 + 85 - 78 + 1356] = I("5=>7?", "ARLTW");
      I[1072 + 412 - 1305 + 1204] = I("\u00140 !", "rYRDT");
      I[927 + 1041 - 1124 + 540] = I("毫", "gsTcM");
      I[534 + 635 - 764 + 980] = I("烬", "Lzahr");
      I[555 + 963 - 1085 + 953] = I("1 %\f", "WIWiH");
      I[871 + 966 - 1587 + 1137] = I("\u0002\u001e\u000139\u001f\u0010\u0014\u0002/\u001d", "oqclJ");
      I[1211 + 1161 - 1106 + 122] = I("僱抪咡孬", "JpdhE");
      I[1242 + 943 - 1453 + 657] = I("\u000b\u0005\u0006\u001e\u001c\u0007\u001d\n(\u001e", "fjdMl");
      I[333 + 1236 - 985 + 806] = I("\u0000\u0000\u001a;\"\u001b\u0000\u0018\u0016\"", "oaqdQ");
      I[987 + 1025 - 715 + 94] = I("奨坰塠", "COnRs");
      I[268 + 264 - -812 + 48] = I("休渍濨哮", "fEKgo");
      I[480 + 698 - 1053 + 1268] = I("浶娒湈", "DOkeR");
      I[912 + 976 - 1074 + 580] = I("!\u0003(\n5! &\f#", "RwIcG");
      I[526 + 448 - 691 + 1112] = I("\u0017..\u001d>", "tFKnJ");
      I[1344 + 64 - 810 + 798] = I("垜捋", "MAiih");
      I[397 + 425 - 285 + 860] = I("\u0001\u00106\u000b;", "bxSxO");
      I[564 + 1127 - 1446 + 1153] = I("?\u00031\u0012\u001b\"\b0>\u0018$\u00140", "MfUao");
      I[684 + 745 - 120 + 90] = I("栟漕樖", "gELkZ");
      I[95 + 348 - -672 + 285] = I("挄汧件瀟", "pxErA");
      I[495 + 910 - 864 + 860] = I("\u0005?=\u000b5\u00184<<4\u0004.", "wZYxA");
      I[688 + 543 - 315 + 486] = I("0:78+:7\t:61", "TSVUD");
      I[270 + 235 - 6 + 904] = I("廜势剽岶榲", "qGZWZ");
      I[1023 + 880 - 1081 + 582] = I("澬", "RkwvW");
      I[237 + 932 - 525 + 761] = I("\u0016\u0013\u00125<\u0018\f\u0018\u001f1", "yawqU");
      I[171 + 430 - -429 + 376] = I("78\u00165-=5(:.<2\u001c", "SQwXB");
      I[981 + 486 - 678 + 618] = I("桹嘅", "HiEjK");
      I[170 + 178 - -265 + 795] = I("娈", "WWite");
      I[474 + 77 - -631 + 227] = I("劐擰墒仁泆", "GNyDw");
      I[908 + 537 - 336 + 301] = I("\u0011\u001e+\u000497\u001b%\n=\u001d\u0016", "srDgR");
      I[1137 + 683 - 833 + 424] = I("\u0010\u0013\u00136\u0013\u001a\u000f\u0015\u000f\u0013\u0012\u0003\u001e5", "sarPg");
      I[1085 + 640 - 1267 + 954] = I("殓", "LpfSR");
      I[126 + 1300 - 174 + 161] = I("势显棿", "bsXZG");
      I[973 + 993 - 1304 + 752] = I("掋慪", "zznbE");
      I[329 + 675 - -411 + 0] = I("烋", "mgaaK");
      I[579 + 1392 - 1178 + 623] = I("<\r\u001a\u0019:.\f\u000b\u001a", "KbhrX");
      I[585 + 924 - 1154 + 1062] = I(":\u000e\u0000\u0015.", "MfetZ");
      I[582 + 268 - -44 + 524] = I("揢偍棒渗墒", "UnHht");
      I[428 + 171 - -247 + 573] = I("棐智", "VVGlo");
      I[798 + 92 - 685 + 1215] = I("7$7!\u0010", "TVXQc");
      I[1255 + 738 - 1153 + 581] = I("烀漒嫥悢壘", "TqQKU");
      I[104 + 1337 - 1144 + 1125] = I("濒栤則", "CuBvT");
      I[618 + 843 - 1019 + 981] = I("巉毥椭", "OgbZG");
      I[367 + 1416 - 566 + 207] = I("$\r\u0000\u0015&#\u0002\u0016", "BlrxJ");
      I[772 + 1269 - 1272 + 656] = I("0#\u0004+!7,\u0012", "VBvFM");
      I[129 + 444 - -402 + 451] = I("\n\u0004\u0011\u001d+\u000f\u0014", "lqcsJ");
      I[1004 + 1402 - 1625 + 646] = I("乌呡产戮", "zVMvU");
      I[1265 + 526 - 634 + 271] = I("檍愺学廌", "xYnzd");
      I[908 + 1389 - 2292 + 1424] = I("匊托捑", "rqDzk");
      I[1207 + 43 - 1228 + 1408] = I("':*\u0007%\"*", "AOXiD");
      I[195 + 480 - -454 + 302] = I("5\f\u0001\u0017\u0004,\u0017\u001b)\u0001<", "YeuHb");
      I[808 + 773 - 616 + 467] = I("亀漥噛嵑", "TDrQZ");
      I[154 + 1384 - 824 + 719] = I("毭呛欳捇洠", "dGmlz");
      I[1340 + 766 - 954 + 282] = I("婨厱庑奬", "LmAeX");
      I[861 + 430 - 1190 + 1334] = I("\u0010%:\u0005\u000e\u00155", "vPHko");
      I[100 + 745 - 186 + 777] = I(";5\u0006\u0019)!/\u0000(>!&\t", "HAgwM");
      I[1181 + 769 - 541 + 28] = I("櫌孬幮", "BEWVa");
      I[348 + 420 - -464 + 206] = I("坖撻拶憰垎", "XZlJH");
      I[726 + 224 - 933 + 1422] = I("嘭岴惄瀉掬", "gZiao");
      I[632 + 91 - 105 + 822] = I("殫宜", "KWmiM");
      I[264 + 98 - -46 + 1033] = I("\u001f-\b\u001b", "lDouI");
      I[240 + 1330 - 838 + 710] = I("\u0005\r=1\u0015\u001c=6:\u001f\u0000", "rbRUp");
      I[1133 + 1069 - 1803 + 1044] = I("底岫", "nCJrk");
      I[1242 + 1397 - 1670 + 475] = I("厪傠", "TilqR");
      I[264 + 599 - -108 + 474] = I("凜瀬刃", "mlfdg");
      I[1418 + 272 - 1557 + 1313] = I("噻叇昙樏", "lNLoV");
      I[1383 + 1153 - 1424 + 335] = I("劼", "jNrDp");
      I[301 + 530 - 154 + 771] = I("6=\u0016'\u001639", "RRyUY");
      I[1366 + 535 - 902 + 450] = I("\u0019.\n<\u0010\u0007", "uOnXu");
      I[806 + 613 - 466 + 497] = I("彏囲敷", "WRjSg");
      I[1224 + 938 - 1452 + 741] = I("抨仹煬溫", "kdZuw");
      I[197 + 688 - -37 + 530] = I("呤灢櫓娻", "JXGVw");
      I[112 + 642 - 278 + 977] = I("屗", "GvBGy");
      I[1352 + 720 - 768 + 150] = I("慯推侖浒丣", "DmWDm");
      I[639 + 94 - -211 + 511] = I("%+,\u000f\u0016;", "IJHks");
      I[483 + 617 - 917 + 1273] = I("07 \u001d", "BVIqW");
      I[1029 + 608 - 814 + 634] = I("再捪烛奊", "eVtgy");
      I[164 + 191 - -531 + 572] = I("废沂旓娊厹", "hRYbW");
      I[60 + 217 - -526 + 656] = I("岲尊宂", "kpvgi");
      I[29 + 0 - -297 + 1134] = I(": *$", "HACHn");
      I[788 + 509 - 1021 + 1185] = I("5\u00107:)\u0019\u0017,5%4\u0017", "FdXTL");
      I[114 + 81 - -166 + 1101] = I("枨乼喂仆", "XXiVK");
      I[1226 + 948 - 1096 + 385] = I("寀恑敬放", "DnOQs");
      I[54 + 757 - 372 + 1025] = I("土", "VCvma");
      I[1277 + 536 - 608 + 260] = I("6\f\f:\u00046+\u0019<\u0018 ", "ExmSv");
      I[659 + 903 - 970 + 874] = I("\u000f \"$\u0010\u000b()&", "xANHO");
      I[431 + 759 - 577 + 854] = I("寔婣俧", "VWXdN");
      I[1299 + 1322 - 1329 + 176] = I("\u0001\"\u0015\u000b", "rKreE");
      I[288 + 44 - 268 + 1405] = I("\u00026\u0004\u0003\u001b", "nSrfi");
      I[859 + 438 - 53 + 226] = I("垟", "AZWkG");
      I[907 + 1028 - 562 + 98] = I("欃嚂洸哹孠", "NkiDI");
      I[238 + 787 - 996 + 1443] = I("帩憅廦掐", "bfBrM");
      I[550 + 567 - 215 + 571] = I("=+\u0003.\u0017", "QNuKe");
      I[1100 + 1366 - 1334 + 342] = I("\n&6\u0000\n&\"+\u000b\u001c\n'+\u000b0\t>8\u001a\n", "yRYno");
      I[310 + 1178 - 1348 + 1335] = I("彠呎", "bZqvb");
      I[11 + 775 - -179 + 511] = I("旴嬉嬤峌", "lBvoi");
      I[1270 + 1289 - 1611 + 529] = I("嚶崾庙嵆", "gEgWR");
      I[1297 + 1321 - 1334 + 194] = I("帠榁檉", "TpkWQ");
      I[240 + 1460 - 1656 + 1435] = I("掻勗", "trHoc");
      I[833 + 952 - 766 + 461] = I("\u0011(.\u00107\u0014(.3(\u0000..00\u000e4.", "aZKcD");
      I[934 + 1237 - 1226 + 536] = I("\u001a\u00069\b2\u0017\u001b9\u0014", "stVfm");
      I[208 + 1169 - 543 + 648] = I("柸堟夝执斾", "FDSBL");
      I[470 + 872 - 28 + 169] = I("捸", "dknAM");
      I[1351 + 1444 - 2159 + 848] = I("\u000e:\u001a\u00020\u0018:\u001b", "jUupy");
      I[1227 + 835 - 1594 + 1017] = I("%\u001e.(<<.1><!\u00024><\r\u0001---7", "RqALY");
      I[404 + 1030 - 72 + 124] = I("澥惘梐", "qOkNP");
      I[1414 + 1033 - 2133 + 1173] = I("巬榜冁", "FnMro");
      I[437 + 1479 - 632 + 204] = I("擥憾泭喅佝", "cAYue");
      I[338 + 452 - -525 + 174] = I("\u001f(\u0006\n\u0017\u001a(\u0006)\b\u000e.\u0006.\u000b\u0000>", "oZcyd");
      I[607 + 756 - 1240 + 1367] = I("&\u0012\u00039=;\u0019\u0002\u0015&&\u0012", "TwgJI");
      I[1436 + 1206 - 1562 + 411] = I("嫟埴", "Mnjsc");
      I[75 + 22 - -916 + 479] = I("圓云泛唠导", "TTcsr");
      I[502 + 365 - 818 + 1444] = I("57\"\u001c\u0014>63!\u001f?", "ZEGNq");
      I[623 + 1280 - 1458 + 1049] = I("\u0005<\u0006\u000e\u0006\f1\u0001%\u001b\u00070->\u0006\f", "iUrQt");
      I[291 + 624 - 562 + 1142] = I("冟娡婇", "JUMty");
      I[1467 + 953 - 2190 + 1266] = I("櫇塇", "rZApI");
      I[1420 + 213 - 904 + 768] = I("\u000e\n6\u001f4\u0005\u000b'\"?\u0004", "axSMQ");
      I[1021 + 1424 - 2097 + 1150] = I("'\f\u000b\u001e\u001a\r\u0010\u0002\u0013\u001d&\r\t\u00121&\r\u0015\u0014\u0006", "Rbgwn");
      I[946 + 981 - 569 + 141] = I("徾峪仁", "yveug");
      I[124 + 1097 - 761 + 1040] = I("桚梟涘", "pEeBj");
      I[138 + 317 - -535 + 511] = I("\u0019\u0015\u001b0\u0003\u0003\u001f", "wzowb");
      I[871 + 572 - 764 + 823] = I("16\u0006\t\u0012,=\u0007%\u0012,!\u0001\u0012", "CSbzf");
      I[1385 + 902 - 1627 + 843] = I("橻", "zklNo");
      I[1462 + 117 - 1050 + 975] = I("\u0006\u00076.;\u001c\r", "hhBiZ");
      I[273 + 187 - -555 + 490] = I("\u0005\u0004\u0018\t2)\u0012\u0002\u0013#\u0019\u001e", "vpwgW");
      I[266 + 510 - 565 + 1295] = I("唂效故", "nSmAS");
      I[137 + 1111 - 63 + 322] = I("僆佩忱匟僉", "gWyDO");
      I[433 + 1040 - 428 + 463] = I("夕岒凍樑", "rGKAK");
      I[181 + 157 - -740 + 431] = I("圷", "fwZXg");
      I[1460 + 443 - 1409 + 1016] = I("2\u00067?->", "PsCKB");
      I[1043 + 95 - 11 + 384] = I("&\u0018\u00190\u000b9\u0017\u000f\"&", "UvvGT");
      I[2 + 472 - -1038 + 0] = I("汘匣剃", "WAJmo");
      I[1216 + 513 - 1002 + 786] = I("枋斩忳", "bAXfS");
      I[422 + 479 - 866 + 1479] = I("吢榯吹懆嬩", "joZdv");
      I[1155 + 1080 - 2207 + 1487] = I("6'\u0006;", "EIiLQ");
      I[1273 + 17 - 679 + 905] = I("&:$", "OYAco");
      I[1236 + 203 - 630 + 708] = I("伕勰歳懧惶", "pPrxG");
      I[669 + 632 - 528 + 745] = I("拴濗", "cBxJn");
      I[1411 + 233 - 1338 + 1213] = I("嘚", "VkBaA");
      I[1487 + 540 - 543 + 36] = I("咠姿愭撀澂", "qvRFh");
      I[1222 + 563 - 432 + 168] = I("<,\u0014", "UOqtc");
      I[516 + 1197 - 1356 + 1165] = I("%+&5", "VEIBk");
      I[242 + 97 - -1163 + 21] = I("挩娛埁洰", "nxMKg");
      I[1083 + 260 - 696 + 877] = I("屶拯槰傘", "QWtwo");
      I[542 + 1064 - 319 + 238] = I("劳槄", "rqmGa");
      I[847 + 1190 - 745 + 234] = I("嗋檄剋巜", "pmOVx");
      I[771 + 475 - 350 + 631] = I("'&+\u001a", "THDmy");
      I[196 + 1108 - 226 + 450] = I("5-(\u0017\u0004%", "VLKcq");
      I[547 + 748 - 1057 + 1291] = I("慤", "HHlKj");
      I[314 + 670 - -233 + 313] = I("澹掿戊妄", "LXrFK");
      I[79 + 53 - -123 + 1276] = I("剋劀洽梸", "vVSFa");
      I[162 + 380 - -25 + 965] = I("俷", "FOAdB");
      I[301 + 1403 - 271 + 100] = I("\u0017#;\u001b\u0010\u0007", "tBXoe");
      I[1250 + 263 - 1139 + 1160] = I("\u0007.0*", "dBQSs");
      I[788 + 1109 - 808 + 446] = I("憡侽", "dQexO");
      I[1021 + 1053 - 1598 + 1060] = I("伮佺懯嵇冃", "YhIbL");
      I[1268 + 1470 - 1475 + 274] = I("\u00178*!", "tTKXx");
      I[630 + 629 - 297 + 576] = I("+?*\u001c1", "YZOxB");
      I[814 + 1330 - 864 + 259] = I("嵒悂庅乡", "duqLg");
      I[1259 + 910 - 1896 + 1267] = I("妐嬶吡仛橩", "cMBxG");
      I[750 + 1207 - 786 + 370] = I("烚煬来", "eJeFm");
      I[869 + 175 - 332 + 830] = I("\n\"#\u0005#", "xGFaP");
      I[588 + 294 - -249 + 412] = I("0\u001a\u0001185\u0017", "ZojTZ");
      I[1462 + 1213 - 2051 + 920] = I("檈", "WgLrw");
      I[51 + 1126 - 648 + 1016] = I("湋愞", "veXxI");
      I[1100 + 684 - 1183 + 945] = I("濢圥泰", "ycibL");
      I[910 + 1372 - 1286 + 551] = I("忿", "gLdcZ");
      I[1322 + 1120 - 1671 + 777] = I("\u0002\u0007\f&\u0014\u0007\n", "hrgCv");
      I[791 + 888 - 552 + 422] = I("\"1#\u00131", "DTMpT");
      I[1284 + 352 - 244 + 158] = I("偯栙溻", "sBDsj");
      I[601 + 895 - 286 + 341] = I("樟墚梇廆", "LgAAJ");
      I[430 + 710 - 911 + 1323] = I("\u0003$-\u0000\u0013", "eACcv");
      I[411 + 928 - 588 + 802] = I("橹撬僻", "qzZzT");
      I[1408 + 264 - 1224 + 1106] = I("氡椧", "pgZAq");
      I[1431 + 190 - 369 + 303] = I("漭淨偭檀冨", "ccbBm");
      I[1010 + 106 - 766 + 1206] = I("7/\u001e\u0013\u001c.4", "GZscw");
      I[781 + 1428 - 1245 + 593] = I("%%\u001d2\u001d<>", "UPpBv");
      I[663 + 392 - 14 + 517] = I("\u001c\u0011\u0018\u0001<\u0000\u0006\r\n2", "rtliY");
      I[259 + 1421 - 128 + 7] = I("椺嶮彩嘑戛", "IakkQ");
      I[1422 + 1451 - 1806 + 493] = I("/\b\u001c8\n(\u000e\u001b", "GmpTx");
      I[663 + 604 - 677 + 971] = I("\t\u001e2\t1\t\u0010)\u0001", "zqGen");
      I[989 + 1145 - 1362 + 790] = I("壗勾槭", "LVARQ");
      I[428 + 46 - -216 + 873] = I("\u000f*98?\u0006!1", "gOUTL");
      I[1117 + 741 - 485 + 191] = I("\u0010+\u000e  \u0003(\u000f2", "wGaWS");
      I[697 + 1190 - 478 + 156] = I("亥冯圯污沅", "ITrgi");
      I[1158 + 922 - 514 + 0] = I("櫇夗扒", "seElC");
      I[98 + 1474 - 453 + 448] = I("洏", "fAqGP");
      I[624 + 424 - -375 + 145] = I("8\u0019\u0004\u0010\u001a3\u0015\u000e", "Tpcxn");
      I[1083 + 1184 - 1039 + 341] = I("\u001e\u00183\";\u0002", "nwAVZ");
      I[1169 + 71 - 581 + 911] = I("毑劬", "TPsTC");
      I[1072 + 387 - 1177 + 1289] = I("二", "ElYLW");
      I[506 + 139 - -36 + 891] = I("\"& \u0000\u0011>", "RIRtp");
      I[652 + 986 - 1207 + 1142] = I("\u0018!\u001b&\u0012\u0001%\u001f\u0012\u000b\u001a", "tHoyb");
      I[821 + 1551 - 1704 + 906] = I("发呝媪恢揆", "YHJMw");
      I[524 + 1275 - 323 + 99] = I(" \u0004\u00058\u0012!\u001d\u001a!\t", "LmqHg");
      I[56 + 860 - 6 + 666] = I("\u0007\u0017*\u0010", "dvAua");
      I[196 + 1124 - 956 + 1213] = I("暝濽坬棑伞", "bzXWC");
      I[1186 + 911 - 1440 + 921] = I("卹弭", "oEXrY");
      I[248 + 459 - -429 + 443] = I("\u0005;\u001c\u0011", "fZwtW");
      I[775 + 75 - -450 + 280] = I("8?>\u000e\u0006(#+\u0005.?4>\u0004\u001094<", "MQNaq");
      I[144 + 164 - -822 + 451] = I("擃", "ykDSc");
      I[1093 + 1165 - 1018 + 342] = I("汏", "rYWsd");
      I[1270 + 497 - 1586 + 1402] = I("彾杚", "rxWZY");
      I[815 + 609 - 831 + 991] = I("係濄境栛", "VVvyp");
      I[1533 + 223 - 1027 + 856] = I("6$\t6\u0004", "RMfRa");
      I[1133 + 84 - 496 + 865] = I("3\u00000\b\n&\u000b\u0018\u001f\u001d3\n&\u0019\u001d1", "CoGmx");
      I[822 + 314 - 848 + 1299] = I("漥樑數", "ZcjPJ");
      I[256 + 736 - 296 + 892] = I("掊嘃弧呤", "qrqEd");
      I[716 + 273 - -141 + 459] = I("\u0002\u001b\r\u00117", "frbuR");
      I[895 + 1029 - 342 + 8] = I("\u0014\"-\u00196\u00022\u0013\u00174\u0006%?", "gVLpX");
      I[217 + 484 - 668 + 1558] = I("嗹嗟", "sxvHs");
      I[1051 + 945 - 1508 + 1104] = I("\u001d33\u001b\u0014\u000b#\u0015\u001e\u001b\u001d4", "nGRrz");
      I[1074 + 1528 - 1736 + 727] = I("2\u0010&\t,)\r5", "FbGyH");
      I[410 + 1055 - 990 + 1119] = I("潅", "hMaZl");
      I[1155 + 292 - 508 + 656] = I("怇幞", "BEFYq");
      I[490 + 837 - 1060 + 1329] = I("嗁歏", "dGTIu");
      I[721 + 562 - -195 + 119] = I("懍嗥吸棒惲", "jpiXc");
      I[1432 + 106 - 576 + 636] = I("$\u0006\n%#?\u001b\u0019", "PtkUG");
      I[844 + 1596 - 1122 + 281] = I(":\f49$2\u0011\u0005/70", "WcZJP");
      I[185 + 1393 - 937 + 959] = I("喹掟勵", "nTaEw");
      I[1165 + 441 - 1467 + 1462] = I("昑", "APaEc");
      I[1161 + 1444 - 1064 + 61] = I("\b#\u001a\u0017\u001f\u0000>'\u0010\u0004\u000b)1\u0003\f", "eLtdk");
      I[1053 + 14 - -66 + 470] = I("瀸", "IPerT");
      I[378 + 497 - -563 + 166] = I(">#\u001f\u001c#/%\u0019\u0011->:\u001f\u001d2%", "MWprF");
      I[134 + 1024 - 1070 + 1517] = I(":\u0018,\u0005.+\u001e*\b ", "IlCkK");
      I[627 + 92 - 364 + 1251] = I(" \u0004%\r\f\u001d\u001b?\t\n0\u0019%\u0017= \u001a%\u0019\t", "BvJzb");
      I[375 + 483 - 321 + 1070] = I("潖峮", "TpZOu");
      I[708 + 1312 - 1149 + 737] = I("瀵", "aXofm");
      I[1275 + 1439 - 1133 + 28] = I(" \u0011*/&\"\u000b4", "MdYGT");
      I[1277 + 919 - 731 + 145] = I("6\u001f%\u0012+1\t)?)+\u0017\u001e/*+\u0019*", "DzAMF");
      I[1362 + 1031 - 1923 + 1141] = I("兆", "TwYbj");
      I[1348 + 811 - 1444 + 897] = I("埈劭涅刕坕", "ksQKb");
      I[1507 + 1187 - 2198 + 1117] = I("憠沚濰涙涪", "NrLAI");
      I[810 + 658 - 802 + 948] = I("<\u001f>\u001e\u0000>\u0005 ", "QjMvr");
      I[122 + 937 - 317 + 873] = I("\u0018\u0006\u0016\u000f9\u0013\u0015\u000b\u0012", "qtyaf");
      I[1404 + 392 - 1631 + 1451] = I("劓", "rFMgS");
      I[1195 + 875 - 1245 + 792] = I("$\u001f%\n/\u000b\b$\u0007", "BzKiJ");
      I[483 + 1453 - 1537 + 1219] = I("+\"-\u0002!\u0013>-\u001f7", "LNLqR");
      I[995 + 136 - 571 + 1059] = I("呹斫", "gVUaR");
      I[1532 + 785 - 1181 + 484] = I("型幓", "SZiNz");
      I[610 + 972 - 578 + 617] = I("弢橍", "DqbKr");
      I[358 + 1255 - 827 + 836] = I("2\u0019!+1*\u0010;6", "FqHEv");
      I[939 + 9 - -599 + 76] = I("匣毻檚怊啾", "smLGe");
      I[401 + 234 - -207 + 782] = I("唥檙毋囬", "gBOfe");
      I[199 + 653 - -770 + 3] = I("樜嵪居", "SmWyZ");
      I[197 + 714 - -412 + 303] = I("',\u001d\u0000#", "JIqoM");
      I[1147 + 1483 - 1861 + 858] = I("\b\u00125=&:\u00155=+\u000e", "ewYRH");
      I[1301 + 336 - 1501 + 1492] = I("96\u001e#\u001c -, \u0003,.", "ICsSw");
      I[1109 + 722 - 1531 + 1329] = I("夜侌", "ZmkhI");
      I[667 + 1075 - 897 + 785] = I("刔払呫", "bhMbq");
      I[711 + 1412 - 1493 + 1001] = I("埕淊擆", "uYiFu");
      I[1030 + 1077 - 1687 + 1212] = I("=>):($%\u0017>& ", "MKDJC");
      I[1117 + 529 - 957 + 944] = I(";\r\n\u0003 \t\u001b\u0012\t#", "VhflN");
      I[457 + 358 - 347 + 1166] = I("挾欩", "ICopQ");
      I[479 + 1502 - 1656 + 1310] = I("!\u000f\u001b<\u001d8\u0014%8\u0013<", "QzvLv");
      I[705 + 1585 - 836 + 182] = I("\u0014\u0010\u0007\f", "byiiU");
      I[1605 + 135 - 1650 + 1547] = I("桹拥幁", "MBZaQ");
      I[1629 + 1291 - 1693 + 411] = I("扰", "biyLc");
      I[139 + 1063 - 319 + 756] = I("椆圁吹", "oaMWl");
      I[511 + 1270 - 270 + 129] = I("#\u0004>\u000f", "UmPjB");
      I[1543 + 413 - 361 + 46] = I(")/\u001c5\u0007\u0010-\u0013\"\u0007", "OJrVb");
      I[1256 + 739 - 971 + 618] = I("櫝", "eizjH");
      I[745 + 595 - -160 + 143] = I("永", "BqTvF");
      I[628 + 552 - -47 + 417] = I("\u0011\u0004;\u0007$0\u0000!\u0001", "waUdA");
      I[1230 + 528 - 285 + 172] = I("2\u0019 \t9\u000f\u0018=\u000b;\"\u0018", "PkIjR");
      I[322 + 925 - 818 + 1217] = I("吠俶咎烹孠", "AzPUf");
      I[1462 + 132 - 411 + 464] = I("汽喧汄婭", "HYmDz");
      I[931 + 1175 - 2069 + 1611] = I("堺撶煠", "UMNdS");
      I[1305 + 992 - 2272 + 1624] = I("戶", "oFXYY");
      I[709 + 1437 - 2098 + 1602] = I("\u001a\u0005//6\u001a3</'\u0002", "iqNFD");
      I[268 + 692 - 607 + 1298] = I("#\u0011\u0006\u0001\u0010\u000f\u0007\u001b\u0006\u0016;:\u001a\u001b\u00149\u0017\u001a", "Peiou");
      I[951 + 131 - 975 + 1545] = I("怬决劶儬", "hbEgI");
      I[517 + 678 - 1193 + 1651] = I(" \u0002\u0005\u00020 %\u0010\u0004,64\u0016\u0002!8%\t\u0004-'\u001e", "SvdkB");
      I[101 + 1620 - 149 + 82] = I("\t \n\u0014?\r,\u0004", "dYiqS");
      I[748 + 152 - 420 + 1175] = I("塒壬嬱", "frVKq");
      I[1531 + 1347 - 1433 + 211] = I("\u001e *\u000b*", "sYInF");
      I[1583 + 475 - 1552 + 1151] = I("\u001f&9 #\u0004.!<", "hGMEQ");
      I[969 + 970 - 341 + 60] = I("尭唹栊", "furcJ");
      I[804 + 1380 - 1098 + 573] = I("囤", "DeBAT");
      I[809 + 738 - 331 + 444] = I("\u001e-2\"\u001e\u0005%*>", "iLFGl");
      I[1144 + 981 - 928 + 464] = I("暏氢己尴奷", "WgZnq");
      I[665 + 353 - -79 + 565] = I("末", "kUUTM");
      I[621 + 895 - 578 + 725] = I("(\u001d7\u001a 4:1\u001b&-", "FxCrE");
      I[769 + 687 - 67 + 275] = I("-.>$31\u0014(>?  ", "CKJLV");
      I[974 + 820 - 1304 + 1175] = I("!\"\u001c\u0007 =\u0018\n\u001d,,,7\t !$\r", "OGhoE");
      I[1614 + 789 - 1340 + 603] = I("哓杶氁", "RCxwR");
      I[1628 + 795 - 2306 + 1550] = I("\n\u000f$-\u000f\u0016,5+\t\u0001", "djPEj");
      I[1642 + 447 - 578 + 157] = I("\n\u000b\u000e\u0003\u001f\u00161\u0018\u0019\u0013\u0007\u0005%\u0018\u000e\u0005\u0007\b\u0018", "dnzkz");
      I[568 + 135 - -887 + 79] = I("忚涇", "LSopQ");
      I[1459 + 460 - 1370 + 1121] = I("\u001d1\n$:\u001d\u000b\u000e9 \u000b7)?!\r.", "nEkMH");
      I[969 + 48 - 539 + 1193] = I("!\u0016\u0005+==,\u0006\"*;", "OsqCX");
      I[1491 + 985 - 2090 + 1286] = I("嗐唝圞", "ofqJW");
      I[1368 + 1385 - 2445 + 1365] = I("宅旿殭埬", "UyGuW");
      I[1075 + 338 - 511 + 772] = I("\t<?\u00123\u0015\n?\u001b:\f", "gYKzV");
      I[1421 + 1446 - 1773 + 581] = I(".+\n\u001a\u000f%1\u0000\u001c\t\u00141\b\u0010\u0002.", "KEirn");
      I[1591 + 406 - 1809 + 1488] = I("殷帽斆櫻攂", "YXOuO");
      I[509 + 1472 - 625 + 321] = I("免曹彡撎", "hMjUh");
      I[1234 + 1129 - 2153 + 1468] = I("\f%5\u0006%\u0007?;\u000b*\u001d\u001f7\f(\f", "iKVnD");
      I[863 + 454 - 367 + 729] = I("!\u0011\u0017\u0005 -\u0004-\u0001=\"\r\u0016", "CcrrI");
      I[430 + 1275 - 261 + 236] = I("叀朖妉堐", "EGGFK");
      I[1189 + 555 - 664 + 601] = I("厔垘忩嶘杤", "kxeBc");
      I[792 + 171 - -599 + 120] = I("烺亶淵拔", "eYTPP");
      I[363 + 1469 - 869 + 720] = I("\u000177\u0018\r\r\"\u0001\u001b\u0005\r!", "cERod");
      I[1440 + 1532 - 1605 + 317] = I("\u0000\r\f\u00073\u0011\u0003\u0017", "clykW");
      I[1486 + 610 - 879 + 468] = I("桙曪坿嫍毇", "jsSAZ");
      I[532 + 577 - -62 + 515] = I("涻汁", "KSTIl");
      I[69 + 672 - 113 + 1059] = I("\u00069\u001d+%\u00177\u0006", "eXhGA");
      I[468 + 271 - -786 + 163] = I("\u0001\u00194\u001e:\u000b\u0005$ &", "dwPAJ");
      I[1329 + 467 - 1667 + 1560] = I("橀", "jnlmB");
      I[1656 + 656 - 1575 + 953] = I("宆桔悴", "rNVLF");
      I[1083 + 106 - -34 + 468] = I("樆彽惈懗渷", "fhECF");
      I[903 + 1559 - 2115 + 1345] = I("\r\u0002&:*\u0007\u001e6\u000467\n0\u00047\r", "hlBeZ");
      I[5 + 8 - -194 + 1486] = I("司嘵", "XCqcB");
      I[1481 + 580 - 698 + 331] = I("檌", "VkECf");
      I[344 + 988 - 9 + 372] = I("傤戳煉晞榿", "OCdON");
      I[535 + 1467 - 930 + 624] = I("帤溈", "woejS");
      I[1633 + 562 - 1913 + 1415] = I("叄卪", "PdWNx");
      I[288 + 682 - 442 + 1170] = I("$%\u000b\u001a53?\u000e&\u001c3*\u0002/", "AKoJZ");
      I[782 + 1309 - 791 + 399] = I("$\n\u001e\n 5\u000b\u00140", "AdzUS");
      I[715 + 319 - -194 + 472] = I("伌嶻", "XRJrt");
      I[322 + 169 - -1044 + 166] = I("暆斪样溒塟", "jsEAH");
      I[1398 + 466 - 715 + 553] = I("炟", "wMTaQ");
      I[565 + 449 - -623 + 66] = I("彪滪抢", "eMgcN");
      I[685 + 957 - 1575 + 1637] = I(" \u000e\u001b\u0011#\u0004\u0012\u001d\u000b#", "WfreF");
      I[1145 + 126 - 853 + 1287] = I("4\u001e6\u000e\u0018>32\u000e\u0010", "PlWiw");
      I[852 + 1054 - 1245 + 1045] = I("扚", "TqQmk");
      I[1106 + 552 - 327 + 376] = I("橝凙媰瀝", "EiuYK");
      I[978 + 1501 - 1277 + 506] = I("毉嚡懧椽櫞", "crJHV");
      I[299 + 621 - -315 + 474] = I("!\u001a\u000f\u000e\"+-\t\u000e", "EhniM");
      I[1198 + 1377 - 983 + 118] = I("\u001475>\u0000\t<4\u0012\u0018\u0007?!", "fRQMt");
      I[545 + 970 - 1188 + 1384] = I("厚嶜唘倷刞", "EDxbJ");
      I[1179 + 1295 - 1586 + 824] = I("囖嘾", "ekzhs");
      I[571 + 461 - 877 + 1558] = I("屬", "qsvak");
      I[428 + 1611 - 1666 + 1341] = I("圼", "zOVDg");
      I[766 + 1646 - 1114 + 417] = I("7-\b\u0002\u0001*&\t=\u001c\" \u0018", "EHlqu");
      I[252 + 686 - 520 + 1298] = I("&\f6\n&/\u00011!;$\u0000\u001d95'\u0015", "JeBUT");
      I[740 + 667 - 1016 + 1326] = I("楘泧憧彗", "PctyJ");
      I[1585 + 758 - 2101 + 1476] = I("唑柪墧屵", "JOoAF");
      I[790 + 1374 - 593 + 148] = I("埀孪撞", "wjqOc");
      I[90 + 971 - 480 + 1139] = I("嶋啳挫啌", "xgjSp");
      I[1223 + 1018 - 1463 + 943] = I("擏楰", "suBpu");
      I[340 + 373 - -893 + 116] = I(" \u0010=\u001f\u0017=\u001b< \n5\u001d-", "RuYlc");
      I[593 + 1129 - 1613 + 1614] = I("\u000f(\u001d'6\u000e\u0018\u001f*5\u000f\"\u0006\u001a)\u0007&\n", "kGhEZ");
      I[1382 + 983 - 1024 + 383] = I("嶶学垲怔橥", "UAIsA");
      I[174 + 956 - 430 + 1025] = I("壧此唳濆灋", "OMfEq");
      I[1564 + 189 - 287 + 260] = I("嶎瀊庙", "GTjeS");
      I[1639 + 1635 - 3076 + 1529] = I("\u0012\"\u0016\u0002\t\t,\u001b", "eMyfZ");
      I[693 + 1398 - 682 + 319] = I("\" \u0007=0;\u0010\u001b547", "UOhYU");
      I[838 + 546 - 937 + 1282] = I("悰弑坤", "TaYvw");
      I[199 + 1501 - 1383 + 1413] = I("凜廂", "PPmKs");
      I[580 + 869 - 1009 + 1291] = I("'\u0006-\u000f\t<\b ", "PiBkZ");
      I[540 + 1121 - 659 + 730] = I(":,\u0014:0", "YCwUQ");
      I[195 + 1368 - 1010 + 1180] = I("攃", "nTDDd");
      I[935 + 1325 - 2244 + 1718] = I("'&$(\u0013", "DIGGr");
      I[1500 + 755 - 1064 + 544] = I("\u0010\u000e!)\u0019\u0017\u0000!(5\u0010\u001b.$\u0018\u0010", "coOMj");
      I[881 + 239 - 857 + 1473] = I("倠摍櫢洬", "lYHlu");
      I[37 + 610 - -234 + 856] = I("\u0015\u0018\u000f\u00189\u0015?\u000f\u001f/5\u0018\u0001\u001f.", "flnqK");
      I[116 + 1239 - 1181 + 1564] = I("\u0010!6\u0013\u000f\u0019(\f\u000e\u001c\u0010", "uLSan");
      I[775 + 194 - -734 + 36] = I("溶寢", "AQSDZ");
      I[1532 + 984 - 1854 + 1078] = I("俜殎", "ZBlyA");
      I[1224 + 1444 - 1273 + 346] = I("\u001f(31\u000f\u0015(7\u0018\u0006", "pZVtb");
      I[664 + 188 - -416 + 474] = I("\f'\u000b\u001666*\u0007\u00167\u001d", "iIosD");
      I[7 + 1289 - 863 + 1310] = I("働峿渋斪壿", "IYnuw");
      I[708 + 1664 - 1010 + 382] = I("殔倯", "Xgswy");
      I[1449 + 1231 - 1440 + 505] = I("'$\u0014=?\u0001\"\u0015+9", "BJpXM");
      I[603 + 275 - 258 + 1126] = I("\u0007'\u000b\u0001\u0005\u001a'\u0007.\u001a\u001c:\t", "sUbqr");
      I[1023 + 521 - 315 + 518] = I("捨勏刞低", "LrzhI");
      I[866 + 503 - 998 + 1377] = I("嚺楉", "faEEo");
      I[201 + 96 - 231 + 1683] = I("夔擿寽喼", "gjffC");
      I[283 + 211 - -1115 + 141] = I("\u0007\u0003\u001f)4\u001a\u0003\u0013\n\f\u0006\u0003\u0015<", "sqvYc");
      I[1032 + 1092 - 712 + 339] = I("?\u001b\u0011\u00175\"\u001b\u001d", "KixgB");
      I[135 + 882 - 879 + 1614] = I("咨僠", "lwIDt");
      I[717 + 1156 - 1812 + 1692] = I("厺", "gXMVF");
      I[1646 + 245 - 607 + 470] = I("\u0005\u00158<\r\u0018\u00154", "qgQLZ");
      I[523 + 920 - 463 + 775] = I("<.?\u001d\u00165'\u0005\r\u001b6 1", "YCZow");
      I[1439 + 1277 - 1301 + 341] = I("咆儃暣泂埈", "kHfCB");
      I[336 + 1612 - 495 + 304] = I("懃潄", "xqeXg");
      I[310 + 494 - -363 + 591] = I("+\u000e \u0006\t\f\u000f*\u0017\u0003%\u0006", "IbOeb");
      I[1726 + 1361 - 1634 + 306] = I("\u0019;\u001f\u0018\u0014\u000f\u0014\u001e\u0019\u0016\u00039\u001e", "jKmmw");
      I[550 + 155 - -370 + 685] = I("壉佩灗愲僚", "waZfv");
      I[1315 + 196 - 48 + 298] = I("柳憓巈桼廚", "GeRge");
      I[337 + 110 - -959 + 356] = I("弴抌", "BMOMD");
      I[1007 + 420 - 52 + 388] = I("'\u0000906'#76 \u0007\u0004*,'1", "TtXYD");
      I[1162 + 561 - 956 + 997] = I("\r\u0006\u001c\t\u001d0\u001c\u001a\u000b\u001c\u001d\u001c", "oonju");
      I[664 + 974 - 451 + 578] = I("囆橼敞夷", "THQmW");
      I[67 + 250 - -109 + 1340] = I("?'*\u0004+?\u0004$\u0002=\u000e:9\u000e1", "LSKmY");
      I[1142 + 1140 - 2168 + 1653] = I("\u0013\u001c\f\r+\u001c6\u0011\u001e&\u0010\u001b\u0011", "yibjG");
      I[363 + 818 - -333 + 254] = I("勳晦", "jvSmC");
      I[41 + 1322 - 401 + 807] = I("圂杂兖巾", "vHxTT");
      I[394 + 1128 - 1261 + 1509] = I("俹屈棖", "Qznvz");
      I[1367 + 942 - 1072 + 534] = I("\u0016\u00106.\u0016\u001638(\u0000/\u00119 \b\u0000", "edWGd");
      I[334 + 513 - -248 + 677] = I("\u0006\u00064\u0006;\u000b\r\u0006\t6\n\n2", "eiYkZ");
      I[704 + 1584 - 639 + 124] = I("捀洯拤喓亝", "KaEKS");
      I[1678 + 595 - 708 + 209] = I("懰惓擢", "kWzlc");
      I[1537 + 36 - 342 + 544] = I("/\u0015\u0004;\u0006\"\u001e+:\b/\u0011", "LziVg");
      I[1703 + 393 - 2039 + 1719] = I("&<+36*", "DYJPY");
      I[396 + 1419 - 533 + 495] = I("佰憱侩", "yFikw");
      I[1463 + 1732 - 3191 + 1774] = I("升岴", "rbewL");
      I[1502 + 726 - 1901 + 1452] = I("椿栕", "tjurD");
      I[971 + 0 - 553 + 1362] = I("喡掊湚橌", "SfkjY");
      I[83 + 762 - -401 + 535] = I("\r/-\n\u0019\u0001", "oJLiv");
      I[143 + 1442 - 791 + 988] = I(";:\u0016\u0013\u0003=&\u0000\u001e\u0001=\n\u0003\u0010\u00034", "XUtqo");
      I[726 + 1647 - 898 + 308] = I("摸斪櫷", "fQiJZ");
      I[1673 + 760 - 1554 + 905] = I("\u0013\u0000\u0014\n&\u00158\u0017\u0004&", "povhJ");
      I[463 + 1006 - 121 + 437] = I(")>\u001e\u001e4=\r\u0001\u0006%", "ORqiQ");
      I[375 + 1426 - 1602 + 1587] = I("棛", "wIexJ");
      I[1120 + 577 - 973 + 1063] = I("峀兕昘檋撼", "tSWYJ");
      I[233 + 143 - -912 + 500] = I("\u00004 \u00076\u0014\b \u0004", "fXOpS");
      I[305 + 1274 - 448 + 658] = I("( \u000b5%?2", "KAyGJ");
      I[1091 + 1739 - 2810 + 1770] = I("庖儅孶憨", "Pxdac");
      I[648 + 859 - 259 + 543] = I("憞抏博洼塸", "hcVaV");
      I[1461 + 871 - 1921 + 1381] = I("!1\u00191\u00186#", "BPkCw");
      I[543 + 1190 - 978 + 1038] = I("\u0005\u000b\u0001\f7\u001a\u0001\u0006", "udumC");
      I[749 + 296 - -182 + 567] = I("梨煓梭嶑垶", "CeIKp");
      I[1566 + 784 - 1463 + 908] = I("澬棌唁", "ksEJo");
      I[1097 + 1738 - 2478 + 1439] = I("瀑杲溕", "PIPMA");
      I[745 + 147 - 752 + 1657] = I("妙娨堅恣", "XkMep");
      I[1330 + 1660 - 2432 + 1240] = I("\u0000*\u001e\u0012\u000e\u001f \u0019", "pEjsz");
      I[1157 + 958 - 961 + 645] = I("3\u001b\b.)*+\u0005?80\u001b\t", "DtgJL");
      I[175 + 1747 - 610 + 488] = I("岛", "WpkSA");
      I[910 + 1116 - 761 + 536] = I("壠条瀕", "MCPoW");
      I[1684 + 995 - 1338 + 461] = I("\u0018%$#6\u0014", "zPPWY");
      I[844 + 1080 - 1399 + 1278] = I("\u0003\u0011\u0010<:", "pzePV");
      I[748 + 1714 - 793 + 135] = I("呤歩源帚嗫", "LyYpq");
      I[173 + 1619 - 1744 + 1757] = I("丧煚櫫", "pZkvl");
      I[762 + 1344 - 1952 + 1652] = I("6)\u0013\u0018<", "EBftP");
      I[1076 + 808 - 1094 + 1017] = I("\u000644\u001b\u001b", "gZBrw");
      I[382 + 1158 - 853 + 1121] = I("檒煮", "CPvlR");
      I[635 + 861 - 1364 + 1677] = I("凃佱", "ZrJQM");
      I[1327 + 694 - 1741 + 1530] = I("1\u0017<<\u0000", "PyJUl");
      I[1294 + 1558 - 1951 + 910] = I("?\u0006\u0019 \u001b.\u0010'3\u0003.\u0007\f", "KtxPk");
      I[1790 + 917 - 2092 + 1197] = I("劂濯举撌", "KLkPG");
      I[1466 + 1281 - 1790 + 856] = I("\u001b<#\u001d\",&'\u001e", "xTFnV");
      I[755 + 1611 - 2200 + 1648] = I(":*\u000215\t4\u00000&>7\u0000=\u001e&1\u0000*2#1\u0000\u00061:\"\u0011<", "VCeYA");
      I[1037 + 271 - 702 + 1209] = I("枳幎揋扣", "bFYEq");
      I[259 + 1274 - 1403 + 1686] = I("態槂枷", "UMCQG");
      I[694 + 1365 - 1649 + 1407] = I("噿嗚朝峖点", "Ttivx");
      I[421 + 716 - 974 + 1655] = I("搒曽", "AZdbv");
      I[1249 + 1099 - 573 + 44] = I("9\u001d\f\u0006\u0000:\u001d\u00011\u0004/\f\u0000>\u0004'\u001f\r\u0015", "Nxeah");
      I[1449 + 1467 - 1428 + 332] = I("  \u000e\u001e;\u00172\n\u0001% 1\n\f\u001d87\n\u001b1=7\n72$$\u001b\r", "HEohB");
      I[1250 + 1271 - 1981 + 1281] = I("媦庍倄撍", "LKMkC");
      I[156 + 901 - -129 + 636] = I("劢日愋", "OeUnP");
      I[61 + 726 - -801 + 235] = I("\u00126\f\u0001/\u00116\u00016+\u0004'\u00009/\u00002\u0013\u001f", "eSefG");
      I[560 + 341 - -904 + 19] = I(">\u0001\u0017.9.\u001d\u0002%\u0011(\u0000\n1/9\u000e\u0013.<", "KogAN");
      I[1404 + 760 - 391 + 52] = I("巭娚杼", "tmXdr");
      I[233 + 1045 - 290 + 838] = I("\u0002'\t:\u0007\u0013)\u0010%\u0014", "aHdJf");
      I[1218 + 1485 - 1375 + 499] = I("\u0011\u001f6\t4\u0004\u0014\u001e\u000f)\f\u0000 \u001e'\u0015\u001f3", "apAlF");
      I[1744 + 1158 - 1975 + 901] = I("擅氊嵅威副", "eVrbq");
      I[1099 + 1102 - 1414 + 1042] = I("楅侺", "XPdmT");
      I[374 + 240 - -224 + 992] = I("捓", "VkBjE");
      I[1334 + 450 - 1236 + 1283] = I("巛択樐栶", "QOFFh");
      I[554 + 285 - 683 + 1676] = I("35*9\u0012\";3&\u0001", "PZGIs");
      I[722 + 1419 - 623 + 315] = I("7\u0002\u000b\u001e\u001d4\u000b\u0006-\u00106\u0017\u0017\u0011\u0000<\u0011", "Scrrt");
      I[312 + 1667 - 1157 + 1012] = I("懨烙壓", "CuazZ");
      I[1008 + 161 - 730 + 1396] = I("僫滰媌濰", "jkzcp");
      I[537 + 1641 - 1802 + 1460] = I("暳寭掦勃", "JQJFI");
      I[1803 + 828 - 846 + 52] = I("瀫摊楰妮", "dXGHz");
      I[1826 + 219 - 257 + 50] = I("嵷殊峁岄朴", "PgZbm");
      I[589 + 640 - -305 + 305] = I("736\u0017?*87;))91\u000f", "EVRdK");
      I[503 + 1668 - 2162 + 1831] = I("冴", "kFozc");
      I[1745 + 1585 - 2059 + 570] = I("伥唺圷佡", "mFRIw");
      I[34 + 169 - -500 + 1139] = I("\t;\b/\b92\u0003?\u0017\u00049\u0002", "kWgLc");
      I[810 + 140 - -102 + 791] = I("&\u001f-\u001e\r-5#\u001e\u001c", "WjLly");
      I[1392 + 671 - 1792 + 1573] = I("浰塘", "ICOWJ");
      I[667 + 1065 - 610 + 723] = I("歱", "FDmLw");
      I[266 + 990 - -333 + 257] = I("6+\u0005\u0010\u0017*?\u0004\u0019\u0000,4", "XNqxr");
      I[1686 + 82 - 1072 + 1151] = I("\n,\u0013\u0005\r\u0010", "bCcuh");
      I[953 + 1419 - 975 + 451] = I("烎斯故攟塸", "QgazW");
      I[292 + 466 - 176 + 1267] = I("帑沙", "SSyeP");
      I[1398 + 1443 - 2365 + 1374] = I("+\u0019\u00011\u000e1", "CvqAk");
      I[376 + 1075 - 406 + 806] = I("曳桹潕晍喁", "plIMj");
      I[42 + 1667 - 314 + 457] = I("奄巚搡", "zNFqq");
      I[995 + 1260 - 1039 + 637] = I("9 \u0018\u001632\u0017\u0015\u000b$#", "HUydG");
      I[354 + 1633 - 1366 + 1233] = I("\" \u0004\u0010<)\n\u0007\u000e'0>", "SUebH");
      I[23 + 1116 - 733 + 1449] = I(";\u0002*\u0003\u00040(8\u0005\u0011#\u00058", "JwKqp");
      I[673 + 865 - 1190 + 1508] = I("擆娕潯墬", "RYLCI");
      I[1792 + 1098 - 1224 + 191] = I("\u0000\u00110\u000f\b\u00004$\u0007\b\u0007\u001f", "seQfz");
      I[1699 + 1598 - 2264 + 825] = I("\r\u00061'\u0002\r\u0011*<+\u001e\u0004,\"", "leENt");
      I[1374 + 208 - 28 + 305] = I("浚匧溗剖", "clrCi");
      I[920 + 1483 - 1998 + 1455] = I("汚梎澿彰司", "gULso");
      I[973 + 965 - 137 + 60] = I("\u0002\u00168\u0010\"\u0002\u0001#\u000b\u0006\u0002\u001c ", "cuLyT");
      I[930 + 1809 - 880 + 3] = I("3>&\n<2>", "WLIzL");
      I[1606 + 1712 - 2945 + 1490] = I("炛喸摠媁惖", "DTVXP");
      I[630 + 749 - 984 + 1469] = I("澻垮", "qXuFb");
      I[1534 + 1560 - 2931 + 1702] = I("\u0013$6\u0000)\u0012$", "wVYpY");
      I[707 + 1786 - 993 + 366] = I("\u0017\u001c\u0016>\u0003\u0001\f(?\f\u0016\f\u00129\b\u00007\u0014;\f\u001d", "dhwWm");
      I[686 + 1586 - 907 + 502] = I("晸涖捰晒", "HxvnO");
      I[1630 + 1412 - 2950 + 1776] = I("厨派枓捏懞", "fdwMz");
      I[1794 + 1478 - 1881 + 478] = I("\u000e+\t\u0013?\f5\f\u000f\u0019\b#;\u001e\u0016\u0004)\r\u000e", "mGhjw");
      I[1617 + 1023 - 1787 + 1017] = I(")\u001d\u0019\u001b;?\r'\u00159;\u001a\u000b-%;\u0007\u001d", "ZixrU");
      I[1236 + 1840 - 2700 + 1495] = I("榉冤梔晅", "CPGuk");
      I[1661 + 14 - 1360 + 1557] = I("烶沪摗拶婃", "YqVTU");
      I[1103 + 1672 - 2639 + 1737] = I("搌", "ArcsV");
      I[1666 + 142 - 1383 + 1449] = I("檯毋撙榾", "aibIB");
      I[1559 + 1131 - 1743 + 928] = I("://(7:&/(\u0001*\u0000*'\u0017=", "NGFFd");
      I[400 + 1347 - 294 + 423] = I("\n\u00046\u000f\u0004\u0015S", "faWya");
      I[1214 + 576 - 1488 + 1575] = I("俪噔侏怍", "vGJZX");
      I[1593 + 1639 - 3037 + 1683] = I("浶", "QyYRj");
      I[534 + 262 - 39 + 1122] = I("嫪濺冣", "OKdGT");
      I[54 + 1104 - 194 + 916] = I("4/,%\u0002+", "XJMSg");
      I[1154 + 1111 - 2058 + 1674] = I("!\u0000!`", "MoFRv");
      I[1177 + 1252 - 2293 + 1746] = I("屭剴氎岝", "vzIlb");
      I[1030 + 309 - 294 + 838] = I("僱剬毊垇", "BUQcL");
      I[1665 + 393 - 1624 + 1450] = I("僢噋", "QPHED");
      I[846 + 1146 - 776 + 669] = I("\u0005\u001e6", "iqQSP");
      I[1607 + 1625 - 2498 + 1152] = I("\f\f\u0015\u0004\u000e\f0\u0007\u0013\u0006\u0004\u001d\u0007", "motgg");
      I[636 + 693 - 522 + 1080] = I("煴大嵆", "TbFrj");
      I[246 + 1352 - 929 + 1219] = I("哀垱悰", "YAsqx");
      I[1288 + 1653 - 2527 + 1475] = I("4%\u0011\b84\u0006\u001f\u000e.\u00062\u0011\u0002#&", "GQpaJ");
      I[1725 + 1699 - 2285 + 751] = I("\u001604!6\u001d0-\u0015\u001a\u00060/8\u001a", "rQFJi");
      I[851 + 776 - 259 + 523] = I("忋寇廲", "IQBCN");
      I[1816 + 1215 - 1199 + 60] = I("9\u0018(\u0013$9;&\u00152\u000e\r;\u0011\u0019+\u0007", "JlIzV");
      I[888 + 575 - 468 + 898] = I("\"\r\u0001>\u000b", "QahSn");
      I[267 + 1813 - 1464 + 1278] = I("匯嬅", "UBXQM");
      I[363 + 543 - 445 + 1434] = I("叧杓", "XahUt");
      I[1288 + 1525 - 1117 + 200] = I("\u0016\u001e\u001c \u0002", "eruMg");
      I[1156 + 118 - 1092 + 1715] = I(":\u0018\u0016%'=\u000b", "XydWN");
      I[163 + 534 - -352 + 849] = I("嬅烖", "fTqOo");
      I[855 + 877 - 22 + 189] = I("冽惌塾噼", "ExEGb");
      I[62 + 1420 - 24 + 442] = I("尠廕宀嘀", "tRUGS");
      I[60 + 1155 - 684 + 1370] = I("濢圚塑呿", "xwqVu");
      I[199 + 75 - -1032 + 596] = I("8\u00156(\r?\u0006", "ZtDZd");
      I[637 + 145 - -291 + 830] = I("\u0004*:\u0000=\u0019*4\u001e\u0006\u00027'", "mXUnb");
      I[971 + 32 - 739 + 1640] = I("旟亳倳", "feWge");
      I[1851 + 1545 - 2499 + 1008] = I("唊", "DWsEe");
      I[846 + 557 - 653 + 1156] = I("\u00115\r\u0002\u0010\n&\u0012\b+\u00175", "xGblD");
      I[1420 + 406 - 1316 + 1397] = I("84 +\f)4 6\u0004", "HFIXa");
      I[1067 + 1396 - 1102 + 547] = I("收", "jlxxh");
      I[188 + 1414 - 667 + 974] = I("嚶巤柛", "MoHBP");
      I[512 + 1768 - 1465 + 1095] = I("涪悄募暬梭", "tTmRW");
      I[1333 + 1082 - 2105 + 1601] = I("媘欔姴拟渀", "UNZKy");
      I[1584 + 124 - 951 + 1155] = I("\u0015=\u0004\n\t\u0004=\u0004\u0017\u0001", "eOmyd");
      I[896 + 470 - 1042 + 1589] = I("\u0007\t\u0000\u0015\u001a\u0015\u0002\u0015/\u0004\u001a", "tlaJv");
      I[1511 + 405 - 895 + 893] = I("拣擟才啉", "JsrdV");
      I[192 + 1831 - 824 + 716] = I("\u00174\u0000\u0015\u0014\n%\u0004+\u001b", "dQaYu");
      I[1190 + 910 - 984 + 800] = I("-\r\u000f\u0007!)\u0003\u00153", "ElvXC");
      I[1736 + 1899 - 2106 + 388] = I("棠", "FEhSu");
      I[314 + 1358 - 1624 + 1870] = I("帱攝仜束彘", "LmPAt");
      I[503 + 895 - 332 + 853] = I("橯", "KSahB");
      I[666 + 838 - 1404 + 1820] = I("悏慆", "wNHsC");
      I[1231 + 1133 - 874 + 431] = I("%7.\u0006\u0005\"5<", "MVWDi");
      I[1297 + 234 - 109 + 500] = I("6\u0012\u001a$*!", "UshTO");
      I[1329 + 452 - 1012 + 1154] = I("浒氎摉挣櫶", "pRWeo");
      I[1336 + 72 - -175 + 341] = I("烡嘩昆壱冚", "tTmov");
      I[608 + 1208 - 332 + 441] = I("\u0003?78\n\u0015\"(1=", "tPXTI");
      I[1429 + 1244 - 899 + 152] = I("12\u0010\u0016=76\u0006-;52\u001b", "YSbrX");
      I[539 + 1679 - 1231 + 940] = I("勂桰崟", "hXBky");
      I[580 + 1852 - 2183 + 1679] = I("厉漾", "QRUlP");
      I[536 + 774 - 749 + 1368] = I("晛", "nTsyh");
      I[1014 + 1097 - 1660 + 1479] = I(" 950.\"'0,\b&1", "CUTIf");
      I[1742 + 1706 - 3101 + 1584] = I("6=7\n;7>9\u0005\u000f", "URVfd");
      I[1266 + 454 - 651 + 863] = I("卶旭忧擞", "jkuvu");
      I[230 + 902 - 658 + 1459] = I("'!*.\u001d\u0006\"$!", "EMEMv");
      I[727 + 1030 - -166 + 11] = I("\u001a94\u0013\u0002\u000e\u0007>\u001b\u0002", "jXWxg");
      I[450 + 1332 - 1248 + 1401] = I("洎", "dCeLv");
      I[1935 + 1607 - 1824 + 218] = I("僤湩櫢刎悍", "ZSojE");
      I[1912 + 826 - 1807 + 1006] = I("刀汝", "pyerG");
      I[604 + 4 - -544 + 786] = I("停", "dnzgj");
      I[668 + 1601 - 540 + 210] = I("\u000f\u000e,\u001c/\u0005\u0006,(", "fmILN");
      I[1649 + 1053 - 1075 + 313] = I("2;\u001c\t*3\u000b\u0019\u0007'8 ", "VTikF");
      I[1401 + 275 - 1474 + 1739] = I("中", "CFfLY");
      I[67 + 1775 - 667 + 767] = I("烔枽凖圙", "VZWrC");
      I[855 + 784 - 435 + 739] = I("\u0006$&\u00030\u001c> 26\u0014>)\b&", "uPGmT");
      I[914 + 756 - 1028 + 1302] = I("夝涡", "YTFKX");
      I[568 + 553 - 560 + 1384] = I("摟扻嫶挗", "Iamdo");
      I[1780 + 1285 - 2244 + 1125] = I("1-\u0014\u000b?!", "SLzeZ");
      I[124 + 44 - -284 + 1495] = I("\u0003\u0019\u000e\t%\u0016\u0019\f\u000b\u001f\u0006", "txbez");
      I[1312 + 226 - 901 + 1311] = I("汮圃卯", "aYPjx");
      I[683 + 493 - 860 + 1633] = I("倯姲喖焗", "KCFVa");
      I[23 + 465 - -632 + 830] = I("墹孲庑", "wpsdo");
      I[258 + 1483 - 896 + 1106] = I("坃倢兵柍怓", "CmaJB");
      I[185 + 245 - -1334 + 188] = I("80*\u001c#(", "ZQDrF");
      I[509 + 191 - -1016 + 237] = I("/(:\u001d\u001a,!7.\u0017.=&\u0012\u0007$;\u001c\u0018\u001d=,1\u0005\u0016/", "KICqs");
      I[479 + 1607 - 421 + 289] = I("奸丼方渜烄", "YTqEb");
      I[1901 + 1711 - 2801 + 1144] = I("摶暮冚", "eaHHL");
      I[662 + 639 - 107 + 762] = I("樘寏槖", "tTQqE");
      I[295 + 1330 - 1396 + 1728] = I("丘厴媦嗜妿", "yJCAx");
      I[1510 + 1507 - 1891 + 832] = I("\u00032\u00136+\u001f3$\u0011%\u001f2", "qWweJ");
      I[699 + 1381 - 174 + 53] = I("\u0011\u000e\u0017\u0010:\u0002\u0005\u0017<=\f\u0005\u0016", "cksOI");
      I[1655 + 1291 - 2794 + 1808] = I("7\u0014.\t*$\u001f.%-*\u001f/\t*1\u0010#$*", "EqJVY");
      I[303 + 1696 - 1046 + 1008] = I("澵", "znjUx");
      I[513 + 259 - -12 + 1178] = I("叽命栵", "xlQHa");
      I[529 + 1626 - 1740 + 1548] = I("=\u0001.\u0001:='*\f\u001b/\u001b+;<!\u001b*", "NuOhH");
      I[545 + 588 - 348 + 1179] = I("\t5\u001c\f4\b\u0005\u001a\u001a7\u0003?6\u001d4\f8[", "mZinX");
      I[1096 + 301 - 982 + 1550] = I("灛崄亇快殶", "dFrcw");
      I[940 + 1206 - 549 + 369] = I("抟", "cJMYf");
      I[685 + 1283 - 1372 + 1371] = I("80.:+\u0018( 6|", "KDATN");
      I[500 + 1199 - -164 + 105] = I("=\u0017\u0007\u001b3\u0011\u0010\u0004\u00144|", "NchuV");
      I[1383 + 91 - 918 + 1413] = I("炱旼匮", "kmyPP");
      I[180 + 1412 - -346 + 32] = I("桳昶懍垉", "mEwJs");
      I[1041 + 824 - 422 + 528] = I("呗激擆帰", "LjWds");
      I[1713 + 286 - 1055 + 1028] = I("檻", "oSWvs");
      I[1717 + 1159 - 2236 + 1333] = I("'\u0000);\u001d\u0007\u0018'7J", "TtFUx");
      I[519 + 1720 - 605 + 340] = I("\u0017\u00060#,\u0001)$3!\u0007\u0013\u001d1.\u0010\u0013", "dvBVO");
      I[1652 + 479 - 1398 + 1242] = I("浚樖", "ghwDC");
      I[480 + 114 - 386 + 1768] = I("洪", "DsOnt");
      I[1151 + 728 - 452 + 550] = I("嶱咳冨墯", "WmaDH");
      I[1660 + 736 - 1754 + 1336] = I("勇历", "gnkpc");
      I[1865 + 689 - 1678 + 1103] = I("%2\u0006</3\u0004\u0011'/3\u0005\u0015=)", "VBtIL");
      I[1367 + 1729 - 2323 + 1207] = I("-\u0006>\r;\u0010\t)\u00000*0+\u000f'*", "OoLnS");
      I[464 + 1142 - 367 + 742] = I("孺", "fcwLM");
      I[1025 + 1015 - 1657 + 1599] = I("!\u0007\u0017 )\u0005\u000b\u000b $\u0004\u000f\u0011&", "CneCA");
      I[1941 + 1883 - 3591 + 1750] = I("074$\u000b?\u001d<&\t9'\u0005$\u0006.'", "ZBZCg");
      I[1342 + 1267 - 2270 + 1645] = I("橞戊櫠媟", "OfOHe");
      I[1558 + 1476 - 1828 + 779] = I(">\u00186\u0015\u00001+=\u001c\u000f1*9\u0006\t", "TmXrl");
      I[1830 + 1236 - 2712 + 1632] = I("\u000e\u00161#\u0010\u0005\u0016(\u0017)\u000f\u0019 -\u0010\r\u00167-", "jwCHO");
      I[1821 + 539 - 1993 + 1620] = I("撤歃之", "JxjfN");
      I[1379 + 652 - 218 + 175] = I("咶旚揼煉洡", "oIjrI");
      I[626 + 857 - 28 + 534] = I("\n\u001209\u001e\u000f\u0018\u00047?\r\u0016\u00053%\u000b", "nsBRQ");
      I[1548 + 1206 - 2099 + 1335] = I("31\u0000;83\r\u0007=?17>?0&7", "RRaXQ");
      I[296 + 1013 - -150 + 532] = I("售", "JPzbJ");
      I[339 + 1120 - 369 + 902] = I("掕嗿愭姚澼", "GkujE");
      I[1521 + 1857 - 2968 + 1583] = I("\n\u001a54,\n?19&\u000e>5# ", "kyTWE");
      I[1490 + 1121 - 1449 + 832] = I("\u001c\"\u0004/\u0002\n\r\u0010?\u000f\f7", "oRvZa");
      I[1392 + 1765 - 1843 + 681] = I("櫼噭", "UCDnJ");
      I[1132 + 779 - 1161 + 1246] = I("傇", "twrhN");
      I[190 + 1502 - -103 + 202] = I("坛洭卺滬溗", "qFANs");
      I[1210 + 198 - 1016 + 1606] = I("><\u0004\u001d!(\n\u0013\u0006!(", "MLvhB");
      I[220 + 1954 - 1276 + 1101] = I("(\u0003#\u0019\u0001\u0015\f4\u0014\n/", "JjQzi");
      I[1974 + 1346 - 1721 + 401] = I("檞", "BSmxd");
      I[379 + 638 - 661 + 1645] = I("塰姖卝", "UGEiN");
      I[581 + 845 - -436 + 140] = I("忕歊叏掮", "oyQZf");
      I[1570 + 1356 - 1120 + 197] = I("\u0006'0\u000b\f\"+,\u000b\u0001", "dNBhd");
      I[1223 + 966 - 1254 + 1069] = I("3\u0006\u001e\u000e)<,\u0016\f+:\u0016", "YspiE");
      I[261 + 1825 - 247 + 166] = I("尪楱格", "ZZOTX");
      I[107 + 1431 - 1140 + 1608] = I("刂堑修偉", "wPOWa");
      I[39 + 1482 - 977 + 1463] = I("奊吜暈", "oOIke");
      I[1086 + 1549 - 1960 + 1333] = I("恿嬔", "hFXrH");
      I[1530 + 405 - 75 + 149] = I(":\u0018/1\u00165+$8\u00195", "PmAVz");
      I[736 + 1266 - 1404 + 1412] = I("1(*-\t:(3\u001900';#", "UIXFV");
      I[164 + 1702 - 931 + 1076] = I("尯榪", "xyixx");
      I[536 + 1559 - 1875 + 1792] = I("品岔", "tVKtN");
      I[925 + 526 - 568 + 1130] = I("掚攚摑", "jmTls");
      I[293 + 1665 - 1787 + 1843] = I("\u0003\u0007\u0001\u0018#\u0006\r5\u0016\u0002\u0004\u0003", "gfssl");
      I[616 + 523 - 1012 + 1888] = I("\u0004\u0013\u0018\u0017\u0010\u0004/\u001f\u0011\u0017\u0006\u0015", "epyty");
      I[599 + 252 - -624 + 541] = I("墛樸栰濧", "ggLBH");
      I[1785 + 528 - 805 + 509] = I("従", "Qurmv");
      I[1346 + 1356 - 2389 + 1705] = I("戡傓木扦", "BHlqR");
      I[661 + 946 - 1085 + 1497] = I("0\u000132\f0$7?\u00064", "QbRQe");
      I[1522 + 135 - 341 + 704] = I(" \u0017\u00177\u001b68\u0001-\u0017!", "SgeBx");
      I[942 + 769 - 1316 + 1626] = I("弃冒汾仚毶", "hJUPi");
      I[221 + 845 - -30 + 926] = I("\b;. ;\u001c&41\r", "lTARh");
      I[649 + 963 - 1189 + 1600] = I("\u0000\u001b4,'=\u0016) =", "brFOO");
      I[1214 + 1135 - 827 + 502] = I("殸懣", "OJpkG");
      I[478 + 746 - -475 + 326] = I("渵浹", "ZNwmF");
      I[602 + 1292 - 800 + 932] = I("勡", "LVyTq");
      I[480 + 1381 - 1042 + 1208] = I("\u0015!*&1\u0018<&<", "qNETs");
      I[682 + 702 - 955 + 1599] = I(";\u0013$+\u001b49.#\u0018#", "QfJLw");
      I[1223 + 1237 - 2056 + 1625] = I("擾揳塡剾", "piKco");
      I[922 + 637 - 90 + 561] = I("#-7&\r2,?8\"", "GBXTG");
      I[1575 + 1426 - 974 + 4] = I("\u0013:0 \u001d\u0013\u00065,\u001b\u0000", "rYQCt");
      I[592 + 1199 - -52 + 189] = I("凗", "LDAjB");
      I[305 + 482 - -177 + 1069] = I("\n'6(\u0012\r):32", "nHYZS");
      I[391 + 1973 - 1271 + 941] = I("0 \u0002:(; \u001b\u000e\u0013;.\u0002", "TApQw");
      I[590 + 781 - 1195 + 1859] = I("浭烺", "yoNfU");
      I[240 + 639 - -508 + 649] = I("持权", "xNOBK");
      I[153 + 1048 - -33 + 803] = I("忻侦故桭桅", "SjlUO");
      I[447 + 895 - -297 + 399] = I("\u0016.$\u0017\u0006\u00133 *#\u0019", "rAKeB");
      I[1900 + 1584 - 2884 + 1439] = I("$\u00077>\u001a.\r", "AiSah");
      I[472 + 566 - -208 + 794] = I("歅", "HeiZK");
      I[119 + 1052 - -427 + 443] = I("濑孮圔", "TZVAQ");
      I[1516 + 1928 - 3258 + 1856] = I("!\u0018(\u00039 ", "DvLQV");
      I[687 + 898 - 967 + 1425] = I("\u0000>\u001b'>\u0010\t\u00049*\r\"", "cVtUK");
      I[971 + 596 - 112 + 589] = I("滢懵愖", "SCRfA");
      I[751 + 395 - 402 + 1301] = I("潗带憮恌", "acyWl");
      I[1745 + 939 - 869 + 231] = I("\u0001\u000b\u0007\u001e\u0003\u00113\u0004\r\u0018\u0016", "bchlv");
      I[1898 + 1815 - 2256 + 590] = I("\u0002\u001d\u001a\u0002\u0004\u0012*\u0013\u001c\u001e\u0016\u0010\u0007", "auupq");
      I[1250 + 1397 - 2377 + 1778] = I("港沤朌", "bieEK");
      I[1353 + 746 - 1309 + 1259] = I("瀳晻巖", "VRICM");
      I[1875 + 1938 - 1938 + 175] = I("0\u0000-(\u0012 ..5\u00106\u001a", "ShBZg");
      I[269 + 1792 - 1575 + 1565] = I("暮晹埗", "kXARj");
      I[168 + 1080 - 516 + 1320] = I("俋", "kJmpN");
      I[225 + 1641 - 1430 + 1617] = I("垦", "KiAdW");
      I[1779 + 1000 - 1270 + 545] = I("5!\u0004\u0003\u00167\u0016\u001a\u001c\u0000.", "ETvsc");
      I[176 + 1245 - -29 + 605] = I("\u001d\r*\u001f0\u001f':\u0003*\u000e\u0013", "mxXoE");
      I[1626 + 1147 - 2488 + 1771] = I("\u0016$74\u0000\u0014\u000e5-\u0019\n07", "fQEDu");
      I[1207 + 566 - 1740 + 2024] = I("堁擙坉", "wAGdb");
      I[104 + 1774 - 868 + 1048] = I("品估椸剿", "qwFor");
      I[2025 + 1761 - 3498 + 1771] = I("椵几七傌", "BdhoX");
      I[24 + 1611 - -398 + 27] = I("\u0017\u001e\u001a<\u0003\u0015;\u0001 \u001a\u0006\u0019", "gkhLv");
      I[1252 + 1288 - 1383 + 904] = I("\u001c&\u0017\u0003\u001e\u001e\f\u0016\u0007\n\u0005!\u0016", "lSesk");
      I[71 + 1229 - -473 + 289] = I("淎巯夾", "rTiYG");
      I[1274 + 973 - 1187 + 1003] = I("椂注嶏", "HURIh");
      I[416 + 1759 - 1032 + 921] = I("\u0004\u000e+<+\u0004*?')\u0002\b", "wzJUY");
      I[176 + 540 - -90 + 1259] = I("\u0002/\u0017\u0006\u0003\u0000\u0005\u0001\u0019\u0003\u00106\u0000)\u0005\u001e;\u0007", "rZevv");
      I[193 + 862 - -798 + 213] = I("屸剉", "nfqGS");
      I[755 + 409 - 743 + 1646] = I("\u001d\u0007\u000780\u001f!\u0019)'", "mruHE");
      I[880 + 383 - 384 + 1189] = I("\u0007\u0007$4\"\u0005-%(6\u0015", "wrVDW");
      I[2055 + 1972 - 3239 + 1281] = I("昐", "NILMZ");
      I[1869 + 1368 - 3221 + 2054] = I("展倀儯嫅", "tNKFN");
      I[8 + 444 - -1410 + 209] = I("\u0013:\u000b>:\u0011\u001c\u0015/-", "cOyNO");
      I[1122 + 67 - 247 + 1130] = I("'7\b%\u000100\u000f\u0011\u0010", "BYlzc");
      I[1976 + 982 - 2734 + 1849] = I("啾恨櫓", "lFlfu");
      I[1154 + 756 - 1508 + 1672] = I("\u0017\u0014\"8\u001d\u001b\u0019-\t", "rzFzo");
      I[819 + 66 - -479 + 711] = I("'\u0000.\u0012\u0016*\n?\u0015", "EeKfd");
      I[1363 + 320 - 838 + 1231] = I("桎勂曨瀦儘", "FYMvV");
      I[958 + 951 - 1671 + 1839] = I("湟僿", "UHoWd");
      I[430 + 804 - 471 + 1315] = I("掀", "XYaCe");
      I[164 + 598 - 583 + 1900] = I("徍", "bqtfm");
      I[1650 + 1404 - 1302 + 328] = I("\u0000'\u0007=\u0007\r-\u0016:", "bBbIu");
      I[1284 + 305 - 1551 + 2043] = I("烔慹损宩改", "Vmwsz");
      I[1054 + 678 - 710 + 1060] = I("嶾啢偲映", "OdYWm");
      I[51 + 616 - -1176 + 240] = I("\u0003\u001c3);4\u000f&2", "dnRZH");
      I[1784 + 1583 - 2080 + 797] = I("\u000b\u0004\f2\u001f3\u0006\f5\u0004", "lvmAl");
      I[1199 + 595 - 459 + 750] = I("\n#\f1\u001f\u000e9\r\u0019\u0019\u0016", "oMhnx");
      I[1859 + 126 - 546 + 647] = I("桯嶙杓丬欦", "DLPke");
      I[1651 + 1195 - 1346 + 587] = I("曏悀斧桛潕", "bHZQB");
      I[1365 + 280 - -346 + 97] = I("\u0000\r:<\u0002\u0006\u0001$><\u0011\u0007'4\u0002\u001c\f\u0015;\u000f\u001d\u000b!", "rhJYc");
      I[1064 + 1671 - 1696 + 1050] = I("攰撟憵澚", "WSFaL");
      I[1188 + 119 - -756 + 27] = I("傪傪劓", "Jamqo");
      I[708 + 860 - 513 + 1036] = I("厹囧冤娶", "OcvVX");
      I[2085 + 337 - 2244 + 1914] = I("煪", "EnzPw");
      I[221 + 1867 - 1718 + 1723] = I("\u0010\u00124.9\u0016\u001e*,\u001b\r\u001a)*6\u00065($;\t", "bwDKX");
      I[1879 + 1897 - 2513 + 831] = I("4\f2\u0006\u0016\b\u0007<\u0002\u00156\n70\u001a;\u000b0\u0004", "WdSox");
      I[1989 + 1378 - 2860 + 1588] = I("湘", "mymOu");
      I[913 + 1104 - 1202 + 1281] = I("嫚即將乗", "cGulW");
      I[952 + 780 - 1703 + 2068] = I(".82\u0018,\u000e?>\u001c##4\u0011\u001d-.;", "MPSqB");
      I[709 + 1803 - 931 + 517] = I("\u00028\u001c\u001e\u0004\u0001.,\u0004\u0013\u0001", "dJsmp");
      I[1330 + 681 - 1289 + 1377] = I("款楼炫殊梳", "VwwJd");
      I[406 + 675 - 137 + 1156] = I("椩濠希圌坟", "UPbaL");
      I[1089 + 726 - 175 + 461] = I("儂", "eBbeB");
      I[2034 + 470 - 637 + 235] = I("\u001c\u0011+\u0019\u001c\u001f\u0007\r\t\r", "zcDjh");
      I[1735 + 137 - 1841 + 2072] = I("\u000f/\u00054\u0016", "bNbYw");
      I[2016 + 688 - 2393 + 1793] = I("峂帰", "TVeNs");
      I[860 + 980 - 1645 + 1910] = I("屁捤敛怖殕", "pCEoB");
      I[127 + 2042 - 216 + 153] = I("\b'\u001d;\u0011", "eFzVp");
      I[250 + 1510 - 810 + 1157] = I("\"7\f\u00102>\r\u000f\u0019%8\r\u001a\u00148/9", "LRxxW");
      I[1496 + 790 - 2016 + 1838] = I("恝液寏放榙", "baBjN");
      I[300 + 900 - -552 + 357] = I("梭圚備戏", "pZRBZ");
      I[1262 + 582 - 1564 + 1830] = I("\u001c\t\u0015=*\u0000;\u0000';0\u0000\u000e6$", "rlaUO");
      I[1367 + 1098 - 1041 + 687] = I("\u0016=\u0005>$\u0001,\t\u00048;:\u0013\b)\u000f", "dXaaJ");
      I[1612 + 1452 - 1491 + 539] = I("晉嘴氰叺", "cWmeD");
      I[1795 + 264 - 1391 + 1445] = I("念侑", "NioAl");
      I[1121 + 26 - -202 + 765] = I("0\n\u00008\u00166\u0007\u0001\u000410\u0006\u0007\u001d", "Bodvs");
      I[1683 + 147 - 643 + 928] = I("\f!\u0002\u0014-\f\"\u0003\u0012\u0019", "nNlqr");
      I[1904 + 1188 - 1829 + 853] = I("伺", "Rsncx");
      I[196 + 1367 - 198 + 752] = I("槎", "tINyn");
      I[1216 + 160 - 530 + 1272] = I("炱斆攎岗啞", "AdMqZ");
      I[391 + 135 - -1443 + 150] = I("\u0012\u0005\b\u0003'\u001c\u0005\u0005\r", "pjffe");
      I[1665 + 1275 - 1560 + 740] = I("\u0014\u0004\u001f\u00029\u0013\u0005\u001f\u0012\u0005\u0011\u001f\u0004\u0013", "gpmwZ");
      I[948 + 1583 - 1396 + 986] = I("攳憫壈撞俧", "KIFnq");
      I[912 + 2029 - 1026 + 207] = I("\u0014\u001b\"&\u0016\u0013\u001a\"6#\b\u00064", "goPSu");
      I[470 + 1579 - 730 + 804] = I("\u0017:!$\u001c\u000e= ", "xXRAn");
      I[1070 + 2087 - 1637 + 604] = I("仙噉儡婴", "gFaVd");
      I[854 + 1561 - 1362 + 1072] = I("壳瀕", "NMKUW");
      I[888 + 1010 - 246 + 474] = I("\u0004&*3\u0000\u001d!+", "kDYVr");
      I[2009 + 548 - 1891 + 1461] = I("\u001d\u0006\u0002%15\u001d\u0003$8\u0001\u000b\u0019\u000e6\u0005\u0016", "jnkQT");
      I[1711 + 1742 - 3358 + 2033] = I("嗟俱執", "qhclA");
      I[1551 + 1457 - 1467 + 588] = I(">\u001d\u001e\u0007\u001d(\u0007)\u0004\u000e\u001a\u001d\u0002\u001f\u0013", "Mukkv");
      I[979 + 580 - 476 + 1047] = I("\u00054\f\u0006\u001e\u000f\u0019\u001e\u0000\f\u0006-\b\u001a&\b)\u0015", "jFmhy");
      I[654 + 2098 - 2633 + 2012] = I("寕抽", "PdoNE");
      I[275 + 1276 - 571 + 1152] = I("櫀岉沁", "uMkJu");
      I[1372 + 939 - 339 + 161] = I("慦惧殼奂塔", "tYhil");
      I[1027 + 998 - 1569 + 1678] = I("!\u0006$\u0014%7\u001c\u0013\u00176\u001d\u001c0\u0016)7", "RnQxN");
      I[1580 + 1418 - 2656 + 1793] = I("\u001d\u0013\u0012 $\u0004\u0013*6\"\u0005\u001e\u001e 8/\u0010\u001a=", "pruEJ");
      I[702 + 1728 - 1945 + 1651] = I("彋垦櫌溽咘", "oXgTn");
      I[274 + 331 - -1457 + 75] = I("搑偈岌", "ZVttW");
      I[1348 + 828 - 155 + 117] = I("泪嗥僯暳摈", "vcXDM");
      I[632 + 1055 - 1437 + 1889] = I("槙俼枘涮", "qNraS");
      I[695 + 1500 - 737 + 682] = I("\u0012*\u0003\u000b\u001c\u000404\b\u000f,#\u0011\u0002\u0019\u0015#", "aBvgw");
      I[46 + 558 - -426 + 1111] = I("'\u0007\u0002\u000f\u0003\u0014\f\t\u0012\u0012\u0014\u001d\r\u0012\u001b \u000b\u00178\u0015$\u0016", "Knegw");
      I[121 + 1610 - -306 + 105] = I("栂", "LkvWX");
      I[1182 + 1377 - 738 + 322] = I("\u00111:4<\u0007+\r7/.0(0# 5:=", "bYOXW");
      I[713 + 1558 - 1467 + 1340] = I("\u0015\u0017\u0006\u001c\u000e\u001b-\u0019\u0018\u0014\u0000\u0019\u000f\u0002>\u000e\u001d\u0012", "lrjpa");
      I[1330 + 857 - 740 + 698] = I("仲媩", "JAcps");
      I[1318 + 674 - 67 + 221] = I("?\u0004\u001a)1)\u001e-*\"\u0015\t\u0003)5;", "LloEZ");
      I[940 + 661 - -519 + 27] = I("/\u0000\u00055*0\u0001\u001d<\u001e&\u001b72\u001a;", "CihPu");
      I[912 + 498 - 198 + 936] = I("煈梼機", "kBNmB");
      I[682 + 2144 - 925 + 248] = I("7\u0007\u0013-\f!\u001d$.\u001f\b\u0006\u000b$", "DofAg");
      I[1306 + 979 - 372 + 237] = I("\u001a-)\u0018\u0007\u0019,2\u001f3\u000f6\u0018\u00117\u0012", "jDGsX");
      I[1383 + 353 - 336 + 751] = I("栢桾", "lBUgj");
      I[2052 + 39 - 1492 + 1553] = I("戝", "iCKLA");
      I[500 + 349 - -340 + 964] = I("8*\"'\u001b.0\u0015$\b\u001b+9 ", "KBWKp");
      I[854 + 2112 - 1414 + 602] = I("\u0001\u00061\u00178\u0015\u001c%\u0002\f\u0003\u0006\u000f\f\b\u001e", "ftPng");
      I[717 + 1550 - 1209 + 1097] = I("懦滫峟梿尧", "ZOPcv");
      I[1398 + 547 - 1106 + 1317] = I("址寃昝宧嶜", "ECzWy");
      I[1560 + 1025 - 2328 + 1900] = I("惒寙压岔奓", "RFWcd");
      I[1847 + 75 - 1469 + 1705] = I("2:\u001e\u0007&$ )\u00045\u0006 \n\u0012", "ARkkM");
      I[49 + 502 - -1470 + 138] = I("\u0015?\u000e\u000e\f\u0014\t\u0011\u0010\u001c\n=\u0007\n6\u00049\u001a", "fVbxi");
      I[118 + 660 - 544 + 1926] = I("漈嚜櫺塘", "kulMg");
      I[1352 + 213 - -475 + 121] = I("叓", "tBTuB");
      I[924 + 895 - 1360 + 1703] = I("寬亲决劋岬", "WkwGN");
      I[423 + 567 - -125 + 1048] = I("昋尿", "kLEsY");
      I[142 + 1160 - 309 + 1171] = I("俅岙掃俩", "koPfr");
      I[227 + 1713 - 894 + 1119] = I("\u0015\u0012\"\u000f3\u0003\b\u0015\f 5\u0013;\u0015=\u0014", "fzWcX");
      I[1453 + 483 - 1868 + 2098] = I("\u000e\u0016\u000e\u0006\u001d\u001e\u0007\u001a\u0004)\b\u001d0\n-\u0015", "moohB");
      I[1881 + 1764 - 2759 + 1281] = I("旍", "XMucz");
      I[544 + 1679 - 1340 + 1285] = I("剉", "JlKmf");
      I[1795 + 873 - 1819 + 1320] = I("?\u0000\u0014\u0002\t)\u001a#\u0001\u001a\u000f\u0011\u0000\u0000", "Lhanb");
      I[1513 + 1403 - 1736 + 990] = I("\u0018\u0012$\u0018\u0015\r8%\u0000\f\u0004\f3\u001a&\n\b.", "hgVhy");
      I[483 + 677 - 718 + 1729] = I("厗偆偝潟堧", "SUCGM");
      I[192 + 1628 - 1287 + 1639] = I("\u001c* \u0015,\n0\u0017\u0016??7'\t+\n", "oBUyG");
      I[1119 + 785 - 191 + 460] = I("\u001a\u00046\f8\u000b\u00006\u0005\f\u001d\u001a\u001c\u000b\b\u0000", "xhCig");
      I[1322 + 393 - -220 + 239] = I("搰戏嵺树戔", "IxnwV");
      I[2089 + 609 - 1690 + 1167] = I("幑", "ZVspP");
      I[1269 + 1654 - 2851 + 2104] = I("捓抣伷毝", "smKia");
      I[1298 + 1136 - 1409 + 1152] = I("\u001c* \u001c\u0002\n0\u0017\u001f\u0011-. \u0015", "oBUpi");
      I[1749 + 518 - 1795 + 1706] = I(" +$\r)\u001d*#\u000f+)<9%%-!", "BYKzG");
      I[1121 + 1000 - 437 + 495] = I("柜弶", "aCPvY");
      I[749 + 1183 - -184 + 64] = I("昛沯烘埣偩", "vpfao");
      I[1005 + 454 - 493 + 1215] = I("榷橒挦", "xeYLb");
      I[1923 + 2015 - 3500 + 1744] = I(":\u001a\u0006\u0003\u001e,\u00001\u0000\r\u000b\u0000\u001c\u0018\u001b", "Irsou");
      I[68 + 226 - -1650 + 239] = I(",\u0004\u0011$\f\u0014\u0005\u001c4\u000e \u0013\u0006\u001e\u0000$\u000e", "KvtAb");
      I[224 + 568 - -486 + 906] = I("回櫀", "fJwnd");
      I[1145 + 764 - 535 + 811] = I("众桖", "reDsS");
      I[2119 + 517 - 835 + 385] = I("槏欵", "CSeeb");
      I[1577 + 1390 - 2916 + 2136] = I("\u0018>;\u0014>\u000e$\f\u0017-,$+\u001d;", "kVNxU");
      I[954 + 2143 - 1909 + 1000] = I("\u0002\f.\u001c%\u0018\u001c&(3\u00026(,.", "piJCV");
      I[606 + 878 - -242 + 463] = I("伈估戉暓亗", "RFrNg");
      I[1965 + 1202 - 2172 + 1195] = I("儨丩婥", "bGmmE");
      I[192 + 938 - -748 + 313] = I("洄敦", "FSayd");
      I[1490 + 1294 - 635 + 43] = I("2\n\u00074&$\u0010075\u0013\u0007\u0016", "AbrXM");
      I[1818 + 165 - 1710 + 1920] = I("\u0014\"\u00052\t)=\f$\u000e\u001d+\u0016\u000e\u0000\u00196", "vNdQb");
      I[1440 + 221 - -514 + 19] = I("岃摷偾椑拻", "SRKad");
      I[1343 + 1152 - 2009 + 1709] = I("暞淵弈奧棿", "Mhyce");
      I[295 + 664 - -558 + 679] = I("囷垒惁涙僩", "wwtOm");
      I[1474 + 987 - 1593 + 1329] = I("+=;\u0018>='\f\u001b-\u001a9/\u0017>", "XUNtU");
      I[220 + 1101 - 857 + 1734] = I("\u0002\u0018\u0000\"7*\u0017\u00057(\u0010\u00146\"7\u0007\u0002\b5=\u0001\u0004\b", "upiVR");
      I[489 + 528 - 263 + 1445] = I("寜岯烾烶", "MZQEn");
      I[154 + 594 - -162 + 1290] = I("\n>6)/\u0000\u00130+)\u001f)3\u0018<\u0000>%&+\n8#&", "eLWGH");
      I[800 + 1796 - 421 + 26] = I("厾巹澯", "vryye");
      I[876 + 435 - 282 + 1173] = I("勦倝惏挹", "GGzrb");
      I[38 + 269 - -280 + 1616] = I("\t \"4\u001d\u0010 \u001a6\u001f\u0005; 5,\u0010$7#\u0012\u0007.1%\u0012", "dAEQs");
      I[1790 + 2032 - 2806 + 1188] = I("消", "dWklm");
      I[1051 + 895 - 936 + 1195] = I("擝傔浞暺槯", "woVwJ");
      I[1684 + 1055 - 2327 + 1794] = I("捛撷唷棪掮", "OIjiA");
      I[509 + 1559 - 1480 + 1619] = I("\u000b9%>'82.#687.7)\u00024\u001d\"6\u0015\"#5<\u0013$#", "gPBVS");
      I[1084 + 137 - -897 + 90] = I("涊搃", "HiXYf");
      I[1996 + 769 - 1504 + 948] = I("烧宾歖", "XxAyF");
      I[410 + 1717 - 703 + 786] = I("檨拲埉俁崼", "Ryiub");
      I[278 + 1842 - 1381 + 1472] = I("-\u0006\u0018\u000b\n#<\u0013\u000b\u0004.\u0006\u00108\u00111\u0011\u0006\u0006\u0006;\u0017\u0000\u0006", "Tctge");
      I[446 + 737 - -906 + 123] = I("彎啊嗰", "VuhvA");
      I[1290 + 489 - 1188 + 1622] = I("廤", "LUOns");
      I[797 + 515 - 242 + 1144] = I("曽毻檼晳囊", "ZGzdf");
      I[6 + 1265 - 998 + 1942] = I("廾婄弟潬挮", "obJLc");
      I[115 + 2123 - 196 + 174] = I("擆坖僺奛婙", "ZHGmN");
      I[113 + 1451 - 158 + 811] = I("\u000b\u0010\u0018\u0002)\u0000\u0015\u0014\u001d\u0013\u0003&\u0001\u0002\u0004\u0015\u0018\u0016\b\u0002\u0013\u0018", "gyugv");
      I[2092 + 1598 - 2876 + 1404] = I("己嶃炌", "SGRHi");
      I[1321 + 196 - 1388 + 2090] = I("嶔", "hjvvV");
      I[2134 + 1609 - 2165 + 642] = I(";0/\u0013\u0016,5 \u0002,/\u00065\u001d;98\"\u0017=?8", "KYAxI");
      I[710 + 929 - -256 + 326] = I("傃喷儝嶆", "TXpIa");
      I[764 + 1756 - 1369 + 1071] = I("娜", "YEeWT");
      I[1797 + 1020 - 960 + 366] = I("廹叡洍嫺", "ViqSW");
      I[2191 + 984 - 3140 + 2189] = I("\r\u0010\u00056\u001a\r\u000e\u00055 \u000e=\u0010*7\u0018\u0003\u0007 1\u001e\u0003", "jbdOE");
      I[1041 + 467 - 1419 + 2136] = I("圡", "odcpB");
      I[458 + 52 - 5 + 1721] = I("关宲", "gBxZy");
      I[2142 + 1356 - 2014 + 743] = I("\u0011\u0019\u0014\u0007\u0015\u0010/\u001f\u001d\u0011\u0018\u0015\u001c.\u0004\u0007\u0002\n\u0010\u0013\r\u0004\f\u0010", "bpxqp");
      I[608 + 884 - 700 + 1436] = I("励", "BAJUz");
      I[1813 + 1480 - 1515 + 451] = I("媓榘奍", "kJTwX");
      I[680 + 1549 - 160 + 161] = I("敟槱樬", "LzTQx");
      I[192 + 1199 - -21 + 819] = I("!\t$\u001a\u0010%\u001c$\u000e*&/1\u0011=0\u0011&\u001b;6\u0011", "BpEtO");
      I[608 + 980 - 938 + 1582] = I("櫅", "niTCj");
      I[522 + 1035 - -392 + 284] = I("\u001e\u001f?''\u000b5*;*\u0014\u000f)\b?\u000b\u0018?6(\u0001\u001e96", "njMWK");
      I[2003 + 1930 - 3371 + 1672] = I("侔慘嘦宆漉", "ABfAq");
      I[371 + 2173 - 316 + 7] = I("啚润嚂昘埸", "oVvKj");
      I[2102 + 1426 - 2738 + 1446] = I("沧击僧", "XLYJR");
      I[2153 + 1463 - 3538 + 2159] = I("\u0013/\u00064\r\u0016/\u0012+7\u0015\u001c\u00074 \u0003\"\u0010>&\u0005\"", "qCsQR");
      I[844 + 1299 - 658 + 753] = I("劓帅埛旉槒", "QJnQM");
      I[1483 + 1816 - 2242 + 1182] = I("攀敻沽思", "XtFWg");
      I[1418 + 1355 - 1987 + 1454] = I("嬃嫴徶戜", "SHeEx");
      I[1385 + 1116 - 1684 + 1424] = I("\u0013&\b\u0007&.3\u000b\u00112\u001408\u0004-\u0003&\u0006\u0013'\u0005 \u0006", "qTgpH");
      I[437 + 2067 - 2209 + 1947] = I("僊慾峋", "YGENC");
      I[1904 + 1949 - 2187 + 577] = I("浂涫廡傣", "VGGdP");
      I[1332 + 1294 - 2073 + 1691] = I("\u0002$\u001616:1\u001f5\"\u00002, =\u0017$\u001277\u0011\"\u0012", "eVsTX");
      I[739 + 1144 - 61 + 423] = I("灒涙", "uEQep");
      I[2130 + 784 - 1481 + 813] = I("慕奸氼怩厶", "JIrzz");
      I[1003 + 432 - -17 + 795] = I("\u0001<\u0015,=\u001f8\u000b\u0016>,-\u0014\u0001(\u0012:\u001e\u0007.\u0012", "sYqsZ");
      I[488 + 2187 - 1753 + 1326] = I("刟搲", "dfHcH");
      I[390 + 664 - -724 + 471] = I("峀博慿", "Lmxgb");
      I[1807 + 1460 - 1045 + 28] = I("檅墆敂桋妙", "dZfBa");
      I[1615 + 1512 - 2971 + 2095] = I("\u0018>/0\r%5\"2\u001c\u001f6\u0011'\u0003\b /0\t\u000e&/", "zRNSf");
      I[1065 + 1211 - 2063 + 2039] = I("妗吏浾怴", "TxCTw");
      I[518 + 1271 - -63 + 401] = I("椲", "qfyUT");
      I[2082 + 1687 - 2879 + 1364] = I("*%\b3\u001e,>\u0003", "IJfPl");
      I[140 + 628 - -778 + 709] = I("夔", "oLjNv");
      I[841 + 1471 - 1886 + 1830] = I("&\u0016\u0007\u0001\u0003 \r\f", "Eyibq");
      I[1297 + 916 - 733 + 777] = I("$$\n;#\"?\u0001\u0007!(<\u0000=#", "GKdXQ");
      I[1341 + 290 - 576 + 1203] = I("幀澑楧橠懵", "SGAaR");
      I[1975 + 9 - -186 + 89] = I("嫨櫅偰劘桑", "opVeh");
      I[1370 + 283 - 713 + 1320] = I("\"7;(($,0\u001b56<09", "AXUKZ");
      I[1240 + 2000 - 1626 + 647] = I("\u00001\u0000;\u0012\u00070\u0000+.\u0011)\u001d-\u001a", "sErNq");
      I[1614 + 6 - 808 + 1450] = I("呝挼冣淄", "ySTip");
      I[40 + 1691 - 721 + 1253] = I("佰", "hIOXO");
      I[390 + 817 - -523 + 534] = I("#=\u00156\u0000$<\u0015&!<&\u0004(", "PIgCc");
      I[1187 + 262 - 5 + 821] = I("塤屢徐叾", "FYBSj");
      I[2247 + 1907 - 3385 + 1497] = I("圯庥", "VeMgI");
      I[921 + 1710 - 1980 + 1616] = I("幖斯嗦", "TlBfZ");
      I[1759 + 543 - 1611 + 1577] = I("泂峄段垽娘", "AocyH");
      I[351 + 1525 - 1261 + 1654] = I("宻乿", "zFScS");
      I[704 + 2128 - 899 + 337] = I("\u0001\u0005\u001f4\u0007\u001c\u0005\u0013", "uwvDp");
      I[431 + 1302 - 48 + 586] = I("傝忱", "ivYNW");
      I[11 + 1078 - -511 + 672] = I("攋声", "zVDFh");
      I[361 + 2010 - 1544 + 1446] = I("毭岪", "EcMVH");
      I[1589 + 1359 - 1895 + 1221] = I("圅备", "rNBJW");
      I[754 + 1331 - 538 + 728] = I("兼捖", "DqumD");
      I[1727 + 1664 - 2060 + 945] = I("漁叛峵欂棰", "LCgJZ");
      I[541 + 815 - -497 + 424] = I("亏", "YofaI");
      I[1084 + 336 - -188 + 670] = I(".\r\u0015", "OdgOM");
   }

   public void onBlockClicked(World var1, BlockPos var2, EntityPlayer var3) {
   }

   public CreativeTabs getCreativeTabToDisplayOn() {
      return this.displayOnCreativeTab;
   }

   /** @deprecated */
   @Deprecated
   public int getPackedLightmapCoords(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      int var4 = var2.getCombinedLight(var3, var1.getLightValue());
      if (var4 == 0 && var1.getBlock() instanceof BlockSlab) {
         var3 = var3.down();
         var1 = var2.getBlockState(var3);
         return var2.getCombinedLight(var3, var1.getLightValue());
      } else {
         return var4;
      }
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      return (boolean)"".length();
   }

   /** @deprecated */
   @Deprecated
   public float getPlayerRelativeBlockHardness(IBlockState var1, EntityPlayer var2, World var3, BlockPos var4) {
      float var5 = var1.getBlockHardness(var3, var4);
      if (var5 < 0.0F) {
         return 0.0F;
      } else {
         AutoTool var6 = (AutoTool)ZewSide.instance.featureManager.getFeature(AutoTool.class);
         float var10000;
         ItemStack var10002;
         if (!var2.canHarvestBlock(var1)) {
            if (var6.isEnabled() && var6.silentSwitch.getCurrentValue()) {
               var10002 = var2.inventory.getStackInSlot(var6.itemIndex);
               "".length();
               if (0 == 3) {
                  throw null;
               }
            } else {
               var10002 = var2.getHeldItemMainhand();
            }

            var10000 = var2.getDigSpeed(var1, var10002) / var5 / 100.0F;
            "".length();
            if (4 == 2) {
               throw null;
            }
         } else {
            if (var6.isEnabled() && var6.silentSwitch.getCurrentValue()) {
               var10002 = var2.inventory.getStackInSlot(var6.itemIndex);
               "".length();
               if (0 < -1) {
                  throw null;
               }
            } else {
               var10002 = var2.getHeldItemMainhand();
            }

            var10000 = var2.getDigSpeed(var1, var10002) / var5 / 30.0F;
         }

         return var10000;
      }
   }

   public void randomTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      this.updateTick(var1, var2, var3, var4);
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getStateFromMeta(var7);
   }

   public static void registerBlocks() {
      String var10000 = I[56 + 54 - 44 + 64];
      String var10001 = I[83 + 58 - 16 + 6];
      String var10002 = I[83 + 16 - 26 + 59];
      var10001 = I[90 + 0 - 57 + 100];
      var10000 = I[6 + 33 - 27 + 122];
      var10001 = I[117 + 118 - 222 + 122];
      var10002 = I[51 + 20 - -5 + 60];
      var10001 = I[16 + 77 - -18 + 26];
      var10000 = I[25 + 44 - 42 + 111];
      var10001 = I[78 + 69 - 33 + 25];
      var10002 = I[82 + 98 - 171 + 131];
      var10001 = I[97 + 55 - 112 + 101];
      var10000 = I[18 + 52 - -13 + 59];
      var10001 = I[126 + 93 - 193 + 117];
      var10002 = I[82 + 33 - 21 + 50];
      var10001 = I[118 + 20 - 48 + 55];
      var10000 = I[22 + 28 - 23 + 119];
      var10001 = I[16 + 105 - 44 + 70];
      var10002 = I[124 + 59 - 59 + 24];
      var10001 = I[30 + 141 - 90 + 68];
      var10000 = I[102 + 112 - 96 + 32];
      var10001 = I[23 + 35 - -45 + 48];
      var10002 = I[2 + 77 - 74 + 147];
      var10001 = I[64 + 140 - 54 + 3];
      var10000 = I[95 + 66 - 97 + 90];
      var10001 = I[112 + 139 - 186 + 90];
      var10002 = I[100 + 137 - 221 + 140];
      var10001 = I[6 + 47 - -41 + 63];
      var10000 = I[36 + 109 - 29 + 42];
      var10001 = I[60 + 110 - 135 + 124];
      var10002 = I[29 + 155 - 87 + 63];
      var10001 = I[156 + 79 - 225 + 151];
      var10000 = I[87 + 26 - 105 + 154];
      var10001 = I[51 + 64 - 51 + 99];
      var10002 = I[137 + 123 - 144 + 48];
      var10001 = I[143 + 18 - 140 + 144];
      var10000 = I[75 + 30 - 87 + 148];
      var10001 = I[140 + 124 - 246 + 149];
      var10002 = I[98 + 120 - 174 + 124];
      var10001 = I[153 + 130 - 136 + 22];
      var10000 = I[22 + 144 - 112 + 116];
      var10001 = I[158 + 62 - 170 + 121];
      var10002 = I[80 + 77 - 87 + 102];
      var10001 = I[153 + 75 - 62 + 7];
      var10000 = I[93 + 109 - 56 + 28];
      var10001 = I[20 + 2 - -135 + 18];
      var10002 = I[42 + 116 - -11 + 7];
      var10001 = I[42 + 36 - -40 + 59];
      var10000 = I[38 + 43 - 36 + 133];
      var10001 = I[120 + 126 - 193 + 126];
      var10002 = I[25 + 1 - -2 + 152];
      var10001 = I[180 + 40 - 203 + 164];
      var10000 = I[41 + 21 - 49 + 169];
      var10001 = I[182 + 75 - 204 + 130];
      var10002 = I[40 + 1 - -103 + 40];
      var10001 = I[75 + 73 - 80 + 117];
      var10000 = I[17 + 106 - 92 + 155];
      var10001 = I[109 + 24 - -53 + 1];
      var10002 = I[9 + 53 - -117 + 9];
      var10001 = I[172 + 30 - 100 + 87];
      var10000 = I[44 + 3 - -110 + 33];
      var10001 = I[47 + 116 - 12 + 40];
      var10002 = I[103 + 99 - 123 + 113];
      var10001 = I[53 + 168 - 207 + 179];
      var10000 = I[120 + 75 - 91 + 90];
      var10001 = I[158 + 26 - 170 + 181];
      var10002 = I[107 + 167 - 152 + 74];
      var10001 = I[5 + 109 - -43 + 40];
      var10000 = I[86 + 83 - 22 + 51];
      var10001 = I[77 + 88 - 151 + 185];
      var10002 = I[198 + 56 - 59 + 5];
      var10001 = I[18 + 53 - -67 + 63];
      var10000 = I[91 + 166 - 113 + 58];
      var10001 = I[101 + 198 - 138 + 42];
      var10002 = I[71 + 148 - 52 + 37];
      var10001 = I[119 + 12 - 101 + 175];
      var10000 = I[140 + 32 - 81 + 115];
      var10001 = I[163 + 163 - 158 + 39];
      var10002 = I[174 + 190 - 240 + 84];
      var10001 = I[206 + 178 - 352 + 177];
      var10000 = I[102 + 115 - 60 + 53];
      var10001 = I[200 + 57 - 214 + 168];
      var10002 = I[37 + 7 - -116 + 52];
      var10001 = I[140 + 44 - 131 + 160];
      var10000 = I[160 + 11 - 94 + 137];
      var10001 = I[36 + 8 - 19 + 190];
      var10002 = I[145 + 199 - 340 + 212];
      var10001 = I[90 + 13 - 48 + 162];
      var10000 = I[110 + 32 - 54 + 130];
      var10001 = I[51 + 93 - 103 + 178];
      var10002 = I[96 + 100 - 76 + 100];
      var10001 = I[21 + 112 - 100 + 188];
      var10000 = I[133 + 13 - -6 + 70];
      var10001 = I[37 + 74 - -39 + 73];
      var10002 = I[27 + 25 - -100 + 72];
      var10001 = I[9 + 83 - -69 + 64];
      var10000 = I[134 + 134 - 187 + 145];
      var10001 = I[61 + 61 - -42 + 63];
      var10002 = I[112 + 177 - 179 + 118];
      var10001 = I[155 + 125 - 107 + 56];
      var10000 = I[148 + 198 - 339 + 223];
      var10001 = I[48 + 186 - 71 + 68];
      var10002 = I[163 + 135 - 221 + 155];
      var10001 = I[149 + 66 - 90 + 108];
      var10000 = I[82 + 95 - 126 + 183];
      var10001 = I[119 + 62 - -24 + 30];
      var10002 = I[218 + 145 - 355 + 228];
      var10001 = I[15 + 1 - -151 + 70];
      var10000 = I[194 + 58 - 39 + 25];
      var10001 = I[180 + 102 - 128 + 85];
      var10002 = I[201 + 218 - 407 + 228];
      var10001 = I[66 + 149 - -17 + 9];
      var10000 = I[83 + 232 - 171 + 98];
      var10001 = I[103 + 130 - 222 + 232];
      var10002 = I[220 + 192 - 271 + 103];
      var10001 = I[14 + 114 - 68 + 185];
      var10000 = I[207 + 89 - 272 + 222];
      var10001 = I[137 + 184 - 294 + 220];
      var10002 = I[144 + 163 - 230 + 171];
      var10001 = I[53 + 69 - 105 + 232];
      var10000 = I[153 + 157 - 177 + 117];
      var10001 = I[145 + 12 - 115 + 209];
      var10002 = I[146 + 250 - 339 + 195];
      var10001 = I[186 + 130 - 204 + 141];
      var10000 = I[227 + 68 - 204 + 163];
      var10001 = I[84 + 30 - -114 + 27];
      var10002 = I[216 + 193 - 199 + 46];
      var10001 = I[84 + 42 - -124 + 7];
      var10000 = I[69 + 59 - 49 + 179];
      var10001 = I[115 + 156 - 125 + 113];
      var10002 = I[13 + 210 - 198 + 235];
      var10001 = I[194 + 112 - 252 + 207];
      var10000 = I[167 + 9 - 161 + 247];
      var10001 = I[186 + 229 - 243 + 91];
      var10002 = I[132 + 145 - 215 + 202];
      var10001 = I[211 + 160 - 134 + 28];
      var10000 = I[53 + 101 - 32 + 144];
      var10001 = I[166 + 161 - 222 + 162];
      var10002 = I[205 + 11 - -40 + 12];
      var10001 = I[160 + 115 - 252 + 246];
      var10000 = I[249 + 71 - 128 + 78];
      var10001 = I[155 + 15 - -15 + 86];
      var10002 = I[8 + 52 - -127 + 85];
      var10001 = I[202 + 267 - 264 + 68];
      var10000 = I[30 + 200 - 78 + 122];
      var10001 = I[24 + 72 - -24 + 155];
      var10002 = I[94 + 174 - 97 + 105];
      var10001 = I[200 + 209 - 249 + 117];
      var10000 = I[90 + 97 - -9 + 82];
      var10001 = I[65 + 30 - -133 + 51];
      var10002 = I[11 + 112 - -84 + 73];
      var10001 = I[236 + 93 - 106 + 58];
      var10000 = I[161 + 240 - 310 + 191];
      var10001 = I[113 + 60 - 36 + 146];
      var10002 = I[129 + 190 - 214 + 179];
      var10001 = I[53 + 153 - -14 + 65];
      var10000 = I[136 + 28 - 133 + 255];
      var10001 = I[165 + 157 - 254 + 219];
      var10002 = I[240 + 25 - 225 + 248];
      var10001 = I[117 + 76 - -7 + 89];
      var10000 = I[59 + 5 - -135 + 91];
      var10001 = I[218 + 9 - 128 + 192];
      var10002 = I[39 + 28 - -76 + 149];
      var10001 = I[159 + 19 - 116 + 231];
      var10000 = I[135 + 165 - 12 + 6];
      var10001 = I[278 + 204 - 280 + 93];
      var10002 = I[206 + 148 - 232 + 174];
      var10001 = I[181 + 49 - -59 + 8];
      var10000 = I[171 + 45 - -38 + 44];
      var10001 = I[251 + 292 - 311 + 67];
      var10002 = I[252 + 166 - 146 + 28];
      var10001 = I[18 + 47 - -122 + 114];
      var10000 = I[26 + 9 - -169 + 98];
      var10001 = I[126 + 55 - -23 + 99];
      var10002 = I[215 + 217 - 337 + 209];
      var10001 = I[31 + 179 - -2 + 93];
      var10000 = I[293 + 285 - 342 + 70];
      var10001 = I[55 + 258 - 218 + 212];
      var10002 = I[264 + 300 - 419 + 163];
      var10001 = I[60 + 160 - -83 + 6];
      var10000 = I[171 + 299 - 438 + 278];
      var10001 = I[29 + 181 - 185 + 286];
      var10002 = I[35 + 290 - 135 + 122];
      var10001 = I[129 + 146 - 83 + 121];
      var10000 = I[182 + 199 - 349 + 282];
      var10001 = I[178 + 143 - 92 + 86];
      var10002 = I[99 + 102 - -17 + 98];
      var10001 = I[208 + 224 - 247 + 132];
      var10000 = I[12 + 191 - 80 + 195];
      var10001 = I[31 + 193 - -71 + 24];
      var10002 = I[73 + 251 - 77 + 73];
      var10001 = I[104 + 277 - 321 + 261];
      var10000 = I[7 + 215 - 5 + 105];
      var10001 = I[98 + 159 - 58 + 124];
      var10002 = I[75 + 261 - 261 + 249];
      var10001 = I[159 + 320 - 275 + 121];
      var10000 = I[308 + 73 - 267 + 212];
      var10001 = I[133 + 111 - -6 + 77];
      var10002 = I[197 + 210 - 282 + 203];
      var10001 = I[276 + 327 - 510 + 236];
      var10000 = I[179 + 79 - -29 + 43];
      var10001 = I[63 + 63 - -186 + 19];
      var10002 = I[87 + 42 - 46 + 249];
      var10001 = I[246 + 86 - 42 + 43];
      var10000 = I[29 + 146 - 168 + 327];
      var10001 = I[69 + 287 - 321 + 300];
      var10002 = I[305 + 245 - 540 + 326];
      var10001 = I[227 + 140 - 50 + 20];
      var10000 = I[9 + 47 - -275 + 7];
      var10001 = I[7 + 118 - 119 + 333];
      var10002 = I[248 + 274 - 350 + 168];
      var10001 = I[254 + 20 - 267 + 334];
      var10000 = I[272 + 203 - 319 + 186];
      var10001 = I[102 + 279 - 310 + 272];
      var10002 = I[47 + 55 - -57 + 185];
      var10001 = I[342 + 278 - 420 + 145];
      var10000 = I[255 + 20 - 41 + 112];
      var10001 = I[99 + 337 - 238 + 149];
      var10002 = I[31 + 89 - 67 + 295];
      var10001 = I[116 + 114 - 224 + 343];
      var10000 = I[214 + 104 - 187 + 219];
      var10001 = I[20 + 317 - 132 + 146];
      var10002 = I[315 + 59 - 166 + 144];
      var10001 = I[210 + 218 - 370 + 295];
      var10000 = I[334 + 153 - 205 + 72];
      var10001 = I[65 + 133 - 9 + 166];
      var10002 = I[324 + 331 - 533 + 234];
      var10001 = I[89 + 328 - 134 + 74];
      var10000 = I[266 + 263 - 510 + 339];
      var10001 = I[31 + 197 - 106 + 237];
      var10002 = I[132 + 311 - 320 + 237];
      var10001 = I[8 + 215 - 68 + 206];
      var10000 = I[185 + 183 - 84 + 78];
      var10001 = I[14 + 87 - 0 + 262];
      var10002 = I[290 + 94 - 326 + 306];
      var10001 = I[109 + 6 - -134 + 116];
      var10000 = I[157 + 169 - 76 + 116];
      var10001 = I[130 + 120 - -29 + 88];
      var10002 = I[195 + 227 - 68 + 14];
      var10001 = I[289 + 121 - 117 + 76];
      var10000 = I[195 + 258 - 343 + 260];
      var10001 = I[242 + 180 - 194 + 143];
      var10002 = I[80 + 80 - -92 + 120];
      var10001 = I[361 + 317 - 579 + 274];
      var10000 = I[129 + 98 - 55 + 202];
      var10001 = I[20 + 247 - 94 + 202];
      var10002 = I[313 + 208 - 365 + 220];
      var10001 = I[234 + 78 - 297 + 362];
      var10000 = I[99 + 334 - 406 + 351];
      var10001 = I[165 + 230 - 380 + 364];
      var10002 = I[37 + 127 - -185 + 31];
      var10001 = I[175 + 89 - 83 + 200];
      var10000 = I[264 + 371 - 386 + 133];
      var10001 = I[249 + 86 - 172 + 220];
      var10002 = I[68 + 291 - 303 + 328];
      var10001 = I[226 + 267 - 398 + 290];
      var10000 = I[212 + 1 - -46 + 127];
      var10001 = I[142 + 314 - 229 + 160];
      var10002 = I[206 + 84 - 27 + 125];
      var10001 = I[197 + 141 - 24 + 75];
      var10000 = I[362 + 315 - 376 + 89];
      var10001 = I[159 + 103 - -101 + 28];
      var10002 = I[280 + 304 - 375 + 183];
      var10001 = I[214 + 157 - 184 + 206];
      var10000 = I[3 + 363 - 298 + 326];
      var10001 = I[187 + 78 - 90 + 220];
      var10002 = I[314 + 112 - 221 + 191];
      var10001 = I[261 + 97 - -24 + 15];
      var10000 = I[231 + 335 - 333 + 165];
      var10001 = I[67 + 339 - 336 + 329];
      var10002 = I[185 + 335 - 158 + 38];
      var10001 = I[140 + 352 - 327 + 236];
      var10000 = I[170 + 229 - 10 + 13];
      var10001 = I[61 + 373 - 364 + 333];
      var10002 = I[187 + 226 - 393 + 384];
      var10001 = I[279 + 206 - 367 + 287];
      var10000 = I[26 + 182 - 196 + 394];
      var10001 = I[33 + 163 - 10 + 221];
      var10002 = I[78 + 267 - 143 + 206];
      var10001 = I[192 + 269 - 415 + 363];
      var10000 = I[267 + 200 - 333 + 276];
      var10001 = I[156 + 29 - -138 + 88];
      var10002 = I[313 + 152 - 186 + 133];
      var10001 = I[7 + 62 - -330 + 14];
      var10000 = I[243 + 310 - 248 + 109];
      var10001 = I[359 + 214 - 549 + 391];
      var10002 = I[93 + 191 - 75 + 207];
      var10001 = I[297 + 184 - 433 + 369];
      var10000 = I[104 + 216 - -52 + 46];
      var10001 = I[404 + 310 - 304 + 9];
      var10002 = I[253 + 326 - 248 + 89];
      var10001 = I[386 + 183 - 539 + 391];
      var10000 = I[386 + 43 - 133 + 126];
      var10001 = I[416 + 1 - 52 + 58];
      var10002 = I[45 + 280 - 316 + 415];
      var10001 = I[134 + 181 - 4 + 114];
      var10000 = I[395 + 127 - 461 + 365];
      var10001 = I[30 + 371 - 153 + 179];
      var10002 = I[206 + 359 - 546 + 409];
      var10001 = I[109 + 417 - 209 + 112];
      var10000 = I[199 + 18 - -93 + 120];
      var10001 = I[68 + 55 - -96 + 212];
      var10002 = I[110 + 151 - -81 + 90];
      var10001 = I[49 + 103 - 139 + 420];
      var10000 = I[251 + 288 - 337 + 232];
      var10001 = I[433 + 192 - 522 + 332];
      var10002 = I[365 + 380 - 700 + 391];
      var10001 = I[104 + 304 - 184 + 213];
      var10000 = I[22 + 24 - -367 + 25];
      var10001 = I[175 + 303 - 377 + 338];
      var10002 = I[377 + 92 - 367 + 338];
      var10001 = I[319 + 191 - 433 + 364];
      var10000 = I[370 + 187 - 299 + 184];
      var10001 = I[369 + 319 - 402 + 157];
      var10002 = I[151 + 348 - 265 + 210];
      var10001 = I[238 + 379 - 176 + 4];
      var10000 = I[296 + 49 - 212 + 313];
      var10001 = I[397 + 419 - 403 + 34];
      var10002 = I[389 + 412 - 417 + 64];
      var10001 = I[289 + 350 - 378 + 188];
      var10000 = I[307 + 137 - 237 + 243];
      var10001 = I[295 + 443 - 718 + 431];
      var10002 = I[397 + 451 - 459 + 63];
      var10001 = I[386 + 319 - 281 + 29];
      var10000 = I[52 + 300 - 197 + 299];
      var10001 = I[405 + 134 - 123 + 39];
      var10002 = I[422 + 12 - 425 + 447];
      var10001 = I[131 + 329 - 250 + 247];
      var10000 = I[84 + 125 - 5 + 254];
      var10001 = I[34 + 432 - 109 + 102];
      var10002 = I[193 + 391 - 199 + 75];
      var10001 = I[90 + 7 - -82 + 282];
      var10000 = I[429 + 376 - 801 + 458];
      var10001 = I[308 + 340 - 523 + 338];
      var10002 = I[335 + 244 - 425 + 310];
      var10001 = I[140 + 402 - 533 + 456];
      var10000 = I[52 + 272 - 281 + 423];
      var10001 = I[300 + 402 - 516 + 281];
      var10002 = I[151 + 159 - 8 + 166];
      var10001 = I[287 + 232 - 316 + 266];
      var10000 = I[413 + 123 - 493 + 427];
      var10001 = I[129 + 245 - 347 + 444];
      var10002 = I[456 + 238 - 411 + 189];
      var10001 = I[372 + 356 - 470 + 215];
      var10000 = I[240 + 293 - 235 + 176];
      var10001 = I[211 + 71 - -23 + 170];
      var10002 = I[244 + 227 - 204 + 209];
      var10001 = I[177 + 350 - 367 + 317];
      var10000 = I[186 + 394 - 574 + 472];
      var10001 = I[154 + 91 - 28 + 262];
      var10002 = I[342 + 261 - 305 + 182];
      var10001 = I[299 + 86 - 114 + 210];
      var10000 = I[152 + 406 - 106 + 30];
      var10001 = I[181 + 207 - -37 + 58];
      var10002 = I[58 + 9 - -56 + 361];
      var10001 = I[189 + 384 - 92 + 4];
      var10000 = I[54 + 127 - -201 + 104];
      var10001 = I[256 + 27 - -76 + 128];
      var10002 = I[368 + 480 - 572 + 212];
      var10001 = I[420 + 57 - 216 + 228];
      var10000 = I[161 + 385 - 340 + 284];
      var10001 = I[98 + 132 - 81 + 342];
      var10002 = I[397 + 420 - 667 + 342];
      var10001 = I[337 + 119 - 224 + 261];
      var10000 = I[355 + 308 - 374 + 205];
      var10001 = I[405 + 260 - 360 + 190];
      var10002 = I[71 + 213 - 274 + 486];
      var10001 = I[430 + 28 - 448 + 487];
      var10000 = I[90 + 226 - -67 + 115];
      var10001 = I[423 + 308 - 331 + 99];
      var10002 = I[415 + 257 - 616 + 444];
      var10001 = I[296 + 397 - 370 + 178];
      var10000 = I[405 + 8 - -57 + 32];
      var10001 = I[375 + 265 - 360 + 223];
      var10002 = I[340 + 502 - 342 + 4];
      var10001 = I[395 + 274 - 435 + 271];
      var10000 = I[348 + 286 - 452 + 324];
      var10001 = I[372 + 270 - 395 + 260];
      var10002 = I[170 + 297 - 353 + 394];
      var10001 = I[203 + 127 - -124 + 55];
      var10000 = I[440 + 379 - 655 + 346];
      var10001 = I[485 + 180 - 441 + 287];
      var10002 = I[131 + 93 - -123 + 165];
      var10001 = I[228 + 10 - -180 + 95];
      var10000 = I[126 + 198 - 245 + 435];
      var10001 = I[146 + 395 - 166 + 140];
      var10002 = I[461 + 174 - 513 + 394];
      var10001 = I[408 + 61 - 400 + 448];
      var10000 = I[434 + 300 - 226 + 10];
      var10001 = I[248 + 482 - 454 + 243];
      var10002 = I[231 + 55 - -207 + 27];
      var10001 = I[453 + 171 - 115 + 12];
      var10000 = I[102 + 249 - 319 + 490];
      var10001 = I[449 + 317 - 738 + 495];
      var10002 = I[494 + 58 - 185 + 157];
      var10001 = I[176 + 511 - 293 + 131];
      var10000 = I[249 + 23 - -155 + 99];
      var10001 = I[505 + 480 - 462 + 4];
      var10002 = I[179 + 115 - 252 + 486];
      var10001 = I[528 + 2 - 403 + 402];
      var10000 = I[277 + 286 - 343 + 310];
      var10001 = I[119 + 484 - 391 + 319];
      var10002 = I[111 + 19 - -76 + 326];
      var10001 = I[182 + 318 - 47 + 80];
      var10000 = I[401 + 476 - 618 + 275];
      var10001 = I[240 + 420 - 598 + 473];
      var10002 = I[412 + 215 - 308 + 217];
      var10001 = I[24 + 351 - 40 + 202];
      var10000 = I[467 + 177 - 403 + 297];
      var10001 = I[446 + 310 - 592 + 375];
      var10002 = I[295 + 222 - 419 + 442];
      var10001 = I[241 + 405 - 452 + 347];
      var10000 = I[128 + 460 - 100 + 54];
      var10001 = I[222 + 326 - 48 + 43];
      var10002 = I[261 + 462 - 312 + 133];
      var10001 = I[320 + 509 - 595 + 311];
      var10000 = I[446 + 488 - 649 + 261];
      var10001 = I[114 + 544 - 508 + 397];
      var10002 = I[52 + 117 - -72 + 307];
      var10001 = I[442 + 87 - 99 + 119];
      var10000 = I[430 + 135 - 136 + 121];
      var10001 = I[19 + 351 - -105 + 76];
      var10002 = I[310 + 213 - 33 + 62];
      var10001 = I[419 + 434 - 309 + 9];
      var10000 = I[395 + 465 - 842 + 536];
      var10001 = I[154 + 474 - 145 + 72];
      var10002 = I[530 + 273 - 655 + 408];
      var10001 = I[516 + 188 - 331 + 184];
      var10000 = I[454 + 253 - 532 + 383];
      var10001 = I[139 + 499 - 412 + 333];
      var10002 = I[431 + 125 - 510 + 514];
      var10001 = I[558 + 328 - 558 + 233];
      var10000 = I[35 + 52 - -75 + 400];
      var10001 = I[524 + 461 - 904 + 482];
      var10002 = I[249 + 421 - 257 + 151];
      var10001 = I[144 + 185 - 254 + 490];
      var10000 = I[264 + 388 - 538 + 452];
      var10001 = I[110 + 325 - 414 + 546];
      var10002 = I[42 + 302 - -31 + 193];
      var10001 = I[160 + 549 - 213 + 73];
      var10000 = I[536 + 263 - 658 + 429];
      var10001 = I[423 + 478 - 643 + 313];
      var10002 = I[90 + 342 - -56 + 84];
      var10001 = I[483 + 492 - 480 + 78];
      var10000 = I[369 + 446 - 447 + 206];
      var10001 = I[474 + 549 - 536 + 88];
      var10002 = I[412 + 5 - -138 + 21];
      var10001 = I[139 + 161 - 238 + 515];
      var10000 = I[508 + 522 - 635 + 183];
      var10001 = I[531 + 290 - 382 + 140];
      var10002 = I[429 + 445 - 813 + 519];
      var10001 = I[228 + 444 - 670 + 579];
      var10000 = I[420 + 33 - 150 + 279];
      var10001 = I[40 + 393 - 344 + 494];
      var10002 = I[210 + 79 - 267 + 562];
      var10001 = I[448 + 413 - 575 + 299];
      var10000 = I[227 + 494 - 438 + 303];
      var10001 = I[397 + 163 - 519 + 546];
      var10002 = I[486 + 390 - 764 + 476];
      var10001 = I[8 + 467 - 76 + 190];
      var10000 = I[250 + 390 - 625 + 575];
      var10001 = I[528 + 509 - 837 + 391];
      var10002 = I[199 + 300 - 440 + 533];
      var10001 = I[528 + 2 - 186 + 249];
      var10000 = I[236 + 235 - 229 + 352];
      var10001 = I[442 + 115 - 31 + 69];
      var10002 = I[411 + 147 - 117 + 155];
      var10001 = I[116 + 152 - -140 + 189];
      var10000 = I[78 + 148 - 195 + 567];
      var10001 = I[364 + 396 - 410 + 249];
      var10002 = I[387 + 414 - 729 + 528];
      var10001 = I[208 + 140 - 341 + 594];
      var10000 = I[270 + 168 - -119 + 45];
      var10001 = I[313 + 401 - 329 + 218];
      var10002 = I[539 + 85 - 152 + 132];
      var10001 = I[64 + 573 - 209 + 177];
      var10000 = I[379 + 566 - 591 + 252];
      var10001 = I[184 + 62 - 184 + 545];
      var10002 = I[395 + 89 - 287 + 411];
      var10001 = I[60 + 20 - -453 + 76];
      var10000 = I[71 + 104 - -327 + 108];
      var10001 = I[269 + 424 - 528 + 446];
      var10002 = I[215 + 160 - 246 + 483];
      var10001 = I[315 + 102 - 399 + 595];
      var10000 = I[515 + 144 - 596 + 551];
      var10001 = I[448 + 571 - 689 + 285];
      var10002 = I[111 + 449 - 43 + 99];
      var10001 = I[417 + 282 - 327 + 245];
      var10000 = I[18 + 544 - 196 + 252];
      var10001 = I[553 + 603 - 1068 + 531];
      var10002 = I[295 + 135 - 158 + 348];
      var10001 = I[77 + 132 - -324 + 88];
      var10000 = I[299 + 382 - 536 + 477];
      var10001 = I[384 + 571 - 729 + 397];
      var10002 = I[406 + 559 - 498 + 157];
      var10001 = I[442 + 582 - 799 + 400];
      var10000 = I[224 + 494 - 445 + 353];
      var10001 = I[141 + 419 - -48 + 19];
      var10002 = I[564 + 6 - 389 + 447];
      var10001 = I[501 + 510 - 506 + 124];
      var10000 = I[154 + 360 - 171 + 287];
      var10001 = I[265 + 263 - 62 + 165];
      var10002 = I[554 + 212 - 424 + 290];
      var10001 = I[555 + 537 - 1036 + 577];
      var10000 = I[246 + 438 - 116 + 66];
      var10001 = I[85 + 435 - 487 + 602];
      var10002 = I[610 + 51 - 368 + 343];
      var10001 = I[103 + 63 - -377 + 94];
      var10000 = I[168 + 461 - 118 + 127];
      var10001 = I[16 + 377 - 174 + 420];
      var10002 = I[177 + 565 - 153 + 51];
      var10001 = I[96 + 83 - -87 + 375];
      var10000 = I[376 + 627 - 605 + 244];
      var10001 = I[627 + 398 - 980 + 598];
      var10002 = I[534 + 577 - 752 + 285];
      var10001 = I[379 + 435 - 321 + 152];
      var10000 = I[645 + 122 - 671 + 550];
      var10001 = I[211 + 92 - -121 + 223];
      var10002 = I[72 + 286 - 323 + 613];
      var10001 = I[321 + 299 - 159 + 188];
      var10000 = I[75 + 622 - 286 + 239];
      var10001 = I[132 + 233 - -147 + 139];
      var10002 = I[468 + 441 - 466 + 209];
      var10001 = I[651 + 271 - 768 + 499];
      var10000 = I[29 + 178 - -189 + 258];
      var10001 = I[26 + 47 - -170 + 412];
      var10002 = I[473 + 288 - 637 + 532];
      var10001 = I[36 + 17 - -557 + 47];
      var10000 = I[256 + 488 - 574 + 488];
      var10001 = I[384 + 89 - -142 + 44];
      var10002 = I[385 + 84 - 247 + 438];
      var10001 = I[269 + 208 - 127 + 311];
      var10000 = I[284 + 113 - -149 + 116];
      var10001 = I[399 + 548 - 559 + 275];
      var10002 = I[380 + 644 - 787 + 427];
      var10001 = I[455 + 359 - 497 + 348];
      var10000 = I[180 + 506 - 452 + 432];
      var10001 = I[368 + 362 - 104 + 41];
      var10002 = I[584 + 29 - 270 + 325];
      var10001 = I[270 + 642 - 432 + 189];
      var10000 = I[287 + 236 - 327 + 474];
      var10001 = I[368 + 639 - 816 + 480];
      var10002 = I[520 + 5 - -122 + 25];
      var10001 = I[192 + 66 - -327 + 88];
      var10000 = I[362 + 346 - 576 + 542];
      var10001 = I[515 + 184 - 680 + 656];
      var10002 = I[495 + 232 - 203 + 152];
      var10001 = I[159 + 256 - -172 + 90];
      var10000 = I[138 + 578 - 243 + 205];
      var10001 = I[641 + 416 - 388 + 10];
      var10002 = I[402 + 627 - 976 + 627];
      var10001 = I[322 + 466 - 701 + 594];
      var10000 = I[137 + 309 - 115 + 351];
      var10001 = I[682 + 397 - 451 + 55];
      var10002 = I[581 + 432 - 803 + 474];
      var10001 = I[513 + 325 - 341 + 188];
      var10000 = I[475 + 551 - 776 + 436];
      var10001 = I[58 + 164 - 82 + 547];
      var10002 = I[171 + 235 - 350 + 632];
      var10001 = I[9 + 499 - 101 + 282];
      var10000 = I[122 + 351 - 231 + 448];
      var10001 = I[124 + 169 - -261 + 137];
      var10002 = I[76 + 218 - -254 + 144];
      var10001 = I[415 + 468 - 635 + 445];
      var10000 = I[373 + 530 - 429 + 220];
      var10001 = I[33 + 399 - 303 + 566];
      var10002 = I[341 + 137 - 212 + 430];
      var10001 = I[213 + 487 - 145 + 142];
      var10000 = I[209 + 257 - 363 + 595];
      var10001 = I[621 + 510 - 731 + 299];
      var10002 = I[55 + 201 - -280 + 164];
      var10001 = I[429 + 234 - 56 + 94];
      var10000 = I[188 + 364 - 46 + 196];
      var10001 = I[83 + 478 - 156 + 298];
      var10002 = I[589 + 695 - 973 + 393];
      var10001 = I[691 + 163 - 434 + 285];
      var10000 = I[704 + 533 - 1026 + 495];
      var10001 = I[283 + 295 - 326 + 455];
      var10002 = I[636 + 233 - 690 + 529];
      var10001 = I[286 + 199 - -74 + 150];
      var10000 = I[151 + 7 - -279 + 273];
      var10001 = I[171 + 104 - -149 + 287];
      var10002 = I[145 + 11 - -345 + 211];
      var10001 = I[408 + 285 - 403 + 423];
      var10000 = I[390 + 269 - 214 + 269];
      var10001 = I[714 + 127 - 403 + 277];
      var10002 = I[98 + 544 - 401 + 475];
      var10001 = I[635 + 571 - 842 + 353];
      var10000 = I[133 + 161 - 183 + 607];
      var10001 = I[544 + 429 - 845 + 591];
      var10002 = I[473 + 573 - 921 + 595];
      var10001 = I[560 + 644 - 665 + 182];
      var10000 = I[713 + 211 - 219 + 17];
      var10001 = I[673 + 378 - 859 + 531];
      var10002 = I[67 + 144 - 101 + 614];
      var10001 = I[662 + 539 - 611 + 135];
      var10000 = I[483 + 85 - 540 + 698];
      var10001 = I[665 + 105 - 554 + 511];
      var10002 = I[40 + 311 - -192 + 185];
      var10001 = I[135 + 657 - 507 + 444];
      var10000 = I[648 + 604 - 1109 + 587];
      var10001 = I[109 + 17 - -324 + 281];
      var10002 = I[521 + 48 - 416 + 579];
      var10001 = I[230 + 87 - -299 + 117];
      var10000 = I[598 + 667 - 939 + 408];
      var10001 = I[422 + 48 - 133 + 398];
      var10002 = I[507 + 628 - 461 + 62];
      var10001 = I[370 + 414 - 257 + 210];
      var10000 = I[638 + 625 - 617 + 92];
      var10001 = I[129 + 524 - 98 + 184];
      var10002 = I[95 + 583 - 333 + 395];
      var10001 = I[41 + 715 - 201 + 186];
      var10000 = I[340 + 631 - 430 + 201];
      var10001 = I[175 + 377 - -133 + 58];
      var10002 = I[704 + 187 - 154 + 7];
      var10001 = I[647 + 708 - 1327 + 717];
      var10000 = I[387 + 64 - -154 + 141];
      var10001 = I[743 + 448 - 627 + 183];
      var10002 = I[703 + 117 - 493 + 421];
      var10001 = I[577 + 121 - 235 + 286];
      var10000 = I[317 + 90 - -282 + 61];
      var10001 = I[157 + 298 - 84 + 380];
      var10002 = I[223 + 530 - 19 + 18];
      var10001 = I[698 + 125 - 534 + 464];
      var10000 = I[558 + 299 - 759 + 656];
      var10001 = I[281 + 42 - 139 + 571];
      var10002 = I[88 + 407 - 155 + 416];
      var10001 = I[310 + 103 - 277 + 621];
      var10000 = I[149 + 240 - -95 + 274];
      var10001 = I[515 + 103 - 511 + 652];
      var10002 = I[387 + 587 - 260 + 46];
      var10001 = I[408 + 81 - -13 + 259];
      var10000 = I[152 + 315 - 151 + 446];
      var10001 = I[470 + 369 - 150 + 74];
      var10002 = I[601 + 626 - 466 + 3];
      var10001 = I[489 + 333 - 589 + 532];
      var10000 = I[598 + 726 - 711 + 153];
      var10001 = I[162 + 121 - 185 + 669];
      var10002 = I[143 + 490 - 623 + 758];
      var10001 = I[355 + 91 - 280 + 603];
      var10000 = I[505 + 714 - 772 + 323];
      var10001 = I[215 + 441 - 271 + 386];
      var10002 = I[410 + 548 - 545 + 359];
      var10001 = I[592 + 767 - 651 + 65];
      var10000 = I[250 + 708 - 420 + 236];
      var10001 = I[55 + 237 - -458 + 25];
      var10002 = I[196 + 462 - 335 + 453];
      var10001 = I[626 + 534 - 488 + 105];
      var10000 = I[735 + 677 - 1030 + 396];
      var10001 = I[32 + 109 - -249 + 389];
      var10002 = I[37 + 384 - -83 + 276];
      var10001 = I[697 + 592 - 744 + 236];
      var10000 = I[403 + 627 - 737 + 489];
      var10001 = I[219 + 110 - -277 + 177];
      var10002 = I[136 + 245 - -98 + 305];
      var10001 = I[219 + 203 - 295 + 658];
      var10000 = I[339 + 266 - -48 + 133];
      var10001 = I[453 + 457 - 364 + 241];
      var10002 = I[269 + 709 - 590 + 400];
      var10001 = I[115 + 589 - 359 + 444];
      var10000 = I[110 + 109 - -127 + 444];
      var10001 = I[348 + 538 - 217 + 122];
      var10002 = I[759 + 48 - 474 + 459];
      var10001 = I[481 + 749 - 791 + 354];
      var10000 = I[430 + 22 - 368 + 710];
      var10001 = I[441 + 625 - 552 + 281];
      var10002 = I[155 + 16 - -83 + 542];
      var10001 = I[688 + 622 - 1200 + 687];
      var10000 = I[761 + 407 - 440 + 70];
      var10001 = I[383 + 451 - 398 + 363];
      var10002 = I[357 + 485 - 757 + 715];
      var10001 = I[596 + 158 - 603 + 650];
      var10000 = I[290 + 284 - -46 + 182];
      var10001 = I[462 + 605 - 400 + 136];
      var10002 = I[279 + 339 - 246 + 432];
      var10001 = I[223 + 89 - 173 + 666];
      var10000 = I[740 + 677 - 1030 + 419];
      var10001 = I[253 + 257 - 128 + 425];
      var10002 = I[632 + 369 - 728 + 535];
      var10001 = I[614 + 484 - 705 + 416];
      var10000 = I[647 + 525 - 991 + 629];
      var10001 = I[261 + 656 - 183 + 77];
      var10002 = I[130 + 283 - -113 + 286];
      var10001 = I[385 + 246 - 360 + 542];
      var10000 = I[131 + 212 - 17 + 488];
      var10001 = I[305 + 760 - 907 + 657];
      var10002 = I[769 + 290 - 303 + 60];
      var10001 = I[171 + 2 - -530 + 114];
      var10000 = I[51 + 292 - -408 + 67];
      var10001 = I[143 + 483 - 443 + 636];
      var10002 = I[465 + 676 - 794 + 473];
      var10001 = I[352 + 404 - 253 + 318];
      var10000 = I[314 + 543 - 59 + 24];
      var10001 = I[170 + 662 - 599 + 590];
      var10002 = I[43 + 428 - -39 + 314];
      var10001 = I[609 + 141 - 436 + 511];
      var10000 = I[170 + 542 - 443 + 557];
      var10001 = I[798 + 719 - 1018 + 328];
      var10002 = I[303 + 740 - 1039 + 824];
      var10001 = I[521 + 656 - 1122 + 774];
      var10000 = I[562 + 630 - 452 + 90];
      var10001 = I[765 + 398 - 492 + 160];
      var10002 = I[409 + 561 - 421 + 283];
      var10001 = I[15 + 57 - -201 + 560];
      var10000 = I[720 + 337 - 862 + 639];
      var10001 = I[426 + 565 - 406 + 250];
      var10002 = I[289 + 356 - 423 + 614];
      var10001 = I[717 + 679 - 1238 + 679];
      var10000 = I[429 + 685 - 463 + 187];
      var10001 = I[588 + 348 - 474 + 377];
      var10002 = I[610 + 487 - 580 + 323];
      var10001 = I[141 + 689 - 370 + 381];
      var10000 = I[370 + 139 - 219 + 552];
      var10001 = I[731 + 604 - 589 + 97];
      var10002 = I[760 + 211 - 296 + 169];
      var10001 = I[6 + 134 - -559 + 146];
      var10000 = I[741 + 285 - 805 + 625];
      var10001 = I[393 + 822 - 1052 + 684];
      var10002 = I[758 + 262 - 491 + 319];
      var10001 = I[652 + 367 - 244 + 74];
      var10000 = I[372 + 183 - 450 + 745];
      var10001 = I[182 + 807 - 811 + 673];
      var10002 = I[788 + 422 - 602 + 244];
      var10001 = I[286 + 477 - 28 + 118];
      var10000 = I[341 + 83 - 357 + 787];
      var10001 = I[374 + 295 - -173 + 13];
      var10002 = I[569 + 304 - 233 + 216];
      var10001 = I[31 + 771 - 457 + 512];
      var10000 = I[647 + 534 - 484 + 161];
      var10001 = I[7 + 215 - -112 + 525];
      var10002 = I[761 + 639 - 1027 + 487];
      var10001 = I[725 + 126 - -9 + 1];
      var10000 = I[675 + 790 - 1317 + 714];
      var10001 = I[266 + 708 - 656 + 545];
      var10002 = I[486 + 376 - 62 + 64];
      var10001 = I[843 + 547 - 911 + 386];
      var10000 = I[358 + 625 - 186 + 69];
      var10001 = I[657 + 210 - 208 + 208];
      var10002 = I[717 + 583 - 630 + 198];
      var10001 = I[341 + 648 - 421 + 301];
      var10000 = I[800 + 792 - 1463 + 741];
      var10001 = I[105 + 830 - 700 + 636];
      var10002 = I[3 + 581 - 315 + 603];
      var10001 = I[724 + 722 - 826 + 253];
      var10000 = I[687 + 723 - 1288 + 752];
      var10001 = I[418 + 760 - 390 + 87];
      var10002 = I[506 + 789 - 1240 + 821];
      var10001 = I[54 + 210 - -555 + 58];
      var10000 = I[201 + 403 - -236 + 38];
      var10001 = I[473 + 230 - 15 + 191];
      var10002 = I[659 + 877 - 1126 + 470];
      var10001 = I[500 + 260 - 639 + 760];
      var10000 = I[100 + 343 - -60 + 379];
      var10001 = I[159 + 850 - 607 + 481];
      var10002 = I[827 + 377 - 1059 + 739];
      var10001 = I[225 + 281 - 452 + 831];
      var10000 = I[826 + 409 - 490 + 141];
      var10001 = I[839 + 157 - 584 + 475];
      var10002 = I[149 + 106 - -24 + 609];
      var10001 = I[202 + 254 - 40 + 473];
      var10000 = I[356 + 238 - -38 + 258];
      var10001 = I[415 + 428 - 366 + 414];
      var10002 = I[138 + 438 - 282 + 598];
      var10001 = I[220 + 424 - 331 + 580];
      var10000 = I[21 + 193 - -204 + 476];
      var10001 = I[269 + 12 - -473 + 141];
      var10002 = I[776 + 105 - 648 + 663];
      var10001 = I[132 + 711 - 305 + 359];
      var10000 = I[460 + 610 - 334 + 162];
      var10001 = I[847 + 101 - 735 + 686];
      var10002 = I[885 + 272 - 1064 + 807];
      var10001 = I[280 + 825 - 223 + 19];
      var10000 = I[853 + 796 - 1479 + 732];
      var10001 = I[299 + 334 - 110 + 380];
      var10002 = I[378 + 758 - 708 + 476];
      var10001 = I[431 + 384 - 67 + 157];
      var10000 = I[657 + 95 - -28 + 126];
      var10001 = I[117 + 795 - 603 + 598];
      var10002 = I[356 + 647 - 184 + 89];
      var10001 = I[139 + 759 - 645 + 656];
      var10000 = I[898 + 397 - 479 + 94];
      var10001 = I[725 + 535 - 650 + 301];
      var10002 = I[563 + 866 - 993 + 476];
      var10001 = I[566 + 162 - 523 + 708];
      var10000 = I[613 + 362 - 739 + 678];
      var10001 = I[800 + 346 - 337 + 106];
      var10002 = I[180 + 655 - 777 + 858];
      var10001 = I[914 + 869 - 1235 + 369];
      var10000 = I[585 + 177 - 392 + 548];
      var10001 = I[553 + 694 - 521 + 193];
      var10002 = I[101 + 870 - 828 + 777];
      var10001 = I[780 + 572 - 979 + 548];
      var10000 = I[834 + 404 - 523 + 207];
      var10001 = I[184 + 341 - -269 + 129];
      var10002 = I[844 + 823 - 1245 + 502];
      var10001 = I[868 + 629 - 809 + 237];
      var10000 = I[634 + 672 - 470 + 90];
      var10001 = I[222 + 308 - -45 + 352];
      var10002 = I[573 + 782 - 1032 + 605];
      var10001 = I[220 + 360 - -129 + 220];
      var10000 = I[25 + 408 - 19 + 516];
      var10001 = I[307 + 806 - 661 + 479];
      var10002 = I[747 + 427 - 948 + 706];
      var10001 = I[380 + 361 - 225 + 417];
      var10000 = I[100 + 298 - 289 + 825];
      var10001 = I[207 + 53 - -145 + 530];
      var10002 = I[713 + 47 - 466 + 642];
      var10001 = I[714 + 642 - 1037 + 618];
      var10000 = I[244 + 494 - 682 + 882];
      var10001 = I[890 + 281 - 507 + 275];
      var10002 = I[178 + 239 - 394 + 917];
      var10001 = I[828 + 818 - 1629 + 924];
      var10000 = I[772 + 233 - 97 + 34];
      var10001 = I[555 + 239 - 367 + 516];
      var10002 = I[546 + 226 - 467 + 639];
      var10001 = I[138 + 14 - -65 + 728];
      var10000 = I[733 + 2 - -94 + 117];
      var10001 = I[938 + 317 - 1106 + 798];
      var10002 = I[737 + 834 - 830 + 207];
      var10001 = I[841 + 146 - 507 + 469];
      var10000 = I[313 + 352 - 594 + 879];
      var10001 = I[830 + 305 - 631 + 447];
      var10002 = I[91 + 287 - 222 + 796];
      var10001 = I[477 + 729 - 814 + 561];
      var10000 = I[144 + 716 - 102 + 196];
      var10001 = I[670 + 456 - 448 + 277];
      var10002 = I[89 + 728 - 674 + 813];
      var10001 = I[458 + 479 - 340 + 360];
      var10000 = I[834 + 94 - 238 + 268];
      var10001 = I[100 + 286 - -399 + 174];
      var10002 = I[511 + 947 - 1214 + 716];
      var10001 = I[429 + 402 - 734 + 864];
      var10000 = I[622 + 303 - 895 + 932];
      var10001 = I[663 + 494 - 558 + 364];
      var10002 = I[633 + 772 - 803 + 362];
      var10001 = I[127 + 642 - 169 + 365];
      var10000 = I[20 + 578 - 231 + 599];
      var10001 = I[42 + 655 - 243 + 513];
      var10002 = I[133 + 563 - 97 + 369];
      var10001 = I[908 + 81 - 308 + 288];
      var10000 = I[203 + 719 - 13 + 61];
      var10001 = I[360 + 261 - 345 + 695];
      var10002 = I[405 + 375 - 82 + 274];
      var10001 = I[527 + 236 - 562 + 772];
      var10000 = I[377 + 565 - 22 + 54];
      var10001 = I[105 + 763 - 257 + 364];
      var10002 = I[766 + 200 - 528 + 538];
      var10001 = I[391 + 848 - 544 + 282];
      var10000 = I[439 + 106 - 256 + 689];
      var10001 = I[457 + 815 - 1209 + 916];
      var10002 = I[96 + 528 - -295 + 61];
      var10001 = I[437 + 923 - 1185 + 806];
      var10000 = I[190 + 600 - 370 + 562];
      var10001 = I[28 + 690 - -182 + 83];
      var10002 = I[171 + 26 - -405 + 382];
      var10001 = I[275 + 406 - 337 + 641];
      var10000 = I[687 + 560 - 1070 + 809];
      var10001 = I[176 + 50 - -84 + 677];
      var10002 = I[80 + 279 - -78 + 551];
      var10001 = I[360 + 707 - 848 + 770];
      var10000 = I[593 + 592 - 329 + 134];
      var10001 = I[524 + 562 - 460 + 365];
      var10002 = I[618 + 773 - 912 + 513];
      var10001 = I[718 + 815 - 1276 + 736];
      var10000 = I[868 + 427 - 814 + 513];
      var10001 = I[215 + 118 - -166 + 496];
      var10002 = I[777 + 976 - 1040 + 283];
      var10001 = I[102 + 235 - -389 + 271];
      var10000 = I[586 + 932 - 1114 + 594];
      var10001 = I[256 + 807 - 614 + 550];
      var10002 = I[465 + 951 - 1324 + 908];
      var10001 = I[154 + 749 - 232 + 330];
      var10000 = I[229 + 856 - 843 + 760];
      var10001 = I[103 + 649 - 360 + 611];
      var10002 = I[383 + 785 - 183 + 19];
      var10001 = I[797 + 976 - 1448 + 680];
      var10000 = I[114 + 974 - 104 + 22];
      var10001 = I[594 + 979 - 738 + 172];
      var10002 = I[737 + 976 - 1049 + 344];
      var10001 = I[209 + 403 - -113 + 284];
      var10000 = I[987 + 505 - 698 + 216];
      var10001 = I[890 + 639 - 757 + 239];
      var10002 = I[59 + 311 - 47 + 689];
      var10001 = I[29 + 804 - 370 + 550];
      var10000 = I[690 + 153 - 214 + 385];
      var10001 = I[985 + 942 - 1279 + 367];
      var10002 = I[643 + 378 - 992 + 987];
      var10001 = I[95 + 610 - -31 + 281];
      var10000 = I[809 + 942 - 1548 + 815];
      var10001 = I[253 + 970 - 645 + 441];
      var10002 = I[977 + 166 - 829 + 706];
      var10001 = I[156 + 15 - 102 + 952];
      var10000 = I[431 + 679 - 246 + 158];
      var10001 = I[79 + 862 - 225 + 307];
      var10002 = I[182 + 214 - 197 + 825];
      var10001 = I[951 + 688 - 1267 + 653];
      var10000 = I[372 + 641 - 906 + 919];
      var10001 = I[637 + 911 - 839 + 318];
      var10002 = I[598 + 953 - 701 + 178];
      var10001 = I[635 + 624 - 817 + 587];
      var10000 = I[979 + 633 - 1494 + 912];
      var10001 = I[188 + 677 - 287 + 453];
      var10002 = I[899 + 959 - 1811 + 985];
      var10001 = I[684 + 348 - 786 + 787];
      var10000 = I[840 + 205 - 449 + 438];
      var10001 = I[958 + 826 - 1768 + 1019];
      var10002 = I[78 + 631 - 66 + 393];
      var10001 = I[637 + 188 - -161 + 51];
      var10000 = I[693 + 964 - 893 + 274];
      var10001 = I[921 + 623 - 1180 + 675];
      var10002 = I[903 + 328 - 261 + 70];
      var10001 = I[884 + 154 - 542 + 545];
      var10000 = I[420 + 199 - -64 + 359];
      var10001 = I[188 + 602 - 660 + 913];
      var10002 = I[665 + 214 - 860 + 1025];
      var10001 = I[884 + 604 - 832 + 389];
      var10000 = I[419 + 721 - 1041 + 947];
      var10001 = I[891 + 680 - 1423 + 899];
      var10002 = I[725 + 844 - 632 + 111];
      var10001 = I[461 + 377 - 149 + 360];
      var10000 = I[13 + 809 - 467 + 695];
      var10001 = I[172 + 724 - -139 + 16];
      var10002 = I[997 + 875 - 1125 + 305];
      var10001 = I[632 + 577 - 193 + 37];
      var10000 = I[773 + 98 - 515 + 698];
      var10001 = I[675 + 1045 - 673 + 8];
      var10002 = I[911 + 767 - 1178 + 556];
      var10001 = I[804 + 901 - 1511 + 863];
      var10000 = I[835 + 477 - 255 + 1];
      var10001 = I[584 + 62 - 548 + 961];
      var10002 = I[432 + 200 - -290 + 138];
      var10001 = I[682 + 1006 - 1486 + 859];
      var10000 = I[433 + 887 - 430 + 172];
      var10001 = I[213 + 698 - 482 + 634];
      var10002 = I[940 + 110 - 709 + 723];
      var10001 = I[979 + 84 - 783 + 785];
      var10000 = I[823 + 960 - 1762 + 1045];
      var10001 = I[1002 + 524 - 613 + 154];
      var10002 = I[433 + 691 - 770 + 714];
      var10001 = I[24 + 276 - -680 + 89];
      var10000 = I[945 + 670 - 1441 + 896];
      var10001 = I[156 + 1049 - 1155 + 1021];
      var10002 = I[814 + 778 - 1224 + 704];
      var10001 = I[477 + 899 - 809 + 506];
      var10000 = I[395 + 728 - 392 + 343];
      var10001 = I[530 + 521 - 366 + 390];
      var10002 = I[255 + 36 - -532 + 253];
      var10001 = I[957 + 831 - 1390 + 679];
      var10000 = I[810 + 80 - 360 + 548];
      var10001 = I[215 + 814 - 614 + 664];
      var10002 = I[141 + 579 - 21 + 381];
      var10001 = I[633 + 267 - 828 + 1009];
      var10000 = I[546 + 754 - 395 + 177];
      var10001 = I[154 + 161 - 244 + 1012];
      var10002 = I[582 + 212 - 147 + 437];
      var10001 = I[944 + 78 - 660 + 723];
      var10000 = I[141 + 281 - 295 + 959];
      var10001 = I[526 + 382 - 729 + 908];
      var10002 = I[255 + 510 - -168 + 155];
      var10001 = I[219 + 381 - -82 + 407];
      var10000 = I[980 + 520 - 1382 + 972];
      var10001 = I[1050 + 998 - 1176 + 219];
      var10002 = I[540 + 89 - -427 + 36];
      var10001 = I[15 + 824 - 589 + 843];
      var10000 = I[33 + 890 - 591 + 762];
      var10001 = I[320 + 87 - -409 + 279];
      var10002 = I[499 + 856 - 1272 + 1013];
      var10001 = I[1000 + 627 - 1124 + 594];
      var10000 = I[354 + 113 - -69 + 562];
      var10001 = I[239 + 196 - -325 + 339];
      var10002 = I[200 + 883 - 296 + 313];
      var10001 = I[750 + 610 - 1023 + 764];
      var10000 = I[93 + 567 - 289 + 731];
      var10001 = I[564 + 597 - 535 + 477];
      var10002 = I[608 + 898 - 1173 + 771];
      var10001 = I[423 + 769 - 163 + 76];
      var10000 = I[561 + 710 - 579 + 414];
      var10001 = I[477 + 847 - 252 + 35];
      var10002 = I[515 + 907 - 1045 + 731];
      var10001 = I[934 + 658 - 730 + 247];
      var10000 = I[847 + 226 - 355 + 392];
      var10001 = I[323 + 193 - -519 + 76];
      var10002 = I[832 + 876 - 831 + 235];
      var10001 = I[225 + 586 - 311 + 613];
      var10000 = I[322 + 1025 - 451 + 218];
      var10001 = I[1046 + 193 - 927 + 803];
      var10002 = I[962 + 1083 - 1337 + 408];
      var10001 = I[766 + 252 - 738 + 837];
      var10000 = I[55 + 584 - -68 + 411];
      var10001 = I[498 + 662 - 490 + 449];
      var10002 = I[714 + 410 - 899 + 895];
      var10001 = I[569 + 861 - 1019 + 710];
      var10000 = I[827 + 821 - 1023 + 497];
      var10001 = I[836 + 455 - 666 + 498];
      var10002 = I[440 + 804 - 139 + 19];
      var10001 = I[880 + 906 - 1579 + 918];
      var10000 = I[175 + 904 - 788 + 835];
      var10001 = I[163 + 682 - 503 + 785];
      var10002 = I[842 + 427 - 938 + 797];
      var10001 = I[947 + 1045 - 1714 + 851];
      var10000 = I[509 + 770 - 859 + 710];
      var10001 = I[510 + 848 - 596 + 369];
      var10002 = I[303 + 441 - 164 + 552];
      var10001 = I[250 + 289 - 501 + 1095];
      var10000 = I[1017 + 274 - 275 + 118];
      var10001 = I[779 + 83 - 590 + 863];
      var10002 = I[457 + 301 - -81 + 297];
      var10001 = I[818 + 23 - 12 + 308];
      var10000 = I[37 + 1133 - 1031 + 999];
      var10001 = I[4 + 397 - -489 + 249];
      var10002 = I[787 + 174 - 99 + 278];
      var10001 = I[935 + 155 - 599 + 650];
      var10000 = I[653 + 355 - 974 + 1108];
      var10001 = I[48 + 694 - 277 + 678];
      var10002 = I[458 + 586 - 367 + 467];
      var10001 = I[1141 + 454 - 1079 + 629];
      var10000 = I[746 + 420 - 405 + 385];
      var10001 = I[251 + 546 - 414 + 764];
      var10002 = I[479 + 178 - 43 + 534];
      var10001 = I[715 + 299 - 253 + 388];
      var10000 = I[79 + 497 - 536 + 1110];
      var10001 = I[210 + 282 - -650 + 9];
      var10002 = I[842 + 1087 - 1919 + 1142];
      var10001 = I[286 + 131 - -448 + 288];
      int var30 = "".length();
      ResourceLocation var33 = AIR_ID;
      I[87 + 1032 - 576 + 611].length();
      I[933 + 83 - 879 + 1018].length();
      I[190 + 838 - 823 + 951].length();
      I[834 + 552 - 1282 + 1053].length();
      registerBlock(var30, var33, (new BlockAir()).setUnlocalizedName(I[1041 + 367 - 1289 + 1039]));
      var30 = " ".length();
      var10001 = I[245 + 740 - -151 + 23];
      I[334 + 200 - -309 + 317].length();
      I[457 + 661 - 682 + 725].length();
      registerBlock(var30, var10001, (new BlockStone()).setHardness(1.5F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[997 + 540 - 1270 + 895]));
      var30 = "  ".length();
      var10001 = I[1031 + 747 - 662 + 47];
      I[950 + 20 - 161 + 355].length();
      I[11 + 40 - -346 + 768].length();
      I[1037 + 642 - 566 + 53].length();
      I[461 + 401 - 499 + 804].length();
      registerBlock(var30, var10001, (new BlockGrass()).setHardness(0.6F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[1063 + 454 - 1308 + 959]));
      var30 = "   ".length();
      var10001 = I[59 + 912 - 843 + 1041];
      I[291 + 617 - 591 + 853].length();
      I[411 + 431 - -229 + 100].length();
      I[509 + 293 - -119 + 251].length();
      registerBlock(var30, var10001, (new BlockDirt()).setHardness(0.5F).setSoundType(SoundType.GROUND).setUnlocalizedName(I[32 + 542 - 341 + 940]));
      I[983 + 469 - 442 + 164].length();
      I[949 + 981 - 1007 + 252].length();
      Block var0 = (new Block(Material.ROCK)).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[575 + 370 - 59 + 290]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
      registerBlock(104 ^ 108, I[66 + 483 - 322 + 950], var0);
      I[947 + 1113 - 1657 + 775].length();
      I[800 + 12 - -330 + 37].length();
      I[940 + 362 - 1276 + 1154].length();
      I[406 + 282 - 624 + 1117].length();
      I[1078 + 413 - 931 + 622].length();
      Block var1 = (new BlockPlanks()).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[609 + 882 - 1089 + 781]);
      registerBlock(93 ^ 88, I[794 + 947 - 1155 + 598], var1);
      var30 = 9 ^ 15;
      var10001 = I[408 + 1174 - 1447 + 1050];
      I[222 + 147 - -733 + 84].length();
      I[711 + 487 - 607 + 596].length();
      I[916 + 336 - 1244 + 1180].length();
      registerBlock(var30, var10001, (new BlockSapling()).setHardness(0.0F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[754 + 595 - 1207 + 1047]));
      var30 = 177 ^ 182;
      var10001 = I[383 + 1168 - 857 + 496];
      I[289 + 387 - 362 + 877].length();
      registerBlock(var30, var10001, (new BlockEmptyDrops(Material.ROCK)).setBlockUnbreakable().setResistance(6000000.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[156 + 601 - 408 + 843]).disableStats().setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 49 ^ 57;
      var10001 = I[422 + 1033 - 1236 + 974];
      I[387 + 502 - 786 + 1091].length();
      registerBlock(var30, var10001, (new BlockDynamicLiquid(Material.WATER)).setHardness(100.0F).setLightOpacity("   ".length()).setUnlocalizedName(I[396 + 211 - -562 + 26]).disableStats());
      var30 = 72 ^ 65;
      var10001 = I[1170 + 928 - 1387 + 485];
      I[462 + 1039 - 430 + 126].length();
      registerBlock(var30, var10001, (new BlockStaticLiquid(Material.WATER)).setHardness(100.0F).setLightOpacity("   ".length()).setUnlocalizedName(I[888 + 640 - 1134 + 804]).disableStats());
      var30 = 78 ^ 68;
      var10001 = I[984 + 61 - 248 + 402];
      I[1191 + 724 - 1637 + 922].length();
      I[525 + 884 - 765 + 557].length();
      I[786 + 770 - 1100 + 746].length();
      registerBlock(var30, var10001, (new BlockDynamicLiquid(Material.LAVA)).setHardness(100.0F).setLightLevel(1.0F).setUnlocalizedName(I[965 + 792 - 1609 + 1055]).disableStats());
      var30 = 185 ^ 178;
      var10001 = I[578 + 766 - 559 + 419];
      I[899 + 690 - 1368 + 984].length();
      registerBlock(var30, var10001, (new BlockStaticLiquid(Material.LAVA)).setHardness(100.0F).setLightLevel(1.0F).setUnlocalizedName(I[1116 + 157 - 485 + 418]).disableStats());
      var30 = 203 ^ 199;
      var10001 = I[899 + 10 - -150 + 148];
      I[316 + 494 - -393 + 5].length();
      I[1149 + 795 - 1129 + 394].length();
      registerBlock(var30, var10001, (new BlockSand()).setHardness(0.5F).setSoundType(SoundType.SAND).setUnlocalizedName(I[820 + 753 - 1238 + 875]));
      var30 = 113 ^ 124;
      var10001 = I[1059 + 108 - 141 + 185];
      I[384 + 954 - 321 + 195].length();
      registerBlock(var30, var10001, (new BlockGravel()).setHardness(0.6F).setSoundType(SoundType.GROUND).setUnlocalizedName(I[700 + 323 - 335 + 525]));
      var30 = 93 ^ 83;
      var10001 = I[210 + 711 - 478 + 771];
      I[763 + 667 - 1334 + 1119].length();
      I[919 + 637 - 414 + 74].length();
      I[347 + 653 - 397 + 614].length();
      registerBlock(var30, var10001, (new BlockOre()).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[758 + 27 - -234 + 199]));
      var30 = 9 ^ 6;
      var10001 = I[492 + 951 - 623 + 399];
      I[755 + 902 - 1149 + 712].length();
      I[1139 + 862 - 1444 + 664].length();
      I[1031 + 412 - 876 + 655].length();
      I[684 + 229 - 826 + 1136].length();
      registerBlock(var30, var10001, (new BlockOre()).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[9 + 200 - 143 + 1158]));
      var30 = 45 ^ 61;
      var10001 = I[10 + 1132 - 484 + 567];
      I[1089 + 635 - 891 + 393].length();
      I[105 + 81 - -274 + 767].length();
      registerBlock(var30, var10001, (new BlockOre()).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[48 + 294 - -679 + 207]));
      var30 = 143 ^ 158;
      var10001 = I[643 + 4 - -192 + 390];
      I[293 + 828 - 1089 + 1198].length();
      I[1126 + 577 - 1418 + 946].length();
      I[653 + 350 - -28 + 201].length();
      registerBlock(var30, var10001, (new BlockOldLog()).setUnlocalizedName(I[1099 + 301 - 1041 + 874]));
      var30 = 58 ^ 40;
      var10001 = I[585 + 603 - 1005 + 1051];
      I[678 + 212 - 648 + 993].length();
      I[691 + 792 - 750 + 503].length();
      I[630 + 820 - 543 + 330].length();
      I[309 + 18 - -359 + 552].length();
      registerBlock(var30, var10001, (new BlockOldLeaf()).setUnlocalizedName(I[7 + 589 - -555 + 88]));
      var30 = 162 ^ 177;
      var10001 = I[1224 + 112 - 748 + 652];
      I[304 + 216 - -318 + 403].length();
      I[579 + 54 - 559 + 1168].length();
      I[932 + 576 - 639 + 374].length();
      I[1124 + 737 - 623 + 6].length();
      I[852 + 147 - -200 + 46].length();
      registerBlock(var30, var10001, (new BlockSponge()).setHardness(0.6F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[517 + 156 - 593 + 1166]));
      var30 = 214 ^ 194;
      var10001 = I[409 + 224 - -310 + 304];
      I[1062 + 169 - 814 + 831].length();
      I[1146 + 866 - 1389 + 626].length();
      registerBlock(var30, var10001, (new BlockGlass(Material.GLASS, (boolean)"".length())).setHardness(0.3F).setSoundType(SoundType.GLASS).setUnlocalizedName(I[574 + 1107 - 595 + 164]));
      var30 = 14 ^ 27;
      var10001 = I[533 + 434 - -116 + 168];
      I[418 + 1130 - 1109 + 813].length();
      registerBlock(var30, var10001, (new BlockOre()).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1171 + 756 - 1397 + 723]));
      var30 = 23 ^ 1;
      var10001 = I[412 + 33 - 24 + 833];
      I[292 + 529 - 95 + 529].length();
      I[154 + 218 - -720 + 164].length();
      I[606 + 102 - -357 + 192].length();
      registerBlock(var30, var10001, (new Block(Material.IRON, MapColor.LAPIS)).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[691 + 242 - 631 + 956]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 31 ^ 8;
      var10001 = I[715 + 1179 - 744 + 109];
      I[935 + 630 - 1027 + 722].length();
      registerBlock(var30, var10001, (new BlockDispenser()).setHardness(3.5F).setSoundType(SoundType.STONE).setUnlocalizedName(I[245 + 222 - 378 + 1172]));
      I[575 + 735 - 956 + 908].length();
      I[869 + 383 - 836 + 847].length();
      Block var2 = (new BlockSandStone()).setSoundType(SoundType.STONE).setHardness(0.8F).setUnlocalizedName(I[1035 + 1053 - 1226 + 402]);
      registerBlock(29 ^ 5, I[645 + 663 - 773 + 730], var2);
      var30 = 173 ^ 180;
      var10001 = I[262 + 821 - 417 + 600];
      I[751 + 976 - 654 + 194].length();
      registerBlock(var30, var10001, (new BlockNote()).setSoundType(SoundType.WOOD).setHardness(0.8F).setUnlocalizedName(I[550 + 377 - 303 + 644]));
      var30 = 169 ^ 179;
      var10001 = I[508 + 771 - 101 + 91];
      I[231 + 369 - -314 + 356].length();
      I[779 + 315 - 1071 + 1248].length();
      I[587 + 594 - 884 + 975].length();
      registerBlock(var30, var10001, (new BlockBed()).setSoundType(SoundType.WOOD).setHardness(0.2F).setUnlocalizedName(I[592 + 265 - -233 + 183]).disableStats());
      var30 = 39 ^ 60;
      var10001 = I[1227 + 53 - 1162 + 1156];
      I[1143 + 624 - 588 + 96].length();
      registerBlock(var30, var10001, (new BlockRailPowered()).setHardness(0.7F).setSoundType(SoundType.METAL).setUnlocalizedName(I[300 + 7 - -290 + 679]));
      var30 = 26 ^ 6;
      var10001 = I[955 + 166 - 388 + 544];
      I[1097 + 1000 - 1063 + 244].length();
      I[112 + 740 - 757 + 1184].length();
      registerBlock(var30, var10001, (new BlockRailDetector()).setHardness(0.7F).setSoundType(SoundType.METAL).setUnlocalizedName(I[1226 + 615 - 1254 + 693]));
      var30 = 115 ^ 110;
      var10001 = I[1140 + 26 - 463 + 578];
      I[1137 + 274 - 465 + 336].length();
      I[212 + 809 - 258 + 520].length();
      registerBlock(var30, var10001, (new BlockPistonBase((boolean)" ".length())).setUnlocalizedName(I[1087 + 182 - 1176 + 1191]));
      var30 = 87 ^ 73;
      var10001 = I[897 + 131 - 808 + 1065];
      I[432 + 1184 - 680 + 350].length();
      I[500 + 873 - 110 + 24].length();
      registerBlock(var30, var10001, (new BlockWeb()).setLightOpacity(" ".length()).setHardness(4.0F).setUnlocalizedName(I[466 + 896 - 296 + 222]));
      var30 = 118 ^ 105;
      var10001 = I[430 + 66 - -523 + 270];
      I[729 + 380 - 125 + 306].length();
      I[603 + 912 - 1178 + 954].length();
      I[381 + 188 - 455 + 1178].length();
      registerBlock(var30, var10001, (new BlockTallGrass()).setHardness(0.0F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[781 + 538 - 356 + 330]));
      var30 = 153 ^ 185;
      var10001 = I[114 + 324 - -43 + 813];
      I[274 + 121 - -873 + 27].length();
      I[746 + 1253 - 853 + 150].length();
      I[686 + 85 - 279 + 805].length();
      I[228 + 348 - 495 + 1217].length();
      registerBlock(var30, var10001, (new BlockDeadBush()).setHardness(0.0F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[1007 + 930 - 918 + 280]));
      var30 = 114 ^ 83;
      var10001 = I[731 + 885 - 1426 + 1110];
      I[233 + 383 - -638 + 47].length();
      I[666 + 252 - 515 + 899].length();
      I[998 + 1202 - 1670 + 773].length();
      registerBlock(var30, var10001, (new BlockPistonBase((boolean)"".length())).setUnlocalizedName(I[193 + 582 - -513 + 16]));
      var30 = 230 ^ 196;
      var10001 = I[395 + 767 - 814 + 957];
      I[316 + 1201 - 873 + 662].length();
      I[832 + 355 - 1039 + 1159].length();
      I[1032 + 1276 - 1404 + 404].length();
      registerBlock(var30, var10001, (new BlockPistonExtension()).setUnlocalizedName(I[1308 + 258 - 806 + 549]));
      var30 = 22 ^ 53;
      var10001 = I[1296 + 1247 - 1821 + 588];
      I[737 + 257 - -251 + 66].length();
      I[418 + 914 - 144 + 124].length();
      I[232 + 1027 - 597 + 651].length();
      I[425 + 1042 - 688 + 535].length();
      registerBlock(var30, var10001, (new BlockColored(Material.CLOTH)).setHardness(0.8F).setSoundType(SoundType.CLOTH).setUnlocalizedName(I[739 + 274 - -46 + 256]));
      var30 = 99 ^ 71;
      var10001 = I[387 + 760 - 858 + 1027];
      I[727 + 279 - 223 + 534].length();
      I[410 + 42 - -726 + 140].length();
      registerBlock(var30, (String)var10001, new BlockPistonMoving());
      var30 = 8 ^ 45;
      var10001 = I[760 + 728 - 272 + 103];
      I[77 + 152 - -517 + 574].length();
      I[260 + 1096 - 1329 + 1294].length();
      registerBlock(var30, var10001, (new BlockYellowFlower()).setHardness(0.0F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[504 + 805 - 649 + 662]));
      var30 = 17 ^ 55;
      var10001 = I[85 + 579 - -82 + 577];
      I[47 + 1242 - 894 + 929].length();
      I[129 + 675 - 424 + 945].length();
      I[52 + 570 - -431 + 273].length();
      registerBlock(var30, var10001, (new BlockRedFlower()).setHardness(0.0F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[493 + 1228 - 1159 + 765]));
      I[669 + 67 - -323 + 269].length();
      I[396 + 293 - 358 + 998].length();
      I[164 + 794 - 623 + 995].length();
      Block var3 = (new BlockMushroom()).setHardness(0.0F).setSoundType(SoundType.PLANT).setLightLevel(0.125F).setUnlocalizedName(I[351 + 59 - -704 + 217]);
      registerBlock(178 ^ 149, I[500 + 1286 - 1591 + 1137], var3);
      I[259 + 481 - 654 + 1247].length();
      I[441 + 1133 - 632 + 392].length();
      I[990 + 988 - 700 + 57].length();
      I[192 + 1148 - 831 + 827].length();
      Block var4 = (new BlockMushroom()).setHardness(0.0F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[425 + 157 - -653 + 102]);
      registerBlock(81 ^ 121, I[512 + 229 - 616 + 1213], var4);
      var30 = 135 ^ 174;
      var10001 = I[474 + 68 - -343 + 454];
      I[710 + 101 - 25 + 554].length();
      I[1074 + 816 - 1442 + 893].length();
      I[733 + 1021 - 1622 + 1210].length();
      I[279 + 430 - -30 + 604].length();
      registerBlock(var30, var10001, (new Block(Material.IRON, MapColor.GOLD)).setHardness(3.0F).setResistance(10.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[2 + 31 - -206 + 1105]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 16 ^ 58;
      var10001 = I[905 + 647 - 856 + 649];
      I[42 + 1135 - 251 + 420].length();
      I[920 + 13 - 140 + 554].length();
      registerBlock(var30, var10001, (new Block(Material.IRON, MapColor.IRON)).setHardness(5.0F).setResistance(10.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[1124 + 1046 - 1148 + 326]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 75 ^ 96;
      var10001 = I[1052 + 1179 - 1252 + 370];
      I[300 + 89 - 83 + 1044].length();
      registerBlock(var30, var10001, (new BlockDoubleStoneSlab()).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[617 + 287 - -7 + 440]));
      var30 = 132 ^ 168;
      var10001 = I[1154 + 1320 - 2216 + 1094];
      I[874 + 376 - -80 + 23].length();
      I[514 + 76 - 10 + 774].length();
      I[544 + 537 - -37 + 237].length();
      I[324 + 1267 - 464 + 229].length();
      registerBlock(var30, var10001, (new BlockHalfStoneSlab()).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[618 + 379 - 177 + 537]));
      I[1339 + 118 - 610 + 511].length();
      I[122 + 405 - -279 + 553].length();
      I[412 + 926 - 1149 + 1171].length();
      Block var5 = (new Block(Material.ROCK, MapColor.RED)).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1180 + 1344 - 1428 + 265]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
      registerBlock(6 ^ 43, I[784 + 84 - 707 + 1201], var5);
      var30 = 20 ^ 58;
      var10001 = I[1019 + 1006 - 1517 + 855];
      I[84 + 867 - 536 + 949].length();
      registerBlock(var30, var10001, (new BlockTNT()).setHardness(0.0F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[1050 + 787 - 1668 + 1196]));
      var30 = 92 ^ 115;
      var10001 = I[572 + 109 - -260 + 425];
      I[878 + 1010 - 1728 + 1207].length();
      I[357 + 178 - 123 + 956].length();
      registerBlock(var30, var10001, (new BlockBookshelf()).setHardness(1.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[127 + 401 - -107 + 734]));
      var30 = 185 ^ 137;
      var10001 = I[279 + 705 - 438 + 824];
      I[708 + 164 - 537 + 1036].length();
      I[228 + 654 - 467 + 957].length();
      I[366 + 1134 - 1296 + 1169].length();
      registerBlock(var30, var10001, (new Block(Material.ROCK)).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[336 + 314 - -649 + 75]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 131 ^ 178;
      var10001 = I[654 + 630 - 9 + 100];
      I[212 + 946 - 528 + 746].length();
      registerBlock(var30, var10001, (new BlockObsidian()).setHardness(50.0F).setResistance(2000.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[850 + 1182 - 1695 + 1040]));
      var30 = 126 ^ 76;
      var10001 = I[260 + 211 - -610 + 297];
      I[708 + 166 - 496 + 1001].length();
      I[1256 + 421 - 438 + 141].length();
      I[1281 + 1342 - 2438 + 1196].length();
      registerBlock(var30, var10001, (new BlockTorch()).setHardness(0.0F).setLightLevel(0.9375F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1040 + 1204 - 1784 + 922]));
      var30 = 77 ^ 126;
      var10001 = I[530 + 1282 - 558 + 129];
      I[1170 + 292 - 269 + 191].length();
      I[88 + 969 - 714 + 1042].length();
      registerBlock(var30, var10001, (new BlockFire()).setHardness(0.0F).setLightLevel(1.0F).setSoundType(SoundType.CLOTH).setUnlocalizedName(I[261 + 1170 - 932 + 887]).disableStats());
      var30 = 190 ^ 138;
      var10001 = I[969 + 349 - 160 + 229];
      I[300 + 160 - -359 + 569].length();
      registerBlock(var30, var10001, (new BlockMobSpawner()).setHardness(5.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[441 + 58 - 310 + 1200]).disableStats());
      var30 = 46 ^ 27;
      var10001 = I[456 + 162 - 358 + 1130];
      I[1282 + 114 - 714 + 709].length();
      I[894 + 467 - 749 + 780].length();
      I[1032 + 1044 - 1481 + 798].length();
      registerBlock(var30, var10001, (new BlockStairs(var1.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.OAK))).setUnlocalizedName(I[598 + 93 - 622 + 1325]));
      var30 = 138 ^ 188;
      var10001 = I[1071 + 577 - 1222 + 969];
      I[935 + 1137 - 741 + 65].length();
      registerBlock(var30, var10001, (new BlockChest(BlockChest.Type.BASIC)).setHardness(2.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[485 + 685 - 314 + 541]));
      var30 = 124 ^ 75;
      var10001 = I[378 + 163 - -634 + 223];
      I[306 + 1396 - 1276 + 973].length();
      I[716 + 244 - 585 + 1025].length();
      registerBlock(var30, var10001, (new BlockRedstoneWire()).setHardness(0.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[985 + 1279 - 1824 + 961]).disableStats());
      var30 = 18 ^ 42;
      var10001 = I[1283 + 840 - 1353 + 632];
      I[421 + 153 - 565 + 1394].length();
      I[1285 + 708 - 1007 + 418].length();
      registerBlock(var30, var10001, (new BlockOre()).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1132 + 742 - 1517 + 1048]));
      var30 = 171 ^ 146;
      var10001 = I[999 + 1152 - 1596 + 851];
      I[1087 + 981 - 1029 + 368].length();
      I[73 + 84 - 76 + 1327].length();
      I[290 + 28 - -983 + 108].length();
      registerBlock(var30, var10001, (new Block(Material.IRON, MapColor.DIAMOND)).setHardness(5.0F).setResistance(10.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[1339 + 570 - 1502 + 1003]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 19 ^ 41;
      var10001 = I[91 + 440 - -266 + 614];
      I[978 + 966 - 715 + 183].length();
      I[234 + 333 - -544 + 302].length();
      I[504 + 273 - -493 + 144].length();
      I[998 + 509 - 1124 + 1032].length();
      registerBlock(var30, var10001, (new BlockWorkbench()).setHardness(2.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1105 + 9 - 22 + 324]));
      var30 = 71 ^ 124;
      var10001 = I[754 + 612 - 1200 + 1251];
      I[1249 + 382 - 1624 + 1411].length();
      I[1213 + 817 - 730 + 119].length();
      registerBlock(var30, var10001, (new BlockCrops()).setUnlocalizedName(I[222 + 714 - 296 + 780]));
      I[841 + 819 - 637 + 398].length();
      I[52 + 637 - -439 + 294].length();
      I[519 + 174 - -478 + 252].length();
      Block var6 = (new BlockFarmland()).setHardness(0.6F).setSoundType(SoundType.GROUND).setUnlocalizedName(I[1096 + 1115 - 1211 + 424]);
      registerBlock(34 ^ 30, I[975 + 1310 - 1515 + 655], var6);
      var30 = 20 ^ 41;
      var10001 = I[912 + 698 - 1593 + 1409];
      I[69 + 1108 - 659 + 909].length();
      I[1367 + 726 - 1274 + 609].length();
      I[1341 + 424 - 549 + 213].length();
      registerBlock(var30, var10001, (new BlockFurnace((boolean)"".length())).setHardness(3.5F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1073 + 1018 - 1145 + 484]).setCreativeTab(CreativeTabs.DECORATIONS));
      var30 = 37 ^ 27;
      var10001 = I[87 + 509 - -391 + 444];
      I[352 + 1283 - 853 + 650].length();
      I[400 + 304 - 58 + 787].length();
      I[987 + 956 - 1446 + 937].length();
      registerBlock(var30, var10001, (new BlockFurnace((boolean)" ".length())).setHardness(3.5F).setSoundType(SoundType.STONE).setLightLevel(0.875F).setUnlocalizedName(I[1190 + 937 - 1277 + 585]));
      var30 = 81 ^ 110;
      var10001 = I[247 + 1212 - 1223 + 1200];
      I[576 + 1419 - 1290 + 732].length();
      I[275 + 1286 - 287 + 164].length();
      I[1313 + 1348 - 2479 + 1257].length();
      I[1360 + 1175 - 1838 + 743].length();
      registerBlock(var30, var10001, (new BlockStandingSign()).setHardness(1.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1334 + 1272 - 2280 + 1115]).disableStats());
      var30 = 29 ^ 93;
      var10001 = I[776 + 121 - 341 + 886];
      I[665 + 968 - 1438 + 1248].length();
      I[310 + 243 - -362 + 529].length();
      I[1139 + 1262 - 1913 + 957].length();
      I[1247 + 1394 - 1558 + 363].length();
      I[339 + 1056 - 622 + 674].length();
      registerBlock(var30, var10001, (new BlockDoor(Material.WOOD)).setHardness(3.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[319 + 201 - -840 + 88]).disableStats());
      var30 = 88 ^ 25;
      var10001 = I[1153 + 130 - 72 + 238];
      I[577 + 315 - 830 + 1388].length();
      I[1324 + 700 - 1738 + 1165].length();
      I[1303 + 1308 - 1847 + 688].length();
      I[1044 + 717 - 720 + 412].length();
      I[189 + 1172 - 105 + 198].length();
      registerBlock(var30, var10001, (new BlockLadder()).setHardness(0.4F).setSoundType(SoundType.LADDER).setUnlocalizedName(I[1029 + 698 - 923 + 651]));
      var30 = 55 ^ 117;
      var10001 = I[304 + 958 - 364 + 558];
      I[1042 + 162 - 828 + 1081].length();
      I[1156 + 368 - 558 + 492].length();
      I[552 + 1126 - 383 + 164].length();
      registerBlock(var30, var10001, (new BlockRail()).setHardness(0.7F).setSoundType(SoundType.METAL).setUnlocalizedName(I[357 + 374 - 439 + 1168]));
      var30 = 15 ^ 76;
      var10001 = I[35 + 421 - 186 + 1191];
      I[547 + 279 - 734 + 1370].length();
      I[557 + 228 - -647 + 31].length();
      I[1029 + 1206 - 2031 + 1260].length();
      registerBlock(var30, var10001, (new BlockStairs(var0.getDefaultState())).setUnlocalizedName(I[1311 + 511 - 1788 + 1431]));
      var30 = 197 ^ 129;
      var10001 = I[1004 + 1317 - 1622 + 767];
      I[368 + 565 - 662 + 1196].length();
      registerBlock(var30, var10001, (new BlockWallSign()).setHardness(1.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[822 + 532 - 1073 + 1187]).disableStats());
      var30 = 238 ^ 171;
      var10001 = I[1319 + 1196 - 2395 + 1349];
      I[960 + 1268 - 987 + 229].length();
      I[458 + 1186 - 1243 + 1070].length();
      I[106 + 70 - -1031 + 265].length();
      registerBlock(var30, var10001, (new BlockLever()).setHardness(0.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1053 + 380 - 519 + 559]));
      var30 = 25 ^ 95;
      var10001 = I[143 + 629 - 113 + 815];
      I[857 + 1246 - 1250 + 622].length();
      I[94 + 519 - -686 + 177].length();
      I[1107 + 726 - 1021 + 665].length();
      I[1465 + 731 - 1051 + 333].length();
      I[1372 + 496 - 1591 + 1202].length();
      registerBlock(var30, var10001, (new BlockPressurePlate(Material.ROCK, BlockPressurePlate.Sensitivity.MOBS)).setHardness(0.5F).setSoundType(SoundType.STONE).setUnlocalizedName(I[169 + 555 - 635 + 1391]));
      var30 = 222 ^ 153;
      var10001 = I[393 + 466 - -584 + 38];
      I[281 + 1060 - 1047 + 1188].length();
      I[1470 + 790 - 1588 + 811].length();
      registerBlock(var30, var10001, (new BlockDoor(Material.IRON)).setHardness(5.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[688 + 148 - 212 + 860]).disableStats());
      var30 = 201 ^ 129;
      var10001 = I[312 + 722 - 827 + 1278];
      I[370 + 199 - -735 + 182].length();
      I[688 + 1181 - 1076 + 694].length();
      I[1145 + 475 - 929 + 797].length();
      registerBlock(var30, var10001, (new BlockPressurePlate(Material.WOOD, BlockPressurePlate.Sensitivity.EVERYTHING)).setHardness(0.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[254 + 1488 - 1053 + 800]));
      var30 = 140 ^ 197;
      var10001 = I[909 + 1421 - 1342 + 502];
      I[858 + 1242 - 1627 + 1018].length();
      I[1404 + 1270 - 2407 + 1225].length();
      registerBlock(var30, var10001, (new BlockRedstoneOre((boolean)"".length())).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1364 + 430 - 1600 + 1299]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 75 ^ 1;
      var10001 = I[1463 + 44 - 653 + 640];
      I[449 + 152 - -125 + 769].length();
      I[512 + 1354 - 1694 + 1324].length();
      registerBlock(var30, var10001, (new BlockRedstoneOre((boolean)" ".length())).setLightLevel(0.625F).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[746 + 913 - 1413 + 1251]));
      var30 = 48 ^ 123;
      var10001 = I[240 + 439 - -393 + 426];
      I[392 + 0 - -792 + 315].length();
      I[996 + 1246 - 1196 + 454].length();
      registerBlock(var30, var10001, (new BlockRedstoneTorch((boolean)"".length())).setHardness(0.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[543 + 729 - 424 + 653]));
      var30 = 82 ^ 30;
      var10001 = I[1311 + 1436 - 1848 + 603];
      I[627 + 1062 - 885 + 699].length();
      registerBlock(var30, var10001, (new BlockRedstoneTorch((boolean)" ".length())).setHardness(0.0F).setLightLevel(0.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1046 + 1466 - 1614 + 606]).setCreativeTab(CreativeTabs.REDSTONE));
      var30 = 19 ^ 94;
      var10001 = I[1181 + 88 - 554 + 790];
      I[838 + 455 - 426 + 639].length();
      I[1408 + 352 - 991 + 738].length();
      I[311 + 660 - -42 + 495].length();
      I[636 + 693 - 654 + 834].length();
      registerBlock(var30, var10001, (new BlockButtonStone()).setHardness(0.5F).setSoundType(SoundType.STONE).setUnlocalizedName(I[116 + 1055 - -147 + 192]));
      var30 = 60 ^ 114;
      var10001 = I[1223 + 1141 - 1794 + 941];
      I[172 + 37 - -843 + 460].length();
      I[869 + 1282 - 665 + 27].length();
      I[1418 + 176 - 990 + 910].length();
      registerBlock(var30, var10001, (new BlockSnow()).setHardness(0.1F).setSoundType(SoundType.SNOW).setUnlocalizedName(I[688 + 723 - 531 + 635]).setLightOpacity("".length()));
      var30 = 1 ^ 78;
      var10001 = I[767 + 653 - 1299 + 1395];
      I[600 + 644 - 982 + 1255].length();
      I[93 + 1456 - 1473 + 1442].length();
      I[89 + 1166 - 778 + 1042].length();
      I[1076 + 1283 - 1491 + 652].length();
      registerBlock(var30, var10001, (new BlockIce()).setHardness(0.5F).setLightOpacity("   ".length()).setSoundType(SoundType.GLASS).setUnlocalizedName(I[540 + 1237 - 1154 + 898]));
      var30 = 51 ^ 99;
      var10001 = I[645 + 1112 - 287 + 52];
      I[313 + 1203 - 128 + 135].length();
      I[1162 + 219 - 1155 + 1298].length();
      I[250 + 1065 - 52 + 262].length();
      I[1408 + 409 - 1715 + 1424].length();
      registerBlock(var30, var10001, (new BlockSnowBlock()).setHardness(0.2F).setSoundType(SoundType.SNOW).setUnlocalizedName(I[295 + 663 - 318 + 887]));
      var30 = 54 ^ 103;
      var10001 = I[896 + 795 - 1389 + 1226];
      I[202 + 976 - 1017 + 1368].length();
      I[1200 + 317 - 1450 + 1463].length();
      I[57 + 1405 - 44 + 113].length();
      I[39 + 877 - 412 + 1028].length();
      registerBlock(var30, var10001, (new BlockCactus()).setHardness(0.4F).setSoundType(SoundType.CLOTH).setUnlocalizedName(I[361 + 683 - -410 + 79]));
      var30 = 215 ^ 133;
      var10001 = I[458 + 958 - 302 + 420];
      I[816 + 785 - 1084 + 1018].length();
      I[1424 + 397 - 508 + 223].length();
      registerBlock(var30, var10001, (new BlockClay()).setHardness(0.6F).setSoundType(SoundType.GROUND).setUnlocalizedName(I[698 + 1276 - 1294 + 857]));
      var30 = 207 ^ 156;
      var10001 = I[818 + 361 - -276 + 83];
      I[370 + 1154 - 142 + 157].length();
      I[1148 + 808 - 751 + 335].length();
      I[145 + 1387 - 639 + 648].length();
      registerBlock(var30, var10001, (new BlockReed()).setHardness(0.0F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[468 + 694 - 623 + 1003]).disableStats());
      var30 = 28 ^ 72;
      var10001 = I[111 + 1115 - 1148 + 1465];
      I[1026 + 1411 - 1588 + 695].length();
      I[148 + 977 - -339 + 81].length();
      I[38 + 966 - 873 + 1415].length();
      I[1535 + 91 - 666 + 587].length();
      registerBlock(var30, var10001, (new BlockJukebox()).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[266 + 1385 - 1589 + 1486]));
      var30 = 63 ^ 106;
      var10001 = I[484 + 1330 - 630 + 365];
      I[1170 + 423 - 855 + 812].length();
      I[490 + 399 - -12 + 650].length();
      registerBlock(var30, var10001, (new BlockFence(Material.WOOD, BlockPlanks.EnumType.OAK.getMapColor())).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[177 + 1515 - 347 + 207]));
      I[92 + 277 - -838 + 346].length();
      I[1062 + 193 - 950 + 1249].length();
      I[285 + 1548 - 1458 + 1180].length();
      Block var7 = (new BlockPumpkin()).setHardness(1.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1202 + 1006 - 2052 + 1400]);
      registerBlock(144 ^ 198, I[426 + 462 - 625 + 1294], var7);
      var30 = 74 ^ 29;
      var10001 = I[729 + 598 - -170 + 61];
      I[1480 + 1245 - 2413 + 1247].length();
      registerBlock(var30, var10001, (new BlockNetherrack()).setHardness(0.4F).setSoundType(SoundType.STONE).setUnlocalizedName(I[628 + 636 - 883 + 1179]));
      var30 = 76 ^ 20;
      var10001 = I[1427 + 1366 - 2100 + 868];
      I[546 + 128 - 555 + 1443].length();
      registerBlock(var30, var10001, (new BlockSoulSand()).setHardness(0.5F).setSoundType(SoundType.SAND).setUnlocalizedName(I[43 + 531 - -452 + 537]));
      var30 = 153 ^ 192;
      var10001 = I[845 + 1379 - 1205 + 545];
      I[87 + 845 - -261 + 372].length();
      I[1083 + 392 - -82 + 9].length();
      I[640 + 1255 - 726 + 398].length();
      registerBlock(var30, var10001, (new BlockGlowstone(Material.GLASS)).setHardness(0.3F).setSoundType(SoundType.GLASS).setLightLevel(1.0F).setUnlocalizedName(I[55 + 1193 - 768 + 1088]));
      var30 = 243 ^ 169;
      var10001 = I[1102 + 198 - -209 + 60];
      I[1149 + 1295 - 921 + 47].length();
      I[1049 + 319 - -13 + 190].length();
      registerBlock(var30, var10001, (new BlockPortal()).setHardness(-1.0F).setSoundType(SoundType.GLASS).setLightLevel(0.75F).setUnlocalizedName(I[916 + 1026 - 743 + 373]));
      var30 = 214 ^ 141;
      var10001 = I[1281 + 1400 - 1120 + 12];
      I[1209 + 1432 - 2631 + 1564].length();
      registerBlock(var30, var10001, (new BlockPumpkin()).setHardness(1.0F).setSoundType(SoundType.WOOD).setLightLevel(1.0F).setUnlocalizedName(I[824 + 500 - -172 + 79]));
      var30 = 57 ^ 101;
      var10001 = I[1287 + 193 - 888 + 984];
      I[1314 + 1470 - 2696 + 1489].length();
      I[1153 + 593 - 1538 + 1370].length();
      registerBlock(var30, var10001, (new BlockCake()).setHardness(0.5F).setSoundType(SoundType.CLOTH).setUnlocalizedName(I[786 + 1523 - 1435 + 705]).disableStats());
      var30 = 238 ^ 179;
      var10001 = I[359 + 184 - -713 + 324];
      I[52 + 971 - -394 + 164].length();
      I[773 + 1335 - 830 + 304].length();
      I[250 + 1244 - 1369 + 1458].length();
      I[86 + 281 - -1095 + 122].length();
      registerBlock(var30, var10001, (new BlockRedstoneRepeater((boolean)"".length())).setHardness(0.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1201 + 273 - 1293 + 1404]).disableStats());
      var30 = 255 ^ 161;
      var10001 = I[1345 + 188 - 292 + 345];
      I[341 + 1120 - 1049 + 1175].length();
      I[940 + 116 - 348 + 880].length();
      registerBlock(var30, var10001, (new BlockRedstoneRepeater((boolean)" ".length())).setHardness(0.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1152 + 1080 - 1740 + 1097]).disableStats());
      var30 = 20 ^ 75;
      var10001 = I[418 + 235 - 6 + 943];
      I[1099 + 94 - 1114 + 1512].length();
      registerBlock(var30, var10001, (new BlockStainedGlass(Material.GLASS)).setHardness(0.3F).setSoundType(SoundType.GLASS).setUnlocalizedName(I[1577 + 192 - 727 + 550]));
      var30 = 218 ^ 186;
      var10001 = I[969 + 721 - 1237 + 1140];
      I[168 + 21 - -861 + 544].length();
      I[602 + 84 - -97 + 812].length();
      I[688 + 1193 - 404 + 119].length();
      I[375 + 80 - 319 + 1461].length();
      registerBlock(var30, var10001, (new BlockTrapDoor(Material.WOOD)).setHardness(3.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[444 + 1232 - 1368 + 1290]).disableStats());
      var30 = 61 ^ 92;
      var10001 = I[167 + 702 - 739 + 1469];
      I[219 + 425 - 212 + 1168].length();
      I[552 + 238 - 419 + 1230].length();
      registerBlock(var30, var10001, (new BlockSilverfish()).setHardness(0.75F).setUnlocalizedName(I[1127 + 858 - 1628 + 1245]));
      I[1588 + 1164 - 1349 + 200].length();
      Block var8 = (new BlockStoneBrick()).setHardness(1.5F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[738 + 801 - 1468 + 1533]);
      registerBlock(75 ^ 41, I[1094 + 1601 - 2218 + 1128], var8);
      var30 = 30 ^ 125;
      var10001 = I[725 + 843 - 59 + 97];
      I[460 + 1495 - 1049 + 701].length();
      I[269 + 124 - 128 + 1343].length();
      registerBlock(var30, var10001, (new BlockHugeMushroom(Material.WOOD, MapColor.DIRT, var3)).setHardness(0.2F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1197 + 1546 - 1430 + 296]));
      var30 = 9 ^ 109;
      var10001 = I[888 + 160 - 129 + 691];
      I[1597 + 990 - 2086 + 1110].length();
      I[1199 + 111 - 1239 + 1541].length();
      I[815 + 1470 - 2100 + 1428].length();
      registerBlock(var30, var10001, (new BlockHugeMushroom(Material.WOOD, MapColor.RED, var4)).setHardness(0.2F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[283 + 770 - -404 + 157]));
      var30 = 0 ^ 101;
      var10001 = I[911 + 1420 - 1726 + 1010];
      I[140 + 684 - 652 + 1444].length();
      registerBlock(var30, var10001, (new BlockPane(Material.IRON, (boolean)" ".length())).setHardness(5.0F).setResistance(10.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[439 + 660 - -113 + 405]));
      var30 = 75 ^ 45;
      var10001 = I[1268 + 681 - 1681 + 1350];
      I[919 + 1267 - 1413 + 846].length();
      I[741 + 1042 - 1091 + 928].length();
      I[1256 + 598 - 794 + 561].length();
      registerBlock(var30, var10001, (new BlockPane(Material.GLASS, (boolean)"".length())).setHardness(0.3F).setSoundType(SoundType.GLASS).setUnlocalizedName(I[977 + 272 - -339 + 34]));
      I[241 + 755 - -265 + 362].length();
      I[67 + 89 - -591 + 877].length();
      I[673 + 1255 - 1734 + 1431].length();
      Block var9 = (new BlockMelon()).setHardness(1.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[600 + 212 - 511 + 1325]);
      registerBlock(247 ^ 144, I[1201 + 583 - 228 + 71], var9);
      var30 = 196 ^ 172;
      var10001 = I[1054 + 72 - -73 + 429];
      I[524 + 919 - 359 + 545].length();
      I[952 + 717 - 1594 + 1555].length();
      I[351 + 1166 - 688 + 802].length();
      registerBlock(var30, var10001, (new BlockStem(var7)).setHardness(0.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1049 + 1581 - 2509 + 1511]));
      var30 = 202 ^ 163;
      var10001 = I[1035 + 657 - 1038 + 979];
      I[1514 + 1592 - 1973 + 501].length();
      registerBlock(var30, var10001, (new BlockStem(var9)).setHardness(0.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[380 + 217 - 102 + 1140]));
      var30 = 172 ^ 198;
      var10001 = I[1452 + 707 - 997 + 474];
      I[348 + 876 - 584 + 997].length();
      I[358 + 618 - -126 + 536].length();
      I[1126 + 1463 - 1674 + 724].length();
      registerBlock(var30, var10001, (new BlockVine()).setHardness(0.2F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[366 + 798 - 785 + 1261]));
      var30 = 7 ^ 108;
      var10001 = I[152 + 616 - -161 + 712];
      I[1635 + 1130 - 1928 + 805].length();
      I[1328 + 1271 - 2288 + 1332].length();
      registerBlock(var30, var10001, (new BlockFenceGate(BlockPlanks.EnumType.OAK)).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[188 + 780 - -144 + 532]));
      var30 = 95 ^ 51;
      var10001 = I[526 + 1208 - 1131 + 1042];
      I[1292 + 24 - 1102 + 1432].length();
      I[486 + 1202 - 1434 + 1393].length();
      I[1484 + 1167 - 2465 + 1462].length();
      I[650 + 1001 - 104 + 102].length();
      registerBlock(var30, var10001, (new BlockStairs(var5.getDefaultState())).setUnlocalizedName(I[565 + 1615 - 1538 + 1008]));
      var30 = 102 ^ 11;
      var10001 = I[766 + 1128 - 499 + 256];
      I[1151 + 1318 - 1003 + 186].length();
      registerBlock(var30, var10001, (new BlockStairs(var8.getDefaultState().withProperty(BlockStoneBrick.VARIANT, BlockStoneBrick.EnumType.DEFAULT))).setUnlocalizedName(I[809 + 306 - 501 + 1039]));
      var30 = 35 ^ 77;
      var10001 = I[369 + 971 - 345 + 659];
      I[1247 + 1058 - 1406 + 756].length();
      registerBlock(var30, var10001, (new BlockMycelium()).setHardness(0.6F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[74 + 1407 - 28 + 203]));
      var30 = 112 ^ 31;
      var10001 = I[1219 + 1437 - 1793 + 794];
      I[782 + 45 - 146 + 977].length();
      I[892 + 291 - 1042 + 1518].length();
      registerBlock(var30, var10001, (new BlockLilyPad()).setHardness(0.0F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[1123 + 171 - 798 + 1164]));
      I[1565 + 664 - 2191 + 1623].length();
      I[593 + 1509 - 486 + 46].length();
      Block var10 = (new BlockNetherBrick()).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[371 + 608 - -125 + 559]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
      registerBlock(23 ^ 103, I[1506 + 1222 - 2276 + 1212], var10);
      var30 = 112 ^ 1;
      var10001 = I[1024 + 1371 - 837 + 107];
      I[237 + 1258 - 1207 + 1378].length();
      registerBlock(var30, var10001, (new BlockFence(Material.ROCK, MapColor.NETHERRACK)).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[803 + 1215 - 762 + 411]));
      var30 = 115 ^ 1;
      var10001 = I[1110 + 304 - 755 + 1009];
      I[1376 + 1408 - 1872 + 757].length();
      registerBlock(var30, var10001, (new BlockStairs(var10.getDefaultState())).setUnlocalizedName(I[679 + 135 - -331 + 525]));
      var30 = 85 ^ 38;
      var10001 = I[918 + 509 - -186 + 58];
      I[1566 + 1331 - 2226 + 1001].length();
      I[528 + 1516 - 1595 + 1224].length();
      registerBlock(var30, var10001, (new BlockNetherWart()).setUnlocalizedName(I[67 + 1080 - -317 + 210]));
      var30 = 61 ^ 73;
      var10001 = I[9 + 1084 - -413 + 169];
      I[1351 + 510 - 1772 + 1587].length();
      I[957 + 924 - 824 + 620].length();
      registerBlock(var30, var10001, (new BlockEnchantmentTable()).setHardness(5.0F).setResistance(2000.0F).setUnlocalizedName(I[1312 + 1135 - 2296 + 1527]));
      var30 = 89 ^ 44;
      var10001 = I[905 + 419 - 281 + 636];
      I[262 + 632 - -576 + 210].length();
      I[548 + 302 - 453 + 1284].length();
      I[1619 + 537 - 1381 + 907].length();
      registerBlock(var30, var10001, (new BlockBrewingStand()).setHardness(0.5F).setLightLevel(0.125F).setUnlocalizedName(I[1009 + 139 - -469 + 66]));
      var30 = 66 ^ 52;
      var10001 = I[525 + 527 - -464 + 168];
      I[699 + 175 - 43 + 854].length();
      I[1466 + 852 - 1640 + 1008].length();
      registerBlock(var30, var10001, (new BlockCauldron()).setHardness(2.0F).setUnlocalizedName(I[1361 + 294 - 873 + 905]));
      var30 = 199 ^ 176;
      var10001 = I[789 + 1583 - 2115 + 1431];
      I[46 + 1269 - 19 + 393].length();
      I[562 + 525 - -296 + 307].length();
      I[1198 + 1542 - 1277 + 228].length();
      registerBlock(var30, var10001, (new BlockEndPortal(Material.PORTAL)).setHardness(-1.0F).setResistance(6000000.0F));
      var30 = 64 ^ 56;
      var10001 = I[146 + 1690 - 366 + 222];
      I[1578 + 1560 - 1740 + 295].length();
      I[1661 + 1295 - 2054 + 792].length();
      I[1467 + 1315 - 2169 + 1082].length();
      I[102 + 234 - -1197 + 163].length();
      I[1134 + 1217 - 1212 + 558].length();
      registerBlock(var30, var10001, (new BlockEndPortalFrame()).setSoundType(SoundType.GLASS).setLightLevel(0.125F).setHardness(-1.0F).setUnlocalizedName(I[797 + 1126 - 1388 + 1163]).setResistance(6000000.0F).setCreativeTab(CreativeTabs.DECORATIONS));
      var30 = 193 ^ 184;
      var10001 = I[1436 + 1472 - 1639 + 430];
      I[1627 + 509 - 2101 + 1665].length();
      I[574 + 218 - 570 + 1479].length();
      I[1552 + 296 - 399 + 253].length();
      I[328 + 716 - 997 + 1656].length();
      registerBlock(var30, var10001, (new Block(Material.ROCK, MapColor.SAND)).setHardness(3.0F).setResistance(15.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1523 + 1594 - 2028 + 615]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 198 ^ 188;
      var10001 = I[849 + 1429 - 894 + 321];
      I[515 + 1402 - 825 + 614].length();
      I[451 + 54 - -1126 + 76].length();
      I[748 + 1274 - 1858 + 1544].length();
      registerBlock(var30, var10001, (new BlockDragonEgg()).setHardness(3.0F).setResistance(15.0F).setSoundType(SoundType.STONE).setLightLevel(0.125F).setUnlocalizedName(I[1615 + 775 - 1761 + 1080]));
      var30 = 213 ^ 174;
      var10001 = I[317 + 986 - 996 + 1403];
      I[786 + 66 - 606 + 1465].length();
      I[1520 + 438 - 1656 + 1410].length();
      I[1301 + 1110 - 1104 + 406].length();
      I[43 + 256 - -1045 + 370].length();
      registerBlock(var30, var10001, (new BlockRedstoneLight((boolean)"".length())).setHardness(0.3F).setSoundType(SoundType.GLASS).setUnlocalizedName(I[972 + 812 - 499 + 430]).setCreativeTab(CreativeTabs.REDSTONE));
      var30 = 214 ^ 170;
      var10001 = I[940 + 363 - -222 + 191];
      I[187 + 1019 - -390 + 121].length();
      I[1448 + 1303 - 1405 + 372].length();
      I[1322 + 855 - 898 + 440].length();
      I[843 + 35 - 517 + 1359].length();
      I[568 + 1142 - 56 + 67].length();
      registerBlock(var30, var10001, (new BlockRedstoneLight((boolean)" ".length())).setHardness(0.3F).setSoundType(SoundType.GLASS).setUnlocalizedName(I[1424 + 95 - 68 + 271]));
      var30 = 222 ^ 163;
      var10001 = I[571 + 586 - 691 + 1257];
      I[1643 + 1048 - 1516 + 549].length();
      I[1435 + 142 - 439 + 587].length();
      I[443 + 1706 - 1788 + 1365].length();
      registerBlock(var30, var10001, (new BlockDoubleWoodSlab()).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[916 + 36 - 269 + 1044]));
      var30 = 113 ^ 15;
      var10001 = I[498 + 1471 - 1330 + 1089];
      I[168 + 1489 - 1534 + 1606].length();
      I[876 + 862 - 46 + 38].length();
      registerBlock(var30, var10001, (new BlockHalfWoodSlab()).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[868 + 332 - 5 + 536]));
      var30 = 17 + 81 - 73 + 102;
      var10001 = I[1617 + 215 - 1245 + 1145];
      I[1191 + 1127 - 1484 + 899].length();
      registerBlock(var30, var10001, (new BlockCocoa()).setHardness(0.2F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[752 + 1661 - 2392 + 1713]));
      var30 = 94 + 98 - 173 + 109;
      var10001 = I[5 + 1103 - 190 + 817];
      I[1591 + 1658 - 2530 + 1017].length();
      registerBlock(var30, var10001, (new BlockStairs(var2.getDefaultState().withProperty(BlockSandStone.TYPE, BlockSandStone.EnumType.SMOOTH))).setUnlocalizedName(I[447 + 730 - 118 + 678]));
      var30 = 16 + 45 - 41 + 109;
      var10001 = I[1368 + 1246 - 1396 + 520];
      I[29 + 1529 - 1375 + 1556].length();
      I[951 + 351 - -329 + 109].length();
      registerBlock(var30, var10001, (new BlockOre()).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1072 + 493 - 711 + 887]));
      var30 = 67 + 87 - 86 + 62;
      var10001 = I[752 + 867 - -74 + 49];
      I[351 + 1293 - 1091 + 1190].length();
      I[538 + 1106 - 910 + 1010].length();
      registerBlock(var30, var10001, (new BlockEnderChest()).setHardness(22.5F).setResistance(1000.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1178 + 1658 - 1530 + 439]).setLightLevel(0.5F));
      var30 = 59 + 125 - 60 + 7;
      var10001 = I[1335 + 1383 - 2424 + 1452];
      I[1099 + 74 - 101 + 675].length();
      I[46 + 860 - -794 + 48].length();
      I[443 + 1112 - 771 + 965].length();
      registerBlock(var30, var10001, (new BlockTripWireHook()).setUnlocalizedName(I[1676 + 820 - 1849 + 1103]));
      var30 = 11 + 90 - -11 + 20;
      var10001 = I[1723 + 1218 - 1910 + 720];
      I[150 + 1546 - 911 + 967].length();
      I[1481 + 1189 - 2036 + 1119].length();
      registerBlock(var30, var10001, (new BlockTripWire()).setUnlocalizedName(I[1172 + 1187 - 1238 + 633]));
      var30 = 105 + 92 - 91 + 27;
      var10001 = I[236 + 432 - 503 + 1590];
      I[1461 + 733 - 1437 + 999].length();
      I[198 + 306 - -69 + 1184].length();
      registerBlock(var30, var10001, (new Block(Material.IRON, MapColor.EMERALD)).setHardness(5.0F).setResistance(10.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[1173 + 960 - 1410 + 1035]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 129 + 66 - 76 + 15;
      var10001 = I[1510 + 658 - 1945 + 1536];
      I[784 + 234 - 155 + 897].length();
      I[466 + 102 - -705 + 488].length();
      I[484 + 47 - 114 + 1345].length();
      registerBlock(var30, var10001, (new BlockStairs(var1.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.SPRUCE))).setUnlocalizedName(I[480 + 1664 - 624 + 243]));
      var30 = 33 + 12 - 41 + 131;
      var10001 = I[202 + 1379 - 1354 + 1537];
      I[1532 + 1652 - 2266 + 847].length();
      registerBlock(var30, var10001, (new BlockStairs(var1.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.BIRCH))).setUnlocalizedName(I[885 + 1009 - 1040 + 912]));
      var30 = 25 + 118 - 118 + 111;
      var10001 = I[660 + 47 - -59 + 1001];
      I[1671 + 1643 - 3158 + 1612].length();
      I[586 + 382 - -425 + 376].length();
      I[31 + 700 - -73 + 966].length();
      registerBlock(var30, var10001, (new BlockStairs(var1.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.JUNGLE))).setUnlocalizedName(I[1103 + 228 - 942 + 1382]));
      var30 = 35 + 92 - 100 + 110;
      var10001 = I[1444 + 1703 - 1853 + 478];
      I[1490 + 1605 - 1764 + 442].length();
      I[562 + 14 - -1010 + 188].length();
      registerBlock(var30, var10001, (new BlockCommandBlock(MapColor.BROWN)).setBlockUnbreakable().setResistance(6000000.0F).setUnlocalizedName(I[1572 + 988 - 1896 + 1111]));
      var30 = 20 + 24 - -57 + 37;
      var10001 = I[1432 + 967 - 796 + 173];
      I[1698 + 323 - 994 + 750].length();
      I[973 + 1019 - 939 + 725].length();
      I[1206 + 1018 - 952 + 507].length();
      I[37 + 1130 - -60 + 553].length();
      registerBlock(var30, var10001, (new BlockBeacon()).setUnlocalizedName(I[1655 + 399 - 1769 + 1496]).setLightLevel(1.0F));
      var30 = 61 + 55 - -12 + 11;
      var10001 = I[1656 + 1264 - 2179 + 1041];
      I[1028 + 749 - 737 + 743].length();
      registerBlock(var30, var10001, (new BlockWall(var0)).setUnlocalizedName(I[549 + 537 - -443 + 255]));
      var30 = 84 + 114 - 181 + 123;
      var10001 = I[1454 + 770 - 1277 + 838];
      I[477 + 1084 - 435 + 660].length();
      I[728 + 638 - -173 + 248].length();
      registerBlock(var30, var10001, (new BlockFlowerPot()).setHardness(0.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[119 + 954 - -396 + 319]));
      var30 = 73 + 97 - 150 + 121;
      var10001 = I[230 + 499 - -860 + 200];
      I[825 + 757 - 1411 + 1619].length();
      I[699 + 1407 - 2091 + 1776].length();
      registerBlock(var30, var10001, (new BlockCarrot()).setUnlocalizedName(I[913 + 678 - -126 + 75]));
      var30 = 34 + 60 - 64 + 112;
      var10001 = I[689 + 1731 - 1269 + 642];
      I[693 + 1579 - 684 + 206].length();
      I[1410 + 1264 - 1370 + 491].length();
      I[775 + 1678 - 1427 + 770].length();
      I[644 + 1280 - 1374 + 1247].length();
      registerBlock(var30, var10001, (new BlockPotato()).setUnlocalizedName(I[554 + 515 - -699 + 30]));
      var30 = 51 + 106 - 123 + 109;
      var10001 = I[1100 + 192 - 607 + 1114];
      I[967 + 223 - -55 + 555].length();
      I[1762 + 1354 - 2516 + 1201].length();
      registerBlock(var30, var10001, (new BlockButtonWood()).setHardness(0.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[357 + 1624 - 196 + 17]));
      var30 = 110 + 27 - 83 + 90;
      var10001 = I[504 + 1426 - 1683 + 1556];
      I[1362 + 135 - 1302 + 1609].length();
      I[1027 + 492 - 1352 + 1638].length();
      registerBlock(var30, var10001, (new BlockSkull()).setHardness(1.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1779 + 1699 - 2221 + 549]));
      var30 = 93 + 52 - 28 + 28;
      var10001 = I[1442 + 1615 - 1559 + 309];
      I[1459 + 1287 - 2589 + 1651].length();
      I[298 + 880 - 217 + 848].length();
      registerBlock(var30, var10001, (new BlockAnvil()).setHardness(5.0F).setSoundType(SoundType.ANVIL).setResistance(2000.0F).setUnlocalizedName(I[1779 + 909 - 1154 + 276]));
      var30 = 17 + 124 - 71 + 76;
      var10001 = I[1690 + 1275 - 2228 + 1074];
      I[423 + 1065 - 30 + 354].length();
      registerBlock(var30, var10001, (new BlockChest(BlockChest.Type.TRAP)).setHardness(2.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[578 + 853 - 577 + 959]));
      var30 = 139 + 82 - 107 + 33;
      var10001 = I[940 + 520 - 933 + 1287];
      I[1024 + 1764 - 1498 + 525].length();
      I[393 + 1322 - 1611 + 1712].length();
      I[597 + 1739 - 1938 + 1419].length();
      I[988 + 873 - 639 + 596].length();
      registerBlock(var30, var10001, (new BlockPressurePlateWeighted(Material.IRON, 47 ^ 32, MapColor.GOLD)).setHardness(0.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1500 + 641 - 763 + 441]));
      var30 = 42 + 142 - 112 + 76;
      var10001 = I[1815 + 1320 - 2757 + 1442];
      I[900 + 703 - 508 + 726].length();
      I[698 + 1021 - 589 + 692].length();
      registerBlock(var30, var10001, (new BlockPressurePlateWeighted(Material.IRON, 13 + 27 - 39 + 149)).setHardness(0.5F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1435 + 708 - 1692 + 1372]));
      var30 = 60 + 43 - 67 + 113;
      var10001 = I[1050 + 1034 - 1466 + 1206];
      I[1650 + 811 - 1198 + 562].length();
      registerBlock(var30, var10001, (new BlockRedstoneComparator((boolean)"".length())).setHardness(0.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[964 + 1261 - 908 + 509]).disableStats());
      var30 = 46 + 129 - 97 + 72;
      var10001 = I[111 + 1418 - 330 + 628];
      I[1587 + 1475 - 2263 + 1029].length();
      I[376 + 982 - 224 + 695].length();
      I[1288 + 1199 - 1627 + 970].length();
      I[630 + 1525 - 1828 + 1504].length();
      registerBlock(var30, var10001, (new BlockRedstoneComparator((boolean)" ".length())).setHardness(0.0F).setLightLevel(0.625F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[858 + 104 - 645 + 1515]).disableStats());
      var30 = 102 + 42 - 9 + 16;
      var10001 = I[738 + 1460 - 705 + 340];
      I[341 + 1447 - 734 + 780].length();
      I[1675 + 1031 - 1440 + 569].length();
      I[1075 + 243 - -404 + 114].length();
      I[1800 + 548 - 2059 + 1548].length();
      I[1568 + 1670 - 1623 + 223].length();
      registerBlock(var30, (String)var10001, new BlockDaylightDetector((boolean)"".length()));
      var30 = 70 + 84 - 103 + 101;
      var10001 = I[316 + 1460 - 1654 + 1717];
      I[1586 + 1557 - 2506 + 1203].length();
      I[861 + 1836 - 1520 + 664].length();
      registerBlock(var30, var10001, (new BlockCompressedPowered(Material.IRON, MapColor.TNT)).setHardness(5.0F).setResistance(10.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[1509 + 878 - 1785 + 1240]).setCreativeTab(CreativeTabs.REDSTONE));
      var30 = 70 + 86 - 132 + 129;
      var10001 = I[419 + 1280 - 1509 + 1653];
      I[70 + 481 - -832 + 461].length();
      I[1223 + 774 - 655 + 503].length();
      registerBlock(var30, var10001, (new BlockOre(MapColor.NETHERRACK)).setHardness(3.0F).setResistance(5.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[480 + 865 - -47 + 454]));
      var30 = 113 + 65 - 120 + 96;
      var10001 = I[737 + 1707 - 1870 + 1273];
      I[233 + 1840 - 1349 + 1124].length();
      I[103 + 1648 - 218 + 316].length();
      registerBlock(var30, var10001, (new BlockHopper()).setHardness(3.0F).setResistance(8.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[747 + 537 - -485 + 81]));
      I[1381 + 1327 - 1120 + 263].length();
      I[1559 + 128 - 1023 + 1188].length();
      Block var11 = (new BlockQuartz()).setSoundType(SoundType.STONE).setHardness(0.8F).setUnlocalizedName(I[912 + 672 - 1415 + 1684]);
      registerBlock(74 + 46 - -34 + 1, I[787 + 780 - 1449 + 1736], var11);
      var30 = 1 + 77 - 1 + 79;
      var10001 = I[1588 + 1510 - 1558 + 315];
      I[267 + 869 - 295 + 1015].length();
      registerBlock(var30, var10001, (new BlockStairs(var11.getDefaultState().withProperty(BlockQuartz.VARIANT, BlockQuartz.EnumType.DEFAULT))).setUnlocalizedName(I[1312 + 1771 - 1584 + 358]));
      var30 = 96 + 34 - 19 + 46;
      var10001 = I[424 + 752 - 1049 + 1731];
      I[1544 + 892 - 1830 + 1253].length();
      I[797 + 1758 - 947 + 252].length();
      registerBlock(var30, var10001, (new BlockRailPowered()).setHardness(0.7F).setSoundType(SoundType.METAL).setUnlocalizedName(I[630 + 307 - 481 + 1405]));
      var30 = 142 + 109 - 204 + 111;
      var10001 = I[1723 + 743 - 1459 + 855];
      I[649 + 243 - 857 + 1828].length();
      I[939 + 1275 - 633 + 283].length();
      registerBlock(var30, var10001, (new BlockDropper()).setHardness(3.5F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1287 + 1457 - 1962 + 1083]));
      var30 = 51 + 55 - 95 + 148;
      var10001 = I[344 + 1366 - 279 + 435];
      I[1576 + 318 - 952 + 925].length();
      I[1671 + 1639 - 3224 + 1782].length();
      registerBlock(var30, var10001, (new BlockStainedHardenedClay()).setHardness(1.25F).setResistance(7.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[660 + 1689 - 562 + 82]));
      var30 = 35 + 6 - -71 + 48;
      var10001 = I[1853 + 471 - 1998 + 1544];
      I[1686 + 1227 - 1478 + 436].length();
      I[969 + 480 - 1217 + 1640].length();
      I[511 + 100 - 285 + 1547].length();
      I[1541 + 392 - 704 + 645].length();
      registerBlock(var30, var10001, (new BlockStainedGlassPane()).setHardness(0.3F).setSoundType(SoundType.GLASS).setUnlocalizedName(I[1451 + 386 - 388 + 426]));
      var30 = 159 + 31 - 92 + 63;
      var10001 = I[635 + 1065 - 685 + 861];
      I[1342 + 1559 - 1609 + 585].length();
      I[439 + 150 - 212 + 1501].length();
      I[826 + 510 - 166 + 709].length();
      registerBlock(var30, var10001, (new BlockNewLeaf()).setUnlocalizedName(I[159 + 869 - 506 + 1358]));
      var30 = 126 + 13 - 9 + 32;
      var10001 = I[1165 + 1031 - 1583 + 1268];
      I[503 + 512 - 616 + 1483].length();
      I[336 + 177 - -154 + 1216].length();
      I[7 + 707 - 702 + 1872].length();
      registerBlock(var30, var10001, (new BlockNewLog()).setUnlocalizedName(I[1236 + 1459 - 1162 + 352]));
      var30 = 154 + 25 - 155 + 139;
      var10001 = I[408 + 154 - -589 + 735];
      I[449 + 1542 - 747 + 643].length();
      I[1418 + 1248 - 1021 + 243].length();
      registerBlock(var30, var10001, (new BlockStairs(var1.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.ACACIA))).setUnlocalizedName(I[1482 + 998 - 648 + 57]));
      var30 = 106 + 119 - 212 + 151;
      var10001 = I[1304 + 830 - 349 + 105];
      I[251 + 521 - 751 + 1870].length();
      registerBlock(var30, var10001, (new BlockStairs(var1.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.DARK_OAK))).setUnlocalizedName(I[1509 + 895 - 618 + 106]));
      var30 = 148 + 62 - 126 + 81;
      var10001 = I[728 + 95 - -381 + 689];
      I[528 + 553 - 990 + 1803].length();
      I[1341 + 1780 - 1399 + 173].length();
      registerBlock(var30, var10001, (new BlockSlime()).setUnlocalizedName(I[769 + 673 - -261 + 193]).setSoundType(SoundType.SLIME));
      var30 = 10 + 128 - 107 + 135;
      var10001 = I[1512 + 301 - 236 + 320];
      I[1733 + 1156 - 2294 + 1303].length();
      I[649 + 932 - 1216 + 1534].length();
      I[848 + 844 - 986 + 1194].length();
      I[140 + 676 - -441 + 644].length();
      registerBlock(var30, var10001, (new BlockBarrier()).setUnlocalizedName(I[1221 + 95 - -347 + 239]));
      var30 = 70 + 56 - -38 + 3;
      var10001 = I[1597 + 391 - 1079 + 994];
      I[1476 + 565 - 480 + 343].length();
      I[382 + 1378 - 252 + 397].length();
      registerBlock(var30, var10001, (new BlockTrapDoor(Material.IRON)).setHardness(5.0F).setSoundType(SoundType.METAL).setUnlocalizedName(I[1402 + 1860 - 2965 + 1609]).disableStats());
      var30 = 148 + 104 - 123 + 39;
      var10001 = I[1377 + 533 - 1168 + 1165];
      I[1002 + 1184 - 812 + 534].length();
      I[964 + 395 - -444 + 106].length();
      I[75 + 1652 - -110 + 73].length();
      I[1670 + 836 - 1607 + 1012].length();
      registerBlock(var30, var10001, (new BlockPrismarine()).setHardness(1.5F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[63 + 864 - -780 + 205]));
      var30 = 30 + 124 - 152 + 167;
      var10001 = I[1572 + 534 - 490 + 297];
      I[171 + 788 - -383 + 572].length();
      registerBlock(var30, var10001, (new BlockSeaLantern(Material.GLASS)).setHardness(0.3F).setSoundType(SoundType.GLASS).setLightLevel(1.0F).setUnlocalizedName(I[1720 + 169 - 635 + 661]));
      var30 = 7 + 159 - 164 + 168;
      var10001 = I[1619 + 489 - 946 + 754];
      I[648 + 1485 - 289 + 73].length();
      I[1534 + 1523 - 1660 + 521].length();
      I[1789 + 665 - 1890 + 1355].length();
      I[1156 + 87 - -67 + 610].length();
      registerBlock(var30, var10001, (new BlockHay()).setHardness(0.5F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[114 + 1303 - 788 + 1292]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 158 + 124 - 172 + 61;
      var10001 = I[906 + 981 - 1508 + 1543];
      I[1455 + 430 - 1541 + 1579].length();
      I[565 + 754 - -208 + 397].length();
      registerBlock(var30, var10001, (new BlockCarpet()).setHardness(0.1F).setSoundType(SoundType.CLOTH).setUnlocalizedName(I[351 + 250 - -601 + 723]).setLightOpacity("".length()));
      var30 = 17 + 104 - -45 + 6;
      var10001 = I[1622 + 1206 - 2598 + 1696];
      I[1454 + 1230 - 1321 + 564].length();
      I[1596 + 813 - 1253 + 772].length();
      I[1754 + 14 - 1343 + 1504].length();
      registerBlock(var30, var10001, (new BlockHardenedClay()).setHardness(1.25F).setResistance(7.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[970 + 1703 - 2380 + 1637]));
      var30 = 88 + 61 - 28 + 52;
      var10001 = I[1091 + 295 - 968 + 1513];
      I[137 + 1101 - 515 + 1209].length();
      registerBlock(var30, var10001, (new Block(Material.ROCK, MapColor.BLACK)).setHardness(5.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[617 + 518 - 1124 + 1922]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 45 + 18 - -96 + 15;
      var10001 = I[327 + 615 - -794 + 198];
      I[1805 + 284 - 669 + 515].length();
      I[50 + 1861 - 630 + 655].length();
      I[924 + 56 - -70 + 887].length();
      I[1367 + 1586 - 1933 + 918].length();
      registerBlock(var30, var10001, (new BlockPackedIce()).setHardness(0.5F).setSoundType(SoundType.GLASS).setUnlocalizedName(I[186 + 1618 - 1617 + 1752]));
      var30 = 8 + 28 - -30 + 109;
      var10001 = I[1242 + 1110 - 1656 + 1244];
      I[403 + 781 - 219 + 976].length();
      I[1122 + 472 - 284 + 632].length();
      registerBlock(var30, (String)var10001, new BlockDoublePlant());
      var30 = 30 + 39 - -72 + 35;
      var10001 = I[1641 + 676 - 813 + 439];
      I[720 + 679 - 310 + 855].length();
      I[1197 + 1595 - 1848 + 1001].length();
      registerBlock(var30, var10001, (new BlockBanner.BlockBannerStanding()).setHardness(1.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1780 + 1546 - 2109 + 729]).disableStats());
      var30 = 54 + 175 - 58 + 6;
      var10001 = I[1841 + 1911 - 1909 + 104];
      I[1584 + 1572 - 2870 + 1662].length();
      I[50 + 645 - -455 + 799].length();
      I[1868 + 1304 - 1811 + 589].length();
      I[1256 + 300 - 1366 + 1761].length();
      registerBlock(var30, var10001, (new BlockBanner.BlockBannerHanging()).setHardness(1.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1199 + 917 - 1309 + 1145]).disableStats());
      var30 = 159 + 42 - 46 + 23;
      var10001 = I[1449 + 287 - -46 + 171];
      I[864 + 683 - 1490 + 1897].length();
      I[1799 + 744 - 2302 + 1714].length();
      I[685 + 1342 - 1887 + 1816].length();
      registerBlock(var30, (String)var10001, new BlockDaylightDetector((boolean)" ".length()));
      I[536 + 452 - 183 + 1152].length();
      Block var12 = (new BlockRedSandstone()).setSoundType(SoundType.STONE).setHardness(0.8F).setUnlocalizedName(I[952 + 1234 - 1411 + 1183]);
      registerBlock(50 + 38 - -46 + 45, I[1002 + 1573 - 1088 + 472], var12);
      var30 = 149 + 84 - 158 + 105;
      var10001 = I[23 + 166 - -1243 + 528];
      I[347 + 115 - -924 + 575].length();
      I[1462 + 207 - 425 + 718].length();
      registerBlock(var30, var10001, (new BlockStairs(var12.getDefaultState().withProperty(BlockRedSandstone.TYPE, BlockRedSandstone.EnumType.SMOOTH))).setUnlocalizedName(I[1637 + 1508 - 2256 + 1074]));
      var30 = 79 + 46 - 10 + 66;
      var10001 = I[1772 + 25 - 1651 + 1818];
      I[1519 + 312 - 381 + 515].length();
      I[823 + 1803 - 1897 + 1237].length();
      registerBlock(var30, var10001, (new BlockDoubleStoneSlabNew()).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[441 + 177 - -1139 + 210]));
      var30 = 118 + 22 - 123 + 165;
      var10001 = I[324 + 289 - 276 + 1631];
      I[1045 + 604 - 1369 + 1689].length();
      I[1094 + 762 - -32 + 82].length();
      I[1641 + 1015 - 2138 + 1453].length();
      I[308 + 668 - 869 + 1865].length();
      registerBlock(var30, var10001, (new BlockHalfStoneSlabNew()).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[298 + 1568 - 1849 + 1956]));
      var30 = 80 + 3 - -75 + 25;
      var10001 = I[1852 + 251 - 410 + 281];
      I[1909 + 1578 - 1522 + 10].length();
      I[496 + 1239 - 1483 + 1724].length();
      I[1084 + 410 - 857 + 1340].length();
      I[60 + 555 - -167 + 1196].length();
      registerBlock(var30, var10001, (new BlockFenceGate(BlockPlanks.EnumType.SPRUCE)).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[657 + 970 - -41 + 311]));
      var30 = 18 + 57 - -100 + 9;
      var10001 = I[948 + 535 - 1100 + 1597];
      I[512 + 1899 - 1937 + 1507].length();
      registerBlock(var30, var10001, (new BlockFenceGate(BlockPlanks.EnumType.BIRCH)).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[172 + 131 - -1637 + 42]));
      var30 = 16 + 143 - 99 + 125;
      var10001 = I[1795 + 1585 - 2471 + 1074];
      I[545 + 470 - 914 + 1883].length();
      registerBlock(var30, var10001, (new BlockFenceGate(BlockPlanks.EnumType.JUNGLE)).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[245 + 107 - -540 + 1093]));
      var30 = 18 + 82 - -84 + 2;
      var10001 = I[289 + 971 - -691 + 35];
      I[782 + 1374 - 2131 + 1962].length();
      I[769 + 1774 - 791 + 236].length();
      registerBlock(var30, var10001, (new BlockFenceGate(BlockPlanks.EnumType.DARK_OAK)).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1092 + 1937 - 2250 + 1210]));
      var30 = 133 + 111 - 130 + 73;
      var10001 = I[1656 + 1405 - 2483 + 1412];
      I[1739 + 1737 - 2974 + 1489].length();
      I[176 + 657 - 684 + 1843].length();
      registerBlock(var30, var10001, (new BlockFenceGate(BlockPlanks.EnumType.ACACIA)).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1161 + 440 - 626 + 1018]));
      var30 = 132 + 38 - 123 + 141;
      var10001 = I[1686 + 1562 - 1817 + 563];
      I[910 + 883 - 1325 + 1527].length();
      I[335 + 1004 - 1263 + 1920].length();
      I[296 + 1134 - 772 + 1339].length();
      registerBlock(var30, var10001, (new BlockFence(Material.WOOD, BlockPlanks.EnumType.SPRUCE.getMapColor())).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[288 + 93 - 119 + 1736]));
      var30 = 66 + 14 - -20 + 89;
      var10001 = I[1445 + 1013 - 1047 + 588];
      I[1500 + 976 - 1997 + 1521].length();
      I[277 + 202 - -474 + 1048].length();
      I[445 + 115 - -1288 + 154].length();
      registerBlock(var30, var10001, (new BlockFence(Material.WOOD, BlockPlanks.EnumType.BIRCH.getMapColor())).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[995 + 478 - 128 + 658]));
      var30 = 131 + 3 - -49 + 7;
      var10001 = I[93 + 205 - -997 + 709];
      I[928 + 652 - 407 + 832].length();
      I[396 + 1487 - 1780 + 1903].length();
      I[43 + 269 - -593 + 1102].length();
      I[1716 + 1631 - 1681 + 342].length();
      registerBlock(var30, var10001, (new BlockFence(Material.WOOD, BlockPlanks.EnumType.JUNGLE.getMapColor())).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[10 + 936 - 489 + 1552]));
      var30 = 187 + 141 - 143 + 6;
      var10001 = I[297 + 595 - 773 + 1891];
      I[1746 + 1438 - 2822 + 1649].length();
      I[1109 + 1146 - 1883 + 1640].length();
      I[1277 + 1166 - 1083 + 653].length();
      registerBlock(var30, var10001, (new BlockFence(Material.WOOD, BlockPlanks.EnumType.DARK_OAK.getMapColor())).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[778 + 287 - 477 + 1426]));
      var30 = 51 + 19 - -50 + 72;
      var10001 = I[1814 + 389 - 1290 + 1102];
      I[1863 + 1907 - 2885 + 1131].length();
      I[1208 + 877 - 2001 + 1933].length();
      I[1800 + 714 - 1173 + 677].length();
      registerBlock(var30, var10001, (new BlockFence(Material.WOOD, BlockPlanks.EnumType.ACACIA.getMapColor())).setHardness(2.0F).setResistance(5.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1197 + 766 - 1445 + 1501]));
      var30 = 10 + 144 - 28 + 67;
      var10001 = I[1431 + 380 - -167 + 42];
      I[106 + 222 - -60 + 1633].length();
      registerBlock(var30, var10001, (new BlockDoor(Material.WOOD)).setHardness(3.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1067 + 1820 - 1168 + 303]).disableStats());
      var30 = 45 + 30 - 7 + 126;
      var10001 = I[1210 + 1920 - 2317 + 1210];
      I[1107 + 1313 - 1216 + 820].length();
      I[282 + 417 - -1250 + 76].length();
      I[271 + 674 - -244 + 837].length();
      registerBlock(var30, var10001, (new BlockDoor(Material.WOOD)).setHardness(3.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1844 + 1046 - 1878 + 1015]).disableStats());
      var30 = 36 + 115 - 124 + 168;
      var10001 = I[254 + 752 - -723 + 299];
      I[848 + 1516 - 1215 + 880].length();
      registerBlock(var30, var10001, (new BlockDoor(Material.WOOD)).setHardness(3.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1 + 1838 - 533 + 724]).disableStats());
      var30 = 13 + 82 - 54 + 155;
      var10001 = I[833 + 1180 - 1201 + 1219];
      I[1237 + 864 - 674 + 605].length();
      registerBlock(var30, var10001, (new BlockDoor(Material.WOOD)).setHardness(3.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1416 + 842 - 331 + 106]).disableStats());
      var30 = 158 + 53 - 53 + 39;
      var10001 = I[1074 + 1803 - 2182 + 1339];
      I[1984 + 338 - 1671 + 1384].length();
      I[816 + 1186 - 520 + 554].length();
      I[39 + 839 - -717 + 442].length();
      registerBlock(var30, var10001, (new BlockDoor(Material.WOOD)).setHardness(3.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[646 + 688 - -372 + 332]).disableStats());
      var30 = 46 + 79 - -33 + 40;
      var10001 = I[976 + 323 - -720 + 20];
      I[1861 + 1246 - 1071 + 4].length();
      I[1239 + 1915 - 1558 + 445].length();
      registerBlock(var30, var10001, (new BlockEndRod()).setHardness(0.0F).setLightLevel(0.9375F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[2040 + 528 - 1597 + 1071]));
      var30 = 47 + 50 - -29 + 73;
      var10001 = I[718 + 301 - 700 + 1724];
      I[1544 + 406 - 642 + 736].length();
      I[736 + 1012 - 1390 + 1687].length();
      registerBlock(var30, var10001, (new BlockChorusPlant()).setHardness(0.4F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1647 + 501 - 1871 + 1769]));
      var30 = 187 + 196 - 241 + 58;
      var10001 = I[1728 + 531 - 594 + 382];
      I[116 + 2017 - 389 + 304].length();
      I[1634 + 908 - 2537 + 2044].length();
      registerBlock(var30, var10001, (new BlockChorusFlower()).setHardness(0.4F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[270 + 1454 - 1161 + 1487]));
      I[397 + 2001 - 435 + 88].length();
      I[1534 + 1266 - 2388 + 1640].length();
      I[200 + 1221 - -380 + 252].length();
      Block var13 = (new Block(Material.ROCK, MapColor.MAGENTA)).setHardness(1.5F).setResistance(10.0F).setSoundType(SoundType.STONE).setCreativeTab(CreativeTabs.BUILDING_BLOCKS).setUnlocalizedName(I[1424 + 1117 - 2013 + 1526]);
      registerBlock(33 + 98 - 45 + 115, I[1535 + 1054 - 1356 + 822], var13);
      var30 = 82 + 115 - 86 + 91;
      var10001 = I[1939 + 1210 - 2953 + 1860];
      I[71 + 1559 - 1310 + 1737].length();
      I[863 + 806 - 1492 + 1881].length();
      I[1479 + 817 - 944 + 707].length();
      registerBlock(var30, var10001, (new BlockRotatedPillar(Material.ROCK, MapColor.MAGENTA)).setHardness(1.5F).setResistance(10.0F).setSoundType(SoundType.STONE).setCreativeTab(CreativeTabs.BUILDING_BLOCKS).setUnlocalizedName(I[1084 + 1783 - 1074 + 267]));
      var30 = 32 + 158 - 1 + 14;
      var10001 = I[573 + 635 - -307 + 546];
      I[1244 + 173 - 904 + 1549].length();
      I[1129 + 1042 - 1153 + 1045].length();
      registerBlock(var30, var10001, (new BlockStairs(var13.getDefaultState())).setUnlocalizedName(I[26 + 201 - -548 + 1289]));
      var30 = 109 + 6 - 81 + 170;
      var10001 = I[1221 + 1707 - 1561 + 698];
      I[796 + 1782 - 716 + 204].length();
      registerBlock(var30, var10001, (new BlockPurpurSlab.Double()).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[390 + 13 - -948 + 716]));
      var30 = 196 + 122 - 138 + 25;
      var10001 = I[190 + 188 - -1385 + 305];
      I[177 + 1135 - 1141 + 1898].length();
      I[770 + 156 - -841 + 303].length();
      registerBlock(var30, var10001, (new BlockPurpurSlab.Half()).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1775 + 1786 - 3517 + 2027]));
      var30 = 34 + 139 - 151 + 184;
      var10001 = I[1617 + 585 - 878 + 748];
      I[1131 + 1104 - 1073 + 911].length();
      registerBlock(var30, var10001, (new Block(Material.ROCK, MapColor.SAND)).setSoundType(SoundType.STONE).setHardness(0.8F).setCreativeTab(CreativeTabs.BUILDING_BLOCKS).setUnlocalizedName(I[1323 + 130 - 384 + 1005]));
      var30 = 94 + 50 - 123 + 186;
      var10001 = I[986 + 1591 - 2003 + 1501];
      I[501 + 1018 - 743 + 1300].length();
      I[51 + 765 - -1123 + 138].length();
      I[661 + 1063 - -190 + 164].length();
      I[10 + 2021 - 1743 + 1791].length();
      registerBlock(var30, var10001, (new BlockBeetroot()).setUnlocalizedName(I[1076 + 1656 - 2414 + 1762]));
      I[221 + 1720 - 1652 + 1792].length();
      I[1651 + 357 - 542 + 616].length();
      Block var14 = (new BlockGrassPath()).setHardness(0.65F).setSoundType(SoundType.PLANT).setUnlocalizedName(I[1423 + 1743 - 2406 + 1323]).disableStats();
      registerBlock(26 + 138 - 30 + 74, I[101 + 1969 - 847 + 861], var14);
      var30 = 136 + 135 - 101 + 39;
      var10001 = I[2009 + 1430 - 2080 + 726];
      I[1778 + 1436 - 2671 + 1543].length();
      I[1928 + 1632 - 3126 + 1653].length();
      registerBlock(var30, var10001, (new BlockEndGateway(Material.PORTAL)).setHardness(-1.0F).setResistance(6000000.0F));
      var30 = 26 + 195 - 152 + 141;
      var10001 = I[1364 + 718 - 57 + 63];
      I[569 + 1958 - 2405 + 1967].length();
      I[1887 + 690 - 1301 + 814].length();
      I[1514 + 1513 - 1947 + 1011].length();
      I[1727 + 792 - 1788 + 1361].length();
      registerBlock(var30, var10001, (new BlockCommandBlock(MapColor.PURPLE)).setBlockUnbreakable().setResistance(6000000.0F).setUnlocalizedName(I[1381 + 1282 - 1729 + 1159]));
      var30 = 167 + 169 - 128 + 3;
      var10001 = I[190 + 2060 - 1600 + 1444];
      I[1241 + 1584 - 1209 + 479].length();
      I[157 + 343 - -47 + 1549].length();
      registerBlock(var30, var10001, (new BlockCommandBlock(MapColor.GREEN)).setBlockUnbreakable().setResistance(6000000.0F).setUnlocalizedName(I[457 + 1669 - 1483 + 1454]));
      var30 = 4 + 197 - 183 + 194;
      var10001 = I[1959 + 845 - 2770 + 2064];
      I[1883 + 1961 - 3669 + 1924].length();
      I[1406 + 1144 - 2312 + 1862].length();
      I[643 + 9 - -1096 + 353].length();
      registerBlock(var30, var10001, (new BlockFrostedIce()).setHardness(0.5F).setLightOpacity("   ".length()).setSoundType(SoundType.GLASS).setUnlocalizedName(I[2078 + 810 - 2882 + 2096]));
      var30 = 183 + 134 - 116 + 12;
      var10001 = I[105 + 1728 - 1315 + 1585];
      I[482 + 824 - 506 + 1304].length();
      I[1316 + 1168 - 1295 + 916].length();
      registerBlock(var30, var10001, (new BlockMagma()).setHardness(0.5F).setSoundType(SoundType.STONE).setUnlocalizedName(I[175 + 1516 - 1492 + 1907]));
      var30 = 179 + 85 - 181 + 131;
      var10001 = I[1186 + 1125 - 1675 + 1471];
      I[1571 + 804 - 1105 + 838].length();
      I[637 + 559 - -118 + 795].length();
      registerBlock(var30, var10001, (new Block(Material.GRASS, MapColor.RED)).setCreativeTab(CreativeTabs.BUILDING_BLOCKS).setHardness(1.0F).setSoundType(SoundType.WOOD).setUnlocalizedName(I[1760 + 8 - 802 + 1144]));
      var30 = 0 + 22 - -165 + 28;
      var10001 = I[1871 + 1422 - 1363 + 181];
      I[756 + 14 - 32 + 1374].length();
      I[1249 + 1384 - 631 + 111].length();
      registerBlock(var30, var10001, (new BlockNetherBrick()).setHardness(2.0F).setResistance(10.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[597 + 978 - 1339 + 1878]).setCreativeTab(CreativeTabs.BUILDING_BLOCKS));
      var30 = 124 + 89 - 40 + 43;
      var10001 = I[1658 + 861 - 1647 + 1243];
      I[1733 + 363 - 1713 + 1733].length();
      I[1054 + 1572 - 1332 + 823].length();
      I[2074 + 305 - 2276 + 2015].length();
      registerBlock(var30, var10001, (new BlockBone()).setUnlocalizedName(I[2008 + 1715 - 2072 + 468]));
      var30 = 26 + 212 - 60 + 39;
      var10001 = I[1232 + 754 - 1671 + 1805];
      I[1549 + 669 - 467 + 370].length();
      registerBlock(var30, var10001, (new BlockStructureVoid()).setUnlocalizedName(I[744 + 1004 - 1678 + 2052]));
      var30 = 217 + 184 - 341 + 158;
      var10001 = I[2046 + 24 - 1179 + 1232];
      I[178 + 1345 - 1367 + 1968].length();
      I[1993 + 1200 - 1206 + 138].length();
      registerBlock(var30, var10001, (new BlockObserver()).setHardness(3.0F).setUnlocalizedName(I[1878 + 282 - 1453 + 1419]));
      var30 = 92 + 1 - -69 + 57;
      var10001 = I[2034 + 224 - 1394 + 1263];
      I[1785 + 239 - 216 + 320].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.WHITE)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[752 + 936 - -277 + 164]));
      var30 = 143 + 181 - 165 + 61;
      var10001 = I[862 + 762 - 1277 + 1783];
      I[423 + 1063 - 661 + 1306].length();
      I[1524 + 941 - 1949 + 1616].length();
      I[1880 + 1846 - 1660 + 67].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.ORANGE)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[33 + 348 - -1406 + 347]));
      var30 = 63 + 169 - 192 + 181;
      var10001 = I[1222 + 776 - 762 + 899];
      I[1361 + 1019 - 1126 + 882].length();
      I[1033 + 2124 - 1316 + 296].length();
      I[1679 + 1739 - 1864 + 584].length();
      I[1208 + 1549 - 1145 + 527].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.MAGENTA)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1603 + 1411 - 891 + 17]));
      var30 = 210 + 11 - 27 + 28;
      var10001 = I[1282 + 1218 - 1091 + 732];
      I[680 + 472 - 617 + 1607].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.LIGHT_BLUE)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1684 + 585 - 227 + 101]));
      var30 = 178 + 199 - 322 + 168;
      var10001 = I[1974 + 891 - 1974 + 1253];
      I[2004 + 167 - 221 + 195].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.YELLOW)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1940 + 1558 - 2529 + 1177]));
      var30 = 5 + 215 - 175 + 179;
      var10001 = I[1134 + 269 - 1356 + 2100];
      I[517 + 1911 - 800 + 520].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.LIME)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[564 + 1291 - 880 + 1174]));
      var30 = 192 + 153 - 298 + 178;
      var10001 = I[1094 + 559 - 522 + 1019];
      I[417 + 438 - -966 + 330].length();
      I[1915 + 1525 - 2075 + 787].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.PINK)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[863 + 1286 - 2040 + 2044]));
      var30 = 196 + 194 - 315 + 151;
      var10001 = I[1063 + 1054 - 287 + 324];
      I[1783 + 1805 - 2295 + 862].length();
      I[1965 + 573 - 1950 + 1568].length();
      I[2155 + 343 - 1915 + 1574].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.GRAY)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[770 + 977 - 837 + 1248]));
      var30 = 185 + 188 - 194 + 48;
      var10001 = I[951 + 1244 - 766 + 730];
      I[194 + 1612 - 366 + 720].length();
      I[703 + 438 - -531 + 489].length();
      I[553 + 810 - 255 + 1054].length();
      I[1087 + 1919 - 1396 + 553].length();
      I[1029 + 1688 - 2364 + 1811].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.SILVER)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1258 + 136 - 192 + 963]));
      var30 = 54 + 23 - -40 + 111;
      var10001 = I[791 + 1163 - 1318 + 1530];
      I[607 + 1906 - 1341 + 995].length();
      I[147 + 1124 - 527 + 1424].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.CYAN)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1746 + 1331 - 2539 + 1631]));
      var30 = 151 + 17 - 96 + 157;
      var10001 = I[869 + 1219 - 505 + 587];
      I[719 + 991 - 612 + 1073].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.PURPLE)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1258 + 1619 - 1161 + 456]));
      var30 = 122 + 64 - 107 + 151;
      var10001 = I[725 + 576 - 229 + 1101];
      I[876 + 2028 - 1711 + 981].length();
      I[1275 + 845 - 1950 + 2005].length();
      I[1652 + 1467 - 2640 + 1697].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.BLUE)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1363 + 1488 - 1210 + 536]));
      var30 = 182 + 127 - 162 + 84;
      var10001 = I[171 + 688 - 603 + 1922];
      I[447 + 1748 - 2065 + 2049].length();
      I[919 + 214 - 534 + 1581].length();
      I[823 + 1108 - 1479 + 1729].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.BROWN)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1017 + 1823 - 2614 + 1956]));
      var30 = 63 + 119 - 163 + 213;
      var10001 = I[1417 + 77 - 679 + 1368];
      I[1715 + 1799 - 3220 + 1890].length();
      I[280 + 1264 - -466 + 175].length();
      I[300 + 381 - 149 + 1654].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.GREEN)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[984 + 574 - 891 + 1520]));
      var30 = 202 + 86 - 236 + 181;
      var10001 = I[381 + 835 - 91 + 1063];
      I[1932 + 1073 - 2132 + 1316].length();
      I[130 + 716 - 290 + 1634].length();
      I[684 + 890 - -553 + 64].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.RED)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1574 + 273 - 889 + 1234]));
      var30 = 24 + 30 - -73 + 107;
      var10001 = I[2148 + 86 - 1667 + 1626];
      I[1919 + 1558 - 2328 + 1045].length();
      I[28 + 786 - 758 + 2139].length();
      I[429 + 1292 - 1287 + 1762].length();
      registerBlock(var30, var10001, (new BlockShulkerBox(EnumDyeColor.BLACK)).setHardness(2.0F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1467 + 49 - 1179 + 1860]));
      var30 = 153 + 201 - 143 + 24;
      var10001 = I[2104 + 1770 - 2476 + 800];
      I[140 + 1347 - 604 + 1316].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.WHITE));
      var30 = 36 + 90 - -85 + 25;
      var10001 = I[1549 + 1900 - 1393 + 144];
      I[793 + 1242 - 316 + 482].length();
      I[1478 + 1676 - 2151 + 1199].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.ORANGE));
      var30 = 87 + 73 - 36 + 113;
      var10001 = I[1119 + 954 - 447 + 577];
      I[1065 + 1020 - 1012 + 1131].length();
      I[856 + 715 - 1407 + 2041].length();
      I[1117 + 1908 - 969 + 150].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.MAGENTA));
      var30 = 9 + 127 - 4 + 106;
      var10001 = I[1595 + 653 - 1005 + 964];
      I[1399 + 1717 - 2553 + 1645].length();
      I[1717 + 1147 - 1858 + 1203].length();
      I[841 + 1158 - 206 + 417].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.LIGHT_BLUE));
      var30 = 53 + 3 - 43 + 226;
      var10001 = I[748 + 1529 - 2095 + 2029];
      I[1731 + 328 - 203 + 356].length();
      I[1065 + 1763 - 1577 + 962].length();
      I[1252 + 514 - 362 + 810].length();
      I[765 + 1923 - 2366 + 1893].length();
      I[1450 + 181 - -20 + 565].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.YELLOW));
      var30 = 115 + 70 - -6 + 49;
      var10001 = I[1490 + 1823 - 1699 + 603];
      I[516 + 822 - 645 + 1525].length();
      I[1822 + 266 - 594 + 725].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.LIME));
      var30 = 63 + 39 - 47 + 186;
      var10001 = I[1855 + 962 - 1362 + 765];
      I[1925 + 1410 - 2620 + 1506].length();
      I[5 + 2007 - 1074 + 1284].length();
      I[192 + 1450 - -565 + 16].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.PINK));
      var30 = 224 + 54 - 182 + 146;
      var10001 = I[1663 + 138 - 599 + 1022];
      I[474 + 66 - 136 + 1821].length();
      I[2046 + 38 - 1327 + 1469].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.GRAY));
      var30 = 42 + 125 - 96 + 172;
      var10001 = I[1705 + 726 - 1847 + 1643];
      I[2132 + 1213 - 2129 + 1012].length();
      I[1945 + 1965 - 2922 + 1241].length();
      I[2010 + 2213 - 2743 + 750].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.SILVER));
      var30 = 34 + 173 - 55 + 92;
      var10001 = I[475 + 1112 - 1549 + 2193];
      I[717 + 1469 - 1006 + 1052].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.CYAN));
      var30 = 14 + 133 - 131 + 229;
      var10001 = I[713 + 2205 - 2605 + 1920];
      I[441 + 398 - 634 + 2029].length();
      I[1253 + 1615 - 741 + 108].length();
      I[1836 + 325 - 532 + 607].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.PURPLE));
      var30 = 36 + 77 - 53 + 186;
      var10001 = I[102 + 570 - 599 + 2164];
      I[1167 + 277 - -537 + 257].length();
      I[1037 + 273 - 277 + 1206].length();
      I[2025 + 1033 - 925 + 107].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.BLUE));
      var30 = 79 + 27 - -11 + 130;
      var10001 = I[1748 + 772 - 2518 + 2239];
      I[67 + 1767 - 233 + 641].length();
      I[563 + 436 - 510 + 1754].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.BROWN));
      var30 = 107 + 34 - -107 + 0;
      var10001 = I[914 + 1729 - 2498 + 2099];
      I[1363 + 1900 - 1538 + 520].length();
      I[1434 + 1758 - 2518 + 1572].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.GREEN));
      var30 = 242 + 236 - 459 + 230;
      var10001 = I[918 + 1215 - 587 + 701];
      I[692 + 448 - 986 + 2094].length();
      I[744 + 450 - -427 + 628].length();
      I[513 + 639 - -1025 + 73].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.RED));
      var30 = 50 + 103 - 123 + 220;
      var10001 = I[79 + 172 - -1943 + 57];
      I[541 + 1022 - -381 + 308].length();
      I[1769 + 1132 - 1390 + 742].length();
      registerBlock(var30, (String)var10001, new BlockGlazedTerracotta(EnumDyeColor.BLACK));
      var30 = 155 + 133 - 222 + 185;
      var10001 = I[1895 + 612 - 1162 + 909];
      I[2157 + 1759 - 3278 + 1617].length();
      registerBlock(var30, var10001, (new BlockColored(Material.ROCK)).setHardness(1.8F).setSoundType(SoundType.STONE).setUnlocalizedName(I[1772 + 1232 - 2566 + 1818]));
      var30 = 172 + 113 - 102 + 69;
      var10001 = I[1339 + 1056 - 1597 + 1459];
      I[244 + 2227 - 1929 + 1716].length();
      I[1052 + 1469 - 1057 + 795].length();
      registerBlock(var30, var10001, (new BlockConcretePowder()).setHardness(0.5F).setSoundType(SoundType.SAND).setUnlocalizedName(I[209 + 1497 - -536 + 18]));
      var30 = 129 + 239 - 168 + 55;
      var10001 = I[1745 + 1053 - 1605 + 1068];
      I[1559 + 207 - 263 + 759].length();
      I[621 + 973 - 1518 + 2187].length();
      registerBlock(var30, var10001, (new BlockStructure()).setBlockUnbreakable().setResistance(6000000.0F).setUnlocalizedName(I[721 + 954 - -450 + 139]));
      REGISTRY.validateKey();
      Iterator var15 = REGISTRY.iterator();

      do {
         int var20;
         if (!var15.hasNext()) {
            Block[] var32 = new Block[" ".length()];
            I[313 + 1758 - 1108 + 1302].length();
            I[944 + 955 - 1277 + 1644].length();
            I[1102 + 2116 - 2011 + 1060].length();
            int var31 = "".length();
            RegistryNamespacedDefaultedByKey var10003 = REGISTRY;
            I[1682 + 619 - 2134 + 2101].length();
            I[1142 + 272 - 209 + 1064].length();
            var32[var31] = (Block)var10003.getObject(new ResourceLocation(I[412 + 1885 - 737 + 710]));
            HashSet var23 = Sets.newHashSet(var32);
            Iterator var24 = REGISTRY.iterator();

            do {
               if (!var24.hasNext()) {
                  return;
               }

               Block var25 = (Block)var24.next();
               if (!var23.contains(var25)) {
                  UnmodifiableIterator var27 = var25.getBlockState().getValidStates().iterator();

                  while(var27.hasNext()) {
                     IBlockState var29 = (IBlockState)var27.next();
                     var20 = REGISTRY.getIDForObject(var25) << (186 ^ 190) | var25.getMetaFromState(var29);
                     BLOCK_STATE_IDS.put(var29, var20);
                     "".length();
                     if (2 >= 4) {
                        throw null;
                     }
                  }
               } else {
                  int var26 = "".length();

                  while(var26 < (38 ^ 41)) {
                     int var28 = REGISTRY.getIDForObject(var25) << (21 ^ 17) | var26;
                     BLOCK_STATE_IDS.put(var25.getStateFromMeta(var26), var28);
                     ++var26;
                     "".length();
                     if (3 <= 1) {
                        throw null;
                     }
                  }

                  "".length();
                  if (2 != 2) {
                     throw null;
                  }
               }

               "".length();
            } while(-1 == -1);

            throw null;
         }

         Block var16 = (Block)var15.next();
         if (var16.blockMaterial == Material.AIR) {
            var16.useNeighborBrightness = (boolean)"".length();
            "".length();
            if (false) {
               throw null;
            }
         } else {
            int var17 = "".length();
            boolean var18 = var16 instanceof BlockStairs;
            boolean var19 = var16 instanceof BlockSlab;
            if (var16 != var6 && var16 != var14) {
               var30 = "".length();
            } else {
               var30 = " ".length();
               "".length();
               if (2 == 3) {
                  throw null;
               }
            }

            var20 = var30;
            boolean var21 = var16.translucent;
            if (var16.lightOpacity == 0) {
               var30 = " ".length();
               "".length();
               if (2 <= -1) {
                  throw null;
               }
            } else {
               var30 = "".length();
            }

            int var22 = var30;
            if (var18 || var19 || var20 != 0 || var21 || var22 != 0) {
               var17 = " ".length();
            }

            var16.useNeighborBrightness = (boolean)var17;
         }

         "".length();
      } while(1 >= 0);

      throw null;
   }

   /** @deprecated */
   @Deprecated
   public boolean canEntitySpawn(IBlockState var1, Entity var2) {
      return (boolean)" ".length();
   }

   protected static boolean func_193384_b(Block var0) {
      int var10000;
      if (!(var0 instanceof BlockShulkerBox) && !(var0 instanceof BlockLeaves) && !(var0 instanceof BlockTrapDoor) && var0 != Blocks.BEACON && var0 != Blocks.CAULDRON && var0 != Blocks.GLASS && var0 != Blocks.GLOWSTONE && var0 != Blocks.ICE && var0 != Blocks.SEA_LANTERN && var0 != Blocks.STAINED_GLASS) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (4 <= -1) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   /** @deprecated */
   @Deprecated
   public boolean canProvidePower(IBlockState var1) {
      return (boolean)"".length();
   }

   public void onFallenUpon(World var1, BlockPos var2, Entity var3, float var4) {
      var3.fall(var4, 1.0F);
   }

   public boolean isReplaceable(IBlockAccess var1, BlockPos var2) {
      return (boolean)"".length();
   }

   public Block(Material var1, MapColor var2) {
      this.enableStats = (boolean)" ".length();
      this.blockSoundType = SoundType.STONE;
      this.blockParticleGravity = 1.0F;
      this.slipperiness = 0.6F;
      this.blockMaterial = var1;
      this.blockMapColor = var2;
      this.blockState = this.createBlockState();
      this.setDefaultState(this.blockState.getBaseState());
      this.fullBlock = this.getDefaultState().isOpaqueCube();
      int var10001;
      if (this.fullBlock) {
         var10001 = 57 + 231 - 105 + 72;
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.lightOpacity = var10001;
      if (!var1.blocksLight()) {
         var10001 = " ".length();
         "".length();
         if (2 == 0) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.translucent = (boolean)var10001;
   }

   protected Block setSoundType(SoundType var1) {
      this.blockSoundType = var1;
      return this;
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
   }

   public static IBlockState getStateById(int var0) {
      int var1 = var0 & 749 + 2535 - 2673 + 3484;
      int var2 = var0 >> (0 ^ 12) & (120 ^ 119);
      return getBlockById(var1).getStateFromMeta(var2);
   }

   /** @deprecated */
   @Deprecated
   public boolean causesSuffocation(IBlockState var1) {
      int var10000;
      if (this.blockMaterial.blocksMovement() && this.getDefaultState().isFullCube()) {
         var10000 = " ".length();
         "".length();
         if (0 >= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static boolean isEqualTo(Block var0, Block var1) {
      if (var0 != null && var1 != null) {
         int var10000;
         if (var0 == var1) {
            var10000 = " ".length();
            "".length();
            if (4 <= -1) {
               throw null;
            }
         } else {
            var10000 = var0.isAssociatedBlock(var1);
         }

         return (boolean)var10000;
      } else {
         return (boolean)"".length();
      }
   }

   public String toString() {
      String var10000 = I[219 ^ 162];
      String var10001 = I[28 ^ 102];
      String var10002 = I[219 ^ 160];
      var10001 = I[69 ^ 57];
      I[70 ^ 59].length();
      I[5 ^ 123].length();
      I[117 + 88 - 117 + 39].length();
      return I[127 + 60 - 176 + 117] + REGISTRY.getNameForObject(this) + I[13 + 13 - -11 + 92];
   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I[28 ^ 93];
      String var10001 = I[58 ^ 120];
      String var10002 = I[105 ^ 42];
      var10001 = I[211 ^ 151];
      Item var2 = Item.getItemFromBlock(this);
      int var3 = "".length();
      if (var2.getHasSubtypes()) {
         var3 = this.getMetaFromState(var1);
      }

      I[67 ^ 6].length();
      I[25 ^ 95].length();
      I[202 ^ 141].length();
      I[126 ^ 54].length();
      return new ItemStack(var2, " ".length(), var3);
   }

   public static Block getBlockFromItem(@Nullable Item var0) {
      Block var10000;
      if (var0 instanceof ItemBlock) {
         var10000 = ((ItemBlock)var0).getBlock();
         "".length();
         if (3 == 0) {
            throw null;
         }
      } else {
         var10000 = Blocks.AIR;
      }

      return var10000;
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
   }

   public void onBlockDestroyedByPlayer(World var1, BlockPos var2, IBlockState var3) {
   }

   public static Block getBlockById(int var0) {
      return (Block)REGISTRY.getObjectById(var0);
   }

   protected Block setLightLevel(float var1) {
      this.lightValue = (int)(15.0F * var1);
      return this;
   }

   public static int getStateId(IBlockState var0) {
      Block var1 = var0.getBlock();
      return getIdFromBlock(var1) + (var1.getMetaFromState(var0) << (141 ^ 129));
   }

   public boolean canSpawnInBlock() {
      int var10000;
      if (!this.blockMaterial.isSolid() && !this.blockMaterial.isLiquid()) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   /** @deprecated */
   @Deprecated
   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      return "".length();
   }

   /** @deprecated */
   @Deprecated
   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1;
   }

   protected void dropXpOnBlockBreak(World var1, BlockPos var2, int var3) {
      String var10000 = I[60 ^ 19];
      String var10001 = I[58 ^ 10];
      String var10002 = I[95 ^ 110];
      var10001 = I[18 ^ 32];
      if (!var1.isRemote && var1.getGameRules().getBoolean(I[20 ^ 39])) {
         while(var3 > 0) {
            int var4 = EntityXPOrb.getXPSplit(var3);
            I[113 ^ 69].length();
            I[5 ^ 48].length();
            var3 -= var4;
            I[10 ^ 60].length();
            var1.spawnEntityInWorld(new EntityXPOrb(var1, (double)var2.getX() + 0.5D, (double)var2.getY() + 0.5D, (double)var2.getZ() + 0.5D, var4));
            I[126 ^ 73].length();
            I[173 ^ 149].length();
            "".length();
            if (1 < 0) {
               throw null;
            }
         }
      }

   }

   /** @deprecated */
   @Deprecated
   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)" ".length();
   }

   /** @deprecated */
   @Deprecated
   public boolean eventReceived(IBlockState var1, World var2, BlockPos var3, int var4, int var5) {
      return (boolean)"".length();
   }

   /** @deprecated */
   @Deprecated
   public boolean isBlockNormalCube(IBlockState var1) {
      int var10000;
      if (var1.getMaterial().blocksMovement() && var1.isFullCube()) {
         var10000 = " ".length();
         "".length();
         if (3 < 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int tickRate(World var1) {
      return 73 ^ 67;
   }

   /** @deprecated */
   @Deprecated
   public Material getMaterial(IBlockState var1) {
      return this.blockMaterial;
   }

   /** @deprecated */
   @Deprecated
   public boolean isFullBlock(IBlockState var1) {
      return this.fullBlock;
   }

   public void func_190948_a(ItemStack var1, @Nullable World var2, List<String> var3, ITooltipFlag var4) {
   }

   public boolean hasTileEntity() {
      return this.isBlockContainer;
   }

   public void onEntityWalk(World var1, BlockPos var2, Entity var3) {
   }

   /** @deprecated */
   @Deprecated
   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState();
   }

   /** @deprecated */
   @Deprecated
   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1;
   }

   public final IBlockState getDefaultState() {
      return this.defaultBlockState;
   }

   /** @deprecated */
   @Deprecated
   public float getAmbientOcclusionLightValue(IBlockState var1) {
      float var10000;
      if (var1.isBlockNormalCube()) {
         var10000 = 0.2F;
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10000 = 1.0F;
      }

      return var10000;
   }

   /** @deprecated */
   @Deprecated
   public boolean isFullCube(IBlockState var1) {
      return (boolean)" ".length();
   }

   private static void registerBlock(int var0, String var1, Block var2) {
      String var10000 = I[89 + 1344 - -793 + 45];
      String var10001 = I[1069 + 399 - 799 + 1603];
      String var10002 = I[63 + 1969 - 242 + 483];
      var10001 = I[1458 + 1436 - 2881 + 2261];
      I[1403 + 2037 - 1938 + 773].length();
      I[1970 + 1416 - 1634 + 524].length();
      I[1661 + 1827 - 1314 + 103].length();
      registerBlock(var0, new ResourceLocation(var1), var2);
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      String var10000 = I[83 ^ 76];
      String var10001 = I[179 ^ 147];
      String var10002 = I[133 ^ 164];
      var10001 = I[3 ^ 33];
      if (!var1.isRemote) {
         int var6 = this.quantityDroppedWithBonus(var5, var1.rand);
         int var7 = "".length();

         while(var7 < var6) {
            if (var1.rand.nextFloat() <= var4) {
               Item var8 = this.getItemDropped(var3, var1.rand, var5);
               if (var8 != Items.field_190931_a) {
                  I[108 ^ 79].length();
                  I[86 ^ 114].length();
                  I[64 ^ 101].length();
                  I[225 ^ 199].length();
                  spawnAsEntity(var1, var2, new ItemStack(var8, " ".length(), this.damageDropped(var3)));
               }
            }

            ++var7;
            "".length();
            if (2 != 2) {
               throw null;
            }
         }
      }

   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
   }

   /** @deprecated */
   @Deprecated
   public Vec3d func_190949_e(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      String var10000 = I[168 ^ 198];
      String var10001 = I[119 ^ 24];
      String var10002 = I[51 ^ 67];
      var10001 = I[76 ^ 61];
      Block.EnumOffsetType var4 = this.getOffsetType();
      if (var4 == Block.EnumOffsetType.NONE) {
         return Vec3d.ZERO;
      } else {
         long var5 = MathHelper.getCoordinateRandom(var3.getX(), "".length(), var3.getZ());
         Vec3d var7 = new Vec3d;
         I[57 ^ 75].length();
         I[60 ^ 79].length();
         double var8 = (double)((float)(var5 >> (93 ^ 77) & 15L) / 15.0F);
         I[225 ^ 149].length();
         I[71 ^ 50].length();
         var8 = (var8 - 0.5D) * 0.5D;
         double var10003;
         if (var4 == Block.EnumOffsetType.XYZ) {
            var10003 = (double)((float)(var5 >> (112 ^ 100) & 15L) / 15.0F);
            I[235 ^ 157].length();
            var10003 = (var10003 - 1.0D) * 0.2D;
            "".length();
            if (0 >= 3) {
               throw null;
            }
         } else {
            var10003 = 0.0D;
         }

         double var10004 = (double)((float)(var5 >> (101 ^ 125) & 15L) / 15.0F);
         I[202 ^ 189].length();
         I[93 ^ 37].length();
         var7.<init>(var8, var10003, (var10004 - 0.5D) * 0.5D);
         return var7;
      }
   }

   public void onLanded(World var1, Entity var2) {
      var2.motionY = 0.0D;
   }

   public Vec3d modifyAcceleration(World var1, BlockPos var2, Entity var3, Vec3d var4) {
      return var4;
   }

   public int quantityDropped(Random var1) {
      return " ".length();
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(this);
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[119 ^ 42];
      String var10001 = I[59 ^ 101];
      String var10002 = I[222 ^ 129];
      var10001 = I[124 ^ 28];
      I[103 ^ 6].length();
      I[247 ^ 149].length();
      I[223 ^ 188].length();
      I[78 ^ 42].length();
      var2.add(new ItemStack(this));
      I[83 ^ 54].length();
   }

   /** @deprecated */
   @Deprecated
   public int getLightValue(IBlockState var1) {
      return this.lightValue;
   }

   public final void dropBlockAsItem(World var1, BlockPos var2, IBlockState var3, int var4) {
      this.dropBlockAsItemWithChance(var1, var2, var3, 1.0F, var4);
   }

   /** @deprecated */
   @Deprecated
   public boolean getUseNeighborBrightness(IBlockState var1) {
      return this.useNeighborBrightness;
   }

   public static void spawnAsEntity(World var0, BlockPos var1, ItemStack var2) {
      String var10000 = I[128 ^ 167];
      String var10001 = I[118 ^ 94];
      String var10002 = I[169 ^ 128];
      var10001 = I[126 ^ 84];
      if (!var0.isRemote && !var2.isEmpty() && var0.getGameRules().getBoolean(I[6 ^ 45])) {
         float var3 = 0.5F;
         double var4 = (double)(var0.rand.nextFloat() * 0.5F) + 0.25D;
         double var6 = (double)(var0.rand.nextFloat() * 0.5F) + 0.25D;
         double var8 = (double)(var0.rand.nextFloat() * 0.5F) + 0.25D;
         I[162 ^ 142].length();
         EntityItem var10 = new EntityItem(var0, (double)var1.getX() + var4, (double)var1.getY() + var6, (double)var1.getZ() + var8, var2);
         var10.setDefaultPickupDelay();
         var0.spawnEntityInWorld(var10);
         I[20 ^ 57].length();
         I[236 ^ 194].length();
      }

   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[6 ^ 81];
      String var10001 = I[252 ^ 164];
      String var10002 = I[218 ^ 131];
      var10001 = I[243 ^ 169];
      I[218 ^ 129].length();
      I[27 ^ 71].length();
      return new ItemStack(Item.getItemFromBlock(this), " ".length(), this.damageDropped(var3));
   }

   /** @deprecated */
   @Deprecated
   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return "".length();
   }

   protected Block setLightOpacity(int var1) {
      this.lightOpacity = var1;
      return this;
   }

   protected boolean canSilkHarvest() {
      int var10000;
      if (this.getDefaultState().isFullCube() && !this.isBlockContainer) {
         var10000 = " ".length();
         "".length();
         if (3 == 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public boolean canPlaceBlockOnSide(World var1, BlockPos var2, EnumFacing var3) {
      return this.canPlaceBlockAt(var1, var2);
   }

   private static void registerBlock(int var0, ResourceLocation var1, Block var2) {
      REGISTRY.register(var0, var1, var2);
   }

   /** @deprecated */
   @Deprecated
   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return this.blockMapColor;
   }

   /** @deprecated */
   @Deprecated
   public EnumPushReaction getMobilityFlag(IBlockState var1) {
      return this.blockMaterial.getMobilityFlag();
   }

   /** @deprecated */
   @Deprecated
   public float getBlockHardness(IBlockState var1, World var2, BlockPos var3) {
      return this.blockHardness;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
   }

   /** @deprecated */
   @Deprecated
   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      addCollisionBoxToList(var3, var4, var5, var1.getCollisionBoundingBox(var2, var3));
   }

   public static int getIdFromBlock(Block var0) {
      return REGISTRY.getIDForObject(var0);
   }

   public float getExplosionResistance(Entity var1) {
      return this.blockResistance / 5.0F;
   }

   public boolean isAssociatedBlock(Block var1) {
      int var10000;
      if (this == var1) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public String getLocalizedName() {
      String var10000 = I[194 ^ 139];
      String var10001 = I[110 ^ 36];
      String var10002 = I[2 ^ 73];
      var10001 = I[2 ^ 78];
      I[41 ^ 100].length();
      I[20 ^ 90].length();
      I[244 ^ 187].length();
      return I18n.translateToLocal(this.getUnlocalizedName() + I[226 ^ 178]);
   }

   public Block setCreativeTab(CreativeTabs var1) {
      this.displayOnCreativeTab = var1;
      return this;
   }

   /** @deprecated */
   @Deprecated
   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return FULL_BLOCK_AABB;
   }

   /** @deprecated */
   @Deprecated
   public AxisAlignedBB getSelectedBoundingBox(IBlockState var1, World var2, BlockPos var3) {
      return var1.getBoundingBox(var2, var3).offset(var3);
   }

   @Nullable
   protected RayTraceResult rayTrace(BlockPos var1, Vec3d var2, Vec3d var3, AxisAlignedBB var4) {
      String var10000 = I[248 ^ 193];
      String var10001 = I[20 ^ 46];
      String var10002 = I[153 ^ 162];
      var10001 = I[35 ^ 31];
      Vec3d var5 = var2.subtract((double)var1.getX(), (double)var1.getY(), (double)var1.getZ());
      Vec3d var6 = var3.subtract((double)var1.getX(), (double)var1.getY(), (double)var1.getZ());
      RayTraceResult var7 = var4.calculateIntercept(var5, var6);
      RayTraceResult var8;
      if (var7 == null) {
         var8 = null;
         "".length();
         if (1 == -1) {
            throw null;
         }
      } else {
         I[41 ^ 20].length();
         I[41 ^ 23].length();
         I[86 ^ 105].length();
         I[24 ^ 88].length();
         var8 = new RayTraceResult(var7.hitVec.add((double)var1.getX(), (double)var1.getY(), (double)var1.getZ()), var7.sideHit, var1);
      }

      return var8;
   }

   public Block.EnumOffsetType getOffsetType() {
      return Block.EnumOffsetType.NONE;
   }

   protected final void setDefaultState(IBlockState var1) {
      this.defaultBlockState = var1;
   }

   public int quantityDroppedWithBonus(int var1, Random var2) {
      return this.quantityDropped(var2);
   }

   /** @deprecated */
   @Deprecated
   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean isCollidable() {
      return (boolean)" ".length();
   }

   public void fillWithRain(World var1, BlockPos var2) {
   }

   protected static boolean func_193382_c(Block var0) {
      int var10000;
      if (!func_193384_b(var0) && var0 != Blocks.PISTON && var0 != Blocks.STICKY_PISTON && var0 != Blocks.PISTON_HEAD) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   static {
      I();
      AIR_ID = new ResourceLocation(I[459 + 1583 - 1876 + 2112]);
      REGISTRY = new RegistryNamespacedDefaultedByKey(AIR_ID);
      BLOCK_STATE_IDS = new ObjectIntIdentityMap();
      FULL_BLOCK_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      NULL_AABB = null;
   }

   protected Block setHardness(float var1) {
      this.blockHardness = var1;
      if (this.blockResistance < var1 * 5.0F) {
         this.blockResistance = var1 * 5.0F;
      }

      return this;
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
   }

   public boolean getEnableStats() {
      return this.enableStats;
   }

   /** @deprecated */
   @Deprecated
   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.SOLID;
   }

   protected Block(Material var1) {
      this(var1, var1.getMaterialMapColor());
   }

   protected Block setTickRandomly(boolean var1) {
      this.needsRandomTick = var1;
      return this;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.SOLID;
   }

   /** @deprecated */
   @Nullable
   @Deprecated
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return var1.getBoundingBox(var2, var3);
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      var2.addStat(StatList.getBlockStats(this));
      var2.addExhaustion(0.005F);
      if (this.canSilkHarvest() && EnchantmentHelper.getEnchantmentLevel(Enchantments.SILK_TOUCH, var6) > 0) {
         ItemStack var8 = this.getSilkTouchDrop(var4);
         spawnAsEntity(var1, var3, var8);
         "".length();
         if (-1 < -1) {
            throw null;
         }
      } else {
         int var7 = EnchantmentHelper.getEnchantmentLevel(Enchantments.FORTUNE, var6);
         this.dropBlockAsItem(var1, var3, var4, var7);
      }

   }

   /** @deprecated */
   @Deprecated
   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   /** @deprecated */
   @Deprecated
   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return var1;
   }

   /** @deprecated */
   @Deprecated
   public boolean isTranslucent(IBlockState var1) {
      return this.translucent;
   }

   public int getMetaFromState(IBlockState var1) {
      String var10000 = I[25 ^ 17];
      String var10001 = I[183 ^ 190];
      String var10002 = I[55 ^ 61];
      var10001 = I[14 ^ 5];
      var10000 = I[38 ^ 42];
      var10001 = I[179 ^ 190];
      var10002 = I[72 ^ 70];
      var10001 = I[166 ^ 169];
      if (var1.getPropertyNames().isEmpty()) {
         return "".length();
      } else {
         I[57 ^ 41].length();
         I[140 ^ 157].length();
         I[91 ^ 73].length();
         I[182 ^ 165].length();
         I[90 ^ 78].length();
         IllegalArgumentException var2 = new IllegalArgumentException(I[147 ^ 134] + var1 + I[4 ^ 18]);
         I[171 ^ 188].length();
         I[115 ^ 107].length();
         I[130 ^ 155].length();
         throw var2;
      }
   }

   /** @deprecated */
   @Deprecated
   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      AxisAlignedBB var5 = var1.getBoundingBox(var2, var3);
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var4.ordinal()]) {
      case 1:
         if (var5.minY > 0.0D) {
            return (boolean)" ".length();
         }
         break;
      case 2:
         if (var5.maxY < 1.0D) {
            return (boolean)" ".length();
         }
         break;
      case 3:
         if (var5.minZ > 0.0D) {
            return (boolean)" ".length();
         }
         break;
      case 4:
         if (var5.maxZ < 1.0D) {
            return (boolean)" ".length();
         }
         break;
      case 5:
         if (var5.minX > 0.0D) {
            return (boolean)" ".length();
         }
         break;
      case 6:
         if (var5.maxX < 1.0D) {
            return (boolean)" ".length();
         }
      }

      int var10000;
      if (!var2.getBlockState(var3.offset(var4)).isOpaqueCube()) {
         var10000 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 4);

      throw null;
   }

   public boolean canDropFromExplosion(Explosion var1) {
      return (boolean)" ".length();
   }

   public String getUnlocalizedName() {
      String var10000 = I[117 ^ 36];
      String var10001 = I[64 ^ 18];
      String var10002 = I[4 ^ 87];
      var10001 = I[240 ^ 164];
      I[199 ^ 146].length();
      return I[87 ^ 1] + this.unlocalizedName;
   }

   public Block setUnlocalizedName(String var1) {
      this.unlocalizedName = var1;
      return this;
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      return var1.getBlockState(var2).getBlock().blockMaterial.isReplaceable();
   }

   public BlockStateContainer getBlockState() {
      return this.blockState;
   }

   protected Block disableStats() {
      this.enableStats = (boolean)"".length();
      return this;
   }

   public int damageDropped(IBlockState var1) {
      return "".length();
   }

   protected static void addCollisionBoxToList(BlockPos var0, AxisAlignedBB var1, List<AxisAlignedBB> var2, @Nullable AxisAlignedBB var3) {
      if (var3 != NULL_AABB) {
         AxisAlignedBB var4 = var3.offset(var0);
         if (var1.intersectsWith(var4)) {
            var2.add(var4);
            I[105 ^ 119].length();
         }
      }

   }

   public SoundType getSoundType() {
      return this.blockSoundType;
   }

   protected Block setResistance(float var1) {
      this.blockResistance = var1 * 3.0F;
      return this;
   }

   protected Block setBlockUnbreakable() {
      this.setHardness(-1.0F);
      I[3 ^ 25].length();
      I[164 ^ 191].length();
      I[56 ^ 36].length();
      I[80 ^ 77].length();
      return this;
   }

   @Nullable
   public static Block getBlockFromName(String var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[92 ^ 88].length();
      I[90 ^ 95].length();
      I[125 ^ 123].length();
      I[113 ^ 118].length();
      ResourceLocation var1 = new ResourceLocation(var0);
      if (REGISTRY.containsKey(var1)) {
         return (Block)REGISTRY.getObject(var1);
      } else {
         try {
            return (Block)REGISTRY.getObjectById(Integer.parseInt(var0));
         } catch (NumberFormatException var3) {
            return null;
         }
      }
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
   }

   public void onBlockDestroyedByExplosion(World var1, BlockPos var2, Explosion var3) {
   }

   /** @deprecated */
   @Deprecated
   public boolean func_190946_v(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      int var10000;
      if (!this.blockMaterial.blocksMovement()) {
         var10000 = " ".length();
         "".length();
         if (2 >= 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   /** @deprecated */
   @Deprecated
   public int getLightOpacity(IBlockState var1) {
      return this.lightOpacity;
   }

   /** @deprecated */
   @Deprecated
   public boolean isNormalCube(IBlockState var1) {
      int var10000;
      if (var1.getMaterial().isOpaque() && var1.isFullCube() && !var1.canProvidePower()) {
         var10000 = " ".length();
         "".length();
         if (4 < 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   /** @deprecated */
   @Deprecated
   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return "".length();
   }

   public boolean canCollideCheck(IBlockState var1, boolean var2) {
      Iterator var3 = ((List)Objects.requireNonNull(NoInteract.getRightClickableBlocks())).iterator();

      while(var3.hasNext()) {
         Block var4 = (Block)var3.next();
         if (var1.getBlock() == var4) {
            if (ZewSide.instance.featureManager.getFeature(NoInteract.class).isEnabled()) {
               return (boolean)"".length();
            }

            "".length();
            if (0 >= 3) {
               throw null;
            }
         }
      }

      return this.isCollidable();
   }

   /** @deprecated */
   @Deprecated
   @Nullable
   public RayTraceResult collisionRayTrace(IBlockState var1, World var2, BlockPos var3, Vec3d var4, Vec3d var5) {
      return this.rayTrace(var3, var4, var5, var1.getBoundingBox(var2, var3));
   }

   public boolean requiresUpdates() {
      return (boolean)" ".length();
   }

   public boolean getTickRandomly() {
      return this.needsRandomTick;
   }

   /** @deprecated */
   @Deprecated
   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
   }

   public void onBlockHarvested(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[44 ^ 74];
      String var10001 = I[195 ^ 164];
      String var10002 = I[197 ^ 173];
      var10001 = I[202 ^ 163];
      I[9 ^ 99].length();
      I[75 ^ 32].length();
      I[107 ^ 7].length();
      I[239 ^ 130].length();
      return new BlockStateContainer(this, new IProperty["".length()]);
   }

   /** @deprecated */
   @Deprecated
   public boolean isFullyOpaque(IBlockState var1) {
      int var10000;
      if (var1.getMaterial().isOpaque() && var1.isFullCube()) {
         var10000 = " ".length();
         "".length();
         if (3 == -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static enum EnumOffsetType {
      // $FF: synthetic field
      XZ,
      // $FF: synthetic field
      NONE,
      // $FF: synthetic field
      XYZ;

      // $FF: synthetic field
      private static final String[] I;

      static {
         I();
         NONE = new Block.EnumOffsetType(I["".length()], "".length());
         XZ = new Block.EnumOffsetType(I[" ".length()], " ".length());
         XYZ = new Block.EnumOffsetType(I["  ".length()], "  ".length());
         Block.EnumOffsetType[] var10000 = new Block.EnumOffsetType["   ".length()];
         var10000["".length()] = NONE;
         var10000[" ".length()] = XZ;
         var10000["  ".length()] = XYZ;
      }

      private static void I() {
         I = new String["   ".length()];
         I["".length()] = I("\t\u0007\u000b4", "GHEqj");
         I[" ".length()] = I(",\r", "tWadt");
         I["  ".length()] = I("\u00123\u001f", "JjEbs");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 != -1);

         throw null;
      }
   }
}

package net.minecraft.block;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockRedstoneWire extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockRedstoneWire.EnumAttachPosition> EAST;
   // $FF: synthetic field
   public static final PropertyEnum<BlockRedstoneWire.EnumAttachPosition> SOUTH;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] REDSTONE_WIRE_AABB;
   // $FF: synthetic field
   public static final PropertyEnum<BlockRedstoneWire.EnumAttachPosition> NORTH;
   // $FF: synthetic field
   private boolean canProvidePower = " ".length();
   // $FF: synthetic field
   public static final PropertyEnum<BlockRedstoneWire.EnumAttachPosition> WEST;
   // $FF: synthetic field
   public static final PropertyInteger POWER;
   // $FF: synthetic field
   private final Set<BlockPos> blocksNeedingUpdate = Sets.newHashSet();

   protected BlockStateContainer createBlockState() {
      String var10000 = I[64 ^ 118];
      String var10001 = I[139 ^ 188];
      String var10002 = I[54 ^ 14];
      var10001 = I[161 ^ 152];
      var10000 = I[155 ^ 161];
      var10001 = I[168 ^ 147];
      var10002 = I[188 ^ 128];
      var10001 = I[152 ^ 165];
      var10000 = I[63 ^ 1];
      var10001 = I[0 ^ 63];
      var10002 = I[213 ^ 149];
      var10001 = I[109 ^ 44];
      var10000 = I[30 ^ 92];
      var10001 = I[255 ^ 188];
      var10002 = I[219 ^ 159];
      var10001 = I[231 ^ 162];
      var10000 = I[112 ^ 54];
      var10001 = I[49 ^ 118];
      var10002 = I[20 ^ 92];
      var10001 = I[214 ^ 159];
      var10000 = I[12 ^ 70];
      var10001 = I[45 ^ 102];
      var10002 = I[112 ^ 60];
      var10001 = I[74 ^ 7];
      I[121 ^ 55].length();
      I[223 ^ 144].length();
      I[22 ^ 70].length();
      IProperty[] var10003 = new IProperty[183 ^ 178];
      I[123 ^ 42].length();
      I[110 ^ 60].length();
      I[45 ^ 126].length();
      var10003["".length()] = NORTH;
      I[10 ^ 94].length();
      I[116 ^ 33].length();
      var10003[" ".length()] = EAST;
      I[193 ^ 151].length();
      I[251 ^ 172].length();
      I[31 ^ 71].length();
      var10003["  ".length()] = SOUTH;
      I[255 ^ 166].length();
      I[92 ^ 6].length();
      I[29 ^ 70].length();
      I[101 ^ 57].length();
      I[55 ^ 106].length();
      var10003["   ".length()] = WEST;
      I[105 ^ 55].length();
      var10003[81 ^ 85] = POWER;
      return new BlockStateContainer(this, var10003);
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         this.updateSurroundingRedstone(var1, var2, var3);
         I[144 ^ 133].length();
         I[145 ^ 135].length();
         Iterator var4 = EnumFacing.Plane.VERTICAL.iterator();

         EnumFacing var5;
         while(var4.hasNext()) {
            var5 = (EnumFacing)var4.next();
            var1.notifyNeighborsOfStateChange(var2.offset(var5), this, (boolean)"".length());
            "".length();
            if (3 < -1) {
               throw null;
            }
         }

         var4 = EnumFacing.Plane.HORIZONTAL.iterator();

         while(var4.hasNext()) {
            var5 = (EnumFacing)var4.next();
            this.notifyWireNeighborsOfStateChange(var1, var2.offset(var5));
            "".length();
            if (1 >= 3) {
               throw null;
            }
         }

         var4 = EnumFacing.Plane.HORIZONTAL.iterator();

         while(var4.hasNext()) {
            var5 = (EnumFacing)var4.next();
            BlockPos var6 = var2.offset(var5);
            if (var1.getBlockState(var6).isNormalCube()) {
               this.notifyWireNeighborsOfStateChange(var1, var6.up());
               "".length();
               if (3 <= -1) {
                  throw null;
               }
            } else {
               this.notifyWireNeighborsOfStateChange(var1, var6.down());
            }

            "".length();
            if (4 < 4) {
               throw null;
            }
         }
      }

   }

   private void notifyWireNeighborsOfStateChange(World var1, BlockPos var2) {
      if (var1.getBlockState(var2).getBlock() == this) {
         var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
         EnumFacing[] var3 = EnumFacing.values();
         int var4 = var3.length;
         int var5 = "".length();

         while(var5 < var4) {
            EnumFacing var6 = var3[var5];
            var1.notifyNeighborsOfStateChange(var2.offset(var6), this, (boolean)"".length());
            ++var5;
            "".length();
            if (1 <= 0) {
               throw null;
            }
         }
      }

   }

   static {
      I();
      NORTH = PropertyEnum.create(I[221 ^ 130], BlockRedstoneWire.EnumAttachPosition.class);
      EAST = PropertyEnum.create(I[106 ^ 10], BlockRedstoneWire.EnumAttachPosition.class);
      SOUTH = PropertyEnum.create(I[74 ^ 43], BlockRedstoneWire.EnumAttachPosition.class);
      WEST = PropertyEnum.create(I[14 ^ 108], BlockRedstoneWire.EnumAttachPosition.class);
      POWER = PropertyInteger.create(I[37 ^ 70], "".length(), 147 ^ 156);
      AxisAlignedBB[] var10000 = new AxisAlignedBB[28 ^ 12];
      var10000["".length()] = new AxisAlignedBB(0.1875D, 0.0D, 0.1875D, 0.8125D, 0.0625D, 0.8125D);
      var10000[" ".length()] = new AxisAlignedBB(0.1875D, 0.0D, 0.1875D, 0.8125D, 0.0625D, 1.0D);
      var10000["  ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.1875D, 0.8125D, 0.0625D, 0.8125D);
      var10000["   ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.1875D, 0.8125D, 0.0625D, 1.0D);
      var10000[33 ^ 37] = new AxisAlignedBB(0.1875D, 0.0D, 0.0D, 0.8125D, 0.0625D, 0.8125D);
      var10000[90 ^ 95] = new AxisAlignedBB(0.1875D, 0.0D, 0.0D, 0.8125D, 0.0625D, 1.0D);
      var10000[185 ^ 191] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.8125D, 0.0625D, 0.8125D);
      var10000[112 ^ 119] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.8125D, 0.0625D, 1.0D);
      var10000[31 ^ 23] = new AxisAlignedBB(0.1875D, 0.0D, 0.1875D, 1.0D, 0.0625D, 0.8125D);
      var10000[184 ^ 177] = new AxisAlignedBB(0.1875D, 0.0D, 0.1875D, 1.0D, 0.0625D, 1.0D);
      var10000[202 ^ 192] = new AxisAlignedBB(0.0D, 0.0D, 0.1875D, 1.0D, 0.0625D, 0.8125D);
      var10000[38 ^ 45] = new AxisAlignedBB(0.0D, 0.0D, 0.1875D, 1.0D, 0.0625D, 1.0D);
      var10000[142 ^ 130] = new AxisAlignedBB(0.1875D, 0.0D, 0.0D, 1.0D, 0.0625D, 0.8125D);
      var10000[53 ^ 56] = new AxisAlignedBB(0.1875D, 0.0D, 0.0D, 1.0D, 0.0625D, 1.0D);
      var10000[103 ^ 105] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.0625D, 0.8125D);
      var10000[75 ^ 68] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.0625D, 1.0D);
      REDSTONE_WIRE_AABB = var10000;
   }

   public static int colorMultiplier(int var0) {
      float var1 = (float)var0 / 15.0F;
      float var2 = var1 * 0.6F + 0.4F;
      if (var0 == 0) {
         var2 = 0.3F;
      }

      float var10000 = var1 * var1 * 0.7F;
      I[118 ^ 84].length();
      I[137 ^ 170].length();
      float var3 = var10000 - 0.5F;
      var10000 = var1 * var1 * 0.6F;
      I[108 ^ 72].length();
      float var4 = var10000 - 0.7F;
      if (var3 < 0.0F) {
         var3 = 0.0F;
      }

      if (var4 < 0.0F) {
         var4 = 0.0F;
      }

      int var5 = MathHelper.clamp((int)(var2 * 255.0F), "".length(), 23 + 180 - 190 + 242);
      int var6 = MathHelper.clamp((int)(var3 * 255.0F), "".length(), 17 + 150 - 100 + 188);
      int var7 = MathHelper.clamp((int)(var4 * 255.0F), "".length(), 67 + 206 - 209 + 191);
      return -(4041374 + 4371110 - 4613023 + 12977755) | var5 << (158 ^ 142) | var6 << (74 ^ 66) | var7;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(NORTH));
      case 2:
         return var1.withProperty(EAST, var1.getValue(WEST)).withProperty(WEST, var1.getValue(EAST));
      default:
         return super.withMirror(var1, var2);
      }
   }

   private boolean isPowerSourceAt(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
      BlockPos var4 = var2.offset(var3);
      IBlockState var5 = var1.getBlockState(var4);
      boolean var6 = var5.isNormalCube();
      boolean var7 = var1.getBlockState(var2.up()).isNormalCube();
      if (!var7 && var6 && canConnectUpwardsTo(var1, var4.up())) {
         return (boolean)" ".length();
      } else if (canConnectTo(var5, var3)) {
         return (boolean)" ".length();
      } else if (var5.getBlock() == Blocks.POWERED_REPEATER && var5.getValue(BlockRedstoneDiode.FACING) == var3) {
         return (boolean)" ".length();
      } else {
         int var10000;
         if (!var6 && canConnectUpwardsTo(var1, var4.down())) {
            var10000 = " ".length();
            "".length();
            if (0 >= 1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   private IBlockState updateSurroundingRedstone(World var1, BlockPos var2, IBlockState var3) {
      var3 = this.calculateCurrentChanges(var1, var2, var2, var3);
      ArrayList var4 = Lists.newArrayList(this.blocksNeedingUpdate);
      this.blocksNeedingUpdate.clear();
      Iterator var5 = var4.iterator();

      do {
         if (!var5.hasNext()) {
            return var3;
         }

         BlockPos var6 = (BlockPos)var5.next();
         var1.notifyNeighborsOfStateChange(var6, this, (boolean)"".length());
         "".length();
      } while(4 == 4);

      throw null;
   }

   private IBlockState calculateCurrentChanges(World var1, BlockPos var2, BlockPos var3, IBlockState var4) {
      IBlockState var5 = var4;
      int var6 = (Integer)var4.getValue(POWER);
      int var7 = "".length();
      var7 = this.getMaxCurrentStrength(var1, var3, var7);
      this.canProvidePower = (boolean)"".length();
      int var8 = var1.isBlockIndirectlyGettingPowered(var2);
      this.canProvidePower = (boolean)" ".length();
      int var10002;
      if (var8 > 0) {
         var10002 = " ".length();
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         if (var8 > var7 - var10002) {
            var7 = var8;
         }
      }

      int var9 = "".length();
      Iterator var10 = EnumFacing.Plane.HORIZONTAL.iterator();

      do {
         if (!var10.hasNext()) {
            if (var9 > var7) {
               int var10001 = " ".length();
               I["   ".length()].length();
               I[15 ^ 11].length();
               I[15 ^ 10].length();
               I[191 ^ 185].length();
               var7 = var9 - var10001;
               "".length();
               if (3 <= -1) {
                  throw null;
               }
            } else if (var7 > 0) {
               --var7;
               "".length();
               if (4 <= 1) {
                  throw null;
               }
            } else {
               var7 = "".length();
            }

            var10002 = " ".length();
            I[108 ^ 107].length();
            I[17 ^ 25].length();
            if (var8 > var7 - var10002) {
               var7 = var8;
            }

            if (var6 != var7) {
               var4 = var4.withProperty(POWER, var7);
               if (var1.getBlockState(var2) == var5) {
                  var1.setBlockState(var2, var4, "  ".length());
                  I[207 ^ 198].length();
                  I[129 ^ 139].length();
                  I[93 ^ 86].length();
                  I[191 ^ 179].length();
               }

               this.blocksNeedingUpdate.add(var2);
               I[54 ^ 59].length();
               I[191 ^ 177].length();
               I[32 ^ 47].length();
               I[53 ^ 37].length();
               EnumFacing[] var14 = EnumFacing.values();
               int var15 = var14.length;
               int var16 = "".length();

               while(var16 < var15) {
                  EnumFacing var17 = var14[var16];
                  this.blocksNeedingUpdate.add(var2.offset(var17));
                  I[4 ^ 21].length();
                  I[73 ^ 91].length();
                  I[8 ^ 27].length();
                  I[141 ^ 153].length();
                  ++var16;
                  "".length();
                  if (3 <= 0) {
                     throw null;
                  }
               }
            }

            return var4;
         }

         EnumFacing var11 = (EnumFacing)var10.next();
         BlockPos var12 = var2.offset(var11);
         int var10000;
         if (var12.getX() == var3.getX() && var12.getZ() == var3.getZ()) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (0 == 3) {
               throw null;
            }
         }

         int var13 = var10000;
         if (var13 != 0) {
            var9 = this.getMaxCurrentStrength(var1, var12, var9);
         }

         if (var1.getBlockState(var12).isNormalCube() && !var1.getBlockState(var2.up()).isNormalCube()) {
            if (var13 != 0 && var2.getY() >= var3.getY()) {
               var9 = this.getMaxCurrentStrength(var1, var12.up(), var9);
               "".length();
               if (false) {
                  throw null;
               }
            }
         } else if (!var1.getBlockState(var12).isNormalCube() && var13 != 0 && var2.getY() <= var3.getY()) {
            var9 = this.getMaxCurrentStrength(var1, var12.down(), var9);
         }

         "".length();
      } while(2 > 0);

      throw null;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(EAST, var1.getValue(WEST)).withProperty(SOUTH, var1.getValue(NORTH)).withProperty(WEST, var1.getValue(EAST));
      case 2:
         return var1.withProperty(NORTH, var1.getValue(EAST)).withProperty(EAST, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(WEST)).withProperty(WEST, var1.getValue(NORTH));
      case 3:
         return var1.withProperty(NORTH, var1.getValue(WEST)).withProperty(EAST, var1.getValue(NORTH)).withProperty(SOUTH, var1.getValue(EAST)).withProperty(WEST, var1.getValue(SOUTH));
      default:
         return var1;
      }
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      var1 = var1.withProperty(WEST, this.getAttachPosition(var2, var3, EnumFacing.WEST));
      var1 = var1.withProperty(EAST, this.getAttachPosition(var2, var3, EnumFacing.EAST));
      var1 = var1.withProperty(NORTH, this.getAttachPosition(var2, var3, EnumFacing.NORTH));
      var1 = var1.withProperty(SOUTH, this.getAttachPosition(var2, var3, EnumFacing.SOUTH));
      return var1;
   }

   private int getMaxCurrentStrength(World var1, BlockPos var2, int var3) {
      if (var1.getBlockState(var2).getBlock() != this) {
         return var3;
      } else {
         int var4 = (Integer)var1.getBlockState(var2).getValue(POWER);
         int var10000;
         if (var4 > var3) {
            var10000 = var4;
            "".length();
            if (1 >= 3) {
               throw null;
            }
         } else {
            var10000 = var3;
         }

         return var10000;
      }
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (!var1.getBlockState(var2.down()).isFullyOpaque() && var1.getBlockState(var2.down()).getBlock() != Blocks.GLOWSTONE) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (2 <= 0) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public boolean canProvidePower(IBlockState var1) {
      return this.canProvidePower;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(POWER);
   }

   protected static boolean canConnectTo(IBlockState var0, @Nullable EnumFacing var1) {
      Block var2 = var0.getBlock();
      if (var2 == Blocks.REDSTONE_WIRE) {
         return (boolean)" ".length();
      } else {
         int var10000;
         if (Blocks.UNPOWERED_REPEATER.isSameDiode(var0)) {
            EnumFacing var3 = (EnumFacing)var0.getValue(BlockRedstoneRepeater.FACING);
            if (var3 != var1 && var3.getOpposite() != var1) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (1 <= 0) {
                  throw null;
               }
            }

            return (boolean)var10000;
         } else if (Blocks.OBSERVER == var0.getBlock()) {
            if (var1 == var0.getValue(BlockObserver.FACING)) {
               var10000 = " ".length();
               "".length();
               if (0 == 4) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         } else {
            if (var0.canProvidePower() && var1 != null) {
               var10000 = " ".length();
               "".length();
               if (2 <= 0) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      }
   }

   private BlockRedstoneWire.EnumAttachPosition getAttachPosition(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
      BlockPos var4 = var2.offset(var3);
      IBlockState var5 = var1.getBlockState(var2.offset(var3));
      if (!canConnectTo(var1.getBlockState(var4), var3) && (var5.isNormalCube() || !canConnectUpwardsTo(var1.getBlockState(var4.down())))) {
         IBlockState var6 = var1.getBlockState(var2.up());
         if (!var6.isNormalCube()) {
            int var10000;
            if (!var1.getBlockState(var4).isFullyOpaque() && var1.getBlockState(var4).getBlock() != Blocks.GLOWSTONE) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (0 >= 3) {
                  throw null;
               }
            }

            int var7 = var10000;
            if (var7 != 0 && canConnectUpwardsTo(var1.getBlockState(var4.up()))) {
               if (var5.isBlockNormalCube()) {
                  return BlockRedstoneWire.EnumAttachPosition.UP;
               }

               return BlockRedstoneWire.EnumAttachPosition.SIDE;
            }
         }

         return BlockRedstoneWire.EnumAttachPosition.NONE;
      } else {
         return BlockRedstoneWire.EnumAttachPosition.SIDE;
      }
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote) {
         if (this.canPlaceBlockAt(var2, var3)) {
            this.updateSurroundingRedstone(var2, var3, var1);
            I[99 ^ 121].length();
            I[11 ^ 16].length();
            I[34 ^ 62].length();
            "".length();
            if (-1 >= 3) {
               throw null;
            }
         } else {
            this.dropBlockAsItem(var2, var3, var1, "".length());
            var2.setBlockToAir(var3);
            I[20 ^ 9].length();
         }
      }

   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.REDSTONE;
   }

   private static int getAABBIndex(IBlockState var0) {
      int var1 = "".length();
      int var10000;
      if (var0.getValue(NORTH) != BlockRedstoneWire.EnumAttachPosition.NONE) {
         var10000 = " ".length();
         "".length();
         if (3 <= 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var2 = var10000;
      if (var0.getValue(EAST) != BlockRedstoneWire.EnumAttachPosition.NONE) {
         var10000 = " ".length();
         "".length();
         if (0 >= 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var3 = var10000;
      if (var0.getValue(SOUTH) != BlockRedstoneWire.EnumAttachPosition.NONE) {
         var10000 = " ".length();
         "".length();
         if (0 <= -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var4 = var10000;
      if (var0.getValue(WEST) != BlockRedstoneWire.EnumAttachPosition.NONE) {
         var10000 = " ".length();
         "".length();
         if (3 <= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var5 = var10000;
      if (var2 != 0 || var4 != 0 && var2 == 0 && var3 == 0 && var5 == 0) {
         var1 |= " ".length() << EnumFacing.NORTH.getHorizontalIndex();
      }

      if (var3 != 0 || var5 != 0 && var2 == 0 && var3 == 0 && var4 == 0) {
         var1 |= " ".length() << EnumFacing.EAST.getHorizontalIndex();
      }

      if (var4 != 0 || var2 != 0 && var3 == 0 && var4 == 0 && var5 == 0) {
         var1 |= " ".length() << EnumFacing.SOUTH.getHorizontalIndex();
      }

      if (var5 != 0 || var3 != 0 && var2 == 0 && var4 == 0 && var5 == 0) {
         var1 |= " ".length() << EnumFacing.WEST.getHorizontalIndex();
      }

      return var1;
   }

   public BlockRedstoneWire() {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(NORTH, BlockRedstoneWire.EnumAttachPosition.NONE).withProperty(EAST, BlockRedstoneWire.EnumAttachPosition.NONE).withProperty(SOUTH, BlockRedstoneWire.EnumAttachPosition.NONE).withProperty(WEST, BlockRedstoneWire.EnumAttachPosition.NONE).withProperty(POWER, "".length()));
   }

   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if (!this.canProvidePower) {
         var10000 = "".length();
         "".length();
         if (3 == -1) {
            throw null;
         }
      } else {
         var10000 = var1.getWeakPower(var2, var3, var4);
      }

      return var10000;
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      super.breakBlock(var1, var2, var3);
      if (!var1.isRemote) {
         EnumFacing[] var4 = EnumFacing.values();
         int var5 = var4.length;
         int var6 = "".length();

         while(var6 < var5) {
            EnumFacing var7 = var4[var6];
            var1.notifyNeighborsOfStateChange(var2.offset(var7), this, (boolean)"".length());
            ++var6;
            "".length();
            if (0 >= 3) {
               throw null;
            }
         }

         this.updateSurroundingRedstone(var1, var2, var3);
         I[83 ^ 68].length();
         I[84 ^ 76].length();
         I[10 ^ 19].length();
         Iterator var8 = EnumFacing.Plane.HORIZONTAL.iterator();

         EnumFacing var9;
         while(var8.hasNext()) {
            var9 = (EnumFacing)var8.next();
            this.notifyWireNeighborsOfStateChange(var1, var2.offset(var9));
            "".length();
            if (3 == 4) {
               throw null;
            }
         }

         var8 = EnumFacing.Plane.HORIZONTAL.iterator();

         while(var8.hasNext()) {
            var9 = (EnumFacing)var8.next();
            BlockPos var10 = var2.offset(var9);
            if (var1.getBlockState(var10).isNormalCube()) {
               this.notifyWireNeighborsOfStateChange(var1, var10.up());
               "".length();
               if (0 < 0) {
                  throw null;
               }
            } else {
               this.notifyWireNeighborsOfStateChange(var1, var10.down());
            }

            "".length();
            if (2 != 2) {
               throw null;
            }
         }
      }

   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[86 ^ 103];
      String var10001 = I[145 ^ 163];
      String var10002 = I[59 ^ 8];
      var10001 = I[145 ^ 165];
      I[126 ^ 75].length();
      return new ItemStack(Items.REDSTONE);
   }

   private static void I() {
      I = new String[102 ^ 2];
      I["".length()] = I("冡", "fvaqU");
      I[" ".length()] = I("吤働", "tYImR");
      I["  ".length()] = I("柚", "UNoBo");
      I["   ".length()] = I("僵旲怴志惓", "lXEXJ");
      I[187 ^ 191] = I("泍妍毲岻傀", "WpYEQ");
      I[9 ^ 12] = I("氇佣", "bZYeA");
      I[3 ^ 5] = I("果擡屘", "DikVj");
      I[46 ^ 41] = I("槄潾圪沖", "IIIUE");
      I[206 ^ 198] = I("悡", "cZEJm");
      I[164 ^ 173] = I("潪昞徦", "zmddq");
      I[8 ^ 2] = I("懲傫", "GKWuT");
      I[188 ^ 183] = I("渵战椧俲", "HpASY");
      I[155 ^ 151] = I("弁渎嬂挜峗", "iVmWl");
      I[64 ^ 77] = I("冧嚖朝歰杌", "xexut");
      I[184 ^ 182] = I("旟", "PDhIb");
      I[146 ^ 157] = I("搪橫湃夜", "xiEUi");
      I[173 ^ 189] = I("拼哞亱孹", "stIYy");
      I[138 ^ 155] = I("瀩", "AbsrC");
      I[162 ^ 176] = I("毲暍残", "rqDMA");
      I[99 ^ 112] = I("劏淈斞圏", "iDDxF");
      I[125 ^ 105] = I("娬仈匸俉棄", "UZNPJ");
      I[128 ^ 149] = I("架涶喤椟", "ijXwK");
      I[83 ^ 69] = I("瀶泔榟扉汽", "KBgQJ");
      I[63 ^ 40] = I("烓", "EYMwj");
      I[82 ^ 74] = I("枅斔炀梺唉", "PBHXP");
      I[69 ^ 92] = I("欽", "hPoAn");
      I[80 ^ 74] = I("煢攌仺橆揚", "UGvYr");
      I[139 ^ 144] = I("晪嵔哳嗏", "SJMBw");
      I[116 ^ 104] = I("仞刹員", "frsgr");
      I[112 ^ 109] = I("溇嬁仯", "fIeJL");
      I[29 ^ 3] = I("洼噯", "vIfmD");
      I[127 ^ 96] = I("劧烚榑", "aPUFB");
      I[86 ^ 118] = I("歧滇", "MCkds");
      I[189 ^ 156] = I("濲往娞噯沕", "STusF");
      I[89 ^ 123] = I("曉徑憗淈", "QKFgC");
      I[62 ^ 29] = I("墪堲", "Eweud");
      I[54 ^ 18] = I("偯", "RoOzi");
      I[70 ^ 99] = I("慡", "MjMnM");
      I[86 ^ 112] = I("栘潓", "VpGrR");
      I[44 ^ 11] = I("厺冁尙儾", "wlqPu");
      I[161 ^ 137] = I("兹敥拴啰惀", "jhCBM");
      I[88 ^ 113] = I("況檤", "RlBYK");
      I[8 ^ 34] = I("勪汑沽", "bBQtL");
      I[170 ^ 129] = I("宦崰岩涬", "RuvyN");
      I[8 ^ 36] = I("団吢岲滪", "njjFK");
      I[160 ^ 141] = I("幼", "OTnzW");
      I[238 ^ 192] = I("婱殱埡", "tRBks");
      I[53 ^ 26] = I("垖嶥灗廫幆", "YpKzw");
      I[241 ^ 193] = I("炫", "RpyrS");
      I[168 ^ 153] = I("日嵰", "sRUDc");
      I[188 ^ 142] = I("伪灎", "SgCnD");
      I[191 ^ 140] = I("瀨憕", "zwYFx");
      I[36 ^ 16] = I("櫡寲", "xgrxS");
      I[9 ^ 60] = I("敭淦寘汩", "zNYpK");
      I[145 ^ 167] = I("掤塁", "uLuiQ");
      I[78 ^ 121] = I("毅坒", "zDHQd");
      I[19 ^ 43] = I("氒媝", "dyANG");
      I[121 ^ 64] = I("枽撄", "dqQxU");
      I[94 ^ 100] = I("晟哱", "UrJRk");
      I[0 ^ 59] = I("榅栤", "NLtHI");
      I[180 ^ 136] = I("嚝憞", "WOtfA");
      I[255 ^ 194] = I("凂樆", "KRgLa");
      I[120 ^ 70] = I("斗僠", "AYdFH");
      I[98 ^ 93] = I("渕旻", "VqYmd");
      I[6 ^ 70] = I("哄涧", "RKXAq");
      I[118 ^ 55] = I("汌冔", "QkYHi");
      I[103 ^ 37] = I("嫥淦", "fVdWE");
      I[63 ^ 124] = I("冾帊", "ReDEe");
      I[222 ^ 154] = I("楕戍", "BrhSn");
      I[62 ^ 123] = I("劬冈", "ldIJR");
      I[243 ^ 181] = I("婠儎", "Rszmj");
      I[83 ^ 20] = I("僢忠", "BALcs");
      I[221 ^ 149] = I("刢吠", "XHkbi");
      I[236 ^ 165] = I("嬦佁", "irDtQ");
      I[240 ^ 186] = I("朑垤", "CqDcb");
      I[108 ^ 39] = I("濍濫", "JGrbV");
      I[103 ^ 43] = I("梑憢", "RViLz");
      I[250 ^ 183] = I("抉氦", "VUWaE");
      I[223 ^ 145] = I("倥栔凕晝", "WkOfz");
      I[247 ^ 184] = I("棊濧凖栞殂", "gZSHP");
      I[123 ^ 43] = I("楸", "ERnAv");
      I[75 ^ 26] = I("実朎", "CbqKi");
      I[24 ^ 74] = I("晃沬嘽楂愐", "wxYiR");
      I[125 ^ 46] = I("榅故味", "sSyJK");
      I[106 ^ 62] = I("嬮枠棏殮", "RYIko");
      I[51 ^ 102] = I("例", "CQDNR");
      I[19 ^ 69] = I("櫺", "invLm");
      I[251 ^ 172] = I("寬啧埕", "LrlUC");
      I[110 ^ 54] = I("曯", "LSdzv");
      I[111 ^ 54] = I("噉搸", "cytLR");
      I[34 ^ 120] = I("汴望", "URert");
      I[254 ^ 165] = I("櫢朰", "kWgWG");
      I[48 ^ 108] = I("尊坅恶槔", "wQihz");
      I[239 ^ 178] = I("垟榍丙", "xcYht");
      I[156 ^ 194] = I("殷撑棨密", "aLaEe");
      I[107 ^ 52] = I("\u0001\n\u001e>\u001b", "oelJs");
      I[102 ^ 6] = I("\u0014\f\u0002-", "qmqYb");
      I[239 ^ 142] = I("\u001c\u001b<8\t", "otILa");
      I[61 ^ 95] = I("\u001a3\"\u001a", "mVQnG");
      I[57 ^ 90] = I("$\r'3\u000b", "TbPVy");
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return REDSTONE_WIRE_AABB[getAABBIndex(var1.getActualState(var2, var3))];
   }

   protected static boolean canConnectUpwardsTo(IBlockState var0) {
      return canConnectTo(var0, (EnumFacing)null);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(POWER, var1);
   }

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (!this.canProvidePower) {
         return "".length();
      } else {
         int var5 = (Integer)var1.getValue(POWER);
         if (var5 == 0) {
            return "".length();
         } else if (var4 == EnumFacing.UP) {
            return var5;
         } else {
            EnumSet var6 = EnumSet.noneOf(EnumFacing.class);
            Iterator var7 = EnumFacing.Plane.HORIZONTAL.iterator();

            do {
               if (!var7.hasNext()) {
                  if (var4.getAxis().isHorizontal() && var6.isEmpty()) {
                     return var5;
                  }

                  if (var6.contains(var4) && !var6.contains(var4.rotateYCCW()) && !var6.contains(var4.rotateY())) {
                     return var5;
                  }

                  return "".length();
               }

               EnumFacing var8 = (EnumFacing)var7.next();
               if (this.isPowerSourceAt(var2, var3, var8)) {
                  var6.add(var8);
                  I[94 ^ 64].length();
                  I[68 ^ 91].length();
                  I[24 ^ 56].length();
                  I[178 ^ 147].length();
               }

               "".length();
            } while(3 > -1);

            throw null;
         }
      }
   }

   protected static boolean canConnectUpwardsTo(IBlockAccess var0, BlockPos var1) {
      return canConnectUpwardsTo(var0.getBlockState(var1));
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      int var5 = (Integer)var1.getValue(POWER);
      if (var5 != 0) {
         double var10000 = (double)var3.getX() + 0.5D;
         double var10001 = (double)var4.nextFloat();
         I[14 ^ 43].length();
         I[160 ^ 134].length();
         I[0 ^ 39].length();
         double var6 = var10000 + (var10001 - 0.5D) * 0.2D;
         double var8 = (double)((float)var3.getY() + 0.0625F);
         var10000 = (double)var3.getZ() + 0.5D;
         var10001 = (double)var4.nextFloat();
         I[40 ^ 0].length();
         I[36 ^ 13].length();
         I[97 ^ 75].length();
         double var10 = var10000 + (var10001 - 0.5D) * 0.2D;
         float var12 = (float)var5 / 15.0F;
         float var13 = var12 * 0.6F + 0.4F;
         float var16 = var12 * var12 * 0.7F;
         I[40 ^ 3].length();
         float var14 = Math.max(0.0F, var16 - 0.5F);
         var16 = var12 * var12 * 0.6F;
         I[183 ^ 155].length();
         I[160 ^ 141].length();
         I[171 ^ 133].length();
         I[175 ^ 128].length();
         I[122 ^ 74].length();
         float var15 = Math.max(0.0F, var16 - 0.7F);
         var2.spawnParticle(EnumParticleTypes.REDSTONE, var6, var8, var10, (double)var13, (double)var14, (double)var15);
      }

   }

   static enum EnumAttachPosition implements IStringSerializable {
      // $FF: synthetic field
      NONE,
      // $FF: synthetic field
      SIDE,
      // $FF: synthetic field
      UP;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final String name;

      public String getName() {
         return this.name;
      }

      public String toString() {
         return this.getName();
      }

      static {
         I();
         UP = new BlockRedstoneWire.EnumAttachPosition(I["".length()], "".length(), I[" ".length()]);
         SIDE = new BlockRedstoneWire.EnumAttachPosition(I["  ".length()], " ".length(), I["   ".length()]);
         NONE = new BlockRedstoneWire.EnumAttachPosition(I[180 ^ 176], "  ".length(), I[21 ^ 16]);
         BlockRedstoneWire.EnumAttachPosition[] var10000 = new BlockRedstoneWire.EnumAttachPosition["   ".length()];
         var10000["".length()] = UP;
         var10000[" ".length()] = SIDE;
         var10000["  ".length()] = NONE;
      }

      private EnumAttachPosition(String var3) {
         this.name = var3;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 == -1);

         throw null;
      }

      private static void I() {
         I = new String[153 ^ 159];
         I["".length()] = I("7 ", "bpOjS");
         I[" ".length()] = I("-\u001f", "XoNbK");
         I["  ".length()] = I("=\u0004+\u0015", "nMoPl");
         I["   ".length()] = I("0\u0010%,", "CyAIs");
         I[73 ^ 77] = I("&?:5", "hptpk");
         I[42 ^ 47] = I("6\u0004:\u0012", "XkTwo");
      }
   }
}

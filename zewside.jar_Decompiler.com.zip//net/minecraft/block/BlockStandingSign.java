package net.minecraft.block;

import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockStandingSign extends BlockSign {
   // $FF: synthetic field
   public static final PropertyInteger ROTATION;
   // $FF: synthetic field
   private static final String[] I;

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(ROTATION, var2.rotate((Integer)var1.getValue(ROTATION), 190 ^ 174));
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withProperty(ROTATION, var2.mirrorRotation((Integer)var1.getValue(ROTATION), 16 ^ 0));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   public BlockStandingSign() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(ROTATION, "".length()));
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(ROTATION);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["  ".length()];
      String var10001 = I["   ".length()];
      String var10002 = I[125 ^ 121];
      var10001 = I[23 ^ 18];
      var10000 = I[20 ^ 18];
      var10001 = I[111 ^ 104];
      var10002 = I[172 ^ 164];
      var10001 = I[94 ^ 87];
      I[204 ^ 198].length();
      I[44 ^ 39].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[67 ^ 79].length();
      I[141 ^ 128].length();
      var10003["".length()] = ROTATION;
      return new BlockStateContainer(this, var10003);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.getBlockState(var3.down()).getMaterial().isSolid()) {
         this.dropBlockAsItem(var2, var3, var1, "".length());
         var2.setBlockToAir(var3);
         I["".length()].length();
         I[" ".length()].length();
      }

      super.neighborChanged(var1, var2, var3, var4, var5);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(ROTATION, var1);
   }

   static {
      I();
      ROTATION = PropertyInteger.create(I[17 ^ 31], "".length(), 66 ^ 77);
   }

   private static void I() {
      I = new String[154 ^ 149];
      I["".length()] = I("撑", "JciiU");
      I[" ".length()] = I("揙澱", "KrGQY");
      I["  ".length()] = I("烡屎", "TXXzk");
      I["   ".length()] = I("哷徕", "HFleh");
      I[166 ^ 162] = I("滗孭", "JitEL");
      I[164 ^ 161] = I("润啭", "ukQIZ");
      I[2 ^ 4] = I("淽濰", "XqrsD");
      I[140 ^ 139] = I("橅民", "mhzsI");
      I[151 ^ 159] = I("桯杫", "bYEIQ");
      I[132 ^ 141] = I("仨桲", "naXCn");
      I[174 ^ 164] = I("幐嗴", "DgPWW");
      I[43 ^ 32] = I("匡滦亨", "rlNzp");
      I[82 ^ 94] = I("厃宁婪傳喇", "QbhRI");
      I[87 ^ 90] = I("洹", "thDuT");
      I[29 ^ 19] = I("\u0013>\u001e;\u001b\b>\u0004", "aQjZo");
   }
}

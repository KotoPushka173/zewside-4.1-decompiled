package net.minecraft.block;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockOldLeaf extends BlockLeaves {
   // $FF: synthetic field
   public static final PropertyEnum<BlockPlanks.EnumType> VARIANT;
   // $FF: synthetic field
   private static final String[] I;

   private static void I() {
      I = new String[58 ^ 111];
      I["".length()] = I("煞宨", "tiOBs");
      I[" ".length()] = I("塓崩", "mtFny");
      I["  ".length()] = I("沗揩", "RbrXG");
      I["   ".length()] = I("杝噢", "GuLON");
      I[78 ^ 74] = I("勼忉挢屔惋", "zIBNW");
      I[35 ^ 38] = I("劶喢叞攭", "OIPHZ");
      I[43 ^ 45] = I("滆售", "NRQmj");
      I[128 ^ 135] = I("昏榐", "nuXbH");
      I[170 ^ 162] = I("涫偠", "VOqQv");
      I[63 ^ 54] = I("噹卟", "LTrWj");
      I[115 ^ 121] = I("彮嚎", "BgLqi");
      I[186 ^ 177] = I("只廓", "LIAvZ");
      I[189 ^ 177] = I("枍亡", "XcVRp");
      I[28 ^ 17] = I("塰汯", "tZFJn");
      I[149 ^ 155] = I("惗捖", "QaQuZ");
      I[91 ^ 84] = I("氆坛", "frOzH");
      I[86 ^ 70] = I("漱嶈", "RwMNb");
      I[190 ^ 175] = I("浊斋", "MwiaQ");
      I[7 ^ 21] = I("歱噀", "pantC");
      I[31 ^ 12] = I("厉僣", "HfwHv");
      I[155 ^ 143] = I("妽忂", "aJAkm");
      I[128 ^ 149] = I("宏焷", "YpXtx");
      I[173 ^ 187] = I("恬樢恕", "LrbKc");
      I[90 ^ 77] = I("庳扩崽嗦", "EijDs");
      I[60 ^ 36] = I("屿炡幅", "JTPpw");
      I[130 ^ 155] = I("涒划", "aSlOD");
      I[112 ^ 106] = I("偟倇", "eYJBP");
      I[175 ^ 180] = I("壛彴", "dbhQo");
      I[122 ^ 102] = I("椼架搇", "xnUSF");
      I[122 ^ 103] = I("氐懛樼庲", "ahtlJ");
      I[28 ^ 2] = I("揾", "nrENY");
      I[143 ^ 144] = I("匬椬刽樆培", "sOFEa");
      I[10 ^ 42] = I("悎唨", "byJOl");
      I[129 ^ 160] = I("岅佤嬂", "ztDxI");
      I[152 ^ 186] = I("政塶", "KRxDw");
      I[140 ^ 175] = I("摈兎奍啒", "chAOQ");
      I[178 ^ 150] = I("奋圬嘡戰娨", "wsITD");
      I[128 ^ 165] = I("噗尳忦摜", "NhdAt");
      I[121 ^ 95] = I("塃梑摲乐灸", "IsFkl");
      I[89 ^ 126] = I("整海", "vgrGR");
      I[71 ^ 111] = I("洐东尷攴摢", "KLxEX");
      I[26 ^ 51] = I("械槱世栣毽", "LNCBk");
      I[58 ^ 16] = I("傊", "PFfTL");
      I[106 ^ 65] = I("欀佩冤溵濦", "LXgNe");
      I[184 ^ 148] = I("忍愶汗帵", "DyKXI");
      I[128 ^ 173] = I("宕栎", "ytgcG");
      I[103 ^ 73] = I("嗲沦", "qQZzq");
      I[135 ^ 168] = I("俥伟", "PBqGA");
      I[163 ^ 147] = I("毲匡", "lpiLu");
      I[71 ^ 118] = I("歛桘", "aOnWi");
      I[48 ^ 2] = I("摣榢峼", "WhssL");
      I[89 ^ 106] = I("星橯", "LEHnl");
      I[114 ^ 70] = I("椒殶", "aOpab");
      I[127 ^ 74] = I("吟炷", "kjvRd");
      I[2 ^ 52] = I("檩澘", "esvUg");
      I[60 ^ 11] = I("慗歞", "UEpas");
      I[114 ^ 74] = I("尜伾", "TOsvU");
      I[147 ^ 170] = I("宗核", "LlxKE");
      I[117 ^ 79] = I("嫪圗", "jytNk");
      I[162 ^ 153] = I("弉烩", "PWtQc");
      I[56 ^ 4] = I("坷樝", "TqTUF");
      I[3 ^ 62] = I("坾抮", "wPKaU");
      I[149 ^ 171] = I("瀷峷", "TRHZk");
      I[42 ^ 21] = I("妾坭", "oqERh");
      I[7 ^ 71] = I("洇口", "lFiHb");
      I[220 ^ 157] = I("峥徼", "OFhIn");
      I[75 ^ 9] = I("椛毝", "saxvb");
      I[239 ^ 172] = I("炋尴仰哸柗", "QyiDX");
      I[66 ^ 6] = I("朰坐", "osqbz");
      I[28 ^ 89] = I("匬拂漎", "LRYNR");
      I[234 ^ 172] = I("洏洂", "PpGif");
      I[2 ^ 69] = I("巎淘枤娅", "oOFtv");
      I[202 ^ 130] = I("丌尮灛择", "lZktB");
      I[44 ^ 101] = I("忄浊嚜俰", "iILHm");
      I[8 ^ 66] = I("涎嚘忿", "nlaop");
      I[22 ^ 93] = I("枒厜掫", "VcTEX");
      I[229 ^ 169] = I("晒津", "IkrkD");
      I[85 ^ 24] = I("摷啠搧", "iXBri");
      I[79 ^ 1] = I("凰娄", "NqHYv");
      I[33 ^ 110] = I("潼凞", "pMdVJ");
      I[29 ^ 77] = I("娗婐", "nsExL");
      I[2 ^ 83] = I("桭妷", "PxnKi");
      I[250 ^ 168] = I("亨橴凳劝", "lxckl");
      I[85 ^ 6] = I("渜押", "LaiWZ");
      I[224 ^ 180] = I("\u0007\">\u001e4\u001f7", "qCLwU");
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      String var10000 = I[97 ^ 47];
      String var10001 = I[83 ^ 28];
      String var10002 = I[97 ^ 49];
      var10001 = I[58 ^ 107];
      if (!var1.isRemote && var6.getItem() == Items.SHEARS) {
         var2.addStat(StatList.getBlockStats(this));
         I[69 ^ 23].length();
         I[244 ^ 167].length();
         spawnAsEntity(var1, var3, new ItemStack(Item.getItemFromBlock(this), " ".length(), ((BlockPlanks.EnumType)var4.getValue(VARIANT)).getMetadata()));
         "".length();
         if (1 >= 4) {
            throw null;
         }
      } else {
         super.harvestBlock(var1, var2, var3, var4, var5, var6);
      }

   }

   protected int getSaplingDropChance(IBlockState var1) {
      int var10000;
      if (var1.getValue(VARIANT) == BlockPlanks.EnumType.JUNGLE) {
         var10000 = 96 ^ 72;
         "".length();
         if (-1 >= 1) {
            throw null;
         }
      } else {
         var10000 = super.getSaplingDropChance(var1);
      }

      return var10000;
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[177 ^ 183];
      String var10001 = I[196 ^ 195];
      String var10002 = I[73 ^ 65];
      var10001 = I[170 ^ 163];
      var10000 = I[102 ^ 108];
      var10001 = I[53 ^ 62];
      var10002 = I[93 ^ 81];
      var10001 = I[179 ^ 190];
      var10000 = I[86 ^ 88];
      var10001 = I[144 ^ 159];
      var10002 = I[75 ^ 91];
      var10001 = I[191 ^ 174];
      var10000 = I[126 ^ 108];
      var10001 = I[92 ^ 79];
      var10002 = I[78 ^ 90];
      var10001 = I[129 ^ 148];
      I[209 ^ 199].length();
      I[82 ^ 69].length();
      I[2 ^ 26].length();
      I[25 ^ 0].length();
      I[18 ^ 8].length();
      var2.add(new ItemStack(this, " ".length(), BlockPlanks.EnumType.OAK.getMetadata()));
      I[139 ^ 144].length();
      I[188 ^ 160].length();
      I[221 ^ 192].length();
      I[21 ^ 11].length();
      I[51 ^ 44].length();
      var2.add(new ItemStack(this, " ".length(), BlockPlanks.EnumType.SPRUCE.getMetadata()));
      I[21 ^ 53].length();
      I[20 ^ 53].length();
      I[131 ^ 161].length();
      I[167 ^ 132].length();
      I[157 ^ 185].length();
      var2.add(new ItemStack(this, " ".length(), BlockPlanks.EnumType.BIRCH.getMetadata()));
      I[31 ^ 58].length();
      I[17 ^ 55].length();
      I[106 ^ 77].length();
      I[109 ^ 69].length();
      I[64 ^ 105].length();
      var2.add(new ItemStack(this, " ".length(), BlockPlanks.EnumType.JUNGLE.getMetadata()));
      I[187 ^ 145].length();
      I[112 ^ 91].length();
      I[181 ^ 153].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 4);

      throw null;
   }

   public BlockPlanks.EnumType getWoodType(int var1) {
      return BlockPlanks.EnumType.byMetadata((var1 & "   ".length()) % (197 ^ 193));
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[197 ^ 145], BlockPlanks.EnumType.class, new Predicate<BlockPlanks.EnumType>() {
         public boolean apply(@Nullable BlockPlanks.EnumType var1) {
            int var10000;
            if (var1.getMetadata() < (151 ^ 147)) {
               var10000 = " ".length();
               "".length();
               if (3 == -1) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(1 >= 1);

            throw null;
         }
      });
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[29 ^ 46];
      String var10001 = I[173 ^ 153];
      String var10002 = I[107 ^ 94];
      var10001 = I[57 ^ 15];
      var10000 = I[175 ^ 152];
      var10001 = I[189 ^ 133];
      var10002 = I[188 ^ 133];
      var10001 = I[106 ^ 80];
      var10000 = I[176 ^ 139];
      var10001 = I[102 ^ 90];
      var10002 = I[78 ^ 115];
      var10001 = I[20 ^ 42];
      var10000 = I[9 ^ 54];
      var10001 = I[210 ^ 146];
      var10002 = I[44 ^ 109];
      var10001 = I[114 ^ 48];
      I[57 ^ 122].length();
      I[119 ^ 51].length();
      I[130 ^ 199].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[236 ^ 170].length();
      I[108 ^ 43].length();
      var10003["".length()] = VARIANT;
      I[252 ^ 180].length();
      I[124 ^ 53].length();
      var10003[" ".length()] = CHECK_DECAY;
      I[241 ^ 187].length();
      I[27 ^ 80].length();
      I[33 ^ 109].length();
      I[52 ^ 121].length();
      var10003["  ".length()] = DECAYABLE;
      return new BlockStateContainer(this, var10003);
   }

   protected void dropApple(World var1, BlockPos var2, IBlockState var3, int var4) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (var3.getValue(VARIANT) == BlockPlanks.EnumType.OAK && var1.rand.nextInt(var4) == 0) {
         I[96 ^ 100].length();
         I[114 ^ 119].length();
         spawnAsEntity(var1, var2, new ItemStack(Items.APPLE));
      }

   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I[9 ^ 36];
      String var10001 = I[97 ^ 79];
      String var10002 = I[4 ^ 43];
      var10001 = I[3 ^ 51];
      I[124 ^ 77].length();
      I[135 ^ 181].length();
      return new ItemStack(Item.getItemFromBlock(this), " ".length(), ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata());
   }

   public BlockOldLeaf() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockPlanks.EnumType.OAK).withProperty(CHECK_DECAY, Boolean.valueOf((boolean)" ".length())).withProperty(DECAYABLE, Boolean.valueOf((boolean)" ".length())));
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(VARIANT, this.getWoodType(var1));
      PropertyBool var10001 = DECAYABLE;
      int var10002;
      if ((var1 & (143 ^ 139)) == 0) {
         var10002 = " ".length();
         "".length();
         if (4 <= -1) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = CHECK_DECAY;
      if ((var1 & (137 ^ 129)) > 0) {
         var10002 = " ".length();
         "".length();
         if (3 <= 0) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
      if (!(Boolean)var1.getValue(DECAYABLE)) {
         var2 |= 135 ^ 131;
      }

      if ((Boolean)var1.getValue(CHECK_DECAY)) {
         var2 |= 113 ^ 121;
      }

      return var2;
   }
}

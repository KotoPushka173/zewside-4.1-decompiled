package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class CPacketPlayerDigging implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private CPacketPlayerDigging.Action action;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private EnumFacing facing;
   // $FF: synthetic field
   private BlockPos position;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 1);

      throw null;
   }

   public CPacketPlayerDigging(CPacketPlayerDigging.Action var1, BlockPos var2, EnumFacing var3) {
      this.action = var1;
      this.position = var2;
      this.facing = var3;
   }

   public BlockPos getPosition() {
      return this.position;
   }

   public CPacketPlayerDigging() {
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.action = (CPacketPlayerDigging.Action)var1.readEnumValue(CPacketPlayerDigging.Action.class);
      this.position = var1.readBlockPos();
      this.facing = EnumFacing.getFront(var1.readUnsignedByte());
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processPlayerDigging(this);
   }

   private static void I() {
      I = new String[77 ^ 73];
      I["".length()] = I("庸彰唾欄櫟", "LpIes");
      I[" ".length()] = I("崀毼校汁壡", "inoux");
      I["  ".length()] = I("滻怨", "qsllf");
      I["   ".length()] = I("欯宿", "KJALY");
   }

   public EnumFacing getFacing() {
      return this.facing;
   }

   public CPacketPlayerDigging.Action getAction() {
      return this.action;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.action);
      I["".length()].length();
      var1.writeBlockPos(this.position);
      I[" ".length()].length();
      var1.writeByte(this.facing.getIndex());
      I["  ".length()].length();
      I["   ".length()].length();
   }

   public static enum Action {
      // $FF: synthetic field
      ABORT_DESTROY_BLOCK;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      DROP_ITEM,
      // $FF: synthetic field
      SWAP_HELD_ITEMS,
      // $FF: synthetic field
      DROP_ALL_ITEMS,
      // $FF: synthetic field
      STOP_DESTROY_BLOCK,
      // $FF: synthetic field
      START_DESTROY_BLOCK,
      // $FF: synthetic field
      RELEASE_USE_ITEM;

      static {
         I();
         START_DESTROY_BLOCK = new CPacketPlayerDigging.Action(I["".length()], "".length());
         ABORT_DESTROY_BLOCK = new CPacketPlayerDigging.Action(I[" ".length()], " ".length());
         STOP_DESTROY_BLOCK = new CPacketPlayerDigging.Action(I["  ".length()], "  ".length());
         DROP_ALL_ITEMS = new CPacketPlayerDigging.Action(I["   ".length()], "   ".length());
         DROP_ITEM = new CPacketPlayerDigging.Action(I[79 ^ 75], 57 ^ 61);
         RELEASE_USE_ITEM = new CPacketPlayerDigging.Action(I[168 ^ 173], 157 ^ 152);
         SWAP_HELD_ITEMS = new CPacketPlayerDigging.Action(I[112 ^ 118], 119 ^ 113);
         CPacketPlayerDigging.Action[] var10000 = new CPacketPlayerDigging.Action[190 ^ 185];
         var10000["".length()] = START_DESTROY_BLOCK;
         var10000[" ".length()] = ABORT_DESTROY_BLOCK;
         var10000["  ".length()] = STOP_DESTROY_BLOCK;
         var10000["   ".length()] = DROP_ALL_ITEMS;
         var10000[91 ^ 95] = DROP_ITEM;
         var10000[194 ^ 199] = RELEASE_USE_ITEM;
         var10000[66 ^ 68] = SWAP_HELD_ITEMS;
      }

      private static void I() {
         I = new String[152 ^ 159];
         I["".length()] = I("8<#>\u000e4,'?\u000e9';3\u0018''!'", "khblZ");
         I[" ".length()] = I("\u0000\u0017+(\u0012\u001e\u0011!)\u0012\u0013\u001a=%\u0004\r\u001a'1", "AUdzF");
         I["  ".length()] = I("$\u0007=)\u000e3\u0016!-\u00038\n-;\u001d8\u00109", "wSryQ");
         I["   ".length()] = I("\f\u0005\u0018)\u0017\t\u001b\u001b&\u0001\u001c\u0012\u001a*", "HWWyH");
         I[60 ^ 56] = I("\t'\u0015\u0003,\u0004!\u001f\u001e", "MuZSs");
         I[120 ^ 125] = I("=7\u0005'\u0016<7\u00167\u0004*-\u00006\u0012\"", "orIbW");
         I[154 ^ 156] = I("<\u0012&;,'\u0000+/,&\u0011\"& ", "oEgks");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 < 3);

         throw null;
      }
   }
}

package net.minecraft.advancements;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraft.network.PacketBuffer;

public class CriterionProgress {
   // $FF: synthetic field
   private final AdvancementProgress field_192156_b;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final SimpleDateFormat field_192155_a;
   // $FF: synthetic field
   private Date field_192157_c;

   public CriterionProgress(AdvancementProgress var1) {
      this.field_192156_b = var1;
   }

   public void func_192150_a(PacketBuffer var1) {
      int var10001;
      if (this.field_192157_c != null) {
         var10001 = " ".length();
         "".length();
         if (1 == 3) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      var1.writeBoolean((boolean)var10001);
      I[3 ^ 12].length();
      I[110 ^ 126].length();
      I[52 ^ 37].length();
      if (this.field_192157_c != null) {
         var1.func_192574_a(this.field_192157_c);
         I[126 ^ 108].length();
         I[21 ^ 6].length();
         I[36 ^ 48].length();
      }

   }

   public static CriterionProgress func_192152_a(AdvancementProgress var0, String var1) {
      String var10000 = I[171 ^ 137];
      String var10001 = I[49 ^ 18];
      String var10002 = I[23 ^ 51];
      var10001 = I[74 ^ 111];
      var10000 = I[228 ^ 194];
      var10001 = I[167 ^ 128];
      var10002 = I[58 ^ 18];
      var10001 = I[139 ^ 162];
      var10000 = I[169 ^ 131];
      var10001 = I[3 ^ 40];
      var10002 = I[184 ^ 148];
      var10001 = I[72 ^ 101];
      I[107 ^ 69].length();
      I[234 ^ 197].length();
      I[84 ^ 100].length();
      CriterionProgress var2 = new CriterionProgress(var0);

      try {
         var2.field_192157_c = field_192155_a.parse(var1);
         return var2;
      } catch (ParseException var4) {
         I[89 ^ 104].length();
         I[135 ^ 181].length();
         I[7 ^ 52].length();
         I[145 ^ 165].length();
         I[77 ^ 120].length();
         I[56 ^ 14].length();
         JsonSyntaxException var5 = new JsonSyntaxException(I[151 ^ 160] + var1, var4);
         I[12 ^ 52].length();
         I[92 ^ 101].length();
         I[174 ^ 148].length();
         I[135 ^ 188].length();
         I[23 ^ 43].length();
         throw var5;
      }
   }

   static {
      I();
      field_192155_a = new SimpleDateFormat(I[182 ^ 139]);
   }

   public JsonElement func_192148_e() {
      String var10000 = I[12 ^ 25];
      String var10001 = I[3 ^ 21];
      String var10002 = I[34 ^ 53];
      var10001 = I[191 ^ 167];
      Object var1;
      if (this.field_192157_c != null) {
         I[20 ^ 13].length();
         I[190 ^ 164].length();
         var1 = new JsonPrimitive(field_192155_a.format(this.field_192157_c));
         "".length();
         if (4 < -1) {
            throw null;
         }
      } else {
         var1 = JsonNull.INSTANCE;
      }

      return (JsonElement)var1;
   }

   public void func_192153_b() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[181 ^ 177].length();
      I[35 ^ 38].length();
      I[182 ^ 176].length();
      I[58 ^ 61].length();
      this.field_192157_c = new Date();
   }

   private static void I() {
      I = new String[190 ^ 128];
      I["".length()] = I("墟溊", "RMdEX");
      I[" ".length()] = I("湨吞", "QGzYs");
      I["  ".length()] = I("危匑", "wulmS");
      I["   ".length()] = I("泭憹", "cKHXJ");
      I[4 ^ 0] = I("榊椗楩棪壑", "diYcv");
      I[15 ^ 10] = I("娶", "zyMLe");
      I[128 ^ 134] = I("桑", "XJEeP");
      I[106 ^ 109] = I("栽抜径埳", "pxtuJ");
      I[94 ^ 86] = I("滍叭", "sCheo");
      I[61 ^ 52] = I("奅弖", "WXZMB");
      I[157 ^ 151] = I("屩涎", "HjuxI");
      I[46 ^ 37] = I("埄曖", "rNNgG");
      I[147 ^ 159] = I("嗖氇孂", "oIKUu");
      I[177 ^ 188] = I("+\u0014\u000e0)\u001a\u000f\b*\u001c\u001a\t\u00006)\u001b\u0015\u001c+.\u001c\u0007\u000e*)\f[", "hfgDL");
      I[34 ^ 44] = I("7\f\u000b8\f", "QmgKi");
      I[183 ^ 184] = I("炵汕柇", "mftua");
      I[103 ^ 119] = I("歟", "QzMyM");
      I[27 ^ 10] = I("坩妰烑又咎", "wDzZR");
      I[121 ^ 107] = I("底柪媳卙乴", "AtSsJ");
      I[56 ^ 43] = I("伫吷捪氧", "BZrBf");
      I[107 ^ 127] = I("圆圂忀桟", "eMujG");
      I[136 ^ 157] = I("沺匬", "Kunmr");
      I[16 ^ 6] = I("塋奓", "OROhc");
      I[118 ^ 97] = I("朘佱", "lDcZh");
      I[105 ^ 113] = I("叉履", "FVFvN");
      I[119 ^ 110] = I("攨", "FwxLe");
      I[40 ^ 50] = I("帀嫰", "JpcMo");
      I[114 ^ 105] = I("洠末", "DpsMj");
      I[97 ^ 125] = I("氼叏", "XUEvi");
      I[18 ^ 15] = I("晸敏", "qhChE");
      I[175 ^ 177] = I("啗摴", "yJwuD");
      I[188 ^ 163] = I("扇什妥", "GGMms");
      I[186 ^ 154] = I("啊", "mnrak");
      I[54 ^ 23] = I("仞塷敷仠呄", "hgrwd");
      I[106 ^ 72] = I("婋嫷", "PTEZw");
      I[35 ^ 0] = I("欫岩", "iAsqY");
      I[13 ^ 41] = I("滃恽", "EsRaV");
      I[185 ^ 156] = I("化俊", "syEsU");
      I[181 ^ 147] = I("淭嗄", "AMESc");
      I[146 ^ 181] = I("擈橜", "NLxIq");
      I[67 ^ 107] = I("囓敥", "dpoLd");
      I[98 ^ 75] = I("氎昛", "JJGgx");
      I[135 ^ 173] = I("嫅侕", "zbQQj");
      I[64 ^ 107] = I("垽卸", "UOvGY");
      I[95 ^ 115] = I("渏喉", "MJWQL");
      I[11 ^ 38] = I("屐凟", "uHEsf");
      I[165 ^ 139] = I("擖掔揉嬭寝", "kRmbw");
      I[128 ^ 175] = I("杔浧", "zNUEW");
      I[38 ^ 22] = I("浀哄峡", "meFbo");
      I[115 ^ 66] = I("儸姶桸棰搐", "hbMdH");
      I[138 ^ 184] = I("俔溄哝", "oiVzj");
      I[114 ^ 65] = I("瀠椣点", "SZNUO");
      I[27 ^ 47] = I("櫐", "obmrs");
      I[121 ^ 76] = I("佉圐侚桂昳", "ZQIkn");
      I[141 ^ 187] = I("杇壈娥梹", "VzJvK");
      I[156 ^ 171] = I("\u0011'\u0017\f;1-A\t6,,\u0015\u0004:=sA", "XIamW");
      I[143 ^ 183] = I("棞棷啹", "zDqJs");
      I[65 ^ 120] = I("亹噆桢左揌", "fcrHp");
      I[46 ^ 20] = I("扰忁橡坾", "PLSmY");
      I[115 ^ 72] = I("橶", "FEZGQ");
      I[125 ^ 65] = I("姴壮堹", "DYrVL");
      I[155 ^ 166] = I("18\r\u001ea\u0005\fY\u0003(h\t<]!%{\u0007\u0014l\u0012", "HAtgL");
   }

   public boolean func_192151_a() {
      int var10000;
      if (this.field_192157_c != null) {
         var10000 = " ".length();
         "".length();
         if (2 < 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static CriterionProgress func_192149_a(PacketBuffer var0, AdvancementProgress var1) {
      String var10000 = I[151 ^ 140];
      String var10001 = I[12 ^ 16];
      String var10002 = I[150 ^ 139];
      var10001 = I[176 ^ 174];
      I[116 ^ 107].length();
      I[133 ^ 165].length();
      I[78 ^ 111].length();
      CriterionProgress var2 = new CriterionProgress(var1);
      if (var0.readBoolean()) {
         var2.field_192157_c = var0.func_192573_m();
      }

      return var2;
   }

   public Date func_193140_d() {
      return this.field_192157_c;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 3);

      throw null;
   }

   public void func_192154_c() {
      this.field_192157_c = null;
   }

   public String toString() {
      String var10000 = I[161 ^ 169];
      String var10001 = I[63 ^ 54];
      String var10002 = I[48 ^ 58];
      var10001 = I[79 ^ 68];
      I[187 ^ 183].length();
      StringBuilder var1 = (new StringBuilder()).append(I[154 ^ 151]);
      Object var2;
      if (this.field_192157_c == null) {
         var2 = I[135 ^ 137];
         "".length();
         if (-1 == 4) {
            throw null;
         }
      } else {
         var2 = this.field_192157_c;
      }

      return var1.append(var2).append((char)('\u001f' ^ 'b')).toString();
   }
}

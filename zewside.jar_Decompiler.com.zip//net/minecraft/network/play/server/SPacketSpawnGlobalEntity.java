package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketSpawnGlobalEntity implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private double z;
   // $FF: synthetic field
   private double x;
   // $FF: synthetic field
   private int type;
   // $FF: synthetic field
   private double y;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 4);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.type = var1.readByte();
      this.x = var1.readDouble();
      this.y = var1.readDouble();
      this.z = var1.readDouble();
   }

   public double getZ() {
      return this.z;
   }

   static {
      I();
   }

   public double getY() {
      return this.y;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSpawnGlobalEntity(this);
   }

   public SPacketSpawnGlobalEntity() {
   }

   public SPacketSpawnGlobalEntity(Entity var1) {
      this.entityId = var1.getEntityId();
      this.x = var1.posX;
      this.y = var1.posY;
      this.z = var1.posZ;
      if (var1 instanceof EntityLightningBolt) {
         this.type = " ".length();
      }

   }

   public double getX() {
      return this.x;
   }

   private static void I() {
      I = new String[7 ^ 12];
      I["".length()] = I("廍", "jEHQw");
      I[" ".length()] = I("厨汯岤", "JhIpN");
      I["  ".length()] = I("攼", "BUYXt");
      I["   ".length()] = I("潶唐", "cMqUZ");
      I[151 ^ 147] = I("奜奸柅剾囀", "dFPTW");
      I[69 ^ 64] = I("厉晊剈待嶷", "HWNle");
      I[191 ^ 185] = I("摞憀热恇偰", "vTCwJ");
      I[58 ^ 61] = I("愯", "cINMg");
      I[45 ^ 37] = I("呱婳壣噑", "BARcB");
      I[170 ^ 163] = I("博欐崳", "mPaHk");
      I[142 ^ 132] = I("劭", "ickSv");
   }

   public int getType() {
      return this.type;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeByte(this.type);
      I["  ".length()].length();
      var1.writeDouble(this.x);
      I["   ".length()].length();
      I[195 ^ 199].length();
      var1.writeDouble(this.y);
      I[126 ^ 123].length();
      I[59 ^ 61].length();
      I[18 ^ 21].length();
      I[12 ^ 4].length();
      var1.writeDouble(this.z);
      I[191 ^ 182].length();
      I[63 ^ 53].length();
   }

   public int getEntityId() {
      return this.entityId;
   }
}

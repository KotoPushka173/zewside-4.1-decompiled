package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class BlockOre extends Block {
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      super.dropBlockAsItemWithChance(var1, var2, var3, var4, var5);
      if (this.getItemDropped(var3, var1.rand, var5) != Item.getItemFromBlock(this)) {
         int var6 = "".length();
         if (this == Blocks.COAL_ORE) {
            var6 = MathHelper.getInt(var1.rand, "".length(), "  ".length());
            "".length();
            if (3 == -1) {
               throw null;
            }
         } else if (this == Blocks.DIAMOND_ORE) {
            var6 = MathHelper.getInt(var1.rand, "   ".length(), 39 ^ 32);
            "".length();
            if (1 == -1) {
               throw null;
            }
         } else if (this == Blocks.EMERALD_ORE) {
            var6 = MathHelper.getInt(var1.rand, "   ".length(), 140 ^ 139);
            "".length();
            if (3 <= -1) {
               throw null;
            }
         } else if (this == Blocks.LAPIS_ORE) {
            var6 = MathHelper.getInt(var1.rand, "  ".length(), 100 ^ 97);
            "".length();
            if (0 >= 1) {
               throw null;
            }
         } else if (this == Blocks.QUARTZ_ORE) {
            var6 = MathHelper.getInt(var1.rand, "  ".length(), 127 ^ 122);
         }

         this.dropXpOnBlockBreak(var1, var2, var6);
      }

   }

   private static void I() {
      I = new String[158 ^ 151];
      I["".length()] = I("呑", "JexIV");
      I[" ".length()] = I("床弬", "zGrOJ");
      I["  ".length()] = I("媤仝", "UZKRr");
      I["   ".length()] = I("夅湍", "nqxYS");
      I[166 ^ 162] = I("摶姼", "xXfmy");
      I[29 ^ 24] = I("垡匾棃", "UFxzO");
      I[121 ^ 127] = I("幓", "tuKuK");
      I[23 ^ 16] = I("埑歲淸", "RXwaG");
      I[122 ^ 114] = I("匧彋", "QxiGW");
   }

   public int damageDropped(IBlockState var1) {
      int var10000;
      if (this == Blocks.LAPIS_ORE) {
         var10000 = EnumDyeColor.BLUE.getDyeDamage();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[172 ^ 168];
      I[158 ^ 155].length();
      I[93 ^ 91].length();
      I[46 ^ 41].length();
      I[200 ^ 192].length();
      return new ItemStack(this);
   }

   public int quantityDroppedWithBonus(int var1, Random var2) {
      if (var1 > 0 && Item.getItemFromBlock(this) != this.getItemDropped((IBlockState)this.getBlockState().getValidStates().iterator().next(), var2, var1)) {
         int var10000 = var2.nextInt(var1 + "  ".length());
         int var10001 = " ".length();
         I["".length()].length();
         int var3 = var10000 - var10001;
         if (var3 < 0) {
            var3 = "".length();
         }

         return this.quantityDropped(var2) * (var3 + " ".length());
      } else {
         return this.quantityDropped(var2);
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 2);

      throw null;
   }

   public BlockOre() {
      this(Material.ROCK.getMaterialMapColor());
   }

   public BlockOre(MapColor var1) {
      super(Material.ROCK, var1);
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public int quantityDropped(Random var1) {
      int var10000;
      if (this == Blocks.LAPIS_ORE) {
         var10000 = (111 ^ 107) + var1.nextInt(133 ^ 128);
         "".length();
         if (4 <= 2) {
            throw null;
         }
      } else {
         var10000 = " ".length();
      }

      return var10000;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      if (this == Blocks.COAL_ORE) {
         return Items.COAL;
      } else if (this == Blocks.DIAMOND_ORE) {
         return Items.DIAMOND;
      } else if (this == Blocks.LAPIS_ORE) {
         return Items.DYE;
      } else if (this == Blocks.EMERALD_ORE) {
         return Items.EMERALD;
      } else {
         Item var10000;
         if (this == Blocks.QUARTZ_ORE) {
            var10000 = Items.QUARTZ;
            "".length();
            if (-1 == 0) {
               throw null;
            }
         } else {
            var10000 = Item.getItemFromBlock(this);
         }

         return var10000;
      }
   }
}

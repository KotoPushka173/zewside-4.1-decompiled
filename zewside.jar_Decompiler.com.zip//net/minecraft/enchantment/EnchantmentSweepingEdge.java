package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentSweepingEdge extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public EnchantmentSweepingEdge(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.WEAPON, var2);
   }

   public int getMinEnchantability(int var1) {
      int var10000 = 34 ^ 39;
      int var10002 = " ".length();
      I["".length()].length();
      return var10000 + (var1 - var10002) * (113 ^ 120);
   }

   public static float func_191526_e(int var0) {
      float var10001 = 1.0F / (float)(var0 + " ".length());
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      I[197 ^ 193].length();
      I[92 ^ 89].length();
      return 1.0F - var10001;
   }

   public int getMaxEnchantability(int var1) {
      return this.getMinEnchantability(var1) + (178 ^ 189);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   public int getMaxLevel() {
      return "   ".length();
   }

   private static void I() {
      I = new String[52 ^ 51];
      I["".length()] = I("归梿昃", "QQgaj");
      I[" ".length()] = I("檷兼", "KYKbI");
      I["  ".length()] = I("曹乒湓圉桏", "Ivlur");
      I["   ".length()] = I("滢伙", "iIMMe");
      I[5 ^ 1] = I("嘏榮漀", "Tvhsf");
      I[195 ^ 198] = I("榿侵圜灥滍", "xOFmQ");
      I[15 ^ 9] = I(",\u001f/ \u0006'\u0005!-\t=_??\u0002,\u0001%&\u0000", "IqLHg");
   }

   public String getName() {
      return I[27 ^ 29];
   }
}

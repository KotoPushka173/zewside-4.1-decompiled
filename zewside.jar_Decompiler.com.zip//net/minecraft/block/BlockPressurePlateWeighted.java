package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class BlockPressurePlateWeighted extends BlockBasePressurePlate {
   // $FF: synthetic field
   public static final PropertyInteger POWER;
   // $FF: synthetic field
   private final int maxWeight;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != -1);

      throw null;
   }

   protected IBlockState setRedstoneStrength(IBlockState var1, int var2) {
      return var1.withProperty(POWER, var2);
   }

   public int tickRate(World var1) {
      return 113 ^ 123;
   }

   static {
      I();
      POWER = PropertyInteger.create(I[206 ^ 192], "".length(), 14 ^ 1);
   }

   protected void playClickOffSound(World var1, BlockPos var2) {
      var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_METAL_PRESSPLATE_CLICK_OFF, SoundCategory.BLOCKS, 0.3F, 0.75F);
   }

   protected BlockPressurePlateWeighted(Material var1, int var2) {
      this(var1, var2, var1.getMaterialMapColor());
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(POWER, var1);
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(POWER);
   }

   private static void I() {
      I = new String[64 ^ 79];
      I["".length()] = I("涉涯", "XtPzv");
      I[" ".length()] = I("挦桱", "gqsIC");
      I["  ".length()] = I("炮樐", "NlsRn");
      I["   ".length()] = I("瀑彳", "LbvNt");
      I[103 ^ 99] = I("嘒嗜", "NdRtk");
      I[43 ^ 46] = I("擁嗫", "GzbeM");
      I[193 ^ 199] = I("娙宿", "PJwNh");
      I[93 ^ 90] = I("呣忣", "EmHVI");
      I[92 ^ 84] = I("晄", "AWVfs");
      I[29 ^ 20] = I("僶殯杧榪潊", "saoOM");
      I[61 ^ 55] = I("塥", "cARsn");
      I[181 ^ 190] = I("憢婁毎涂", "LAYrf");
      I[3 ^ 15] = I("滝傈掣", "OmHFW");
      I[83 ^ 94] = I("俅悅昑毌損", "HeBAG");
      I[177 ^ 191] = I("7%\u001f\u0004\u0017", "GJhae");
   }

   protected void playClickOnSound(World var1, BlockPos var2) {
      var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_METAL_PRESSPLATE_CLICK_ON, SoundCategory.BLOCKS, 0.3F, 0.90000004F);
   }

   protected BlockPressurePlateWeighted(Material var1, int var2, MapColor var3) {
      super(var1, var3);
      this.setDefaultState(this.blockState.getBaseState().withProperty(POWER, "".length()));
      this.maxWeight = var2;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[111 ^ 107];
      var10001 = I[152 ^ 157];
      var10002 = I[85 ^ 83];
      var10001 = I[194 ^ 197];
      I[81 ^ 89].length();
      I[91 ^ 82].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[27 ^ 17].length();
      I[147 ^ 152].length();
      I[138 ^ 134].length();
      I[74 ^ 71].length();
      var10003["".length()] = POWER;
      return new BlockStateContainer(this, var10003);
   }

   protected int computeRedstoneStrength(World var1, BlockPos var2) {
      int var3 = Math.min(var1.getEntitiesWithinAABB(Entity.class, PRESSURE_AABB.offset(var2)).size(), this.maxWeight);
      if (var3 > 0) {
         float var4 = (float)Math.min(this.maxWeight, var3) / (float)this.maxWeight;
         return MathHelper.ceil(var4 * 15.0F);
      } else {
         return "".length();
      }
   }

   protected int getRedstoneStrength(IBlockState var1) {
      return (Integer)var1.getValue(POWER);
   }
}

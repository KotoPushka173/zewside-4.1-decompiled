package net.minecraft.network.datasync;

import javax.annotation.ParametersAreNonnullByDefault;
import mcp.MethodsReturnNonnullByDefault;

// $FF: synthetic class
@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
interface package-info {
}

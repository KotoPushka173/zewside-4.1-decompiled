package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketSpawnMob implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private byte headPitch;
   // $FF: synthetic field
   private int velocityX;
   // $FF: synthetic field
   private double x;
   // $FF: synthetic field
   private int velocityZ;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private byte yaw;
   // $FF: synthetic field
   private List<EntityDataManager.DataEntry<?>> dataManagerEntries;
   // $FF: synthetic field
   private double y;
   // $FF: synthetic field
   private byte pitch;
   // $FF: synthetic field
   private UUID uniqueId;
   // $FF: synthetic field
   private double z;
   // $FF: synthetic field
   private int type;
   // $FF: synthetic field
   private int velocityY;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private EntityDataManager dataManager;

   public int getEntityID() {
      return this.entityId;
   }

   static {
      I();
   }

   @Nullable
   public List<EntityDataManager.DataEntry<?>> getDataManagerEntries() {
      return this.dataManagerEntries;
   }

   public byte getPitch() {
      return this.pitch;
   }

   public int getEntityType() {
      return this.type;
   }

   private static void I() {
      I = new String[107 ^ 119];
      I["".length()] = I("徢抮搾堢囩", "rTEpS");
      I[" ".length()] = I("木", "oYlBl");
      I["  ".length()] = I("殛巴", "gBXAm");
      I["   ".length()] = I("也", "eANOu");
      I[120 ^ 124] = I("厏愙拆", "GJbVb");
      I[190 ^ 187] = I("唌炏攙渐", "uVCNp");
      I[30 ^ 24] = I("怪夀", "jJsNj");
      I[8 ^ 15] = I("什毢亙", "DeMRD");
      I[190 ^ 182] = I("漹", "RVxNB");
      I[120 ^ 113] = I("扉憏", "guVIc");
      I[182 ^ 188] = I("槱宙搿憾坺", "sFQTY");
      I[182 ^ 189] = I("戚", "otjjz");
      I[29 ^ 17] = I("婈欦侾晁憰", "oQlOo");
      I[46 ^ 35] = I("嵸洩", "NlcsN");
      I[34 ^ 44] = I("婲", "DNdPh");
      I[2 ^ 13] = I("媛噁偷桔彺", "kqkSB");
      I[151 ^ 135] = I("幭澊控億", "yOJFL");
      I[187 ^ 170] = I("柙暍弝", "pvdRA");
      I[97 ^ 115] = I("夓傡杰嗬", "yGFxe");
      I[189 ^ 174] = I("嘛溿戳", "yIGYA");
      I[54 ^ 34] = I("壀佪", "wRZSz");
      I[209 ^ 196] = I("懲坹", "xsITj");
      I[124 ^ 106] = I("浅櫬挊嬬嫏", "xmmzj");
      I[132 ^ 147] = I("湛喻廍昽懀", "yqXJc");
      I[122 ^ 98] = I("抄灷塉佣", "tSezz");
      I[16 ^ 9] = I("抁彑捶", "rjsZd");
      I[110 ^ 116] = I("暠濦", "dLHLM");
      I[223 ^ 196] = I("灰涪", "TRpWL");
   }

   public double getX() {
      return this.x;
   }

   public byte getHeadPitch() {
      return this.headPitch;
   }

   public int getVelocityZ() {
      return this.velocityZ;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeUuid(this.uniqueId);
      I["  ".length()].length();
      I["   ".length()].length();
      I[152 ^ 156].length();
      var1.writeVarIntToBuffer(this.type);
      I[129 ^ 132].length();
      I[112 ^ 118].length();
      I[16 ^ 23].length();
      var1.writeDouble(this.x);
      I[123 ^ 115].length();
      I[57 ^ 48].length();
      I[123 ^ 113].length();
      var1.writeDouble(this.y);
      I[43 ^ 32].length();
      var1.writeDouble(this.z);
      I[7 ^ 11].length();
      I[112 ^ 125].length();
      var1.writeByte(this.yaw);
      I[113 ^ 127].length();
      I[175 ^ 160].length();
      var1.writeByte(this.pitch);
      I[68 ^ 84].length();
      I[23 ^ 6].length();
      var1.writeByte(this.headPitch);
      I[82 ^ 64].length();
      I[44 ^ 63].length();
      I[17 ^ 5].length();
      var1.writeShort(this.velocityX);
      I[78 ^ 91].length();
      var1.writeShort(this.velocityY);
      I[15 ^ 25].length();
      I[66 ^ 85].length();
      I[60 ^ 36].length();
      var1.writeShort(this.velocityZ);
      I[86 ^ 79].length();
      I[141 ^ 151].length();
      I[24 ^ 3].length();
      this.dataManager.writeEntries(var1);
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSpawnMob(this);
   }

   public byte getYaw() {
      return this.yaw;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != -1);

      throw null;
   }

   public int getVelocityY() {
      return this.velocityY;
   }

   public UUID getUniqueId() {
      return this.uniqueId;
   }

   public double getY() {
      return this.y;
   }

   public double getZ() {
      return this.z;
   }

   public int getVelocityX() {
      return this.velocityX;
   }

   public SPacketSpawnMob() {
   }

   public SPacketSpawnMob(EntityLivingBase var1) {
      this.entityId = var1.getEntityId();
      this.uniqueId = var1.getUniqueID();
      this.type = EntityList.REGISTRY.getIDForObject(var1.getClass());
      this.x = var1.posX;
      this.y = var1.posY;
      this.z = var1.posZ;
      this.yaw = (byte)((int)(var1.rotationYaw * 256.0F / 360.0F));
      this.pitch = (byte)((int)(var1.rotationPitch * 256.0F / 360.0F));
      this.headPitch = (byte)((int)(var1.rotationYawHead * 256.0F / 360.0F));
      double var2 = 3.9D;
      double var4 = var1.motionX;
      double var6 = var1.motionY;
      double var8 = var1.motionZ;
      if (var4 < -3.9D) {
         var4 = -3.9D;
      }

      if (var6 < -3.9D) {
         var6 = -3.9D;
      }

      if (var8 < -3.9D) {
         var8 = -3.9D;
      }

      if (var4 > 3.9D) {
         var4 = 3.9D;
      }

      if (var6 > 3.9D) {
         var6 = 3.9D;
      }

      if (var8 > 3.9D) {
         var8 = 3.9D;
      }

      this.velocityX = (int)(var4 * 8000.0D);
      this.velocityY = (int)(var6 * 8000.0D);
      this.velocityZ = (int)(var8 * 8000.0D);
      this.dataManager = var1.getDataManager();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.uniqueId = var1.readUuid();
      this.type = var1.readVarIntFromBuffer();
      this.x = var1.readDouble();
      this.y = var1.readDouble();
      this.z = var1.readDouble();
      this.yaw = var1.readByte();
      this.pitch = var1.readByte();
      this.headPitch = var1.readByte();
      this.velocityX = var1.readShort();
      this.velocityY = var1.readShort();
      this.velocityZ = var1.readShort();
      this.dataManagerEntries = EntityDataManager.readEntries(var1);
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketSetSlot implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int windowId;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int slot;
   // $FF: synthetic field
   private ItemStack item;

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.windowId = var1.readByte();
      this.slot = var1.readShort();
      this.item = var1.readItemStackFromBuffer();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSetSlot(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.windowId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeShort(this.slot);
      I["   ".length()].length();
      var1.writeItemStackToBuffer(this.item);
      I[179 ^ 183].length();
   }

   public int getSlot() {
      return this.slot;
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 < 4);

      throw null;
   }

   public int getWindowId() {
      return this.windowId;
   }

   public SPacketSetSlot(int var1, int var2, ItemStack var3) {
      this.item = ItemStack.field_190927_a;
      this.windowId = var1;
      this.slot = var2;
      this.item = var3.copy();
   }

   public ItemStack getStack() {
      return this.item;
   }

   private static void I() {
      I = new String[101 ^ 96];
      I["".length()] = I("欥烐", "qFQNM");
      I[" ".length()] = I("櫊惯姗", "tDWks");
      I["  ".length()] = I("墓捓墪孳嬒", "iOpNt");
      I["   ".length()] = I("敏淩潀", "eJROx");
      I[8 ^ 12] = I("媇仏崕", "HmuFA");
   }

   public SPacketSetSlot() {
      this.item = ItemStack.field_190927_a;
   }
}

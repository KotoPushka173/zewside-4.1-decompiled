package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketHeldItemChange implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int heldItemHotbarIndex;

   public int getHeldItemHotbarIndex() {
      return this.heldItemHotbarIndex;
   }

   private static void I() {
      I = new String[178 ^ 183];
      I["".length()] = I("桿刯泮墎", "aCGNj");
      I[" ".length()] = I("岔抶攋呴", "iXwjP");
      I["  ".length()] = I("棡嵻湑", "nGVJn");
      I["   ".length()] = I("嶏壮", "vzGCI");
      I[85 ^ 81] = I("咄塐忥", "FZtyw");
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleHeldItemChange(this);
   }

   public SPacketHeldItemChange() {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public SPacketHeldItemChange(int var1) {
      this.heldItemHotbarIndex = var1;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.heldItemHotbarIndex);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      I[22 ^ 18].length();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.heldItemHotbarIndex = var1.readByte();
   }
}

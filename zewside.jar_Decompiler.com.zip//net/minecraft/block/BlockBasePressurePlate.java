package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockBasePressurePlate extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB UNPRESSED_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB PRESSED_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB PRESSURE_AABB;

   public void randomTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public int tickRate(World var1) {
      return 42 ^ 62;
   }

   protected BlockBasePressurePlate(Material var1, MapColor var2) {
      super(var1, var2);
      this.setCreativeTab(CreativeTabs.REDSTONE);
      this.setTickRandomly((boolean)" ".length());
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      return this.canBePlacedOn(var1, var2.down());
   }

   private static void I() {
      I = new String[142 ^ 130];
      I["".length()] = I("介吜元旊", "Haeza");
      I[" ".length()] = I("巤", "DBtwA");
      I["  ".length()] = I("墩斀", "NCaKZ");
      I["   ".length()] = I("櫫溍", "bpgev");
      I[128 ^ 132] = I("勋安", "QqutB");
      I[168 ^ 173] = I("佘泧", "Clczm");
      I[114 ^ 116] = I("嫋厮椬圧", "bGgqa");
      I[99 ^ 100] = I("俾榯灬", "oFLqi");
      I[157 ^ 149] = I("偧炴孖", "XPKPL");
      I[135 ^ 142] = I("挲", "DpJvS");
      I[166 ^ 172] = I("吶", "XvIjP");
      I[10 ^ 1] = I("厲噝", "Zgmng");
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote) {
         int var5 = this.getRedstoneStrength(var3);
         if (var5 > 0) {
            this.updateState(var1, var2, var3, var5);
         }
      }

   }

   public EnumPushReaction getMobilityFlag(IBlockState var1) {
      return EnumPushReaction.DESTROY;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      int var10000;
      if (this.getRedstoneStrength(var1) > 0) {
         var10000 = " ".length();
         "".length();
         if (4 == 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var4 = var10000;
      AxisAlignedBB var5;
      if (var4 != 0) {
         var5 = PRESSED_AABB;
         "".length();
         if (2 <= -1) {
            throw null;
         }
      } else {
         var5 = UNPRESSED_AABB;
      }

      return var5;
   }

   protected abstract void playClickOnSound(World var1, BlockPos var2);

   public boolean canSpawnInBlock() {
      return (boolean)" ".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 > 0);

      throw null;
   }

   static {
      I();
      PRESSED_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.03125D, 0.9375D);
      UNPRESSED_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.0625D, 0.9375D);
      PRESSURE_AABB = new AxisAlignedBB(0.125D, 0.0D, 0.125D, 0.875D, 0.25D, 0.875D);
   }

   public boolean canProvidePower(IBlockState var1) {
      return (boolean)" ".length();
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!this.canBePlacedOn(var2, var3.down())) {
         this.dropBlockAsItem(var2, var3, var1, "".length());
         var2.setBlockToAir(var3);
         I["".length()].length();
         I[" ".length()].length();
      }

   }

   protected BlockBasePressurePlate(Material var1) {
      this(var1, var1.getMaterialMapColor());
   }

   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if (var4 == EnumFacing.UP) {
         var10000 = this.getRedstoneStrength(var1);
         "".length();
         if (2 >= 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   protected abstract int computeRedstoneStrength(World var1, BlockPos var2);

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      return (boolean)" ".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      if (!var1.isRemote) {
         int var5 = this.getRedstoneStrength(var3);
         if (var5 == 0) {
            this.updateState(var1, var2, var3, var5);
         }
      }

   }

   private boolean canBePlacedOn(World var1, BlockPos var2) {
      int var10000;
      if (!var1.getBlockState(var2).isFullyOpaque() && !(var1.getBlockState(var2).getBlock() instanceof BlockFence)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (2 < 2) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      if (this.getRedstoneStrength(var3) > 0) {
         this.updateNeighbors(var1, var2);
      }

      super.breakBlock(var1, var2, var3);
   }

   protected abstract void playClickOffSound(World var1, BlockPos var2);

   protected void updateState(World var1, BlockPos var2, IBlockState var3, int var4) {
      String var10000 = I["  ".length()];
      String var10001 = I["   ".length()];
      String var10002 = I[194 ^ 198];
      var10001 = I[86 ^ 83];
      int var5 = this.computeRedstoneStrength(var1, var2);
      int var8;
      if (var4 > 0) {
         var8 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var8 = "".length();
      }

      int var6 = var8;
      if (var5 > 0) {
         var8 = " ".length();
         "".length();
         if (3 == 1) {
            throw null;
         }
      } else {
         var8 = "".length();
      }

      int var7 = var8;
      if (var4 != var5) {
         var3 = this.setRedstoneStrength(var3, var5);
         var1.setBlockState(var2, var3, "  ".length());
         I[91 ^ 93].length();
         this.updateNeighbors(var1, var2);
         var1.markBlockRangeForRenderUpdate(var2, var2);
      }

      if (var7 == 0 && var6 != 0) {
         this.playClickOffSound(var1, var2);
         "".length();
         if (4 < 1) {
            throw null;
         }
      } else if (var7 != 0 && var6 == 0) {
         this.playClickOnSound(var1, var2);
      }

      if (var7 != 0) {
         I[62 ^ 57].length();
         I[45 ^ 37].length();
         I[120 ^ 113].length();
         I[130 ^ 136].length();
         I[164 ^ 175].length();
         var1.scheduleUpdate(new BlockPos(var2), this, this.tickRate(var1));
      }

   }

   protected abstract IBlockState setRedstoneStrength(IBlockState var1, int var2);

   protected abstract int getRedstoneStrength(IBlockState var1);

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return this.getRedstoneStrength(var1);
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   protected void updateNeighbors(World var1, BlockPos var2) {
      var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
      var1.notifyNeighborsOfStateChange(var2.down(), this, (boolean)"".length());
   }
}

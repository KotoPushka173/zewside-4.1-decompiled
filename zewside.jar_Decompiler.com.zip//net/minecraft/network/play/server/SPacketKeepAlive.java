package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketKeepAlive implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private long id;

   static {
      I();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleKeepAlive(this);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= -1);

      throw null;
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("孭婉", "tDkaU");
      I[" ".length()] = I("沾槁", "LVxYb");
      I["  ".length()] = I("汪", "LJhdO");
   }

   public SPacketKeepAlive(long var1) {
      this.id = var1;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.id = var1.readLong();
   }

   public long getId() {
      return this.id;
   }

   public SPacketKeepAlive() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeLong(this.id);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }
}

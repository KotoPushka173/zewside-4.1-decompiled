package net.minecraft.block;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockNewLeaf extends BlockLeaves {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockPlanks.EnumType> VARIANT;

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      int var10001 = ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
      int var10002 = 78 ^ 74;
      I[60 ^ 21].length();
      I[113 ^ 91].length();
      var2 |= var10001 - var10002;
      if (!(Boolean)var1.getValue(DECAYABLE)) {
         var2 |= 186 ^ 190;
      }

      if ((Boolean)var1.getValue(CHECK_DECAY)) {
         var2 |= 165 ^ 173;
      }

      return var2;
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      String var10000 = I[246 ^ 176];
      String var10001 = I[102 ^ 33];
      String var10002 = I[202 ^ 130];
      var10001 = I[90 ^ 19];
      if (!var1.isRemote && var6.getItem() == Items.SHEARS) {
         var2.addStat(StatList.getBlockStats(this));
         I[241 ^ 187].length();
         Item var10004 = Item.getItemFromBlock(this);
         int var10005 = " ".length();
         int var10006 = ((BlockPlanks.EnumType)var4.getValue(VARIANT)).getMetadata();
         int var10007 = 2 ^ 6;
         I[253 ^ 182].length();
         I[21 ^ 89].length();
         spawnAsEntity(var1, var3, new ItemStack(var10004, var10005, var10006 - var10007));
         "".length();
         if (3 <= 1) {
            throw null;
         }
      } else {
         super.harvestBlock(var1, var2, var3, var4, var5, var6);
      }

   }

   protected void dropApple(World var1, BlockPos var2, IBlockState var3, int var4) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (var3.getValue(VARIANT) == BlockPlanks.EnumType.DARK_OAK && var1.rand.nextInt(var4) == 0) {
         I[30 ^ 26].length();
         I[64 ^ 69].length();
         spawnAsEntity(var1, var2, new ItemStack(Items.APPLE));
      }

   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[186 ^ 188];
      String var10001 = I[147 ^ 148];
      String var10002 = I[95 ^ 87];
      var10001 = I[110 ^ 103];
      I[9 ^ 3].length();
      I[98 ^ 105].length();
      I[203 ^ 199].length();
      return new ItemStack(this, " ".length(), var3.getBlock().getMetaFromState(var3) & "   ".length());
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public BlockNewLeaf() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockPlanks.EnumType.ACACIA).withProperty(CHECK_DECAY, Boolean.valueOf((boolean)" ".length())).withProperty(DECAYABLE, Boolean.valueOf((boolean)" ".length())));
   }

   public BlockPlanks.EnumType getWoodType(int var1) {
      return BlockPlanks.EnumType.byMetadata((var1 & "   ".length()) + (171 ^ 175));
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[172 ^ 135];
      String var10001 = I[133 ^ 169];
      String var10002 = I[21 ^ 56];
      var10001 = I[151 ^ 185];
      var10000 = I[233 ^ 198];
      var10001 = I[160 ^ 144];
      var10002 = I[19 ^ 34];
      var10001 = I[130 ^ 176];
      var10000 = I[87 ^ 100];
      var10001 = I[5 ^ 49];
      var10002 = I[184 ^ 141];
      var10001 = I[77 ^ 123];
      var10000 = I[92 ^ 107];
      var10001 = I[60 ^ 4];
      var10002 = I[158 ^ 167];
      var10001 = I[2 ^ 56];
      I[48 ^ 11].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[69 ^ 121].length();
      I[150 ^ 171].length();
      I[186 ^ 132].length();
      var10003["".length()] = VARIANT;
      I[151 ^ 168].length();
      I[195 ^ 131].length();
      I[247 ^ 182].length();
      I[100 ^ 38].length();
      I[50 ^ 113].length();
      var10003[" ".length()] = CHECK_DECAY;
      I[95 ^ 27].length();
      I[88 ^ 29].length();
      var10003["  ".length()] = DECAYABLE;
      return new BlockStateContainer(this, var10003);
   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I[142 ^ 145];
      String var10001 = I[161 ^ 129];
      String var10002 = I[78 ^ 111];
      var10001 = I[86 ^ 116];
      I[180 ^ 151].length();
      I[127 ^ 91].length();
      I[56 ^ 29].length();
      Item var2 = Item.getItemFromBlock(this);
      int var10003 = " ".length();
      int var10004 = ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
      int var10005 = 157 ^ 153;
      I[5 ^ 35].length();
      I[48 ^ 23].length();
      I[112 ^ 88].length();
      return new ItemStack(var2, var10003, var10004 - var10005);
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(VARIANT, this.getWoodType(var1));
      PropertyBool var10001 = DECAYABLE;
      int var10002;
      if ((var1 & (7 ^ 3)) == 0) {
         var10002 = " ".length();
         "".length();
         if (2 <= 0) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = CHECK_DECAY;
      if ((var1 & (108 ^ 100)) > 0) {
         var10002 = " ".length();
         "".length();
         if (4 < -1) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[160 ^ 173];
      String var10001 = I[190 ^ 176];
      String var10002 = I[159 ^ 144];
      var10001 = I[111 ^ 127];
      var10000 = I[108 ^ 125];
      var10001 = I[51 ^ 33];
      var10002 = I[7 ^ 20];
      var10001 = I[84 ^ 64];
      I[208 ^ 197].length();
      I[175 ^ 185].length();
      var2.add(new ItemStack(this, " ".length(), "".length()));
      I[19 ^ 4].length();
      I[175 ^ 183].length();
      I[186 ^ 163].length();
      I[167 ^ 189].length();
      I[92 ^ 71].length();
      var2.add(new ItemStack(this, " ".length(), " ".length()));
      I[19 ^ 15].length();
      I[57 ^ 36].length();
      I[73 ^ 87].length();
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[90 ^ 23], BlockPlanks.EnumType.class, new Predicate<BlockPlanks.EnumType>() {
         public boolean apply(@Nullable BlockPlanks.EnumType var1) {
            int var10000;
            if (var1.getMetadata() >= (142 ^ 138)) {
               var10000 = " ".length();
               "".length();
               if (2 < 0) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 >= -1);

            throw null;
         }
      });
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 3);

      throw null;
   }

   private static void I() {
      I = new String[137 ^ 199];
      I["".length()] = I("埼以", "usOaI");
      I[" ".length()] = I("横摫", "txwuB");
      I["  ".length()] = I("漾倅", "CbNeA");
      I["   ".length()] = I("棪樟", "CXagT");
      I[116 ^ 112] = I("櫋", "PqUIR");
      I[107 ^ 110] = I("如塂", "wDLmy");
      I[130 ^ 132] = I("敜浏", "WXlQf");
      I[196 ^ 195] = I("嵗坸", "heata");
      I[168 ^ 160] = I("嘇恗", "cSdVH");
      I[31 ^ 22] = I("傤泯", "ggBTH");
      I[109 ^ 103] = I("歕亜", "bBQhk");
      I[79 ^ 68] = I("壁帠樣", "Yjoeq");
      I[154 ^ 150] = I("夻坕幣挪", "VvczD");
      I[130 ^ 143] = I("焋峈", "ILsiX");
      I[138 ^ 132] = I("殟凢", "LryBI");
      I[172 ^ 163] = I("孋墱", "UPkuw");
      I[214 ^ 198] = I("撽扄", "YKmhU");
      I[151 ^ 134] = I("唐愼", "GMUOm");
      I[23 ^ 5] = I("截徹", "jSkfU");
      I[62 ^ 45] = I("佥渰", "GELPN");
      I[35 ^ 55] = I("涢槈", "wZucF");
      I[13 ^ 24] = I("抇寝墾曇濄", "gEHjF");
      I[178 ^ 164] = I("嶁浽", "LsyHz");
      I[37 ^ 50] = I("漚丯圻吁曒", "WpNAz");
      I[56 ^ 32] = I("樾咘儦婗", "QzWhd");
      I[44 ^ 53] = I("攠厤挽叜慁", "fwsxv");
      I[145 ^ 139] = I("告瀭抄欃", "eqsvc");
      I[85 ^ 78] = I("垘毭洮", "lHsIX");
      I[107 ^ 119] = I("滽崽", "RkLEW");
      I[35 ^ 62] = I("憕愊俸孱", "qRIQr");
      I[107 ^ 117] = I("唋", "UAIvk");
      I[39 ^ 56] = I("崚櫜", "OFGRh");
      I[8 ^ 40] = I("懡涼", "cScmV");
      I[102 ^ 71] = I("寓垌", "Cjqlt");
      I[26 ^ 56] = I("沏媼", "BOpVi");
      I[42 ^ 9] = I("湸媐揅夫", "CPYdr");
      I[170 ^ 142] = I("剜瀆塘檨揕", "QjIue");
      I[77 ^ 104] = I("啔推洁", "fUhjx");
      I[44 ^ 10] = I("勫怐杁恲", "bMHWa");
      I[8 ^ 47] = I("剢澴渨", "CYlAL");
      I[33 ^ 9] = I("榃", "wEiqN");
      I[4 ^ 45] = I("偵峞暱槥", "SMIIL");
      I[127 ^ 85] = I("宨坒暪凐浲", "ukjSM");
      I[100 ^ 79] = I("昗廦", "iSJfK");
      I[48 ^ 28] = I("核沯", "lDyKZ");
      I[139 ^ 166] = I("撶妝", "qshAF");
      I[15 ^ 33] = I("弞愬", "ELrLP");
      I[55 ^ 24] = I("峛你", "OnCNn");
      I[105 ^ 89] = I("墼垗", "nQZSa");
      I[25 ^ 40] = I("岹揍", "wrsdm");
      I[94 ^ 108] = I("媀围", "ImEpB");
      I[79 ^ 124] = I("慤橁", "Taatj");
      I[88 ^ 108] = I("并動", "eNtEm");
      I[39 ^ 18] = I("溡怤", "PJDLv");
      I[158 ^ 168] = I("冸吀", "dfkXh");
      I[53 ^ 2] = I("侄嗞", "RoAff");
      I[89 ^ 97] = I("幽炲", "tXQQL");
      I[21 ^ 44] = I("徹廃", "eyXCh");
      I[115 ^ 73] = I("榥仨", "tcmuE");
      I[173 ^ 150] = I("搁", "INNjg");
      I[158 ^ 162] = I("奬", "jqnfd");
      I[71 ^ 122] = I("樇揱", "BaZuK");
      I[127 ^ 65] = I("厤炔", "uhQGh");
      I[44 ^ 19] = I("巜影俠", "JYPoh");
      I[241 ^ 177] = I("松孴愿嚶", "OxMhj");
      I[71 ^ 6] = I("捄揺呍", "TNTAX");
      I[73 ^ 11] = I("冦抧", "qVxCN");
      I[252 ^ 191] = I("仂吼", "NHMNH");
      I[59 ^ 127] = I("崕", "MQioR");
      I[214 ^ 147] = I("忺漇币", "JyHYf");
      I[46 ^ 104] = I("巂悉", "GOYFX");
      I[83 ^ 20] = I("橾廵", "AqZMP");
      I[87 ^ 31] = I("庙厸", "QrZSx");
      I[223 ^ 150] = I("檉嬭", "TZrvR");
      I[235 ^ 161] = I("彫櫤圖奂", "diRbR");
      I[221 ^ 150] = I("吶敊奉", "pQiYc");
      I[45 ^ 97] = I("拟拞曲", "yHuOy");
      I[50 ^ 127] = I("\u001e\"\u0011\u000f-\u00067", "hCcfL");
   }
}

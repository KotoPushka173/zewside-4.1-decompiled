package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;

public class BlockSnowBlock extends Block {
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public int quantityDropped(Random var1) {
      return 65 ^ 69;
   }

   private static void I() {
      I = new String[112 ^ 116];
      I["".length()] = I("毭媋墘", "eFaCi");
      I[" ".length()] = I("偍壐侜娑", "cegWL");
      I["  ".length()] = I("満懖嶂欍", "WBOpw");
      I["   ".length()] = I("卦京嚃", "bGcOh");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 >= -1);

      throw null;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (var1.getLightFor(EnumSkyBlock.BLOCK, var2) > (173 ^ 166)) {
         this.dropBlockAsItem(var1, var2, var1.getBlockState(var2), "".length());
         var1.setBlockToAir(var2);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }

   }

   protected BlockSnowBlock() {
      super(Material.CRAFTED_SNOW);
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.SNOWBALL;
   }
}

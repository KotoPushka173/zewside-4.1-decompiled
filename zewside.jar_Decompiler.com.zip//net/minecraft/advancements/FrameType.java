package net.minecraft.advancements;

import net.minecraft.util.text.TextFormatting;

public enum FrameType {
   // $FF: synthetic field
   TASK;

   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final TextFormatting field_193230_f;
   // $FF: synthetic field
   private final int field_192314_e;
   // $FF: synthetic field
   private final String field_192313_d;
   // $FF: synthetic field
   GOAL,
   // $FF: synthetic field
   CHALLENGE;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 0);

      throw null;
   }

   static {
      I();
      TASK = new FrameType(I[34 ^ 54], "".length(), I[181 ^ 160], "".length(), TextFormatting.GREEN);
      CHALLENGE = new FrameType(I[21 ^ 3], " ".length(), I[49 ^ 38], 121 ^ 99, TextFormatting.DARK_PURPLE);
      GOAL = new FrameType(I[156 ^ 132], "  ".length(), I[168 ^ 177], 117 ^ 65, TextFormatting.GREEN);
      FrameType[] var10000 = new FrameType["   ".length()];
      var10000["".length()] = TASK;
      var10000[" ".length()] = CHALLENGE;
      var10000["  ".length()] = GOAL;
   }

   public String func_192307_a() {
      return this.field_192313_d;
   }

   private static void I() {
      I = new String[90 ^ 64];
      I["".length()] = I("折渚", "WVdvR");
      I[" ".length()] = I("抏汌", "hDPUD");
      I["  ".length()] = I("挹湬", "UkujG");
      I["   ".length()] = I("峣櫧", "ZUnwY");
      I[151 ^ 147] = I("唔枼", "aAZxR");
      I[136 ^ 141] = I("月曨", "QaiEV");
      I[125 ^ 123] = I("塡坴", "mwGup");
      I[96 ^ 103] = I("湛幟", "smpnT");
      I[188 ^ 180] = I("枥宇持", "dFOTG");
      I[175 ^ 166] = I("毮坺允泳榛", "PCwHB");
      I[98 ^ 104] = I("曚歓柨搄忻", "CAxGk");
      I[112 ^ 123] = I("擫", "YydPX");
      I[63 ^ 51] = I("呍堿殶揘", "CRtke");
      I[167 ^ 170] = I("另烶娑泡", "ujIrS");
      I[169 ^ 167] = I("1\u001e\u0018*\u001e\u0013\u001eS\"\u0003\u0005\u001d\u0016d\u0005\u001d\u0000\u0016dV", "dpsDq");
      I[131 ^ 140] = I("w", "PnsVy");
      I[2 ^ 18] = I("敋么洮椒廖", "JrspG");
      I[62 ^ 47] = I("嘯惒拦渻", "rSmrM");
      I[58 ^ 40] = I("桫澱摪", "ICgxN");
      I[160 ^ 179] = I("尿垓漷嵔", "smkmS");
      I[119 ^ 99] = I(",\u0003#\t", "xBpBs");
      I[126 ^ 107] = I("=6+\u001e", "IWXuk");
      I[100 ^ 114] = I("\u0012\u001b\u0017>\u0003\u0014\u001d\u00117", "QSVrO");
      I[7 ^ 16] = I("7\u0019\u0006\"51\u001f\u0000+", "TqgNY");
      I[44 ^ 52] = I("\u001f'\u00126", "XhSzx");
      I[175 ^ 182] = I("%\u000e;$", "BaZHp");
   }

   private FrameType(String var3, int var4, TextFormatting var5) {
      this.field_192313_d = var3;
      this.field_192314_e = var4;
      this.field_193230_f = var5;
   }

   public int func_192309_b() {
      return this.field_192314_e;
   }

   public static FrameType func_192308_a(String var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[157 ^ 153];
      var10001 = I[13 ^ 8];
      var10002 = I[155 ^ 157];
      var10001 = I[79 ^ 72];
      FrameType[] var1 = values();
      int var2 = var1.length;
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            I[3 ^ 11].length();
            I[31 ^ 22].length();
            I[177 ^ 187].length();
            I[137 ^ 130].length();
            I[24 ^ 20].length();
            I[76 ^ 65].length();
            IllegalArgumentException var5 = new IllegalArgumentException(I[93 ^ 83] + var0 + I[19 ^ 28]);
            I[164 ^ 180].length();
            I[98 ^ 115].length();
            I[63 ^ 45].length();
            I[165 ^ 182].length();
            throw var5;
         }

         FrameType var4 = var1[var3];
         if (var4.field_192313_d.equals(var0)) {
            return var4;
         }

         ++var3;
         "".length();
      } while(3 >= 0);

      throw null;
   }

   public TextFormatting func_193229_c() {
      return this.field_193230_f;
   }
}

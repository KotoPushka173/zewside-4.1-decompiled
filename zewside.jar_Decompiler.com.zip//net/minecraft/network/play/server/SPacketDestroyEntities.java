package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketDestroyEntities implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int[] entityIDs;
   // $FF: synthetic field
   private static final String[] I;

   public SPacketDestroyEntities() {
   }

   private static void I() {
      I = new String["  ".length()];
      I["".length()] = I("厙官", "idRsi");
      I[" ".length()] = I("抁", "DfvcV");
   }

   public int[] getEntityIDs() {
      return this.entityIDs;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityIDs.length);
      I["".length()].length();
      int[] var2 = this.entityIDs;
      int var3 = var2.length;
      int var4 = "".length();

      do {
         if (var4 >= var3) {
            return;
         }

         int var5 = var2[var4];
         var1.writeVarIntToBuffer(var5);
         I[" ".length()].length();
         ++var4;
         "".length();
      } while(3 != 4);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleDestroyEntities(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityIDs = new int[var1.readVarIntFromBuffer()];
      int var2 = "".length();

      do {
         if (var2 >= this.entityIDs.length) {
            return;
         }

         this.entityIDs[var2] = var1.readVarIntFromBuffer();
         ++var2;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 2);

      throw null;
   }

   public SPacketDestroyEntities(int... var1) {
      this.entityIDs = var1;
   }
}

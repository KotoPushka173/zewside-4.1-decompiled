package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import java.io.IOException;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class NettyPacketDecoder extends ByteToMessageDecoder {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final EnumPacketDirection direction;
   // $FF: synthetic field
   private static final Logger LOGGER;
   // $FF: synthetic field
   private static final Marker RECEIVED_PACKET_MARKER;

   static {
      I();
      LOGGER = LogManager.getLogger();
      RECEIVED_PACKET_MARKER = MarkerManager.getMarker(I[39 ^ 22], NetworkManager.NETWORK_PACKETS_MARKER);
   }

   private static void I() {
      I = new String[79 ^ 125];
      I["".length()] = I("氤形", "SqcFp");
      I[" ".length()] = I("园埱", "pWqMF");
      I["  ".length()] = I("櫸埿", "DOLSH");
      I["   ".length()] = I("桜揂", "ChSKH");
      I[184 ^ 188] = I("煎媌", "UCDRY");
      I[176 ^ 181] = I("楪擰", "uDRqX");
      I[128 ^ 134] = I("敉峷", "wtVbp");
      I[50 ^ 53] = I("楍勎", "dzPCP");
      I[172 ^ 164] = I("噤櫼", "hxwcN");
      I[103 ^ 110] = I("姓灯", "eAeUC");
      I[64 ^ 74] = I("噸嫄", "TnpzL");
      I[91 ^ 80] = I("嶵嗗", "VVJPs");
      I[203 ^ 199] = I("幰吃", "BHsEV");
      I[113 ^ 124] = I("娧滪", "rUjTU");
      I[158 ^ 144] = I("履梍", "qulZg");
      I[151 ^ 152] = I("巇尩", "ZgPbS");
      I[97 ^ 113] = I("啾摶", "TbWgA");
      I[21 ^ 4] = I("匶柀", "eihei");
      I[186 ^ 168] = I("櫲庞", "QMfiQ");
      I[51 ^ 32] = I("毱漲", "OofKn");
      I[59 ^ 47] = I("卤", "vlAJR");
      I[39 ^ 50] = I("澦樛弁棪憒", "hMiiI");
      I[131 ^ 149] = I("搊", "cKuWU");
      I[21 ^ 2] = I("槨劉憊朤沋", "dGWrK");
      I[97 ^ 121] = I("烩", "sWnKM");
      I[149 ^ 140] = I("尉娘媯", "HzFpt");
      I[158 ^ 132] = I("#\u0010\u000bj\u0011\u0000\u0012\u0004/\u0015A\u0018\u000bj", "aqoJa");
      I[21 ^ 14] = I("涤", "ufpDK");
      I[6 ^ 26] = I("幜楛勑宎峓", "duPmC");
      I[37 ^ 56] = I("凎員刞斡", "tbuXj");
      I[60 ^ 34] = I("搔氷", "AJgvr");
      I[81 ^ 78] = I("嚱墧埐刉椿", "BSOqK");
      I[96 ^ 64] = I("族弭嚶岐圂", "EDxLp");
      I[138 ^ 171] = I("仌塽", "ZuypZ");
      I[184 ^ 154] = I("橉曤旧拘杠", "iVmUk");
      I[168 ^ 139] = I("斌墘", "VZSfY");
      I[179 ^ 151] = I("斖凊囫添夾", "qbvHd");
      I[109 ^ 72] = I("\u0017\u0005-/+3D", "GdNDN");
      I[77 ^ 107] = I("m", "BoBDm");
      I[157 ^ 186] = I("ox", "OPRqB");
      I[104 ^ 64] = I("bH?\u0007\u0010k\u0004)\u0014\u0004.\u001ah\u0012\u000b*\u0006h/C.\u00108\u0003\u0000?\r,JC-\u0007=\b\u0007k", "KhHfc");
      I[120 ^ 81] = I("N) 6\u000f\u001dk<:\u001e\u001c*y5\u0002\u0007'*6J\u001c.8&\u0003\u0000,y2\u000b\r <6J", "nKYBj");
      I[109 ^ 71] = I("嗘", "miIXR");
      I[162 ^ 137] = I("佭噜", "nLIYP");
      I[82 ^ 126] = I("弬濪嫫", "wZtVg");
      I[185 ^ 148] = I("妪泽嵩呁", "bGjaE");
      I[38 ^ 8] = I("劫喎廖搮乲", "zHOoZ");
      I[238 ^ 193] = I("嶏圧", "VsTHr");
      I[89 ^ 105] = I("L\u0006,kC74\u001fk\u0018\u0011\u0012B*\u001e", "lObQc");
      I[68 ^ 117] = I("\u001f\u0006,\u0000?\u001b\u0018=\u000e9\n\u000e9\u000e>", "OGoKz");
   }

   public NettyPacketDecoder(EnumPacketDirection var1) {
      this.direction = var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   protected void decode(ChannelHandlerContext var1, ByteBuf var2, List<Object> var3) throws IOException, IllegalAccessException, InstantiationException, Exception {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[93 ^ 89];
      var10001 = I[112 ^ 117];
      var10002 = I[189 ^ 187];
      var10001 = I[182 ^ 177];
      var10000 = I[128 ^ 136];
      var10001 = I[178 ^ 187];
      var10002 = I[158 ^ 148];
      var10001 = I[104 ^ 99];
      var10000 = I[81 ^ 93];
      var10001 = I[145 ^ 156];
      var10002 = I[181 ^ 187];
      var10001 = I[188 ^ 179];
      var10000 = I[187 ^ 171];
      var10001 = I[170 ^ 187];
      var10002 = I[83 ^ 65];
      var10001 = I[2 ^ 17];
      if (var2.readableBytes() != 0) {
         I[191 ^ 171].length();
         I[22 ^ 3].length();
         I[183 ^ 161].length();
         PacketBuffer var4 = new PacketBuffer(var2);
         int var5 = var4.readVarIntFromBuffer();
         Packet var6 = ((EnumConnectionState)var1.channel().attr(NetworkManager.PROTOCOL_ATTRIBUTE_KEY).get()).getPacket(this.direction, var5);
         IOException var7;
         if (var6 == null) {
            I[91 ^ 76].length();
            I[15 ^ 23].length();
            I[71 ^ 94].length();
            var7 = new IOException(I[135 ^ 157] + var5);
            I[27 ^ 0].length();
            I[21 ^ 9].length();
            I[151 ^ 138].length();
            throw var7;
         }

         var6.readPacketData(var4);
         if (var4.readableBytes() > 0) {
            I[35 ^ 61].length();
            I[144 ^ 143].length();
            I[106 ^ 74].length();
            I[92 ^ 125].length();
            I[52 ^ 22].length();
            I[143 ^ 172].length();
            I[23 ^ 51].length();
            var7 = new IOException(I[87 ^ 114] + ((EnumConnectionState)var1.channel().attr(NetworkManager.PROTOCOL_ATTRIBUTE_KEY).get()).getId() + I[21 ^ 51] + var5 + I[63 ^ 24] + var6.getClass().getSimpleName() + I[153 ^ 177] + var4.readableBytes() + I[109 ^ 68] + var5);
            I[169 ^ 131].length();
            I[176 ^ 155].length();
            I[29 ^ 49].length();
            I[178 ^ 159].length();
            I[88 ^ 118].length();
            throw var7;
         }

         var3.add(var6);
         I[11 ^ 36].length();
         if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(RECEIVED_PACKET_MARKER, I[104 ^ 88], var1.channel().attr(NetworkManager.PROTOCOL_ATTRIBUTE_KEY).get(), var5, var6.getClass().getName());
         }
      }

   }
}

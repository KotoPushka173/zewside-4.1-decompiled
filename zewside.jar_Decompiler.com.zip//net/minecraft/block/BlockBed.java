package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Biomes;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBed;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockBed extends BlockHorizontal implements ITileEntityProvider {
   // $FF: synthetic field
   public static final PropertyBool OCCUPIED;
   // $FF: synthetic field
   protected static final AxisAlignedBB BED_AABB;
   // $FF: synthetic field
   public static final PropertyEnum<BlockBed.EnumPartType> PART;
   // $FF: synthetic field
   private static final String[] I;

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.ENTITYBLOCK_ANIMATED;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return BED_AABB;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[50 ^ 104];
      String var10001 = I[87 ^ 12];
      String var10002 = I[11 ^ 87];
      var10001 = I[200 ^ 149];
      var10000 = I[203 ^ 149];
      var10001 = I[116 ^ 43];
      var10002 = I[114 ^ 18];
      var10001 = I[8 ^ 105];
      var10000 = I[11 ^ 105];
      var10001 = I[19 ^ 112];
      var10002 = I[194 ^ 166];
      var10001 = I[49 ^ 84];
      var10000 = I[85 ^ 51];
      var10001 = I[161 ^ 198];
      var10002 = I[237 ^ 133];
      var10001 = I[238 ^ 135];
      I[244 ^ 158].length();
      I[101 ^ 14].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[85 ^ 57].length();
      I[35 ^ 78].length();
      var10003["".length()] = FACING;
      I[35 ^ 77].length();
      I[70 ^ 41].length();
      I[249 ^ 137].length();
      I[176 ^ 193].length();
      var10003[" ".length()] = PART;
      I[70 ^ 52].length();
      I[207 ^ 188].length();
      var10003["  ".length()] = OCCUPIED;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public static boolean func_193385_b(int var0) {
      int var10000;
      if ((var0 & (182 ^ 190)) != 0) {
         var10000 = " ".length();
         "".length();
         if (3 < 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
      if (var1.getValue(PART) == BlockBed.EnumPartType.HEAD) {
         var2 |= 86 ^ 94;
         if ((Boolean)var1.getValue(OCCUPIED)) {
            var2 |= 20 ^ 16;
         }
      }

      return var2;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean func_190946_v(IBlockState var1) {
      return (boolean)" ".length();
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      Item var10000;
      if (var1.getValue(PART) == BlockBed.EnumPartType.FOOT) {
         var10000 = Items.field_190931_a;
         "".length();
         if (4 < 1) {
            throw null;
         }
      } else {
         var10000 = Items.BED;
      }

      return var10000;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[225 ^ 177];
      String var10001 = I[210 ^ 131];
      String var10002 = I[85 ^ 7];
      var10001 = I[225 ^ 178];
      BlockPos var4 = var2;
      if (var3.getValue(PART) == BlockBed.EnumPartType.FOOT) {
         var4 = var2.offset((EnumFacing)var3.getValue(FACING));
      }

      TileEntity var5 = var1.getTileEntity(var4);
      EnumDyeColor var7;
      if (var5 instanceof TileEntityBed) {
         var7 = ((TileEntityBed)var5).func_193048_a();
         "".length();
         if (0 >= 1) {
            throw null;
         }
      } else {
         var7 = EnumDyeColor.RED;
      }

      EnumDyeColor var6 = var7;
      I[100 ^ 48].length();
      I[66 ^ 23].length();
      return new ItemStack(Items.BED, " ".length(), var6.getMetadata());
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      EnumFacing var6 = (EnumFacing)var1.getValue(FACING);
      if (var1.getValue(PART) == BlockBed.EnumPartType.FOOT) {
         if (var2.getBlockState(var3.offset(var6)).getBlock() != this) {
            var2.setBlockToAir(var3);
            I[178 ^ 157].length();
            I[125 ^ 77].length();
            I[106 ^ 91].length();
            I[117 ^ 71].length();
            "".length();
            if (1 <= -1) {
               throw null;
            }
         }
      } else if (var2.getBlockState(var3.offset(var6.getOpposite())).getBlock() != this) {
         if (!var2.isRemote) {
            this.dropBlockAsItem(var2, var3, var1, "".length());
         }

         var2.setBlockToAir(var3);
         I[27 ^ 40].length();
         I[55 ^ 3].length();
         I[72 ^ 125].length();
      }

   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, TileEntity var5, ItemStack var6) {
      if (var4.getValue(PART) == BlockBed.EnumPartType.HEAD && var5 instanceof TileEntityBed) {
         TileEntityBed var7 = (TileEntityBed)var5;
         ItemStack var8 = var7.func_193049_f();
         spawnAsEntity(var1, var3, var8);
         "".length();
         if (1 < 1) {
            throw null;
         }
      } else {
         super.harvestBlock(var1, var2, var3, var4, (TileEntity)null, var6);
      }

   }

   public void onLanded(World var1, Entity var2) {
      String var10000 = I[110 ^ 70];
      String var10001 = I[100 ^ 77];
      String var10002 = I[70 ^ 108];
      var10001 = I[7 ^ 44];
      if (var2.isSneaking()) {
         super.onLanded(var1, var2);
         "".length();
         if (-1 >= 0) {
            throw null;
         }
      } else if (var2.motionY < 0.0D) {
         var2.motionY = -var2.motionY * 0.6600000262260437D;
         if (!(var2 instanceof EntityLivingBase)) {
            I[63 ^ 19].length();
            I[111 ^ 66].length();
            I[92 ^ 114].length();
            var2.motionY *= 0.8D;
         }
      }

   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      if (var1.getValue(PART) == BlockBed.EnumPartType.FOOT) {
         IBlockState var4 = var2.getBlockState(var3.offset((EnumFacing)var1.getValue(FACING)));
         if (var4.getBlock() == this) {
            var1 = var1.withProperty(OCCUPIED, var4.getValue(OCCUPIED));
         }
      }

      return var1;
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[39 ^ 83];
      String var10001 = I[32 ^ 85];
      String var10002 = I[15 ^ 121];
      var10001 = I[30 ^ 105];
      I[251 ^ 131].length();
      I[64 ^ 57].length();
      I[48 ^ 74].length();
      return new TileEntityBed();
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   @Nullable
   public static BlockPos getSafeExitLocation(World var0, BlockPos var1, int var2) {
      String var10000 = I[56 ^ 14];
      String var10001 = I[32 ^ 23];
      String var10002 = I[96 ^ 88];
      var10001 = I[66 ^ 123];
      EnumFacing var3 = (EnumFacing)var0.getBlockState(var1).getValue(FACING);
      int var4 = var1.getX();
      int var5 = var1.getY();
      int var6 = var1.getZ();
      int var7 = "".length();

      do {
         if (var7 > " ".length()) {
            return null;
         }

         int var16 = var3.getFrontOffsetX() * var7;
         I[94 ^ 100].length();
         I[33 ^ 26].length();
         I[49 ^ 13].length();
         int var15 = var4 - var16;
         var16 = " ".length();
         I[129 ^ 188].length();
         I[188 ^ 130].length();
         I[185 ^ 134].length();
         int var8 = var15 - var16;
         var16 = var3.getFrontOffsetZ() * var7;
         I[26 ^ 90].length();
         I[231 ^ 166].length();
         I[49 ^ 115].length();
         var15 = var6 - var16;
         var16 = " ".length();
         I[210 ^ 145].length();
         I[108 ^ 40].length();
         int var9 = var15 - var16;
         int var10 = var8 + "  ".length();
         int var11 = var9 + "  ".length();
         int var12 = var8;

         while(var12 <= var10) {
            int var13 = var9;

            while(var13 <= var11) {
               I[244 ^ 177].length();
               I[233 ^ 175].length();
               I[123 ^ 60].length();
               I[61 ^ 117].length();
               BlockPos var14 = new BlockPos(var12, var5, var13);
               if (hasRoomForPlayer(var0, var14)) {
                  if (var2 <= 0) {
                     return var14;
                  }

                  --var2;
               }

               ++var13;
               "".length();
               if (4 == 2) {
                  throw null;
               }
            }

            ++var12;
            "".length();
            if (4 <= 1) {
               throw null;
            }
         }

         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 2);

      throw null;
   }

   @Nullable
   private EntityPlayer getPlayerInBed(World var1, BlockPos var2) {
      Iterator var3 = var1.playerEntities.iterator();

      do {
         if (!var3.hasNext()) {
            return null;
         }

         EntityPlayer var4 = (EntityPlayer)var3.next();
         if (var4.isPlayerSleeping() && var4.bedLocation.equals(var2)) {
            return var4;
         }

         "".length();
      } while(true);

      throw null;
   }

   public EnumPushReaction getMobilityFlag(IBlockState var1) {
      return EnumPushReaction.DESTROY;
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      if (var1.getValue(PART) == BlockBed.EnumPartType.FOOT) {
         TileEntity var4 = var2.getTileEntity(var3);
         if (var4 instanceof TileEntityBed) {
            EnumDyeColor var5 = ((TileEntityBed)var4).func_193048_a();
            return MapColor.func_193558_a(var5);
         }
      }

      return MapColor.CLOTH;
   }

   public IBlockState getStateFromMeta(int var1) {
      EnumFacing var2 = EnumFacing.byHorizontalIndex(var1);
      IBlockState var10000;
      if ((var1 & (151 ^ 159)) > 0) {
         var10000 = this.getDefaultState().withProperty(PART, BlockBed.EnumPartType.HEAD).withProperty(FACING, var2);
         PropertyBool var10001 = OCCUPIED;
         int var10002;
         if ((var1 & (161 ^ 165)) > 0) {
            var10002 = " ".length();
            "".length();
            if (-1 != -1) {
               throw null;
            }
         } else {
            var10002 = "".length();
         }

         var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
         "".length();
         if (4 <= 0) {
            throw null;
         }
      } else {
         var10000 = this.getDefaultState().withProperty(PART, BlockBed.EnumPartType.FOOT).withProperty(FACING, var2);
      }

      return var10000;
   }

   private static void I() {
      I = new String[101 ^ 24];
      I["".length()] = I("欸淜", "rHOxi");
      I[" ".length()] = I("挞暸", "zodec");
      I["  ".length()] = I("灕嫰", "EStgw");
      I["   ".length()] = I("掼扤", "vroAo");
      I[48 ^ 52] = I("檯崞", "zUVPm");
      I[95 ^ 90] = I("唈憧", "wfbNj");
      I[157 ^ 155] = I("濃屇", "HhbSO");
      I[95 ^ 88] = I("椑捓", "lyQdp");
      I[93 ^ 85] = I("崟櫐", "ABqle");
      I[100 ^ 109] = I("廯娼", "KwRoe");
      I[26 ^ 16] = I("烑柽", "AAiPU");
      I[24 ^ 19] = I("假旁", "rgBgT");
      I[31 ^ 19] = I("凎岄", "FwzNv");
      I[107 ^ 102] = I("卪杔", "pMefG");
      I[157 ^ 147] = I("抭嘜", "Dfyzv");
      I[52 ^ 59] = I("柙氭", "zaSpY");
      I[178 ^ 162] = I("殚汷瀆嚹", "qoDgG");
      I[166 ^ 183] = I("潾嗷枺呭敲", "BYAfp");
      I[5 ^ 23] = I("佧堁", "SwSJK");
      I[181 ^ 166] = I("壓姞打宥枋", "ihWmC");
      I[157 ^ 137] = I("\u0004\u001c\u0007!h\u0012\u0010\u000fj)\u0013\u0016\u001e4/\u0015\u0011", "pukDF");
      I[76 ^ 89] = I("夋心", "XGcsx");
      I[214 ^ 192] = I("中", "DxlsK");
      I[184 ^ 175] = I("敺", "xkDTl");
      I[186 ^ 162] = I("就巨椤", "lCzqm");
      I[187 ^ 162] = I("渒椁扥撂", "KIdKz");
      I[218 ^ 192] = I("汇搘嫦", "ykJjA");
      I[108 ^ 119] = I("媙", "eXtcU");
      I[7 ^ 27] = I("%#\u0005\u0013h3/\rX(>\u0019\u0005\u0013#!", "QJivF");
      I[172 ^ 177] = I("婢", "HkRLI");
      I[51 ^ 45] = I("仧廋屓吹", "XHkWx");
      I[140 ^ 147] = I("\u0010\u001b\u001a\u0016y\u0006\u0017\u0012]9\u000b\u0006%\u00121\u0001", "drvsW");
      I[48 ^ 16] = I("幠惱桂槽巵", "KRXMv");
      I[4 ^ 37] = I("孤彀噿嬘", "VokwR");
      I[94 ^ 124] = I("0\u00074\u0011B&\u000b<Z\u0018+\u0001\u001e\u0015\u001e\u0005\u00199\r", "DnXtl");
      I[132 ^ 167] = I("楧", "MuYVB");
      I[27 ^ 63] = I("亊挈", "cdwOS");
      I[70 ^ 99] = I("内憵仲叹崷", "inhll");
      I[130 ^ 164] = I("摗巉栙拙", "IAJLZ");
      I[159 ^ 184] = I("号榐兘寒懁", "OBYQM");
      I[24 ^ 48] = I("揇濛", "qGcRo");
      I[111 ^ 70] = I("挜尃", "WxYIl");
      I[35 ^ 9] = I("幼晏", "pGlEP");
      I[148 ^ 191] = I("晐噫", "shyRi");
      I[59 ^ 23] = I("溈", "rrNsT");
      I[188 ^ 145] = I("孌塒", "rQChZ");
      I[37 ^ 11] = I("汃", "kTECI");
      I[173 ^ 130] = I("掹檪涃惥寋", "GkyCw");
      I[15 ^ 63] = I("滭捶仁", "DEZyR");
      I[1 ^ 48] = I("捒灐受斳", "fwsuW");
      I[240 ^ 194] = I("帰", "gcVuC");
      I[23 ^ 36] = I("渍浔岺嫮伲", "RUDpb");
      I[57 ^ 13] = I("殾傲濁", "XjvMV");
      I[48 ^ 5] = I("櫋毂刅", "nqayk");
      I[15 ^ 57] = I("弦取", "zzjSz");
      I[58 ^ 13] = I("凑嫛", "qxNHU");
      I[174 ^ 150] = I("墖儣", "VtaDg");
      I[127 ^ 70] = I("泿妁", "cBozk");
      I[46 ^ 20] = I("剫掎", "aLCDy");
      I[55 ^ 12] = I("云", "gPpmx");
      I[250 ^ 198] = I("嗼寤嵝囹", "yINKb");
      I[118 ^ 75] = I("婴录", "HlvgD");
      I[33 ^ 31] = I("掹介煈暤", "LMKEQ");
      I[79 ^ 112] = I("上受", "TfDbE");
      I[238 ^ 174] = I("幹潖峳尹塋", "ONRBO");
      I[52 ^ 117] = I("匀憻", "XcqwK");
      I[206 ^ 140] = I("岿歶妑棪", "UDFzs");
      I[53 ^ 118] = I("慶抜", "xBbKj");
      I[93 ^ 25] = I("何券懤彞恹", "DURhZ");
      I[119 ^ 50] = I("桔湉毇煓", "rTMSW");
      I[118 ^ 48] = I("尮", "PyjwR");
      I[18 ^ 85] = I("僬夲", "tcRPb");
      I[67 ^ 11] = I("柁岸傌匧氯", "yMQYy");
      I[220 ^ 149] = I("櫌娉", "bfnnV");
      I[193 ^ 139] = I("渶恶", "igFgU");
      I[238 ^ 165] = I("吵桏", "jWaOP");
      I[43 ^ 103] = I("朶濗", "yaWFo");
      I[94 ^ 19] = I("媡", "TCQvw");
      I[245 ^ 187] = I("嵋", "cmvkf");
      I[33 ^ 110] = I("欵到汰吆桥", "MuPXx");
      I[27 ^ 75] = I("殜壚", "jWVxu");
      I[121 ^ 40] = I("亵洧", "XGhME");
      I[110 ^ 60] = I("潚怽", "FeTOU");
      I[38 ^ 117] = I("廬屍", "SLvUI");
      I[14 ^ 90] = I("天捥凝愥", "gdmMA");
      I[245 ^ 160] = I("殲掟坬", "CrQwA");
      I[200 ^ 158] = I("寳攰", "fCXSr");
      I[150 ^ 193] = I("俤", "lPKcw");
      I[206 ^ 150] = I("噚", "prsiX");
      I[67 ^ 26] = I("泑榉杣", "qgMVQ");
      I[48 ^ 106] = I("唦嗡", "PCKWH");
      I[247 ^ 172] = I("價淚", "RNSWC");
      I[19 ^ 79] = I("桮昝", "oEsew");
      I[83 ^ 14] = I("擱寻", "tgmLI");
      I[252 ^ 162] = I("埋樧", "hnHlI");
      I[202 ^ 149] = I("崻嶋", "rQWzI");
      I[213 ^ 181] = I("搹完", "uGwqx");
      I[55 ^ 86] = I("炲悦", "ZQfOc");
      I[222 ^ 188] = I("煌沏", "zDbuO");
      I[209 ^ 178] = I("忂涕", "jKfNG");
      I[122 ^ 30] = I("洳柟", "KJLzM");
      I[230 ^ 131] = I("懡恏", "jfyKT");
      I[61 ^ 91] = I("欹栽", "BmaEK");
      I[61 ^ 90] = I("嬶朽", "Auuwd");
      I[36 ^ 76] = I("焵尸", "rPGLQ");
      I[246 ^ 159] = I("澆屠", "ihalz");
      I[201 ^ 163] = I("濺歏审", "NXppX");
      I[18 ^ 121] = I("楉学", "XCwPh");
      I[66 ^ 46] = I("嬕敝姵樚", "YQFRJ");
      I[50 ^ 95] = I("昏", "kEQcv");
      I[209 ^ 191] = I("捾勌沚亄椣", "ZVsYz");
      I[11 ^ 100] = I("欣呞毫", "PAQIa");
      I[49 ^ 65] = I("凫捞梊旬", "ZOQYE");
      I[53 ^ 68] = I("巽擌毚奖棢", "JAESm");
      I[26 ^ 104] = I("摖廜攩", "HdilQ");
      I[207 ^ 188] = I("堺曰昉", "Zfgse");
      I[103 ^ 19] = I("撇弓", "oSYTc");
      I[26 ^ 111] = I("搽啃", "fvlyt");
      I[250 ^ 140] = I("姦凭", "oAysm");
      I[182 ^ 193] = I("捨亣", "xWoXN");
      I[252 ^ 132] = I("忐摗匽尨曮", "Mjjjh");
      I[240 ^ 137] = I("灅懄幒扱", "OGbsI");
      I[74 ^ 48] = I("囝岼", "mfRWI");
      I[104 ^ 19] = I("%7\u001c\u001b", "UVnoi");
      I[206 ^ 178] = I("(\"\u0004\u0007\n.$\u0003", "GAgrz");
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      super.breakBlock(var1, var2, var3);
      var1.removeTileEntity(var2);
   }

   protected static boolean hasRoomForPlayer(World var0, BlockPos var1) {
      int var10000;
      if (var0.getBlockState(var1.down()).isFullyOpaque() && !var0.getBlockState(var1).getMaterial().isSolid() && !var0.getBlockState(var1.up()).getMaterial().isSolid()) {
         var10000 = " ".length();
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      String var10000 = I[83 ^ 26];
      String var10001 = I[247 ^ 189];
      String var10002 = I[198 ^ 141];
      var10001 = I[126 ^ 50];
      if (var3.getValue(PART) == BlockBed.EnumPartType.HEAD) {
         TileEntity var6 = var1.getTileEntity(var2);
         EnumDyeColor var8;
         if (var6 instanceof TileEntityBed) {
            var8 = ((TileEntityBed)var6).func_193048_a();
            "".length();
            if (3 == -1) {
               throw null;
            }
         } else {
            var8 = EnumDyeColor.RED;
         }

         EnumDyeColor var7 = var8;
         I[215 ^ 154].length();
         I[25 ^ 87].length();
         I[7 ^ 72].length();
         spawnAsEntity(var1, var2, new ItemStack(Items.BED, " ".length(), var7.getMetadata()));
      }

   }

   public void onBlockHarvested(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      if (var4.capabilities.isCreativeMode && var3.getValue(PART) == BlockBed.EnumPartType.FOOT) {
         BlockPos var5 = var2.offset((EnumFacing)var3.getValue(FACING));
         if (var1.getBlockState(var5).getBlock() == this) {
            var1.setBlockToAir(var5);
            I[110 ^ 56].length();
            I[61 ^ 106].length();
            I[243 ^ 171].length();
            I[53 ^ 108].length();
         }
      }

   }

   public void onFallenUpon(World var1, BlockPos var2, Entity var3, float var4) {
      super.onFallenUpon(var1, var2, var3, var4 * 0.5F);
   }

   public BlockBed() {
      super(Material.CLOTH);
      this.setDefaultState(this.blockState.getBaseState().withProperty(PART, BlockBed.EnumPartType.FOOT).withProperty(OCCUPIED, Boolean.valueOf((boolean)"".length())));
      this.isBlockContainer = (boolean)" ".length();
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[26 ^ 30];
      var10001 = I[4 ^ 1];
      var10002 = I[98 ^ 100];
      var10001 = I[100 ^ 99];
      var10000 = I[145 ^ 153];
      var10001 = I[81 ^ 88];
      var10002 = I[55 ^ 61];
      var10001 = I[1 ^ 10];
      var10000 = I[64 ^ 76];
      var10001 = I[50 ^ 63];
      var10002 = I[135 ^ 137];
      var10001 = I[189 ^ 178];
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         if (var3.getValue(PART) != BlockBed.EnumPartType.HEAD) {
            var2 = var2.offset((EnumFacing)var3.getValue(FACING));
            var3 = var1.getBlockState(var2);
            if (var3.getBlock() != this) {
               return (boolean)" ".length();
            }
         }

         if (var1.provider.canRespawnHere() && var1.getBiome(var2) != Biomes.HELL) {
            if ((Boolean)var3.getValue(OCCUPIED)) {
               EntityPlayer var11 = this.getPlayerInBed(var1, var2);
               if (var11 != null) {
                  I[82 ^ 66].length();
                  I[25 ^ 8].length();
                  I[162 ^ 176].length();
                  I[66 ^ 81].length();
                  var4.addChatComponentMessage(new TextComponentTranslation(I[14 ^ 26], new Object["".length()]), (boolean)" ".length());
                  return (boolean)" ".length();
               }

               var3 = var3.withProperty(OCCUPIED, Boolean.valueOf((boolean)"".length()));
               var1.setBlockState(var2, var3, 35 ^ 39);
               I[99 ^ 118].length();
               I[79 ^ 89].length();
            }

            EntityPlayer.SleepResult var12 = var4.trySleep(var2);
            if (var12 == EntityPlayer.SleepResult.OK) {
               var3 = var3.withProperty(OCCUPIED, Boolean.valueOf((boolean)" ".length()));
               var1.setBlockState(var2, var3, 104 ^ 108);
               I[215 ^ 192].length();
               I[68 ^ 92].length();
               I[95 ^ 70].length();
               return (boolean)" ".length();
            } else {
               if (var12 == EntityPlayer.SleepResult.NOT_POSSIBLE_NOW) {
                  I[110 ^ 116].length();
                  I[78 ^ 85].length();
                  var4.addChatComponentMessage(new TextComponentTranslation(I[105 ^ 117], new Object["".length()]), (boolean)" ".length());
                  "".length();
                  if (4 <= 3) {
                     throw null;
                  }
               } else if (var12 == EntityPlayer.SleepResult.NOT_SAFE) {
                  I[39 ^ 58].length();
                  I[162 ^ 188].length();
                  var4.addChatComponentMessage(new TextComponentTranslation(I[119 ^ 104], new Object["".length()]), (boolean)" ".length());
                  "".length();
                  if (4 != 4) {
                     throw null;
                  }
               } else if (var12 == EntityPlayer.SleepResult.TOO_FAR_AWAY) {
                  I[182 ^ 150].length();
                  I[230 ^ 199].length();
                  var4.addChatComponentMessage(new TextComponentTranslation(I[126 ^ 92], new Object["".length()]), (boolean)" ".length());
               }

               return (boolean)" ".length();
            }
         } else {
            var1.setBlockToAir(var2);
            I[90 ^ 121].length();
            I[67 ^ 103].length();
            BlockPos var10 = var2.offset(((EnumFacing)var3.getValue(FACING)).getOpposite());
            if (var1.getBlockState(var10).getBlock() == this) {
               var1.setBlockToAir(var10);
               I[124 ^ 89].length();
            }

            var1.newExplosion((Entity)null, (double)var2.getX() + 0.5D, (double)var2.getY() + 0.5D, (double)var2.getZ() + 0.5D, 5.0F, (boolean)" ".length(), (boolean)" ".length());
            I[51 ^ 21].length();
            I[34 ^ 5].length();
            return (boolean)" ".length();
         }
      }
   }

   static {
      I();
      PART = PropertyEnum.create(I[209 ^ 170], BlockBed.EnumPartType.class);
      OCCUPIED = PropertyBool.create(I[92 ^ 32]);
      BED_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5625D, 1.0D);
   }

   public static enum EnumPartType implements IStringSerializable {
      // $FF: synthetic field
      FOOT,
      // $FF: synthetic field
      HEAD;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private static final String[] I;

      static {
         I();
         HEAD = new BlockBed.EnumPartType(I["".length()], "".length(), I[" ".length()]);
         FOOT = new BlockBed.EnumPartType(I["  ".length()], " ".length(), I["   ".length()]);
         BlockBed.EnumPartType[] var10000 = new BlockBed.EnumPartType["  ".length()];
         var10000["".length()] = HEAD;
         var10000[" ".length()] = FOOT;
      }

      private EnumPartType(String var3) {
         this.name = var3;
      }

      public String toString() {
         return this.name;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 != 3);

         throw null;
      }

      public String getName() {
         return this.name;
      }

      private static void I() {
         I = new String[90 ^ 94];
         I["".length()] = I("\f7\r5", "DrLqi");
         I[" ".length()] = I("\u0011\u0004\u00141", "yauUg");
         I["  ".length()] = I("3\u0000*3", "uOegy");
         I["   ".length()] = I("\u00175\u001d\u0011", "qZreZ");
      }
   }
}

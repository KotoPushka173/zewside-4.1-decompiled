package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockStainedHardenedClay extends BlockColored {
   // $FF: synthetic field
   private static final MapColor[] field_193389_b;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 3);

      throw null;
   }

   static {
      MapColor[] var10000 = new MapColor[133 ^ 149];
      var10000["".length()] = MapColor.field_193561_M;
      var10000[" ".length()] = MapColor.field_193562_N;
      var10000["  ".length()] = MapColor.field_193563_O;
      var10000["   ".length()] = MapColor.field_193564_P;
      var10000[53 ^ 49] = MapColor.field_193565_Q;
      var10000[38 ^ 35] = MapColor.field_193566_R;
      var10000[100 ^ 98] = MapColor.field_193567_S;
      var10000[115 ^ 116] = MapColor.field_193568_T;
      var10000[184 ^ 176] = MapColor.field_193569_U;
      var10000[191 ^ 182] = MapColor.field_193570_V;
      var10000[206 ^ 196] = MapColor.field_193571_W;
      var10000[36 ^ 47] = MapColor.field_193572_X;
      var10000[124 ^ 112] = MapColor.field_193573_Y;
      var10000[8 ^ 5] = MapColor.field_193574_Z;
      var10000[21 ^ 27] = MapColor.field_193559_aa;
      var10000[94 ^ 81] = MapColor.field_193560_ab;
      field_193389_b = var10000;
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return field_193389_b[((EnumDyeColor)var1.getValue(COLOR)).getMetadata()];
   }

   public BlockStainedHardenedClay() {
      super(Material.ROCK);
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketResourcePackSend implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private String url;
   // $FF: synthetic field
   private String hash;

   static {
      I();
   }

   public SPacketResourcePackSend() {
   }

   public String getURL() {
      return this.url;
   }

   private static void I() {
      I = new String[161 ^ 167];
      I["".length()] = I("\u0007\u000f\u001a\tf&\u001dI\u0015) N\u0005\u000e((NA\f'7N]Qjo\u0019\b\u0012f", "OniaF");
      I[" ".length()] = I("L", "ekRUM");
      I["  ".length()] = I("棗喘柜夭奭", "HmBOx");
      I["   ".length()] = I("恜哢巖掴瀪", "hgeXw");
      I[133 ^ 129] = I("徏滱椒墁厣", "OBAir");
      I[118 ^ 115] = I("歸", "Vnkxc");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.url = var1.readStringFromBuffer(29018 + 18045 - 29254 + 14958);
      this.hash = var1.readStringFromBuffer(148 ^ 188);
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleResourcePack(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.url);
      I["  ".length()].length();
      I["   ".length()].length();
      I[179 ^ 183].length();
      var1.writeString(this.hash);
      I[85 ^ 80].length();
   }

   public String getHash() {
      return this.hash;
   }

   public SPacketResourcePackSend(String var1, String var2) {
      this.url = var1;
      this.hash = var2;
      if (var2.length() > (178 ^ 154)) {
         throw new IllegalArgumentException(I["".length()] + var2.length() + I[" ".length()]);
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }
}

package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockColored extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<EnumDyeColor> COLOR;

   public BlockColored(Material var1) {
      super(var1);
      this.setDefaultState(this.blockState.getBaseState().withProperty(COLOR, EnumDyeColor.WHITE));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(COLOR, EnumDyeColor.byMetadata(var1));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= -1);

      throw null;
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.func_193558_a((EnumDyeColor)var1.getValue(COLOR));
   }

   public int damageDropped(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(COLOR)).getMetadata();
   }

   private static void I() {
      I = new String[140 ^ 154];
      I["".length()] = I("按嬋", "ESCxv");
      I[" ".length()] = I("桧侍", "BaOQU");
      I["  ".length()] = I("卝敪", "wPEym");
      I["   ".length()] = I("濌堶", "kRxIw");
      I[18 ^ 22] = I("奦枪", "sUDZb");
      I[50 ^ 55] = I("潨椼劔栏", "TJjwl");
      I[46 ^ 40] = I("煦壾", "RIAbl");
      I[135 ^ 128] = I("伔弙峥", "qskUI");
      I[187 ^ 179] = I("偝尲", "ayyjQ");
      I[139 ^ 130] = I("壧煄", "KGDJx");
      I[78 ^ 68] = I("塾澦", "slEvU");
      I[138 ^ 129] = I("溓个", "Ucofx");
      I[13 ^ 1] = I("坖剛", "SaWJm");
      I[32 ^ 45] = I("埏樯", "WkxdI");
      I[159 ^ 145] = I("淊廭", "FFauJ");
      I[1 ^ 14] = I("婂婹", "aIimr");
      I[177 ^ 161] = I("扝測歹嫞", "pzvvD");
      I[176 ^ 161] = I("濿憿哳値瀘", "mNEIZ");
      I[114 ^ 96] = I("倝澗峿", "wbCBs");
      I[4 ^ 23] = I("摑殗攈傔吟", "UBiXr");
      I[70 ^ 82] = I("澏斛枑", "lbcZx");
      I[189 ^ 168] = I("!\u001c\",+", "BsNCY");
   }

   static {
      I();
      COLOR = PropertyEnum.create(I[51 ^ 38], EnumDyeColor.class);
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(COLOR)).getMetadata();
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      EnumDyeColor[] var3 = EnumDyeColor.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         EnumDyeColor var6 = var3[var5];
         I[18 ^ 22].length();
         I[171 ^ 174].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[38 ^ 32].length();
         I[50 ^ 53].length();
         ++var5;
         "".length();
      } while(0 > -1);

      throw null;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[51 ^ 59];
      String var10001 = I[77 ^ 68];
      String var10002 = I[182 ^ 188];
      var10001 = I[206 ^ 197];
      var10000 = I[165 ^ 169];
      var10001 = I[22 ^ 27];
      var10002 = I[111 ^ 97];
      var10001 = I[100 ^ 107];
      I[169 ^ 185].length();
      I[74 ^ 91].length();
      I[38 ^ 52].length();
      I[14 ^ 29].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[30 ^ 10].length();
      var10003["".length()] = COLOR;
      return new BlockStateContainer(this, var10003);
   }
}

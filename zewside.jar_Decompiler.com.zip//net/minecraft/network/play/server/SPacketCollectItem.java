package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketCollectItem implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int field_191209_c;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private int collectedItemEntityId;

   public int func_191208_c() {
      return this.field_191209_c;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.collectedItemEntityId = var1.readVarIntFromBuffer();
      this.entityId = var1.readVarIntFromBuffer();
      this.field_191209_c = var1.readVarIntFromBuffer();
   }

   public int getEntityID() {
      return this.entityId;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.collectedItemEntityId);
      I["".length()].length();
      var1.writeVarIntToBuffer(this.entityId);
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeVarIntToBuffer(this.field_191209_c);
      I["   ".length()].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 2);

      throw null;
   }

   private static void I() {
      I = new String[58 ^ 62];
      I["".length()] = I("挾嗫嵎塢灒", "tkomK");
      I[" ".length()] = I("媸怜佪搖徑", "lheqB");
      I["  ".length()] = I("冸庌果儊嬪", "hZnNU");
      I["   ".length()] = I("呆", "hmxHf");
   }

   public int getCollectedItemEntityID() {
      return this.collectedItemEntityId;
   }

   public SPacketCollectItem() {
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleCollectItem(this);
   }

   public SPacketCollectItem(int var1, int var2, int var3) {
      this.collectedItemEntityId = var1;
      this.entityId = var2;
      this.field_191209_c = var3;
   }
}

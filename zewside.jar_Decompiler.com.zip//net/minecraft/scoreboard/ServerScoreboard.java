package net.minecraft.scoreboard;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketDisplayObjective;
import net.minecraft.network.play.server.SPacketScoreboardObjective;
import net.minecraft.network.play.server.SPacketTeams;
import net.minecraft.network.play.server.SPacketUpdateScore;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.PlayerList;

public class ServerScoreboard extends Scoreboard {
   // $FF: synthetic field
   private Runnable[] dirtyRunnables = new Runnable["".length()];
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Set<ScoreObjective> addedObjectives = Sets.newHashSet();
   // $FF: synthetic field
   private final MinecraftServer scoreboardMCServer;

   public int getObjectiveDisplaySlotCount(ScoreObjective var1) {
      int var2 = "".length();
      int var3 = "".length();

      do {
         if (var3 >= (9 ^ 26)) {
            return var2;
         }

         if (this.getObjectiveInDisplaySlot(var3) == var1) {
            ++var2;
         }

         ++var3;
         "".length();
      } while(3 >= 1);

      throw null;
   }

   public void setObjectiveInDisplaySlot(int var1, ScoreObjective var2) {
      String var10000 = I[1 ^ 21];
      String var10001 = I[50 ^ 39];
      String var10002 = I[144 ^ 134];
      var10001 = I[99 ^ 116];
      var10000 = I[76 ^ 84];
      var10001 = I[223 ^ 198];
      var10002 = I[20 ^ 14];
      var10001 = I[123 ^ 96];
      ScoreObjective var3 = this.getObjectiveInDisplaySlot(var1);
      super.setObjectiveInDisplaySlot(var1, var2);
      PlayerList var4;
      if (var3 != var2 && var3 != null) {
         if (this.getObjectiveDisplaySlotCount(var3) > 0) {
            var4 = this.scoreboardMCServer.getPlayerList();
            I[142 ^ 146].length();
            I[117 ^ 104].length();
            I[108 ^ 114].length();
            I[15 ^ 16].length();
            var4.sendPacketToAllPlayers(new SPacketDisplayObjective(var1, var2));
            "".length();
            if (2 <= 1) {
               throw null;
            }
         } else {
            this.sendDisplaySlotRemovalPackets(var3);
         }
      }

      if (var2 != null) {
         if (this.addedObjectives.contains(var2)) {
            var4 = this.scoreboardMCServer.getPlayerList();
            I[41 ^ 9].length();
            I[113 ^ 80].length();
            I[117 ^ 87].length();
            I[79 ^ 108].length();
            var4.sendPacketToAllPlayers(new SPacketDisplayObjective(var1, var2));
            "".length();
            if (false) {
               throw null;
            }
         } else {
            this.addObjective(var2);
         }
      }

      this.markSaveDataDirty();
   }

   public void broadcastScoreUpdate(String var1) {
      String var10000 = I[167 ^ 161];
      String var10001 = I[70 ^ 65];
      String var10002 = I[159 ^ 151];
      var10001 = I[41 ^ 32];
      super.broadcastScoreUpdate(var1);
      PlayerList var2 = this.scoreboardMCServer.getPlayerList();
      I[173 ^ 167].length();
      I[175 ^ 164].length();
      I[160 ^ 172].length();
      I[98 ^ 111].length();
      var2.sendPacketToAllPlayers(new SPacketUpdateScore(var1));
      this.markSaveDataDirty();
   }

   protected void markSaveDataDirty() {
      Runnable[] var1 = this.dirtyRunnables;
      int var2 = var1.length;
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            return;
         }

         Runnable var4 = var1[var3];
         var4.run();
         ++var3;
         "".length();
      } while(0 != 4);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 0);

      throw null;
   }

   public void onScoreUpdated(Score var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      super.onScoreUpdated(var1);
      if (this.addedObjectives.contains(var1.getObjective())) {
         PlayerList var2 = this.scoreboardMCServer.getPlayerList();
         I[5 ^ 1].length();
         I[33 ^ 36].length();
         var2.sendPacketToAllPlayers(new SPacketUpdateScore(var1));
      }

      this.markSaveDataDirty();
   }

   public ServerScoreboard(MinecraftServer var1) {
      this.scoreboardMCServer = var1;
   }

   public void onObjectiveDisplayNameChanged(ScoreObjective var1) {
      String var10000 = I[190 ^ 128];
      String var10001 = I[170 ^ 149];
      String var10002 = I[60 ^ 124];
      var10001 = I[19 ^ 82];
      super.onObjectiveDisplayNameChanged(var1);
      if (this.addedObjectives.contains(var1)) {
         PlayerList var2 = this.scoreboardMCServer.getPlayerList();
         I[237 ^ 175].length();
         I[242 ^ 177].length();
         I[225 ^ 165].length();
         I[117 ^ 48].length();
         var2.sendPacketToAllPlayers(new SPacketScoreboardObjective(var1, "  ".length()));
      }

      this.markSaveDataDirty();
   }

   public void broadcastTeamCreated(ScorePlayerTeam var1) {
      String var10000 = I[97 ^ 39];
      String var10001 = I[116 ^ 51];
      String var10002 = I[220 ^ 148];
      var10001 = I[79 ^ 6];
      super.broadcastTeamCreated(var1);
      PlayerList var2 = this.scoreboardMCServer.getPlayerList();
      I[34 ^ 104].length();
      I[47 ^ 100].length();
      I[220 ^ 144].length();
      var2.sendPacketToAllPlayers(new SPacketTeams(var1, "".length()));
      this.markSaveDataDirty();
   }

   public void sendDisplaySlotRemovalPackets(ScoreObjective var1) {
      List var2 = this.getDestroyPackets(var1);
      Iterator var3 = this.scoreboardMCServer.getPlayerList().getPlayerList().iterator();

      do {
         if (!var3.hasNext()) {
            this.addedObjectives.remove(var1);
            I[53 + 110 - 135 + 109].length();
            I[20 + 8 - -96 + 14].length();
            return;
         }

         EntityPlayerMP var4 = (EntityPlayerMP)var3.next();
         Iterator var5 = var2.iterator();

         while(var5.hasNext()) {
            Packet var6 = (Packet)var5.next();
            var4.connection.sendPacket(var6);
            "".length();
            if (3 == -1) {
               throw null;
            }
         }

         "".length();
      } while(2 != -1);

      throw null;
   }

   public void addObjective(ScoreObjective var1) {
      List var2 = this.getCreatePackets(var1);
      Iterator var3 = this.scoreboardMCServer.getPlayerList().getPlayerList().iterator();

      do {
         if (!var3.hasNext()) {
            this.addedObjectives.add(var1);
            I[64 ^ 55].length();
            I[89 ^ 33].length();
            return;
         }

         EntityPlayerMP var4 = (EntityPlayerMP)var3.next();
         Iterator var5 = var2.iterator();

         while(var5.hasNext()) {
            Packet var6 = (Packet)var5.next();
            var4.connection.sendPacket(var6);
            "".length();
            if (-1 != -1) {
               throw null;
            }
         }

         "".length();
      } while(4 > 0);

      throw null;
   }

   public void removePlayerFromTeam(String var1, ScorePlayerTeam var2) {
      String var10000 = I[153 ^ 168];
      String var10001 = I[140 ^ 190];
      String var10002 = I[246 ^ 197];
      var10001 = I[23 ^ 35];
      var10000 = I[178 ^ 135];
      var10001 = I[185 ^ 143];
      var10002 = I[164 ^ 147];
      var10001 = I[112 ^ 72];
      super.removePlayerFromTeam(var1, var2);
      PlayerList var3 = this.scoreboardMCServer.getPlayerList();
      I[57 ^ 0].length();
      I[9 ^ 51].length();
      I[169 ^ 146].length();
      String[] var10004 = new String[" ".length()];
      I[168 ^ 148].length();
      I[149 ^ 168].length();
      var10004["".length()] = var1;
      var3.sendPacketToAllPlayers(new SPacketTeams(var2, Arrays.asList(var10004), 152 ^ 156));
      this.markSaveDataDirty();
   }

   public void broadcastTeamRemove(ScorePlayerTeam var1) {
      String var10000 = I[44 ^ 120];
      String var10001 = I[32 ^ 117];
      String var10002 = I[210 ^ 132];
      var10001 = I[206 ^ 153];
      super.broadcastTeamRemove(var1);
      PlayerList var2 = this.scoreboardMCServer.getPlayerList();
      I[70 ^ 30].length();
      I[233 ^ 176].length();
      I[44 ^ 118].length();
      var2.sendPacketToAllPlayers(new SPacketTeams(var1, " ".length()));
      this.markSaveDataDirty();
   }

   public boolean addPlayerToTeam(String var1, String var2) {
      String var10000 = I[159 ^ 187];
      String var10001 = I[40 ^ 13];
      String var10002 = I[5 ^ 35];
      var10001 = I[99 ^ 68];
      var10000 = I[27 ^ 51];
      var10001 = I[169 ^ 128];
      var10002 = I[154 ^ 176];
      var10001 = I[165 ^ 142];
      if (super.addPlayerToTeam(var1, var2)) {
         ScorePlayerTeam var3 = this.getTeam(var2);
         PlayerList var4 = this.scoreboardMCServer.getPlayerList();
         I[83 ^ 127].length();
         I[133 ^ 168].length();
         I[142 ^ 160].length();
         String[] var10004 = new String[" ".length()];
         I[74 ^ 101].length();
         I[184 ^ 136].length();
         var10004["".length()] = var1;
         var4.sendPacketToAllPlayers(new SPacketTeams(var3, Arrays.asList(var10004), "   ".length()));
         this.markSaveDataDirty();
         return (boolean)" ".length();
      } else {
         return (boolean)"".length();
      }
   }

   public List<Packet<?>> getCreatePackets(ScoreObjective var1) {
      String var10000 = I[29 ^ 67];
      String var10001 = I[4 ^ 91];
      String var10002 = I[39 ^ 71];
      var10001 = I[48 ^ 81];
      var10000 = I[255 ^ 157];
      var10001 = I[202 ^ 169];
      var10002 = I[76 ^ 40];
      var10001 = I[193 ^ 164];
      var10000 = I[240 ^ 150];
      var10001 = I[124 ^ 27];
      var10002 = I[239 ^ 135];
      var10001 = I[126 ^ 23];
      ArrayList var2 = Lists.newArrayList();
      I[109 ^ 7].length();
      I[44 ^ 71].length();
      var2.add(new SPacketScoreboardObjective(var1, "".length()));
      I[168 ^ 196].length();
      I[57 ^ 84].length();
      int var3 = "".length();

      do {
         if (var3 >= (128 ^ 147)) {
            Iterator var5 = this.getSortedScores(var1).iterator();

            do {
               if (!var5.hasNext()) {
                  return var2;
               }

               Score var4 = (Score)var5.next();
               I[13 ^ 127].length();
               I[61 ^ 78].length();
               var2.add(new SPacketUpdateScore(var4));
               I[232 ^ 156].length();
               I[215 ^ 162].length();
               I[2 ^ 116].length();
               "".length();
            } while(4 == 4);

            throw null;
         }

         if (this.getObjectiveInDisplaySlot(var3) == var1) {
            I[207 ^ 161].length();
            I[113 ^ 30].length();
            var2.add(new SPacketDisplayObjective(var3, var1));
            I[73 ^ 57].length();
            I[202 ^ 187].length();
         }

         ++var3;
         "".length();
      } while(1 < 3);

      throw null;
   }

   public void addDirtyRunnable(Runnable var1) {
      this.dirtyRunnables = (Runnable[])((Runnable[])Arrays.copyOf(this.dirtyRunnables, this.dirtyRunnables.length + " ".length()));
      Runnable[] var10000 = this.dirtyRunnables;
      int var10001 = this.dirtyRunnables.length;
      int var10002 = " ".length();
      I[122 ^ 33].length();
      I[229 ^ 185].length();
      I[90 ^ 7].length();
      var10000[var10001 - var10002] = var1;
   }

   private static void I() {
      I = new String[130 + 9 - 30 + 30];
      I["".length()] = I("殩涕", "STZUv");
      I[" ".length()] = I("奢壶", "qNMxv");
      I["  ".length()] = I("屭俇", "lBEyS");
      I["   ".length()] = I("噧湂", "pwjii");
      I[96 ^ 100] = I("扼机桠", "AQeZX");
      I[55 ^ 50] = I("昼澏曒樵氂", "sRetA");
      I[128 ^ 134] = I("瀒勖", "jZNJH");
      I[127 ^ 120] = I("探漦", "QcdfZ");
      I[169 ^ 161] = I("治昀", "OPmTt");
      I[127 ^ 118] = I("沦垽", "yzUlG");
      I[177 ^ 187] = I("儦", "rcYfB");
      I[181 ^ 190] = I("掹昨旽檿", "CLqqV");
      I[147 ^ 159] = I("消嬋尼", "CypzS");
      I[91 ^ 86] = I("升卡濲愝", "wnuUo");
      I[40 ^ 38] = I("亰哿", "hHLhm");
      I[159 ^ 144] = I("唂殗", "wCqFl");
      I[62 ^ 46] = I("唫濞", "ITYwl");
      I[179 ^ 162] = I("瀒泆", "nWTOQ");
      I[111 ^ 125] = I("旜後焧孈", "jjeyi");
      I[40 ^ 59] = I("曶昳嶭", "iIAeI");
      I[137 ^ 157] = I("滷庇", "UyaHd");
      I[92 ^ 73] = I("妘匮", "Yyutg");
      I[111 ^ 121] = I("惨灣", "OSVvq");
      I[190 ^ 169] = I("押呃", "RlwQb");
      I[151 ^ 143] = I("旄憷", "kSHSh");
      I[60 ^ 37] = I("忳孳", "tdltl");
      I[64 ^ 90] = I("勶奒", "IJNLe");
      I[102 ^ 125] = I("刧坻", "hHNeU");
      I[222 ^ 194] = I("改權濌", "JBABf");
      I[160 ^ 189] = I("毣怣揢", "WkLHT");
      I[186 ^ 164] = I("怳撏尳彝", "wrcsl");
      I[182 ^ 169] = I("掞七", "fPiPZ");
      I[92 ^ 124] = I("瀣", "lnYNR");
      I[37 ^ 4] = I("嬻", "YOAKV");
      I[164 ^ 134] = I("沏嬲", "mSaTy");
      I[111 ^ 76] = I("妡", "DTIAm");
      I[157 ^ 185] = I("擬懪", "TDdWH");
      I[131 ^ 166] = I("嘣倄", "eongi");
      I[5 ^ 35] = I("儍嘵", "eZxeX");
      I[8 ^ 47] = I("橤敝", "tFhlZ");
      I[134 ^ 174] = I("抁囍", "uSCFc");
      I[66 ^ 107] = I("巧瀓", "VMnUA");
      I[36 ^ 14] = I("欱潇", "crBoj");
      I[21 ^ 62] = I("欸孂", "aYDld");
      I[136 ^ 164] = I("掊嘥", "EcsLU");
      I[161 ^ 140] = I("椇媌", "KKfyQ");
      I[1 ^ 47] = I("煄", "PTChV");
      I[59 ^ 20] = I("敜溎扆", "rAsLu");
      I[153 ^ 169] = I("涙", "bsFwN");
      I[114 ^ 67] = I("暖愌", "bOoEV");
      I[182 ^ 132] = I("煡剸", "cVTMZ");
      I[44 ^ 31] = I("潛庣", "pHqGN");
      I[84 ^ 96] = I("滹檫", "aHBka");
      I[178 ^ 135] = I("哇昀", "CcacH");
      I[72 ^ 126] = I("敞慀", "OQbfD");
      I[165 ^ 146] = I("媼仸", "rfHTT");
      I[75 ^ 115] = I("婿炐", "eSADJ");
      I[173 ^ 148] = I("捼寔斣偟", "fnXKI");
      I[8 ^ 50] = I("圶溑柅", "eiDCB");
      I[130 ^ 185] = I("慻", "dDBzA");
      I[103 ^ 91] = I("濊攈极傅", "NLdAx");
      I[100 ^ 89] = I("巟", "AVPLN");
      I[169 ^ 151] = I("壞曱", "ZRzsu");
      I[168 ^ 151] = I("嫋忯", "PDoUi");
      I[133 ^ 197] = I("壵杽", "UqceL");
      I[98 ^ 35] = I("啢杊", "AZhhV");
      I[25 ^ 91] = I("湵揦勨溿涴", "irnKN");
      I[215 ^ 148] = I("冑", "nMAAk");
      I[20 ^ 80] = I("奰", "hwoLq");
      I[98 ^ 39] = I("堄姸槜摑", "NnerI");
      I[83 ^ 21] = I("挍傏", "fuqay");
      I[245 ^ 178] = I("劄刲", "JQlda");
      I[94 ^ 22] = I("妢檛", "vkFyO");
      I[196 ^ 141] = I("崸沫", "notlM");
      I[236 ^ 166] = I("欙怨", "tGdhA");
      I[108 ^ 39] = I("帚", "BgSVG");
      I[3 ^ 79] = I("曊嶤桰巿启", "uSdnb");
      I[5 ^ 72] = I("媢槥", "iKDpq");
      I[100 ^ 42] = I("栻徝", "rRuVr");
      I[82 ^ 29] = I("汴惰", "ZKkUa");
      I[229 ^ 181] = I("彷圳", "beJlf");
      I[107 ^ 58] = I("嶑兾", "jSuon");
      I[62 ^ 108] = I("斂撽拳", "ERciw");
      I[199 ^ 148] = I("曬", "wzPwY");
      I[252 ^ 168] = I("員浢", "pqRdB");
      I[33 ^ 116] = I("慚性", "Thlsh");
      I[205 ^ 155] = I("僝淳", "BtTfH");
      I[102 ^ 49] = I("匲垔", "irCBK");
      I[110 ^ 54] = I("傅", "Lomux");
      I[227 ^ 186] = I("愤", "tymEJ");
      I[237 ^ 183] = I("歪每", "yliqS");
      I[44 ^ 119] = I("嬩儶", "XhkXg");
      I[73 ^ 21] = I("囁", "SWZWB");
      I[88 ^ 5] = I("暞哹", "PRwxb");
      I[193 ^ 159] = I("友愣", "dLJdF");
      I[211 ^ 140] = I("儧挗", "ZKmnI");
      I[105 ^ 9] = I("划夜", "fIqxz");
      I[59 ^ 90] = I("嗞匚", "hnHdC");
      I[201 ^ 171] = I("学晋", "Uolsq");
      I[236 ^ 143] = I("倔椞", "bgOFa");
      I[1 ^ 101] = I("冦幘", "qlzXl");
      I[20 ^ 113] = I("楴峴", "yWudO");
      I[223 ^ 185] = I("噩宸", "dXTwB");
      I[162 ^ 197] = I("孭槨", "YzfvR");
      I[15 ^ 103] = I("夥摕", "euCIm");
      I[241 ^ 152] = I("拞怨", "TPiQw");
      I[61 ^ 87] = I("兗撿刵梒", "RiYhq");
      I[64 ^ 43] = I("倲攂廭", "jPqVy");
      I[169 ^ 197] = I("漐嵾", "nguLd");
      I[216 ^ 181] = I("峮嬔", "JfOMZ");
      I[26 ^ 116] = I("煥惧卖", "GsrYj");
      I[169 ^ 198] = I("咉", "gHZtn");
      I[6 ^ 118] = I("兕", "CdFso");
      I[243 ^ 130] = I("枇崽毬毬桃", "GWuUT");
      I[200 ^ 186] = I("婧煫瀿滿", "VLtVl");
      I[253 ^ 142] = I("炢戥昙儀嶯", "UEiIL");
      I[51 ^ 71] = I("務呁挎优恮", "xmYht");
      I[86 ^ 35] = I("潉潐櫺娒", "EAAhN");
      I[69 ^ 51] = I("乖曏宝即樅", "jsqkr");
      I[222 ^ 169] = I("以", "qWgoF");
      I[194 ^ 186] = I("叱", "Qvszh");
      I[218 ^ 163] = I("梋峥", "DidJN");
      I[242 ^ 136] = I("傚喔", "jbCXN");
      I[103 ^ 28] = I("殔濻", "DHmJQ");
      I[48 ^ 76] = I("兹棤", "pMteb");
      I[33 ^ 92] = I("嬘喡", "vBdjw");
      I[102 ^ 24] = I("桥变", "KoCEU");
      I[94 + 4 - 94 + 123] = I("烅从", "xxBqX");
      I[1 + 3 - -109 + 15] = I("崩既", "jUGzu");
      I[118 + 58 - 171 + 124] = I("围", "vaPiG");
      I[122 + 64 - 76 + 20] = I("彉栂", "FcVcz");
      I[17 + 39 - -54 + 21] = I("淪怤", "gyIoG");
      I[76 + 77 - 93 + 72] = I("火", "pFOyL");
      I[61 + 56 - 98 + 114] = I("棎欯", "sqZrA");
      I[35 + 30 - -57 + 12] = I("嬤", "oBABv");
      I[59 + 107 - 88 + 57] = I("昨櫁", "hryCZ");
      I[6 + 114 - 4 + 20] = I("廑奞棧揥拜", "lQSlf");
      I[117 + 31 - 11 + 0] = I("歚", "ceYGI");
      I[86 + 85 - 34 + 1] = I("偟劆", "YUCgM");
   }

   public void broadcastScoreUpdate(String var1, ScoreObjective var2) {
      String var10000 = I[10 ^ 4];
      String var10001 = I[42 ^ 37];
      String var10002 = I[166 ^ 182];
      var10001 = I[108 ^ 125];
      super.broadcastScoreUpdate(var1, var2);
      PlayerList var3 = this.scoreboardMCServer.getPlayerList();
      I[29 ^ 15].length();
      I[44 ^ 63].length();
      var3.sendPacketToAllPlayers(new SPacketUpdateScore(var1, var2));
      this.markSaveDataDirty();
   }

   public void broadcastTeamInfoUpdate(ScorePlayerTeam var1) {
      String var10000 = I[25 ^ 84];
      String var10001 = I[96 ^ 46];
      String var10002 = I[253 ^ 178];
      var10001 = I[71 ^ 23];
      super.broadcastTeamInfoUpdate(var1);
      PlayerList var2 = this.scoreboardMCServer.getPlayerList();
      I[121 ^ 40].length();
      I[127 ^ 45].length();
      I[12 ^ 95].length();
      var2.sendPacketToAllPlayers(new SPacketTeams(var1, "  ".length()));
      this.markSaveDataDirty();
   }

   public void onScoreObjectiveRemoved(ScoreObjective var1) {
      super.onScoreObjectiveRemoved(var1);
      if (this.addedObjectives.contains(var1)) {
         this.sendDisplaySlotRemovalPackets(var1);
      }

      this.markSaveDataDirty();
   }

   public void onScoreObjectiveAdded(ScoreObjective var1) {
      super.onScoreObjectiveAdded(var1);
      this.markSaveDataDirty();
   }

   static {
      I();
   }

   public List<Packet<?>> getDestroyPackets(ScoreObjective var1) {
      String var10000 = I[241 ^ 136];
      String var10001 = I[189 ^ 199];
      String var10002 = I[250 ^ 129];
      var10001 = I[45 ^ 81];
      var10000 = I[249 ^ 132];
      var10001 = I[81 ^ 47];
      var10002 = I[76 + 106 - 173 + 118];
      var10001 = I[41 + 6 - 7 + 88];
      ArrayList var2 = Lists.newArrayList();
      I[101 + 70 - 64 + 22].length();
      I[37 + 70 - 72 + 95].length();
      I[75 + 66 - 139 + 129].length();
      var2.add(new SPacketScoreboardObjective(var1, " ".length()));
      I[3 + 82 - -10 + 37].length();
      I[131 + 73 - 170 + 99].length();
      int var3 = "".length();

      do {
         if (var3 >= (66 ^ 81)) {
            return var2;
         }

         if (this.getObjectiveInDisplaySlot(var3) == var1) {
            I[117 + 20 - 7 + 4].length();
            I[55 + 119 - 142 + 103].length();
            var2.add(new SPacketDisplayObjective(var3, var1));
            I[114 + 69 - 128 + 81].length();
         }

         ++var3;
         "".length();
      } while(0 < 4);

      throw null;
   }
}

package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.potion.PotionType;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class BrewedPotionTrigger implements ICriterionTrigger<BrewedPotionTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_192176_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, BrewedPotionTrigger.Listeners> field_192177_b = Maps.newHashMap();

   public BrewedPotionTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[164 ^ 171];
      String var10001 = I[50 ^ 34];
      String var10002 = I[56 ^ 41];
      var10001 = I[133 ^ 151];
      var10000 = I[45 ^ 62];
      var10001 = I[150 ^ 130];
      var10002 = I[52 ^ 33];
      var10001 = I[154 ^ 140];
      var10000 = I[58 ^ 45];
      var10001 = I[93 ^ 69];
      var10002 = I[219 ^ 194];
      var10001 = I[157 ^ 135];
      var10000 = I[31 ^ 4];
      var10001 = I[142 ^ 146];
      var10002 = I[179 ^ 174];
      var10001 = I[71 ^ 89];
      PotionType var3 = null;
      if (var1.has(I[104 ^ 119])) {
         I[122 ^ 90].length();
         I[74 ^ 107].length();
         I[0 ^ 34].length();
         ResourceLocation var4 = new ResourceLocation(JsonUtils.getString(var1, I[178 ^ 145]));
         if (!PotionType.REGISTRY.containsKey(var4)) {
            I[41 ^ 13].length();
            I[76 ^ 105].length();
            JsonSyntaxException var5 = new JsonSyntaxException(I[94 ^ 120] + var4 + I[95 ^ 120]);
            I[239 ^ 199].length();
            I[170 ^ 131].length();
            I[123 ^ 81].length();
            throw var5;
         }

         var3 = (PotionType)PotionType.REGISTRY.getObject(var4);
      }

      I[6 ^ 45].length();
      return new BrewedPotionTrigger.Instance(var3);
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<BrewedPotionTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      BrewedPotionTrigger.Listeners var3 = (BrewedPotionTrigger.Listeners)this.field_192177_b.get(var1);
      if (var3 == null) {
         I[141 ^ 137].length();
         I[89 ^ 92].length();
         var3 = new BrewedPotionTrigger.Listeners(var1);
         this.field_192177_b.put(var1, var3);
         I[173 ^ 171].length();
         I[88 ^ 95].length();
         I[27 ^ 19].length();
         I[11 ^ 2].length();
      }

      var3.func_192349_a(var2);
   }

   public ResourceLocation func_192163_a() {
      return field_192176_a;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<BrewedPotionTrigger.Instance> var2) {
      BrewedPotionTrigger.Listeners var3 = (BrewedPotionTrigger.Listeners)this.field_192177_b.get(var1);
      if (var3 != null) {
         var3.func_192346_b(var2);
         if (var3.func_192347_a()) {
            this.field_192177_b.remove(var1);
            I[124 ^ 118].length();
            I[64 ^ 75].length();
         }
      }

   }

   static {
      I();
      field_192176_a = new ResourceLocation(I[127 ^ 83]);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 3);

      throw null;
   }

   private static void I() {
      I = new String[95 ^ 114];
      I["".length()] = I("擨吹", "gkdpe");
      I[" ".length()] = I("涧榑", "teEAV");
      I["  ".length()] = I("準涊", "atVLo");
      I["   ".length()] = I("奶帉", "vwWUf");
      I[34 ^ 38] = I("暐", "cLIPB");
      I[194 ^ 199] = I("姚擫愧", "NLCNk");
      I[178 ^ 180] = I("沑厄", "NCnvY");
      I[138 ^ 141] = I("倾庵撐埼摟", "iBIyc");
      I[188 ^ 180] = I("昄", "WPSCy");
      I[54 ^ 63] = I("孯倬垞欘", "iSujs");
      I[54 ^ 60] = I("僸漮哬烖", "QwuEj");
      I[182 ^ 189] = I("妘", "JPxkF");
      I[187 ^ 183] = I("戟坵", "rJuJK");
      I[3 ^ 14] = I("抂啉巈廌揲", "yHQgd");
      I[61 ^ 51] = I("汫暤拯僼录", "eRpaF");
      I[66 ^ 77] = I("桴伻", "uddlf");
      I[148 ^ 132] = I("懓她", "sMBgz");
      I[179 ^ 162] = I("寃殮", "JAdcU");
      I[52 ^ 38] = I("梞樉", "fukGL");
      I[213 ^ 198] = I("烧棽", "QxNUb");
      I[24 ^ 12] = I("捐强", "YkmNF");
      I[58 ^ 47] = I("恖喕", "hpYSa");
      I[23 ^ 1] = I("嚞崏", "cUzaU");
      I[111 ^ 120] = I("晛嶒", "IXOwj");
      I[137 ^ 145] = I("惹歛", "wJhPh");
      I[26 ^ 3] = I("喡将", "EiuRC");
      I[0 ^ 26] = I("嶆劷", "RBcUR");
      I[61 ^ 38] = I("垜噞", "OqhVd");
      I[162 ^ 190] = I("匑刋", "YKkHA");
      I[47 ^ 50] = I("欙嶒", "FMstr");
      I[138 ^ 148] = I("堞栮", "QjvYQ");
      I[31 ^ 0] = I(")\u0007\u0012(#7", "YhfAL");
      I[135 ^ 167] = I("埳", "oLRfR");
      I[49 ^ 16] = I("姜哈", "bBXkR");
      I[174 ^ 140] = I("棬兲夙懝", "SIABZ");
      I[8 ^ 43] = I("\u0002\u000e&/\r\u001c", "raRFb");
      I[230 ^ 194] = I("侯嵩榡", "BMvSd");
      I[144 ^ 181] = I("厺櫼忬暟", "azLJb");
      I[138 ^ 172] = I("\u0000&#\u0019.\"&h\u0007.!!'\u0019ar", "UHHwA");
      I[57 ^ 30] = I("n", "IiXcP");
      I[232 ^ 192] = I("樳互", "TNDKR");
      I[139 ^ 162] = I("巏樳挌倰", "rrsjP");
      I[40 ^ 2] = I("彐厠刔姈", "ESRNE");
      I[168 ^ 131] = I("攅", "OauvF");
      I[8 ^ 36] = I("\u0005#\u0012\u0016=\u0003\u000e\u0007\u000e,\u000e>\u0019", "gQwaX");
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192177_b.remove(var1);
      I[13 ^ 1].length();
      I[167 ^ 170].length();
      I[9 ^ 7].length();
   }

   public void func_192173_a(EntityPlayerMP var1, PotionType var2) {
      BrewedPotionTrigger.Listeners var3 = (BrewedPotionTrigger.Listeners)this.field_192177_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_192348_a(var2);
      }

   }

   static class Listeners {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<BrewedPotionTrigger.Instance>> field_192351_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_192350_a;

      public void func_192346_b(ICriterionTrigger.Listener<BrewedPotionTrigger.Instance> var1) {
         this.field_192351_b.remove(var1);
         I[194 ^ 198].length();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192350_a = var1;
      }

      public boolean func_192347_a() {
         return this.field_192351_b.isEmpty();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 != -1);

         throw null;
      }

      static {
         I();
      }

      private static void I() {
         I = new String[32 ^ 39];
         I["".length()] = I("暂冟擨", "eObQs");
         I[" ".length()] = I("樉嶽嗣揂", "nxSFN");
         I["  ".length()] = I("椓溕侓涅婬", "iNZqN");
         I["   ".length()] = I("懥呑無卅悳", "WNeTw");
         I[158 ^ 154] = I("冊乣梍慶", "LUlXN");
         I[5 ^ 0] = I("炳惥仮", "lLwti");
         I[193 ^ 199] = I("灈劍", "CYnQf");
      }

      public void func_192348_a(PotionType var1) {
         ArrayList var2 = null;
         Iterator var3 = this.field_192351_b.iterator();

         ICriterionTrigger.Listener var4;
         while(var3.hasNext()) {
            var4 = (ICriterionTrigger.Listener)var3.next();
            if (((BrewedPotionTrigger.Instance)var4.func_192158_a()).func_192250_a(var1)) {
               if (var2 == null) {
                  var2 = Lists.newArrayList();
               }

               var2.add(var4);
               I[4 ^ 1].length();
               I[61 ^ 59].length();
            }

            "".length();
            if (4 <= 0) {
               throw null;
            }
         }

         if (var2 != null) {
            var3 = var2.iterator();

            while(var3.hasNext()) {
               var4 = (ICriterionTrigger.Listener)var3.next();
               var4.func_192159_a(this.field_192350_a);
               "".length();
               if (4 < 4) {
                  throw null;
               }
            }
         }

      }

      public void func_192349_a(ICriterionTrigger.Listener<BrewedPotionTrigger.Instance> var1) {
         this.field_192351_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final PotionType field_192251_a;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 == 4);

         throw null;
      }

      public boolean func_192250_a(PotionType var1) {
         int var10000;
         if (this.field_192251_a != null && this.field_192251_a != var1) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (0 == 2) {
               throw null;
            }
         }

         return (boolean)var10000;
      }

      public Instance(@Nullable PotionType var1) {
         super(BrewedPotionTrigger.field_192176_a);
         this.field_192251_a = var1;
      }
   }
}

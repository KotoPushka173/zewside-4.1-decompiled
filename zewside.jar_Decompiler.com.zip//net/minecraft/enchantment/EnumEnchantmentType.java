package net.minecraft.enchantment;

import net.minecraft.block.BlockPumpkin;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemSkull;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public enum EnumEnchantmentType {
   // $FF: synthetic field
   WEAPON,
   // $FF: synthetic field
   BREAKABLE,
   // $FF: synthetic field
   FISHING_ROD,
   // $FF: synthetic field
   WEARABLE,
   // $FF: synthetic field
   DIGGER,
   // $FF: synthetic field
   ARMOR_LEGS,
   // $FF: synthetic field
   ARMOR,
   // $FF: synthetic field
   BOW,
   // $FF: synthetic field
   ARMOR_FEET;

   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   ALL,
   // $FF: synthetic field
   ARMOR_HEAD,
   // $FF: synthetic field
   ARMOR_CHEST;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 2);

      throw null;
   }

   public abstract boolean canEnchantItem(Item var1);

   private EnumEnchantmentType() {
   }

   static {
      I();
      ALL = new EnumEnchantmentType(I["".length()], "".length()) {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(true);

            throw null;
         }

         public boolean canEnchantItem(Item var1) {
            EnumEnchantmentType[] var2 = EnumEnchantmentType.values();
            int var3 = var2.length;
            int var4 = "".length();

            do {
               if (var4 >= var3) {
                  return (boolean)"".length();
               }

               EnumEnchantmentType var5 = var2[var4];
               if (var5 != EnumEnchantmentType.ALL && var5.canEnchantItem(var1)) {
                  return (boolean)" ".length();
               }

               ++var4;
               "".length();
            } while(4 >= -1);

            throw null;
         }
      };
      ARMOR = new EnumEnchantmentType(I[" ".length()], " ".length()) {
         public boolean canEnchantItem(Item var1) {
            return var1 instanceof ItemArmor;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 == 3);

            throw null;
         }
      };
      ARMOR_FEET = new EnumEnchantmentType(I["  ".length()], "  ".length()) {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 == -1);

            throw null;
         }

         public boolean canEnchantItem(Item var1) {
            int var10000;
            if (var1 instanceof ItemArmor && ((ItemArmor)var1).armorType == EntityEquipmentSlot.FEET) {
               var10000 = " ".length();
               "".length();
               if (-1 == 3) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      };
      ARMOR_LEGS = new EnumEnchantmentType(I["   ".length()], "   ".length()) {
         public boolean canEnchantItem(Item var1) {
            int var10000;
            if (var1 instanceof ItemArmor && ((ItemArmor)var1).armorType == EntityEquipmentSlot.LEGS) {
               var10000 = " ".length();
               "".length();
               if (3 == 1) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(0 < 4);

            throw null;
         }
      };
      ARMOR_CHEST = new EnumEnchantmentType(I[29 ^ 25], 132 ^ 128) {
         public boolean canEnchantItem(Item var1) {
            int var10000;
            if (var1 instanceof ItemArmor && ((ItemArmor)var1).armorType == EntityEquipmentSlot.CHEST) {
               var10000 = " ".length();
               "".length();
               if (false) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 > 3);

            throw null;
         }
      };
      ARMOR_HEAD = new EnumEnchantmentType(I[25 ^ 28], 40 ^ 45) {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 < 4);

            throw null;
         }

         public boolean canEnchantItem(Item var1) {
            int var10000;
            if (var1 instanceof ItemArmor && ((ItemArmor)var1).armorType == EntityEquipmentSlot.HEAD) {
               var10000 = " ".length();
               "".length();
               if (2 >= 4) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      };
      WEAPON = new EnumEnchantmentType(I[86 ^ 80], 154 ^ 156) {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 >= 0);

            throw null;
         }

         public boolean canEnchantItem(Item var1) {
            return var1 instanceof ItemSword;
         }
      };
      DIGGER = new EnumEnchantmentType(I[80 ^ 87], 122 ^ 125) {
         public boolean canEnchantItem(Item var1) {
            return var1 instanceof ItemTool;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(1 < 2);

            throw null;
         }
      };
      FISHING_ROD = new EnumEnchantmentType(I[76 ^ 68], 117 ^ 125) {
         public boolean canEnchantItem(Item var1) {
            return var1 instanceof ItemFishingRod;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(0 >= 0);

            throw null;
         }
      };
      BREAKABLE = new EnumEnchantmentType(I[17 ^ 24], 179 ^ 186) {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 > 0);

            throw null;
         }

         public boolean canEnchantItem(Item var1) {
            return var1.isDamageable();
         }
      };
      BOW = new EnumEnchantmentType(I[152 ^ 146], 43 ^ 33) {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 < 0);

            throw null;
         }

         public boolean canEnchantItem(Item var1) {
            return var1 instanceof ItemBow;
         }
      };
      WEARABLE = new EnumEnchantmentType(I[93 ^ 86], 120 ^ 115) {
         public boolean canEnchantItem(Item var1) {
            int var10000;
            if (var1 instanceof ItemBlock && ((ItemBlock)var1).getBlock() instanceof BlockPumpkin) {
               var10000 = " ".length();
               "".length();
               if (false) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            int var2 = var10000;
            if (!(var1 instanceof ItemArmor) && !(var1 instanceof ItemElytra) && !(var1 instanceof ItemSkull) && var2 == 0) {
               var10000 = "".length();
            } else {
               var10000 = " ".length();
               "".length();
               if (2 >= 4) {
                  throw null;
               }
            }

            return (boolean)var10000;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(true);

            throw null;
         }
      };
      EnumEnchantmentType[] var10000 = new EnumEnchantmentType[65 ^ 77];
      var10000["".length()] = ALL;
      var10000[" ".length()] = ARMOR;
      var10000["  ".length()] = ARMOR_FEET;
      var10000["   ".length()] = ARMOR_LEGS;
      var10000[197 ^ 193] = ARMOR_CHEST;
      var10000[16 ^ 21] = ARMOR_HEAD;
      var10000[170 ^ 172] = WEAPON;
      var10000[77 ^ 74] = DIGGER;
      var10000[40 ^ 32] = FISHING_ROD;
      var10000[92 ^ 85] = BREAKABLE;
      var10000[163 ^ 169] = BOW;
      var10000[28 ^ 23] = WEARABLE;
   }

   // $FF: synthetic method
   EnumEnchantmentType(Object var3) {
      this();
   }

   private static void I() {
      I = new String[34 ^ 46];
      I["".length()] = I("5<#", "tpocE");
      I[" ".length()] = I("\u00125\u001d!\u001b", "SgPnI");
      I["  ".length()] = I(",\u0014\" \u001e2\u0000**\u0018", "mFooL");
      I["   ".length()] = I("+\u0005\u0014\u001c\u00045\u001b\u001c\u0014\u0005", "jWYSV");
      I[190 ^ 186] = I("\u0006 *;\u0011\u00181/1\u0010\u0013", "GrgtC");
      I[85 ^ 80] = I("-?\u0014\r\u00173%\u001c\u0003\u0001", "lmYBE");
      I[92 ^ 90] = I("\u0002\u0014\r97\u001b", "UQLix");
      I[63 ^ 56] = I("\u0013:\u000147\u0005", "WsFsr");
      I[183 ^ 191] = I("0(\">!8&.$'2", "vaqvh");
      I[59 ^ 50] = I(":\u0014\u000e*#9\u0004\u0007.", "xFKkh");
      I[135 ^ 141] = I("2\"\u0016", "pmAua");
      I[22 ^ 29] = I("=\u0007\t44(\u000e\r", "jBHfu");
   }
}

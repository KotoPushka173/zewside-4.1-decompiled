package net.minecraft.block.state;

import com.google.common.base.Function;
import com.google.common.base.MoreObjects;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.ImmutableCollection;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSortedMap;
import com.google.common.collect.ImmutableTable;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.UnmodifiableIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.regex.Pattern;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BitArray;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MapPopulator;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Cartesian;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IBlockStatePalette;
import net.minecraftforge.common.property.IUnlistedProperty;
import optifine.BlockModelUtils;
import optifine.Reflector;
import optifine.ReflectorConstructor;
import optifine.ReflectorMethod;

public class BlockStateContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected BitArray storage;
   // $FF: synthetic field
   private final ImmutableSortedMap<String, IProperty<?>> properties;
   // $FF: synthetic field
   private static final Pattern NAME_PATTERN;
   // $FF: synthetic field
   private static final Function<IProperty<?>, String> GET_NAME_FUNC;
   // $FF: synthetic field
   protected IBlockStatePalette palette;
   // $FF: synthetic field
   private final Block block;
   // $FF: synthetic field
   private final ImmutableList<IBlockState> validStates;

   private static void I() {
      I = new String[83 ^ 99];
      I["".length()] = I("烺寗", "ZQRqy");
      I[" ".length()] = I("宔悻", "RlGGU");
      I["  ".length()] = I("敥剣", "tWRLS");
      I["   ".length()] = I("摵奿", "tqQxG");
      I[15 ^ 11] = I("櫀殒亼", "CEOad");
      I[9 ^ 12] = I("母偨廜", "BcChc");
      I[73 ^ 79] = I("体啬唿峗欌", "UkDYa");
      I[90 ^ 93] = I("杝曆準溃", "zCPdw");
      I[157 ^ 149] = I("瀟媕晘", "XUubf");
      I[75 ^ 66] = I("棶徠", "yzLHc");
      I[48 ^ 58] = I("椢孃", "XTRgW");
      I[60 ^ 55] = I("扶怱", "mFPDK");
      I[114 ^ 126] = I("敀洇", "TYNRV");
      I[91 ^ 86] = I("堎愽", "tShCb");
      I[178 ^ 188] = I("剀垙", "FDVIU");
      I[91 ^ 84] = I("河櫬", "vbgyO");
      I[27 ^ 11] = I("倥兔", "btSMD");
      I[164 ^ 181] = I("嫘嶙", "Rboxv");
      I[47 ^ 61] = I("囉堾", "JTCxZ");
      I[132 ^ 151] = I("撦圠", "ScgOR");
      I[100 ^ 112] = I("征棃", "ytMWL");
      I[187 ^ 174] = I("昱嵝", "RChwt");
      I[26 ^ 12] = I("巪庈", "VqIgb");
      I[140 ^ 155] = I("嶶嬡", "EQZuF");
      I[88 ^ 64] = I("啄勰", "IdIkz");
      I[15 ^ 22] = I("凸溾寇姩櫁", "yoquL");
      I[160 ^ 186] = I("勢嚯", "AvMhg");
      I[60 ^ 39] = I("俈團擖嘏", "RzeIr");
      I[134 ^ 154] = I("唍倹叠瀤", "vopPQ");
      I[145 ^ 140] = I("15*\u0011 Iy", "sYErK");
      I[138 ^ 148] = I("g,2$s.*%6?. ?.s)%>27g4!8#\"6'.ig", "GDSWS");
      I[2 ^ 29] = I("樷傭", "CAVCW");
      I[160 ^ 128] = I("樕伊", "YOauR");
      I[175 ^ 142] = I("椟", "GfEUH");
      I[69 ^ 103] = I("嫾濆枲漘", "aicid");
      I[147 ^ 176] = I("俇勹撀动", "RGibk");
      I[173 ^ 137] = I("标俷", "oudAn");
      I[67 ^ 102] = I("2\u0015\u0017\u0017.JY", "pyxtE");
      I[62 ^ 24] = I("N\u00076\u0010G\u001e\u001d8\u0013\u0002\u001c\u001b.YG", "noWcg");
      I[151 ^ 176] = I("l:\u0010\u00018l$\u0017\u00031 $\u001d\u0019)l#\u0018\u00185(m\u000f\u0014<9(CU", "LMyuP");
      I[78 ^ 102] = I("壝啻振烤", "uxpVu");
      I[108 ^ 69] = I("榙煥剩搲啲", "wztml");
      I[161 ^ 139] = I("歲栝暢櫩", "wrceF");
      I[119 ^ 92] = I("媄扒", "vCmAY");
      I[182 ^ 154] = I("售", "GYSSA");
      I[30 ^ 51] = I("09 \u0012&", "RUOqM");
      I[167 ^ 137] = I("5\u001c\u000b(\u00167\u001a\r=\u0000", "EndXs");
      I[125 ^ 82] = I("\u0019?\u0006g4wI^\u0015\u0013l@", "GdgJN");
   }

   public static <T extends Comparable<T>> String validateProperty(Block var0, IProperty<T> var1) {
      String var10000 = I[138 ^ 131];
      String var10001 = I[21 ^ 31];
      String var10002 = I[49 ^ 58];
      var10001 = I[77 ^ 65];
      var10000 = I[161 ^ 172];
      var10001 = I[95 ^ 81];
      var10002 = I[19 ^ 28];
      var10001 = I[1 ^ 17];
      var10000 = I[77 ^ 92];
      var10001 = I[143 ^ 157];
      var10002 = I[74 ^ 89];
      var10001 = I[172 ^ 184];
      var10000 = I[169 ^ 188];
      var10001 = I[167 ^ 177];
      var10002 = I[175 ^ 184];
      var10001 = I[19 ^ 11];
      String var2 = var1.getName();
      IllegalArgumentException var6;
      if (!NAME_PATTERN.matcher(var2).matches()) {
         I[50 ^ 43].length();
         I[16 ^ 10].length();
         I[95 ^ 68].length();
         I[180 ^ 168].length();
         var6 = new IllegalArgumentException(I[128 ^ 157] + var0.getClass() + I[15 ^ 17] + var2);
         I[92 ^ 67].length();
         I[30 ^ 62].length();
         throw var6;
      } else {
         Iterator var3 = var1.getAllowedValues().iterator();

         do {
            if (!var3.hasNext()) {
               return var2;
            }

            Comparable var4 = (Comparable)var3.next();
            String var5 = var1.getName(var4);
            if (!NAME_PATTERN.matcher(var5).matches()) {
               I[159 ^ 190].length();
               I[77 ^ 111].length();
               I[125 ^ 94].length();
               I[45 ^ 9].length();
               var6 = new IllegalArgumentException(I[29 ^ 56] + var0.getClass() + I[177 ^ 151] + var2 + I[142 ^ 169] + var5);
               I[53 ^ 29].length();
               I[78 ^ 103].length();
               throw var6;
            }

            "".length();
         } while(3 != 2);

         throw null;
      }
   }

   public BlockStateContainer(Block var1, IProperty<?>... var2) {
      this(var1, var2, (ImmutableMap)null);
   }

   public Collection<IProperty<?>> getProperties() {
      return this.properties.values();
   }

   public ImmutableList<IBlockState> getValidStates() {
      return this.validStates;
   }

   protected BlockStateContainer(Block var1, IProperty<?>[] var2, ImmutableMap<IUnlistedProperty<?>, Optional<?>> var3) {
      this.block = var1;
      HashMap var4 = Maps.newHashMap();
      IProperty[] var5 = var2;
      int var6 = var2.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            this.properties = ImmutableSortedMap.copyOf(var4);
            LinkedHashMap var11 = Maps.newLinkedHashMap();
            ArrayList var12 = Lists.newArrayList();
            Iterator var13 = Cartesian.cartesianProduct(this.getAllowedValues()).iterator();

            do {
               if (!var13.hasNext()) {
                  var13 = var12.iterator();

                  do {
                     if (!var13.hasNext()) {
                        this.validStates = ImmutableList.copyOf(var12);
                        return;
                     }

                     BlockStateContainer.StateImplementation var15 = (BlockStateContainer.StateImplementation)var13.next();
                     var15.buildPropertyValueTable(var11);
                     "".length();
                  } while(4 > 3);

                  throw null;
               }

               List var14 = (List)var13.next();
               Map var9 = MapPopulator.createMap(this.properties.values(), var14);
               BlockStateContainer.StateImplementation var10 = this.createState(var1, ImmutableMap.copyOf(var9), var3);
               var11.put(var9, var10);
               var12.add(var10);
               "".length();
            } while(4 >= 0);

            throw null;
         }

         IProperty var8 = var5[var7];
         validateProperty(var1, var8);
         var4.put(var8.getName(), var8);
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   protected BlockStateContainer.StateImplementation createState(Block var1, ImmutableMap<IProperty<?>, Comparable<?>> var2, @Nullable ImmutableMap<IUnlistedProperty<?>, Optional<?>> var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[191 ^ 187].length();
      I[72 ^ 77].length();
      I[25 ^ 31].length();
      I[105 ^ 110].length();
      I[130 ^ 138].length();
      return new BlockStateContainer.StateImplementation(var1, var2);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   public String toString() {
      return MoreObjects.toStringHelper(this).add(I[67 ^ 110], Block.REGISTRY.getNameForObject(this.block)).add(I[103 ^ 73], Iterables.transform(this.properties.values(), GET_NAME_FUNC)).toString();
   }

   public IBlockState getBaseState() {
      return (IBlockState)this.validStates.get("".length());
   }

   @Nullable
   public IProperty<?> getProperty(String var1) {
      return (IProperty)this.properties.get(var1);
   }

   public Block getBlock() {
      return this.block;
   }

   private List<Iterable<Comparable<?>>> getAllowedValues() {
      ArrayList var1 = Lists.newArrayList();
      ImmutableCollection var2 = this.properties.values();
      UnmodifiableIterator var3 = var2.iterator();

      do {
         if (!var3.hasNext()) {
            return var1;
         }

         IProperty var4 = (IProperty)var3.next();
         var1.add(var4.getAllowedValues());
         I[21 ^ 63].length();
         I[49 ^ 26].length();
         I[99 ^ 79].length();
         "".length();
      } while(3 < 4);

      throw null;
   }

   static {
      I();
      NAME_PATTERN = Pattern.compile(I[177 ^ 158]);
      GET_NAME_FUNC = new Function<IProperty<?>, String>() {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 > -1);

            throw null;
         }

         private static void I() {
            I = new String[" ".length()];
            I["".length()] = I("s\u00140\u0000#q", "OZeLo");
         }

         @Nullable
         public String apply(@Nullable IProperty<?> var1) {
            String var10000;
            if (var1 == null) {
               var10000 = I["".length()];
               "".length();
               if (3 < -1) {
                  throw null;
               }
            } else {
               var10000 = var1.getName();
            }

            return var10000;
         }
      };
   }

   static class StateImplementation extends BlockStateBase {
      // $FF: synthetic field
      private final ImmutableMap<IProperty<?>, Comparable<?>> properties;
      // $FF: synthetic field
      private ImmutableTable<IProperty<?>, Comparable<?>, IBlockState> propertyValueTable;
      // $FF: synthetic field
      private final Block block;
      // $FF: synthetic field
      private static final String[] I;

      public boolean func_191058_s() {
         return this.block.causesSuffocation(this);
      }

      public <T extends Comparable<T>, V extends T> IBlockState withProperty(IProperty<T> var1, V var2) {
         String var10000 = I[26 ^ 14];
         String var10001 = I[75 ^ 94];
         String var10002 = I[189 ^ 171];
         var10001 = I[134 ^ 145];
         var10000 = I[66 ^ 90];
         var10001 = I[126 ^ 103];
         var10002 = I[95 ^ 69];
         var10001 = I[153 ^ 130];
         var10000 = I[145 ^ 141];
         var10001 = I[42 ^ 55];
         var10002 = I[219 ^ 197];
         var10001 = I[29 ^ 2];
         var10000 = I[100 ^ 68];
         var10001 = I[73 ^ 104];
         var10002 = I[112 ^ 82];
         var10001 = I[4 ^ 39];
         Comparable var3 = (Comparable)this.properties.get(var1);
         IllegalArgumentException var5;
         if (var3 == null) {
            I[26 ^ 62].length();
            I[124 ^ 89].length();
            I[167 ^ 129].length();
            I[92 ^ 123].length();
            I[39 ^ 15].length();
            I[99 ^ 74].length();
            var5 = new IllegalArgumentException(I[48 ^ 26] + var1 + I[19 ^ 56] + this.block.getBlockState());
            I[11 ^ 39].length();
            I[237 ^ 192].length();
            I[235 ^ 197].length();
            throw var5;
         } else if (var3 == var2) {
            return this;
         } else {
            IBlockState var4 = (IBlockState)this.propertyValueTable.get(var1, var2);
            if (var4 == null) {
               I[235 ^ 196].length();
               I[6 ^ 54].length();
               I[113 ^ 64].length();
               I[122 ^ 72].length();
               I[172 ^ 159].length();
               I[43 ^ 31].length();
               var5 = new IllegalArgumentException(I[189 ^ 136] + var1 + I[150 ^ 160] + var2 + I[70 ^ 113] + Block.REGISTRY.getNameForObject(this.block) + I[70 ^ 126]);
               I[96 ^ 89].length();
               throw var5;
            } else {
               return var4;
            }
         }
      }

      public boolean doesSideBlockRendering(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
         String var10000 = I[109 + 22 - 85 + 92];
         String var10001 = I[41 + 63 - -32 + 3];
         String var10002 = I[0 + 137 - 15 + 18];
         var10001 = I[84 + 125 - 173 + 105];
         var10000 = I[21 + 132 - 140 + 129];
         var10001 = I[24 + 121 - 93 + 91];
         var10002 = I[85 + 53 - 57 + 63];
         var10001 = I[103 + 45 - 37 + 34];
         var10000 = I[126 + 102 - 209 + 127];
         var10001 = I[29 + 141 - 133 + 110];
         var10002 = I[47 + 65 - -11 + 25];
         var10001 = I[118 + 109 - 91 + 13];
         var10000 = I[49 + 36 - -61 + 4];
         var10001 = I[96 + 120 - 111 + 46];
         var10002 = I[92 + 99 - 160 + 121];
         var10001 = I[79 + 95 - 106 + 85];
         Block var4 = this.block;
         ReflectorMethod var6 = Reflector.ForgeBlock_doesSideBlockRendering;
         Object[] var5 = new Object[9 ^ 13];
         I[72 + 52 - 28 + 58].length();
         I[84 + 85 - 81 + 67].length();
         I[18 + 44 - -37 + 57].length();
         var5["".length()] = this;
         I[41 + 19 - -43 + 54].length();
         I[42 + 131 - 104 + 89].length();
         var5[" ".length()] = var1;
         I[145 + 124 - 228 + 118].length();
         I[68 + 15 - -59 + 18].length();
         var5["  ".length()] = var2;
         I[32 + 9 - -21 + 99].length();
         I[83 + 54 - 136 + 161].length();
         I[44 + 96 - 85 + 108].length();
         I[123 + 162 - 246 + 125].length();
         var5["   ".length()] = var3;
         return Reflector.callBoolean(var4, var6, var5);
      }

      public Vec3d func_191059_e(IBlockAccess var1, BlockPos var2) {
         return this.block.func_190949_e(this, var1, var2);
      }

      public boolean onBlockEventReceived(World var1, BlockPos var2, int var3, int var4) {
         return this.block.eventReceived(this, var1, var2, var3, var4);
      }

      public int getLightOpacity(IBlockAccess var1, BlockPos var2) {
         String var10000 = I[108 ^ 39];
         String var10001 = I[220 ^ 144];
         String var10002 = I[247 ^ 186];
         var10001 = I[212 ^ 154];
         var10000 = I[102 ^ 41];
         var10001 = I[97 ^ 49];
         var10002 = I[39 ^ 118];
         var10001 = I[204 ^ 158];
         var10000 = I[107 ^ 56];
         var10001 = I[25 ^ 77];
         var10002 = I[207 ^ 154];
         var10001 = I[7 ^ 81];
         Block var3 = this.block;
         ReflectorMethod var4 = Reflector.ForgeBlock_getLightOpacity;
         Object[] var5 = new Object["   ".length()];
         I[237 ^ 186].length();
         var5["".length()] = this;
         I[206 ^ 150].length();
         I[87 ^ 14].length();
         var5[" ".length()] = var1;
         I[17 ^ 75].length();
         I[58 ^ 97].length();
         var5["  ".length()] = var2;
         return Reflector.callInt(var3, var4, var5);
      }

      public boolean isBlockNormalCube() {
         return this.block.isBlockNormalCube(this);
      }

      public BlockFaceShape func_193401_d(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
         return this.block.func_193383_a(var1, this, var2, var3);
      }

      public boolean isFullCube() {
         return this.block.isFullCube(this);
      }

      public int getWeakPower(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
         return this.block.getWeakPower(this, var1, var2, var3);
      }

      public boolean hasComparatorInputOverride() {
         return this.block.hasComparatorInputOverride(this);
      }

      public MapColor getMapColor(IBlockAccess var1, BlockPos var2) {
         return this.block.getMapColor(this, var1, var2);
      }

      public void neighborChanged(World var1, BlockPos var2, Block var3, BlockPos var4) {
         this.block.neighborChanged(this, var1, var2, var3, var4);
      }

      public float getPlayerRelativeBlockHardness(EntityPlayer var1, World var2, BlockPos var3) {
         return this.block.getPlayerRelativeBlockHardness(this, var1, var2, var3);
      }

      public int getLightOpacity() {
         return this.block.getLightOpacity(this);
      }

      public AxisAlignedBB getSelectedBoundingBox(World var1, BlockPos var2) {
         return this.block.getSelectedBoundingBox(this, var1, var2);
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 == 2);

         throw null;
      }

      public EnumPushReaction getMobilityFlag() {
         return this.block.getMobilityFlag(this);
      }

      public void buildPropertyValueTable(Map<Map<IProperty<?>, Comparable<?>>, BlockStateContainer.StateImplementation> var1) {
         String var10000 = I[3 ^ 57];
         String var10001 = I[178 ^ 137];
         String var10002 = I[91 ^ 103];
         var10001 = I[108 ^ 81];
         if (this.propertyValueTable != null) {
            I[91 ^ 101].length();
            IllegalStateException var8 = new IllegalStateException();
            I[63 ^ 0].length();
            I[117 ^ 53].length();
            I[52 ^ 117].length();
            throw var8;
         } else {
            HashBasedTable var2 = HashBasedTable.create();
            UnmodifiableIterator var3 = this.properties.entrySet().iterator();

            do {
               if (!var3.hasNext()) {
                  this.propertyValueTable = ImmutableTable.copyOf(var2);
                  return;
               }

               Entry var4 = (Entry)var3.next();
               IProperty var5 = (IProperty)var4.getKey();
               Iterator var6 = var5.getAllowedValues().iterator();

               while(var6.hasNext()) {
                  Comparable var7 = (Comparable)var6.next();
                  if (var7 != var4.getValue()) {
                     var2.put(var5, var7, var1.get(this.getPropertiesWithValue(var5, var7)));
                     I[15 ^ 77].length();
                     I[80 ^ 19].length();
                     I[31 ^ 91].length();
                     I[230 ^ 163].length();
                     I[200 ^ 142].length();
                  }

                  "".length();
                  if (4 <= -1) {
                     throw null;
                  }
               }

               "".length();
            } while(3 >= 2);

            throw null;
         }
      }

      private static void I() {
         I = new String[126 + 131 - 159 + 67];
         I["".length()] = I("婜份", "yxKNk");
         I[" ".length()] = I("晒戩", "BWJKW");
         I["  ".length()] = I("塓寻", "LqDvY");
         I["   ".length()] = I("国榊", "QfKuI");
         I[163 ^ 167] = I("摤值", "xWHTI");
         I[191 ^ 186] = I("啓峯", "VuVbH");
         I[109 ^ 107] = I("凡欎", "SWuZh");
         I[90 ^ 93] = I("栍墋", "vfFPq");
         I[119 ^ 127] = I("毉园", "eTwmp");
         I[114 ^ 123] = I("控晊泋", "geZdf");
         I[24 ^ 18] = I("澭庙亏", "UJScp");
         I[142 ^ 133] = I("嬆啑勫梓瀲", "btvJp");
         I[140 ^ 128] = I("恨", "EXgza");
         I[76 ^ 65] = I("\u001a\u001b:%(-Z3.3y\n&$7<\b 2g", "YzTKG");
         I[134 ^ 136] = I("d\t*Y\r0H=\u0016\u00017H7\u0016\u0010d\r!\u0010\u00170H0\u0017D", "DhYyd");
         I[130 ^ 141] = I("整浼庺掃完", "WzMcv");
         I[42 ^ 58] = I("涌吲", "pDgSs");
         I[182 ^ 167] = I("嚜剻撏卺撗", "uUsZE");
         I[133 ^ 151] = I("僠", "TaJfm");
         I[2 ^ 17] = I("廒悽", "yYLWC");
         I[53 ^ 33] = I("梳渿", "qJRAU");
         I[210 ^ 199] = I("坉娪", "vsRHa");
         I[74 ^ 92] = I("沪抟", "UMuDS");
         I[149 ^ 130] = I("嫪夾", "ItQqO");
         I[124 ^ 100] = I("刓恀", "nmfQw");
         I[35 ^ 58] = I("嘙瀈", "seuII");
         I[174 ^ 180] = I("殸出", "wIdaZ");
         I[55 ^ 44] = I("椹押", "KfnTM");
         I[109 ^ 113] = I("愁恔", "vjwVB");
         I[16 ^ 13] = I("嬐券", "KJWHp");
         I[39 ^ 57] = I("懖倁", "tJYNa");
         I[141 ^ 146] = I("啐搟", "ASimR");
         I[103 ^ 71] = I("掱搮", "JaxYA");
         I[150 ^ 183] = I("漭垯", "lTrxR");
         I[146 ^ 176] = I("侐渏", "CWknX");
         I[81 ^ 114] = I("桏湶", "yAwCp");
         I[43 ^ 15] = I("婥围", "kDjtf");
         I[51 ^ 22] = I("切俟濒", "PDybF");
         I[125 ^ 91] = I("嶂夹", "ICztq");
         I[61 ^ 26] = I("侏檚埾", "OqCcv");
         I[167 ^ 143] = I("塏", "sdzIq");
         I[139 ^ 162] = I("旂枔", "ShwPl");
         I[28 ^ 54] = I("\t4\u0003\u001d\u000e>u\u001e\u0016\u0015j%\u001f\u001c\u0011/'\u0019\nA", "JUmsa");
         I[130 ^ 169] = I("I/8x#\u001dn/7/\u001an%7>I+319\u001dn\"6j", "iNKXJ");
         I[136 ^ 164] = I("嚻懝", "bBjZv");
         I[12 ^ 33] = I("侼橮橛岓", "FXnhg");
         I[126 ^ 80] = I("幅槧嘖峵", "mCfXc");
         I[4 ^ 43] = I("校梃傮", "udrmR");
         I[132 ^ 180] = I("慣煌", "NOhoC");
         I[139 ^ 186] = I("刺尀樼斐", "Rpccl");
         I[122 ^ 72] = I("杇勀敞", "WymNk");
         I[151 ^ 164] = I("戧墤", "aUzcD");
         I[162 ^ 150] = I("嬶勱", "gdHET");
         I[32 ^ 21] = I("\u001a\u0005\"?6-D?4-y\u0014>>)<\u00168(y", "YdLQY");
         I[95 ^ 105] = I("d\u001a$A", "DnKaD");
         I[161 ^ 150] = I("j\u0017(b*&\u0017%)h", "JxFBH");
         I[54 ^ 14] = I("hS\u000b%h-\u0000B?'0S\u0003?h%\u001f\u000e>?!\u0017B')(\u0006\u0007", "DsbQH");
         I[182 ^ 143] = I("柑瀺儩偔", "fhlWW");
         I[14 ^ 52] = I("欪儐", "YVvfC");
         I[133 ^ 190] = I("叫洴", "VuDDj");
         I[173 ^ 145] = I("戲未", "tDqAD");
         I[14 ^ 51] = I("令揇", "pSGBe");
         I[166 ^ 152] = I("槭屎", "kfXcQ");
         I[7 ^ 56] = I("姧切夠伅杨", "sINMG");
         I[249 ^ 185] = I("僵妤嚙济徵", "iKQeV");
         I[85 ^ 20] = I("楏", "eLFsg");
         I[67 ^ 1] = I("泿恄倮", "Cbvtl");
         I[40 ^ 107] = I("孕剎幽戫", "irPsr");
         I[9 ^ 77] = I("朳", "fSQsr");
         I[226 ^ 167] = I("佣櫣儡嫵", "YGpMz");
         I[12 ^ 74] = I("嗹橎堊恽", "DlgQM");
         I[73 ^ 14] = I("屪枛毽厶", "Bgoio");
         I[225 ^ 169] = I("倽毙", "Lcijd");
         I[68 ^ 13] = I("悅庀朅峰佸", "lqbjR");
         I[58 ^ 112] = I("偤氹浻侘", "atKGD");
         I[241 ^ 186] = I("桪唧", "Osoww");
         I[9 ^ 69] = I("昄怸", "ebgGG");
         I[122 ^ 55] = I("搒橈", "DffCT");
         I[250 ^ 180] = I("哝帩", "PiGia");
         I[77 ^ 2] = I("孧嬜", "WZhvt");
         I[12 ^ 92] = I("享溕", "mmfQQ");
         I[147 ^ 194] = I("僯墫", "BbBQl");
         I[6 ^ 84] = I("听堬", "kEgzG");
         I[111 ^ 60] = I("抈姐", "FfLCr");
         I[40 ^ 124] = I("卍寘", "gpOUu");
         I[103 ^ 50] = I("枕槢", "azwJP");
         I[30 ^ 72] = I("异径", "oqoDZ");
         I[67 ^ 20] = I("攗憿寓収樾", "rENjq");
         I[101 ^ 61] = I("厾濥欑弹濡", "OByqg");
         I[43 ^ 114] = I("坮", "sWesV");
         I[118 ^ 44] = I("慥泲儱", "IaKPg");
         I[13 ^ 86] = I("照剈", "QBMdW");
         I[11 ^ 87] = I("俊拌", "qMDwO");
         I[244 ^ 169] = I("丣泝", "ixfWc");
         I[89 ^ 7] = I("欰攘", "LPYXE");
         I[47 ^ 112] = I("尧游", "xrSSZ");
         I[12 ^ 108] = I("戵吃", "DjaEc");
         I[97 ^ 0] = I("俤孉", "gwnrp");
         I[52 ^ 86] = I("烨叀", "bIccd");
         I[217 ^ 186] = I("峀剾", "JDRqH");
         I[83 ^ 55] = I("忿亞", "NXsdG");
         I[253 ^ 152] = I("坑崿", "QgqlR");
         I[203 ^ 173] = I("浍愮", "LmDLE");
         I[73 ^ 46] = I("値壯", "sqral");
         I[16 ^ 120] = I("慼昚撂嶛", "jgWZg");
         I[216 ^ 177] = I("姜嵒惢涍慒", "SXDTr");
         I[193 ^ 171] = I("廵幹", "ubmWo");
         I[121 ^ 18] = I("拵墶", "YkZnp");
         I[170 ^ 198] = I("咞", "KgKxJ");
         I[48 ^ 93] = I("煓楈廡巉前", "phmEb");
         I[103 ^ 9] = I("桄晄", "OTBNV");
         I[3 ^ 108] = I("暶勞", "eHbox");
         I[183 ^ 199] = I("庤曊佝岰", "rFyBm");
         I[5 ^ 116] = I("堨瀭", "pltjr");
         I[250 ^ 136] = I("倆愐", "glGMG");
         I[94 ^ 45] = I("埲槶", "qIbXf");
         I[59 ^ 79] = I("嵠伇", "GhgXC");
         I[125 ^ 8] = I("淒巘", "hFasY");
         I[98 ^ 20] = I("侍兞", "biXlp");
         I[233 ^ 158] = I("叆潥", "GzjmC");
         I[26 ^ 98] = I("扨塿", "nGsCp");
         I[89 ^ 32] = I("樮坠", "Rfmtn");
         I[122 ^ 0] = I("傓搢", "Lnolo");
         I[76 ^ 55] = I("曔搰", "CheWC");
         I[51 ^ 79] = I("溑僜", "yCTYe");
         I[52 ^ 73] = I("劗喔", "NJZym");
         I[233 ^ 151] = I("氷加", "rpGcK");
         I[71 + 7 - 68 + 117] = I("崔峚", "RTvVb");
         I[14 + 61 - -43 + 10] = I("揩炚", "TcIxt");
         I[27 + 106 - 87 + 83] = I("濼檩", "enBiv");
         I[65 + 20 - 20 + 65] = I("煤框", "klREV");
         I[88 + 99 - 84 + 28] = I("桸戱", "Wklrb");
         I[90 + 16 - 71 + 97] = I("冺屵", "LAAQa");
         I[70 + 48 - 20 + 35] = I("槀媋", "bEqTy");
         I[43 + 44 - -16 + 31] = I("啌", "MeGTQ");
         I[24 + 29 - 37 + 119] = I("姵", "BHOge");
         I[28 + 118 - 128 + 118] = I("垺婜庒戺墘", "ONmUg");
         I[133 + 55 - 65 + 14] = I("嗈忻弛楥恡", "tuwRn");
         I[6 + 82 - 59 + 109] = I("捯寄", "ybGRJ");
         I[96 + 122 - 214 + 135] = I("昣戫", "QvmoI");
         I[109 + 23 - 116 + 124] = I("孳梘", "HRxMz");
         I[15 + 30 - -74 + 22] = I("毈涬", "fAQMz");
         I[132 + 112 - 170 + 68] = I("柅泶", "fzwWM");
         I[13 + 121 - 53 + 62] = I("奷澘", "iFYTi");
         I[115 + 129 - 216 + 116] = I("咤唰", "CJDPb");
         I[27 + 8 - -95 + 15] = I("傃掷", "LvSkZ");
         I[121 + 61 - 62 + 26] = I("滇尙", "mEFpO");
         I[45 + 67 - 102 + 137] = I("奿憆", "bRknS");
         I[83 + 135 - 135 + 65] = I("彳揩", "pmAyJ");
         I[75 + 16 - 64 + 122] = I("欏毽", "hQYSq");
         I[96 + 45 - -5 + 4] = I("懯嵰", "ywPSS");
         I[143 + 10 - 68 + 66] = I("噚屫", "zmAAw");
         I[58 + 81 - 20 + 33] = I("櫚愲", "BtMdj");
         I[8 + 18 - -64 + 63] = I("涞尻", "mVwNe");
         I[142 + 36 - 49 + 25] = I("泴擈", "WSmCb");
         I[39 + 124 - 55 + 47] = I("瀸御拣潵嘩", "BoSsy");
         I[12 + 29 - -98 + 17] = I("丝摫棴溄", "ZrVhf");
         I[139 + 102 - 100 + 16] = I("剂巼柺澻", "HaQep");
         I[87 + 19 - 61 + 113] = I("嵽媍墂凬", "ewvxM");
         I[33 + 145 - 78 + 59] = I("杆炼媨俅", "QjQxE");
         I[20 + 21 - -41 + 78] = I("帒澯佌", "ildBI");
         I[50 + 20 - -24 + 67] = I("値嚒", "RESWN");
         I[156 + 64 - 95 + 37] = I("则", "JDwOH");
         I[83 + 133 - 210 + 157] = I("噑冼", "Pyewy");
         I[29 + 91 - 42 + 86] = I("彙澁嘋捒", "RmMxh");
      }

      private StateImplementation(Block var1, ImmutableMap<IProperty<?>, Comparable<?>> var2) {
         this.block = var1;
         this.properties = var2;
      }

      public float getBlockHardness(World var1, BlockPos var2) {
         return this.block.getBlockHardness(this, var1, var2);
      }

      public boolean isFullyOpaque() {
         return this.block.isFullyOpaque(this);
      }

      public Material getMaterial() {
         return this.block.getMaterial(this);
      }

      public int getStrongPower(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
         return this.block.getStrongPower(this, var1, var2, var3);
      }

      public boolean isOpaqueCube() {
         return this.block.isOpaqueCube(this);
      }

      public int hashCode() {
         return this.properties.hashCode();
      }

      public int getLightValue(IBlockAccess var1, BlockPos var2) {
         String var10000 = I[80 ^ 12];
         String var10001 = I[230 ^ 187];
         String var10002 = I[90 ^ 4];
         var10001 = I[17 ^ 78];
         var10000 = I[198 ^ 166];
         var10001 = I[204 ^ 173];
         var10002 = I[8 ^ 106];
         var10001 = I[82 ^ 49];
         var10000 = I[107 ^ 15];
         var10001 = I[96 ^ 5];
         var10002 = I[246 ^ 144];
         var10001 = I[106 ^ 13];
         Block var3 = this.block;
         ReflectorMethod var4 = Reflector.ForgeBlock_getLightValue;
         Object[] var5 = new Object["   ".length()];
         I[235 ^ 131].length();
         I[172 ^ 197].length();
         I[73 ^ 35].length();
         var5["".length()] = this;
         I[194 ^ 169].length();
         I[193 ^ 173].length();
         I[96 ^ 13].length();
         var5[" ".length()] = var1;
         I[55 ^ 89].length();
         I[117 ^ 26].length();
         I[22 ^ 102].length();
         var5["  ".length()] = var2;
         return Reflector.callInt(var3, var4, var5);
      }

      public boolean useNeighborBrightness() {
         return this.block.getUseNeighborBrightness(this);
      }

      static {
         I();
      }

      public boolean isNormalCube() {
         return this.block.isNormalCube(this);
      }

      public boolean shouldSideBeRendered(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
         return this.block.shouldSideBeRendered(this, var1, var2, var3);
      }

      public IBlockState withMirror(Mirror var1) {
         return this.block.withMirror(this, var1);
      }

      public void addCollisionBoxToList(World var1, BlockPos var2, AxisAlignedBB var3, List<AxisAlignedBB> var4, @Nullable Entity var5, boolean var6) {
         this.block.addCollisionBoxToList(this, var1, var2, var3, var4, var5, var6);
      }

      public Collection<IProperty<?>> getPropertyNames() {
         return Collections.unmodifiableCollection(this.properties.keySet());
      }

      public boolean equals(Object var1) {
         int var10000;
         if (this == var1) {
            var10000 = " ".length();
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }

      public int getLightValue() {
         return this.block.getLightValue(this);
      }

      public AxisAlignedBB getBoundingBox(IBlockAccess var1, BlockPos var2) {
         Block.EnumOffsetType var3 = this.block.getOffsetType();
         if (var3 != Block.EnumOffsetType.NONE && !(this.block instanceof BlockFlower)) {
            AxisAlignedBB var4 = this.block.getBoundingBox(this, var1, var2);
            var4 = BlockModelUtils.getOffsetBoundingBox(var4, var3, var2);
            return var4;
         } else {
            return this.block.getBoundingBox(this, var1, var2);
         }
      }

      @Nullable
      public AxisAlignedBB getCollisionBoundingBox(IBlockAccess var1, BlockPos var2) {
         return this.block.getCollisionBoundingBox(this, var1, var2);
      }

      private Map<IProperty<?>, Comparable<?>> getPropertiesWithValue(IProperty<?> var1, Comparable<?> var2) {
         HashMap var3 = Maps.newHashMap(this.properties);
         var3.put(var1, var2);
         I[40 ^ 111].length();
         I[202 ^ 130].length();
         I[76 ^ 5].length();
         I[72 ^ 2].length();
         return var3;
      }

      public ImmutableMap<IProperty<?>, Comparable<?>> getProperties() {
         return this.properties;
      }

      public IBlockState getActualState(IBlockAccess var1, BlockPos var2) {
         return this.block.getActualState(this, var1, var2);
      }

      public Block getBlock() {
         return this.block;
      }

      public int getPackedLightmapCoords(IBlockAccess var1, BlockPos var2) {
         return this.block.getPackedLightmapCoords(this, var1, var2);
      }

      public boolean canProvidePower() {
         return this.block.canProvidePower(this);
      }

      protected StateImplementation(Block var1, ImmutableMap<IProperty<?>, Comparable<?>> var2, ImmutableTable<IProperty<?>, Comparable<?>, IBlockState> var3) {
         this.block = var1;
         this.properties = var2;
         this.propertyValueTable = var3;
      }

      public ImmutableTable<IProperty<?>, Comparable<?>, IBlockState> getPropertyValueTable() {
         return this.propertyValueTable;
      }

      public IBlockState withRotation(Rotation var1) {
         return this.block.withRotation(this, var1);
      }

      public boolean canEntitySpawn(Entity var1) {
         return this.block.canEntitySpawn(this, var1);
      }

      public int getComparatorInputOverride(World var1, BlockPos var2) {
         return this.block.getComparatorInputOverride(this, var1, var2);
      }

      public boolean func_191057_i() {
         return this.block.func_190946_v(this);
      }

      public boolean isTranslucent() {
         return this.block.isTranslucent(this);
      }

      public boolean isFullBlock() {
         return this.block.isFullBlock(this);
      }

      public RayTraceResult collisionRayTrace(World var1, BlockPos var2, Vec3d var3, Vec3d var4) {
         return this.block.collisionRayTrace(this, var1, var2, var3, var4);
      }

      public <T extends Comparable<T>> T getValue(IProperty<T> var1) {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         var10000 = I[152 ^ 156];
         var10001 = I[184 ^ 189];
         var10002 = I[56 ^ 62];
         var10001 = I[58 ^ 61];
         Comparable var2 = (Comparable)this.properties.get(var1);
         if (var2 == null) {
            I[125 ^ 117].length();
            I[113 ^ 120].length();
            I[79 ^ 69].length();
            I[91 ^ 80].length();
            I[162 ^ 174].length();
            IllegalArgumentException var3 = new IllegalArgumentException(I[144 ^ 157] + var1 + I[48 ^ 62] + this.block.getBlockState());
            I[57 ^ 54].length();
            I[42 ^ 58].length();
            I[124 ^ 109].length();
            I[185 ^ 171].length();
            I[76 ^ 95].length();
            throw var3;
         } else {
            return (Comparable)var1.getValueClass().cast(var2);
         }
      }

      // $FF: synthetic method
      StateImplementation(Block var1, ImmutableMap var2, Object var3) {
         this(var1, var2);
      }

      public EnumBlockRenderType getRenderType() {
         return this.block.getRenderType(this);
      }

      public float getAmbientOcclusionLightValue() {
         return this.block.getAmbientOcclusionLightValue(this);
      }

      public boolean isSideSolid(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
         String var10000 = I[234 ^ 155];
         String var10001 = I[210 ^ 160];
         String var10002 = I[248 ^ 139];
         var10001 = I[56 ^ 76];
         var10000 = I[179 ^ 198];
         var10001 = I[103 ^ 17];
         var10002 = I[176 ^ 199];
         var10001 = I[69 ^ 61];
         var10000 = I[18 ^ 107];
         var10001 = I[221 ^ 167];
         var10002 = I[206 ^ 181];
         var10001 = I[226 ^ 158];
         var10000 = I[125 ^ 0];
         var10001 = I[6 ^ 120];
         var10002 = I[22 + 108 - 129 + 126];
         var10001 = I[101 + 98 - 106 + 35];
         Block var4 = this.block;
         ReflectorMethod var6 = Reflector.ForgeBlock_isSideSolid;
         Object[] var5 = new Object[89 ^ 93];
         I[105 + 74 - 84 + 34].length();
         I[101 + 11 - 23 + 41].length();
         var5["".length()] = this;
         I[12 + 90 - 43 + 72].length();
         I[61 + 78 - 48 + 41].length();
         I[60 + 10 - -36 + 27].length();
         var5[" ".length()] = var1;
         I[1 + 20 - -50 + 63].length();
         I[88 + 133 - 166 + 80].length();
         var5["  ".length()] = var2;
         I[122 + 26 - 98 + 86].length();
         I[72 + 111 - 114 + 68].length();
         var5["   ".length()] = var3;
         return Reflector.callBoolean(var4, var6, var5);
      }
   }

   public static class Builder {
      // $FF: synthetic field
      private final List<IUnlistedProperty<?>> unlisted = Lists.newArrayList();
      // $FF: synthetic field
      private final List<IProperty<?>> listed = Lists.newArrayList();
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Block block;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 >= -1);

         throw null;
      }

      public BlockStateContainer.Builder add(IProperty<?>... var1) {
         IProperty[] var2 = var1;
         int var3 = var1.length;
         int var4 = "".length();

         do {
            if (var4 >= var3) {
               return this;
            }

            IProperty var5 = var2[var4];
            this.listed.add(var5);
            I["".length()].length();
            ++var4;
            "".length();
         } while(3 == 3);

         throw null;
      }

      static {
         I();
      }

      public BlockStateContainer.Builder add(IUnlistedProperty<?>... var1) {
         IUnlistedProperty[] var2 = var1;
         int var3 = var1.length;
         int var4 = "".length();

         do {
            if (var4 >= var3) {
               return this;
            }

            IUnlistedProperty var5 = var2[var4];
            this.unlisted.add(var5);
            I[" ".length()].length();
            I["  ".length()].length();
            ++var4;
            "".length();
         } while(4 >= 1);

         throw null;
      }

      private static void I() {
         I = new String[106 ^ 113];
         I["".length()] = I("濆攷恂垸冽", "NKyFk");
         I[" ".length()] = I("抍涍攥", "WBDUp");
         I["  ".length()] = I("屳倻", "EytPc");
         I["   ".length()] = I("炋殯", "EJaOw");
         I[4 ^ 0] = I("夅擳", "EBSfi");
         I[105 ^ 108] = I("峆兕", "eHPlc");
         I[52 ^ 50] = I("儩偪", "pPzzT");
         I[3 ^ 4] = I("呏慌", "FkAlF");
         I[0 ^ 8] = I("亊並", "gBFbv");
         I[107 ^ 98] = I("瀡塐", "SZmzH");
         I[150 ^ 156] = I("俙偛", "kpYuJ");
         I[140 ^ 135] = I("姎剦", "TDPmz");
         I[51 ^ 63] = I("刢曝", "MIndR");
         I[71 ^ 74] = I("曐峰", "rngss");
         I[201 ^ 199] = I("淋搊", "BEeVf");
         I[170 ^ 165] = I("厅嗗", "bLEHl");
         I[162 ^ 178] = I("嗫坊", "eUvmC");
         I[3 ^ 18] = I("洼侙", "yfezP");
         I[211 ^ 193] = I("屔嵢", "ALOAD");
         I[21 ^ 6] = I("挝嗂洁", "aLbHs");
         I[79 ^ 91] = I("且巖徼栫", "dOYLJ");
         I[159 ^ 138] = I("啜墏印", "RlOFQ");
         I[53 ^ 35] = I("慖嘸体", "PNwnj");
         I[20 ^ 3] = I("娍", "SSLKa");
         I[45 ^ 53] = I("声坥樽倫澫", "lSztU");
         I[159 ^ 134] = I("挒", "CumBe");
         I[151 ^ 141] = I("炰恫侾柇", "hVSmw");
      }

      public BlockStateContainer build() {
         String var10000 = I["   ".length()];
         String var10001 = I[79 ^ 75];
         String var10002 = I[23 ^ 18];
         var10001 = I[73 ^ 79];
         var10000 = I[11 ^ 12];
         var10001 = I[205 ^ 197];
         var10002 = I[39 ^ 46];
         var10001 = I[5 ^ 15];
         var10000 = I[102 ^ 109];
         var10001 = I[97 ^ 109];
         var10002 = I[42 ^ 39];
         var10001 = I[68 ^ 74];
         var10000 = I[98 ^ 109];
         var10001 = I[185 ^ 169];
         var10002 = I[41 ^ 56];
         var10001 = I[182 ^ 164];
         IProperty[] var1 = new IProperty[this.listed.size()];
         var1 = (IProperty[])((IProperty[])this.listed.toArray(var1));
         if (this.unlisted.size() == 0) {
            I[50 ^ 33].length();
            return new BlockStateContainer(this.block, var1);
         } else {
            IUnlistedProperty[] var2 = new IUnlistedProperty[this.unlisted.size()];
            var2 = (IUnlistedProperty[])((IUnlistedProperty[])this.unlisted.toArray(var2));
            ReflectorConstructor var3 = Reflector.ExtendedBlockState_Constructor;
            Object[] var4 = new Object["   ".length()];
            I[101 ^ 113].length();
            I[92 ^ 73].length();
            I[2 ^ 20].length();
            var4["".length()] = this.block;
            I[66 ^ 85].length();
            I[170 ^ 178].length();
            I[173 ^ 180].length();
            var4[" ".length()] = var1;
            I[53 ^ 47].length();
            var4["  ".length()] = var2;
            return (BlockStateContainer)Reflector.newInstance(var3, var4);
         }
      }

      public Builder(Block var1) {
         this.block = var1;
      }
   }
}

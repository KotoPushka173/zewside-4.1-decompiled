package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketChangeGameState implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private float value;
   // $FF: synthetic field
   public static final String[] MESSAGE_NAMES;
   // $FF: synthetic field
   private int state;
   // $FF: synthetic field
   private static final String[] I;

   public SPacketChangeGameState() {
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleChangeGameState(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.state);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeFloat(this.value);
      I["   ".length()].length();
      I[111 ^ 107].length();
      I[136 ^ 141].length();
      I[50 ^ 52].length();
   }

   static {
      I();
      String[] var10000 = new String[" ".length()];
      var10000["".length()] = I[76 ^ 75];
      MESSAGE_NAMES = var10000;
   }

   public int getGameState() {
      return this.state;
   }

   private static void I() {
      I = new String[165 ^ 173];
      I["".length()] = I("漬", "KDwIS");
      I[" ".length()] = I("灼", "XlYtM");
      I["  ".length()] = I("傈咢", "YFmIE");
      I["   ".length()] = I("异帿", "lBUlJ");
      I[188 ^ 184] = I("慆悀勬", "ufyYQ");
      I[15 ^ 10] = I("憑", "dUrzi");
      I[5 ^ 3] = I("杵帵比椇", "pIfyV");
      I[146 ^ 149] = I("1\u0000)\u0007T'\f!L\u0014*\u001d\u0013\u0003\u0016,\r", "EiEbz");
   }

   public float getValue() {
      return this.value;
   }

   public SPacketChangeGameState(int var1, float var2) {
      this.state = var1;
      this.value = var2;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 0);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.state = var1.readUnsignedByte();
      this.value = var1.readFloat();
   }
}

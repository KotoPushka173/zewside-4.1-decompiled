package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;

public class EffectsChangedTrigger implements ICriterionTrigger<EffectsChangedTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_193154_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, EffectsChangedTrigger.Listeners> field_193155_b = Maps.newHashMap();

   static {
      I();
      field_193154_a = new ResourceLocation(I[34 ^ 55]);
   }

   private static void I() {
      I = new String[190 ^ 168];
      I["".length()] = I("实炴", "ZrmDF");
      I[" ".length()] = I("咙樲", "esuup");
      I["  ".length()] = I("敪嚀", "UksLN");
      I["   ".length()] = I("淜斘", "FYxSe");
      I[162 ^ 166] = I("滰埩伖", "ZDtth");
      I[23 ^ 18] = I("澱支", "JKZiA");
      I[175 ^ 169] = I("尰澦", "TbLrU");
      I[27 ^ 28] = I("儓婜冹", "LYmGp");
      I[130 ^ 138] = I("後娿殑愣", "hWZHY");
      I[185 ^ 176] = I("挶", "zQntd");
      I[137 ^ 131] = I("撩", "ODLmf");
      I[155 ^ 144] = I("潓佖昖", "BJKcu");
      I[64 ^ 76] = I("呛", "vDQzg");
      I[33 ^ 44] = I("侕", "EXeOh");
      I[173 ^ 163] = I("旐", "RrwsV");
      I[41 ^ 38] = I("匑倜", "Wjywa");
      I[123 ^ 107] = I("抲墽", "vxaVS");
      I[70 ^ 87] = I("嚧愔", "iAjRA");
      I[42 ^ 56] = I("汄挫", "npuzk");
      I[39 ^ 52] = I("\u0011\u001e#7:\u0000\u000b", "txERY");
      I[75 ^ 95] = I("悇", "KONdl");
      I[18 ^ 7] = I("&\u0015\u0017\f*7\u0000.\n!\"\u001d\u0016\f-", "CsqiI");
   }

   public void func_193153_a(EntityPlayerMP var1) {
      EffectsChangedTrigger.Listeners var2 = (EffectsChangedTrigger.Listeners)this.field_193155_b.get(var1.func_192039_O());
      if (var2 != null) {
         var2.func_193432_a(var1);
      }

   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193155_b.remove(var1);
      I[43 ^ 38].length();
      I[79 ^ 65].length();
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<EffectsChangedTrigger.Instance> var2) {
      EffectsChangedTrigger.Listeners var3 = (EffectsChangedTrigger.Listeners)this.field_193155_b.get(var1);
      if (var3 != null) {
         var3.func_193429_b(var2);
         if (var3.func_193430_a()) {
            this.field_193155_b.remove(var1);
            I[175 ^ 166].length();
            I[130 ^ 136].length();
            I[127 ^ 116].length();
            I[136 ^ 132].length();
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 0);

      throw null;
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<EffectsChangedTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      EffectsChangedTrigger.Listeners var3 = (EffectsChangedTrigger.Listeners)this.field_193155_b.get(var1);
      if (var3 == null) {
         I[133 ^ 129].length();
         I[61 ^ 56].length();
         var3 = new EffectsChangedTrigger.Listeners(var1);
         this.field_193155_b.put(var1, var3);
         I[74 ^ 76].length();
         I[100 ^ 99].length();
         I[128 ^ 136].length();
      }

      var3.func_193431_a(var2);
   }

   public ResourceLocation func_192163_a() {
      return field_193154_a;
   }

   public EffectsChangedTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[130 ^ 141];
      String var10001 = I[160 ^ 176];
      String var10002 = I[95 ^ 78];
      var10001 = I[120 ^ 106];
      MobEffectsPredicate var3 = MobEffectsPredicate.func_193471_a(var1.get(I[10 ^ 25]));
      I[182 ^ 162].length();
      return new EffectsChangedTrigger.Instance(var3);
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final MobEffectsPredicate field_193196_a;

      public Instance(MobEffectsPredicate var1) {
         super(EffectsChangedTrigger.field_193154_a);
         this.field_193196_a = var1;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 != -1);

         throw null;
      }

      public boolean func_193195_a(EntityPlayerMP var1) {
         return this.field_193196_a.func_193472_a(var1);
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<EffectsChangedTrigger.Instance>> field_193434_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_193433_a;
      // $FF: synthetic field
      private static final String[] I;

      public void func_193431_a(ICriterionTrigger.Listener<EffectsChangedTrigger.Instance> var1) {
         this.field_193434_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      private static void I() {
         I = new String[164 ^ 162];
         I["".length()] = I("奘儱娨", "OhXny");
         I[" ".length()] = I("披揖烫劭晰", "hUnnj");
         I["  ".length()] = I("勂儴", "NBxnQ");
         I["   ".length()] = I("揣", "yKotd");
         I[136 ^ 140] = I("妯惘", "socKH");
         I[77 ^ 72] = I("拪捪佰崎", "LXdBd");
      }

      public void func_193429_b(ICriterionTrigger.Listener<EffectsChangedTrigger.Instance> var1) {
         this.field_193434_b.remove(var1);
         I["  ".length()].length();
         I["   ".length()].length();
      }

      public void func_193432_a(EntityPlayerMP var1) {
         ArrayList var2 = null;
         Iterator var3 = this.field_193434_b.iterator();

         ICriterionTrigger.Listener var4;
         while(var3.hasNext()) {
            var4 = (ICriterionTrigger.Listener)var3.next();
            if (((EffectsChangedTrigger.Instance)var4.func_192158_a()).func_193195_a(var1)) {
               if (var2 == null) {
                  var2 = Lists.newArrayList();
               }

               var2.add(var4);
               I[135 ^ 131].length();
               I[12 ^ 9].length();
            }

            "".length();
            if (2 <= 1) {
               throw null;
            }
         }

         if (var2 != null) {
            var3 = var2.iterator();

            while(var3.hasNext()) {
               var4 = (ICriterionTrigger.Listener)var3.next();
               var4.func_192159_a(this.field_193433_a);
               "".length();
               if (0 == -1) {
                  throw null;
               }
            }
         }

      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193433_a = var1;
      }

      public boolean func_193430_a() {
         return this.field_193434_b.isEmpty();
      }

      static {
         I();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 == 4);

         throw null;
      }
   }
}

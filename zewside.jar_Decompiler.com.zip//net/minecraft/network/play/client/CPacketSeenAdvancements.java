package net.minecraft.network.play.client;

import java.io.IOException;
import javax.annotation.Nullable;
import net.minecraft.advancements.Advancement;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.util.ResourceLocation;

public class CPacketSeenAdvancements implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private ResourceLocation field_194167_b;
   // $FF: synthetic field
   private CPacketSeenAdvancements.Action field_194166_a;

   public CPacketSeenAdvancements() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.field_194166_a);
      I[34 ^ 46].length();
      I[125 ^ 112].length();
      I[140 ^ 130].length();
      if (this.field_194166_a == CPacketSeenAdvancements.Action.OPENED_TAB) {
         var1.func_192572_a(this.field_194167_b);
         I[4 ^ 11].length();
         I[143 ^ 159].length();
         I[177 ^ 160].length();
         I[84 ^ 70].length();
      }

   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.field_194166_a = (CPacketSeenAdvancements.Action)var1.readEnumValue(CPacketSeenAdvancements.Action.class);
      if (this.field_194166_a == CPacketSeenAdvancements.Action.OPENED_TAB) {
         this.field_194167_b = var1.func_192575_l();
      }

   }

   public CPacketSeenAdvancements.Action func_194162_b() {
      return this.field_194166_a;
   }

   static {
      I();
   }

   private static void I() {
      I = new String[70 ^ 85];
      I["".length()] = I("嗝仉", "foccG");
      I[" ".length()] = I("濴昖", "lMQVI");
      I["  ".length()] = I("搚涥", "ENTXj");
      I["   ".length()] = I("悔拲", "BkvoY");
      I[49 ^ 53] = I("吞案", "SIZnA");
      I[52 ^ 49] = I("歡", "CuPIq");
      I[124 ^ 122] = I("暻歽", "iTtNh");
      I[32 ^ 39] = I("清搼", "DZNVD");
      I[168 ^ 160] = I("慾橴", "jgmsF");
      I[126 ^ 119] = I("嵼慄", "LgVNL");
      I[24 ^ 18] = I("垆", "vqpYT");
      I[74 ^ 65] = I("瀫", "uPokQ");
      I[53 ^ 57] = I("患佢尚", "Cjtuj");
      I[18 ^ 31] = I("侳嚙", "aUVEQ");
      I[115 ^ 125] = I("囩業", "FQuxk");
      I[73 ^ 70] = I("勩伻拡瀆", "jQeOT");
      I[120 ^ 104] = I("勩懹", "ACcxB");
      I[157 ^ 140] = I("恎兒噖凕滬", "Zelne");
      I[123 ^ 105] = I("屲槜掹", "Lbyea");
   }

   public ResourceLocation func_194165_c() {
      return this.field_194167_b;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.func_194027_a(this);
   }

   public CPacketSeenAdvancements(CPacketSeenAdvancements.Action var1, @Nullable ResourceLocation var2) {
      this.field_194166_a = var1;
      this.field_194167_b = var2;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 2);

      throw null;
   }

   public static CPacketSeenAdvancements func_194163_a(Advancement var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[106 ^ 110].length();
      I[159 ^ 154].length();
      return new CPacketSeenAdvancements(CPacketSeenAdvancements.Action.OPENED_TAB, var0.func_192067_g());
   }

   public static CPacketSeenAdvancements func_194164_a() {
      String var10000 = I[13 ^ 11];
      String var10001 = I[50 ^ 53];
      String var10002 = I[171 ^ 163];
      var10001 = I[164 ^ 173];
      I[39 ^ 45].length();
      I[179 ^ 184].length();
      return new CPacketSeenAdvancements(CPacketSeenAdvancements.Action.CLOSED_SCREEN, (ResourceLocation)null);
   }

   public static enum Action {
      // $FF: synthetic field
      CLOSED_SCREEN;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      OPENED_TAB;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 >= 0);

         throw null;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I(" \u0003\u0007?\u0006+\f\u00160\u0001", "oSBqC");
         I[" ".length()] = I("\u000b\t-<+\f\u001a1,<\r\u0000,", "HEbon");
      }

      static {
         I();
         OPENED_TAB = new CPacketSeenAdvancements.Action(I["".length()], "".length());
         CLOSED_SCREEN = new CPacketSeenAdvancements.Action(I[" ".length()], " ".length());
         CPacketSeenAdvancements.Action[] var10000 = new CPacketSeenAdvancements.Action["  ".length()];
         var10000["".length()] = OPENED_TAB;
         var10000[" ".length()] = CLOSED_SCREEN;
      }
   }
}

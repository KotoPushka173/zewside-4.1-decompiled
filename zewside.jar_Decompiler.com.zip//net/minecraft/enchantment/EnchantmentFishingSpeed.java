package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentFishingSpeed extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   protected EnchantmentFishingSpeed(Enchantment.Rarity var1, EnumEnchantmentType var2, EntityEquipmentSlot... var3) {
      super(var1, var2, var3);
      this.setName(I["".length()]);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 4);

      throw null;
   }

   static {
      I();
   }

   public int getMinEnchantability(int var1) {
      int var10000 = 114 ^ 125;
      int var10002 = " ".length();
      I[" ".length()].length();
      return var10000 + (var1 - var10002) * (48 ^ 57);
   }

   public int getMaxEnchantability(int var1) {
      return super.getMinEnchantability(var1) + (60 ^ 14);
   }

   private static void I() {
      I = new String["  ".length()];
      I["".length()] = I("#\r\u0005*-+\u0003%2! \u0000", "EdvBD");
      I[" ".length()] = I("墔烾", "xePak");
   }

   public int getMaxLevel() {
      return "   ".length();
   }
}

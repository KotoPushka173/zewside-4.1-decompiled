package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketClickWindow implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private int usedButton;
   // $FF: synthetic field
   private ItemStack clickedItem;
   // $FF: synthetic field
   private ClickType mode;
   // $FF: synthetic field
   private short actionNumber;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int windowId;
   // $FF: synthetic field
   private int slotId;

   private static void I() {
      I = new String[66 ^ 73];
      I["".length()] = I("噱挮厕", "OpbHZ");
      I[" ".length()] = I("拚", "OojKr");
      I["  ".length()] = I("層巐", "lQHQN");
      I["   ".length()] = I("戋倵浴叨", "cFZdW");
      I[97 ^ 101] = I("嬴愬", "tbLoN");
      I[178 ^ 183] = I("寖圹淞渜", "CgDec");
      I[176 ^ 182] = I("澕巗宠晘", "dappD");
      I[119 ^ 112] = I("忮槕", "GfecH");
      I[189 ^ 181] = I("亦庐", "mXylV");
      I[105 ^ 96] = I("汪圬煩", "nXqXC");
      I[89 ^ 83] = I("佝佼孡朌搲", "PHBna");
   }

   public CPacketClickWindow() {
      this.clickedItem = ItemStack.field_190927_a;
   }

   public int getWindowId() {
      return this.windowId;
   }

   public short getActionNumber() {
      return this.actionNumber;
   }

   public ClickType getClickType() {
      return this.mode;
   }

   public CPacketClickWindow(int var1, int var2, int var3, ClickType var4, ItemStack var5, short var6) {
      this.clickedItem = ItemStack.field_190927_a;
      this.windowId = var1;
      this.slotId = var2;
      this.usedButton = var3;
      this.clickedItem = var5.copy();
      this.actionNumber = var6;
      this.mode = var4;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.windowId = var1.readByte();
      this.slotId = var1.readShort();
      this.usedButton = var1.readByte();
      this.actionNumber = var1.readShort();
      this.mode = (ClickType)var1.readEnumValue(ClickType.class);
      this.clickedItem = var1.readItemStackFromBuffer();
   }

   public int getUsedButton() {
      return this.usedButton;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processClickWindow(this);
   }

   public int getSlotId() {
      return this.slotId;
   }

   public ItemStack getClickedItem() {
      return this.clickedItem;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.windowId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeShort(this.slotId);
      I[115 ^ 119].length();
      var1.writeByte(this.usedButton);
      I[158 ^ 155].length();
      var1.writeShort(this.actionNumber);
      I[30 ^ 24].length();
      I[42 ^ 45].length();
      var1.writeEnumValue(this.mode);
      I[101 ^ 109].length();
      I[24 ^ 17].length();
      var1.writeItemStackToBuffer(this.clickedItem);
      I[122 ^ 112].length();
   }

   static {
      I();
   }
}

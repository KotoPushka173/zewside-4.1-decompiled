package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackData;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockJukebox extends BlockContainer {
   // $FF: synthetic field
   public static final PropertyBool HAS_RECORD;
   // $FF: synthetic field
   private static final String[] I;

   public int getMetaFromState(IBlockState var1) {
      int var10000;
      if ((Boolean)var1.getValue(HAS_RECORD)) {
         var10000 = " ".length();
         "".length();
         if (4 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public static void registerFixesJukebox(DataFixer var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[136 ^ 140];
      var10001 = I[85 ^ 80];
      var10002 = I[18 ^ 20];
      var10001 = I[104 ^ 111];
      FixTypes var1 = FixTypes.BLOCK_ENTITY;
      I[15 ^ 7].length();
      String[] var10005 = new String[" ".length()];
      I[129 ^ 136].length();
      I[164 ^ 174].length();
      var10005["".length()] = I[123 ^ 112];
      var0.registerWalker(var1, new ItemStackData(BlockJukebox.TileEntityJukebox.class, var10005));
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[224 ^ 194];
      String var10001 = I[153 ^ 186];
      String var10002 = I[101 ^ 65];
      var10001 = I[14 ^ 43];
      var10000 = I[40 ^ 14];
      var10001 = I[143 ^ 168];
      var10002 = I[129 ^ 169];
      var10001 = I[81 ^ 120];
      I[153 ^ 179].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[235 ^ 192].length();
      I[130 ^ 174].length();
      I[186 ^ 151].length();
      I[167 ^ 137].length();
      var10003["".length()] = HAS_RECORD;
      return new BlockStateContainer(this, var10003);
   }

   private void dropRecord(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[83 ^ 67];
      String var10001 = I[31 ^ 14];
      String var10002 = I[95 ^ 77];
      var10001 = I[155 ^ 136];
      if (!var1.isRemote) {
         TileEntity var4 = var1.getTileEntity(var2);
         if (var4 instanceof BlockJukebox.TileEntityJukebox) {
            BlockJukebox.TileEntityJukebox var5 = (BlockJukebox.TileEntityJukebox)var4;
            ItemStack var6 = var5.getRecord();
            if (!var6.isEmpty()) {
               var1.playEvent(676 + 717 - 977 + 594, var2, "".length());
               var1.playRecord(var2, (SoundEvent)null);
               var5.setRecord(ItemStack.field_190927_a);
               float var7 = 0.7F;
               double var8 = (double)(var1.rand.nextFloat() * 0.7F) + 0.15000000596046448D;
               double var10 = (double)(var1.rand.nextFloat() * 0.7F) + 0.06000000238418579D + 0.6D;
               double var12 = (double)(var1.rand.nextFloat() * 0.7F) + 0.15000000596046448D;
               ItemStack var14 = var6.copy();
               I[28 ^ 8].length();
               I[157 ^ 136].length();
               EntityItem var15 = new EntityItem(var1, (double)var2.getX() + var8, (double)var2.getY() + var10, (double)var2.getZ() + var12, var14);
               var15.setDefaultPickupDelay();
               var1.spawnEntityInWorld(var15);
               I[67 ^ 85].length();
               I[76 ^ 91].length();
               I[188 ^ 164].length();
            }
         }
      }

   }

   static {
      I();
      HAS_RECORD = PropertyBool.create(I[83 ^ 124]);
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      this.dropRecord(var1, var2, var3);
      super.breakBlock(var1, var2, var3);
   }

   protected BlockJukebox() {
      super(Material.WOOD, MapColor.DIRT);
      this.setDefaultState(this.blockState.getBaseState().withProperty(HAS_RECORD, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      TileEntity var4 = var2.getTileEntity(var3);
      if (var4 instanceof BlockJukebox.TileEntityJukebox) {
         ItemStack var5 = ((BlockJukebox.TileEntityJukebox)var4).getRecord();
         if (!var5.isEmpty()) {
            int var10000 = Item.getIdFromItem(var5.getItem()) + " ".length();
            int var10001 = Item.getIdFromItem(Items.RECORD_13);
            I[33 ^ 62].length();
            I[86 ^ 118].length();
            I[78 ^ 111].length();
            return var10000 - var10001;
         }
      }

      return "".length();
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      if (!var1.isRemote) {
         super.dropBlockAsItemWithChance(var1, var2, var3, var4, "".length());
      }

   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState();
      PropertyBool var10001 = HAS_RECORD;
      int var10002;
      if (var1 > 0) {
         var10002 = " ".length();
         "".length();
         if (-1 < -1) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public void insertRecord(World var1, BlockPos var2, IBlockState var3, ItemStack var4) {
      TileEntity var5 = var1.getTileEntity(var2);
      if (var5 instanceof BlockJukebox.TileEntityJukebox) {
         ((BlockJukebox.TileEntityJukebox)var5).setRecord(var4.copy());
         var1.setBlockState(var2, var3.withProperty(HAS_RECORD, Boolean.valueOf((boolean)" ".length())), "  ".length());
         I[32 ^ 46].length();
         I[75 ^ 68].length();
      }

   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if ((Boolean)var3.getValue(HAS_RECORD)) {
         this.dropRecord(var1, var2, var3);
         var3 = var3.withProperty(HAS_RECORD, Boolean.valueOf((boolean)"".length()));
         var1.setBlockState(var2, var3, "  ".length());
         I[109 ^ 97].length();
         I[203 ^ 198].length();
         return (boolean)" ".length();
      } else {
         return (boolean)"".length();
      }
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[119 ^ 110];
      String var10001 = I[60 ^ 38];
      String var10002 = I[25 ^ 2];
      var10001 = I[92 ^ 64];
      I[169 ^ 180].length();
      I[112 ^ 110].length();
      return new BlockJukebox.TileEntityJukebox();
   }

   private static void I() {
      I = new String[242 ^ 194];
      I["".length()] = I("冢梪", "KXOrk");
      I[" ".length()] = I("传榖", "zSXBj");
      I["  ".length()] = I("栯沐", "OWawf");
      I["   ".length()] = I("吇炅", "VUWEM");
      I[55 ^ 51] = I("嘬樽", "fzNkf");
      I[73 ^ 76] = I("巈淍", "iWVTu");
      I[38 ^ 32] = I("勼槒", "QDUqh");
      I[39 ^ 32] = I("浲欱", "lQpmT");
      I[19 ^ 27] = I("梤埁孀楚慤", "FyZhQ");
      I[207 ^ 198] = I("沩丷桪", "aNlTr");
      I[157 ^ 151] = I("峪喺劵捪", "gKkRP");
      I[80 ^ 91] = I("\u001b\u000b)\u0007\u0011-'>\r\u000e", "InJhc");
      I[112 ^ 124] = I("塦樆凪撰", "kxGDt");
      I[92 ^ 81] = I("媾堢", "OvrXh");
      I[70 ^ 72] = I("劳寢德", "XflBY");
      I[138 ^ 133] = I("峖", "IdnAW");
      I[170 ^ 186] = I("咕煮", "sEQdN");
      I[30 ^ 15] = I("尸椴", "EYtWU");
      I[157 ^ 143] = I("喴塲", "ZUmBP");
      I[38 ^ 53] = I("涔勖", "SDcqM");
      I[59 ^ 47] = I("寨桽", "cfZez");
      I[149 ^ 128] = I("剞嶎咟懬捷", "yWkyz");
      I[22 ^ 0] = I("旪泱冽欑佋", "hYrQj");
      I[140 ^ 155] = I("瀉欑", "dqvbP");
      I[21 ^ 13] = I("炱幒梡佗咍", "jsWHO");
      I[62 ^ 39] = I("厔亵", "jEwsw");
      I[93 ^ 71] = I("媍旤", "jMXjL");
      I[144 ^ 139] = I("侓営", "ldyzX");
      I[217 ^ 197] = I("橃東", "SPAGs");
      I[116 ^ 105] = I("揩下淄", "dfdYe");
      I[133 ^ 155] = I("榼惡哺呲櫠", "qzIpY");
      I[36 ^ 59] = I("晝婷嶾", "QbVtI");
      I[58 ^ 26] = I("夠堮夃崦姽", "ymnzZ");
      I[226 ^ 195] = I("圤漋嚌噹", "iaPtF");
      I[147 ^ 177] = I("擯嵒", "PmtSw");
      I[16 ^ 51] = I("揫憘", "xjZYj");
      I[83 ^ 119] = I("埏仞", "DNmxP");
      I[141 ^ 168] = I("埸劸", "DnSqh");
      I[114 ^ 84] = I("劙扠", "qmvmx");
      I[183 ^ 144] = I("图庶", "YdXuh");
      I[85 ^ 125] = I("儓女", "ZXLJM");
      I[157 ^ 180] = I("墫亻", "Uygot");
      I[96 ^ 74] = I("扗墂", "gmChW");
      I[174 ^ 133] = I("怾", "sWNMz");
      I[37 ^ 9] = I("沘汸惓最", "OLijQ");
      I[186 ^ 151] = I("扨伂岲墒倮", "PcFwa");
      I[7 ^ 41] = I("嬧溣漌", "CyfPp");
      I[176 ^ 159] = I("\u0003\u0000\u0006*3\u000e\u0002\u001a\u0007%", "kauuA");
   }

   public static class TileEntityJukebox extends TileEntity {
      // $FF: synthetic field
      private ItemStack record;
      // $FF: synthetic field
      private static final String[] I;

      private static void I() {
         I = new String[153 ^ 142];
         I["".length()] = I("喭歐", "qxiYv");
         I[" ".length()] = I("圮哏", "URmtH");
         I["  ".length()] = I("炱煱", "SAKPW");
         I["   ".length()] = I("俴枧", "Szspu");
         I[52 ^ 48] = I("澁有", "tgcpt");
         I[100 ^ 97] = I("昫换", "ZMcsW");
         I[175 ^ 169] = I("嶷峸", "GnDue");
         I[126 ^ 121] = I("儰婣", "PgKRI");
         I[16 ^ 24] = I(">\r (:\b!7\"%", "lhCGH");
         I[17 ^ 24] = I("墅弼摆峳", "ruOPf");
         I[74 ^ 64] = I("噘扆", "ydoTe");
         I[169 ^ 162] = I("16!?\u000b\u0007\u001a65\u0014", "cSBPy");
         I[95 ^ 83] = I("+\u0014-\u0015\u0005\u001d", "yqNzw");
         I[182 ^ 187] = I("濲圝炀", "zoPWt");
         I[143 ^ 129] = I("*\u0002\n\b\u0003\u001c", "xgigq");
         I[80 ^ 95] = I("嫉幜", "WHAen");
         I[107 ^ 123] = I("嬦他", "lvajP");
         I[15 ^ 30] = I("昑塋", "TNZTj");
         I[190 ^ 172] = I("娬柑", "LAxZf");
         I[58 ^ 41] = I("嵧召凌", "zkInM");
         I[32 ^ 52] = I("\u0019\n%9\u0018/&23\u0007", "KoFVj");
         I[49 ^ 36] = I("溽慅愹涬兾", "SrPiC");
         I[136 ^ 158] = I("圄娕柤攕堤", "DrMhS");
      }

      public void setRecord(ItemStack var1) {
         this.record = var1;
         this.markDirty();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 >= -1);

         throw null;
      }

      public TileEntityJukebox() {
         this.record = ItemStack.field_190927_a;
      }

      public void readFromNBT(NBTTagCompound var1) {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         var10000 = I[47 ^ 43];
         var10001 = I[139 ^ 142];
         var10002 = I[185 ^ 191];
         var10001 = I[120 ^ 127];
         super.readFromNBT(var1);
         if (var1.hasKey(I[1 ^ 9], 7 ^ 13)) {
            I[159 ^ 150].length();
            I[188 ^ 182].length();
            this.setRecord(new ItemStack(var1.getCompoundTag(I[67 ^ 72])));
            "".length();
            if (-1 >= 3) {
               throw null;
            }
         } else if (var1.getInteger(I[1 ^ 13]) > 0) {
            I[55 ^ 58].length();
            this.setRecord(new ItemStack(Item.getItemById(var1.getInteger(I[117 ^ 123]))));
         }

      }

      public NBTTagCompound writeToNBT(NBTTagCompound var1) {
         String var10000 = I[35 ^ 44];
         String var10001 = I[215 ^ 199];
         String var10002 = I[22 ^ 7];
         var10001 = I[126 ^ 108];
         super.writeToNBT(var1);
         I[65 ^ 82].length();
         if (!this.getRecord().isEmpty()) {
            var10001 = I[11 ^ 31];
            ItemStack var2 = this.getRecord();
            I[34 ^ 55].length();
            I[125 ^ 107].length();
            var1.setTag(var10001, var2.writeToNBT(new NBTTagCompound()));
         }

         return var1;
      }

      static {
         I();
      }

      public ItemStack getRecord() {
         return this.record;
      }
   }
}

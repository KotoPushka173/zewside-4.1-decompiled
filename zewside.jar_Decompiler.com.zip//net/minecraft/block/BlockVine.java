package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockVine extends Block {
   // $FF: synthetic field
   public static final PropertyBool EAST;
   // $FF: synthetic field
   protected static final AxisAlignedBB EAST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB UP_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB WEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB NORTH_AABB;
   // $FF: synthetic field
   public static final PropertyBool NORTH;
   // $FF: synthetic field
   public static final PropertyBool SOUTH;
   // $FF: synthetic field
   protected static final AxisAlignedBB SOUTH_AABB;
   // $FF: synthetic field
   public static final PropertyBool UP;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool[] ALL_FACES;
   // $FF: synthetic field
   public static final PropertyBool WEST;

   private boolean func_193396_c(World var1, BlockPos var2, EnumFacing var3) {
      IBlockState var4 = var1.getBlockState(var2);
      int var10000;
      if (var4.func_193401_d(var1, var2, var3) == BlockFaceShape.SOLID && !func_193397_e(var4.getBlock())) {
         var10000 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static PropertyBool getPropertyFor(EnumFacing var0) {
      String var10000 = I[85 ^ 19];
      String var10001 = I[16 ^ 87];
      String var10002 = I[204 ^ 132];
      var10001 = I[7 ^ 78];
      var10000 = I[2 ^ 72];
      var10001 = I[35 ^ 104];
      var10002 = I[19 ^ 95];
      var10001 = I[3 ^ 78];
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var0.ordinal()]) {
      case 1:
         return UP;
      case 2:
         return NORTH;
      case 3:
         return SOUTH;
      case 4:
         return WEST;
      case 5:
         return EAST;
      default:
         I[24 ^ 86].length();
         I[249 ^ 182].length();
         I[59 ^ 107].length();
         IllegalArgumentException var1 = new IllegalArgumentException(var0 + I[116 ^ 37]);
         I[15 ^ 93].length();
         I[50 ^ 97].length();
         I[232 ^ 188].length();
         I[26 ^ 79].length();
         throw var1;
      }
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[228 ^ 198];
      String var10001 = I[74 ^ 105];
      String var10002 = I[183 ^ 147];
      var10001 = I[173 ^ 136];
      var10000 = I[117 ^ 83];
      var10001 = I[144 ^ 183];
      var10002 = I[52 ^ 28];
      var10001 = I[190 ^ 151];
      var10000 = I[31 ^ 53];
      var10001 = I[69 ^ 110];
      var10002 = I[234 ^ 198];
      var10001 = I[9 ^ 36];
      var10000 = I[173 ^ 131];
      var10001 = I[64 ^ 111];
      var10002 = I[5 ^ 53];
      var10001 = I[61 ^ 12];
      var10000 = I[161 ^ 147];
      var10001 = I[47 ^ 28];
      var10002 = I[130 ^ 182];
      var10001 = I[30 ^ 43];
      var10000 = I[166 ^ 144];
      var10001 = I[96 ^ 87];
      var10002 = I[4 ^ 60];
      var10001 = I[17 ^ 40];
      I[162 ^ 152].length();
      IProperty[] var10003 = new IProperty[120 ^ 125];
      I[107 ^ 80].length();
      I[248 ^ 196].length();
      var10003["".length()] = UP;
      I[143 ^ 178].length();
      var10003[" ".length()] = NORTH;
      I[184 ^ 134].length();
      I[190 ^ 129].length();
      var10003["  ".length()] = EAST;
      I[207 ^ 143].length();
      I[52 ^ 117].length();
      var10003["   ".length()] = SOUTH;
      I[57 ^ 123].length();
      I[24 ^ 91].length();
      I[195 ^ 135].length();
      I[46 ^ 107].length();
      var10003[120 ^ 124] = WEST;
      return new BlockStateContainer(this, var10003);
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      String var10000 = I[60 ^ 33];
      String var10001 = I[148 ^ 138];
      String var10002 = I[219 ^ 196];
      var10001 = I[72 ^ 104];
      if (!var1.isRemote && var6.getItem() == Items.SHEARS) {
         var2.addStat(StatList.getBlockStats(this));
         I[85 ^ 116].length();
         spawnAsEntity(var1, var3, new ItemStack(Blocks.VINE, " ".length(), "".length()));
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         super.harvestBlock(var1, var2, var3, var4, var5, var6);
      }

   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote && var1.rand.nextInt(171 ^ 175) == 0) {
         int var5 = 22 ^ 18;
         int var6 = 121 ^ 124;
         int var7 = "".length();
         int var8 = -(57 ^ 61);

         label213:
         while(var8 <= (80 ^ 84)) {
            int var9 = -(157 ^ 153);

            while(var9 <= (32 ^ 36)) {
               int var10 = -" ".length();

               while(var10 <= " ".length()) {
                  if (var1.getBlockState(var2.add(var8, var10, var9)).getBlock() == this) {
                     --var6;
                     if (var6 <= 0) {
                        var7 = " ".length();
                        "".length();
                        if (false) {
                           throw null;
                        }
                        break label213;
                     }
                  }

                  ++var10;
                  "".length();
                  if (-1 >= 4) {
                     throw null;
                  }
               }

               ++var9;
               "".length();
               if (4 <= 1) {
                  throw null;
               }
            }

            ++var8;
            "".length();
            if (3 == 0) {
               throw null;
            }
         }

         EnumFacing var19 = EnumFacing.random(var4);
         BlockPos var20 = var2.up();
         if (var19 == EnumFacing.UP && var2.getY() < 7 + 20 - -63 + 165 && var1.isAirBlock(var20)) {
            IBlockState var22 = var3;
            Iterator var23 = EnumFacing.Plane.HORIZONTAL.iterator();

            while(var23.hasNext()) {
               EnumFacing var24 = (EnumFacing)var23.next();
               if (var4.nextBoolean() && this.func_193395_a(var1, var20, var24.getOpposite())) {
                  var22 = var22.withProperty(getPropertyFor(var24), Boolean.valueOf((boolean)" ".length()));
                  "".length();
                  if (4 < 2) {
                     throw null;
                  }
               } else {
                  var22 = var22.withProperty(getPropertyFor(var24), Boolean.valueOf((boolean)"".length()));
               }

               "".length();
               if (-1 != -1) {
                  throw null;
               }
            }

            if ((Boolean)var22.getValue(NORTH) || (Boolean)var22.getValue(EAST) || (Boolean)var22.getValue(SOUTH) || (Boolean)var22.getValue(WEST)) {
               var1.setBlockState(var20, var22, "  ".length());
               I[172 ^ 169].length();
               I[191 ^ 185].length();
               I[51 ^ 52].length();
               I[133 ^ 141].length();
            }

            "".length();
            if (3 < 0) {
               throw null;
            }
         } else {
            IBlockState var11;
            Block var12;
            BlockPos var21;
            if (var19.getAxis().isHorizontal() && !(Boolean)var3.getValue(getPropertyFor(var19))) {
               if (var7 == 0) {
                  var21 = var2.offset(var19);
                  var11 = var1.getBlockState(var21);
                  var12 = var11.getBlock();
                  if (var12.blockMaterial != Material.AIR) {
                     if (var11.func_193401_d(var1, var21, var19) == BlockFaceShape.SOLID) {
                        var1.setBlockState(var2, var3.withProperty(getPropertyFor(var19), Boolean.valueOf((boolean)" ".length())), "  ".length());
                        I[67 ^ 87].length();
                        I[174 ^ 187].length();
                        I[152 ^ 142].length();
                        I[84 ^ 67].length();
                     }
                  } else {
                     EnumFacing var25 = var19.rotateY();
                     EnumFacing var26 = var19.rotateYCCW();
                     boolean var27 = (Boolean)var3.getValue(getPropertyFor(var25));
                     boolean var28 = (Boolean)var3.getValue(getPropertyFor(var26));
                     BlockPos var17 = var21.offset(var25);
                     BlockPos var18 = var21.offset(var26);
                     if (var27 && this.func_193395_a(var1, var17.offset(var25), var25)) {
                        var1.setBlockState(var21, this.getDefaultState().withProperty(getPropertyFor(var25), Boolean.valueOf((boolean)" ".length())), "  ".length());
                        I[15 ^ 6].length();
                        I[170 ^ 160].length();
                        I[25 ^ 18].length();
                        "".length();
                        if (3 <= 1) {
                           throw null;
                        }
                     } else if (var28 && this.func_193395_a(var1, var18.offset(var26), var26)) {
                        var1.setBlockState(var21, this.getDefaultState().withProperty(getPropertyFor(var26), Boolean.valueOf((boolean)" ".length())), "  ".length());
                        I[91 ^ 87].length();
                        "".length();
                        if (1 == 3) {
                           throw null;
                        }
                     } else if (var27 && var1.isAirBlock(var17) && this.func_193395_a(var1, var17, var19)) {
                        var1.setBlockState(var17, this.getDefaultState().withProperty(getPropertyFor(var19.getOpposite()), Boolean.valueOf((boolean)" ".length())), "  ".length());
                        I[174 ^ 163].length();
                        I[126 ^ 112].length();
                        "".length();
                        if (4 < 4) {
                           throw null;
                        }
                     } else if (var28 && var1.isAirBlock(var18) && this.func_193395_a(var1, var18, var19)) {
                        var1.setBlockState(var18, this.getDefaultState().withProperty(getPropertyFor(var19.getOpposite()), Boolean.valueOf((boolean)" ".length())), "  ".length());
                        I[110 ^ 97].length();
                        I[95 ^ 79].length();
                        I[51 ^ 34].length();
                        I[95 ^ 77].length();
                        I[79 ^ 92].length();
                     }

                     "".length();
                     if (1 <= 0) {
                        throw null;
                     }
                  }

                  "".length();
                  if (4 != 4) {
                     throw null;
                  }
               }
            } else if (var2.getY() > " ".length()) {
               var21 = var2.down();
               var11 = var1.getBlockState(var21);
               var12 = var11.getBlock();
               IBlockState var13;
               Iterator var14;
               EnumFacing var15;
               if (var12.blockMaterial == Material.AIR) {
                  var13 = var3;
                  var14 = EnumFacing.Plane.HORIZONTAL.iterator();

                  while(var14.hasNext()) {
                     var15 = (EnumFacing)var14.next();
                     if (var4.nextBoolean()) {
                        var13 = var13.withProperty(getPropertyFor(var15), Boolean.valueOf((boolean)"".length()));
                     }

                     "".length();
                     if (0 <= -1) {
                        throw null;
                     }
                  }

                  if ((Boolean)var13.getValue(NORTH) || (Boolean)var13.getValue(EAST) || (Boolean)var13.getValue(SOUTH) || (Boolean)var13.getValue(WEST)) {
                     var1.setBlockState(var21, var13, "  ".length());
                     I[116 ^ 108].length();
                     I[93 ^ 68].length();
                  }

                  "".length();
                  if (2 == 1) {
                     throw null;
                  }
               } else if (var12 == this) {
                  var13 = var11;
                  var14 = EnumFacing.Plane.HORIZONTAL.iterator();

                  while(var14.hasNext()) {
                     var15 = (EnumFacing)var14.next();
                     PropertyBool var16 = getPropertyFor(var15);
                     if (var4.nextBoolean() && (Boolean)var3.getValue(var16)) {
                        var13 = var13.withProperty(var16, Boolean.valueOf((boolean)" ".length()));
                     }

                     "".length();
                     if (4 == 3) {
                        throw null;
                     }
                  }

                  if ((Boolean)var13.getValue(NORTH) || (Boolean)var13.getValue(EAST) || (Boolean)var13.getValue(SOUTH) || (Boolean)var13.getValue(WEST)) {
                     var1.setBlockState(var21, var13, "  ".length());
                     I[105 ^ 115].length();
                     I[107 ^ 112].length();
                     I[146 ^ 142].length();
                  }
               }
            }
         }
      }

   }

   public boolean func_193395_a(World var1, BlockPos var2, EnumFacing var3) {
      Block var4 = var1.getBlockState(var2.up()).getBlock();
      int var10000;
      if (this.func_193396_c(var1, var2.offset(var3.getOpposite()), var3) && (var4 == Blocks.AIR || var4 == Blocks.VINE || this.func_193396_c(var1, var2.up(), EnumFacing.UP))) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(NORTH));
      case 2:
         return var1.withProperty(EAST, var1.getValue(WEST)).withProperty(WEST, var1.getValue(EAST));
      default:
         return super.withMirror(var1, var2);
      }
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   public boolean isReplaceable(IBlockAccess var1, BlockPos var2) {
      return (boolean)" ".length();
   }

   private static void I() {
      I = new String[92 ^ 7];
      I["".length()] = I("垖夳劕姷昡", "XVDJg");
      I[" ".length()] = I("旺槬坣庌", "WdUQO");
      I["  ".length()] = I("叐廫桼寑昮", "YnYYD");
      I["   ".length()] = I("惱昡挙愶", "PaXiu");
      I[149 ^ 145] = I("噞亭斶扞", "xEldZ");
      I[28 ^ 25] = I("毆", "wwwMB");
      I[70 ^ 64] = I("慹川泇欪", "Nskyp");
      I[8 ^ 15] = I("扝摸寀庯弼", "sRUfx");
      I[129 ^ 137] = I("乻尬吶滦", "YBatL");
      I[9 ^ 0] = I("截歱俣", "UsjvR");
      I[38 ^ 44] = I("嶌擀", "lynPy");
      I[174 ^ 165] = I("敐孹", "YzMYF");
      I[109 ^ 97] = I("喌娓券冴曼", "xhVBY");
      I[27 ^ 22] = I("嗑匡嫓咿", "TaGrO");
      I[183 ^ 185] = I("嚮", "kntKU");
      I[11 ^ 4] = I("殻", "jacJG");
      I[154 ^ 138] = I("嗻刁傶慤", "DXQXQ");
      I[147 ^ 130] = I("充剕嗴堋掳", "goqzT");
      I[63 ^ 45] = I("湸氜灦楳俅", "GVFLw");
      I[165 ^ 182] = I("巛坼歼嘇", "GECpQ");
      I[51 ^ 39] = I("汐", "gzIHW");
      I[89 ^ 76] = I("歘梌寫不", "hOZLl");
      I[148 ^ 130] = I("煍栛扗", "HQEzp");
      I[135 ^ 144] = I("坈晖", "mjuwF");
      I[43 ^ 51] = I("兑滍懓", "SCFjX");
      I[187 ^ 162] = I("愹", "AeNzB");
      I[166 ^ 188] = I("岈曰嵑剙庬", "MgJfs");
      I[46 ^ 53] = I("嵵椃吜做堝", "BMdcs");
      I[140 ^ 144] = I("樽", "dCJYT");
      I[57 ^ 36] = I("敉炮", "yuKrF");
      I[141 ^ 147] = I("噋摰", "EHgBi");
      I[185 ^ 166] = I("烿煐", "vNLBU");
      I[155 ^ 187] = I("凮岍", "KVNwS");
      I[79 ^ 110] = I("妉夭夼", "HGIGA");
      I[101 ^ 71] = I("油更", "tzoQj");
      I[17 ^ 50] = I("庒慻", "TXgQu");
      I[72 ^ 108] = I("湐懸", "OiCAY");
      I[151 ^ 178] = I("俹嫊", "MJdqk");
      I[13 ^ 43] = I("僜敜", "jHgyV");
      I[87 ^ 112] = I("婤宏", "nAWEV");
      I[105 ^ 65] = I("啸彑", "NUypE");
      I[238 ^ 199] = I("渟槏", "ySAAB");
      I[121 ^ 83] = I("京朐", "vsfRZ");
      I[133 ^ 174] = I("伋六", "pqfeu");
      I[149 ^ 185] = I("渡伷", "mwbwu");
      I[15 ^ 34] = I("囁炶", "ErhFU");
      I[9 ^ 39] = I("哮幯", "GIcPP");
      I[139 ^ 164] = I("婍哼", "UVwRY");
      I[6 ^ 54] = I("坧儓", "vpHLq");
      I[62 ^ 15] = I("性毜", "sWeEe");
      I[104 ^ 90] = I("灡垾", "EkBCa");
      I[136 ^ 187] = I("匎亏", "xkrNu");
      I[128 ^ 180] = I("榿怴", "WKiwA");
      I[129 ^ 180] = I("埙攠", "rgXbn");
      I[98 ^ 84] = I("冼娹", "wXwIX");
      I[108 ^ 91] = I("党敢", "gfJwb");
      I[94 ^ 102] = I("懂屨", "XcklX");
      I[43 ^ 18] = I("娄懲", "bDKdb");
      I[160 ^ 154] = I("懋栣拤匐", "lGcIq");
      I[46 ^ 21] = I("卤儈棒撪", "KZhRP");
      I[251 ^ 199] = I("榒湌揨湾堲", "qHvgy");
      I[76 ^ 113] = I("伬亾怋", "uUVeQ");
      I[150 ^ 168] = I("匵桤恤壟", "LnOHS");
      I[105 ^ 86] = I("溮湙块挢", "QEaCc");
      I[78 ^ 14] = I("寸妳浀", "xQoCZ");
      I[134 ^ 199] = I("旋", "IWRSR");
      I[127 ^ 61] = I("懼殦嶠押", "VCyCj");
      I[126 ^ 61] = I("嗄", "RKviw");
      I[103 ^ 35] = I("垏", "DcDTm");
      I[224 ^ 165] = I("柽产", "yKRIT");
      I[234 ^ 172] = I("勻忬", "PvFBq");
      I[61 ^ 122] = I("宾嚱", "VrVsi");
      I[119 ^ 63] = I("劭媒", "PDtav");
      I[254 ^ 183] = I("堊噭", "KDzzm");
      I[113 ^ 59] = I("旇恋", "JrCFx");
      I[57 ^ 114] = I("桛朂", "OmwQo");
      I[92 ^ 16] = I("杖厒", "ITyDB");
      I[200 ^ 133] = I("滿消", "kfmcE");
      I[34 ^ 108] = I("峧嫧憩亓欱", "iJdrZ");
      I[252 ^ 179] = I("彎滿寻岤", "ZNXjF");
      I[193 ^ 145] = I("憮以渞炫刦", "iFsUX");
      I[11 ^ 90] = I("G8\u0016t2\tq\f:%\u0006=\f0s\u00049\n=0\u0002", "gQeTS");
      I[251 ^ 169] = I("潀湘", "LFGJs");
      I[115 ^ 32] = I("尠倃", "vknan");
      I[108 ^ 56] = I("垑桷區枏", "WnHKE");
      I[37 ^ 112] = I("墊", "xxVdE");
      I[82 ^ 4] = I("\u0007\u0014", "rdSap");
      I[118 ^ 33] = I("\u0007\n\u001d\u001f\u0003", "ieokk");
      I[48 ^ 104] = I(" \t\u0018!", "EhkUX");
      I[31 ^ 70] = I("<*$;\u001b", "OEQOs");
      I[110 ^ 52] = I("\u0010\u0013\u001d\u0000", "gvntH");
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote && !this.recheckGrownSides(var2, var3, var1)) {
         this.dropBlockAsItem(var2, var3, var1, "".length());
         var2.setBlockToAir(var3);
         I["   ".length()].length();
         I[93 ^ 89].length();
      }

   }

   public BlockVine() {
      super(Material.VINE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(UP, Boolean.valueOf((boolean)"".length())).withProperty(NORTH, Boolean.valueOf((boolean)"".length())).withProperty(EAST, Boolean.valueOf((boolean)"".length())).withProperty(SOUTH, Boolean.valueOf((boolean)"".length())).withProperty(WEST, Boolean.valueOf((boolean)"".length())));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      var1 = var1.getActualState(var2, var3);
      int var4 = "".length();
      AxisAlignedBB var5 = FULL_BLOCK_AABB;
      if ((Boolean)var1.getValue(UP)) {
         var5 = UP_AABB;
         ++var4;
      }

      if ((Boolean)var1.getValue(NORTH)) {
         var5 = NORTH_AABB;
         ++var4;
      }

      if ((Boolean)var1.getValue(EAST)) {
         var5 = EAST_AABB;
         ++var4;
      }

      if ((Boolean)var1.getValue(SOUTH)) {
         var5 = SOUTH_AABB;
         ++var4;
      }

      if ((Boolean)var1.getValue(WEST)) {
         var5 = WEST_AABB;
         ++var4;
      }

      AxisAlignedBB var10000;
      if (var4 == " ".length()) {
         var10000 = var5;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = FULL_BLOCK_AABB;
      }

      return var10000;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      IBlockState var9 = this.getDefaultState().withProperty(UP, Boolean.valueOf((boolean)"".length())).withProperty(NORTH, Boolean.valueOf((boolean)"".length())).withProperty(EAST, Boolean.valueOf((boolean)"".length())).withProperty(SOUTH, Boolean.valueOf((boolean)"".length())).withProperty(WEST, Boolean.valueOf((boolean)"".length()));
      IBlockState var10000;
      if (var3.getAxis().isHorizontal()) {
         var10000 = var9.withProperty(getPropertyFor(var3.getOpposite()), Boolean.valueOf((boolean)" ".length()));
         "".length();
         if (3 < 1) {
            throw null;
         }
      } else {
         var10000 = var9;
      }

      return var10000;
   }

   private boolean recheckGrownSides(World var1, BlockPos var2, IBlockState var3) {
      IBlockState var4 = var3;
      Iterator var5 = EnumFacing.Plane.HORIZONTAL.iterator();

      do {
         if (!var5.hasNext()) {
            if (getNumGrownFaces(var3) == 0) {
               return (boolean)"".length();
            }

            if (var4 != var3) {
               var1.setBlockState(var2, var3, "  ".length());
               I["".length()].length();
               I[" ".length()].length();
               I["  ".length()].length();
            }

            return (boolean)" ".length();
         }

         EnumFacing var6 = (EnumFacing)var5.next();
         PropertyBool var7 = getPropertyFor(var6);
         if ((Boolean)var3.getValue(var7) && !this.func_193395_a(var1, var2, var6.getOpposite())) {
            IBlockState var8 = var1.getBlockState(var2.up());
            if (var8.getBlock() != this || !(Boolean)var8.getValue(var7)) {
               var3 = var3.withProperty(var7, Boolean.valueOf((boolean)"".length()));
            }
         }

         "".length();
      } while(0 > -1);

      throw null;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(EAST, var1.getValue(WEST)).withProperty(SOUTH, var1.getValue(NORTH)).withProperty(WEST, var1.getValue(EAST));
      case 2:
         return var1.withProperty(NORTH, var1.getValue(EAST)).withProperty(EAST, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(WEST)).withProperty(WEST, var1.getValue(NORTH));
      case 3:
         return var1.withProperty(NORTH, var1.getValue(WEST)).withProperty(EAST, var1.getValue(NORTH)).withProperty(SOUTH, var1.getValue(EAST)).withProperty(WEST, var1.getValue(SOUTH));
      default:
         return var1;
      }
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState();
      PropertyBool var10001 = SOUTH;
      int var10002;
      if ((var1 & " ".length()) > 0) {
         var10002 = " ".length();
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = WEST;
      if ((var1 & "  ".length()) > 0) {
         var10002 = " ".length();
         "".length();
         if (-1 == 3) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = NORTH;
      if ((var1 & (101 ^ 97)) > 0) {
         var10002 = " ".length();
         "".length();
         if (2 < 2) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = EAST;
      if ((var1 & (147 ^ 155)) > 0) {
         var10002 = " ".length();
         "".length();
         if (2 < 1) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 != 1);

      throw null;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.field_190931_a;
   }

   protected static boolean func_193397_e(Block var0) {
      int var10000;
      if (!(var0 instanceof BlockShulkerBox) && var0 != Blocks.BEACON && var0 != Blocks.CAULDRON && var0 != Blocks.GLASS && var0 != Blocks.STAINED_GLASS && var0 != Blocks.PISTON && var0 != Blocks.STICKY_PISTON && var0 != Blocks.PISTON_HEAD && var0 != Blocks.TRAPDOOR) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (1 == 3) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public static int getNumGrownFaces(IBlockState var0) {
      int var1 = "".length();
      PropertyBool[] var2 = ALL_FACES;
      int var3 = var2.length;
      int var4 = "".length();

      do {
         if (var4 >= var3) {
            return var1;
         }

         PropertyBool var5 = var2[var4];
         if ((Boolean)var0.getValue(var5)) {
            ++var1;
         }

         ++var4;
         "".length();
      } while(4 >= 3);

      throw null;
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      BlockPos var4 = var3.up();
      PropertyBool var10001 = UP;
      int var10002;
      if (var2.getBlockState(var4).func_193401_d(var2, var4, EnumFacing.DOWN) == BlockFaceShape.SOLID) {
         var10002 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var1.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public boolean canPlaceBlockOnSide(World var1, BlockPos var2, EnumFacing var3) {
      int var10000;
      if (var3 != EnumFacing.DOWN && var3 != EnumFacing.UP && this.func_193395_a(var1, var2, var3)) {
         var10000 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   static {
      I();
      UP = PropertyBool.create(I[104 ^ 62]);
      NORTH = PropertyBool.create(I[50 ^ 101]);
      EAST = PropertyBool.create(I[105 ^ 49]);
      SOUTH = PropertyBool.create(I[208 ^ 137]);
      WEST = PropertyBool.create(I[255 ^ 165]);
      PropertyBool[] var10000 = new PropertyBool[28 ^ 25];
      var10000["".length()] = UP;
      var10000[" ".length()] = NORTH;
      var10000["  ".length()] = SOUTH;
      var10000["   ".length()] = WEST;
      var10000[158 ^ 154] = EAST;
      ALL_FACES = var10000;
      UP_AABB = new AxisAlignedBB(0.0D, 0.9375D, 0.0D, 1.0D, 1.0D, 1.0D);
      WEST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.0625D, 1.0D, 1.0D);
      EAST_AABB = new AxisAlignedBB(0.9375D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      NORTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.0625D);
      SOUTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.9375D, 1.0D, 1.0D, 1.0D);
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      if ((Boolean)var1.getValue(SOUTH)) {
         var2 |= " ".length();
      }

      if ((Boolean)var1.getValue(WEST)) {
         var2 |= "  ".length();
      }

      if ((Boolean)var1.getValue(NORTH)) {
         var2 |= 1 ^ 5;
      }

      if ((Boolean)var1.getValue(EAST)) {
         var2 |= 81 ^ 89;
      }

      return var2;
   }
}

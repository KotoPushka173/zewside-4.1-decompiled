package net.minecraft.enchantment;

import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentLootBonus extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public int getMaxLevel() {
      return "   ".length();
   }

   protected EnchantmentLootBonus(Enchantment.Rarity var1, EnumEnchantmentType var2, EntityEquipmentSlot... var3) {
      super(var1, var2, var3);
      if (var2 == EnumEnchantmentType.DIGGER) {
         this.setName(I["".length()]);
         "".length();
         if (1 < 0) {
            throw null;
         }
      } else if (var2 == EnumEnchantmentType.FISHING_ROD) {
         this.setName(I[" ".length()]);
         "".length();
         if (-1 >= 1) {
            throw null;
         }
      } else {
         this.setName(I["  ".length()]);
      }

   }

   private static void I() {
      I = new String[163 ^ 165];
      I["".length()] = I(">.,$\u0003=/6#\u0005;&$53", "RACPA");
      I[" ".length()] = I("\u001b6\u0019<\u001a\u00187\u0003;\u001e\u001e*\u001e!6\u0010", "wYvHX");
      I["  ".length()] = I("\n>\n\u001f,\t?\u0010\u0018", "fQekn");
      I["   ".length()] = I("堣妻捚", "JUaqG");
      I[36 ^ 32] = I("毆", "xgpZs");
      I[79 ^ 74] = I("湘淬埲夐庶", "WilMb");
   }

   public boolean canApplyTogether(Enchantment var1) {
      int var10000;
      if (super.canApplyTogether(var1) && var1 != Enchantments.SILK_TOUCH) {
         var10000 = " ".length();
         "".length();
         if (4 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int getMaxEnchantability(int var1) {
      return super.getMinEnchantability(var1) + (149 ^ 167);
   }

   public int getMinEnchantability(int var1) {
      int var10000 = 69 ^ 74;
      int var10002 = " ".length();
      I["   ".length()].length();
      I[28 ^ 24].length();
      I[24 ^ 29].length();
      return var10000 + (var1 - var10002) * (159 ^ 150);
   }

   static {
      I();
   }
}

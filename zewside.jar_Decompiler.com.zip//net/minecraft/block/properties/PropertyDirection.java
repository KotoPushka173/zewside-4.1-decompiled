package net.minecraft.block.properties;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import java.util.Collection;
import net.minecraft.util.EnumFacing;

public class PropertyDirection extends PropertyEnum<EnumFacing> {
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   public static PropertyDirection create(String var0, Collection<EnumFacing> var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[133 ^ 129].length();
      I[30 ^ 27].length();
      I[114 ^ 116].length();
      return new PropertyDirection(var0, var1);
   }

   static {
      I();
   }

   public static PropertyDirection create(String var0, Predicate<EnumFacing> var1) {
      return create(var0, Collections2.filter(Lists.newArrayList(EnumFacing.values()), var1));
   }

   public static PropertyDirection create(String var0) {
      return create(var0, Predicates.alwaysTrue());
   }

   protected PropertyDirection(String var1, Collection<EnumFacing> var2) {
      super(var1, EnumFacing.class, var2);
   }

   private static void I() {
      I = new String[96 ^ 103];
      I["".length()] = I("岘殕", "kNqsd");
      I[" ".length()] = I("弸慈", "zDuMa");
      I["  ".length()] = I("戢淗", "AdZvh");
      I["   ".length()] = I("朎榍", "ngauI");
      I[172 ^ 168] = I("渃灅", "hLzYE");
      I[18 ^ 23] = I("兢勄偼", "GsvEU");
      I[160 ^ 166] = I("嚨匳", "AulXZ");
   }
}

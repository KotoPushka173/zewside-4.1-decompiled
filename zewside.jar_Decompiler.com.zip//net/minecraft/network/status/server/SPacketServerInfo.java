package net.minecraft.network.status.server;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.ServerStatusResponse;
import net.minecraft.network.status.INetHandlerStatusClient;
import net.minecraft.util.EnumTypeAdapterFactory;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;

public class SPacketServerInfo implements Packet<INetHandlerStatusClient> {
   // $FF: synthetic field
   private static final Gson GSON;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private ServerStatusResponse response;

   public SPacketServerInfo() {
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("壾懫娣毃", "cyOEZ");
      I[" ".length()] = I("淯氛潑晽", "WCIgL");
      I["  ".length()] = I("烖攙", "aIynB");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.response = (ServerStatusResponse)JsonUtils.gsonDeserialize(GSON, var1.readStringFromBuffer(24641 + 10523 - 12356 + 9959), ServerStatusResponse.class);
   }

   public SPacketServerInfo(ServerStatusResponse var1) {
      this.response = var1;
   }

   public ServerStatusResponse getResponse() {
      return this.response;
   }

   public void processPacket(INetHandlerStatusClient var1) {
      var1.handleServerInfo(this);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 4);

      throw null;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(GSON.toJson(this.response));
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }

   static {
      I();
      GSON = (new GsonBuilder()).registerTypeAdapter(ServerStatusResponse.Version.class, new ServerStatusResponse.Version.Serializer()).registerTypeAdapter(ServerStatusResponse.Players.class, new ServerStatusResponse.Players.Serializer()).registerTypeAdapter(ServerStatusResponse.class, new ServerStatusResponse.Serializer()).registerTypeHierarchyAdapter(ITextComponent.class, new ITextComponent.Serializer()).registerTypeHierarchyAdapter(Style.class, new Style.Serializer()).registerTypeAdapterFactory(new EnumTypeAdapterFactory()).create();
   }
}

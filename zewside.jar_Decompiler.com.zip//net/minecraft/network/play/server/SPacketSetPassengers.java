package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketSetPassengers implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int[] passengerIds;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeVarIntArray(this.passengerIds);
      I[40 ^ 44].length();
      I[43 ^ 46].length();
   }

   public int[] getPassengerIds() {
      return this.passengerIds;
   }

   public int getEntityId() {
      return this.entityId;
   }

   private static void I() {
      I = new String[57 ^ 63];
      I["".length()] = I("囜慥涔澳", "NHQUb");
      I[" ".length()] = I("毪樯", "LZwoj");
      I["  ".length()] = I("崢", "Uthap");
      I["   ".length()] = I("吽倇兌勳", "HteRP");
      I[99 ^ 103] = I("抋沣剈液", "dWida");
      I[135 ^ 130] = I("嘁旈", "CaRGX");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.passengerIds = var1.readVarIntArray();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSetPassengers(this);
   }

   public SPacketSetPassengers() {
   }

   public SPacketSetPassengers(Entity var1) {
      this.entityId = var1.getEntityId();
      List var2 = var1.getPassengers();
      this.passengerIds = new int[var2.size()];
      int var3 = "".length();

      do {
         if (var3 >= var2.size()) {
            return;
         }

         this.passengerIds[var3] = ((Entity)var2.get(var3)).getEntityId();
         ++var3;
         "".length();
      } while(3 > -1);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   static {
      I();
   }
}

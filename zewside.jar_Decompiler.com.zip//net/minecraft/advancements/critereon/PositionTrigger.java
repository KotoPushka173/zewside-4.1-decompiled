package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.WorldServer;

public class PositionTrigger implements ICriterionTrigger<PositionTrigger.Instance> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, PositionTrigger.Listeners> field_192218_b = Maps.newHashMap();
   // $FF: synthetic field
   private final ResourceLocation field_192217_a;

   private static void I() {
      I = new String[186 ^ 175];
      I["".length()] = I("斛刯", "KJzmQ");
      I[" ".length()] = I("叀昗", "NCdHm");
      I["  ".length()] = I("欽割", "MVdyj");
      I["   ".length()] = I("嵴懼", "XtpSP");
      I[175 ^ 171] = I("巟", "gTrwA");
      I[175 ^ 170] = I("娵吕", "uhysQ");
      I[84 ^ 82] = I("匿哌", "wgCVJ");
      I[198 ^ 193] = I("杖", "SyFKC");
      I[85 ^ 93] = I("晝", "UIDGv");
      I[123 ^ 114] = I("樎潚", "skpSR");
      I[146 ^ 152] = I("廒劺千墿", "HiYIA");
      I[41 ^ 34] = I("呕", "rYdZU");
      I[190 ^ 178] = I("湓昜樒炌喒", "GWMAN");
      I[170 ^ 167] = I("孚恴", "pdOxr");
      I[70 ^ 72] = I("或夡", "ywEoR");
      I[74 ^ 69] = I("忝亀", "cqfZk");
      I[165 ^ 181] = I("懂兛", "HXTUX");
      I[142 ^ 159] = I("斳嫎曍吽", "IUhMP");
      I[182 ^ 164] = I("晻敉庹庳", "ZIHYU");
      I[141 ^ 158] = I("氛幝儽溅", "wtird");
      I[34 ^ 54] = I("帹悡橥湵", "wyeij");
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192218_b.remove(var1);
      I[169 ^ 162].length();
      I[188 ^ 176].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<PositionTrigger.Instance> var2) {
      PositionTrigger.Listeners var3 = (PositionTrigger.Listeners)this.field_192218_b.get(var1);
      if (var3 != null) {
         var3.func_192507_b(var2);
         if (var3.func_192508_a()) {
            this.field_192218_b.remove(var1);
            I[66 ^ 75].length();
            I[4 ^ 14].length();
         }
      }

   }

   public ResourceLocation func_192163_a() {
      return this.field_192217_a;
   }

   public PositionTrigger(ResourceLocation var1) {
      this.field_192217_a = var1;
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<PositionTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      PositionTrigger.Listeners var3 = (PositionTrigger.Listeners)this.field_192218_b.get(var1);
      if (var3 == null) {
         I[27 ^ 31].length();
         I[143 ^ 138].length();
         var3 = new PositionTrigger.Listeners(var1);
         this.field_192218_b.put(var1, var3);
         I[113 ^ 119].length();
         I[114 ^ 117].length();
         I[48 ^ 56].length();
      }

      var3.func_192510_a(var2);
   }

   public PositionTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[0 ^ 13];
      String var10001 = I[101 ^ 107];
      String var10002 = I[182 ^ 185];
      var10001 = I[124 ^ 108];
      LocationPredicate var3 = LocationPredicate.func_193454_a(var1);
      I[60 ^ 45].length();
      I[85 ^ 71].length();
      I[208 ^ 195].length();
      I[43 ^ 63].length();
      return new PositionTrigger.Instance(this.field_192217_a, var3);
   }

   static {
      I();
   }

   public void func_192215_a(EntityPlayerMP var1) {
      PositionTrigger.Listeners var2 = (PositionTrigger.Listeners)this.field_192218_b.get(var1.func_192039_O());
      if (var2 != null) {
         var2.func_193462_a(var1.getServerWorld(), var1.posX, var1.posY, var1.posZ);
      }

   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final LocationPredicate field_193205_a;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 == -1);

         throw null;
      }

      public Instance(ResourceLocation var1, LocationPredicate var2) {
         super(var1);
         this.field_193205_a = var2;
      }

      public boolean func_193204_a(WorldServer var1, double var2, double var4, double var6) {
         return this.field_193205_a.func_193452_a(var1, var2, var4, var6);
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_192511_a;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<PositionTrigger.Instance>> field_192512_b = Sets.newHashSet();
      // $FF: synthetic field
      private static final String[] I;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= 0);

         throw null;
      }

      private static void I() {
         I = new String[34 ^ 42];
         I["".length()] = I("娉樬", "usWCZ");
         I[" ".length()] = I("攋", "QnzOJ");
         I["  ".length()] = I("傕", "lwlOo");
         I["   ".length()] = I("昽姺涫刱孄", "EDyRd");
         I[104 ^ 108] = I("氧刌呍晪", "NvynB");
         I[119 ^ 114] = I("湊", "lAoej");
         I[90 ^ 92] = I("唨昨委恳審", "cpoBM");
         I[30 ^ 25] = I("嫴煐國撠", "mnbof");
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192511_a = var1;
      }

      public boolean func_192508_a() {
         return this.field_192512_b.isEmpty();
      }

      static {
         I();
      }

      public void func_192510_a(ICriterionTrigger.Listener<PositionTrigger.Instance> var1) {
         this.field_192512_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      public void func_192507_b(ICriterionTrigger.Listener<PositionTrigger.Instance> var1) {
         this.field_192512_b.remove(var1);
         I["  ".length()].length();
         I["   ".length()].length();
         I[162 ^ 166].length();
      }

      public void func_193462_a(WorldServer var1, double var2, double var4, double var6) {
         ArrayList var8 = null;
         Iterator var9 = this.field_192512_b.iterator();

         ICriterionTrigger.Listener var10;
         while(var9.hasNext()) {
            var10 = (ICriterionTrigger.Listener)var9.next();
            if (((PositionTrigger.Instance)var10.func_192158_a()).func_193204_a(var1, var2, var4, var6)) {
               if (var8 == null) {
                  var8 = Lists.newArrayList();
               }

               var8.add(var10);
               I[187 ^ 190].length();
               I[90 ^ 92].length();
               I[49 ^ 54].length();
            }

            "".length();
            if (2 <= -1) {
               throw null;
            }
         }

         if (var8 != null) {
            var9 = var8.iterator();

            while(var9.hasNext()) {
               var10 = (ICriterionTrigger.Listener)var9.next();
               var10.func_192159_a(this.field_192511_a);
               "".length();
               if (false) {
                  throw null;
               }
            }
         }

      }
   }
}

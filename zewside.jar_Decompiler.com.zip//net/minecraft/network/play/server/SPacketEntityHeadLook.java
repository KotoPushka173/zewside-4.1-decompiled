package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.World;

public class SPacketEntityHeadLook implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private byte yaw;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int entityId;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeByte(this.yaw);
      I["   ".length()].length();
      I[115 ^ 119].length();
   }

   public SPacketEntityHeadLook(Entity var1, byte var2) {
      this.entityId = var1.getEntityId();
      this.yaw = var2;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityHeadLook(this);
   }

   public Entity getEntity(World var1) {
      return var1.getEntityByID(this.entityId);
   }

   static {
      I();
   }

   public byte getYaw() {
      return this.yaw;
   }

   public SPacketEntityHeadLook() {
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.yaw = var1.readByte();
   }

   private static void I() {
      I = new String[143 ^ 138];
      I["".length()] = I("廧塧", "oRaIj");
      I[" ".length()] = I("殞劋炡倊殯", "ruOnj");
      I["  ".length()] = I("匱", "yVadF");
      I["   ".length()] = I("堑榲乜斍栏", "VOffB");
      I[90 ^ 94] = I("嗀娦尞", "LRPek");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }
}

package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockFarmland extends Block {
   // $FF: synthetic field
   public static final PropertyInteger MOISTURE;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB FARMLAND_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB field_194405_c;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 4);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(MOISTURE);
   }

   private boolean hasWater(World var1, BlockPos var2) {
      Iterator var3 = BlockPos.getAllInBoxMutable(var2.add(-(39 ^ 35), "".length(), -(154 ^ 158)), var2.add(52 ^ 48, " ".length(), 127 ^ 123)).iterator();

      do {
         if (!var3.hasNext()) {
            return (boolean)"".length();
         }

         BlockPos.MutableBlockPos var4 = (BlockPos.MutableBlockPos)var3.next();
         if (var1.getBlockState(var4).getMaterial() == Material.WATER) {
            return (boolean)" ".length();
         }

         "".length();
      } while(0 >= 0);

      throw null;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return FARMLAND_AABB;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Blocks.DIRT.getItemDropped(Blocks.DIRT.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.DIRT), var2, var3);
   }

   private static void I() {
      I = new String[133 ^ 160];
      I["".length()] = I("橍喌呰倀愎", "gaBXT");
      I[" ".length()] = I("偙宕扔煁榻", "tlExy");
      I["  ".length()] = I("凉圶渜嶦刷", "SbTtX");
      I["   ".length()] = I("堇凧瀷搲", "evDDh");
      I[187 ^ 191] = I("唩殣嵗吾斎", "BaRuY");
      I[196 ^ 193] = I("惠", "czrII");
      I[10 ^ 12] = I("愆澒嗣烔涡", "bHrrD");
      I[53 ^ 50] = I("嚸嬎曐棶濤", "YjSjc");
      I[101 ^ 109] = I("岈场", "Jddhk");
      I[163 ^ 170] = I("俁埪恻末坂", "pBLoP");
      I[40 ^ 34] = I("歼埭嚙惮楐", "LBNFD");
      I[29 ^ 22] = I("宛婐", "PPOja");
      I[26 ^ 22] = I("崞厾啱欫", "MeALz");
      I[181 ^ 184] = I("\u000e8\b(\u0014\n2\f\u0006\b\u0004", "cWjof");
      I[203 ^ 197] = I("廰懹", "OchYH");
      I[82 ^ 93] = I("敤沑檓", "AkGBe");
      I[144 ^ 128] = I("仔楌暔", "GlzLR");
      I[79 ^ 94] = I("宭旒", "tXfRj");
      I[149 ^ 135] = I("劶傡", "MiySD");
      I[160 ^ 179] = I("墴", "udcsh");
      I[35 ^ 55] = I("屰伪", "EcIxJ");
      I[142 ^ 155] = I("嶯朓刱", "YcEDX");
      I[93 ^ 75] = I("塧姺烯垲", "lnyRH");
      I[129 ^ 150] = I("夐弊", "nVIlS");
      I[170 ^ 178] = I("曚冉", "lzGcz");
      I[31 ^ 6] = I("工壿", "Wqqvs");
      I[77 ^ 87] = I("乸澚", "KJRlP");
      I[170 ^ 177] = I("夾煩", "bKgLi");
      I[31 ^ 3] = I("悒瀜", "NaLbT");
      I[123 ^ 102] = I("崉忻", "NKWgo");
      I[86 ^ 72] = I("潿渷", "FNMks");
      I[162 ^ 189] = I("悙歗", "bmkAS");
      I[100 ^ 68] = I("傡悡", "dKXgU");
      I[154 ^ 187] = I("氄堰嶇", "ZWPAY");
      I[146 ^ 176] = I("昔漅尐幣搸", "diqxm");
      I[168 ^ 139] = I("切斨嘤呋広", "ouTcs");
      I[137 ^ 173] = I("(\u000b1<\u00100\u0016=", "EdXOd");
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[80 ^ 71];
      String var10001 = I[124 ^ 100];
      String var10002 = I[54 ^ 47];
      var10001 = I[132 ^ 158];
      var10000 = I[15 ^ 20];
      var10001 = I[120 ^ 100];
      var10002 = I[138 ^ 151];
      var10001 = I[163 ^ 189];
      I[172 ^ 179].length();
      I[147 ^ 179].length();
      I[150 ^ 183].length();
      I[182 ^ 148].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[131 ^ 160].length();
      var10003["".length()] = MOISTURE;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(MOISTURE, var1 & (154 ^ 157));
   }

   private boolean hasCrops(World var1, BlockPos var2) {
      Block var3 = var1.getBlockState(var2.up()).getBlock();
      int var10000;
      if (!(var3 instanceof BlockCrops) && !(var3 instanceof BlockStem)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      int var5 = (Integer)var3.getValue(MOISTURE);
      if (!this.hasWater(var1, var2) && !var1.isRainingAt(var2.up())) {
         if (var5 > 0) {
            PropertyInteger var10003 = MOISTURE;
            int var10005 = " ".length();
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            I["   ".length()].length();
            I[73 ^ 77].length();
            var1.setBlockState(var2, var3.withProperty(var10003, var5 - var10005), "  ".length());
            I[93 ^ 88].length();
            I[176 ^ 182].length();
            I[92 ^ 91].length();
            "".length();
            if (4 <= 1) {
               throw null;
            }
         } else if (!this.hasCrops(var1, var2)) {
            func_190970_b(var1, var2);
            "".length();
            if (0 < 0) {
               throw null;
            }
         }
      } else if (var5 < (31 ^ 24)) {
         var1.setBlockState(var2, var3.withProperty(MOISTURE, 90 ^ 93), "  ".length());
         I[174 ^ 166].length();
         I[72 ^ 65].length();
         I[61 ^ 55].length();
      }

   }

   public void onFallenUpon(World var1, BlockPos var2, Entity var3, float var4) {
      if (!var1.isRemote) {
         float var10000 = var1.rand.nextFloat();
         I[152 ^ 147].length();
         I[104 ^ 100].length();
         if (var10000 < var4 - 0.5F && var3 instanceof EntityLivingBase && (var3 instanceof EntityPlayer || var1.getGameRules().getBoolean(I[133 ^ 136])) && var3.width * var3.width * var3.height > 0.512F) {
            func_190970_b(var1, var2);
         }
      }

      super.onFallenUpon(var1, var2, var3, var4);
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var4.ordinal()]) {
      case 1:
         return (boolean)" ".length();
      case 2:
      case 3:
      case 4:
      case 5:
         IBlockState var5 = var2.getBlockState(var3.offset(var4));
         Block var6 = var5.getBlock();
         int var10000;
         if (!var5.isOpaqueCube() && var6 != Blocks.FARMLAND && var6 != Blocks.GRASS_PATH) {
            var10000 = " ".length();
            "".length();
            if (4 < 2) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      default:
         return super.shouldSideBeRendered(var1, var2, var3, var4);
      }
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      super.neighborChanged(var1, var2, var3, var4, var5);
      if (var2.getBlockState(var3.up()).getMaterial().isSolid()) {
         func_190970_b(var2, var3);
      }

   }

   protected BlockFarmland() {
      super(Material.GROUND);
      this.setDefaultState(this.blockState.getBaseState().withProperty(MOISTURE, "".length()));
      this.setTickRandomly((boolean)" ".length());
      this.setLightOpacity(29 + 213 - 94 + 107);
   }

   protected static void func_190970_b(World var0, BlockPos var1) {
      var0.setBlockState(var1, Blocks.DIRT.getDefaultState());
      I[111 ^ 97].length();
      I[187 ^ 180].length();
      AxisAlignedBB var2 = field_194405_c.offset(var1);
      Iterator var3 = var0.getEntitiesWithinAABBExcludingEntity((Entity)null, var2).iterator();

      do {
         if (!var3.hasNext()) {
            return;
         }

         Entity var4 = (Entity)var3.next();
         double var10000 = var2.maxY;
         double var10001 = var2.minY;
         I[28 ^ 12].length();
         I[115 ^ 98].length();
         I[172 ^ 190].length();
         I[172 ^ 191].length();
         var10000 -= var10001;
         var10001 = var2.maxY;
         double var10002 = var4.getEntityBoundingBox().minY;
         I[36 ^ 48].length();
         I[32 ^ 53].length();
         I[112 ^ 102].length();
         double var5 = Math.min(var10000, var10001 - var10002);
         var4.setPositionAndUpdate(var4.posX, var4.posY + var5 + 0.001D, var4.posZ);
         "".length();
      } while(3 >= -1);

      throw null;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = BlockFaceShape.SOLID;
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   static {
      I();
      MOISTURE = PropertyInteger.create(I[61 ^ 25], "".length(), 103 ^ 96);
      FARMLAND_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.9375D, 1.0D);
      field_194405_c = new AxisAlignedBB(0.0D, 0.9375D, 0.0D, 1.0D, 1.0D, 1.0D);
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      super.onBlockAdded(var1, var2, var3);
      if (var1.getBlockState(var2.up()).getMaterial().isSolid()) {
         func_190970_b(var1, var2);
      }

   }
}

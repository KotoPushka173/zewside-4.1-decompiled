package net.minecraft.network.play.server;

import java.io.IOException;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.potion.Potion;
import net.minecraft.world.World;

public class SPacketRemoveEntityEffect implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private Potion effectId;
   // $FF: synthetic field
   private static final String[] I;

   public SPacketRemoveEntityEffect() {
   }

   static {
      I();
   }

   @Nullable
   public Potion getPotion() {
      return this.effectId;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.effectId = Potion.getPotionById(var1.readUnsignedByte());
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleRemoveEntityEffect(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeByte(Potion.getIdFromPotion(this.effectId));
      I[39 ^ 35].length();
      I[199 ^ 194].length();
   }

   public SPacketRemoveEntityEffect(int var1, Potion var2) {
      this.entityId = var1;
      this.effectId = var2;
   }

   private static void I() {
      I = new String[57 ^ 63];
      I["".length()] = I("夕尔", "dfGbV");
      I[" ".length()] = I("澰傦岪杆够", "zxYIQ");
      I["  ".length()] = I("三溥檘噫向", "UqHRA");
      I["   ".length()] = I("浟亿傈", "tLIDn");
      I[96 ^ 100] = I("倬椳奨抧擑", "nEouV");
      I[120 ^ 125] = I("廕徒仺扒", "AFIDE");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 > -1);

      throw null;
   }

   @Nullable
   public Entity getEntity(World var1) {
      return var1.getEntityByID(this.entityId);
   }
}

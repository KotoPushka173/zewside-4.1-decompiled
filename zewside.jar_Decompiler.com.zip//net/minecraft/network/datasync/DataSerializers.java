package net.minecraft.network.datasync;

import com.google.common.base.Optional;
import java.io.IOException;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IntIdentityHashBiMap;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Rotations;
import net.minecraft.util.text.ITextComponent;

public class DataSerializers {
   // $FF: synthetic field
   public static final DataSerializer<BlockPos> BLOCK_POS;
   // $FF: synthetic field
   public static final DataSerializer<EnumFacing> FACING;
   // $FF: synthetic field
   public static final DataSerializer<ItemStack> OPTIONAL_ITEM_STACK;
   // $FF: synthetic field
   public static final DataSerializer<String> STRING;
   // $FF: synthetic field
   public static final DataSerializer<NBTTagCompound> field_192734_n;
   // $FF: synthetic field
   public static final DataSerializer<Integer> VARINT;
   // $FF: synthetic field
   public static final DataSerializer<Optional<UUID>> OPTIONAL_UNIQUE_ID;
   // $FF: synthetic field
   public static final DataSerializer<ITextComponent> TEXT_COMPONENT;
   // $FF: synthetic field
   public static final DataSerializer<Byte> BYTE;
   // $FF: synthetic field
   public static final DataSerializer<Optional<BlockPos>> OPTIONAL_BLOCK_POS;
   // $FF: synthetic field
   private static final IntIdentityHashBiMap<DataSerializer<?>> REGISTRY;
   // $FF: synthetic field
   public static final DataSerializer<Rotations> ROTATIONS;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final DataSerializer<Optional<IBlockState>> OPTIONAL_BLOCK_STATE;
   // $FF: synthetic field
   public static final DataSerializer<Boolean> BOOLEAN;
   // $FF: synthetic field
   public static final DataSerializer<Float> FLOAT;

   static {
      I();
      REGISTRY = new IntIdentityHashBiMap(211 ^ 195);
      BYTE = new DataSerializer<Byte>() {
         // $FF: synthetic field
         private static final String[] I;

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(1 > -1);

            throw null;
         }

         private static void I() {
            I = new String[185 ^ 176];
            I["".length()] = I("凐廲唙", "fqalX");
            I[" ".length()] = I("灲栠", "rjwpV");
            I["  ".length()] = I("泟挙", "DwyeN");
            I["   ".length()] = I("呇喉", "ZRhTS");
            I[116 ^ 112] = I("栈庥", "Buxqn");
            I[0 ^ 5] = I("尐瀸媴楮", "SSVmC");
            I[111 ^ 105] = I("儯涊", "BJytH");
            I[140 ^ 139] = I("俒昉", "MvKjv");
            I[178 ^ 186] = I("炪巌渍桉", "QlTWM");
         }

         public DataParameter<Byte> createKey(int var1) {
            String var10000 = I[" ".length()];
            String var10001 = I["  ".length()];
            String var10002 = I["   ".length()];
            var10001 = I[18 ^ 22];
            I[196 ^ 193].length();
            I[198 ^ 192].length();
            I[92 ^ 91].length();
            I[6 ^ 14].length();
            return new DataParameter(var1, this);
         }

         public void write(PacketBuffer var1, Byte var2) {
            var1.writeByte(var2);
            I["".length()].length();
         }

         public Byte func_192717_a(Byte var1) {
            return var1;
         }

         static {
            I();
         }

         public Byte read(PacketBuffer var1) throws IOException {
            return var1.readByte();
         }
      };
      VARINT = new DataSerializer<Integer>() {
         // $FF: synthetic field
         private static final String[] I;

         public void write(PacketBuffer var1, Integer var2) {
            var1.writeVarIntToBuffer(var2);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 > 0);

            throw null;
         }

         public Integer func_192717_a(Integer var1) {
            return var1;
         }

         public Integer read(PacketBuffer var1) throws IOException {
            return var1.readVarIntFromBuffer();
         }

         static {
            I();
         }

         public DataParameter<Integer> createKey(int var1) {
            String var10000 = I["   ".length()];
            String var10001 = I[51 ^ 55];
            String var10002 = I[199 ^ 194];
            var10001 = I[197 ^ 195];
            I[192 ^ 199].length();
            I[154 ^ 146].length();
            return new DataParameter(var1, this);
         }

         private static void I() {
            I = new String[38 ^ 47];
            I["".length()] = I("徫宓暴抽", "Mxtau");
            I[" ".length()] = I("歡惜僠", "ElwSF");
            I["  ".length()] = I("攀杖", "VJOfq");
            I["   ".length()] = I("愴坆", "uFgZG");
            I[123 ^ 127] = I("椒潂", "pPhHb");
            I[15 ^ 10] = I("傖厒", "WDvJi");
            I[186 ^ 188] = I("烬揂", "oDXSg");
            I[64 ^ 71] = I("咂", "zbbUU");
            I[15 ^ 7] = I("淪可椋", "aUxqF");
         }
      };
      FLOAT = new DataSerializer<Float>() {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static void I() {
            I = new String[129 ^ 137];
            I["".length()] = I("伢嬜怰", "YthWB");
            I[" ".length()] = I("洳愰溵啤匌", "nQEgu");
            I["  ".length()] = I("朙决冲小", "JyDIs");
            I["   ".length()] = I("傛波", "SBdjn");
            I[34 ^ 38] = I("哧娱", "UPLxh");
            I[166 ^ 163] = I("唲乑", "MltrX");
            I[63 ^ 57] = I("偍杂", "gymlK");
            I[23 ^ 16] = I("桬影欕", "isoGP");
         }

         public Float func_192717_a(Float var1) {
            return var1;
         }

         public void write(PacketBuffer var1, Float var2) {
            var1.writeFloat(var2);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 > -1);

            throw null;
         }

         public DataParameter<Float> createKey(int var1) {
            String var10000 = I["   ".length()];
            String var10001 = I[28 ^ 24];
            String var10002 = I[141 ^ 136];
            var10001 = I[166 ^ 160];
            I[13 ^ 10].length();
            return new DataParameter(var1, this);
         }

         public Float read(PacketBuffer var1) throws IOException {
            return var1.readFloat();
         }
      };
      STRING = new DataSerializer<String>() {
         // $FF: synthetic field
         private static final String[] I;

         public DataParameter<String> createKey(int var1) {
            String var10000 = I["   ".length()];
            String var10001 = I[149 ^ 145];
            String var10002 = I[137 ^ 140];
            var10001 = I[8 ^ 14];
            I[77 ^ 74].length();
            I[60 ^ 52].length();
            I[176 ^ 185].length();
            return new DataParameter(var1, this);
         }

         public void write(PacketBuffer var1, String var2) {
            var1.writeString(var2);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 >= -1);

            throw null;
         }

         public String read(PacketBuffer var1) throws IOException {
            return var1.readStringFromBuffer(29567 + 23468 - '鄽' + 16913);
         }

         static {
            I();
         }

         public String func_192717_a(String var1) {
            return var1;
         }

         private static void I() {
            I = new String[24 ^ 18];
            I["".length()] = I("换擋", "PqEtw");
            I[" ".length()] = I("曪灃伯", "LaOiI");
            I["  ".length()] = I("埛楟", "rFExu");
            I["   ".length()] = I("嚀尦", "gvMlm");
            I[122 ^ 126] = I("俭曎", "XUESI");
            I[149 ^ 144] = I("烒楊", "OwBXp");
            I[191 ^ 185] = I("壥岽", "lcMZN");
            I[42 ^ 45] = I("啒嶞岻了", "TCpBp");
            I[187 ^ 179] = I("悐坃寠列", "WKzwx");
            I[86 ^ 95] = I("柒宰創橴", "QOIFV");
         }
      };
      TEXT_COMPONENT = new DataSerializer<ITextComponent>() {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         public ITextComponent func_192717_a(ITextComponent var1) {
            return var1.createCopy();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 < 1);

            throw null;
         }

         public DataParameter<ITextComponent> createKey(int var1) {
            String var10000 = I[94 ^ 90];
            String var10001 = I[116 ^ 113];
            String var10002 = I[23 ^ 17];
            var10001 = I[43 ^ 44];
            I[102 ^ 110].length();
            I[51 ^ 58].length();
            I[139 ^ 129].length();
            I[173 ^ 166].length();
            return new DataParameter(var1, this);
         }

         private static void I() {
            I = new String[134 ^ 138];
            I["".length()] = I("煢", "JAwsD");
            I[" ".length()] = I("匊斫夋嘙渗", "kksrz");
            I["  ".length()] = I("埆", "vGVZL");
            I["   ".length()] = I("漢幀泹挕", "JhOvF");
            I[43 ^ 47] = I("椳嗺", "ovgOz");
            I[130 ^ 135] = I("囙凼", "dikrY");
            I[100 ^ 98] = I("汎剻", "PMzFq");
            I[193 ^ 198] = I("囐幤", "OPoqL");
            I[41 ^ 33] = I("殹没忚", "FVupY");
            I[119 ^ 126] = I("楿捤彩", "OlNpe");
            I[135 ^ 141] = I("嬽堵伍姖", "vpElu");
            I[126 ^ 117] = I("歝", "MrhrX");
         }

         public ITextComponent read(PacketBuffer var1) throws IOException {
            return var1.readTextComponent();
         }

         public void write(PacketBuffer var1, ITextComponent var2) {
            var1.writeTextComponent(var2);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            I["   ".length()].length();
         }
      };
      OPTIONAL_ITEM_STACK = new DataSerializer<ItemStack>() {
         // $FF: synthetic field
         private static final String[] I;

         public void write(PacketBuffer var1, ItemStack var2) {
            var1.writeItemStackToBuffer(var2);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(1 >= 1);

            throw null;
         }

         private static void I() {
            I = new String[191 ^ 181];
            I["".length()] = I("嶍暂", "ljdth");
            I[" ".length()] = I("捧当媈吷佟", "NGUKi");
            I["  ".length()] = I("婍洧摾摳", "elgfw");
            I["   ".length()] = I("京残", "OeEmm");
            I[83 ^ 87] = I("煙抳", "YhtNx");
            I[62 ^ 59] = I("嘺找", "OlsWk");
            I[6 ^ 0] = I("愎勍", "hnDfx");
            I[124 ^ 123] = I("傺汧厸兼", "RACUc");
            I[204 ^ 196] = I("岿孿", "MKZSO");
            I[148 ^ 157] = I("喬僑忎嫴", "YGsUL");
         }

         public ItemStack read(PacketBuffer var1) throws IOException {
            return var1.readItemStackFromBuffer();
         }

         public ItemStack func_192717_a(ItemStack var1) {
            return var1.copy();
         }

         static {
            I();
         }

         public DataParameter<ItemStack> createKey(int var1) {
            String var10000 = I["   ".length()];
            String var10001 = I[14 ^ 10];
            String var10002 = I[52 ^ 49];
            var10001 = I[174 ^ 168];
            I[141 ^ 138].length();
            I[97 ^ 105].length();
            I[22 ^ 31].length();
            return new DataParameter(var1, this);
         }
      };
      OPTIONAL_BLOCK_STATE = new DataSerializer<Optional<IBlockState>>() {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static void I() {
            I = new String[119 ^ 125];
            I["".length()] = I("煻", "yBNKV");
            I[" ".length()] = I("側沬", "CUKBy");
            I["  ".length()] = I("唔", "PvNhW");
            I["   ".length()] = I("恗堖", "KXYUI");
            I[113 ^ 117] = I("剰堜", "eUxBr");
            I[8 ^ 13] = I("懗崓", "SaXgX");
            I[56 ^ 62] = I("儓洐", "yasEO");
            I[112 ^ 119] = I("或媸扽湍", "VibHg");
            I[32 ^ 40] = I("和晷厷", "odlDr");
            I[7 ^ 14] = I("湾兡", "Dcexs");
         }

         public Optional<IBlockState> read(PacketBuffer var1) throws IOException {
            int var2 = var1.readVarIntFromBuffer();
            Optional var10000;
            if (var2 == 0) {
               var10000 = Optional.absent();
               "".length();
               if (0 >= 2) {
                  throw null;
               }
            } else {
               var10000 = Optional.of(Block.getStateById(var2));
            }

            return var10000;
         }

         public DataParameter<Optional<IBlockState>> createKey(int var1) {
            String var10000 = I["   ".length()];
            String var10001 = I[109 ^ 105];
            String var10002 = I[181 ^ 176];
            var10001 = I[137 ^ 143];
            I[64 ^ 71].length();
            I[182 ^ 190].length();
            I[8 ^ 1].length();
            return new DataParameter(var1, this);
         }

         public Optional<IBlockState> func_192717_a(Optional<IBlockState> var1) {
            return var1;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 >= 4);

            throw null;
         }

         public void write(PacketBuffer var1, Optional<IBlockState> var2) {
            if (var2.isPresent()) {
               var1.writeVarIntToBuffer(Block.getStateId((IBlockState)var2.get()));
               I["".length()].length();
               "".length();
               if (4 <= 3) {
                  throw null;
               }
            } else {
               var1.writeVarIntToBuffer("".length());
               I[" ".length()].length();
               I["  ".length()].length();
            }

         }
      };
      BOOLEAN = new DataSerializer<Boolean>() {
         // $FF: synthetic field
         private static final String[] I;

         public Boolean func_192717_a(Boolean var1) {
            return var1;
         }

         public Boolean read(PacketBuffer var1) throws IOException {
            return var1.readBoolean();
         }

         public void write(PacketBuffer var1, Boolean var2) {
            var1.writeBoolean(var2);
            I["".length()].length();
            I[" ".length()].length();
         }

         static {
            I();
         }

         private static void I() {
            I = new String[173 ^ 165];
            I["".length()] = I("媗劲摔涭", "ugmsY");
            I[" ".length()] = I("倠", "MvryB");
            I["  ".length()] = I("刅垆", "kvKaM");
            I["   ".length()] = I("偔烘", "MiqRZ");
            I[74 ^ 78] = I("楈准", "UfUce");
            I[85 ^ 80] = I("尲惒", "MaVFE");
            I[35 ^ 37] = I("嫡淞懤", "heDlU");
            I[159 ^ 152] = I("潯岽", "RngHe");
         }

         public DataParameter<Boolean> createKey(int var1) {
            String var10000 = I["  ".length()];
            String var10001 = I["   ".length()];
            String var10002 = I[12 ^ 8];
            var10001 = I[156 ^ 153];
            I[196 ^ 194].length();
            I[88 ^ 95].length();
            return new DataParameter(var1, this);
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(0 != 3);

            throw null;
         }
      };
      ROTATIONS = new DataSerializer<Rotations>() {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         public DataParameter<Rotations> createKey(int var1) {
            String var10000 = I[58 ^ 53];
            String var10001 = I[120 ^ 104];
            String var10002 = I[27 ^ 10];
            var10001 = I[34 ^ 48];
            I[176 ^ 163].length();
            I[69 ^ 81].length();
            I[5 ^ 16].length();
            I[111 ^ 121].length();
            return new DataParameter(var1, this);
         }

         public void write(PacketBuffer var1, Rotations var2) {
            var1.writeFloat(var2.getX());
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            var1.writeFloat(var2.getY());
            I["   ".length()].length();
            I[31 ^ 27].length();
            I[141 ^ 136].length();
            I[59 ^ 61].length();
            var1.writeFloat(var2.getZ());
            I[162 ^ 165].length();
            I[93 ^ 85].length();
            I[64 ^ 73].length();
         }

         public Rotations func_192717_a(Rotations var1) {
            return var1;
         }

         private static void I() {
            I = new String[93 ^ 74];
            I["".length()] = I("屓巌", "udSDL");
            I[" ".length()] = I("枰", "WDfQd");
            I["  ".length()] = I("寺", "NedvC");
            I["   ".length()] = I("炁厝妜", "BxkOT");
            I[130 ^ 134] = I("嫋", "kRnoJ");
            I[118 ^ 115] = I("媨梪亻", "csuOl");
            I[84 ^ 82] = I("彛槮", "HEdlc");
            I[152 ^ 159] = I("悭", "axaEr");
            I[51 ^ 59] = I("愜呺抺嫌", "qrTGa");
            I[207 ^ 198] = I("滱妏欍", "YeIWh");
            I[32 ^ 42] = I("倀枿", "ATpTs");
            I[6 ^ 13] = I("娈夓", "kQINT");
            I[175 ^ 163] = I("噔丧", "gEGrN");
            I[178 ^ 191] = I("奋撱", "lclbU");
            I[145 ^ 159] = I("夃", "yzDub");
            I[90 ^ 85] = I("攬揖", "GzmEd");
            I[145 ^ 129] = I("毼咐", "fmTBl");
            I[55 ^ 38] = I("厊兔", "tbtYD");
            I[28 ^ 14] = I("厡東", "GjOjs");
            I[186 ^ 169] = I("庳", "ejGms");
            I[29 ^ 9] = I("巑亄埰抃澴", "qyonr");
            I[46 ^ 59] = I("埡媛", "zfPqe");
            I[118 ^ 96] = I("倡唔", "nTIUl");
         }

         public Rotations read(PacketBuffer var1) throws IOException {
            String var10000 = I[47 ^ 37];
            String var10001 = I[186 ^ 177];
            String var10002 = I[77 ^ 65];
            var10001 = I[127 ^ 114];
            I[145 ^ 159].length();
            return new Rotations(var1.readFloat(), var1.readFloat(), var1.readFloat());
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(1 != 3);

            throw null;
         }
      };
      BLOCK_POS = new DataSerializer<BlockPos>() {
         // $FF: synthetic field
         private static final String[] I;

         public void write(PacketBuffer var1, BlockPos var2) {
            var1.writeBlockPos(var2);
            I["".length()].length();
            I[" ".length()].length();
         }

         public DataParameter<BlockPos> createKey(int var1) {
            String var10000 = I["  ".length()];
            String var10001 = I["   ".length()];
            String var10002 = I[124 ^ 120];
            var10001 = I[11 ^ 14];
            I[191 ^ 185].length();
            I[111 ^ 104].length();
            return new DataParameter(var1, this);
         }

         public BlockPos read(PacketBuffer var1) throws IOException {
            return var1.readBlockPos();
         }

         static {
            I();
         }

         public BlockPos func_192717_a(BlockPos var1) {
            return var1;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(3 != -1);

            throw null;
         }

         private static void I() {
            I = new String[25 ^ 17];
            I["".length()] = I("慂凧涙炴枋", "NBQTV");
            I[" ".length()] = I("擕攢墵倜", "RvFFV");
            I["  ".length()] = I("佅哷", "yWDjv");
            I["   ".length()] = I("唚梢", "jZrJg");
            I[193 ^ 197] = I("橹彸", "ZQBQt");
            I[24 ^ 29] = I("泍潎", "LirUq");
            I[46 ^ 40] = I("瀷仍", "vidWr");
            I[41 ^ 46] = I("塲", "fvZDt");
         }
      };
      OPTIONAL_BLOCK_POS = new DataSerializer<Optional<BlockPos>>() {
         // $FF: synthetic field
         private static final String[] I;

         private static void I() {
            I = new String[143 ^ 128];
            I["".length()] = I("氀侤掏", "Aammn");
            I[" ".length()] = I("攠沕侁惉柯", "lLWiI");
            I["  ".length()] = I("幨", "YKBVr");
            I["   ".length()] = I("佒忾潭", "Gdiae");
            I[142 ^ 138] = I("沾", "dJqKZ");
            I[148 ^ 145] = I("卞樒妭圿", "QadUq");
            I[135 ^ 129] = I("煹", "RTvcj");
            I[115 ^ 116] = I("濠嘅", "PbWvo");
            I[142 ^ 134] = I("徛摘", "sOGmE");
            I[138 ^ 131] = I("櫋侽", "MYZkv");
            I[157 ^ 151] = I("暇倗", "UTvMW");
            I[136 ^ 131] = I("尀樤", "YENpI");
            I[121 ^ 117] = I("嘭廐炸塤啖", "NFQEi");
            I[39 ^ 42] = I("姼半", "eKdNo");
            I[93 ^ 83] = I("伍枃壨戩", "BVtOs");
         }

         public Optional<BlockPos> func_192717_a(Optional<BlockPos> var1) {
            return var1;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 != 3);

            throw null;
         }

         public DataParameter<Optional<BlockPos>> createKey(int var1) {
            String var10000 = I[199 ^ 192];
            String var10001 = I[140 ^ 132];
            String var10002 = I[92 ^ 85];
            var10001 = I[80 ^ 90];
            I[64 ^ 75].length();
            I[102 ^ 106].length();
            I[18 ^ 31].length();
            I[38 ^ 40].length();
            return new DataParameter(var1, this);
         }

         public void write(PacketBuffer var1, Optional<BlockPos> var2) {
            var1.writeBoolean(var2.isPresent());
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            if (var2.isPresent()) {
               var1.writeBlockPos((BlockPos)var2.get());
               I["   ".length()].length();
               I[61 ^ 57].length();
               I[68 ^ 65].length();
               I[162 ^ 164].length();
            }

         }

         static {
            I();
         }

         public Optional<BlockPos> read(PacketBuffer var1) throws IOException {
            Optional var10000;
            if (!var1.readBoolean()) {
               var10000 = Optional.absent();
               "".length();
               if (1 < -1) {
                  throw null;
               }
            } else {
               var10000 = Optional.of(var1.readBlockPos());
            }

            return var10000;
         }
      };
      FACING = new DataSerializer<EnumFacing>() {
         // $FF: synthetic field
         private static final String[] I;

         public void write(PacketBuffer var1, EnumFacing var2) {
            var1.writeEnumValue(var2);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
         }

         private static void I() {
            I = new String[61 ^ 55];
            I["".length()] = I("朕攘", "TSFwP");
            I[" ".length()] = I("來", "fSjOV");
            I["  ".length()] = I("棳刖", "LAbhV");
            I["   ".length()] = I("澤侼", "tRdGO");
            I[49 ^ 53] = I("屬湯", "XIpSx");
            I[162 ^ 167] = I("惏佨", "ENAJx");
            I[23 ^ 17] = I("叕定", "wjpAO");
            I[40 ^ 47] = I("沅墸", "LVRSb");
            I[112 ^ 120] = I("挟浅卑岵", "xPOcQ");
            I[104 ^ 97] = I("僘", "vGicM");
         }

         public EnumFacing read(PacketBuffer var1) throws IOException {
            return (EnumFacing)var1.readEnumValue(EnumFacing.class);
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 < 4);

            throw null;
         }

         static {
            I();
         }

         public DataParameter<EnumFacing> createKey(int var1) {
            String var10000 = I["   ".length()];
            String var10001 = I[153 ^ 157];
            String var10002 = I[141 ^ 136];
            var10001 = I[36 ^ 34];
            I[126 ^ 121].length();
            I[82 ^ 90].length();
            I[2 ^ 11].length();
            return new DataParameter(var1, this);
         }

         public EnumFacing func_192717_a(EnumFacing var1) {
            return var1;
         }
      };
      OPTIONAL_UNIQUE_ID = new DataSerializer<Optional<UUID>>() {
         // $FF: synthetic field
         private static final String[] I;

         static {
            I();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(true);

            throw null;
         }

         public Optional<UUID> func_192717_a(Optional<UUID> var1) {
            return var1;
         }

         public DataParameter<Optional<UUID>> createKey(int var1) {
            String var10000 = I[24 ^ 29];
            String var10001 = I[106 ^ 108];
            String var10002 = I[0 ^ 7];
            var10001 = I[200 ^ 192];
            I[96 ^ 105].length();
            return new DataParameter(var1, this);
         }

         public void write(PacketBuffer var1, Optional<UUID> var2) {
            var1.writeBoolean(var2.isPresent());
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            if (var2.isPresent()) {
               var1.writeUuid((UUID)var2.get());
               I["   ".length()].length();
               I[144 ^ 148].length();
            }

         }

         private static void I() {
            I = new String[11 ^ 1];
            I["".length()] = I("怡尓", "QKvdm");
            I[" ".length()] = I("櫫卋敬", "SsLRA");
            I["  ".length()] = I("並叕俺岒俻", "RZYkC");
            I["   ".length()] = I("叿兾滘娐", "pTYIg");
            I[155 ^ 159] = I("毞厢坝", "gZgPt");
            I[180 ^ 177] = I("瀚嚀", "AAwtU");
            I[71 ^ 65] = I("棎崝", "uhULj");
            I[31 ^ 24] = I("媑悇", "VPndq");
            I[117 ^ 125] = I("嘟杷", "tuSCh");
            I[55 ^ 62] = I("密", "BRGty");
         }

         public Optional<UUID> read(PacketBuffer var1) throws IOException {
            Optional var10000;
            if (!var1.readBoolean()) {
               var10000 = Optional.absent();
               "".length();
               if (4 == 1) {
                  throw null;
               }
            } else {
               var10000 = Optional.of(var1.readUuid());
            }

            return var10000;
         }
      };
      field_192734_n = new DataSerializer<NBTTagCompound>() {
         // $FF: synthetic field
         private static final String[] I;

         public NBTTagCompound read(PacketBuffer var1) throws IOException {
            return var1.readNBTTagCompoundFromBuffer();
         }

         public DataParameter<NBTTagCompound> createKey(int var1) {
            String var10000 = I[6 ^ 2];
            String var10001 = I[125 ^ 120];
            String var10002 = I[126 ^ 120];
            var10001 = I[65 ^ 70];
            I[58 ^ 50].length();
            I[44 ^ 37].length();
            return new DataParameter(var1, this);
         }

         public void write(PacketBuffer var1, NBTTagCompound var2) {
            var1.writeNBTTagCompoundToBuffer(var2);
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            I["   ".length()].length();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 >= 2);

            throw null;
         }

         private static void I() {
            I = new String[114 ^ 120];
            I["".length()] = I("昱岬峧", "zhpDj");
            I[" ".length()] = I("帒暏炧業", "KTGNq");
            I["  ".length()] = I("毇恨敞", "zbAvR");
            I["   ".length()] = I("挗亹晡", "FiCfm");
            I[87 ^ 83] = I("嬅埡", "SMQLR");
            I[2 ^ 7] = I("佅榍", "dDoKg");
            I[27 ^ 29] = I("煊桼", "TESmr");
            I[14 ^ 9] = I("攕扺", "SUEBg");
            I[95 ^ 87] = I("塬", "mfEdq");
            I[92 ^ 85] = I("巚", "YgadT");
         }

         public NBTTagCompound func_192717_a(NBTTagCompound var1) {
            return var1.copy();
         }

         static {
            I();
         }
      };
      registerSerializer(BYTE);
      registerSerializer(VARINT);
      registerSerializer(FLOAT);
      registerSerializer(STRING);
      registerSerializer(TEXT_COMPONENT);
      registerSerializer(OPTIONAL_ITEM_STACK);
      registerSerializer(BOOLEAN);
      registerSerializer(ROTATIONS);
      registerSerializer(BLOCK_POS);
      registerSerializer(OPTIONAL_BLOCK_POS);
      registerSerializer(FACING);
      registerSerializer(OPTIONAL_UNIQUE_ID);
      registerSerializer(OPTIONAL_BLOCK_STATE);
      registerSerializer(field_192734_n);
   }

   public static int getSerializerId(DataSerializer<?> var0) {
      return REGISTRY.getId(var0);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > -1);

      throw null;
   }

   public static void registerSerializer(DataSerializer<?> var0) {
      REGISTRY.add(var0);
      I["".length()].length();
   }

   @Nullable
   public static DataSerializer<?> getSerializer(int var0) {
      return (DataSerializer)REGISTRY.get(var0);
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("僟丹摭", "WNHzY");
   }
}

package net.minecraftforge.common.model;

import javax.vecmath.Matrix4f;
import net.minecraft.util.EnumFacing;

public interface ITransformation {
   Matrix4f getMatrix();

   int rotate(EnumFacing var1, int var2);

   EnumFacing rotate(EnumFacing var1);
}

package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketClientStatus implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private CPacketClientStatus.State status;

   public CPacketClientStatus(CPacketClientStatus.State var1) {
      this.status = var1;
   }

   static {
      I();
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processClientStatus(this);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 4);

      throw null;
   }

   public CPacketClientStatus.State getStatus() {
      return this.status;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.status);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("泴", "FIoTO");
      I[" ".length()] = I("煥匌毟務", "MHusQ");
      I["  ".length()] = I("噜崏庽", "bGNqQ");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.status = (CPacketClientStatus.State)var1.readEnumValue(CPacketClientStatus.State.class);
   }

   public CPacketClientStatus() {
   }

   public static enum State {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      REQUEST_STATS,
      // $FF: synthetic field
      PERFORM_RESPAWN;

      static {
         I();
         PERFORM_RESPAWN = new CPacketClientStatus.State(I["".length()], "".length());
         REQUEST_STATS = new CPacketClientStatus.State(I[" ".length()], " ".length());
         CPacketClientStatus.State[] var10000 = new CPacketClientStatus.State["  ".length()];
         var10000["".length()] = PERFORM_RESPAWN;
         var10000[" ".length()] = REQUEST_STATS;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I("2\f\u0010\u000b?0\u0004\u001d\u001f51\u0019\u0003\u001a>", "bIBMp");
         I[" ".length()] = I("\u0006\f\u00181\u001c\u0007\u001d\u00167\r\u0015\u001d\u001a", "TIIdY");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 == 4);

         throw null;
      }
   }
}

package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentArrowInfinite extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= -1);

      throw null;
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I(".\u001f\u001e$\u001a\u0006\u0003\n\"\u0003&\u0019\t", "OmlKm");
   }

   static {
      I();
   }

   public int getMinEnchantability(int var1) {
      return 28 ^ 8;
   }

   public EnchantmentArrowInfinite(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.BOW, var2);
      this.setName(I["".length()]);
   }

   public int getMaxEnchantability(int var1) {
      return 86 ^ 100;
   }

   public boolean canApplyTogether(Enchantment var1) {
      int var10000;
      if (var1 instanceof EnchantmentMending) {
         var10000 = "".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = super.canApplyTogether(var1);
      }

      return (boolean)var10000;
   }

   public int getMaxLevel() {
      return " ".length();
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;

public class SPacketMultiBlockChange implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private ChunkPos chunkPos;
   // $FF: synthetic field
   private SPacketMultiBlockChange.BlockUpdateData[] changedBlocks;

   private static void I() {
      I = new String[105 ^ 112];
      I["".length()] = I("嬷庌", "IwRKm");
      I[" ".length()] = I("偉刴", "ymAhw");
      I["  ".length()] = I("怵棅", "Yhnhd");
      I["   ".length()] = I("揎煣", "giSTA");
      I[104 ^ 108] = I("注循", "hSMCf");
      I[32 ^ 37] = I("晕楁", "wVIJu");
      I[74 ^ 76] = I("欎殶", "zbPse");
      I[98 ^ 101] = I("淁汲", "dJCES");
      I[36 ^ 44] = I("栕吏弩枻", "MaXYB");
      I[29 ^ 20] = I("淬憚净", "OzBLy");
      I[75 ^ 65] = I("愾椢", "hcgzQ");
      I[4 ^ 15] = I("浂", "dlFdP");
      I[133 ^ 137] = I("搸", "DKoMj");
      I[59 ^ 54] = I("桹", "Yngrc");
      I[13 ^ 3] = I("孴夏哆凙", "fqzyG");
      I[162 ^ 173] = I("徸沄归幁擪", "xirau");
      I[25 ^ 9] = I("洚教", "wdhcl");
      I[60 ^ 45] = I("俲", "dusZp");
      I[113 ^ 99] = I("潷", "UvwFf");
      I[140 ^ 159] = I("廏沆", "fupTN");
      I[126 ^ 106] = I("搟奪", "jelGp");
      I[96 ^ 117] = I("李朗币桯", "Lhvav");
      I[158 ^ 136] = I("峝擶槎扢嗯", "mAOGC");
      I[96 ^ 119] = I("厠灏廙", "aiQqS");
      I[92 ^ 68] = I("柄囔滾", "KJyOu");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 1);

      throw null;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeInt(this.chunkPos.x);
      I[138 ^ 134].length();
      I[10 ^ 7].length();
      I[135 ^ 137].length();
      var1.writeInt(this.chunkPos.z);
      I[76 ^ 67].length();
      I[141 ^ 157].length();
      var1.writeVarIntToBuffer(this.changedBlocks.length);
      I[117 ^ 100].length();
      SPacketMultiBlockChange.BlockUpdateData[] var2 = this.changedBlocks;
      int var3 = var2.length;
      int var4 = "".length();

      do {
         if (var4 >= var3) {
            return;
         }

         SPacketMultiBlockChange.BlockUpdateData var5 = var2[var4];
         var1.writeShort(var5.getOffset());
         I[112 ^ 98].length();
         I[123 ^ 104].length();
         I[33 ^ 53].length();
         var1.writeVarIntToBuffer(Block.BLOCK_STATE_IDS.get(var5.getBlockState()));
         I[85 ^ 64].length();
         I[102 ^ 112].length();
         I[32 ^ 55].length();
         I[136 ^ 144].length();
         ++var4;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleMultiBlockChange(this);
   }

   public SPacketMultiBlockChange(int var1, short[] var2, Chunk var3) {
      this.chunkPos = new ChunkPos(var3.x, var3.z);
      this.changedBlocks = new SPacketMultiBlockChange.BlockUpdateData[var1];
      int var4 = "".length();

      do {
         if (var4 >= this.changedBlocks.length) {
            return;
         }

         this.changedBlocks[var4] = new SPacketMultiBlockChange.BlockUpdateData(var2[var4], var3);
         ++var4;
         "".length();
      } while(2 > -1);

      throw null;
   }

   static {
      I();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[198 ^ 194];
      var10001 = I[81 ^ 84];
      var10002 = I[176 ^ 182];
      var10001 = I[14 ^ 9];
      I[167 ^ 175].length();
      I[69 ^ 76].length();
      this.chunkPos = new ChunkPos(var1.readInt(), var1.readInt());
      this.changedBlocks = new SPacketMultiBlockChange.BlockUpdateData[var1.readVarIntFromBuffer()];
      int var2 = "".length();

      do {
         if (var2 >= this.changedBlocks.length) {
            return;
         }

         SPacketMultiBlockChange.BlockUpdateData[] var3 = this.changedBlocks;
         I[76 ^ 70].length();
         I[205 ^ 198].length();
         var3[var2] = new SPacketMultiBlockChange.BlockUpdateData(var1.readShort(), (IBlockState)Block.BLOCK_STATE_IDS.getByValue(var1.readVarIntFromBuffer()));
         ++var2;
         "".length();
      } while(2 >= 0);

      throw null;
   }

   public SPacketMultiBlockChange.BlockUpdateData[] getChangedBlocks() {
      return this.changedBlocks;
   }

   public SPacketMultiBlockChange() {
   }

   public class BlockUpdateData {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final IBlockState blockState;
      // $FF: synthetic field
      private final short offset;

      public BlockPos getPos() {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         I[90 ^ 94].length();
         return new BlockPos(SPacketMultiBlockChange.this.chunkPos.getBlock(this.offset >> (126 ^ 114) & (178 ^ 189), this.offset & 201 + 142 - 145 + 57, this.offset >> (122 ^ 114) & (110 ^ 97)));
      }

      private static void I() {
         I = new String[12 ^ 9];
         I["".length()] = I("椞嘜", "FVKvX");
         I[" ".length()] = I("侒欞", "MaAvI");
         I["  ".length()] = I("凚亽", "ZLxiE");
         I["   ".length()] = I("什憕", "YwKeL");
         I[14 ^ 10] = I("昍毥暦", "NkTop");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 >= -1);

         throw null;
      }

      public BlockUpdateData(short var2, Chunk var3) {
         this.offset = var2;
         this.blockState = var3.getBlockState(this.getPos());
      }

      public IBlockState getBlockState() {
         return this.blockState;
      }

      static {
         I();
      }

      public BlockUpdateData(short var2, IBlockState var3) {
         this.offset = var2;
         this.blockState = var3;
      }

      public short getOffset() {
         return this.offset;
      }
   }
}

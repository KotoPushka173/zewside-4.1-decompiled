package net.minecraft.advancements.critereon;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class EnterBlockTrigger implements ICriterionTrigger<EnterBlockTrigger.Instance> {
   // $FF: synthetic field
   private final Map<PlayerAdvancements, EnterBlockTrigger.Listeners> field_192197_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final ResourceLocation field_192196_a;

   public ResourceLocation func_192163_a() {
      return field_192196_a;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<EnterBlockTrigger.Instance> var2) {
      EnterBlockTrigger.Listeners var3 = (EnterBlockTrigger.Listeners)this.field_192197_b.get(var1);
      if (var3 != null) {
         var3.func_192469_b(var2);
         if (var3.func_192470_a()) {
            this.field_192197_b.remove(var1);
            I[87 ^ 80].length();
            I[135 ^ 143].length();
         }
      }

   }

   private static void I() {
      I = new String[36 ^ 69];
      I["".length()] = I("刑渲", "swDSe");
      I[" ".length()] = I("揞榗", "lSypN");
      I["  ".length()] = I("啇婺", "InbNq");
      I["   ".length()] = I("擵威", "kfFGs");
      I[30 ^ 26] = I("柟氌溑冺", "fzkUZ");
      I[139 ^ 142] = I("枈", "kfFEj");
      I[30 ^ 24] = I("懛庾堮灌", "tNwTc");
      I[73 ^ 78] = I("漦侏朎惌", "EfUfG");
      I[150 ^ 158] = I("欅嘷煚搽廔", "GdKYf");
      I[205 ^ 196] = I("炖崓桇树烘", "FOVYw");
      I[119 ^ 125] = I("併夡妨刊澨", "cIRlD");
      I[88 ^ 83] = I("僩悫搚", "MsqKz");
      I[150 ^ 154] = I("彬吝", "eswcX");
      I[36 ^ 41] = I("斔楠", "ikofR");
      I[166 ^ 168] = I("佑泅", "FwTyv");
      I[72 ^ 71] = I("化溲", "tDMwA");
      I[84 ^ 68] = I("惰尓", "CQaBM");
      I[53 ^ 36] = I("团浣", "jqHkD");
      I[74 ^ 88] = I("欖滛", "Cfhas");
      I[50 ^ 33] = I("滜屑", "vokNK");
      I[178 ^ 166] = I("涑旰", "VBKSA");
      I[208 ^ 197] = I("懊檭", "QWYvW");
      I[178 ^ 164] = I("儒庐", "zccKU");
      I[87 ^ 64] = I("厀僇", "RrVmx");
      I[5 ^ 29] = I("屴剧", "CvCgX");
      I[168 ^ 177] = I("屲圹", "SFGQj");
      I[144 ^ 138] = I("倭媎", "JSvCV");
      I[187 ^ 160] = I("洒欧", "EUadn");
      I[123 ^ 103] = I("泌亳", "XEYWu");
      I[157 ^ 128] = I("攰洍", "iluUg");
      I[167 ^ 185] = I("洨煏", "dmCdf");
      I[169 ^ 182] = I("全怷", "OrzMA");
      I[9 ^ 41] = I("壽弌", "XJCEQ");
      I[145 ^ 176] = I("樯匩", "HHYwW");
      I[77 ^ 111] = I("杧彡", "CZblp");
      I[51 ^ 16] = I("洟媟", "iSIbD");
      I[143 ^ 171] = I("侅杰", "urmBD");
      I[6 ^ 35] = I("圩幩", "jFBsp");
      I[22 ^ 48] = I("柤扱", "vKAks");
      I[66 ^ 101] = I("壏挒", "JEqOw");
      I[105 ^ 65] = I("晧凚", "LKaHf");
      I[90 ^ 115] = I("伙炬", "RxbdU");
      I[150 ^ 188] = I("摼惰", "gUhaC");
      I[183 ^ 156] = I("奆唳", "DBXUV");
      I[162 ^ 142] = I("坮愨", "gAdsD");
      I[88 ^ 117] = I("帍丮", "WRwKb");
      I[181 ^ 155] = I("崛宼", "BoGIg");
      I[6 ^ 41] = I("漤厜", "jPFUm");
      I[103 ^ 87] = I("\u0013:\u000b\u0002\u0003", "qVdah");
      I[138 ^ 187] = I("便揈吠兔", "WDvpm");
      I[117 ^ 71] = I("搐厸", "bzWSL");
      I[81 ^ 98] = I("澎哓彗", "pZwnF");
      I[13 ^ 57] = I("\u0001\r\u00074:", "cahWQ");
      I[113 ^ 68] = I("樰則汬倖", "WOrEI");
      I[128 ^ 182] = I("梙剼廰烝", "OTqxJ");
      I[127 ^ 72] = I("3\u0007('$\u0011\u0007c+'\t\n(i?\u001f\u0019&il", "fiCIK");
      I[56 ^ 0] = I("Q", "vVwBW");
      I[127 ^ 70] = I("挞椼圲枫", "kbmyS");
      I[1 ^ 59] = I("\u0011\u0017+=!", "bcJID");
      I[155 ^ 160] = I("嗚個煆帀挈", "IehKR");
      I[169 ^ 149] = I("坱潀囝惑攛", "MzYxg");
      I[137 ^ 180] = I("6\b8b<U\r3#!\u001b\fv'$\u001a\n=e;\u0001\b\" h\u0002\u0000\"-'\u0000\u001dv$h\u0006\u00193&!\u0013\u00005e*\u0019\u00065.h\u0001\u0010& ", "uiVEH");
      I[78 ^ 112] = I("弡完僔", "JseKB");
      I[70 ^ 121] = I("嫆嗒憡奁", "tbEAS");
      I[234 ^ 170] = I("\u001f17:\u0015", "lEVNp");
      I[227 ^ 162] = I("佢姑氍", "RAiPx");
      I[216 ^ 154] = I("叧烶撢濄人", "xrwhB");
      I[219 ^ 152] = I("傾", "dmSiu");
      I[234 ^ 174] = I("桢崗嫷", "OMyxa");
      I[32 ^ 101] = I("浢噰", "WaafN");
      I[215 ^ 145] = I("\u0012\u0000\u00069\u00070\u0000M5\u0004(\r\u0006w\u001b3\u000f\u00192H7\u001c\u0002'\r5\u001a\u0014wO", "GnmWh");
      I[57 ^ 126] = I("Hy6\r9O;<\r(\u0004yw", "oYPbK");
      I[88 ^ 16] = I("r", "UGakt");
      I[233 ^ 160] = I("唍嶍刣嘼午", "DuWcL");
      I[201 ^ 131] = I("娚淗", "aICZE");
      I[215 ^ 156] = I("姥", "Idxtc");
      I[13 ^ 65] = I("岆沼旐嬢", "xcBav");
      I[117 ^ 56] = I("努怒", "UWqex");
      I[218 ^ 148] = I("樕惻斿榡昜", "ZdxQD");
      I[50 ^ 125] = I("渺懿娠劫灯", "ARAFS");
      I[203 ^ 155] = I("剄洯氾", "XGKKb");
      I[104 ^ 57] = I("\u0005%0\u0016<%/f\u0015<#(-W#8*2\u0012p:**\u00025ll", "LKFwP");
      I[25 ^ 75] = I("@Z\u0016&\u001fG\n\u0002&\u001d\u0002\b\u00040M@", "gzpIm");
      I[34 ^ 113] = I("lj\u0016\u000bf)&\u0016\u0006-km", "KJyeF");
      I[212 ^ 128] = I("k", "LIVyg");
      I[231 ^ 178] = I("察戞仙斓", "fSABA");
      I[234 ^ 188] = I("屺", "YKaYi");
      I[36 ^ 115] = I("啱汯", "ZGSpy");
      I[16 ^ 72] = I("欬", "ivpQL");
      I[85 ^ 12] = I("冫", "ughvv");
      I[215 ^ 141] = I("嗒恔搣殺", "PzjiX");
      I[123 ^ 32] = I("烳曍曚", "vwjYi");
      I[30 ^ 66] = I("娳孀刂", "OomtW");
      I[253 ^ 160] = I("俺嬑喨姙", "PhXlU");
      I[54 ^ 104] = I("嚅慩愭峺漻", "DZQXu");
      I[40 ^ 119] = I("仗", "BHZPA");
      I[14 ^ 110] = I("\u0004\u0006:55>\n\"?$\n", "ahNPG");
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192197_b.remove(var1);
      I[145 ^ 152].length();
      I[162 ^ 168].length();
      I[5 ^ 14].length();
   }

   public void func_192193_a(EntityPlayerMP var1, IBlockState var2) {
      EnterBlockTrigger.Listeners var3 = (EnterBlockTrigger.Listeners)this.field_192197_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_192471_a(var2);
      }

   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<EnterBlockTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      EnterBlockTrigger.Listeners var3 = (EnterBlockTrigger.Listeners)this.field_192197_b.get(var1);
      if (var3 == null) {
         I[12 ^ 8].length();
         I[107 ^ 110].length();
         var3 = new EnterBlockTrigger.Listeners(var1);
         this.field_192197_b.put(var1, var3);
         I[108 ^ 106].length();
      }

      var3.func_192472_a(var2);
   }

   public EnterBlockTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[163 ^ 175];
      String var10001 = I[5 ^ 8];
      String var10002 = I[144 ^ 158];
      var10001 = I[185 ^ 182];
      var10000 = I[8 ^ 24];
      var10001 = I[89 ^ 72];
      var10002 = I[84 ^ 70];
      var10001 = I[82 ^ 65];
      var10000 = I[118 ^ 98];
      var10001 = I[65 ^ 84];
      var10002 = I[86 ^ 64];
      var10001 = I[122 ^ 109];
      var10000 = I[60 ^ 36];
      var10001 = I[39 ^ 62];
      var10002 = I[170 ^ 176];
      var10001 = I[70 ^ 93];
      var10000 = I[154 ^ 134];
      var10001 = I[68 ^ 89];
      var10002 = I[96 ^ 126];
      var10001 = I[68 ^ 91];
      var10000 = I[135 ^ 167];
      var10001 = I[23 ^ 54];
      var10002 = I[97 ^ 67];
      var10001 = I[99 ^ 64];
      var10000 = I[152 ^ 188];
      var10001 = I[151 ^ 178];
      var10002 = I[29 ^ 59];
      var10001 = I[228 ^ 195];
      var10000 = I[54 ^ 30];
      var10001 = I[96 ^ 73];
      var10002 = I[1 ^ 43];
      var10001 = I[46 ^ 5];
      var10000 = I[123 ^ 87];
      var10001 = I[158 ^ 179];
      var10002 = I[153 ^ 183];
      var10001 = I[185 ^ 150];
      Block var3 = null;
      JsonSyntaxException var12;
      if (var1.has(I[64 ^ 112])) {
         I[149 ^ 164].length();
         I[178 ^ 128].length();
         I[171 ^ 152].length();
         ResourceLocation var4 = new ResourceLocation(JsonUtils.getString(var1, I[246 ^ 194]));
         if (!Block.REGISTRY.containsKey(var4)) {
            I[47 ^ 26].length();
            I[47 ^ 25].length();
            var12 = new JsonSyntaxException(I[47 ^ 24] + var4 + I[167 ^ 159]);
            I[174 ^ 151].length();
            throw var12;
         }

         var3 = (Block)Block.REGISTRY.getObject(var4);
      }

      HashMap var11 = null;
      if (var1.has(I[183 ^ 141])) {
         if (var3 == null) {
            I[22 ^ 45].length();
            I[160 ^ 156].length();
            var12 = new JsonSyntaxException(I[187 ^ 134]);
            I[33 ^ 31].length();
            I[6 ^ 57].length();
            throw var12;
         }

         BlockStateContainer var5 = var3.getBlockState();
         Iterator var6 = JsonUtils.getJsonObject(var1, I[134 ^ 198]).entrySet().iterator();

         while(var6.hasNext()) {
            Entry var7 = (Entry)var6.next();
            IProperty var8 = var5.getProperty((String)var7.getKey());
            if (var8 == null) {
               I[2 ^ 67].length();
               I[196 ^ 134].length();
               I[55 ^ 116].length();
               I[241 ^ 181].length();
               I[206 ^ 139].length();
               var12 = new JsonSyntaxException(I[28 ^ 90] + (String)var7.getKey() + I[23 ^ 80] + Block.REGISTRY.getNameForObject(var3) + I[33 ^ 105]);
               I[66 ^ 11].length();
               I[229 ^ 175].length();
               I[35 ^ 104].length();
               throw var12;
            }

            String var9 = JsonUtils.getString((JsonElement)var7.getValue(), (String)var7.getKey());
            Optional var10 = var8.parseValue(var9);
            if (!var10.isPresent()) {
               I[228 ^ 168].length();
               I[9 ^ 68].length();
               I[3 ^ 77].length();
               I[14 ^ 65].length();
               I[50 ^ 98].length();
               var12 = new JsonSyntaxException(I[146 ^ 195] + var9 + I[115 ^ 33] + (String)var7.getKey() + I[209 ^ 130] + Block.REGISTRY.getNameForObject(var3) + I[229 ^ 177]);
               I[114 ^ 39].length();
               I[210 ^ 132].length();
               I[63 ^ 104].length();
               I[224 ^ 184].length();
               throw var12;
            }

            if (var11 == null) {
               var11 = Maps.newHashMap();
            }

            var11.put(var8, var10.get());
            I[21 ^ 76].length();
            I[44 ^ 118].length();
            I[1 ^ 90].length();
            "".length();
            if (2 <= -1) {
               throw null;
            }
         }
      }

      I[210 ^ 142].length();
      I[33 ^ 124].length();
      I[65 ^ 31].length();
      I[99 ^ 60].length();
      return new EnterBlockTrigger.Instance(var3, var11);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != 4);

      throw null;
   }

   static {
      I();
      field_192196_a = new ResourceLocation(I[167 ^ 199]);
   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_192473_a;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<EnterBlockTrigger.Instance>> field_192474_b = Sets.newHashSet();
      // $FF: synthetic field
      private static final String[] I;

      private static void I() {
         I = new String[138 ^ 143];
         I["".length()] = I("欥坁", "NtUIy");
         I[" ".length()] = I("垒妄仄慘僵", "OabdC");
         I["  ".length()] = I("揵减僘", "UcgZc");
         I["   ".length()] = I("歭", "YAmoi");
         I[41 ^ 45] = I("呎", "bvFEm");
      }

      static {
         I();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 >= 2);

         throw null;
      }

      public boolean func_192470_a() {
         return this.field_192474_b.isEmpty();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192473_a = var1;
      }

      public void func_192471_a(IBlockState var1) {
         ArrayList var2 = null;
         Iterator var3 = this.field_192474_b.iterator();

         ICriterionTrigger.Listener var4;
         while(var3.hasNext()) {
            var4 = (ICriterionTrigger.Listener)var3.next();
            if (((EnterBlockTrigger.Instance)var4.func_192158_a()).func_192260_a(var1)) {
               if (var2 == null) {
                  var2 = Lists.newArrayList();
               }

               var2.add(var4);
               I["   ".length()].length();
               I[132 ^ 128].length();
            }

            "".length();
            if (3 <= 2) {
               throw null;
            }
         }

         if (var2 != null) {
            var3 = var2.iterator();

            while(var3.hasNext()) {
               var4 = (ICriterionTrigger.Listener)var3.next();
               var4.func_192159_a(this.field_192473_a);
               "".length();
               if (-1 >= 4) {
                  throw null;
               }
            }
         }

      }

      public void func_192472_a(ICriterionTrigger.Listener<EnterBlockTrigger.Instance> var1) {
         this.field_192474_b.add(var1);
         I["".length()].length();
      }

      public void func_192469_b(ICriterionTrigger.Listener<EnterBlockTrigger.Instance> var1) {
         this.field_192474_b.remove(var1);
         I[" ".length()].length();
         I["  ".length()].length();
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final Block field_192261_a;
      // $FF: synthetic field
      private final Map<IProperty<?>, Object> field_192262_b;

      public boolean func_192260_a(IBlockState var1) {
         if (this.field_192261_a != null && var1.getBlock() != this.field_192261_a) {
            return (boolean)"".length();
         } else {
            if (this.field_192262_b != null) {
               Iterator var2 = this.field_192262_b.entrySet().iterator();

               while(var2.hasNext()) {
                  Entry var3 = (Entry)var2.next();
                  if (var1.getValue((IProperty)var3.getKey()) != var3.getValue()) {
                     return (boolean)"".length();
                  }

                  "".length();
                  if (4 != 4) {
                     throw null;
                  }
               }
            }

            return (boolean)" ".length();
         }
      }

      public Instance(@Nullable Block var1, @Nullable Map<IProperty<?>, Object> var2) {
         super(EnterBlockTrigger.field_192196_a);
         this.field_192261_a = var1;
         this.field_192262_b = var2;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 != 3);

         throw null;
      }
   }
}

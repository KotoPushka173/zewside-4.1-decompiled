package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockGravel extends BlockFalling {
   // $FF: synthetic field
   private static final String[] I;

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      if (var3 > "   ".length()) {
         var3 = "   ".length();
      }

      int var10001 = 104 ^ 98;
      int var10002 = var3 * "   ".length();
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      Item var10000;
      if (var2.nextInt(var10001 - var10002) == 0) {
         var10000 = Items.FLINT;
         "".length();
         if (2 >= 4) {
            throw null;
         }
      } else {
         var10000 = super.getItemDropped(var1, var2, var3);
      }

      return var10000;
   }

   private static void I() {
      I = new String[128 ^ 132];
      I["".length()] = I("泀捐曽偡暅", "fRFzP");
      I[" ".length()] = I("嘭櫣", "lFyiw");
      I["  ".length()] = I("晍樍惢", "Yuwwg");
      I["   ".length()] = I("嫐斄埾", "WiPsf");
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.STONE;
   }

   static {
      I();
   }

   public int getDustColor(IBlockState var1) {
      return -(6784826 + 2692961 - 2141153 + 1020107);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 > -1);

      throw null;
   }
}

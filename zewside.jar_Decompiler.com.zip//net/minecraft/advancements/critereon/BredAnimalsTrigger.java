package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;

public class BredAnimalsTrigger implements ICriterionTrigger<BredAnimalsTrigger.Instance> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, BredAnimalsTrigger.Listeners> field_192172_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final ResourceLocation field_192171_a;

   public ResourceLocation func_192163_a() {
      return field_192171_a;
   }

   public void func_192168_a(EntityPlayerMP var1, EntityAnimal var2, EntityAnimal var3, EntityAgeable var4) {
      BredAnimalsTrigger.Listeners var5 = (BredAnimalsTrigger.Listeners)this.field_192172_b.get(var1.func_192039_O());
      if (var5 != null) {
         var5.func_192342_a(var1, var2, var3, var4);
      }

   }

   private static void I() {
      I = new String[125 ^ 104];
      I["".length()] = I("婏敦", "mnpCf");
      I[" ".length()] = I("浚喁", "NRDeU");
      I["  ".length()] = I("労呦", "GjECj");
      I["   ".length()] = I("找佋", "bdfSQ");
      I[178 ^ 182] = I("楚奾", "xWTqo");
      I[82 ^ 87] = I("嶸朝", "WcSDa");
      I[124 ^ 122] = I("宛梖媞梧椱", "PrNfN");
      I[197 ^ 194] = I("俲昕櫩塌", "hyqpk");
      I[31 ^ 23] = I("埵", "IixcP");
      I[10 ^ 3] = I("怬毥奍埾", "RFDbL");
      I[155 ^ 145] = I("嘳欝偫灄", "WtuVt");
      I[8 ^ 3] = I("始幐", "FbzZQ");
      I[130 ^ 142] = I("撆椼", "jrvhK");
      I[112 ^ 125] = I("丂凇", "iiYeK");
      I[32 ^ 46] = I("櫴俵", "kxZMt");
      I[190 ^ 177] = I("\t\u0015\u0006\u00104\r", "yttuZ");
      I[161 ^ 177] = I("\u0004\u0017\u0006!-\u0011\u0004", "tvtUC");
      I[88 ^ 73] = I("\f\u0006\u0011\u000e\"", "onxbF");
      I[21 ^ 7] = I("倃", "auLSq");
      I[19 ^ 0] = I("柚彺", "TekgD");
      I[43 ^ 63] = I("*<)'7) %.\t$=", "HNLCh");
   }

   public BredAnimalsTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[80 ^ 91];
      String var10001 = I[69 ^ 73];
      String var10002 = I[206 ^ 195];
      var10001 = I[65 ^ 79];
      EntityPredicate var3 = EntityPredicate.func_192481_a(var1.get(I[53 ^ 58]));
      EntityPredicate var4 = EntityPredicate.func_192481_a(var1.get(I[35 ^ 51]));
      EntityPredicate var5 = EntityPredicate.func_192481_a(var1.get(I[186 ^ 171]));
      I[119 ^ 101].length();
      I[97 ^ 114].length();
      return new BredAnimalsTrigger.Instance(var3, var4, var5);
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<BredAnimalsTrigger.Instance> var2) {
      BredAnimalsTrigger.Listeners var3 = (BredAnimalsTrigger.Listeners)this.field_192172_b.get(var1);
      if (var3 != null) {
         var3.func_192340_b(var2);
         if (var3.func_192341_a()) {
            this.field_192172_b.remove(var1);
            I[51 ^ 59].length();
            I[21 ^ 28].length();
         }
      }

   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192172_b.remove(var1);
      I[148 ^ 158].length();
   }

   static {
      I();
      field_192171_a = new ResourceLocation(I[67 ^ 87]);
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<BredAnimalsTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      BredAnimalsTrigger.Listeners var3 = (BredAnimalsTrigger.Listeners)this.field_192172_b.get(var1);
      if (var3 == null) {
         I[12 ^ 8].length();
         I[105 ^ 108].length();
         var3 = new BredAnimalsTrigger.Listeners(var1);
         this.field_192172_b.put(var1, var3);
         I[173 ^ 171].length();
         I[97 ^ 102].length();
      }

      var3.func_192343_a(var2);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 2);

      throw null;
   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<BredAnimalsTrigger.Instance>> field_192345_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_192344_a;
      // $FF: synthetic field
      private static final String[] I;

      public boolean func_192341_a() {
         return this.field_192345_b.isEmpty();
      }

      public void func_192340_b(ICriterionTrigger.Listener<BredAnimalsTrigger.Instance> var1) {
         this.field_192345_b.remove(var1);
         I[59 ^ 63].length();
         I[13 ^ 8].length();
      }

      public void func_192343_a(ICriterionTrigger.Listener<BredAnimalsTrigger.Instance> var1) {
         this.field_192345_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }

      private static void I() {
         I = new String[182 ^ 188];
         I["".length()] = I("叧景", "tqgZE");
         I[" ".length()] = I("檞槪桯", "raFVo");
         I["  ".length()] = I("剚囕", "beqcc");
         I["   ".length()] = I("殦仙浦梔剘", "Mdxqk");
         I[42 ^ 46] = I("峎擘凭伩", "AIccA");
         I[159 ^ 154] = I("捉", "xftGM");
         I[36 ^ 34] = I("嬼婖氜叱", "nhrqf");
         I[111 ^ 104] = I("瀐摝", "Ycmwj");
         I[37 ^ 45] = I("嵔娈枫勍岝", "cbKUu");
         I[15 ^ 6] = I("勿婍婅", "ahHui");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 != 2);

         throw null;
      }

      static {
         I();
      }

      public void func_192342_a(EntityPlayerMP var1, EntityAnimal var2, EntityAnimal var3, EntityAgeable var4) {
         ArrayList var5 = null;
         Iterator var6 = this.field_192345_b.iterator();

         ICriterionTrigger.Listener var7;
         while(var6.hasNext()) {
            var7 = (ICriterionTrigger.Listener)var6.next();
            if (((BredAnimalsTrigger.Instance)var7.func_192158_a()).func_192246_a(var1, var2, var3, var4)) {
               if (var5 == null) {
                  var5 = Lists.newArrayList();
               }

               var5.add(var7);
               I[149 ^ 147].length();
               I[59 ^ 60].length();
               I[44 ^ 36].length();
               I[84 ^ 93].length();
            }

            "".length();
            if (2 <= 0) {
               throw null;
            }
         }

         if (var5 != null) {
            var6 = var5.iterator();

            while(var6.hasNext()) {
               var7 = (ICriterionTrigger.Listener)var6.next();
               var7.func_192159_a(this.field_192344_a);
               "".length();
               if (3 <= 1) {
                  throw null;
               }
            }
         }

      }

      public Listeners(PlayerAdvancements var1) {
         this.field_192344_a = var1;
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final EntityPredicate field_192249_c;
      // $FF: synthetic field
      private final EntityPredicate field_192248_b;
      // $FF: synthetic field
      private final EntityPredicate field_192247_a;

      public boolean func_192246_a(EntityPlayerMP var1, EntityAnimal var2, EntityAnimal var3, EntityAgeable var4) {
         if (!this.field_192249_c.func_192482_a(var1, var4)) {
            return (boolean)"".length();
         } else {
            int var10000;
            if (this.field_192247_a.func_192482_a(var1, var2) && this.field_192248_b.func_192482_a(var1, var3) || this.field_192247_a.func_192482_a(var1, var3) && this.field_192248_b.func_192482_a(var1, var2)) {
               var10000 = " ".length();
               "".length();
               if (1 < 0) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      }

      public Instance(EntityPredicate var1, EntityPredicate var2, EntityPredicate var3) {
         super(BredAnimalsTrigger.field_192171_a);
         this.field_192247_a = var1;
         this.field_192248_b = var2;
         this.field_192249_c = var3;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 > 3);

         throw null;
      }
   }
}

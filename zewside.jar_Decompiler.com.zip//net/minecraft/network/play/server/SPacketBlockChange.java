package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class SPacketBlockChange implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private BlockPos blockPosition;
   // $FF: synthetic field
   private IBlockState blockState;
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public SPacketBlockChange() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeBlockPos(this.blockPosition);
      I["".length()].length();
      var1.writeVarIntToBuffer(Block.BLOCK_STATE_IDS.get(this.blockState));
      I[" ".length()].length();
      I["  ".length()].length();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.blockPosition = var1.readBlockPos();
      this.blockState = (IBlockState)Block.BLOCK_STATE_IDS.getByValue(var1.readVarIntFromBuffer());
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != 3);

      throw null;
   }

   public SPacketBlockChange(World var1, BlockPos var2) {
      this.blockPosition = var2;
      this.blockState = var1.getBlockState(var2);
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("嘛", "ulQQK");
      I[" ".length()] = I("慟汩", "xhRBS");
      I["  ".length()] = I("則", "rQaey");
   }

   public IBlockState getBlockState() {
      return this.blockState;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleBlockChange(this);
   }

   public BlockPos getBlockPosition() {
      return this.blockPosition;
   }
}

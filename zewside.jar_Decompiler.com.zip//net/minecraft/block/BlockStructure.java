package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityStructure;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockStructure extends BlockContainer {
   // $FF: synthetic field
   public static final PropertyEnum<TileEntityStructure.Mode> MODE;
   // $FF: synthetic field
   private static final String[] I;

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(MODE, TileEntityStructure.Mode.getById(var1));
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(MODE, TileEntityStructure.Mode.DATA);
   }

   public int getMetaFromState(IBlockState var1) {
      return ((TileEntityStructure.Mode)var1.getValue(MODE)).getModeId();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[82 ^ 87];
      String var10001 = I[133 ^ 131];
      String var10002 = I[160 ^ 167];
      var10001 = I[140 ^ 132];
      var10000 = I[84 ^ 93];
      var10001 = I[207 ^ 197];
      var10002 = I[52 ^ 63];
      var10001 = I[169 ^ 165];
      I[126 ^ 115].length();
      I[20 ^ 26].length();
      I[204 ^ 195].length();
      I[121 ^ 105].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[154 ^ 139].length();
      var10003["".length()] = MODE;
      return new BlockStateContainer(this, var10003);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      TileEntity var10 = var1.getTileEntity(var2);
      int var10000;
      if (var10 instanceof TileEntityStructure) {
         var10000 = ((TileEntityStructure)var10).usedBy(var4);
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private void trigger(TileEntityStructure var1) {
      switch(null.$SwitchMap$net$minecraft$tileentity$TileEntityStructure$Mode[var1.getMode().ordinal()]) {
      case 1:
         var1.save((boolean)"".length());
         I[60 ^ 46].length();
         I[118 ^ 101].length();
         "".length();
         if (-1 != -1) {
            throw null;
         }
         break;
      case 2:
         var1.load((boolean)"".length());
         I[213 ^ 193].length();
         I[119 ^ 98].length();
         I[11 ^ 29].length();
         "".length();
         if (3 < 3) {
            throw null;
         }
         break;
      case 3:
         var1.unloadStructure();
      case 4:
      }

   }

   static {
      I();
      MODE = PropertyEnum.create(I[127 ^ 104], TileEntityStructure.Mode.class);
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      if (!var1.isRemote) {
         TileEntity var6 = var1.getTileEntity(var2);
         if (var6 instanceof TileEntityStructure) {
            TileEntityStructure var7 = (TileEntityStructure)var6;
            var7.createdBy(var4);
         }
      }

   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[74 ^ 78].length();
      return new TileEntityStructure();
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   public BlockStructure() {
      super(Material.IRON, MapColor.SILVER);
      this.setDefaultState(this.blockState.getBaseState());
   }

   private static void I() {
      I = new String[104 ^ 112];
      I["".length()] = I("渶昐", "mOeXA");
      I[" ".length()] = I("屚庘", "TyPvO");
      I["  ".length()] = I("吮嚠", "xmGKv");
      I["   ".length()] = I("澉淫", "nIxGG");
      I[175 ^ 171] = I("炐圫叴", "caUWP");
      I[42 ^ 47] = I("柅旮", "LqYgu");
      I[174 ^ 168] = I("匐峢", "hSItp");
      I[119 ^ 112] = I("捶囯", "cXZkY");
      I[86 ^ 94] = I("抚烀", "wcOpE");
      I[115 ^ 122] = I("执喝", "EAPTU");
      I[100 ^ 110] = I("変勁", "GCsFl");
      I[107 ^ 96] = I("桾栃", "kyNVh");
      I[97 ^ 109] = I("仡挱", "mpomL");
      I[19 ^ 30] = I("刟", "ZasiG");
      I[136 ^ 134] = I("夹娪嵔噠", "uruse");
      I[92 ^ 83] = I("槨刡", "GDNux");
      I[83 ^ 67] = I("呜楁", "IbVtj");
      I[8 ^ 25] = I("泑劅慰", "tJqqx");
      I[55 ^ 37] = I("喠壤浧氩", "lDvNK");
      I[23 ^ 4] = I("浙", "TXowI");
      I[149 ^ 129] = I("晑捁", "dmAMz");
      I[110 ^ 123] = I("冚娳昜歔", "UDJDx");
      I[60 ^ 42] = I("晍属斥娜侗", "FuYuv");
      I[66 ^ 85] = I("\n;\u00002", "gTdWb");
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote) {
         TileEntity var6 = var2.getTileEntity(var3);
         if (var6 instanceof TileEntityStructure) {
            TileEntityStructure var7 = (TileEntityStructure)var6;
            boolean var8 = var2.isBlockPowered(var3);
            boolean var9 = var7.isPowered();
            if (var8 && !var9) {
               var7.setPowered((boolean)" ".length());
               this.trigger(var7);
               "".length();
               if (3 == -1) {
                  throw null;
               }
            } else if (!var8 && var9) {
               var7.setPowered((boolean)"".length());
            }
         }
      }

   }
}

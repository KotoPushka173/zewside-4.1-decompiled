package net.minecraft.block.state;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableTable;
import com.google.common.collect.Iterables;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.util.ResourceLocation;

public abstract class BlockStateBase implements IBlockState {
   // $FF: synthetic field
   private static final Joiner COMMA_JOINER;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int metadata = -" ".length();
   // $FF: synthetic field
   private static final Function<Entry<IProperty<?>, Comparable<?>>, String> MAP_ENTRY_TO_STRING;
   // $FF: synthetic field
   private int blockId = -" ".length();
   // $FF: synthetic field
   private ResourceLocation blockLocation = null;
   // $FF: synthetic field
   private int blockStateId = -" ".length();

   public int getMetadata() {
      if (this.metadata < 0) {
         this.metadata = this.getBlock().getMetaFromState(this);
      }

      return this.metadata;
   }

   private static void I() {
      I = new String[91 ^ 73];
      I["".length()] = I("仧枫", "mMOiS");
      I[" ".length()] = I("朑惻", "tLWZy");
      I["  ".length()] = I("媈囬", "mVAUW");
      I["   ".length()] = I("妿剬", "wWRsx");
      I[187 ^ 191] = I("游浀潵煻", "bycxs");
      I[30 ^ 27] = I("嬬", "SESwv");
      I[129 ^ 135] = I("曜伂垨宮劌", "uoySJ");
      I[150 ^ 145] = I("曛渪斫撓", "ounnj");
      I[174 ^ 166] = I("\u0018", "Crulx");
      I[7 ^ 14] = I("墚拠帖暦漠", "PsePC");
      I[87 ^ 93] = I("呉泐", "CvAaQ");
      I[152 ^ 147] = I("挒", "gDAbV");
      I[187 ^ 183] = I("堦", "LWxuV");
      I[35 ^ 46] = I("润渡", "DzmBe");
      I[128 ^ 142] = I("侌孻域埿", "ZAIvN");
      I[18 ^ 29] = I("/", "rrEKZ");
      I[54 ^ 38] = I("冿漶殧", "ZLQvb");
      I[169 ^ 184] = I("寎", "iJPgP");
   }

   public String toString() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[154 ^ 158].length();
      StringBuilder var1 = new StringBuilder();
      var1.append(Block.REGISTRY.getNameForObject(this.getBlock()));
      I[15 ^ 10].length();
      I[42 ^ 44].length();
      I[34 ^ 37].length();
      if (!this.getProperties().isEmpty()) {
         var1.append(I[180 ^ 188]);
         I[126 ^ 119].length();
         I[95 ^ 85].length();
         COMMA_JOINER.appendTo(var1, Iterables.transform(this.getProperties().entrySet(), MAP_ENTRY_TO_STRING));
         I[163 ^ 168].length();
         I[66 ^ 78].length();
         I[82 ^ 95].length();
         I[103 ^ 105].length();
         var1.append(I[31 ^ 16]);
         I[24 ^ 8].length();
         I[163 ^ 178].length();
      }

      return var1.toString();
   }

   public ImmutableTable<IProperty<?>, Comparable<?>, IBlockState> getPropertyValueTable() {
      return null;
   }

   public ResourceLocation getBlockLocation() {
      if (this.blockLocation == null) {
         this.blockLocation = (ResourceLocation)Block.REGISTRY.getNameForObject(this.getBlock());
      }

      return this.blockLocation;
   }

   static {
      I();
      COMMA_JOINER = Joiner.on((char)('g' ^ 'K'));
      MAP_ENTRY_TO_STRING = new Function<Entry<IProperty<?>, Comparable<?>>, String>() {
         // $FF: synthetic field
         private static final String[] I;

         private static void I() {
            I = new String[69 ^ 76];
            I["".length()] = I("圩炒", "MCeXz");
            I[" ".length()] = I("嬁暐", "Rnvvq");
            I["  ".length()] = I("捄氓", "QwJGf");
            I["   ".length()] = I("敪娜", "tmnJF");
            I[8 ^ 12] = I("[=\u0004\u0006\u0004Y", "gsQJH");
            I[70 ^ 67] = I("廾", "HVrxB");
            I[100 ^ 98] = I("妇仼关", "iStSC");
            I[189 ^ 186] = I("淡怼曛", "ZjvJN");
            I[98 ^ 106] = I("Y", "dWjTe");
         }

         private <T extends Comparable<T>> String getPropertyName(IProperty<T> var1, Comparable<?> var2) {
            return var1.getName(var2);
         }

         @Nullable
         public String apply(@Nullable Entry<IProperty<?>, Comparable<?>> var1) {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            if (var1 == null) {
               return I[180 ^ 176];
            } else {
               IProperty var2 = (IProperty)var1.getKey();
               I[125 ^ 120].length();
               I[186 ^ 188].length();
               I[53 ^ 50].length();
               return var2.getName() + I[45 ^ 37] + this.getPropertyName(var2, (Comparable)var1.getValue());
            }
         }

         static {
            I();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 > 3);

            throw null;
         }
      };
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 2);

      throw null;
   }

   public int getBlockStateId() {
      if (this.blockStateId < 0) {
         this.blockStateId = Block.getStateId(this);
      }

      return this.blockStateId;
   }

   protected static <T> T cyclePropertyValue(Collection<T> var0, T var1) {
      Iterator var2 = var0.iterator();

      do {
         if (!var2.hasNext()) {
            return var2.next();
         }
      } while(!var2.next().equals(var1));

      if (var2.hasNext()) {
         return var2.next();
      } else {
         return var0.iterator().next();
      }
   }

   public int getBlockId() {
      if (this.blockId < 0) {
         this.blockId = Block.getIdFromBlock(this.getBlock());
      }

      return this.blockId;
   }

   public <T extends Comparable<T>> IBlockState cycleProperty(IProperty<T> var1) {
      return this.withProperty(var1, (Comparable)cyclePropertyValue(var1.getAllowedValues(), this.getValue(var1)));
   }
}

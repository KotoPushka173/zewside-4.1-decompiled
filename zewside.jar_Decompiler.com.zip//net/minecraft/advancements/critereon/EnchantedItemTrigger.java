package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class EnchantedItemTrigger implements ICriterionTrigger<EnchantedItemTrigger.Instance> {
   // $FF: synthetic field
   private final Map<PlayerAdvancements, EnchantedItemTrigger.Listeners> field_192192_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final ResourceLocation field_192191_a;

   public void func_192190_a(EntityPlayerMP var1, ItemStack var2, int var3) {
      EnchantedItemTrigger.Listeners var4 = (EnchantedItemTrigger.Listeners)this.field_192192_b.get(var1.func_192039_O());
      if (var4 != null) {
         var4.func_192459_a(var2, var3);
      }

   }

   public EnchantedItemTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[63 ^ 48];
      String var10001 = I[144 ^ 128];
      String var10002 = I[91 ^ 74];
      var10001 = I[15 ^ 29];
      ItemPredicate var3 = ItemPredicate.func_192492_a(var1.get(I[10 ^ 25]));
      MinMaxBounds var4 = MinMaxBounds.func_192515_a(var1.get(I[125 ^ 105]));
      I[113 ^ 100].length();
      I[165 ^ 179].length();
      I[181 ^ 162].length();
      I[133 ^ 157].length();
      I[11 ^ 18].length();
      return new EnchantedItemTrigger.Instance(var3, var4);
   }

   private static void I() {
      I = new String[94 ^ 69];
      I["".length()] = I("汾善", "iLwzu");
      I[" ".length()] = I("僙恕", "CgrTN");
      I["  ".length()] = I("娞擀", "lubID");
      I["   ".length()] = I("呂崐", "KSSvo");
      I[108 ^ 104] = I("栭拗姒嘦在", "jumdt");
      I[18 ^ 23] = I("崠忠亄凔噣", "GWmEf");
      I[40 ^ 46] = I("栀拫擋炏椓", "NyiXe");
      I[1 ^ 6] = I("劫噒垨", "ktvSb");
      I[82 ^ 90] = I("宪崮淜", "hNoby");
      I[131 ^ 138] = I("崊令擉", "HwkoP");
      I[10 ^ 0] = I("湡坍卨且墕", "BNMSZ");
      I[188 ^ 183] = I("屝中", "eBwMS");
      I[98 ^ 110] = I("乏", "gFyIM");
      I[28 ^ 17] = I("唕乁", "WmGps");
      I[156 ^ 146] = I("嚓", "glsed");
      I[52 ^ 59] = I("暝激", "IMWyv");
      I[117 ^ 101] = I("樵歬", "MxvJZ");
      I[173 ^ 188] = I("湺庣", "AbZjQ");
      I[77 ^ 95] = I("敡潼", "aileG");
      I[101 ^ 118] = I("\"#\u0002\u0003", "KWgnB");
      I[130 ^ 150] = I("8\u00021\u0016\u0002'", "TgGsn");
      I[67 ^ 86] = I("湥券兴恖暧", "DZkNC");
      I[29 ^ 11] = I("埧", "BJRBp");
      I[20 ^ 3] = I("咺埸唓併", "XSgzw");
      I[101 ^ 125] = I("彺", "kCpOL");
      I[84 ^ 77] = I("崎滯厇橠", "yKwAm");
      I[22 ^ 12] = I("\u0014\r\u0010\u0003\u0016\u001f\u0017\u0016\u000f(\u0018\u0017\u0016\u0006", "qcskw");
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192192_b.remove(var1);
      I[176 ^ 189].length();
      I[174 ^ 160].length();
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<EnchantedItemTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      EnchantedItemTrigger.Listeners var3 = (EnchantedItemTrigger.Listeners)this.field_192192_b.get(var1);
      if (var3 == null) {
         I[24 ^ 28].length();
         I[6 ^ 3].length();
         I[177 ^ 183].length();
         var3 = new EnchantedItemTrigger.Listeners(var1);
         this.field_192192_b.put(var1, var3);
         I[128 ^ 135].length();
         I[56 ^ 48].length();
         I[102 ^ 111].length();
      }

      var3.func_192460_a(var2);
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<EnchantedItemTrigger.Instance> var2) {
      EnchantedItemTrigger.Listeners var3 = (EnchantedItemTrigger.Listeners)this.field_192192_b.get(var1);
      if (var3 != null) {
         var3.func_192457_b(var2);
         if (var3.func_192458_a()) {
            this.field_192192_b.remove(var1);
            I[13 ^ 7].length();
            I[10 ^ 1].length();
            I[86 ^ 90].length();
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 < 4);

      throw null;
   }

   static {
      I();
      field_192191_a = new ResourceLocation(I[148 ^ 142]);
   }

   public ResourceLocation func_192163_a() {
      return field_192191_a;
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final MinMaxBounds field_192259_b;
      // $FF: synthetic field
      private final ItemPredicate field_192258_a;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 >= 1);

         throw null;
      }

      public Instance(ItemPredicate var1, MinMaxBounds var2) {
         super(EnchantedItemTrigger.field_192191_a);
         this.field_192258_a = var1;
         this.field_192259_b = var2;
      }

      public boolean func_192257_a(ItemStack var1, int var2) {
         return (boolean)(!this.field_192258_a.func_192493_a(var1) ? "".length() : this.field_192259_b.func_192514_a((float)var2));
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private final PlayerAdvancements field_192461_a;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<EnchantedItemTrigger.Instance>> field_192462_b = Sets.newHashSet();

      public Listeners(PlayerAdvancements var1) {
         this.field_192461_a = var1;
      }

      public void func_192460_a(ICriterionTrigger.Listener<EnchantedItemTrigger.Instance> var1) {
         this.field_192462_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }

      public void func_192457_b(ICriterionTrigger.Listener<EnchantedItemTrigger.Instance> var1) {
         this.field_192462_b.remove(var1);
         I["  ".length()].length();
         I["   ".length()].length();
         I[184 ^ 188].length();
         I[26 ^ 31].length();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 >= -1);

         throw null;
      }

      static {
         I();
      }

      public boolean func_192458_a() {
         return this.field_192462_b.isEmpty();
      }

      public void func_192459_a(ItemStack var1, int var2) {
         ArrayList var3 = null;
         Iterator var4 = this.field_192462_b.iterator();

         ICriterionTrigger.Listener var5;
         while(var4.hasNext()) {
            var5 = (ICriterionTrigger.Listener)var4.next();
            if (((EnchantedItemTrigger.Instance)var5.func_192158_a()).func_192257_a(var1, var2)) {
               if (var3 == null) {
                  var3 = Lists.newArrayList();
               }

               var3.add(var5);
               I[186 ^ 188].length();
               I[38 ^ 33].length();
            }

            "".length();
            if (-1 >= 4) {
               throw null;
            }
         }

         if (var3 != null) {
            var4 = var3.iterator();

            while(var4.hasNext()) {
               var5 = (ICriterionTrigger.Listener)var4.next();
               var5.func_192159_a(this.field_192461_a);
               "".length();
               if (0 == 4) {
                  throw null;
               }
            }
         }

      }

      private static void I() {
         I = new String[50 ^ 58];
         I["".length()] = I("摖噿囒", "QUpjL");
         I[" ".length()] = I("倆昨潘炳坨", "dcEpC");
         I["  ".length()] = I("濅尬嶉欐", "AOaok");
         I["   ".length()] = I("嵋俁漅", "yiaFX");
         I[132 ^ 128] = I("潍", "swVVG");
         I[118 ^ 115] = I("扟壠姲有", "coQEU");
         I[141 ^ 139] = I("敷", "mRdEl");
         I[4 ^ 3] = I("杽婑刚", "YpVIC");
      }
   }
}

package net.minecraft.network.play.server;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketCustomPayload implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private String channel;
   // $FF: synthetic field
   private PacketBuffer data;

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleCustomPayload(this);
   }

   private static void I() {
      I = new String[54 ^ 34];
      I["".length()] = I("\u001c\u000f\u00169\"-\nO8,5N\u0001:9l\f\nu!-\u001c\b0?l\u001a\u00074#l__auyYYu/5\u001a\n&", "LnoUM");
      I[" ".length()] = I("墫唨", "ZRSup");
      I["  ".length()] = I("勴伺", "EzzFj");
      I["   ".length()] = I("坉噄", "VzyRZ");
      I[46 ^ 42] = I("咺歰", "XBDZs");
      I[166 ^ 163] = I("兆凓", "VVbAW");
      I[40 ^ 46] = I("惆澑", "xGyYA");
      I[39 ^ 32] = I("最搪", "GQPMx");
      I[69 ^ 77] = I("沛勆", "mTfRy");
      I[148 ^ 157] = I("泒", "dTiuR");
      I[61 ^ 55] = I("嫎奔嚕烹溕", "yAqIg");
      I[184 ^ 179] = I("恩哠汽弇孩", "WfBPK");
      I[83 ^ 95] = I("凟呭冯", "pbrRq");
      I[79 ^ 66] = I("濤", "WobAb");
      I[47 ^ 33] = I("\u001a83\u0016\u001d+=j\u0017\u00133y$\u0015\u0006j;/Z\u001e++-\u001f\u0000j-\"\u001b\u001cjhzNJ\u007fn|Z\u00103-/\t", "JYJzr");
      I[143 ^ 128] = I("哸憰滊倊嚞", "ShNnT");
      I[31 ^ 15] = I("栣", "JbJvz");
      I[191 ^ 174] = I("氄巧", "WuYXi");
      I[175 ^ 189] = I("娜冴", "Zeptq");
      I[104 ^ 123] = I("忔", "msSLe");
   }

   public SPacketCustomPayload(String var1, PacketBuffer var2) {
      this.channel = var1;
      this.data = var2;
      if (var2.writerIndex() > 671618 + 973258 - 1140264 + 543964) {
         throw new IllegalArgumentException(I["".length()]);
      }
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[138 ^ 142];
      var10000 = I[101 ^ 96];
      var10001 = I[18 ^ 20];
      var10002 = I[125 ^ 122];
      var10001 = I[188 ^ 180];
      this.channel = var1.readStringFromBuffer(118 ^ 98);
      int var2 = var1.readableBytes();
      if (var2 >= 0 && var2 <= 593199 + 95752 - 2587 + 362212) {
         I[82 ^ 91].length();
         I[63 ^ 53].length();
         I[131 ^ 136].length();
         this.data = new PacketBuffer(var1.readBytes(var2));
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         I[60 ^ 48].length();
         I[172 ^ 161].length();
         IOException var3 = new IOException(I[55 ^ 57]);
         I[70 ^ 73].length();
         I[149 ^ 133].length();
         throw var3;
      }
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.channel);
      I[138 ^ 155].length();
      var1.writeBytes((ByteBuf)this.data);
      I[62 ^ 44].length();
      I[10 ^ 25].length();
   }

   public String getChannelName() {
      return this.channel;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 2);

      throw null;
   }

   public PacketBuffer getBufferData() {
      return this.data;
   }

   static {
      I();
   }

   public SPacketCustomPayload() {
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;

public class SPacketUpdateTileEntity implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int metadata;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private NBTTagCompound nbt;
   // $FF: synthetic field
   private BlockPos blockPos;

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleUpdateTileEntity(this);
   }

   public BlockPos getPos() {
      return this.blockPos;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.blockPos = var1.readBlockPos();
      this.metadata = var1.readUnsignedByte();
      this.nbt = var1.readNBTTagCompoundFromBuffer();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 0);

      throw null;
   }

   public SPacketUpdateTileEntity(BlockPos var1, int var2, NBTTagCompound var3) {
      this.blockPos = var1;
      this.metadata = var2;
      this.nbt = var3;
   }

   public int getTileEntityType() {
      return this.metadata;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeBlockPos(this.blockPos);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeByte((byte)this.metadata);
      I["  ".length()].length();
      I["   ".length()].length();
      I[75 ^ 79].length();
      var1.writeNBTTagCompoundToBuffer(this.nbt);
      I[111 ^ 106].length();
      I[0 ^ 6].length();
      I[108 ^ 107].length();
   }

   static {
      I();
   }

   public NBTTagCompound getNbtCompound() {
      return this.nbt;
   }

   public SPacketUpdateTileEntity() {
   }

   private static void I() {
      I = new String[90 ^ 82];
      I["".length()] = I("旓橱渢", "mYmVT");
      I[" ".length()] = I("剨斩懑朅", "DGuVW");
      I["  ".length()] = I("帜", "YtKzn");
      I["   ".length()] = I("杔儺戳樺溽", "nOLyK");
      I[85 ^ 81] = I("掓徑", "AtFbU");
      I[176 ^ 181] = I("垛坐", "GgNNt");
      I[120 ^ 126] = I("弦娞渞", "zYLBl");
      I[172 ^ 171] = I("某擽卦槨", "GVlVB");
   }
}

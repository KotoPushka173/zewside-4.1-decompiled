package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenBigTree;
import net.minecraft.world.gen.feature.WorldGenBirchTree;
import net.minecraft.world.gen.feature.WorldGenCanopyTree;
import net.minecraft.world.gen.feature.WorldGenMegaJungle;
import net.minecraft.world.gen.feature.WorldGenMegaPineTree;
import net.minecraft.world.gen.feature.WorldGenSavannaTree;
import net.minecraft.world.gen.feature.WorldGenTaiga2;
import net.minecraft.world.gen.feature.WorldGenTrees;
import net.minecraft.world.gen.feature.WorldGenerator;

public class BlockSapling extends BlockBush implements IGrowable {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockPlanks.EnumType> TYPE;
   // $FF: synthetic field
   public static final PropertyInteger STAGE;
   // $FF: synthetic field
   protected static final AxisAlignedBB SAPLING_AABB;

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[52 ^ 84];
      String var10001 = I[74 ^ 43];
      String var10002 = I[255 ^ 157];
      var10001 = I[116 ^ 23];
      BlockPlanks.EnumType[] var3 = BlockPlanks.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockPlanks.EnumType var6 = var3[var5];
         I[255 ^ 155].length();
         I[230 ^ 131].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[97 ^ 7].length();
         I[103 ^ 0].length();
         I[102 ^ 14].length();
         I[239 ^ 134].length();
         I[62 ^ 84].length();
         ++var5;
         "".length();
      } while(true);

      throw null;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(TYPE, BlockPlanks.EnumType.byMetadata(var1 & (154 ^ 157))).withProperty(STAGE, (var1 & (123 ^ 115)) >> "   ".length());
   }

   public String getLocalizedName() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[171 ^ 175].length();
      return I18n.translateToLocal(this.getUnlocalizedName() + I[38 ^ 35] + BlockPlanks.EnumType.OAK.getUnlocalizedName() + I[176 ^ 182]);
   }

   public boolean canGrow(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      return (boolean)" ".length();
   }

   private static void I() {
      I = new String[112 + 63 - 149 + 102];
      I["".length()] = I("峃侃", "WIrTk");
      I[" ".length()] = I("歺泶", "YzUVR");
      I["  ".length()] = I("塠棗", "QsFlC");
      I["   ".length()] = I("斁挐", "QQAQy");
      I[24 ^ 28] = I("巓恜徦溸", "uLwSk");
      I[120 ^ 125] = I("I", "gKjbB");
      I[66 ^ 68] = I("b/8\u001f/", "LAYrJ");
      I[175 ^ 168] = I("冃", "EryjT");
      I[49 ^ 57] = I("丑姷漀噙", "OAxTm");
      I[40 ^ 33] = I("亡楔浊忓", "iiQoK");
      I[31 ^ 21] = I("凓俙", "EMFDr");
      I[1 ^ 10] = I("澽弇", "DfAnm");
      I[138 ^ 134] = I("潗嵏", "ttSzP");
      I[175 ^ 162] = I("唢杤", "IEprX");
      I[117 ^ 123] = I("桷劈", "tmVtG");
      I[45 ^ 34] = I("慯埋", "AJIOU");
      I[12 ^ 28] = I("灵屽", "OvEGD");
      I[85 ^ 68] = I("尚楂", "eJFLH");
      I[106 ^ 120] = I("忌扥", "AmLjr");
      I[47 ^ 60] = I("汞檿", "ZXqtQ");
      I[189 ^ 169] = I("僛忒", "xvtGl");
      I[29 ^ 8] = I("捜叕", "wSbev");
      I[50 ^ 36] = I("圽則", "tVwfQ");
      I[124 ^ 107] = I("俈啴", "vJKFu");
      I[18 ^ 10] = I("倱歍", "hHrqZ");
      I[88 ^ 65] = I("沀堒", "zZarJ");
      I[87 ^ 77] = I("潤挎", "BpoEx");
      I[177 ^ 170] = I("嚂孄", "hgOsd");
      I[73 ^ 85] = I("侾摓", "uyPTA");
      I[41 ^ 52] = I("坆嫌", "KkQSM");
      I[120 ^ 102] = I("敾倍", "xgEnO");
      I[117 ^ 106] = I("椷卿", "rPqpP");
      I[188 ^ 156] = I("塟夺", "IJSPI");
      I[8 ^ 41] = I("塶椒", "wiHgS");
      I[169 ^ 139] = I("斀壟", "utIex");
      I[98 ^ 65] = I("吉泿", "aXAAA");
      I[161 ^ 133] = I("徟攔", "qHSND");
      I[15 ^ 42] = I("涷兢", "jrEGA");
      I[68 ^ 98] = I("埇巫", "Oeujq");
      I[20 ^ 51] = I("奿煡", "OpLnu");
      I[55 ^ 31] = I("啅嵅", "xbqct");
      I[119 ^ 94] = I("倫溯", "jXSNa");
      I[119 ^ 93] = I("新壾", "Avisb");
      I[91 ^ 112] = I("暐崭", "fxcZF");
      I[156 ^ 176] = I("泻煖", "tdhzN");
      I[46 ^ 3] = I("即泷", "NnGMX");
      I[98 ^ 76] = I("俁奲櫘", "mxdPe");
      I[37 ^ 10] = I("埝殿刂", "FLkwH");
      I[9 ^ 57] = I("戧哅櫕拂", "mDIOp");
      I[143 ^ 190] = I("徲", "vczHw");
      I[18 ^ 32] = I("溆溓", "bXwIV");
      I[138 ^ 185] = I("憈洳庎溋兟", "wtFrh");
      I[39 ^ 19] = I("亽椤滱仓墂", "cGrkH");
      I[109 ^ 88] = I("怇", "pppkK");
      I[12 ^ 58] = I("亿嶵", "FtyWY");
      I[59 ^ 12] = I("拱愀壗", "snnWp");
      I[42 ^ 18] = I("俖", "txDFk");
      I[94 ^ 103] = I("煊煅奵敟", "GzkNe");
      I[48 ^ 10] = I("五冃廈劵", "BYZQL");
      I[109 ^ 86] = I("俳梃", "uWGnf");
      I[59 ^ 7] = I("徱", "LpdYg");
      I[72 ^ 117] = I("庍", "xIyYZ");
      I[138 ^ 180] = I("桦漍咴", "NBmek");
      I[140 ^ 179] = I("彆暞峒強泾", "skWWO");
      I[220 ^ 156] = I("晴嚠洊劔", "KwspE");
      I[40 ^ 105] = I("浉樴悩氪", "XBdTE");
      I[102 ^ 36] = I("尉厘炳", "XTNFA");
      I[101 ^ 38] = I("撗杙", "DFDpD");
      I[29 ^ 89] = I("斁啲呞捘", "BFwvw");
      I[108 ^ 41] = I("搮", "zWbYy");
      I[84 ^ 18] = I("朣濉欶壙", "fMYLG");
      I[199 ^ 128] = I("星煤杁沞懩", "fgpmv");
      I[115 ^ 59] = I("暱渙愎岧", "NJneh");
      I[216 ^ 145] = I("徸歓晧灧", "lQsJV");
      I[83 ^ 25] = I("氩呧橊泷浌", "xgFiI");
      I[68 ^ 15] = I("壾槞恎嫂揗", "vlAsi");
      I[104 ^ 36] = I("啯", "EgaEz");
      I[127 ^ 50] = I("来母旉", "POzle");
      I[55 ^ 121] = I("嬶", "exana");
      I[78 ^ 1] = I("媏再", "jnVqd");
      I[238 ^ 190] = I("哬洛旂偼", "jBlTc");
      I[219 ^ 138] = I("櫸櫭拧妊", "hElSl");
      I[6 ^ 84] = I("拼樴恮", "YqtUe");
      I[224 ^ 179] = I("劤仵", "kSJbs");
      I[68 ^ 16] = I("澱彺亩劫忞", "rAoXE");
      I[102 ^ 51] = I("壬悗", "YUTnG");
      I[72 ^ 30] = I("姭妡亏昆", "Bztkt");
      I[237 ^ 186] = I("汼滾劳", "PadZA");
      I[123 ^ 35] = I("座扒溝", "WPpvW");
      I[218 ^ 131] = I("嫮潭炦湯潠", "DbuHT");
      I[127 ^ 37] = I("匷嬽", "niHNc");
      I[38 ^ 125] = I("煖撐前夳溺", "uATlZ");
      I[155 ^ 199] = I("泞烕允偳", "SYqeR");
      I[29 ^ 64] = I("檧廍", "jWZEQ");
      I[102 ^ 56] = I("柧棸呤倜拪", "GmjAL");
      I[82 ^ 13] = I("搾坳挳厭", "zvhmT");
      I[38 ^ 70] = I("北勳", "YHVus");
      I[79 ^ 46] = I("捆愸", "NrwiB");
      I[206 ^ 172] = I("嬮匰", "dhKnY");
      I[72 ^ 43] = I("滚无", "OIZGI");
      I[206 ^ 170] = I("桛咺昤", "doQlD");
      I[67 ^ 38] = I("亁", "WuYYZ");
      I[111 ^ 9] = I("旵咲剴妠", "jbyAp");
      I[11 ^ 108] = I("札炳洐", "AmlFx");
      I[2 ^ 106] = I("埩", "qMkke");
      I[245 ^ 156] = I("暎却", "Ohrpu");
      I[238 ^ 132] = I("圠卲少栲", "aZydf");
      I[120 ^ 19] = I("仳咗", "PTUaq");
      I[43 ^ 71] = I("壇榄", "atxOw");
      I[64 ^ 45] = I("修枩", "SvaxB");
      I[216 ^ 182] = I("暣怫", "lXjRS");
      I[236 ^ 131] = I("止洠", "JXSVF");
      I[197 ^ 181] = I("婚徦", "iKPCN");
      I[114 ^ 3] = I("弟徾", "QZGPa");
      I[219 ^ 169] = I("亢揬", "vYAqJ");
      I[252 ^ 143] = I("沲浤", "oYJPa");
      I[74 ^ 62] = I("崋偑", "GNYZb");
      I[50 ^ 71] = I("婠洋", "hvVDX");
      I[212 ^ 162] = I("丼涭", "pQFaj");
      I[214 ^ 161] = I("呔僴", "uMRFn");
      I[80 ^ 40] = I("淤", "DJxKr");
      I[115 ^ 10] = I("婝攕抶帪", "POFce");
      I[16 ^ 106] = I("恂三", "YkogF");
      I[8 ^ 115] = I("厑挍摨潣", "eAjrP");
      I[211 ^ 175] = I("旡挜叶", "JQQAf");
      I[53 ^ 72] = I("掊摩媀六", "UjmqQ");
      I[208 ^ 174] = I(".\u0014\u0015-", "ZmeHM");
      I[25 + 61 - 29 + 70] = I("=.2\u0017\u0006", "NZSpc");
   }

   protected BlockSapling() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(TYPE, BlockPlanks.EnumType.OAK).withProperty(STAGE, "".length()));
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[95 ^ 52];
      String var10001 = I[77 ^ 33];
      String var10002 = I[30 ^ 115];
      var10001 = I[226 ^ 140];
      var10000 = I[220 ^ 179];
      var10001 = I[110 ^ 30];
      var10002 = I[59 ^ 74];
      var10001 = I[13 ^ 127];
      var10000 = I[218 ^ 169];
      var10001 = I[94 ^ 42];
      var10002 = I[226 ^ 151];
      var10001 = I[47 ^ 89];
      I[80 ^ 39].length();
      I[42 ^ 82].length();
      I[204 ^ 181].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[100 ^ 30].length();
      I[82 ^ 41].length();
      var10003["".length()] = TYPE;
      I[65 ^ 61].length();
      I[38 ^ 91].length();
      var10003[" ".length()] = STAGE;
      return new BlockStateContainer(this, var10003);
   }

   static {
      I();
      TYPE = PropertyEnum.create(I[241 ^ 143], BlockPlanks.EnumType.class);
      STAGE = PropertyInteger.create(I[110 + 94 - 127 + 50], "".length(), " ".length());
      SAPLING_AABB = new AxisAlignedBB(0.09999999403953552D, 0.0D, 0.09999999403953552D, 0.8999999761581421D, 0.800000011920929D, 0.8999999761581421D);
   }

   public boolean canUseBonemeal(World var1, Random var2, BlockPos var3, IBlockState var4) {
      int var10000;
      if ((double)var1.rand.nextFloat() < 0.45D) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((BlockPlanks.EnumType)var1.getValue(TYPE)).getMetadata();
      var2 |= (Integer)var1.getValue(STAGE) << "   ".length();
      return var2;
   }

   public void grow(World var1, Random var2, BlockPos var3, IBlockState var4) {
      this.grow(var1, var3, var4, var2);
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote) {
         super.updateTick(var1, var2, var3, var4);
         if (var1.getLightFromNeighbors(var2.up()) >= (107 ^ 98) && var4.nextInt(188 ^ 187) == 0) {
            this.grow(var1, var2, var3, var4);
         }
      }

   }

   public void generateTree(World var1, BlockPos var2, IBlockState var3, Random var4) {
      String var10000 = I[21 ^ 31];
      String var10001 = I[118 ^ 125];
      String var10002 = I[204 ^ 192];
      var10001 = I[27 ^ 22];
      var10000 = I[82 ^ 92];
      var10001 = I[22 ^ 25];
      var10002 = I[93 ^ 77];
      var10001 = I[41 ^ 56];
      var10000 = I[8 ^ 26];
      var10001 = I[145 ^ 130];
      var10002 = I[61 ^ 41];
      var10001 = I[70 ^ 83];
      var10000 = I[86 ^ 64];
      var10001 = I[176 ^ 167];
      var10002 = I[22 ^ 14];
      var10001 = I[28 ^ 5];
      var10000 = I[138 ^ 144];
      var10001 = I[75 ^ 80];
      var10002 = I[3 ^ 31];
      var10001 = I[94 ^ 67];
      var10000 = I[122 ^ 100];
      var10001 = I[144 ^ 143];
      var10002 = I[185 ^ 153];
      var10001 = I[231 ^ 198];
      var10000 = I[34 ^ 0];
      var10001 = I[119 ^ 84];
      var10002 = I[3 ^ 39];
      var10001 = I[179 ^ 150];
      var10000 = I[97 ^ 71];
      var10001 = I[115 ^ 84];
      var10002 = I[157 ^ 181];
      var10001 = I[0 ^ 41];
      var10000 = I[184 ^ 146];
      var10001 = I[70 ^ 109];
      var10002 = I[106 ^ 70];
      var10001 = I[154 ^ 183];
      Object var11;
      if (var4.nextInt(41 ^ 35) == 0) {
         I[102 ^ 72].length();
         I[78 ^ 97].length();
         I[109 ^ 93].length();
         var11 = new WorldGenBigTree((boolean)" ".length());
         "".length();
         if (4 < 3) {
            throw null;
         }
      } else {
         I[9 ^ 56].length();
         I[78 ^ 124].length();
         I[109 ^ 94].length();
         I[153 ^ 173].length();
         I[111 ^ 90].length();
         var11 = new WorldGenTrees((boolean)" ".length());
      }

      Object var5 = var11;
      int var6 = "".length();
      int var7 = "".length();
      int var8 = "".length();
      IBlockState var9;
      switch(null.$SwitchMap$net$minecraft$block$BlockPlanks$EnumType[((BlockPlanks.EnumType)var3.getValue(TYPE)).ordinal()]) {
      case 1:
         var6 = "".length();

         label100:
         while(var6 >= -" ".length()) {
            var7 = "".length();

            while(var7 >= -" ".length()) {
               if (this.isTwoByTwoOfType(var1, var2, var6, var7, BlockPlanks.EnumType.SPRUCE)) {
                  I[133 ^ 179].length();
                  I[8 ^ 63].length();
                  var5 = new WorldGenMegaPineTree((boolean)"".length(), var4.nextBoolean());
                  var8 = " ".length();
                  "".length();
                  if (1 == 3) {
                     throw null;
                  }
                  break label100;
               }

               --var7;
               "".length();
               if (4 == 0) {
                  throw null;
               }
            }

            --var6;
            "".length();
            if (4 < 3) {
               throw null;
            }
         }

         if (var8 == 0) {
            var6 = "".length();
            var7 = "".length();
            I[110 ^ 86].length();
            I[20 ^ 45].length();
            I[121 ^ 67].length();
            var5 = new WorldGenTaiga2((boolean)" ".length());
            "".length();
            if (3 < 0) {
               throw null;
            }
         }
         break;
      case 2:
         I[18 ^ 41].length();
         I[121 ^ 69].length();
         I[79 ^ 114].length();
         var5 = new WorldGenBirchTree((boolean)" ".length(), (boolean)"".length());
         "".length();
         if (3 <= -1) {
            throw null;
         }
         break;
      case 3:
         var9 = Blocks.LOG.getDefaultState().withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.JUNGLE);
         IBlockState var10 = Blocks.LEAVES.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.JUNGLE).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf((boolean)"".length()));
         var6 = "".length();

         label114:
         while(var6 >= -" ".length()) {
            var7 = "".length();

            while(var7 >= -" ".length()) {
               if (this.isTwoByTwoOfType(var1, var2, var6, var7, BlockPlanks.EnumType.JUNGLE)) {
                  I[101 ^ 91].length();
                  I[165 ^ 154].length();
                  I[224 ^ 160].length();
                  I[41 ^ 104].length();
                  var5 = new WorldGenMegaJungle((boolean)" ".length(), 141 ^ 135, 16 ^ 4, var9, var10);
                  var8 = " ".length();
                  "".length();
                  if (false) {
                     throw null;
                  }
                  break label114;
               }

               --var7;
               "".length();
               if (4 < 2) {
                  throw null;
               }
            }

            --var6;
            "".length();
            if (3 == 1) {
               throw null;
            }
         }

         if (var8 == 0) {
            var6 = "".length();
            var7 = "".length();
            I[248 ^ 186].length();
            var5 = new WorldGenTrees((boolean)" ".length(), (62 ^ 58) + var4.nextInt(124 ^ 123), var9, var10, (boolean)"".length());
            "".length();
            if (3 < -1) {
               throw null;
            }
         }
         break;
      case 4:
         I[108 ^ 47].length();
         I[245 ^ 177].length();
         I[100 ^ 33].length();
         I[230 ^ 160].length();
         I[210 ^ 149].length();
         var5 = new WorldGenSavannaTree((boolean)" ".length());
         "".length();
         if (3 == 0) {
            throw null;
         }
         break;
      case 5:
         var6 = "".length();

         label128:
         while(var6 >= -" ".length()) {
            var7 = "".length();

            while(var7 >= -" ".length()) {
               if (this.isTwoByTwoOfType(var1, var2, var6, var7, BlockPlanks.EnumType.DARK_OAK)) {
                  I[72 ^ 0].length();
                  I[83 ^ 26].length();
                  var5 = new WorldGenCanopyTree((boolean)" ".length());
                  var8 = " ".length();
                  "".length();
                  if (0 == 2) {
                     throw null;
                  }
                  break label128;
               }

               --var7;
               "".length();
               if (-1 < -1) {
                  throw null;
               }
            }

            --var6;
            "".length();
            if (4 < 0) {
               throw null;
            }
         }

         if (var8 == 0) {
            return;
         }
      case 6:
      }

      var9 = Blocks.AIR.getDefaultState();
      if (var8 != 0) {
         var1.setBlockState(var2.add(var6, "".length(), var7), var9, 90 ^ 94);
         I[37 ^ 111].length();
         I[139 ^ 192].length();
         var1.setBlockState(var2.add(var6 + " ".length(), "".length(), var7), var9, 95 ^ 91);
         I[18 ^ 94].length();
         I[208 ^ 157].length();
         I[92 ^ 18].length();
         var1.setBlockState(var2.add(var6, "".length(), var7 + " ".length()), var9, 2 ^ 6);
         I[206 ^ 129].length();
         I[227 ^ 179].length();
         var1.setBlockState(var2.add(var6 + " ".length(), "".length(), var7 + " ".length()), var9, 86 ^ 82);
         I[73 ^ 24].length();
         I[201 ^ 155].length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      } else {
         var1.setBlockState(var2, var9, 123 ^ 127);
         I[58 ^ 105].length();
         I[103 ^ 51].length();
      }

      if (!((WorldGenerator)var5).generate(var1, var4, var2.add(var6, "".length(), var7))) {
         if (var8 != 0) {
            var1.setBlockState(var2.add(var6, "".length(), var7), var3, 18 ^ 22);
            I[251 ^ 174].length();
            I[47 ^ 121].length();
            I[255 ^ 168].length();
            var1.setBlockState(var2.add(var6 + " ".length(), "".length(), var7), var3, 129 ^ 133);
            I[230 ^ 190].length();
            I[92 ^ 5].length();
            var1.setBlockState(var2.add(var6, "".length(), var7 + " ".length()), var3, 44 ^ 40);
            I[12 ^ 86].length();
            var1.setBlockState(var2.add(var6 + " ".length(), "".length(), var7 + " ".length()), var3, 154 ^ 158);
            I[78 ^ 21].length();
            I[61 ^ 97].length();
            I[199 ^ 154].length();
            "".length();
            if (1 <= 0) {
               throw null;
            }
         } else {
            var1.setBlockState(var2, var3, 190 ^ 186);
            I[101 ^ 59].length();
            I[113 ^ 46].length();
         }
      }

   }

   public void grow(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if ((Integer)var3.getValue(STAGE) == 0) {
         var1.setBlockState(var2, var3.cycleProperty(STAGE), 88 ^ 92);
         I[170 ^ 173].length();
         I[100 ^ 108].length();
         I[128 ^ 137].length();
         "".length();
         if (3 == 0) {
            throw null;
         }
      } else {
         this.generateTree(var1, var2, var3, var4);
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 2);

      throw null;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return SAPLING_AABB;
   }

   private boolean isTwoByTwoOfType(World var1, BlockPos var2, int var3, int var4, BlockPlanks.EnumType var5) {
      int var10000;
      if (this.isTypeAt(var1, var2.add(var3, "".length(), var4), var5) && this.isTypeAt(var1, var2.add(var3 + " ".length(), "".length(), var4), var5) && this.isTypeAt(var1, var2.add(var3, "".length(), var4 + " ".length()), var5) && this.isTypeAt(var1, var2.add(var3 + " ".length(), "".length(), var4 + " ".length()), var5)) {
         var10000 = " ".length();
         "".length();
         if (3 == 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockPlanks.EnumType)var1.getValue(TYPE)).getMetadata();
   }

   public boolean isTypeAt(World var1, BlockPos var2, BlockPlanks.EnumType var3) {
      IBlockState var4 = var1.getBlockState(var2);
      int var10000;
      if (var4.getBlock() == this && var4.getValue(TYPE) == var3) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }
}

package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;
import me.zewside.client.event.EventManager;
import me.zewside.client.event.events.impl.player.EventLiquidSolid;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockLiquid extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyInteger LEVEL;

   private static void I() {
      I = new String[253 ^ 180];
      I["".length()] = I("夌啝", "QcRag");
      I[" ".length()] = I("俻滬", "NlMpp");
      I["  ".length()] = I("僝垐", "jqUxK");
      I["   ".length()] = I("澘啖", "niJoP");
      I[192 ^ 196] = I("壛揓", "hDHXw");
      I[140 ^ 137] = I("崰", "NKFJF");
      I[143 ^ 137] = I("店呫", "ocQdP");
      I[129 ^ 134] = I("憞栃", "qGQwk");
      I[51 ^ 59] = I("彰栢", "rjPQm");
      I[106 ^ 99] = I("梐搅", "DPXQM");
      I[92 ^ 86] = I("摪宓慏召漖", "qhJMo");
      I[94 ^ 85] = I("婅", "kruZU");
      I[12 ^ 0] = I("漺桚沤", "zwcWy");
      I[17 ^ 28] = I("人屚峦撜寝", "cNeNO");
      I[30 ^ 16] = I("撇小怸", "bERBR");
      I[127 ^ 112] = I("晸槭栙掿帧", "HCJsT");
      I[60 ^ 44] = I("炝", "XMPEc");
      I[9 ^ 24] = I("剉", "NmEIM");
      I[23 ^ 5] = I("伌慕凨", "LfCdG");
      I[69 ^ 86] = I("倬挝", "HqFxK");
      I[164 ^ 176] = I("旂怅凴", "obtwy");
      I[21 ^ 0] = I("渚宱", "NduMW");
      I[5 ^ 19] = I("咛恈包", "ZBKMu");
      I[87 ^ 64] = I("奼昊倛", "dZLJq");
      I[76 ^ 84] = I("彖", "uoBMk");
      I[59 ^ 34] = I("偹朸摔嚺徛", "kDbph");
      I[153 ^ 131] = I("杄墷", "VtRrD");
      I[152 ^ 131] = I("刱", "cHRWm");
      I[32 ^ 60] = I("淠", "UnaUy");
      I[21 ^ 8] = I("徙涭劏康擷", "VoPyV");
      I[17 ^ 15] = I("榫妭潅槲", "xxupW");
      I[87 ^ 72] = I("暅憌氩暝", "zWlCq");
      I[225 ^ 193] = I("妳庎嶍坨扵", "GbhIy");
      I[130 ^ 163] = I("拇瀴淛", "qbNnR");
      I[79 ^ 109] = I("樑涖", "VyGwP");
      I[25 ^ 58] = I("戫巰啟欘卾", "cBtsr");
      I[103 ^ 67] = I("杏棴佧嗍", "VVzvD");
      I[38 ^ 3] = I("憚", "MspVH");
      I[5 ^ 35] = I("檕", "eXqQX");
      I[27 ^ 60] = I("庥柚", "ugPLl");
      I[172 ^ 132] = I("屹嘶", "ezWPt");
      I[79 ^ 102] = I("攆刜", "pRpKu");
      I[160 ^ 138] = I("婮嗬", "HBDlJ");
      I[103 ^ 76] = I("殉擌", "XmLVq");
      I[84 ^ 120] = I("媎孆", "rjWcs");
      I[129 ^ 172] = I("栻侃", "iNkrP");
      I[38 ^ 8] = I("孈婇", "dBxBs");
      I[103 ^ 72] = I("槰抱孱壁", "InVXv");
      I[161 ^ 145] = I("嘛坮條", "GoNYA");
      I[131 ^ 178] = I("曽嫦", "iVZhY");
      I[7 ^ 53] = I("曨咴", "VlRNj");
      I[56 ^ 11] = I("庂剤", "cQXzl");
      I[82 ^ 102] = I("侃旑", "siHFL");
      I[190 ^ 139] = I("哙灃", "mgWGe");
      I[153 ^ 175] = I("戒滖", "wufFS");
      I[83 ^ 100] = I("9\u0001#\u0014\u001b\u0019\u000bu\u0018\u0016\u0004\n'\u001c\u0016\u001c", "poUuw");
      I[187 ^ 131] = I("沁樀临揟", "HiyTv");
      I[102 ^ 95] = I("瀘啽昝塶橥", "BmrbW");
      I[115 ^ 73] = I("媖廕壩悟", "mSFwM");
      I[39 ^ 28] = I("恶拁", "uQGxk");
      I[144 ^ 172] = I("殆抯", "cWymh");
      I[115 ^ 78] = I("准懑", "TpPrD");
      I[112 ^ 78] = I("孁拭", "IGBKx");
      I[253 ^ 194] = I("惥咜惃春", "vcaAt");
      I[244 ^ 180] = I("扡搢氅", "UcabG");
      I[239 ^ 174] = I("9+%7\u0005\u0019!s;\b\u0004 !?\b\u001c", "pESVi");
      I[33 ^ 99] = I("儔敿", "cfzKo");
      I[7 ^ 68] = I("死烊来惮傆", "XDxaO");
      I[14 ^ 74] = I("榉尩瀮恏", "hSfWG");
      I[200 ^ 141] = I("匤吰滉", "bxBip");
      I[29 ^ 91] = I("弮湁氅", "Xmovf");
      I[59 ^ 124] = I("備", "DBwcz");
      I[106 ^ 34] = I("\"3\u000e=\u001b", "NVxXw");
   }

   public static BlockDynamicLiquid getFlowingBlock(Material var0) {
      String var10000 = I[191 ^ 141];
      String var10001 = I[64 ^ 115];
      String var10002 = I[169 ^ 157];
      var10001 = I[72 ^ 125];
      if (var0 == Material.WATER) {
         return Blocks.FLOWING_WATER;
      } else if (var0 == Material.LAVA) {
         return Blocks.FLOWING_LAVA;
      } else {
         I[132 ^ 178].length();
         IllegalArgumentException var1 = new IllegalArgumentException(I[171 ^ 156]);
         I[178 ^ 138].length();
         I[134 ^ 191].length();
         I[162 ^ 152].length();
         throw var1;
      }
   }

   public int tickRate(World var1) {
      if (this.blockMaterial == Material.WATER) {
         return 49 ^ 52;
      } else if (this.blockMaterial == Material.LAVA) {
         int var10000;
         if (var1.provider.getHasNoSky()) {
            var10000 = 201 ^ 195;
            "".length();
            if (-1 >= 2) {
               throw null;
            }
         } else {
            var10000 = 12 ^ 18;
         }

         return var10000;
      } else {
         return "".length();
      }
   }

   public boolean shouldRenderSides(IBlockAccess var1, BlockPos var2) {
      int var3 = -" ".length();

      do {
         if (var3 > " ".length()) {
            return (boolean)"".length();
         }

         int var4 = -" ".length();

         while(var4 <= " ".length()) {
            IBlockState var5 = var1.getBlockState(var2.add(var3, "".length(), var4));
            if (var5.getMaterial() != this.blockMaterial && !var5.isFullBlock()) {
               return (boolean)" ".length();
            }

            ++var4;
            "".length();
            if (4 != 4) {
               throw null;
            }
         }

         ++var3;
         "".length();
      } while(true);

      throw null;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return FULL_BLOCK_AABB;
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(LEVEL);
   }

   public BlockRenderLayer getBlockLayer() {
      BlockRenderLayer var10000;
      if (this.blockMaterial == Material.WATER) {
         var10000 = BlockRenderLayer.TRANSLUCENT;
         "".length();
         if (2 <= 0) {
            throw null;
         }
      } else {
         var10000 = BlockRenderLayer.SOLID;
      }

      return var10000;
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      this.checkForMixing(var1, var2, var3);
      I[223 ^ 195].length();
      I[187 ^ 166].length();
      I[36 ^ 58].length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[132 ^ 163];
      String var10001 = I[35 ^ 11];
      String var10002 = I[13 ^ 36];
      var10001 = I[32 ^ 10];
      var10000 = I[164 ^ 143];
      var10001 = I[30 ^ 50];
      var10002 = I[84 ^ 121];
      var10001 = I[143 ^ 161];
      I[39 ^ 8].length();
      I[10 ^ 58].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[181 ^ 132].length();
      var10003["".length()] = LEVEL;
      return new BlockStateContainer(this, var10003);
   }

   public static BlockStaticLiquid getStaticBlock(Material var0) {
      String var10000 = I[32 ^ 27];
      String var10001 = I[84 ^ 104];
      String var10002 = I[132 ^ 185];
      var10001 = I[4 ^ 58];
      if (var0 == Material.WATER) {
         return Blocks.WATER;
      } else if (var0 == Material.LAVA) {
         return Blocks.LAVA;
      } else {
         I[26 ^ 37].length();
         I[7 ^ 71].length();
         IllegalArgumentException var1 = new IllegalArgumentException(I[234 ^ 171]);
         I[3 ^ 65].length();
         I[26 ^ 89].length();
         throw var1;
      }
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      double var5 = (double)var3.getX();
      double var7 = (double)var3.getY();
      double var9 = (double)var3.getZ();
      if (this.blockMaterial == Material.WATER) {
         int var11 = (Integer)var1.getValue(LEVEL);
         if (var11 > 0 && var11 < (24 ^ 16)) {
            if (var4.nextInt(222 ^ 158) == 0) {
               var2.playSound(var5 + 0.5D, var7 + 0.5D, var9 + 0.5D, SoundEvents.BLOCK_WATER_AMBIENT, SoundCategory.BLOCKS, var4.nextFloat() * 0.25F + 0.75F, var4.nextFloat() + 0.5F, (boolean)"".length());
               "".length();
               if (1 >= 2) {
                  throw null;
               }
            }
         } else if (var4.nextInt(46 ^ 36) == 0) {
            var2.spawnParticle(EnumParticleTypes.SUSPENDED, var5 + (double)var4.nextFloat(), var7 + (double)var4.nextFloat(), var9 + (double)var4.nextFloat(), 0.0D, 0.0D, 0.0D);
         }
      }

      if (this.blockMaterial == Material.LAVA && var2.getBlockState(var3.up()).getMaterial() == Material.AIR && !var2.getBlockState(var3.up()).isOpaqueCube()) {
         if (var4.nextInt(50 ^ 86) == 0) {
            double var18 = var5 + (double)var4.nextFloat();
            double var13 = var7 + var1.getBoundingBox(var2, var3).maxY;
            double var15 = var9 + (double)var4.nextFloat();
            var2.spawnParticle(EnumParticleTypes.LAVA, var18, var13, var15, 0.0D, 0.0D, 0.0D);
            var2.playSound(var18, var13, var15, SoundEvents.BLOCK_LAVA_POP, SoundCategory.BLOCKS, 0.2F + var4.nextFloat() * 0.2F, 0.9F + var4.nextFloat() * 0.15F, (boolean)"".length());
         }

         if (var4.nextInt(103 + 33 - 115 + 179) == 0) {
            var2.playSound(var5, var7, var9, SoundEvents.BLOCK_LAVA_AMBIENT, SoundCategory.BLOCKS, 0.2F + var4.nextFloat() * 0.2F, 0.9F + var4.nextFloat() * 0.15F, (boolean)"".length());
         }
      }

      if (var4.nextInt(65 ^ 75) == 0 && var2.getBlockState(var3.down()).isFullyOpaque()) {
         Material var19 = var2.getBlockState(var3.down("  ".length())).getMaterial();
         if (!var19.blocksMovement() && !var19.isLiquid()) {
            double var12 = var5 + (double)var4.nextFloat();
            I[158 ^ 137].length();
            I[51 ^ 43].length();
            I[118 ^ 111].length();
            double var14 = var7 - 1.05D;
            double var16 = var9 + (double)var4.nextFloat();
            if (this.blockMaterial == Material.WATER) {
               var2.spawnParticle(EnumParticleTypes.DRIP_WATER, var12, var14, var16, 0.0D, 0.0D, 0.0D);
               "".length();
               if (0 >= 4) {
                  throw null;
               }
            } else {
               var2.spawnParticle(EnumParticleTypes.DRIP_LAVA, var12, var14, var16, 0.0D, 0.0D, 0.0D);
            }
         }
      }

   }

   public static float func_190972_g(IBlockState var0, IBlockAccess var1, BlockPos var2) {
      return (float)var2.getY() + func_190973_f(var0, var1, var2);
   }

   protected BlockLiquid(Material var1) {
      super(var1);
      this.setDefaultState(this.blockState.getBaseState().withProperty(LEVEL, "".length()));
      this.setTickRandomly((boolean)" ".length());
   }

   public static float getSlopeAngle(IBlockAccess var0, BlockPos var1, Material var2, IBlockState var3) {
      Vec3d var4 = getFlowingBlock(var2).getFlow(var0, var1, var3);
      float var10000;
      if (var4.x == 0.0D && var4.z == 0.0D) {
         var10000 = -1000.0F;
         "".length();
         if (2 <= 0) {
            throw null;
         }
      } else {
         var10000 = (float)MathHelper.atan2(var4.z, var4.x);
         I[167 ^ 189].length();
         I[15 ^ 20].length();
         --var10000;
      }

      return var10000;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean canCollideCheck(IBlockState var1, boolean var2) {
      int var10000;
      if (var2 && (Integer)var1.getValue(LEVEL) == 0) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static float func_190973_f(IBlockState var0, IBlockAccess var1, BlockPos var2) {
      int var3 = (Integer)var0.getValue(LEVEL);
      float var10000;
      if ((var3 & (20 ^ 19)) == 0 && var1.getBlockState(var2.up()).getMaterial() == Material.WATER) {
         var10000 = 1.0F;
         "".length();
         if (1 <= 0) {
            throw null;
         }
      } else {
         float var10001 = getLiquidHeightPercent(var3);
         I[255 ^ 187].length();
         I[248 ^ 189].length();
         I[10 ^ 76].length();
         I[197 ^ 130].length();
         var10000 = 1.0F - var10001;
      }

      return var10000;
   }

   protected void triggerMixEffects(World var1, BlockPos var2) {
      double var3 = (double)var2.getX();
      double var5 = (double)var2.getY();
      double var7 = (double)var2.getZ();
      EntityPlayer var10001 = (EntityPlayer)null;
      SoundEvent var10003 = SoundEvents.BLOCK_LAVA_EXTINGUISH;
      SoundCategory var10004 = SoundCategory.BLOCKS;
      float var10007 = var1.rand.nextFloat();
      float var10008 = var1.rand.nextFloat();
      I[32 ^ 5].length();
      I[69 ^ 99].length();
      var1.playSound(var10001, var2, var10003, var10004, 0.5F, 2.6F + (var10007 - var10008) * 0.8F);
      int var9 = "".length();

      do {
         if (var9 >= (99 ^ 107)) {
            return;
         }

         var1.spawnParticle(EnumParticleTypes.SMOKE_LARGE, var3 + Math.random(), var5 + 1.2D, var7 + Math.random(), 0.0D, 0.0D, 0.0D);
         ++var9;
         "".length();
      } while(0 < 1);

      throw null;
   }

   protected int getDepth(IBlockState var1) {
      int var10000;
      if (var1.getMaterial() == this.blockMaterial) {
         var10000 = (Integer)var1.getValue(LEVEL);
         "".length();
         if (-1 == 3) {
            throw null;
         }
      } else {
         var10000 = -" ".length();
      }

      return var10000;
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.LIQUID;
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (var2.getBlockState(var3.offset(var4)).getMaterial() == this.blockMaterial) {
         return (boolean)"".length();
      } else {
         int var10000;
         if (var4 == EnumFacing.UP) {
            var10000 = " ".length();
            "".length();
            if (0 == 2) {
               throw null;
            }
         } else {
            var10000 = super.shouldSideBeRendered(var1, var2, var3, var4);
         }

         return (boolean)var10000;
      }
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.field_190931_a;
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   private boolean isBlockSolid(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
      IBlockState var4 = var1.getBlockState(var2);
      Block var5 = var4.getBlock();
      Material var6 = var4.getMaterial();
      if (var6 == this.blockMaterial) {
         return (boolean)"".length();
      } else if (var3 == EnumFacing.UP) {
         return (boolean)" ".length();
      } else if (var6 == Material.ICE) {
         return (boolean)"".length();
      } else {
         int var10000;
         if (!func_193382_c(var5) && !(var5 instanceof BlockStairs)) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (4 <= 1) {
               throw null;
            }
         }

         int var7 = var10000;
         if (var7 == 0 && var4.func_193401_d(var1, var2, var3) == BlockFaceShape.SOLID) {
            var10000 = " ".length();
            "".length();
            if (4 <= 1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      this.checkForMixing(var2, var3, var1);
      I[84 ^ 75].length();
   }

   protected Vec3d getFlow(IBlockAccess var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[138 ^ 140];
      String var10001 = I[9 ^ 14];
      String var10002 = I[35 ^ 43];
      var10001 = I[188 ^ 181];
      double var4 = 0.0D;
      double var6 = 0.0D;
      double var8 = 0.0D;
      int var10 = this.getRenderedDepth(var3);
      BlockPos.PooledMutableBlockPos var11 = BlockPos.PooledMutableBlockPos.retain();
      Iterator var12 = EnumFacing.Plane.HORIZONTAL.iterator();

      while(var12.hasNext()) {
         EnumFacing var13 = (EnumFacing)var12.next();
         var11.setPos((Vec3i)var2).move(var13);
         I[16 ^ 26].length();
         I[34 ^ 41].length();
         int var14 = this.getRenderedDepth(var1.getBlockState(var11));
         int var15;
         if (var14 < 0) {
            if (!var1.getBlockState(var11).getMaterial().blocksMovement()) {
               var14 = this.getRenderedDepth(var1.getBlockState(var11.down()));
               if (var14 >= 0) {
                  int var20 = 60 ^ 52;
                  I[204 ^ 192].length();
                  I[54 ^ 59].length();
                  int var19 = var10 - var20;
                  I[9 ^ 7].length();
                  I[72 ^ 71].length();
                  I[152 ^ 136].length();
                  var15 = var14 - var19;
                  var4 += (double)(var13.getFrontOffsetX() * var15);
                  var6 += (double)(var13.getFrontOffsetY() * var15);
                  var8 += (double)(var13.getFrontOffsetZ() * var15);
                  "".length();
                  if (1 == 3) {
                     throw null;
                  }
               }
            }
         } else if (var14 >= 0) {
            I[167 ^ 182].length();
            I[134 ^ 148].length();
            I[52 ^ 39].length();
            var15 = var14 - var10;
            var4 += (double)(var13.getFrontOffsetX() * var15);
            var6 += (double)(var13.getFrontOffsetY() * var15);
            var8 += (double)(var13.getFrontOffsetZ() * var15);
         }

         "".length();
         if (-1 >= 2) {
            throw null;
         }
      }

      I[3 ^ 23].length();
      Vec3d var16 = new Vec3d(var4, var6, var8);
      if ((Integer)var3.getValue(LEVEL) >= (42 ^ 34)) {
         Iterator var17 = EnumFacing.Plane.HORIZONTAL.iterator();

         while(var17.hasNext()) {
            EnumFacing var18 = (EnumFacing)var17.next();
            var11.setPos((Vec3i)var2).move(var18);
            I[17 ^ 4].length();
            I[110 ^ 120].length();
            if (this.isBlockSolid(var1, var11, var18) || this.isBlockSolid(var1, var11.up(), var18)) {
               var16 = var16.normalize().add(0.0D, -6.0D, 0.0D);
               "".length();
               if (4 < 0) {
                  throw null;
               }
               break;
            }

            "".length();
            if (false) {
               throw null;
            }
         }
      }

      var11.release();
      return var16.normalize();
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(LEVEL, var1);
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public Vec3d modifyAcceleration(World var1, BlockPos var2, Entity var3, Vec3d var4) {
      return var4.add(this.getFlow(var1, var2, var1.getBlockState(var2)));
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      int var10000;
      if (this.blockMaterial != Material.LAVA) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[23 ^ 19].length();
      EventLiquidSolid var4 = new EventLiquidSolid(this, var3);
      EventManager.call(var4);
      I[3 ^ 6].length();
      return var4.getCollision();
   }

   public boolean checkForMixing(World var1, BlockPos var2, IBlockState var3) {
      if (this.blockMaterial == Material.LAVA) {
         int var4 = "".length();
         EnumFacing[] var5 = EnumFacing.values();
         int var6 = var5.length;
         int var7 = "".length();

         while(var7 < var6) {
            EnumFacing var8 = var5[var7];
            if (var8 != EnumFacing.DOWN && var1.getBlockState(var2.offset(var8)).getMaterial() == Material.WATER) {
               var4 = " ".length();
               "".length();
               if (2 != 2) {
                  throw null;
               }
               break;
            }

            ++var7;
            "".length();
            if (1 <= -1) {
               throw null;
            }
         }

         if (var4 != 0) {
            Integer var9 = (Integer)var3.getValue(LEVEL);
            if (var9 == 0) {
               var1.setBlockState(var2, Blocks.OBSIDIAN.getDefaultState());
               I[137 ^ 169].length();
               I[7 ^ 38].length();
               this.triggerMixEffects(var1, var2);
               return (boolean)" ".length();
            }

            if (var9 <= (94 ^ 90)) {
               var1.setBlockState(var2, Blocks.COBBLESTONE.getDefaultState());
               I[74 ^ 104].length();
               I[149 ^ 182].length();
               I[134 ^ 162].length();
               this.triggerMixEffects(var1, var2);
               return (boolean)" ".length();
            }
         }
      }

      return (boolean)"".length();
   }

   static {
      I();
      LEVEL = PropertyInteger.create(I[35 ^ 107], "".length(), 140 ^ 131);
   }

   public int getPackedLightmapCoords(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      int var4 = var2.getCombinedLight(var3, "".length());
      int var5 = var2.getCombinedLight(var3.up(), "".length());
      int var6 = var4 & 206 + 138 - 293 + 204;
      int var7 = var5 & 121 + 7 - -19 + 108;
      int var8 = var4 >> (190 ^ 174) & 73 + 175 - 183 + 190;
      int var9 = var5 >> (215 ^ 199) & 195 + 95 - 71 + 36;
      int var10000;
      if (var6 > var7) {
         var10000 = var6;
         "".length();
         if (2 == 1) {
            throw null;
         }
      } else {
         var10000 = var7;
      }

      int var10001;
      if (var8 > var9) {
         var10001 = var8;
         "".length();
         if (-1 < -1) {
            throw null;
         }
      } else {
         var10001 = var9;
      }

      return var10000 | var10001 << (16 ^ 0);
   }

   protected int getRenderedDepth(IBlockState var1) {
      int var2 = this.getDepth(var1);
      int var10000;
      if (var2 >= (189 ^ 181)) {
         var10000 = "".length();
         "".length();
         if (4 < 0) {
            throw null;
         }
      } else {
         var10000 = var2;
      }

      return var10000;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 4);

      throw null;
   }

   public static float getLiquidHeightPercent(int var0) {
      if (var0 >= (97 ^ 105)) {
         var0 = "".length();
      }

      return (float)(var0 + " ".length()) / 9.0F;
   }
}

package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockCarpet extends Block {
   // $FF: synthetic field
   public static final PropertyEnum<EnumDyeColor> COLOR;
   // $FF: synthetic field
   protected static final AxisAlignedBB CARPET_AABB;
   // $FF: synthetic field
   private static final String[] I;

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (super.canPlaceBlockAt(var1, var2) && this.canBlockStay(var1, var2)) {
         var10000 = " ".length();
         "".length();
         if (3 < 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (var4 == EnumFacing.UP) {
         return (boolean)" ".length();
      } else {
         int var10000;
         if (var2.getBlockState(var3.offset(var4)).getBlock() == this) {
            var10000 = " ".length();
            "".length();
            if (3 == 4) {
               throw null;
            }
         } else {
            var10000 = super.shouldSideBeRendered(var1, var2, var3, var4);
         }

         return (boolean)var10000;
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 3);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(COLOR)).getMetadata();
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = BlockFaceShape.SOLID;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   protected BlockCarpet() {
      super(Material.CARPET);
      this.setDefaultState(this.blockState.getBaseState().withProperty(COLOR, EnumDyeColor.WHITE));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[31 ^ 17];
      String var10001 = I[48 ^ 63];
      String var10002 = I[49 ^ 33];
      var10001 = I[181 ^ 164];
      var10000 = I[172 ^ 190];
      var10001 = I[23 ^ 4];
      var10002 = I[30 ^ 10];
      var10001 = I[52 ^ 33];
      I[126 ^ 104].length();
      I[88 ^ 79].length();
      I[55 ^ 47].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[122 ^ 99].length();
      I[46 ^ 52].length();
      I[101 ^ 126].length();
      var10003["".length()] = COLOR;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(COLOR, EnumDyeColor.byMetadata(var1));
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.func_193558_a((EnumDyeColor)var1.getValue(COLOR));
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return CARPET_AABB;
   }

   private boolean canBlockStay(World var1, BlockPos var2) {
      int var10000;
      if (!var1.isAirBlock(var2.down())) {
         var10000 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int damageDropped(IBlockState var1) {
      return ((EnumDyeColor)var1.getValue(COLOR)).getMetadata();
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[145 ^ 149];
      String var10001 = I[169 ^ 172];
      String var10002 = I[77 ^ 75];
      var10001 = I[19 ^ 20];
      int var3 = "".length();

      do {
         if (var3 >= (100 ^ 116)) {
            return;
         }

         I[149 ^ 157].length();
         I[117 ^ 124].length();
         var2.add(new ItemStack(this, " ".length(), var3));
         I[68 ^ 78].length();
         I[22 ^ 29].length();
         I[3 ^ 15].length();
         I[20 ^ 25].length();
         ++var3;
         "".length();
      } while(3 != 1);

      throw null;
   }

   private static void I() {
      I = new String[136 ^ 149];
      I["".length()] = I("傾寭比楂", "IOGxt");
      I[" ".length()] = I("澠傶柡嘄", "yWnKQ");
      I["  ".length()] = I("晽恬丛", "jsHec");
      I["   ".length()] = I("殷嚄榫", "BhDwJ");
      I[63 ^ 59] = I("徶悿", "sunkl");
      I[121 ^ 124] = I("偧媪", "zBJaa");
      I[171 ^ 173] = I("慍棹", "svAdq");
      I[192 ^ 199] = I("澙右", "xDWEF");
      I[28 ^ 20] = I("忉", "SSpGn");
      I[55 ^ 62] = I("倷", "KUjWY");
      I[54 ^ 60] = I("杖嬣灳楉嚶", "KkSaA");
      I[1 ^ 10] = I("橎榋扉夶溨", "lstMO");
      I[50 ^ 62] = I("凈檢愤", "FRORa");
      I[170 ^ 167] = I("慐搙", "rOMju");
      I[47 ^ 33] = I("戒墴", "daZzO");
      I[149 ^ 154] = I("枉攀", "txtcO");
      I[140 ^ 156] = I("叫搢", "jcWsn");
      I[50 ^ 35] = I("注榰", "qKcoC");
      I[32 ^ 50] = I("旧澌", "vbzWN");
      I[28 ^ 15] = I("櫰亅", "Gjrry");
      I[117 ^ 97] = I("橪櫛", "jItkb");
      I[161 ^ 180] = I("嫣屇", "XIsBt");
      I[66 ^ 84] = I("扩孥批倰", "kaUlJ");
      I[79 ^ 88] = I("屳咾唏", "CQTVl");
      I[178 ^ 170] = I("溥水憷僱呛", "ZLZmh");
      I[148 ^ 141] = I("樎仫損弊", "NjbOa");
      I[56 ^ 34] = I("噛栚媽烉", "NpApk");
      I[182 ^ 173] = I("凍澏惝椤", "hpzIg");
      I[159 ^ 131] = I("0\u0004)&%", "SkEIW");
   }

   static {
      I();
      COLOR = PropertyEnum.create(I[58 ^ 38], EnumDyeColor.class);
      CARPET_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.0625D, 1.0D);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      this.checkForDrop(var2, var3, var1);
      I["".length()].length();
      I[" ".length()].length();
   }

   private boolean checkForDrop(World var1, BlockPos var2, IBlockState var3) {
      if (!this.canBlockStay(var1, var2)) {
         this.dropBlockAsItem(var1, var2, var3, "".length());
         var1.setBlockToAir(var2);
         I["  ".length()].length();
         I["   ".length()].length();
         return (boolean)"".length();
      } else {
         return (boolean)" ".length();
      }
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class SPacketUseBed implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int playerID;
   // $FF: synthetic field
   private BlockPos bedPos;
   // $FF: synthetic field
   private static final String[] I;

   public EntityPlayer getPlayer(World var1) {
      return (EntityPlayer)var1.getEntityByID(this.playerID);
   }

   static {
      I();
   }

   public BlockPos getBedPosition() {
      return this.bedPos;
   }

   public SPacketUseBed() {
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 4);

      throw null;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.playerID);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeBlockPos(this.bedPos);
      I["  ".length()].length();
      I["   ".length()].length();
   }

   private static void I() {
      I = new String[135 ^ 131];
      I["".length()] = I("僧", "Exffm");
      I[" ".length()] = I("廜哎挖", "izvey");
      I["  ".length()] = I("俑凝劸", "UOYER");
      I["   ".length()] = I("漣尴", "VmxHb");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.playerID = var1.readVarIntFromBuffer();
      this.bedPos = var1.readBlockPos();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleUseBed(this);
   }

   public SPacketUseBed(EntityPlayer var1, BlockPos var2) {
      this.playerID = var1.getEntityId();
      this.bedPos = var2;
   }
}

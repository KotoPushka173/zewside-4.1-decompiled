package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.PotionTypes;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBanner;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionUtils;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntityBanner;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockCauldron extends Block {
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_WALL_EAST;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_WALL_WEST;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_LEGS;
   // $FF: synthetic field
   public static final PropertyInteger LEVEL;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_WALL_NORTH;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_WALL_SOUTH;
   // $FF: synthetic field
   private static final String[] I;

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      if (var4 == EnumFacing.UP) {
         return BlockFaceShape.BOWL;
      } else {
         BlockFaceShape var10000;
         if (var4 == EnumFacing.DOWN) {
            var10000 = BlockFaceShape.UNDEFINED;
            "".length();
            if (3 <= 2) {
               throw null;
            }
         } else {
            var10000 = BlockFaceShape.SOLID;
         }

         return var10000;
      }
   }

   public void fillWithRain(World var1, BlockPos var2) {
      if (var1.rand.nextInt(163 ^ 183) == " ".length()) {
         float var3 = var1.getBiome(var2).getFloatTemperature(var2);
         if (var1.getBiomeProvider().getTemperatureAtHeight(var3, var2.getY()) >= 0.15F) {
            IBlockState var4 = var1.getBlockState(var2);
            if ((Integer)var4.getValue(LEVEL) < "   ".length()) {
               var1.setBlockState(var2, var4.cycleProperty(LEVEL), "  ".length());
               I[79 ^ 113].length();
               I[113 ^ 78].length();
            }
         }
      }

   }

   public BlockCauldron() {
      super(Material.IRON, MapColor.STONE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(LEVEL, "".length()));
   }

   public void setWaterLevel(World var1, BlockPos var2, IBlockState var3, int var4) {
      var1.setBlockState(var2, var3.withProperty(LEVEL, MathHelper.clamp(var4, "".length(), "   ".length())), "  ".length());
      I[182 ^ 138].length();
      I[185 ^ 132].length();
      var1.updateComparatorOutputLevel(var2, this);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return FULL_BLOCK_AABB;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(LEVEL, var1);
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      return (boolean)" ".length();
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.CAULDRON;
   }

   private static void I() {
      I = new String[233 ^ 187];
      I["".length()] = I("欯楙溊", "eUdtp");
      I[" ".length()] = I("桹憃执仸瀐", "LRseM");
      I["  ".length()] = I("挾斖", "IudYl");
      I["   ".length()] = I("劖嵮", "XapIT");
      I[163 ^ 167] = I("圢己", "tQNoy");
      I[149 ^ 144] = I("戭氥", "UBYxe");
      I[137 ^ 143] = I("偼杳", "DFuDh");
      I[82 ^ 85] = I("振毎", "XgMeL");
      I[156 ^ 148] = I("嬅嘴", "FyyUM");
      I[109 ^ 100] = I("灔渡", "TVICI");
      I[44 ^ 38] = I("氲慄", "IWJhB");
      I[138 ^ 129] = I("喹暕", "bHLaA");
      I[91 ^ 87] = I("偘伟", "XfdSD");
      I[12 ^ 1] = I("崵濲", "wPNvH");
      I[100 ^ 106] = I("匴恂", "nrNfO");
      I[61 ^ 50] = I("味曡", "hfDiX");
      I[106 ^ 122] = I("橁喲", "FDEhr");
      I[60 ^ 45] = I("幂仟", "jnqcb");
      I[44 ^ 62] = I("对払", "ixAae");
      I[88 ^ 75] = I("刪师", "ltful");
      I[47 ^ 59] = I("昍拫", "pVYBg");
      I[107 ^ 126] = I("楹杺", "DRnWW");
      I[108 ^ 122] = I("憉徴", "MiHHX");
      I[2 ^ 21] = I("含旗", "jXdbl");
      I[166 ^ 190] = I("汔擫", "hloHL");
      I[27 ^ 2] = I("会抗", "SSMNA");
      I[121 ^ 99] = I("洏", "bSgBI");
      I[40 ^ 51] = I("悅", "NBeag");
      I[154 ^ 134] = I("墕滦", "OwjPt");
      I[49 ^ 44] = I("岀渶慛屢劬", "qCEtk");
      I[158 ^ 128] = I("栎乥垼", "lHivS");
      I[72 ^ 87] = I("叙喆", "smQxg");
      I[168 ^ 136] = I("徛掿栙撂", "RjgUJ");
      I[32 ^ 1] = I("屴屆幔幓", "UxjsA");
      I[89 ^ 123] = I("慘", "ZkfqK");
      I[62 ^ 29] = I("単", "rBesg");
      I[137 ^ 173] = I("戃意匲幥枞", "kwFFk");
      I[173 ^ 136] = I("店憶", "aAuyP");
      I[36 ^ 2] = I("寉", "yAbcs");
      I[138 ^ 173] = I("淡壡楉塹伴", "gHNJb");
      I[58 ^ 18] = I("垂楈朅櫷", "hlDlx");
      I[134 ^ 175] = I("套", "AfxJl");
      I[88 ^ 114] = I("侧泸炨嫶凲", "KIlcz");
      I[133 ^ 174] = I("帞刕効彠", "baGqR");
      I[33 ^ 13] = I("呵", "ecDim");
      I[55 ^ 26] = I("哞晘", "fZJEt");
      I[97 ^ 79] = I("寨橉扔", "CwIdP");
      I[105 ^ 70] = I("合俻洔斂", "ZXhYX");
      I[141 ^ 189] = I("忴壛", "gFrXP");
      I[142 ^ 191] = I("仇沴", "VXFPj");
      I[96 ^ 82] = I("掓", "VDYjC");
      I[101 ^ 86] = I("懮柾", "AKIDr");
      I[106 ^ 94] = I("娓橖快弔烳", "NnuHy");
      I[136 ^ 189] = I("庤", "EybGJ");
      I[86 ^ 96] = I("庮囄坖", "inOwb");
      I[61 ^ 10] = I("櫭咣岊", "lcyxP");
      I[152 ^ 160] = I("促奧昊旦兝", "yBQOE");
      I[154 ^ 163] = I("掽堛汝", "GUPLr");
      I[80 ^ 106] = I("兪岪", "mPOQC");
      I[173 ^ 150] = I("孶埏", "EhyzI");
      I[0 ^ 60] = I("斠", "CaCmk");
      I[8 ^ 53] = I("乯喐権哵帼", "YDrFn");
      I[184 ^ 134] = I("夙曒噞", "MswIw");
      I[83 ^ 108] = I("嘙囻崱嘞", "BMgJX");
      I[51 ^ 115] = I("晠吀", "yIPTW");
      I[57 ^ 120] = I("渎埛", "cqjLY");
      I[128 ^ 194] = I("浈撖", "SyWlq");
      I[128 ^ 195] = I("揽亞", "wALKU");
      I[54 ^ 114] = I("渿嫧亳", "hdCZi");
      I[194 ^ 135] = I("凢惷剖埊", "pEEaj");
      I[22 ^ 80] = I("渴橛殽捥溜", "KkNfC");
      I[198 ^ 129] = I("橉垈", "lFliD");
      I[229 ^ 173] = I("晃墋", "nkMvb");
      I[39 ^ 110] = I("撛湞", "ATQcL");
      I[40 ^ 98] = I("呧戣", "FUSEZ");
      I[123 ^ 48] = I("丕兿", "CJmhU");
      I[67 ^ 15] = I("壒栓", "WLFZq");
      I[137 ^ 196] = I("偭斡", "cxtxu");
      I[213 ^ 155] = I("偯克", "WadHc");
      I[216 ^ 151] = I("喰刔", "LIbNI");
      I[83 ^ 3] = I("李仿", "ynfYB");
      I[255 ^ 174] = I("\u0006\u000b\u0004\u000b=", "jnrnQ");
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   static {
      I();
      LEVEL = PropertyInteger.create(I[221 ^ 140], "".length(), "   ".length());
      AABB_LEGS = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.3125D, 1.0D);
      AABB_WALL_NORTH = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.125D);
      AABB_WALL_SOUTH = new AxisAlignedBB(0.0D, 0.0D, 0.875D, 1.0D, 1.0D, 1.0D);
      AABB_WALL_EAST = new AxisAlignedBB(0.875D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      AABB_WALL_WEST = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.125D, 1.0D, 1.0D);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      String var10000 = I["  ".length()];
      String var10001 = I["   ".length()];
      String var10002 = I[143 ^ 139];
      var10001 = I[183 ^ 178];
      var10000 = I[171 ^ 173];
      var10001 = I[99 ^ 100];
      var10002 = I[40 ^ 32];
      var10001 = I[170 ^ 163];
      var10000 = I[178 ^ 184];
      var10001 = I[191 ^ 180];
      var10002 = I[113 ^ 125];
      var10001 = I[69 ^ 72];
      var10000 = I[167 ^ 169];
      var10001 = I[76 ^ 67];
      var10002 = I[47 ^ 63];
      var10001 = I[163 ^ 178];
      var10000 = I[121 ^ 107];
      var10001 = I[23 ^ 4];
      var10002 = I[190 ^ 170];
      var10001 = I[114 ^ 103];
      var10000 = I[186 ^ 172];
      var10001 = I[51 ^ 36];
      var10002 = I[35 ^ 59];
      var10001 = I[72 ^ 81];
      ItemStack var10 = var4.getHeldItem(var5);
      if (var10.isEmpty()) {
         return (boolean)" ".length();
      } else {
         int var11 = (Integer)var3.getValue(LEVEL);
         Item var12 = var10.getItem();
         if (var12 == Items.WATER_BUCKET) {
            if (var11 < "   ".length() && !var1.isRemote) {
               if (!var4.capabilities.isCreativeMode) {
                  I[56 ^ 34].length();
                  I[5 ^ 30].length();
                  I[13 ^ 17].length();
                  var4.setHeldItem(var5, new ItemStack(Items.BUCKET));
               }

               var4.addStat(StatList.CAULDRON_FILLED);
               this.setWaterLevel(var1, var2, var3, "   ".length());
               var1.playSound((EntityPlayer)null, var2, SoundEvents.ITEM_BUCKET_EMPTY, SoundCategory.BLOCKS, 1.0F, 1.0F);
            }

            return (boolean)" ".length();
         } else if (var12 == Items.BUCKET) {
            if (var11 == "   ".length() && !var1.isRemote) {
               if (!var4.capabilities.isCreativeMode) {
                  var10.func_190918_g(" ".length());
                  if (var10.isEmpty()) {
                     I[29 ^ 0].length();
                     var4.setHeldItem(var5, new ItemStack(Items.WATER_BUCKET));
                     "".length();
                     if (0 >= 1) {
                        throw null;
                     }
                  } else {
                     InventoryPlayer var15 = var4.inventory;
                     I[165 ^ 187].length();
                     I[131 ^ 156].length();
                     if (!var15.addItemStackToInventory(new ItemStack(Items.WATER_BUCKET))) {
                        I[20 ^ 52].length();
                        I[145 ^ 176].length();
                        var4.dropItem(new ItemStack(Items.WATER_BUCKET), (boolean)"".length());
                        I[59 ^ 25].length();
                        I[124 ^ 95].length();
                        I[117 ^ 81].length();
                        I[104 ^ 77].length();
                        I[134 ^ 160].length();
                     }
                  }
               }

               var4.addStat(StatList.CAULDRON_USED);
               this.setWaterLevel(var1, var2, var3, "".length());
               var1.playSound((EntityPlayer)null, var2, SoundEvents.ITEM_BUCKET_FILL, SoundCategory.BLOCKS, 1.0F, 1.0F);
            }

            return (boolean)" ".length();
         } else {
            ItemStack var14;
            int var10005;
            if (var12 == Items.GLASS_BOTTLE) {
               if (var11 > 0 && !var1.isRemote) {
                  if (!var4.capabilities.isCreativeMode) {
                     I[82 ^ 117].length();
                     I[90 ^ 114].length();
                     var14 = PotionUtils.addPotionToItemStack(new ItemStack(Items.POTIONITEM), PotionTypes.WATER);
                     var4.addStat(StatList.CAULDRON_USED);
                     var10.func_190918_g(" ".length());
                     if (var10.isEmpty()) {
                        var4.setHeldItem(var5, var14);
                        "".length();
                        if (1 < 0) {
                           throw null;
                        }
                     } else if (!var4.inventory.addItemStackToInventory(var14)) {
                        var4.dropItem(var14, (boolean)"".length());
                        I[131 ^ 170].length();
                        I[180 ^ 158].length();
                        I[33 ^ 10].length();
                        "".length();
                        if (0 >= 4) {
                           throw null;
                        }
                     } else if (var4 instanceof EntityPlayerMP) {
                        ((EntityPlayerMP)var4).sendContainerToPlayer(var4.inventoryContainer);
                     }
                  }

                  var1.playSound((EntityPlayer)null, var2, SoundEvents.ITEM_BOTTLE_FILL, SoundCategory.BLOCKS, 1.0F, 1.0F);
                  var10005 = " ".length();
                  I[107 ^ 71].length();
                  I[116 ^ 89].length();
                  I[232 ^ 198].length();
                  this.setWaterLevel(var1, var2, var3, var11 - var10005);
               }

               return (boolean)" ".length();
            } else if (var12 == Items.POTIONITEM && PotionUtils.getPotionFromItem(var10) == PotionTypes.WATER) {
               if (var11 < "   ".length() && !var1.isRemote) {
                  if (!var4.capabilities.isCreativeMode) {
                     I[93 ^ 114].length();
                     I[243 ^ 195].length();
                     I[164 ^ 149].length();
                     I[10 ^ 56].length();
                     I[105 ^ 90].length();
                     var14 = new ItemStack(Items.GLASS_BOTTLE);
                     var4.addStat(StatList.CAULDRON_USED);
                     var4.setHeldItem(var5, var14);
                     if (var4 instanceof EntityPlayerMP) {
                        ((EntityPlayerMP)var4).sendContainerToPlayer(var4.inventoryContainer);
                     }
                  }

                  var1.playSound((EntityPlayer)null, var2, SoundEvents.field_191241_J, SoundCategory.BLOCKS, 1.0F, 1.0F);
                  this.setWaterLevel(var1, var2, var3, var11 + " ".length());
               }

               return (boolean)" ".length();
            } else {
               if (var11 > 0 && var12 instanceof ItemArmor) {
                  ItemArmor var13 = (ItemArmor)var12;
                  if (var13.getArmorMaterial() == ItemArmor.ArmorMaterial.LEATHER && var13.hasColor(var10) && !var1.isRemote) {
                     var13.removeColor(var10);
                     var10005 = " ".length();
                     I[41 ^ 29].length();
                     I[1 ^ 52].length();
                     I[38 ^ 16].length();
                     this.setWaterLevel(var1, var2, var3, var11 - var10005);
                     var4.addStat(StatList.ARMOR_CLEANED);
                     return (boolean)" ".length();
                  }
               }

               if (var11 > 0 && var12 instanceof ItemBanner) {
                  if (TileEntityBanner.getPatterns(var10) > 0 && !var1.isRemote) {
                     var14 = var10.copy();
                     var14.func_190920_e(" ".length());
                     TileEntityBanner.removeBannerData(var14);
                     var4.addStat(StatList.BANNER_CLEANED);
                     if (!var4.capabilities.isCreativeMode) {
                        var10.func_190918_g(" ".length());
                        var10005 = " ".length();
                        I[41 ^ 30].length();
                        I[48 ^ 8].length();
                        this.setWaterLevel(var1, var2, var3, var11 - var10005);
                     }

                     if (var10.isEmpty()) {
                        var4.setHeldItem(var5, var14);
                        "".length();
                        if (2 <= -1) {
                           throw null;
                        }
                     } else if (!var4.inventory.addItemStackToInventory(var14)) {
                        var4.dropItem(var14, (boolean)"".length());
                        I[57 ^ 0].length();
                        I[8 ^ 50].length();
                        I[86 ^ 109].length();
                        "".length();
                        if (3 < 0) {
                           throw null;
                        }
                     } else if (var4 instanceof EntityPlayerMP) {
                        ((EntityPlayerMP)var4).sendContainerToPlayer(var4.inventoryContainer);
                     }
                  }

                  return (boolean)" ".length();
               } else {
                  return (boolean)"".length();
               }
            }
         }
      }
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[119 ^ 48];
      String var10001 = I[3 ^ 75];
      String var10002 = I[28 ^ 85];
      var10001 = I[25 ^ 83];
      var10000 = I[112 ^ 59];
      var10001 = I[230 ^ 170];
      var10002 = I[218 ^ 151];
      var10001 = I[59 ^ 117];
      I[192 ^ 143].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[244 ^ 164].length();
      var10003["".length()] = LEVEL;
      return new BlockStateContainer(this, var10003);
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(LEVEL);
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      return (Integer)var1.getValue(LEVEL);
   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      int var5 = (Integer)var3.getValue(LEVEL);
      float var6 = (float)var2.getY() + (6.0F + (float)("   ".length() * var5)) / 16.0F;
      if (!var1.isRemote && var4.isBurning() && var5 > 0 && var4.getEntityBoundingBox().minY <= (double)var6) {
         var4.extinguish();
         int var10005 = " ".length();
         I["".length()].length();
         I[" ".length()].length();
         this.setWaterLevel(var1, var2, var3, var5 - var10005);
      }

   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[196 ^ 132];
      String var10001 = I[214 ^ 151];
      String var10002 = I[88 ^ 26];
      var10001 = I[117 ^ 54];
      I[105 ^ 45].length();
      I[22 ^ 83].length();
      I[204 ^ 138].length();
      return new ItemStack(Items.CAULDRON);
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      addCollisionBoxToList(var3, var4, var5, AABB_LEGS);
      addCollisionBoxToList(var3, var4, var5, AABB_WALL_WEST);
      addCollisionBoxToList(var3, var4, var5, AABB_WALL_NORTH);
      addCollisionBoxToList(var3, var4, var5, AABB_WALL_EAST);
      addCollisionBoxToList(var3, var4, var5, AABB_WALL_SOUTH);
   }
}

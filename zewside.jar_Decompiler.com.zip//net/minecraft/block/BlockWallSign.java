package net.minecraft.block;

import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockWallSign extends BlockSign {
   // $FF: synthetic field
   protected static final AxisAlignedBB SIGN_SOUTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB SIGN_NORTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB SIGN_WEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB SIGN_EAST_AABB;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   private static final String[] I;

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      EnumFacing var6 = (EnumFacing)var1.getValue(FACING);
      if (!var2.getBlockState(var3.offset(var6.getOpposite())).getMaterial().isSolid()) {
         this.dropBlockAsItem(var2, var3, var1, "".length());
         var2.setBlockToAir(var3);
         I["".length()].length();
      }

      super.neighborChanged(var1, var2, var3, var4, var5);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 3);

      throw null;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[115 ^ 119];
      var10000 = I[88 ^ 93];
      var10001 = I[23 ^ 17];
      var10002 = I[2 ^ 5];
      var10001 = I[48 ^ 56];
      I[41 ^ 32].length();
      I[131 ^ 137].length();
      I[11 ^ 0].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[81 ^ 93].length();
      I[20 ^ 25].length();
      I[147 ^ 157].length();
      var10003["".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      SIGN_EAST_AABB = new AxisAlignedBB(0.0D, 0.28125D, 0.0D, 0.125D, 0.78125D, 1.0D);
      SIGN_WEST_AABB = new AxisAlignedBB(0.875D, 0.28125D, 0.0D, 1.0D, 0.78125D, 1.0D);
      SIGN_SOUTH_AABB = new AxisAlignedBB(0.0D, 0.28125D, 0.0D, 1.0D, 0.78125D, 0.125D);
      SIGN_NORTH_AABB = new AxisAlignedBB(0.0D, 0.28125D, 0.875D, 1.0D, 0.78125D, 1.0D);
   }

   public BlockWallSign() {
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumFacing)var1.getValue(FACING)).getIndex();
   }

   private static void I() {
      I = new String[99 ^ 108];
      I["".length()] = I("憄伕啮", "LlDYp");
      I[" ".length()] = I("晹材", "EOAvJ");
      I["  ".length()] = I("呺嫈", "DcdmK");
      I["   ".length()] = I("滶她", "SZDdV");
      I[18 ^ 22] = I("楔杆", "ApAce");
      I[163 ^ 166] = I("峨嗛", "POeKK");
      I[125 ^ 123] = I("渟楡", "ytKpz");
      I[123 ^ 124] = I("沖尟", "FUzwe");
      I[206 ^ 198] = I("涫沸", "LBVOB");
      I[84 ^ 93] = I("淇", "laJha");
      I[45 ^ 39] = I("徝滥枃巋", "uTwPZ");
      I[77 ^ 70] = I("廠巣勳", "RRKmw");
      I[55 ^ 59] = I("嬿拫濥姇孅", "vRtng");
      I[190 ^ 179] = I("將塄徳复两", "rlJjV");
      I[40 ^ 38] = I("干権摉棰沼", "eCaRZ");
   }

   public IBlockState getStateFromMeta(int var1) {
      EnumFacing var2 = EnumFacing.getFront(var1);
      if (var2.getAxis() == EnumFacing.Axis.Y) {
         var2 = EnumFacing.NORTH;
      }

      return this.getDefaultState().withProperty(FACING, var2);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
      default:
         return SIGN_NORTH_AABB;
      case 2:
         return SIGN_SOUTH_AABB;
      case 3:
         return SIGN_WEST_AABB;
      case 4:
         return SIGN_EAST_AABB;
      }
   }
}

package net.minecraft.block;

import com.google.common.base.Predicates;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.block.state.pattern.BlockStateMatcher;
import net.minecraft.block.state.pattern.FactoryBlockPattern;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockEndPortalFrame extends Block {
   // $FF: synthetic field
   private static BlockPattern portalShape;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool EYE;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_BLOCK;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_EYE;

   private static void I() {
      I = new String[88 ^ 96];
      I["".length()] = I("桤捫", "SRJyy");
      I[" ".length()] = I("卺椐", "xlsgx");
      I["  ".length()] = I("急怯", "bMpUf");
      I["   ".length()] = I("噽拿", "CAUXr");
      I[85 ^ 81] = I("嫆晘", "wcRgF");
      I[3 ^ 6] = I("搕媵", "iCabq");
      I[121 ^ 127] = I("坝棎", "SEpCB");
      I[67 ^ 68] = I("曖攧", "WVEBf");
      I[59 ^ 51] = I("毒樠", "JNDsD");
      I[143 ^ 134] = I("帗栁", "QMICH");
      I[168 ^ 162] = I("洪愼", "AHYNy");
      I[2 ^ 9] = I("楓媸", "xAauf");
      I[183 ^ 187] = I("婡嵝宨岦", "ZYNrq");
      I[144 ^ 157] = I("櫁挰", "PQOKA");
      I[128 ^ 142] = I("愝懦圹櫛", "osIeO");
      I[35 ^ 44] = I("毛", "kHPRJ");
      I[114 ^ 98] = I("慟恂洮嶔炁", "LHlsT");
      I[23 ^ 6] = I("权歔楯怱", "LnvQF");
      I[57 ^ 43] = I("哖愁煰嘓", "xrUih");
      I[37 ^ 54] = I("懈帵", "MZchK");
      I[54 ^ 34] = I("剩嚰", "ZzJgp");
      I[51 ^ 38] = I("佈嚍", "wkMea");
      I[34 ^ 52] = I("暦僩", "GtktL");
      I[73 ^ 94] = I("崧嗮", "rTYai");
      I[19 ^ 11] = I("崊枂", "sOdGc");
      I[180 ^ 173] = I("乨漟", "RIhlQ");
      I[47 ^ 53] = I("啌唡", "ZWVoG");
      I[20 ^ 15] = I("喬勇", "CpqKS");
      I[109 ^ 113] = I("炨兓", "cvvhM");
      I[36 ^ 57] = I("侢恉", "JawKG");
      I[170 ^ 180] = I("彨橪", "iNsmy");
      I[187 ^ 164] = I("冥刜", "MVuJg");
      I[14 ^ 46] = I("奛槊", "asTuQ");
      I[24 ^ 57] = I("櫮崟", "PqXbZ");
      I[52 ^ 22] = I("剡匵", "IFEAk");
      I[92 ^ 127] = I("仲医", "tzmJg");
      I[180 ^ 144] = I("沈暃", "cbOAl");
      I[2 ^ 39] = I("毼憖", "dJgGU");
      I[9 ^ 47] = I("搆摅", "nRYMM");
      I[190 ^ 153] = I("乬", "BsQEC");
      I[14 ^ 38] = I("杂攤掁", "LJllr");
      I[46 ^ 7] = I("屺廾侜庿", "wVThx");
      I[166 ^ 140] = I("K$\u001c\u0002P", "tRjto");
      I[232 ^ 195] = I("呵灂朤墟", "TOHVs");
      I[152 ^ 180] = I("咅决", "cDALj");
      I[89 ^ 116] = I("X{uZy", "fDJeE");
      I[127 ^ 81] = I("拉丱潢", "GLKZq");
      I[35 ^ 12] = I("摒墯匽傏槽", "NVzfd");
      I[33 ^ 17] = I("TJysr", "juFLN");
      I[83 ^ 98] = I("峔櫝撑嗧", "XrXDj");
      I[104 ^ 90] = I("昀尢峗依", "LLLLO");
      I[72 ^ 123] = I("yXVqK", "GgiNw");
      I[181 ^ 129] = I("溅哊俘歘愢", "OxrLi");
      I[155 ^ 174] = I("扴慸恠朑", "KePmx");
      I[94 ^ 104] = I("~\u001a\u0007\u0007p", "ADYYO");
      I[35 ^ 20] = I("\n-3", "oTVTw");
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      int var10000;
      if ((Boolean)var1.getValue(EYE)) {
         var10000 = 205 ^ 194;
         "".length();
         if (3 == 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   public BlockEndPortalFrame() {
      super(Material.ROCK, MapColor.GREEN);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(EYE, Boolean.valueOf((boolean)"".length())));
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      EYE = PropertyBool.create(I[175 ^ 152]);
      AABB_BLOCK = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.8125D, 1.0D);
      AABB_EYE = new AxisAlignedBB(0.3125D, 0.8125D, 0.3125D, 0.6875D, 1.0D, 0.6875D);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 1);

      throw null;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[123 ^ 127];
      var10001 = I[15 ^ 10];
      var10002 = I[179 ^ 181];
      var10001 = I[158 ^ 153];
      var10000 = I[146 ^ 154];
      var10001 = I[46 ^ 39];
      var10002 = I[160 ^ 170];
      var10001 = I[19 ^ 24];
      I[106 ^ 102].length();
      I[108 ^ 97].length();
      I[76 ^ 66].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[93 ^ 82].length();
      I[60 ^ 44].length();
      var10003["".length()] = FACING;
      I[83 ^ 66].length();
      I[148 ^ 134].length();
      var10003[" ".length()] = EYE;
      return new BlockStateContainer(this, var10003);
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.field_190931_a;
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState();
      PropertyBool var10001 = EYE;
      int var10002;
      if ((var1 & (104 ^ 108)) != 0) {
         var10002 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002)).withProperty(FACING, EnumFacing.byHorizontalIndex(var1 & "   ".length()));
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = BlockFaceShape.SOLID;
         "".length();
         if (2 >= 3) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, var8.getHorizontalFacing().getOpposite()).withProperty(EYE, Boolean.valueOf((boolean)"".length()));
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      addCollisionBoxToList(var3, var4, var5, AABB_BLOCK);
      if ((Boolean)var2.getBlockState(var3).getValue(EYE)) {
         addCollisionBoxToList(var3, var4, var5, AABB_EYE);
      }

   }

   public static BlockPattern getOrCreatePortalShape() {
      String var10000 = I[99 ^ 112];
      String var10001 = I[53 ^ 33];
      String var10002 = I[92 ^ 73];
      var10001 = I[208 ^ 198];
      var10000 = I[168 ^ 191];
      var10001 = I[16 ^ 8];
      var10002 = I[163 ^ 186];
      var10001 = I[170 ^ 176];
      var10000 = I[72 ^ 83];
      var10001 = I[124 ^ 96];
      var10002 = I[63 ^ 34];
      var10001 = I[176 ^ 174];
      var10000 = I[220 ^ 195];
      var10001 = I[44 ^ 12];
      var10002 = I[144 ^ 177];
      var10001 = I[136 ^ 170];
      var10000 = I[142 ^ 173];
      var10001 = I[41 ^ 13];
      var10002 = I[37 ^ 0];
      var10001 = I[87 ^ 113];
      if (portalShape == null) {
         FactoryBlockPattern var0 = FactoryBlockPattern.start();
         String[] var1 = new String[95 ^ 90];
         I[70 ^ 97].length();
         I[90 ^ 114].length();
         I[75 ^ 98].length();
         var1["".length()] = I[46 ^ 4];
         I[46 ^ 5].length();
         I[67 ^ 111].length();
         var1[" ".length()] = I[55 ^ 26];
         I[114 ^ 92].length();
         I[16 ^ 63].length();
         var1["  ".length()] = I[123 ^ 75];
         I[44 ^ 29].length();
         I[107 ^ 89].length();
         var1["   ".length()] = I[154 ^ 169];
         I[186 ^ 142].length();
         I[63 ^ 10].length();
         var1[110 ^ 106] = I[4 ^ 50];
         portalShape = var0.aisle(var1).where((char)(';' ^ '\u0004'), BlockWorldState.hasState(BlockStateMatcher.ANY)).where((char)('U' ^ '\u000b'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.END_PORTAL_FRAME).where(EYE, Predicates.equalTo(Boolean.valueOf((boolean)" ".length()))).where(FACING, Predicates.equalTo(EnumFacing.SOUTH)))).where((char)('3' ^ '\r'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.END_PORTAL_FRAME).where(EYE, Predicates.equalTo(Boolean.valueOf((boolean)" ".length()))).where(FACING, Predicates.equalTo(EnumFacing.WEST)))).where((char)('Ù' ^ '¯'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.END_PORTAL_FRAME).where(EYE, Predicates.equalTo(Boolean.valueOf((boolean)" ".length()))).where(FACING, Predicates.equalTo(EnumFacing.NORTH)))).where((char)('p' ^ 'L'), BlockWorldState.hasState(BlockStateMatcher.forBlock(Blocks.END_PORTAL_FRAME).where(EYE, Predicates.equalTo(Boolean.valueOf((boolean)" ".length()))).where(FACING, Predicates.equalTo(EnumFacing.EAST)))).build();
      }

      return portalShape;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
      if ((Boolean)var1.getValue(EYE)) {
         var2 |= 44 ^ 40;
      }

      return var2;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return AABB_BLOCK;
   }
}

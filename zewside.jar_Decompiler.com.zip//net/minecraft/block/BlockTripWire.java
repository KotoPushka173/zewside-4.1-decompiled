package net.minecraft.block;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockTripWire extends Block {
   // $FF: synthetic field
   public static final PropertyBool NORTH;
   // $FF: synthetic field
   public static final PropertyBool DISARMED;
   // $FF: synthetic field
   public static final PropertyBool WEST;
   // $FF: synthetic field
   public static final PropertyBool SOUTH;
   // $FF: synthetic field
   public static final PropertyBool ATTACHED;
   // $FF: synthetic field
   protected static final AxisAlignedBB TRIP_WRITE_ATTACHED_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB;
   // $FF: synthetic field
   public static final PropertyBool POWERED;
   // $FF: synthetic field
   public static final PropertyBool EAST;
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
      POWERED = PropertyBool.create(I[49 ^ 98]);
      ATTACHED = PropertyBool.create(I[197 ^ 145]);
      DISARMED = PropertyBool.create(I[117 ^ 32]);
      NORTH = PropertyBool.create(I[229 ^ 179]);
      EAST = PropertyBool.create(I[38 ^ 113]);
      SOUTH = PropertyBool.create(I[9 ^ 81]);
      WEST = PropertyBool.create(I[112 ^ 41]);
      AABB = new AxisAlignedBB(0.0D, 0.0625D, 0.0D, 1.0D, 0.15625D, 1.0D);
      TRIP_WRITE_ATTACHED_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
   }

   public static boolean isConnectedTo(IBlockAccess var0, BlockPos var1, IBlockState var2, EnumFacing var3) {
      BlockPos var4 = var1.offset(var3);
      IBlockState var5 = var0.getBlockState(var4);
      Block var6 = var5.getBlock();
      int var10000;
      if (var6 == Blocks.TRIPWIRE_HOOK) {
         EnumFacing var7 = var3.getOpposite();
         if (var5.getValue(BlockTripWireHook.FACING) == var7) {
            var10000 = " ".length();
            "".length();
            if (4 < 1) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      } else {
         if (var6 == Blocks.TRIPWIRE) {
            var10000 = " ".length();
            "".length();
            if (1 <= 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.TRANSLUCENT;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      if ((Boolean)var1.getValue(POWERED)) {
         var2 |= " ".length();
      }

      if ((Boolean)var1.getValue(ATTACHED)) {
         var2 |= 128 ^ 132;
      }

      if ((Boolean)var1.getValue(DISARMED)) {
         var2 |= 144 ^ 152;
      }

      return var2;
   }

   private static void I() {
      I = new String[237 ^ 183];
      I["".length()] = I("柟柒", "iESsO");
      I[" ".length()] = I("勭澸", "wePuI");
      I["  ".length()] = I("殃嫓", "rxIuN");
      I["   ".length()] = I("瀸啜", "ANjHN");
      I[127 ^ 123] = I("煚澼", "tOcuq");
      I[93 ^ 88] = I("徖", "Vibnl");
      I[156 ^ 154] = I("儡", "VbcnU");
      I[116 ^ 115] = I("倕抒焾揞", "TVyZj");
      I[206 ^ 198] = I("拥噭", "Rzfyp");
      I[172 ^ 165] = I("吰扽漃", "riVuy");
      I[163 ^ 169] = I("歉媻", "ygMQY");
      I[126 ^ 117] = I("寡幜", "ARmZN");
      I[17 ^ 29] = I("伶叕", "XTBDh");
      I[115 ^ 126] = I("桿湊", "zhwxW");
      I[134 ^ 136] = I("拍匆", "KNieT");
      I[74 ^ 69] = I("嶋忕", "CRXlB");
      I[69 ^ 85] = I("机剣", "YsWDm");
      I[115 ^ 98] = I("弑叻", "Luezj");
      I[28 ^ 14] = I("坣喝烻怽", "jOvOt");
      I[30 ^ 13] = I("澄忟俿", "fxlZR");
      I[46 ^ 58] = I("柨渔核僗夈", "aAgPQ");
      I[75 ^ 94] = I("媪契奏暯", "KDvXG");
      I[182 ^ 160] = I("摉咒", "rKPOO");
      I[186 ^ 173] = I("倭憨", "EvBdi");
      I[8 ^ 16] = I("尭曓", "VAaAf");
      I[97 ^ 120] = I("晎嫹", "eBDTQ");
      I[55 ^ 45] = I("巶", "sAtET");
      I[83 ^ 72] = I("杙哋擏", "zxlyO");
      I[33 ^ 61] = I("槨汦恽庍", "uYDaS");
      I[54 ^ 43] = I("埶兗斐", "zcsoI");
      I[169 ^ 183] = I("报忊毐垮峑", "qbGCP");
      I[0 ^ 31] = I("滚嬲", "lfzGw");
      I[179 ^ 147] = I("椂儅", "Epebk");
      I[190 ^ 159] = I("壁卽", "Kgpev");
      I[78 ^ 108] = I("帺壸", "KTAZN");
      I[51 ^ 16] = I("崖単", "dGgvj");
      I[224 ^ 196] = I("惛湒", "kSkCs");
      I[185 ^ 156] = I("懼幔", "tWXYN");
      I[10 ^ 44] = I("榗採", "PVwHq");
      I[148 ^ 179] = I("嗂俓", "OpGbT");
      I[110 ^ 70] = I("煹戡", "rrhhM");
      I[74 ^ 99] = I("屲曊", "CONOF");
      I[4 ^ 46] = I("慨毶", "CtiNI");
      I[115 ^ 88] = I("摮搅", "REEPY");
      I[42 ^ 6] = I("曡娇", "dEMCj");
      I[92 ^ 113] = I("溓勪", "beDXU");
      I[125 ^ 83] = I("榆岪", "evfix");
      I[71 ^ 104] = I("杨峬", "uvthU");
      I[64 ^ 112] = I("滱儬", "jBvxM");
      I[128 ^ 177] = I("瀕伿", "vobVH");
      I[46 ^ 28] = I("攋姐", "tkVwm");
      I[157 ^ 174] = I("洕妔", "AAskM");
      I[104 ^ 92] = I("嬂本", "mMIUj");
      I[56 ^ 13] = I("欇毟", "sMoXP");
      I[88 ^ 110] = I("啐揷", "TlJtc");
      I[101 ^ 82] = I("宜涎", "MuSDE");
      I[29 ^ 37] = I("囦朏", "tbmpH");
      I[8 ^ 49] = I("歷噶", "ZJVnP");
      I[113 ^ 75] = I("桾崓", "VOCmi");
      I[41 ^ 18] = I("崪埿", "XmrDw");
      I[120 ^ 68] = I("桍岬", "iArBU");
      I[73 ^ 116] = I("嗝壖", "sayGw");
      I[3 ^ 61] = I("湍摏", "mtxAB");
      I[34 ^ 29] = I("嘇樻偃", "VoUjg");
      I[49 ^ 113] = I("斈剱壌", "GHFJP");
      I[10 ^ 75] = I("愎拙", "GSbxK");
      I[254 ^ 188] = I("兯昙堯", "KRfYd");
      I[5 ^ 70] = I("升", "eLOJD");
      I[13 ^ 73] = I("冰櫶朽", "xLEZc");
      I[241 ^ 180] = I("旴弻彡捿", "lJRVz");
      I[49 ^ 119] = I("樺", "KKDVR");
      I[78 ^ 9] = I("居湎", "pWAog");
      I[75 ^ 3] = I("嗒弍攭情烗", "oHNRm");
      I[85 ^ 28] = I("仵嚽晊侜", "seGLs");
      I[109 ^ 39] = I("淔搎斎桧亢", "FPsuu");
      I[78 ^ 5] = I("姴埁", "IIXwh");
      I[16 ^ 92] = I("奓凷", "XjmYy");
      I[240 ^ 189] = I("宧扷徢", "djdis");
      I[72 ^ 6] = I("傲歛佐", "eaLSo");
      I[241 ^ 190] = I("偑", "uHCZJ");
      I[122 ^ 42] = I("扮峀", "Xuexm");
      I[1 ^ 80] = I("巰块", "kbOqh");
      I[205 ^ 159] = I("壶彍", "Qxsgq");
      I[54 ^ 101] = I("\u0012\u001f4-\u0003\u0007\u0014", "bpCHq");
      I[122 ^ 46] = I("\b#\u0019\f\u0013\u00012\t", "iWmmp");
      I[14 ^ 91] = I("--\u0017\u0010*$!\u0000", "IDdqX");
      I[113 ^ 39] = I("6\u0003(8%", "XlZLM");
      I[16 ^ 71] = I(".*\u0001\u000e", "KKrzQ");
      I[58 ^ 98] = I("\u001f\u0000\u00185\u0011", "lomAy");
      I[246 ^ 175] = I("'\u0014\u0001\u0001", "Pqruk");
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      this.notifyHook(var1, var2, var3.withProperty(POWERED, Boolean.valueOf((boolean)" ".length())));
   }

   public BlockTripWire() {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(POWERED, Boolean.valueOf((boolean)"".length())).withProperty(ATTACHED, Boolean.valueOf((boolean)"".length())).withProperty(DISARMED, Boolean.valueOf((boolean)"".length())).withProperty(NORTH, Boolean.valueOf((boolean)"".length())).withProperty(EAST, Boolean.valueOf((boolean)"".length())).withProperty(SOUTH, Boolean.valueOf((boolean)"".length())).withProperty(WEST, Boolean.valueOf((boolean)"".length())));
      this.setTickRandomly((boolean)" ".length());
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(EAST, var1.getValue(WEST)).withProperty(SOUTH, var1.getValue(NORTH)).withProperty(WEST, var1.getValue(EAST));
      case 2:
         return var1.withProperty(NORTH, var1.getValue(EAST)).withProperty(EAST, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(WEST)).withProperty(WEST, var1.getValue(NORTH));
      case 3:
         return var1.withProperty(NORTH, var1.getValue(WEST)).withProperty(EAST, var1.getValue(NORTH)).withProperty(SOUTH, var1.getValue(EAST)).withProperty(WEST, var1.getValue(SOUTH));
      default:
         return var1;
      }
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote && (Boolean)var1.getBlockState(var2).getValue(POWERED)) {
         this.updateState(var1, var2);
      }

   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.STRING;
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      var1.setBlockState(var2, var3, "   ".length());
      I[116 ^ 113].length();
      I[126 ^ 120].length();
      this.notifyHook(var1, var2, var3);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(NORTH));
      case 2:
         return var1.withProperty(EAST, var1.getValue(WEST)).withProperty(WEST, var1.getValue(EAST));
      default:
         return super.withMirror(var1, var2);
      }
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > -1);

      throw null;
   }

   private void notifyHook(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[123 ^ 113];
      String var10001 = I[43 ^ 32];
      String var10002 = I[173 ^ 161];
      var10001 = I[42 ^ 39];
      var10000 = I[87 ^ 89];
      var10001 = I[51 ^ 60];
      var10002 = I[162 ^ 178];
      var10001 = I[20 ^ 5];
      EnumFacing[] var11 = new EnumFacing["  ".length()];
      I[179 ^ 161].length();
      I[212 ^ 199].length();
      I[89 ^ 77].length();
      var11["".length()] = EnumFacing.SOUTH;
      I[154 ^ 143].length();
      var11[" ".length()] = EnumFacing.WEST;
      EnumFacing[] var4 = var11;
      int var5 = var4.length;
      int var6 = "".length();

      do {
         if (var6 >= var5) {
            return;
         }

         EnumFacing var7 = var4[var6];
         int var8 = " ".length();

         while(var8 < (153 ^ 179)) {
            BlockPos var9 = var2.offset(var7, var8);
            IBlockState var10 = var1.getBlockState(var9);
            if (var10.getBlock() == Blocks.TRIPWIRE_HOOK) {
               if (var10.getValue(BlockTripWireHook.FACING) == var7.getOpposite()) {
                  Blocks.TRIPWIRE_HOOK.calculateState(var1, var9, var10, (boolean)"".length(), (boolean)" ".length(), var8, var3);
                  "".length();
                  if (3 <= -1) {
                     throw null;
                  }
               }
               break;
            }

            if (var10.getBlock() != Blocks.TRIPWIRE) {
               "".length();
               if (4 == 2) {
                  throw null;
               }
               break;
            }

            ++var8;
            "".length();
            if (4 < 4) {
               throw null;
            }
         }

         ++var6;
         "".length();
      } while(0 >= 0);

      throw null;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[47 ^ 43].length();
      return new ItemStack(Items.STRING);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      AxisAlignedBB var10000;
      if (!(Boolean)var1.getValue(ATTACHED)) {
         var10000 = TRIP_WRITE_ATTACHED_AABB;
         "".length();
         if (1 >= 3) {
            throw null;
         }
      } else {
         var10000 = AABB;
      }

      return var10000;
   }

   public void onBlockHarvested(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      if (!var1.isRemote && !var4.getHeldItemMainhand().isEmpty() && var4.getHeldItemMainhand().getItem() == Items.SHEARS) {
         var1.setBlockState(var2, var3.withProperty(DISARMED, Boolean.valueOf((boolean)" ".length())), 87 ^ 83);
         I[91 ^ 92].length();
         I[161 ^ 169].length();
         I[61 ^ 52].length();
      }

   }

   private void updateState(World var1, BlockPos var2) {
      String var10000 = I[42 ^ 60];
      String var10001 = I[11 ^ 28];
      String var10002 = I[74 ^ 82];
      var10001 = I[98 ^ 123];
      IBlockState var3 = var1.getBlockState(var2);
      byte var4 = (Boolean)var3.getValue(POWERED);
      int var5 = "".length();
      List var6 = var1.getEntitiesWithinAABBExcludingEntity((Entity)null, var3.getBoundingBox(var1, var2).offset(var2));
      if (!var6.isEmpty()) {
         Iterator var7 = var6.iterator();

         while(var7.hasNext()) {
            Entity var8 = (Entity)var7.next();
            if (!var8.doesEntityNotTriggerPressurePlate()) {
               var5 = " ".length();
               "".length();
               if (2 >= 4) {
                  throw null;
               }
               break;
            }

            "".length();
            if (2 >= 3) {
               throw null;
            }
         }
      }

      if (var5 != var4) {
         var3 = var3.withProperty(POWERED, Boolean.valueOf((boolean)var5));
         var1.setBlockState(var2, var3, "   ".length());
         I[140 ^ 150].length();
         I[66 ^ 89].length();
         this.notifyHook(var1, var2, var3);
      }

      if (var5 != 0) {
         I[24 ^ 4].length();
         I[58 ^ 39].length();
         I[22 ^ 8].length();
         var1.scheduleUpdate(new BlockPos(var2), this, this.tickRate(var1));
      }

   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      if (!var1.isRemote && !(Boolean)var3.getValue(POWERED)) {
         this.updateState(var1, var2);
      }

   }

   public void randomTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState();
      PropertyBool var10001 = POWERED;
      int var10002;
      if ((var1 & " ".length()) > 0) {
         var10002 = " ".length();
         "".length();
         if (1 < 1) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = ATTACHED;
      if ((var1 & (167 ^ 163)) > 0) {
         var10002 = " ".length();
         "".length();
         if (-1 >= 0) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = DISARMED;
      if ((var1 & (69 ^ 77)) > 0) {
         var10002 = " ".length();
         "".length();
         if (3 <= -1) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[77 ^ 82];
      String var10001 = I[70 ^ 102];
      String var10002 = I[44 ^ 13];
      var10001 = I[109 ^ 79];
      var10000 = I[27 ^ 56];
      var10001 = I[126 ^ 90];
      var10002 = I[130 ^ 167];
      var10001 = I[39 ^ 1];
      var10000 = I[48 ^ 23];
      var10001 = I[61 ^ 21];
      var10002 = I[129 ^ 168];
      var10001 = I[105 ^ 67];
      var10000 = I[186 ^ 145];
      var10001 = I[24 ^ 52];
      var10002 = I[184 ^ 149];
      var10001 = I[123 ^ 85];
      var10000 = I[84 ^ 123];
      var10001 = I[67 ^ 115];
      var10002 = I[163 ^ 146];
      var10001 = I[124 ^ 78];
      var10000 = I[24 ^ 43];
      var10001 = I[153 ^ 173];
      var10002 = I[40 ^ 29];
      var10001 = I[184 ^ 142];
      var10000 = I[127 ^ 72];
      var10001 = I[43 ^ 19];
      var10002 = I[37 ^ 28];
      var10001 = I[7 ^ 61];
      var10000 = I[139 ^ 176];
      var10001 = I[144 ^ 172];
      var10002 = I[89 ^ 100];
      var10001 = I[147 ^ 173];
      I[187 ^ 132].length();
      IProperty[] var10003 = new IProperty[178 ^ 181];
      I[123 ^ 59].length();
      I[239 ^ 174].length();
      I[50 ^ 112].length();
      var10003["".length()] = POWERED;
      I[125 ^ 62].length();
      I[129 ^ 197].length();
      I[59 ^ 126].length();
      var10003[" ".length()] = ATTACHED;
      I[97 ^ 39].length();
      I[254 ^ 185].length();
      I[107 ^ 35].length();
      var10003["  ".length()] = DISARMED;
      I[19 ^ 90].length();
      I[238 ^ 164].length();
      var10003["   ".length()] = NORTH;
      I[204 ^ 135].length();
      I[55 ^ 123].length();
      I[115 ^ 62].length();
      I[37 ^ 107].length();
      var10003[149 ^ 145] = EAST;
      I[215 ^ 152].length();
      var10003[40 ^ 45] = WEST;
      I[13 ^ 93].length();
      I[145 ^ 192].length();
      I[243 ^ 161].length();
      var10003[112 ^ 118] = SOUTH;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return var1.withProperty(NORTH, isConnectedTo(var2, var3, var1, EnumFacing.NORTH)).withProperty(EAST, isConnectedTo(var2, var3, var1, EnumFacing.EAST)).withProperty(SOUTH, isConnectedTo(var2, var3, var1, EnumFacing.SOUTH)).withProperty(WEST, isConnectedTo(var2, var3, var1, EnumFacing.WEST));
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }
}

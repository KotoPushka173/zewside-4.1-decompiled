package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketHeldItemChange implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int slotId;

   public int getSlotId() {
      return this.slotId;
   }

   public CPacketHeldItemChange() {
   }

   static {
      I();
   }

   public CPacketHeldItemChange(int var1) {
      this.slotId = var1;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeShort(this.slotId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("搞瀃朜卧", "DIzpj");
      I[" ".length()] = I("抅凮櫺兒嶩", "aubvK");
      I["  ".length()] = I("旳在侮勗", "NCuVe");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= -1);

      throw null;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processHeldItemChange(this);
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.slotId = var1.readShort();
   }
}

package net.minecraft.block.state;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockPistonStructureHelper {
   // $FF: synthetic field
   private final List<BlockPos> toDestroy = Lists.newArrayList();
   // $FF: synthetic field
   private final BlockPos pistonPos;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final BlockPos blockToMove;
   // $FF: synthetic field
   private final EnumFacing moveDirection;
   // $FF: synthetic field
   private final List<BlockPos> toMove = Lists.newArrayList();
   // $FF: synthetic field
   private final World world;

   public BlockPistonStructureHelper(World var1, BlockPos var2, EnumFacing var3, boolean var4) {
      this.world = var1;
      this.pistonPos = var2;
      if (var4) {
         this.moveDirection = var3;
         this.blockToMove = var2.offset(var3);
         "".length();
         if (-1 >= 4) {
            throw null;
         }
      } else {
         this.moveDirection = var3.getOpposite();
         this.blockToMove = var2.offset(var3, "  ".length());
      }

   }

   public boolean canMove() {
      this.toMove.clear();
      this.toDestroy.clear();
      IBlockState var1 = this.world.getBlockState(this.blockToMove);
      if (!BlockPistonBase.canPush(var1, this.world, this.blockToMove, this.moveDirection, (boolean)"".length(), this.moveDirection)) {
         if (var1.getMobilityFlag() == EnumPushReaction.DESTROY) {
            this.toDestroy.add(this.blockToMove);
            I["".length()].length();
            return (boolean)" ".length();
         } else {
            return (boolean)"".length();
         }
      } else if (!this.addBlockLine(this.blockToMove, this.moveDirection)) {
         return (boolean)"".length();
      } else {
         int var2 = "".length();

         do {
            if (var2 >= this.toMove.size()) {
               return (boolean)" ".length();
            }

            BlockPos var3 = (BlockPos)this.toMove.get(var2);
            if (this.world.getBlockState(var3).getBlock() == Blocks.SLIME_BLOCK && !this.addBranchingBlocks(var3)) {
               return (boolean)"".length();
            }

            ++var2;
            "".length();
         } while(true);

         throw null;
      }
   }

   private void reorderListAtCollision(int var1, int var2) {
      ArrayList var3 = Lists.newArrayList();
      ArrayList var4 = Lists.newArrayList();
      ArrayList var5 = Lists.newArrayList();
      var3.addAll(this.toMove.subList("".length(), var2));
      I[119 ^ 126].length();
      List var10001 = this.toMove;
      int var10002 = this.toMove.size();
      I[143 ^ 133].length();
      I[108 ^ 103].length();
      I[181 ^ 185].length();
      I[34 ^ 47].length();
      var4.addAll(var10001.subList(var10002 - var1, this.toMove.size()));
      I[116 ^ 122].length();
      var10001 = this.toMove;
      int var10003 = this.toMove.size();
      I[201 ^ 198].length();
      I[105 ^ 121].length();
      I[142 ^ 159].length();
      var5.addAll(var10001.subList(var2, var10003 - var1));
      I[11 ^ 25].length();
      I[141 ^ 158].length();
      I[108 ^ 120].length();
      this.toMove.clear();
      this.toMove.addAll(var3);
      I[78 ^ 91].length();
      this.toMove.addAll(var4);
      I[50 ^ 36].length();
      this.toMove.addAll(var5);
      I[33 ^ 54].length();
      I[111 ^ 119].length();
      I[99 ^ 122].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 3);

      throw null;
   }

   private boolean addBranchingBlocks(BlockPos var1) {
      EnumFacing[] var2 = EnumFacing.values();
      int var3 = var2.length;
      int var4 = "".length();

      do {
         if (var4 >= var3) {
            return (boolean)" ".length();
         }

         EnumFacing var5 = var2[var4];
         if (var5.getAxis() != this.moveDirection.getAxis() && !this.addBlockLine(var1.offset(var5), var5)) {
            return (boolean)"".length();
         }

         ++var4;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   private static void I() {
      I = new String[56 ^ 34];
      I["".length()] = I("嗱", "CvecN");
      I[" ".length()] = I("戙堔哮敲", "YXxRg");
      I["  ".length()] = I("奭曱", "wCNmO");
      I["   ".length()] = I("撶榸", "OECVa");
      I[24 ^ 28] = I("櫕歺", "rQBkP");
      I[154 ^ 159] = I("歲樓湾搃", "JenPe");
      I[95 ^ 89] = I("亱凄修刌", "ybHLs");
      I[59 ^ 60] = I("滁攽敛", "ZgOqi");
      I[98 ^ 106] = I("濴烂", "sdoFS");
      I[2 ^ 11] = I("必叏", "uMiLZ");
      I[105 ^ 99] = I("墐檡", "TEwcu");
      I[129 ^ 138] = I("殖渑咔塃", "HIsmp");
      I[159 ^ 147] = I("唈", "qASwo");
      I[85 ^ 88] = I("偅怠湦撉徝", "TSisC");
      I[154 ^ 148] = I("僘凿俋婅嵌", "eLUQR");
      I[148 ^ 155] = I("婠噉", "XpnoA");
      I[96 ^ 112] = I("厶埊", "MTLvw");
      I[57 ^ 40] = I("檡", "hCddT");
      I[138 ^ 152] = I("呜", "qYWoW");
      I[146 ^ 129] = I("將仌", "ADQVc");
      I[160 ^ 180] = I("戤潨噐", "WJKSv");
      I[131 ^ 150] = I("佐氟惉", "UQUzz");
      I[58 ^ 44] = I("敗敪棌挡", "BUxEO");
      I[172 ^ 187] = I("嫛勼惹弸塂", "bEoMK");
      I[104 ^ 112] = I("氃娹儇檀厛", "udUNz");
      I[173 ^ 180] = I("渃泖偙", "ZGJbV");
   }

   public List<BlockPos> getBlocksToDestroy() {
      return this.toDestroy;
   }

   public List<BlockPos> getBlocksToMove() {
      return this.toMove;
   }

   private boolean addBlockLine(BlockPos var1, EnumFacing var2) {
      IBlockState var3 = this.world.getBlockState(var1);
      Block var4 = var3.getBlock();
      if (var3.getMaterial() == Material.AIR) {
         return (boolean)" ".length();
      } else if (!BlockPistonBase.canPush(var3, this.world, var1, this.moveDirection, (boolean)"".length(), var2)) {
         return (boolean)" ".length();
      } else if (var1.equals(this.pistonPos)) {
         return (boolean)" ".length();
      } else if (this.toMove.contains(var1)) {
         return (boolean)" ".length();
      } else {
         int var5 = " ".length();
         if (var5 + this.toMove.size() > (129 ^ 141)) {
            return (boolean)"".length();
         } else {
            while(var4 == Blocks.SLIME_BLOCK) {
               BlockPos var6 = var1.offset(this.moveDirection.getOpposite(), var5);
               var3 = this.world.getBlockState(var6);
               var4 = var3.getBlock();
               if (var3.getMaterial() == Material.AIR || !BlockPistonBase.canPush(var3, this.world, var6, this.moveDirection, (boolean)"".length(), this.moveDirection.getOpposite())) {
                  break;
               }

               if (var6.equals(this.pistonPos)) {
                  "".length();
                  if (3 < 2) {
                     throw null;
                  }
                  break;
               }

               ++var5;
               if (var5 + this.toMove.size() > (87 ^ 91)) {
                  return (boolean)"".length();
               }

               "".length();
               if (0 >= 4) {
                  throw null;
               }
            }

            int var12 = "".length();
            int var10001 = " ".length();
            I[" ".length()].length();
            I["  ".length()].length();
            I["   ".length()].length();
            int var7 = var5 - var10001;

            while(var7 >= 0) {
               this.toMove.add(var1.offset(this.moveDirection.getOpposite(), var7));
               I[37 ^ 33].length();
               I[4 ^ 1].length();
               ++var12;
               --var7;
               "".length();
               if (-1 >= 3) {
                  throw null;
               }
            }

            var7 = " ".length();

            do {
               BlockPos var8 = var1.offset(this.moveDirection, var7);
               int var9 = this.toMove.indexOf(var8);
               if (var9 > -" ".length()) {
                  this.reorderListAtCollision(var12, var9);
                  int var10 = "".length();

                  do {
                     if (var10 > var9 + var12) {
                        return (boolean)" ".length();
                     }

                     BlockPos var11 = (BlockPos)this.toMove.get(var10);
                     if (this.world.getBlockState(var11).getBlock() == Blocks.SLIME_BLOCK && !this.addBranchingBlocks(var11)) {
                        return (boolean)"".length();
                     }

                     ++var10;
                     "".length();
                  } while(4 != 0);

                  throw null;
               }

               var3 = this.world.getBlockState(var8);
               if (var3.getMaterial() == Material.AIR) {
                  return (boolean)" ".length();
               }

               if (!BlockPistonBase.canPush(var3, this.world, var8, this.moveDirection, (boolean)" ".length(), this.moveDirection) || var8.equals(this.pistonPos)) {
                  return (boolean)"".length();
               }

               if (var3.getMobilityFlag() == EnumPushReaction.DESTROY) {
                  this.toDestroy.add(var8);
                  I[166 ^ 160].length();
                  return (boolean)" ".length();
               }

               if (this.toMove.size() >= (148 ^ 152)) {
                  return (boolean)"".length();
               }

               this.toMove.add(var8);
               I[152 ^ 159].length();
               I[129 ^ 137].length();
               ++var12;
               ++var7;
               "".length();
            } while(3 >= 2);

            throw null;
         }
      }
   }

   static {
      I();
   }
}

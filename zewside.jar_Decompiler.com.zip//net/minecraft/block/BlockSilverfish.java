package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockSilverfish extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockSilverfish.EnumType> VARIANT;

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[170 ^ 146];
      String var10001 = I[62 ^ 7];
      String var10002 = I[171 ^ 145];
      var10001 = I[110 ^ 85];
      BlockSilverfish.EnumType[] var3 = BlockSilverfish.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockSilverfish.EnumType var6 = var3[var5];
         I[148 ^ 168].length();
         I[58 ^ 7].length();
         I[119 ^ 73].length();
         I[168 ^ 151].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[7 ^ 71].length();
         I[214 ^ 151].length();
         ++var5;
         "".length();
      } while(4 >= 3);

      throw null;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(VARIANT, BlockSilverfish.EnumType.byMetadata(var1));
   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[175 ^ 171];
      var10001 = I[167 ^ 162];
      var10002 = I[36 ^ 34];
      var10001 = I[104 ^ 111];
      var10000 = I[5 ^ 13];
      var10001 = I[22 ^ 31];
      var10002 = I[28 ^ 22];
      var10001 = I[90 ^ 81];
      var10000 = I[77 ^ 65];
      var10001 = I[163 ^ 174];
      var10002 = I[20 ^ 26];
      var10001 = I[172 ^ 163];
      var10000 = I[169 ^ 185];
      var10001 = I[175 ^ 190];
      var10002 = I[26 ^ 8];
      var10001 = I[153 ^ 138];
      var10000 = I[130 ^ 150];
      var10001 = I[62 ^ 43];
      var10002 = I[97 ^ 119];
      var10001 = I[89 ^ 78];
      switch(null.$SwitchMap$net$minecraft$block$BlockSilverfish$EnumType[((BlockSilverfish.EnumType)var1.getValue(VARIANT)).ordinal()]) {
      case 1:
         I[114 ^ 106].length();
         I[72 ^ 81].length();
         I[85 ^ 79].length();
         return new ItemStack(Blocks.COBBLESTONE);
      case 2:
         I[89 ^ 66].length();
         I[75 ^ 87].length();
         return new ItemStack(Blocks.STONEBRICK);
      case 3:
         I[49 ^ 44].length();
         I[50 ^ 44].length();
         return new ItemStack(Blocks.STONEBRICK, " ".length(), BlockStoneBrick.EnumType.MOSSY.getMetadata());
      case 4:
         I[151 ^ 136].length();
         I[122 ^ 90].length();
         return new ItemStack(Blocks.STONEBRICK, " ".length(), BlockStoneBrick.EnumType.CRACKED.getMetadata());
      case 5:
         I[154 ^ 187].length();
         I[39 ^ 5].length();
         I[18 ^ 49].length();
         return new ItemStack(Blocks.STONEBRICK, " ".length(), BlockStoneBrick.EnumType.CHISELED.getMetadata());
      default:
         I[108 ^ 72].length();
         I[135 ^ 162].length();
         return new ItemStack(Blocks.STONE);
      }
   }

   private static void I() {
      I = new String[80 ^ 0];
      I["".length()] = I("哂儏", "WEtqj");
      I[" ".length()] = I("垍滝", "dMonN");
      I["  ".length()] = I("煪俴", "xZIve");
      I["   ".length()] = I("吁徔", "asWaR");
      I[155 ^ 159] = I("唼灝", "cGwrF");
      I[119 ^ 114] = I("婺槐", "RAKdP");
      I[35 ^ 37] = I("橤塄", "AwoqY");
      I[107 ^ 108] = I("勛暴", "lfTzP");
      I[32 ^ 40] = I("刄忷", "rupQT");
      I[157 ^ 148] = I("杓煾", "ExeiM");
      I[158 ^ 148] = I("毷揥", "EPgLV");
      I[117 ^ 126] = I("暂出", "KktwO");
      I[122 ^ 118] = I("抰乓", "AmyOL");
      I[180 ^ 185] = I("澩檇", "RSnHw");
      I[163 ^ 173] = I("槒煙", "mHeZe");
      I[107 ^ 100] = I("淍徃", "XiuSQ");
      I[47 ^ 63] = I("榤喂", "ahPSF");
      I[110 ^ 127] = I("橕溫", "qXVud");
      I[41 ^ 59] = I("攦夙", "SBVbq");
      I[61 ^ 46] = I("嚜櫤", "RsZvc");
      I[208 ^ 196] = I("渮巈", "exUxD");
      I[120 ^ 109] = I("武尫", "CCuuf");
      I[39 ^ 49] = I("券擬", "WkrYD");
      I[31 ^ 8] = I("曗律", "KMuKD");
      I[140 ^ 148] = I("檃崱摏", "WoiRa");
      I[7 ^ 30] = I("檗姯", "akAWS");
      I[4 ^ 30] = I("橄呝", "DECxd");
      I[91 ^ 64] = I("瀲做嬀", "hXxeV");
      I[41 ^ 53] = I("巨桚欬", "oFPMV");
      I[220 ^ 193] = I("澪檰嵺姁尯", "TQfdX");
      I[10 ^ 20] = I("椟", "SBQgL");
      I[9 ^ 22] = I("儆叚娥", "QVIMF");
      I[13 ^ 45] = I("洨匋", "HTBsm");
      I[51 ^ 18] = I("囲媀它", "tyeBy");
      I[128 ^ 162] = I("潜憤婸殀椬", "OkCkY");
      I[8 ^ 43] = I("娎揁徲札姗", "qOddZ");
      I[154 ^ 190] = I("掓樈匴", "Fysvt");
      I[60 ^ 25] = I("勵仃", "bqhbI");
      I[95 ^ 121] = I("惥吥", "jJDGT");
      I[112 ^ 87] = I("头潫", "iWsyK");
      I[8 ^ 32] = I("旘後", "rxpYa");
      I[172 ^ 133] = I("憎壮", "zVGjd");
      I[41 ^ 3] = I("\u000e55\u00104\u000f\u001e\u0013\u0016(\u0019", "jZayX");
      I[232 ^ 195] = I("怘", "AdTDU");
      I[157 ^ 177] = I("照", "JzcPv");
      I[57 ^ 20] = I("嶔淛正", "pXoei");
      I[105 ^ 71] = I("涎橌", "tqJaV");
      I[87 ^ 120] = I("妉", "XmunW");
      I[159 ^ 175] = I("嘚恲", "SgeuG");
      I[160 ^ 145] = I("堔坱", "AjRLi");
      I[243 ^ 193] = I("听涧", "epWkT");
      I[145 ^ 162] = I("橠伴", "BChNB");
      I[66 ^ 118] = I("偄愭徊兛侐", "qkvRU");
      I[94 ^ 107] = I("杹", "BUnkG");
      I[161 ^ 151] = I("所沌氩汬", "RjjnC");
      I[243 ^ 196] = I("屈", "IbfZq");
      I[77 ^ 117] = I("汕嬁", "kROUF");
      I[167 ^ 158] = I("浪枞", "sEIlD");
      I[189 ^ 135] = I("亐忔", "zhGBN");
      I[186 ^ 129] = I("崲幒", "FExXH");
      I[87 ^ 107] = I("嵪櫒漩", "aibcJ");
      I[124 ^ 65] = I("殲幰墸", "oCbyL");
      I[34 ^ 28] = I("汋惵厵惪", "kvLQx");
      I[107 ^ 84] = I("僡僰岣涣帶", "ewBgH");
      I[223 ^ 159] = I("圲俓圉啿", "cRjIy");
      I[42 ^ 107] = I("坯沿偋", "yqass");
      I[21 ^ 87] = I("憦壀", "JbKHF");
      I[110 ^ 45] = I("樖拋", "vdsjT");
      I[129 ^ 197] = I("昶嫝", "wZMzh");
      I[47 ^ 106] = I("煔欳", "vBZRe");
      I[79 ^ 9] = I("堅僻", "OfmsW");
      I[254 ^ 185] = I("乆澝", "yueqe");
      I[4 ^ 76] = I("冽拤", "ksgve");
      I[19 ^ 90] = I("幋橑", "AAhej");
      I[44 ^ 102] = I("灥椳各", "honoR");
      I[199 ^ 140] = I("儭奾", "aJebz");
      I[120 ^ 52] = I("渞", "egfkj");
      I[219 ^ 150] = I("屄吣亳塇墽", "AIEWK");
      I[56 ^ 118] = I("泴押", "KjByS");
      I[137 ^ 198] = I(";\u00021\u001b\f#\u0017", "McCrm");
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      String var10000 = I[38 ^ 0];
      String var10001 = I[69 ^ 98];
      String var10002 = I[83 ^ 123];
      var10001 = I[31 ^ 54];
      if (!var1.isRemote && var1.getGameRules().getBoolean(I[238 ^ 196])) {
         I[161 ^ 138].length();
         I[76 ^ 96].length();
         I[145 ^ 188].length();
         I[140 ^ 162].length();
         EntitySilverfish var6 = new EntitySilverfish(var1);
         var6.setLocationAndAngles((double)var2.getX() + 0.5D, (double)var2.getY(), (double)var2.getZ() + 0.5D, 0.0F, 0.0F);
         var1.spawnEntityInWorld(var6);
         I[47 ^ 0].length();
         var6.spawnExplosionParticle();
      }

   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 0);

      throw null;
   }

   public BlockSilverfish() {
      super(Material.CLAY);
      this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, BlockSilverfish.EnumType.STONE));
      this.setHardness(0.0F);
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[129 ^ 177];
      String var10001 = I[130 ^ 179];
      String var10002 = I[178 ^ 128];
      var10001 = I[26 ^ 41];
      I[30 ^ 42].length();
      I[61 ^ 8].length();
      I[133 ^ 179].length();
      I[112 ^ 71].length();
      return new ItemStack(this, " ".length(), var3.getBlock().getMetaFromState(var3));
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[206 ^ 129], BlockSilverfish.EnumType.class);
   }

   public static boolean canContainSilverfish(IBlockState var0) {
      Block var1 = var0.getBlock();
      int var10000;
      if (var0 != Blocks.STONE.getDefaultState().withProperty(BlockStone.VARIANT, BlockStone.EnumType.STONE) && var1 != Blocks.COBBLESTONE && var1 != Blocks.STONEBRICK) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (1 <= 0) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[101 ^ 39];
      String var10001 = I[133 ^ 198];
      String var10002 = I[252 ^ 184];
      var10001 = I[9 ^ 76];
      var10000 = I[222 ^ 152];
      var10001 = I[254 ^ 185];
      var10002 = I[250 ^ 178];
      var10001 = I[117 ^ 60];
      I[124 ^ 54].length();
      I[228 ^ 175].length();
      I[117 ^ 57].length();
      I[192 ^ 141].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[94 ^ 16].length();
      var10003["".length()] = VARIANT;
      return new BlockStateContainer(this, var10003);
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockSilverfish.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      CRACKED_STONEBRICK,
      // $FF: synthetic field
      STONEBRICK,
      // $FF: synthetic field
      STONE,
      // $FF: synthetic field
      MOSSY_STONEBRICK;

      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      CHISELED_STONEBRICK;

      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      COBBLESTONE;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private static final String[] I;

      public static BlockSilverfish.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      public String toString() {
         return this.name;
      }

      public abstract IBlockState getModelBlock();

      public static BlockSilverfish.EnumType forModelBlock(IBlockState var0) {
         BlockSilverfish.EnumType[] var1 = values();
         int var2 = var1.length;
         int var3 = "".length();

         do {
            if (var3 >= var2) {
               return STONE;
            }

            BlockSilverfish.EnumType var4 = var1[var3];
            if (var0 == var4.getModelBlock()) {
               return var4;
            }

            ++var3;
            "".length();
         } while(0 < 3);

         throw null;
      }

      private EnumType(int var3, String var4, String var5) {
         this.meta = var3;
         this.name = var4;
         this.unlocalizedName = var5;
      }

      public String getName() {
         return this.name;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 > -1);

         throw null;
      }

      private EnumType(int var3, String var4) {
         this(var3, var4, var4);
      }

      // $FF: synthetic method
      EnumType(int var3, String var4, Object var5) {
         this(var3, var4);
      }

      public int getMetadata() {
         return this.meta;
      }

      static {
         I();
         STONE = new BlockSilverfish.EnumType(I["".length()], "".length(), "".length(), I[" ".length()]) {
            public IBlockState getModelBlock() {
               return Blocks.STONE.getDefaultState().withProperty(BlockStone.VARIANT, BlockStone.EnumType.STONE);
            }

            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(4 > 1);

               throw null;
            }
         };
         COBBLESTONE = new BlockSilverfish.EnumType(I["  ".length()], " ".length(), " ".length(), I["   ".length()], I[48 ^ 52]) {
            public IBlockState getModelBlock() {
               return Blocks.COBBLESTONE.getDefaultState();
            }

            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(2 < 4);

               throw null;
            }
         };
         STONEBRICK = new BlockSilverfish.EnumType(I[182 ^ 179], "  ".length(), "  ".length(), I[135 ^ 129], I[85 ^ 82]) {
            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(-1 < 3);

               throw null;
            }

            public IBlockState getModelBlock() {
               return Blocks.STONEBRICK.getDefaultState().withProperty(BlockStoneBrick.VARIANT, BlockStoneBrick.EnumType.DEFAULT);
            }
         };
         MOSSY_STONEBRICK = new BlockSilverfish.EnumType(I[144 ^ 152], "   ".length(), "   ".length(), I[30 ^ 23], I[185 ^ 179]) {
            public IBlockState getModelBlock() {
               return Blocks.STONEBRICK.getDefaultState().withProperty(BlockStoneBrick.VARIANT, BlockStoneBrick.EnumType.MOSSY);
            }

            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(1 > 0);

               throw null;
            }
         };
         CRACKED_STONEBRICK = new BlockSilverfish.EnumType(I[57 ^ 50], 177 ^ 181, 26 ^ 30, I[36 ^ 40], I[177 ^ 188]) {
            public IBlockState getModelBlock() {
               return Blocks.STONEBRICK.getDefaultState().withProperty(BlockStoneBrick.VARIANT, BlockStoneBrick.EnumType.CRACKED);
            }

            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(1 != -1);

               throw null;
            }
         };
         CHISELED_STONEBRICK = new BlockSilverfish.EnumType(I[98 ^ 108], 36 ^ 33, 137 ^ 140, I[95 ^ 80], I[62 ^ 46]) {
            public IBlockState getModelBlock() {
               return Blocks.STONEBRICK.getDefaultState().withProperty(BlockStoneBrick.VARIANT, BlockStoneBrick.EnumType.CHISELED);
            }

            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(3 == 3);

               throw null;
            }
         };
         BlockSilverfish.EnumType[] var10000 = new BlockSilverfish.EnumType[58 ^ 60];
         var10000["".length()] = STONE;
         var10000[" ".length()] = COBBLESTONE;
         var10000["  ".length()] = STONEBRICK;
         var10000["   ".length()] = MOSSY_STONEBRICK;
         var10000[111 ^ 107] = CRACKED_STONEBRICK;
         var10000[193 ^ 196] = CHISELED_STONEBRICK;
         BlockSilverfish.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockSilverfish.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(2 != 3);

         throw null;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      private static void I() {
         I = new String[59 ^ 42];
         I["".length()] = I("$19:\u0004", "wevtA");
         I[" ".length()] = I("7&<\u001b\u000f", "DRSuj");
         I["  ".length()] = I("1\u001a%%>7\u00063(<7", "rUggr");
         I["   ".length()] = I("\u0016 4\u0014 \u0010<\"\u0019\"\u0010", "uOVvL");
         I[4 ^ 0] = I(") #2\r/", "JOAPa");
         I[101 ^ 96] = I("\u001f\u001a(,\f\u000e\u001c.!\u0002", "LNgbI");
         I[189 ^ 187] = I("\u0017\u0007\u001b\u001a\r;\u0011\u0006\u001d\u000b\u000f", "dstth");
         I[150 ^ 145] = I(")8\u0007\u0011*", "KJnrA");
         I[126 ^ 118] = I("!\u000081\u00163\u001c?-\u0001)\r9+\f'", "lOkbO");
         I[100 ^ 109] = I("\u0006\u0003\n\u000734\u000e\u000b\u001d)\u0000", "klytJ");
         I[126 ^ 116] = I("9\u001e'$86\u0003=4*", "TqTWA");
         I[81 ^ 90] = I("!\u0001+\u0010#'\u00175\u0000<-\u001d/\u0011:+\u0010!", "bSjSh");
         I[206 ^ 194] = I("\u000b\u0000\u001b$'\r\u0016%%>\u0001\u0011\u0011", "hrzGL");
         I[200 ^ 197] = I("\u0016\b\u000b1\u0001\u0010\u001e\b \u0003\u0016\u0011", "uzjRj");
         I[203 ^ 197] = I("&\u001b\n\u00150)\u0016\u0007\u0019&1\u001c\r\u000377\u001a\u0000\r", "eSCFu");
         I[22 ^ 25] = I("+\u0018\u00059\u0003$\u0015\b\u0015\u0004:\u0019\u000f!", "HplJf");
         I[65 ^ 81] = I("\u0011\u001c\u0007;\u0010\u001e\u0011\n*\u0007\u001b\u0017\u0005", "rtnHu");
      }

      // $FF: synthetic method
      EnumType(int var3, String var4, String var5, Object var6) {
         this(var3, var4, var5);
      }
   }
}

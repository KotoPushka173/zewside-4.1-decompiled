package net.minecraft.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;

public class BlockRedSandstone extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockRedSandstone.EnumType> TYPE;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 0);

      throw null;
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      BlockRedSandstone.EnumType[] var3 = BlockRedSandstone.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockRedSandstone.EnumType var6 = var3[var5];
         I[68 ^ 64].length();
         I[106 ^ 111].length();
         I[63 ^ 57].length();
         I[83 ^ 84].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[162 ^ 170].length();
         I[27 ^ 18].length();
         I[141 ^ 135].length();
         ++var5;
         "".length();
      } while(2 > 1);

      throw null;
   }

   private static void I() {
      I = new String[191 ^ 166];
      I["".length()] = I("堁弉", "pAgpt");
      I[" ".length()] = I("昦植", "LJOJa");
      I["  ".length()] = I("幈揰", "UMtCZ");
      I["   ".length()] = I("投漌", "eWdCp");
      I[114 ^ 118] = I("楜", "bSchT");
      I[127 ^ 122] = I("尥時噤", "pMXiK");
      I[10 ^ 12] = I("时", "uQzWz");
      I[151 ^ 144] = I("擣煄", "xLuBZ");
      I[165 ^ 173] = I("廟", "XJIJu");
      I[17 ^ 24] = I("扅椆", "RSvWG");
      I[131 ^ 137] = I("斚亿", "yAtbp");
      I[104 ^ 99] = I("攢桋", "PTGWN");
      I[94 ^ 82] = I("戶噃", "WmEfv");
      I[121 ^ 116] = I("椗恚", "Ivron");
      I[95 ^ 81] = I("徏汅", "ssAty");
      I[22 ^ 25] = I("吏唃", "VGAJl");
      I[107 ^ 123] = I("垡僕", "KpWxS");
      I[137 ^ 152] = I("囕刍", "IJjZB");
      I[92 ^ 78] = I("墨嬪", "AgiLd");
      I[3 ^ 16] = I("朩晞屣噆", "YIEkl");
      I[107 ^ 127] = I("咶撑卣勤崰", "bFzKT");
      I[100 ^ 113] = I("泷姖儱俿", "opHYg");
      I[165 ^ 179] = I("滚", "KHVIc");
      I[107 ^ 124] = I("灸栉", "pDVVt");
      I[101 ^ 125] = I("\u0015;\u0018.", "aBhKs");
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockRedSandstone.EnumType)var1.getValue(TYPE)).getMetadata();
   }

   public int getMetaFromState(IBlockState var1) {
      return ((BlockRedSandstone.EnumType)var1.getValue(TYPE)).getMetadata();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[102 ^ 109];
      String var10001 = I[31 ^ 19];
      String var10002 = I[139 ^ 134];
      var10001 = I[129 ^ 143];
      var10000 = I[102 ^ 105];
      var10001 = I[128 ^ 144];
      var10002 = I[69 ^ 84];
      var10001 = I[20 ^ 6];
      I[41 ^ 58].length();
      I[32 ^ 52].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[146 ^ 135].length();
      I[51 ^ 37].length();
      I[24 ^ 15].length();
      var10003["".length()] = TYPE;
      return new BlockStateContainer(this, var10003);
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(TYPE, BlockRedSandstone.EnumType.byMetadata(var1));
   }

   static {
      I();
      TYPE = PropertyEnum.create(I[62 ^ 38], BlockRedSandstone.EnumType.class);
   }

   public BlockRedSandstone() {
      super(Material.ROCK, BlockSand.EnumType.RED_SAND.getMapColor());
      this.setDefaultState(this.blockState.getBaseState().withProperty(TYPE, BlockRedSandstone.EnumType.DEFAULT));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public static enum EnumType implements IStringSerializable {
      // $FF: synthetic field
      DEFAULT;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      private final String unlocalizedName;
      // $FF: synthetic field
      CHISELED,
      // $FF: synthetic field
      SMOOTH;

      public int getMetadata() {
         return this.meta;
      }

      public String getName() {
         return this.name;
      }

      public String getUnlocalizedName() {
         return this.unlocalizedName;
      }

      public static BlockRedSandstone.EnumType byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      public String toString() {
         return this.name;
      }

      private EnumType(int var3, String var4, String var5) {
         this.meta = var3;
         this.name = var4;
         this.unlocalizedName = var5;
      }

      private static void I() {
         I = new String[141 ^ 132];
         I["".length()] = I(" \u0011\"(\u0017(\u0000", "dTdiB");
         I[" ".length()] = I("\u00072\u0011\r2\u00149\u0011!5\u001a9\u0010", "uWuRA");
         I["  ".length()] = I("77!0\u0006?&", "SRGQs");
         I["   ".length()] = I("0<#;0?1.", "stjhu");
         I[53 ^ 49] = I("3?\u001f&$<2\u0012\n353)& >3\u0005!.>2", "PWvUA");
         I[182 ^ 179] = I("3\t\u0018\u00191<\u0004\u0015", "PaqjT");
         I[101 ^ 99] = I("\"\b\b?\u00069", "qEGpR");
         I[49 ^ 54] = I("#/\b\u001b\u001b8\u001d\u0015\u0011\u000b\u000f1\u0006\u001a\u000b#6\b\u001a\n", "PBgto");
         I[15 ^ 7] = I("\u0002)\u001f75\u0019", "qDpXA");
      }

      static {
         I();
         DEFAULT = new BlockRedSandstone.EnumType(I["".length()], "".length(), "".length(), I[" ".length()], I["  ".length()]);
         CHISELED = new BlockRedSandstone.EnumType(I["   ".length()], " ".length(), " ".length(), I[73 ^ 77], I[54 ^ 51]);
         SMOOTH = new BlockRedSandstone.EnumType(I[199 ^ 193], "  ".length(), "  ".length(), I[118 ^ 113], I[205 ^ 197]);
         BlockRedSandstone.EnumType[] var10000 = new BlockRedSandstone.EnumType["   ".length()];
         var10000["".length()] = DEFAULT;
         var10000[" ".length()] = CHISELED;
         var10000["  ".length()] = SMOOTH;
         BlockRedSandstone.EnumType[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockRedSandstone.EnumType var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(3 < 4);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 < 4);

         throw null;
      }
   }
}

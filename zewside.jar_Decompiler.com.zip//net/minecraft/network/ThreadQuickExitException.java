package net.minecraft.network;

public final class ThreadQuickExitException extends RuntimeException {
   // $FF: synthetic field
   public static final ThreadQuickExitException INSTANCE = new ThreadQuickExitException();

   public synchronized Throwable fillInStackTrace() {
      this.setStackTrace(new StackTraceElement["".length()]);
      return this;
   }

   private ThreadQuickExitException() {
      this.setStackTrace(new StackTraceElement["".length()]);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 2);

      throw null;
   }
}

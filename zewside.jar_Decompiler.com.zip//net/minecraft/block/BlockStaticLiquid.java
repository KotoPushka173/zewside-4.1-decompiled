package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockStaticLiquid extends BlockLiquid {
   // $FF: synthetic field
   private static final String[] I;

   private boolean getCanBlockBurn(World var1, BlockPos var2) {
      int var10000;
      if (var2.getY() >= 0 && var2.getY() < 220 + 163 - 132 + 5 && !var1.isBlockLoaded(var2)) {
         var10000 = "".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = var1.getBlockState(var2).getMaterial().getCanBurn();
      }

      return (boolean)var10000;
   }

   protected boolean isSurroundingBlockFlammable(World var1, BlockPos var2) {
      EnumFacing[] var3 = EnumFacing.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return (boolean)"".length();
         }

         EnumFacing var6 = var3[var5];
         if (this.getCanBlockBurn(var1, var2.offset(var6))) {
            return (boolean)" ".length();
         }

         ++var5;
         "".length();
      } while(3 != 0);

      throw null;
   }

   private void updateLiquid(World var1, BlockPos var2, IBlockState var3) {
      BlockDynamicLiquid var4 = getFlowingBlock(this.blockMaterial);
      var1.setBlockState(var2, var4.getDefaultState().withProperty(LEVEL, var3.getValue(LEVEL)), "  ".length());
      I["".length()].length();
      I[" ".length()].length();
      var1.scheduleUpdate(var2, var4, this.tickRate(var1));
   }

   static {
      I();
   }

   protected BlockStaticLiquid(Material var1) {
      super(var1);
      this.setTickRandomly((boolean)"".length());
      if (var1 == Material.LAVA) {
         this.setTickRandomly((boolean)" ".length());
      }

   }

   private static void I() {
      I = new String[101 ^ 115];
      I["".length()] = I("屺", "ladwC");
      I[" ".length()] = I("煼慾枸", "QjCWR");
      I["  ".length()] = I(",\u0006\u0016::-=90#", "HiPSH");
      I["   ".length()] = I("嘖搱幔", "WVYZP");
      I[8 ^ 12] = I("恞煠呸搘攄", "TyCtv");
      I[123 ^ 126] = I("兆枖仱岚潄", "AAooY");
      I[174 ^ 168] = I("炭墾孑勻偯", "RrAzU");
      I[17 ^ 22] = I("幕垀湱欒初", "QsmnI");
      I[44 ^ 36] = I("檶亼惫", "LzXpQ");
      I[161 ^ 168] = I("浈", "TjCQq");
      I[15 ^ 5] = I("勸妅從榢", "CyXOt");
      I[164 ^ 175] = I("愬侰孊檴料", "VEVAU");
      I[168 ^ 164] = I("悆勌丧淺", "XqUUY");
      I[185 ^ 180] = I("慭攍煽剧啠", "LwOCx");
      I[105 ^ 103] = I("嵞毎擖榸", "SzVpW");
      I[122 ^ 117] = I("愳", "jXbrY");
      I[68 ^ 84] = I("撧徺曵", "BJGNq");
      I[170 ^ 187] = I("搃捘卵", "xDoMk");
      I[181 ^ 167] = I("嫁橃幹", "XCGYI");
      I[38 ^ 53] = I("屝佧栱", "lzdRc");
      I[118 ^ 98] = I("乑柭桀", "yVWvp");
      I[184 ^ 173] = I("寃壜", "SomDJ");
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (this.blockMaterial == Material.LAVA && var1.getGameRules().getBoolean(I["  ".length()])) {
         int var5 = var4.nextInt("   ".length());
         int var10001;
         int var10002;
         int var10003;
         int var10004;
         if (var5 > 0) {
            BlockPos var6 = var2;
            int var7 = "".length();

            while(var7 < var5) {
               var10001 = var4.nextInt("   ".length());
               var10002 = " ".length();
               I["   ".length()].length();
               I[91 ^ 95].length();
               var10001 -= var10002;
               var10002 = " ".length();
               var10003 = var4.nextInt("   ".length());
               var10004 = " ".length();
               I[80 ^ 85].length();
               I[43 ^ 45].length();
               I[92 ^ 91].length();
               var6 = var6.add(var10001, var10002, var10003 - var10004);
               if (var6.getY() >= 0 && var6.getY() < 154 + 124 - 144 + 122 && !var1.isBlockLoaded(var6)) {
                  return;
               }

               Block var8 = var1.getBlockState(var6).getBlock();
               if (var8.blockMaterial == Material.AIR) {
                  if (this.isSurroundingBlockFlammable(var1, var6)) {
                     var1.setBlockState(var6, Blocks.FIRE.getDefaultState());
                     I[180 ^ 188].length();
                     I[121 ^ 112].length();
                     I[8 ^ 2].length();
                     return;
                  }
               } else if (var8.blockMaterial.blocksMovement()) {
                  return;
               }

               ++var7;
               "".length();
               if (3 < 3) {
                  throw null;
               }
            }

            "".length();
            if (1 >= 3) {
               throw null;
            }
         } else {
            int var9 = "".length();

            while(var9 < "   ".length()) {
               var10001 = var4.nextInt("   ".length());
               var10002 = " ".length();
               I[62 ^ 53].length();
               I[10 ^ 6].length();
               I[85 ^ 88].length();
               I[11 ^ 5].length();
               var10001 -= var10002;
               var10002 = "".length();
               var10003 = var4.nextInt("   ".length());
               var10004 = " ".length();
               I[53 ^ 58].length();
               I[136 ^ 152].length();
               I[98 ^ 115].length();
               I[143 ^ 157].length();
               BlockPos var10 = var2.add(var10001, var10002, var10003 - var10004);
               if (var10.getY() >= 0 && var10.getY() < 224 + 208 - 331 + 155 && !var1.isBlockLoaded(var10)) {
                  return;
               }

               if (var1.isAirBlock(var10.up()) && this.getCanBlockBurn(var1, var10)) {
                  var1.setBlockState(var10.up(), Blocks.FIRE.getDefaultState());
                  I[101 ^ 118].length();
                  I[179 ^ 167].length();
                  I[33 ^ 52].length();
               }

               ++var9;
               "".length();
               if (1 < 1) {
                  throw null;
               }
            }
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 1);

      throw null;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!this.checkForMixing(var2, var3, var1)) {
         this.updateLiquid(var2, var3, var1);
      }

   }
}

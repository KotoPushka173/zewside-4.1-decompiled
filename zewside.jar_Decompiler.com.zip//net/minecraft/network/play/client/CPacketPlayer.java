package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketPlayer implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   public double y;
   // $FF: synthetic field
   protected float yaw;
   // $FF: synthetic field
   public boolean onGround;
   // $FF: synthetic field
   protected boolean moving;
   // $FF: synthetic field
   protected float pitch;
   // $FF: synthetic field
   protected double x;
   // $FF: synthetic field
   protected double z;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected boolean rotating;

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processPlayer(this);
   }

   private static void I() {
      I = new String["  ".length()];
      I["".length()] = I("圕冠侹", "ouqAr");
      I[" ".length()] = I("嶦柯", "hocbg");
   }

   public double getY(double var1) {
      double var10000;
      if (this.moving) {
         var10000 = this.y;
         "".length();
         if (-1 == 0) {
            throw null;
         }
      } else {
         var10000 = var1;
      }

      return var10000;
   }

   static {
      I();
   }

   public double getZ(double var1) {
      double var10000;
      if (this.moving) {
         var10000 = this.z;
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = var1;
      }

      return var10000;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      int var10001;
      if (var1.readUnsignedByte() != 0) {
         var10001 = " ".length();
         "".length();
         if (2 == -1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.onGround = (boolean)var10001;
   }

   public CPacketPlayer() {
   }

   public float getYaw(float var1) {
      float var10000;
      if (this.rotating) {
         var10000 = this.yaw;
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = var1;
      }

      return var10000;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public double getX(double var1) {
      double var10000;
      if (this.moving) {
         var10000 = this.x;
         "".length();
         if (3 <= 1) {
            throw null;
         }
      } else {
         var10000 = var1;
      }

      return var10000;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      int var10001;
      if (this.onGround) {
         var10001 = " ".length();
         "".length();
         if (4 == 3) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      var1.writeByte(var10001);
      I["".length()].length();
      I[" ".length()].length();
   }

   public float getPitch(float var1) {
      float var10000;
      if (this.rotating) {
         var10000 = this.pitch;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = var1;
      }

      return var10000;
   }

   public boolean isOnGround() {
      return this.onGround;
   }

   public CPacketPlayer(boolean var1) {
      this.onGround = var1;
   }

   public static class Rotation extends CPacketPlayer {
      // $FF: synthetic field
      private static final String[] I;

      public Rotation() {
         this.rotating = (boolean)" ".length();
      }

      public void writePacketData(PacketBuffer var1) throws IOException {
         var1.writeFloat(this.yaw);
         I["".length()].length();
         I[" ".length()].length();
         var1.writeFloat(this.pitch);
         I["  ".length()].length();
         super.writePacketData(var1);
      }

      static {
         I();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= 1);

         throw null;
      }

      public Rotation(float var1, float var2, boolean var3) {
         this.yaw = var1;
         this.pitch = var2;
         this.onGround = var3;
         this.rotating = (boolean)" ".length();
      }

      private static void I() {
         I = new String["   ".length()];
         I["".length()] = I("噍", "dZBQz");
         I[" ".length()] = I("橣拽叀婯", "eTFQl");
         I["  ".length()] = I("俼瀏僬桶", "wCetA");
      }

      public void readPacketData(PacketBuffer var1) throws IOException {
         this.yaw = var1.readFloat();
         this.pitch = var1.readFloat();
         super.readPacketData(var1);
      }
   }

   public static class Position extends CPacketPlayer {
      // $FF: synthetic field
      private static final String[] I;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 >= 2);

         throw null;
      }

      public void readPacketData(PacketBuffer var1) throws IOException {
         this.x = var1.readDouble();
         this.y = var1.readDouble();
         this.z = var1.readDouble();
         super.readPacketData(var1);
      }

      static {
         I();
      }

      private static void I() {
         I = new String[92 ^ 90];
         I["".length()] = I("樬", "LjxVr");
         I[" ".length()] = I("潬囐", "LxbsO");
         I["  ".length()] = I("摷懧", "PvQJM");
         I["   ".length()] = I("他", "YNRRw");
         I[144 ^ 148] = I("枂桽欲", "BAyHb");
         I[146 ^ 151] = I("桽昉惼丯", "rsBVI");
      }

      public void writePacketData(PacketBuffer var1) throws IOException {
         var1.writeDouble(this.x);
         I["".length()].length();
         I[" ".length()].length();
         var1.writeDouble(this.y);
         I["  ".length()].length();
         var1.writeDouble(this.z);
         I["   ".length()].length();
         I[49 ^ 53].length();
         I[134 ^ 131].length();
         super.writePacketData(var1);
      }

      public Position() {
         this.moving = (boolean)" ".length();
      }

      public Position(double var1, double var3, double var5, boolean var7) {
         this.x = var1;
         this.y = var3;
         this.z = var5;
         this.onGround = var7;
         this.moving = (boolean)" ".length();
      }
   }

   public static class PositionRotation extends CPacketPlayer {
      // $FF: synthetic field
      private static final String[] I;

      public void writePacketData(PacketBuffer var1) throws IOException {
         var1.writeDouble(this.x);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         var1.writeDouble(this.y);
         I["   ".length()].length();
         I[58 ^ 62].length();
         I[76 ^ 73].length();
         var1.writeDouble(this.z);
         I[167 ^ 161].length();
         I[22 ^ 17].length();
         I[17 ^ 25].length();
         var1.writeFloat(this.yaw);
         I[11 ^ 2].length();
         I[59 ^ 49].length();
         var1.writeFloat(this.pitch);
         I[43 ^ 32].length();
         I[130 ^ 142].length();
         I[37 ^ 40].length();
         I[61 ^ 51].length();
         super.writePacketData(var1);
      }

      public void readPacketData(PacketBuffer var1) throws IOException {
         this.x = var1.readDouble();
         this.y = var1.readDouble();
         this.z = var1.readDouble();
         this.yaw = var1.readFloat();
         this.pitch = var1.readFloat();
         super.readPacketData(var1);
      }

      static {
         I();
      }

      public PositionRotation(double var1, double var3, double var5, float var7, float var8, boolean var9) {
         this.x = var1;
         this.y = var3;
         this.z = var5;
         this.yaw = var7;
         this.pitch = var8;
         this.onGround = var9;
         this.rotating = (boolean)" ".length();
         this.moving = (boolean)" ".length();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 < 1);

         throw null;
      }

      public PositionRotation() {
         this.moving = (boolean)" ".length();
         this.rotating = (boolean)" ".length();
      }

      private static void I() {
         I = new String[128 ^ 143];
         I["".length()] = I("湤塇", "wjFVe");
         I[" ".length()] = I("昷扏媵氱", "fdmmX");
         I["  ".length()] = I("孾淏涨嘰", "TptVC");
         I["   ".length()] = I("氌", "hAoKN");
         I[28 ^ 24] = I("湵樟佝", "QzENl");
         I[162 ^ 167] = I("巸寳", "ktFub");
         I[64 ^ 70] = I("浨朸司呤埯", "PkTps");
         I[103 ^ 96] = I("摺", "bTKAN");
         I[46 ^ 38] = I("丫冻塙挪尦", "CXVin");
         I[142 ^ 135] = I("欙噡漇", "WisIn");
         I[89 ^ 83] = I("巅泬", "JyTnS");
         I[200 ^ 195] = I("焠崒", "cLIit");
         I[191 ^ 179] = I("媈妫柊淑歙", "UNNUg");
         I[60 ^ 49] = I("挆嚽圔", "GAmcr");
         I[17 ^ 31] = I("啢", "mVXtW");
      }
   }
}

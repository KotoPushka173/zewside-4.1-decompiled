package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.block.Block;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;

public class SPacketBlockAction implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int pitch;
   // $FF: synthetic field
   private int instrument;
   // $FF: synthetic field
   private BlockPos blockPosition;
   // $FF: synthetic field
   private Block block;
   // $FF: synthetic field
   private static final String[] I;

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleBlockAction(this);
   }

   static {
      I();
   }

   public int getData1() {
      return this.instrument;
   }

   private static void I() {
      I = new String[45 ^ 38];
      I["".length()] = I("嫤曅", "QpYwk");
      I[" ".length()] = I("妊滓", "wGScR");
      I["  ".length()] = I("匳嵬娩布潑", "ApGOh");
      I["   ".length()] = I("崿", "jtINX");
      I[91 ^ 95] = I("婜忄", "DNpoC");
      I[67 ^ 70] = I("嘮炛炆殗", "DUzAQ");
      I[114 ^ 116] = I("煉僢", "lIABa");
      I[184 ^ 191] = I("暞冿", "NOeOr");
      I[12 ^ 4] = I("姜擕", "ToDwT");
      I[116 ^ 125] = I("峽溑厌挍", "ePSER");
      I[136 ^ 130] = I("憐", "mJIWN");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.blockPosition = var1.readBlockPos();
      this.instrument = var1.readUnsignedByte();
      this.pitch = var1.readUnsignedByte();
      this.block = Block.getBlockById(var1.readVarIntFromBuffer() & 1036 + 1040 - -2007 + 12);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public SPacketBlockAction() {
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeBlockPos(this.blockPosition);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeByte(this.instrument);
      I["  ".length()].length();
      I["   ".length()].length();
      I[94 ^ 90].length();
      var1.writeByte(this.pitch);
      I[95 ^ 90].length();
      I[52 ^ 50].length();
      var1.writeVarIntToBuffer(Block.getIdFromBlock(this.block) & 1443 + 632 - 459 + 2479);
      I[156 ^ 155].length();
      I[42 ^ 34].length();
      I[69 ^ 76].length();
      I[150 ^ 156].length();
   }

   public Block getBlockType() {
      return this.block;
   }

   public BlockPos getBlockPosition() {
      return this.blockPosition;
   }

   public SPacketBlockAction(BlockPos var1, Block var2, int var3, int var4) {
      this.blockPosition = var1;
      this.instrument = var3;
      this.pitch = var4;
      this.block = var2;
   }

   public int getData2() {
      return this.pitch;
   }
}

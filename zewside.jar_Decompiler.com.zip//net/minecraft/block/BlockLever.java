package net.minecraft.block;

import java.util.Iterator;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockLever extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB LEVER_DOWN_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB LEVER_SOUTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB LEVER_NORTH_AABB;
   // $FF: synthetic field
   public static final PropertyEnum<BlockLever.EnumOrientation> FACING;
   // $FF: synthetic field
   public static final PropertyBool POWERED;
   // $FF: synthetic field
   protected static final AxisAlignedBB LEVER_EAST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB LEVER_WEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB LEVER_UP_AABB;

   private boolean checkCanSurvive(World var1, BlockPos var2, IBlockState var3) {
      if (this.canPlaceBlockAt(var1, var2)) {
         return (boolean)" ".length();
      } else {
         this.dropBlockAsItem(var1, var2, var3, "".length());
         var1.setBlockToAir(var2);
         I["  ".length()].length();
         I["   ".length()].length();
         return (boolean)"".length();
      }
   }

   static {
      I();
      FACING = PropertyEnum.create(I[111 ^ 116], BlockLever.EnumOrientation.class);
      POWERED = PropertyBool.create(I[22 ^ 10]);
      LEVER_NORTH_AABB = new AxisAlignedBB(0.3125D, 0.20000000298023224D, 0.625D, 0.6875D, 0.800000011920929D, 1.0D);
      LEVER_SOUTH_AABB = new AxisAlignedBB(0.3125D, 0.20000000298023224D, 0.0D, 0.6875D, 0.800000011920929D, 0.375D);
      LEVER_WEST_AABB = new AxisAlignedBB(0.625D, 0.20000000298023224D, 0.3125D, 1.0D, 0.800000011920929D, 0.6875D);
      LEVER_EAST_AABB = new AxisAlignedBB(0.0D, 0.20000000298023224D, 0.3125D, 0.375D, 0.800000011920929D, 0.6875D);
      LEVER_UP_AABB = new AxisAlignedBB(0.25D, 0.0D, 0.25D, 0.75D, 0.6000000238418579D, 0.75D);
      LEVER_DOWN_AABB = new AxisAlignedBB(0.25D, 0.4000000059604645D, 0.25D, 0.75D, 1.0D, 0.75D);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, BlockLever.EnumOrientation.byMetadata(var1 & (57 ^ 62)));
      PropertyBool var10001 = POWERED;
      int var10002;
      if ((var1 & (5 ^ 13)) > 0) {
         var10002 = " ".length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         switch(null.$SwitchMap$net$minecraft$block$BlockLever$EnumOrientation[((BlockLever.EnumOrientation)var1.getValue(FACING)).ordinal()]) {
         case 1:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.WEST);
         case 2:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.EAST);
         case 3:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.NORTH);
         case 4:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.SOUTH);
         default:
            return var1;
         }
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockLever$EnumOrientation[((BlockLever.EnumOrientation)var1.getValue(FACING)).ordinal()]) {
         case 1:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.NORTH);
         case 2:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.SOUTH);
         case 3:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.EAST);
         case 4:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.WEST);
         case 5:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.UP_X);
         case 6:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.UP_Z);
         case 7:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.DOWN_Z);
         case 8:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.DOWN_X);
         }
      case 3:
         switch(null.$SwitchMap$net$minecraft$block$BlockLever$EnumOrientation[((BlockLever.EnumOrientation)var1.getValue(FACING)).ordinal()]) {
         case 1:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.SOUTH);
         case 2:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.NORTH);
         case 3:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.WEST);
         case 4:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.EAST);
         case 5:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.UP_X);
         case 6:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.UP_Z);
         case 7:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.DOWN_Z);
         case 8:
            return var1.withProperty(FACING, BlockLever.EnumOrientation.DOWN_X);
         }
      default:
         return var1;
      }
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[2 ^ 5];
      String var10001 = I[61 ^ 53];
      String var10002 = I[155 ^ 146];
      var10001 = I[141 ^ 135];
      var10000 = I[91 ^ 80];
      var10001 = I[40 ^ 36];
      var10002 = I[43 ^ 38];
      var10001 = I[152 ^ 150];
      var10000 = I[207 ^ 192];
      var10001 = I[27 ^ 11];
      var10002 = I[29 ^ 12];
      var10001 = I[33 ^ 51];
      I[108 ^ 127].length();
      I[67 ^ 87].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[152 ^ 141].length();
      I[182 ^ 160].length();
      I[214 ^ 193].length();
      var10003["".length()] = FACING;
      I[3 ^ 27].length();
      I[118 ^ 111].length();
      I[167 ^ 189].length();
      var10003[" ".length()] = POWERED;
      return new BlockStateContainer(this, var10003);
   }

   private static void I() {
      I = new String[137 ^ 148];
      I["".length()] = I("撎漀喼壖", "grOko");
      I[" ".length()] = I("洍应嶏厄", "pyKGw");
      I["  ".length()] = I("峲倨懔堖", "Tktuk");
      I["   ".length()] = I("备戧暨力曺", "jULhJ");
      I[40 ^ 44] = I("樯屑嫍", "iXssP");
      I[51 ^ 54] = I("刻楢", "cYOlC");
      I[138 ^ 140] = I("湂潒", "AnxfP");
      I[166 ^ 161] = I("峣慁", "dMUUI");
      I[34 ^ 42] = I("份垑", "Wlwuu");
      I[54 ^ 63] = I("囊孀", "ZQiWU");
      I[25 ^ 19] = I("厰漫", "mNXeY");
      I[180 ^ 191] = I("兠棓", "myjpP");
      I[190 ^ 178] = I("岰剑", "ieLSu");
      I[8 ^ 5] = I("歴亶", "cqWGs");
      I[182 ^ 184] = I("垕桏", "HjiwJ");
      I[48 ^ 63] = I("宋淦", "QLrxy");
      I[191 ^ 175] = I("奔欢", "fmsno");
      I[188 ^ 173] = I("澾倐", "OjKhr");
      I[21 ^ 7] = I("懪懺", "Tnwnv");
      I[102 ^ 117] = I("僩忤愼", "TkDTd");
      I[57 ^ 45] = I("坉樨", "fzvZQ");
      I[2 ^ 23] = I("嫁刟", "SBxYs");
      I[26 ^ 12] = I("楅", "kaCzF");
      I[72 ^ 95] = I("卩呥咸偤", "NdFoL");
      I[109 ^ 117] = I("摌", "OYpIo");
      I[178 ^ 171] = I("庲捏坟慂彩", "puklE");
      I[42 ^ 48] = I("囎把哶埊", "aoWkr");
      I[4 ^ 31] = I("\u0007\u00183\u0013&\u0006", "ayPzH");
      I[80 ^ 76] = I("\u001b\u0018&)\u0014\u000e\u0013", "kwQLf");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 != 4);

      throw null;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation(((BlockLever.EnumOrientation)var1.getValue(FACING)).getFacing()));
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      IBlockState var9 = this.getDefaultState().withProperty(POWERED, Boolean.valueOf((boolean)"".length()));
      if (canAttachTo(var1, var2, var3)) {
         return var9.withProperty(FACING, BlockLever.EnumOrientation.forFacings(var3, var8.getHorizontalFacing()));
      } else {
         Iterator var10 = EnumFacing.Plane.HORIZONTAL.iterator();

         do {
            if (!var10.hasNext()) {
               if (var1.getBlockState(var2.down()).isFullyOpaque()) {
                  return var9.withProperty(FACING, BlockLever.EnumOrientation.forFacings(EnumFacing.UP, var8.getHorizontalFacing()));
               }

               return var9;
            }

            EnumFacing var11 = (EnumFacing)var10.next();
            if (var11 != var3 && canAttachTo(var1, var2, var11)) {
               return var9.withProperty(FACING, BlockLever.EnumOrientation.forFacings(var11, var8.getHorizontalFacing()));
            }

            "".length();
         } while(4 != -1);

         throw null;
      }
   }

   public boolean canProvidePower(IBlockState var1) {
      return (boolean)" ".length();
   }

   protected static boolean canAttachTo(World var0, BlockPos var1, EnumFacing var2) {
      return BlockButton.canPlaceBlock(var0, var1, var2);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean canPlaceBlockOnSide(World var1, BlockPos var2, EnumFacing var3) {
      return canAttachTo(var1, var2, var3);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         var3 = var3.cycleProperty(POWERED);
         var1.setBlockState(var2, var3, "   ".length());
         I[178 ^ 182].length();
         I[143 ^ 138].length();
         I[183 ^ 177].length();
         float var10000;
         if ((Boolean)var3.getValue(POWERED)) {
            var10000 = 0.6F;
            "".length();
            if (0 >= 2) {
               throw null;
            }
         } else {
            var10000 = 0.5F;
         }

         float var10 = var10000;
         var1.playSound((EntityPlayer)null, var2, SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.BLOCKS, 0.3F, var10);
         var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
         EnumFacing var11 = ((BlockLever.EnumOrientation)var3.getValue(FACING)).getFacing();
         var1.notifyNeighborsOfStateChange(var2.offset(var11.getOpposite()), this, (boolean)"".length());
         return (boolean)" ".length();
      }
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (this.checkCanSurvive(var2, var3, var1) && !canAttachTo(var2, var3, ((BlockLever.EnumOrientation)var1.getValue(FACING)).getFacing())) {
         this.dropBlockAsItem(var2, var3, var1, "".length());
         var2.setBlockToAir(var3);
         I["".length()].length();
         I[" ".length()].length();
      }

   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      EnumFacing[] var3 = EnumFacing.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return (boolean)"".length();
         }

         EnumFacing var6 = var3[var5];
         if (canAttachTo(var1, var2, var6)) {
            return (boolean)" ".length();
         }

         ++var5;
         "".length();
      } while(-1 < 0);

      throw null;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$block$BlockLever$EnumOrientation[((BlockLever.EnumOrientation)var1.getValue(FACING)).ordinal()]) {
      case 1:
      default:
         return LEVER_EAST_AABB;
      case 2:
         return LEVER_WEST_AABB;
      case 3:
         return LEVER_SOUTH_AABB;
      case 4:
         return LEVER_NORTH_AABB;
      case 5:
      case 6:
         return LEVER_UP_AABB;
      case 7:
      case 8:
         return LEVER_DOWN_AABB;
      }
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((BlockLever.EnumOrientation)var1.getValue(FACING)).getMetadata();
      if ((Boolean)var1.getValue(POWERED)) {
         var2 |= 173 ^ 165;
      }

      return var2;
   }

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if ((Boolean)var1.getValue(POWERED)) {
         var10000 = 152 ^ 151;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      if ((Boolean)var3.getValue(POWERED)) {
         var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
         EnumFacing var4 = ((BlockLever.EnumOrientation)var3.getValue(FACING)).getFacing();
         var1.notifyNeighborsOfStateChange(var2.offset(var4.getOpposite()), this, (boolean)"".length());
      }

      super.breakBlock(var1, var2, var3);
   }

   protected BlockLever() {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, BlockLever.EnumOrientation.NORTH).withProperty(POWERED, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.REDSTONE);
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (!(Boolean)var1.getValue(POWERED)) {
         return "".length();
      } else {
         int var10000;
         if (((BlockLever.EnumOrientation)var1.getValue(FACING)).getFacing() == var4) {
            var10000 = 108 ^ 99;
            "".length();
            if (3 >= 4) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return var10000;
      }
   }

   public static enum EnumOrientation implements IStringSerializable {
      // $FF: synthetic field
      DOWN_Z;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      NORTH,
      // $FF: synthetic field
      EAST;

      // $FF: synthetic field
      private final EnumFacing facing;
      // $FF: synthetic field
      UP_X,
      // $FF: synthetic field
      WEST,
      // $FF: synthetic field
      DOWN_X,
      // $FF: synthetic field
      SOUTH,
      // $FF: synthetic field
      UP_Z;

      // $FF: synthetic field
      private final int meta;

      public String getName() {
         return this.name;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > 1);

         throw null;
      }

      private EnumOrientation(int var3, String var4, EnumFacing var5) {
         this.meta = var3;
         this.name = var4;
         this.facing = var5;
      }

      public static BlockLever.EnumOrientation forFacings(EnumFacing var0, EnumFacing var1) {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         var10000 = I[85 ^ 81];
         var10001 = I[11 ^ 14];
         var10002 = I[140 ^ 138];
         var10001 = I[60 ^ 59];
         var10000 = I[203 ^ 195];
         var10001 = I[187 ^ 178];
         var10002 = I[34 ^ 40];
         var10001 = I[163 ^ 168];
         var10000 = I[135 ^ 139];
         var10001 = I[4 ^ 9];
         var10002 = I[53 ^ 59];
         var10001 = I[171 ^ 164];
         var10000 = I[124 ^ 108];
         var10001 = I[133 ^ 148];
         var10002 = I[134 ^ 148];
         var10001 = I[118 ^ 101];
         var10000 = I[149 ^ 129];
         var10001 = I[173 ^ 184];
         var10002 = I[119 ^ 97];
         var10001 = I[102 ^ 113];
         IllegalArgumentException var2;
         switch(null.$SwitchMap$net$minecraft$util$EnumFacing[var0.ordinal()]) {
         case 1:
            switch(null.$SwitchMap$net$minecraft$util$EnumFacing$Axis[var1.getAxis().ordinal()]) {
            case 1:
               return DOWN_X;
            case 2:
               return DOWN_Z;
            default:
               I[13 ^ 21].length();
               I[128 ^ 153].length();
               I[40 ^ 50].length();
               I[106 ^ 113].length();
               I[111 ^ 115].length();
               var2 = new IllegalArgumentException(I[71 ^ 90] + var1 + I[61 ^ 35] + var0);
               I[219 ^ 196].length();
               I[122 ^ 90].length();
               I[179 ^ 146].length();
               I[136 ^ 170].length();
               I[163 ^ 128].length();
               throw var2;
            }
         case 2:
            switch(null.$SwitchMap$net$minecraft$util$EnumFacing$Axis[var1.getAxis().ordinal()]) {
            case 1:
               return UP_X;
            case 2:
               return UP_Z;
            default:
               I[105 ^ 77].length();
               I[127 ^ 90].length();
               I[57 ^ 31].length();
               I[116 ^ 83].length();
               I[133 ^ 173].length();
               I[122 ^ 83].length();
               var2 = new IllegalArgumentException(I[97 ^ 75] + var1 + I[140 ^ 167] + var0);
               I[47 ^ 3].length();
               I[48 ^ 29].length();
               throw var2;
            }
         case 3:
            return NORTH;
         case 4:
            return SOUTH;
         case 5:
            return WEST;
         case 6:
            return EAST;
         default:
            I[112 ^ 94].length();
            I[11 ^ 36].length();
            I[37 ^ 21].length();
            I[50 ^ 3].length();
            var2 = new IllegalArgumentException(I[27 ^ 41] + var0);
            I[163 ^ 144].length();
            I[168 ^ 156].length();
            I[143 ^ 186].length();
            I[147 ^ 165].length();
            throw var2;
         }
      }

      static {
         I();
         DOWN_X = new BlockLever.EnumOrientation(I[29 ^ 42], "".length(), "".length(), I[144 ^ 168], EnumFacing.DOWN);
         EAST = new BlockLever.EnumOrientation(I[182 ^ 143], " ".length(), " ".length(), I[132 ^ 190], EnumFacing.EAST);
         WEST = new BlockLever.EnumOrientation(I[191 ^ 132], "  ".length(), "  ".length(), I[253 ^ 193], EnumFacing.WEST);
         SOUTH = new BlockLever.EnumOrientation(I[181 ^ 136], "   ".length(), "   ".length(), I[161 ^ 159], EnumFacing.SOUTH);
         NORTH = new BlockLever.EnumOrientation(I[81 ^ 110], 71 ^ 67, 118 ^ 114, I[59 ^ 123], EnumFacing.NORTH);
         UP_Z = new BlockLever.EnumOrientation(I[55 ^ 118], 49 ^ 52, 103 ^ 98, I[95 ^ 29], EnumFacing.UP);
         UP_X = new BlockLever.EnumOrientation(I[229 ^ 166], 32 ^ 38, 14 ^ 8, I[97 ^ 37], EnumFacing.UP);
         DOWN_Z = new BlockLever.EnumOrientation(I[107 ^ 46], 131 ^ 132, 185 ^ 190, I[102 ^ 32], EnumFacing.DOWN);
         BlockLever.EnumOrientation[] var10000 = new BlockLever.EnumOrientation[40 ^ 32];
         var10000["".length()] = DOWN_X;
         var10000[" ".length()] = EAST;
         var10000["  ".length()] = WEST;
         var10000["   ".length()] = SOUTH;
         var10000[134 ^ 130] = NORTH;
         var10000[83 ^ 86] = UP_Z;
         var10000[132 ^ 130] = UP_X;
         var10000[116 ^ 115] = DOWN_Z;
         BlockLever.EnumOrientation[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockLever.EnumOrientation var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(3 > -1);

         throw null;
      }

      public EnumFacing getFacing() {
         return this.facing;
      }

      private static void I() {
         I = new String[106 ^ 45];
         I["".length()] = I("壜垀", "bGYkb");
         I[" ".length()] = I("俥幨", "eEIoD");
         I["  ".length()] = I("丂唼", "kCsAp");
         I["   ".length()] = I("欆愐", "qDULs");
         I[21 ^ 17] = I("唸墫", "twjUy");
         I[6 ^ 3] = I("掫棹", "KjIxx");
         I[25 ^ 31] = I("住懥", "Keaqj");
         I[139 ^ 140] = I("僱婨", "WfGub");
         I[76 ^ 68] = I("儼椌", "GHeBN");
         I[146 ^ 155] = I("嶤懰", "xJKzB");
         I[157 ^ 151] = I("墙敕", "RmLIQ");
         I[1 ^ 10] = I("泙檖", "dbDkJ");
         I[8 ^ 4] = I("徃姍", "MQciU");
         I[150 ^ 155] = I("払朼", "BDZpB");
         I[43 ^ 37] = I("恇溞", "qkwym");
         I[102 ^ 105] = I("濳嗡", "oqKSO");
         I[82 ^ 66] = I("渃囕", "YXCgC");
         I[147 ^ 130] = I("巿周", "KhbzC");
         I[37 ^ 55] = I("浕丢", "HuXBo");
         I[214 ^ 197] = I("楐埥", "GGPKe");
         I[70 ^ 82] = I("极捧", "hmVMj");
         I[133 ^ 144] = I("囀佲", "pqheL");
         I[49 ^ 39] = I("淁煼", "NYEBE");
         I[173 ^ 186] = I("椚埙", "FIZmF");
         I[149 ^ 141] = I("嚯开斫劌恍", "mOBgs");
         I[162 ^ 187] = I("墀嚢殎", "TBowr");
         I[66 ^ 88] = I("摸", "VlfHL");
         I[49 ^ 42] = I("夏廤", "xXcrR");
         I[51 ^ 47] = I("妴槼油塇亣", "lBBXJ");
         I[38 ^ 59] = I("\u001c\u001e2)6<\u0014d-4!\u001901\u001c4\u0013-&=u", "UpDHZ");
         I[66 ^ 92] = I("P#\f\u001co\u0016$\u0000\u0007!\u0017e", "pEcnO");
         I[48 ^ 47] = I("囫叛澯", "XisTs");
         I[139 ^ 171] = I("晟", "pCoOr");
         I[5 ^ 36] = I("墳姮敡奲曜", "PHCvd");
         I[73 ^ 107] = I("泎徣戌澐", "NwbuH");
         I[146 ^ 177] = I("椈啽壃倞儽", "wncPA");
         I[78 ^ 106] = I("灟妡匞斾", "mCjTQ");
         I[125 ^ 88] = I("劏冧愡岵儯", "DCzdv");
         I[147 ^ 181] = I("湼", "zEira");
         I[34 ^ 5] = I("儜濍柽", "QOChQ");
         I[58 ^ 18] = I("巴拫坅淎岟", "gvIpo");
         I[127 ^ 86] = I("榫", "EhtnU");
         I[131 ^ 169] = I("+;<,\u001d\u000b1j(\u001f\u0016<>47\u00036##\u0016B", "bUJMq");
         I[160 ^ 139] = I("k\u0014\u0015\u0002Z-\u0013\u0019\u0019\u0014,R", "Krzpz");
         I[135 ^ 171] = I("敧椘屘滎徸", "ZsIeS");
         I[166 ^ 139] = I("暦啔", "OJMGM");
         I[128 ^ 174] = I("淀榍撶勿悚", "pJCUQ");
         I[61 ^ 18] = I("炢瀔", "lAFGs");
         I[101 ^ 85] = I("嶂", "RkmNc");
         I[74 ^ 123] = I("戝尝于姛坔", "LdVwN");
         I[52 ^ 6] = I("\u0019?.\u0017\r95x\u0010\u0000386\u0011[p", "PQXva");
         I[1 ^ 50] = I("夛榴吻淏函", "BHNYy");
         I[49 ^ 5] = I("暘奐嘔凾", "RZkkg");
         I[89 ^ 108] = I("儽殬扌拣惕", "IsQUG");
         I[21 ^ 35] = I("哃毸溺唠", "zkhle");
         I[178 ^ 133] = I("\u0012,\u001b:\u0019\u000e", "VcLtF");
         I[142 ^ 182] = I("-)39'1", "IFDWx");
         I[1 ^ 56] = I("\u0014\u001272", "QSdfl");
         I[91 ^ 97] = I("2\f8;", "WmKOa");
         I[120 ^ 67] = I("/?\u0002-", "xzQyq");
         I[168 ^ 148] = I("\u00160'\u001d", "aUTiW");
         I[16 ^ 45] = I(":\u00064\u0018\t", "iIaLA");
         I[157 ^ 163] = I("\u001f\u0007\u0017#\u000e", "lhbWf");
         I[47 ^ 16] = I("\"\u001d\u0002\u00112", "lRPEz");
         I[76 ^ 12] = I("\u000f\u000b85\u0018", "adJAp");
         I[3 ^ 66] = I("\u0007\u0007\u0015\u0015", "RWJOY");
         I[0 ^ 66] = I("\u00028<\n", "wHcpD");
         I[23 ^ 84] = I("\u0000\u001e\u001d\u0019", "UNBAO");
         I[228 ^ 160] = I("\u000f\n::", "zzeBU");
         I[45 ^ 104] = I("47/\t\n*", "pxxGU");
         I[110 ^ 40] = I("'8\u001f\u0007\u00139", "CWhiL");
      }

      public int getMetadata() {
         return this.meta;
      }

      public String toString() {
         return this.name;
      }

      public static BlockLever.EnumOrientation byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }
   }
}

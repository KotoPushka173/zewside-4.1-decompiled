package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockWoodSlab extends BlockSlab {
   // $FF: synthetic field
   public static final PropertyEnum<BlockPlanks.EnumType> VARIANT;
   // $FF: synthetic field
   private static final String[] I;

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[174 ^ 163];
      String var10001 = I[159 ^ 145];
      String var10002 = I[0 ^ 15];
      var10001 = I[57 ^ 41];
      BlockPlanks.EnumType[] var3 = BlockPlanks.EnumType.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return;
         }

         BlockPlanks.EnumType var6 = var3[var5];
         I[157 ^ 140].length();
         I[86 ^ 68].length();
         I[53 ^ 38].length();
         var2.add(new ItemStack(this, " ".length(), var6.getMetadata()));
         I[11 ^ 31].length();
         I[114 ^ 103].length();
         ++var5;
         "".length();
      } while(4 > 1);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
      if (!this.isDouble() && var1.getValue(HALF) == BlockSlab.EnumBlockHalf.TOP) {
         var2 |= 65 ^ 73;
      }

      return var2;
   }

   public String getUnlocalizedName(int var1) {
      String var10000 = I[70 ^ 64];
      String var10001 = I[43 ^ 44];
      String var10002 = I[71 ^ 79];
      var10001 = I[81 ^ 88];
      I[107 ^ 97].length();
      I[9 ^ 2].length();
      return super.getUnlocalizedName() + I[19 ^ 31] + BlockPlanks.EnumType.byMetadata(var1).getUnlocalizedName();
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[193 ^ 197].length();
      I[120 ^ 125].length();
      return new ItemStack(Blocks.WOODEN_SLAB, " ".length(), ((BlockPlanks.EnumType)var3.getValue(VARIANT)).getMetadata());
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMapColor();
   }

   public Comparable<?> getTypeForItem(ItemStack var1) {
      return BlockPlanks.EnumType.byMetadata(var1.getMetadata() & (47 ^ 40));
   }

   public int damageDropped(IBlockState var1) {
      return ((BlockPlanks.EnumType)var1.getValue(VARIANT)).getMetadata();
   }

   static {
      I();
      VARIANT = PropertyEnum.create(I[57 ^ 12], BlockPlanks.EnumType.class);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[190 ^ 168];
      String var10001 = I[59 ^ 44];
      String var10002 = I[148 ^ 140];
      var10001 = I[9 ^ 16];
      var10000 = I[9 ^ 19];
      var10001 = I[188 ^ 167];
      var10002 = I[27 ^ 7];
      var10001 = I[3 ^ 30];
      var10000 = I[51 ^ 45];
      var10001 = I[89 ^ 70];
      var10002 = I[63 ^ 31];
      var10001 = I[60 ^ 29];
      var10000 = I[38 ^ 4];
      var10001 = I[145 ^ 178];
      var10002 = I[30 ^ 58];
      var10001 = I[144 ^ 181];
      var10000 = I[29 ^ 59];
      var10001 = I[157 ^ 186];
      var10002 = I[44 ^ 4];
      var10001 = I[73 ^ 96];
      BlockStateContainer var1;
      IProperty[] var10003;
      if (this.isDouble()) {
         I[159 ^ 181].length();
         I[129 ^ 170].length();
         I[66 ^ 110].length();
         I[51 ^ 30].length();
         var10003 = new IProperty[" ".length()];
         I[44 ^ 2].length();
         var10003["".length()] = VARIANT;
         var1 = new BlockStateContainer(this, var10003);
         "".length();
         if (4 == -1) {
            throw null;
         }
      } else {
         I[239 ^ 192].length();
         var10003 = new IProperty["  ".length()];
         I[4 ^ 52].length();
         I[160 ^ 145].length();
         var10003["".length()] = HALF;
         I[93 ^ 111].length();
         I[111 ^ 92].length();
         I[19 ^ 39].length();
         var10003[" ".length()] = VARIANT;
         var1 = new BlockStateContainer(this, var10003);
      }

      return var1;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.WOODEN_SLAB);
   }

   private static void I() {
      I = new String[158 ^ 168];
      I["".length()] = I("汐佬", "DFYvP");
      I[" ".length()] = I("敟呟", "xfEwq");
      I["  ".length()] = I("嵢棘", "FyvSq");
      I["   ".length()] = I("尾亍", "ccneN");
      I[159 ^ 155] = I("溚", "LmjaU");
      I[180 ^ 177] = I("倭椙", "yhGeQ");
      I[123 ^ 125] = I("回岶", "MiOvi");
      I[110 ^ 105] = I("崴涔", "NHgAt");
      I[112 ^ 120] = I("勷巎", "ocixG");
      I[137 ^ 128] = I("拥兤", "daMtH");
      I[9 ^ 3] = I("噃堐克炣嬨", "wCupx");
      I[73 ^ 66] = I("姁務", "Vtxgq");
      I[148 ^ 152] = I("k", "EdCbc");
      I[188 ^ 177] = I("旱叟", "DquGY");
      I[32 ^ 46] = I("潑媤", "Ibntj");
      I[143 ^ 128] = I("媳樯", "fNayF");
      I[88 ^ 72] = I("栶殕", "sEUTZ");
      I[31 ^ 14] = I("帿尯欒媈", "TgTKp");
      I[128 ^ 146] = I("弋栩垈懲姁", "ojkbi");
      I[83 ^ 64] = I("檅幗漈潌", "zjtGt");
      I[57 ^ 45] = I("匰嶕", "DAvDc");
      I[127 ^ 106] = I("烧嬴旐憯", "BUFTJ");
      I[209 ^ 199] = I("宑压", "ztkxp");
      I[120 ^ 111] = I("捪啲", "dMnls");
      I[128 ^ 152] = I("埖式", "QGDOl");
      I[81 ^ 72] = I("樶冄", "wtWMO");
      I[27 ^ 1] = I("奿侏", "geyZK");
      I[110 ^ 117] = I("悈淧", "LUAdC");
      I[184 ^ 164] = I("汣橢", "cNdKg");
      I[9 ^ 20] = I("弅柂", "DCrMe");
      I[80 ^ 78] = I("冕椞", "rgLpb");
      I[55 ^ 40] = I("抆帐", "GAMyG");
      I[117 ^ 85] = I("姍烝", "XZeeD");
      I[136 ^ 169] = I("劬拴", "blQzn");
      I[27 ^ 57] = I("檯二", "eWhLX");
      I[38 ^ 5] = I("晈浌", "NvsFl");
      I[59 ^ 31] = I("幊儱", "IYnrz");
      I[127 ^ 90] = I("櫗揶", "wqsLF");
      I[101 ^ 67] = I("儛澒", "uOkKH");
      I[102 ^ 65] = I("構初", "YDWbR");
      I[0 ^ 40] = I("劳农", "VArOc");
      I[21 ^ 60] = I("椸仔", "jRrut");
      I[58 ^ 16] = I("渘愳嘩忀匎", "JMQkk");
      I[118 ^ 93] = I("橧湐", "JcFuj");
      I[63 ^ 19] = I("妧", "EpFmC");
      I[133 ^ 168] = I("愆坳丱斢棳", "tXApZ");
      I[123 ^ 85] = I("嘞媨洲沇啃", "UYVBw");
      I[183 ^ 152] = I("椇敩厒嬋掓", "tvEgO");
      I[10 ^ 58] = I("满夈捭曊椫", "ZvhDt");
      I[62 ^ 15] = I("抴儭峫媻曂", "vTCND");
      I[22 ^ 36] = I("抧烸佲幨", "pznIt");
      I[101 ^ 86] = I("殊康樭", "lqGNj");
      I[35 ^ 23] = I("剛伞无尷嗐", "xkuws");
      I[24 ^ 45] = I("4/\u0001*\u0017,:", "BNsCv");
   }

   public BlockWoodSlab() {
      super(Material.WOOD);
      IBlockState var1 = this.blockState.getBaseState();
      if (!this.isDouble()) {
         var1 = var1.withProperty(HALF, BlockSlab.EnumBlockHalf.BOTTOM);
      }

      this.setDefaultState(var1.withProperty(VARIANT, BlockPlanks.EnumType.OAK));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public IProperty<?> getVariantProperty() {
      return VARIANT;
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var2 = this.getDefaultState().withProperty(VARIANT, BlockPlanks.EnumType.byMetadata(var1 & (123 ^ 124)));
      if (!this.isDouble()) {
         PropertyEnum var10001 = HALF;
         BlockSlab.EnumBlockHalf var10002;
         if ((var1 & (88 ^ 80)) == 0) {
            var10002 = BlockSlab.EnumBlockHalf.BOTTOM;
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10002 = BlockSlab.EnumBlockHalf.TOP;
         }

         var2 = var2.withProperty(var10001, var10002);
      }

      return var2;
   }
}

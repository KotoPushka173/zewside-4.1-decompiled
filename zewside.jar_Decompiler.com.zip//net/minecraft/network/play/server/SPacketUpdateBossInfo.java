package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.UUID;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.BossInfo;

public class SPacketUpdateBossInfo implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private ITextComponent name;
   // $FF: synthetic field
   private boolean createFog;
   // $FF: synthetic field
   private boolean playEndBossMusic;
   // $FF: synthetic field
   private BossInfo.Overlay overlay;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private BossInfo.Color color;
   // $FF: synthetic field
   private UUID uniqueId;
   // $FF: synthetic field
   private float percent;
   // $FF: synthetic field
   private boolean darkenSky;
   // $FF: synthetic field
   private SPacketUpdateBossInfo.Operation operation;

   private void setFlags(int var1) {
      int var10001;
      if ((var1 & " ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (2 <= 0) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.darkenSky = (boolean)var10001;
      if ((var1 & "  ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (0 <= -1) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.playEndBossMusic = (boolean)var10001;
      if ((var1 & "  ".length()) > 0) {
         var10001 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.createFog = (boolean)var10001;
   }

   public SPacketUpdateBossInfo() {
   }

   public boolean shouldDarkenSky() {
      return this.darkenSky;
   }

   public BossInfo.Overlay getOverlay() {
      return this.overlay;
   }

   public float getPercent() {
      return this.percent;
   }

   public boolean shouldPlayEndBossMusic() {
      return this.playEndBossMusic;
   }

   public SPacketUpdateBossInfo(SPacketUpdateBossInfo.Operation var1, BossInfo var2) {
      this.operation = var1;
      this.uniqueId = var2.getUniqueId();
      this.name = var2.getName();
      this.percent = var2.getPercent();
      this.color = var2.getColor();
      this.overlay = var2.getOverlay();
      this.darkenSky = var2.shouldDarkenSky();
      this.playEndBossMusic = var2.shouldPlayEndBossMusic();
      this.createFog = var2.shouldCreateFog();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.uniqueId = var1.readUuid();
      this.operation = (SPacketUpdateBossInfo.Operation)var1.readEnumValue(SPacketUpdateBossInfo.Operation.class);
      switch(null.$SwitchMap$net$minecraft$network$play$server$SPacketUpdateBossInfo$Operation[this.operation.ordinal()]) {
      case 1:
         this.name = var1.readTextComponent();
         this.percent = var1.readFloat();
         this.color = (BossInfo.Color)var1.readEnumValue(BossInfo.Color.class);
         this.overlay = (BossInfo.Overlay)var1.readEnumValue(BossInfo.Overlay.class);
         this.setFlags(var1.readUnsignedByte());
      case 2:
      default:
         "".length();
         if (2 == 1) {
            throw null;
         }
         break;
      case 3:
         this.percent = var1.readFloat();
         "".length();
         if (4 <= 2) {
            throw null;
         }
         break;
      case 4:
         this.name = var1.readTextComponent();
         "".length();
         if (0 == 4) {
            throw null;
         }
         break;
      case 5:
         this.color = (BossInfo.Color)var1.readEnumValue(BossInfo.Color.class);
         this.overlay = (BossInfo.Overlay)var1.readEnumValue(BossInfo.Overlay.class);
         "".length();
         if (1 == -1) {
            throw null;
         }
         break;
      case 6:
         this.setFlags(var1.readUnsignedByte());
      }

   }

   public UUID getUniqueId() {
      return this.uniqueId;
   }

   public boolean shouldCreateFog() {
      return this.createFog;
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public SPacketUpdateBossInfo.Operation getOperation() {
      return this.operation;
   }

   private int getFlags() {
      int var1 = "".length();
      if (this.darkenSky) {
         var1 |= " ".length();
      }

      if (this.playEndBossMusic) {
         var1 |= "  ".length();
      }

      if (this.createFog) {
         var1 |= "  ".length();
      }

      return var1;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleUpdateEntityNBT(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeUuid(this.uniqueId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeEnumValue(this.operation);
      I["   ".length()].length();
      I[136 ^ 140].length();
      I[94 ^ 91].length();
      switch(null.$SwitchMap$net$minecraft$network$play$server$SPacketUpdateBossInfo$Operation[this.operation.ordinal()]) {
      case 1:
         var1.writeTextComponent(this.name);
         I[83 ^ 85].length();
         I[91 ^ 92].length();
         I[175 ^ 167].length();
         I[188 ^ 181].length();
         I[136 ^ 130].length();
         var1.writeFloat(this.percent);
         I[202 ^ 193].length();
         I[31 ^ 19].length();
         var1.writeEnumValue(this.color);
         I[65 ^ 76].length();
         I[50 ^ 60].length();
         var1.writeEnumValue(this.overlay);
         I[48 ^ 63].length();
         I[109 ^ 125].length();
         I[91 ^ 74].length();
         var1.writeByte(this.getFlags());
         I[80 ^ 66].length();
         I[189 ^ 174].length();
         I[180 ^ 160].length();
      case 2:
      default:
         "".length();
         if (4 <= -1) {
            throw null;
         }
         break;
      case 3:
         var1.writeFloat(this.percent);
         I[82 ^ 71].length();
         I[77 ^ 91].length();
         I[11 ^ 28].length();
         "".length();
         if (0 >= 2) {
            throw null;
         }
         break;
      case 4:
         var1.writeTextComponent(this.name);
         I[138 ^ 146].length();
         I[52 ^ 45].length();
         I[56 ^ 34].length();
         I[191 ^ 164].length();
         "".length();
         if (2 == -1) {
            throw null;
         }
         break;
      case 5:
         var1.writeEnumValue(this.color);
         I[49 ^ 45].length();
         I[60 ^ 33].length();
         I[219 ^ 197].length();
         var1.writeEnumValue(this.overlay);
         I[54 ^ 41].length();
         I[17 ^ 49].length();
         I[111 ^ 78].length();
         "".length();
         if (2 < -1) {
            throw null;
         }
         break;
      case 6:
         var1.writeByte(this.getFlags());
         I[86 ^ 116].length();
         I[146 ^ 177].length();
         I[7 ^ 35].length();
      }

   }

   public BossInfo.Color getColor() {
      return this.color;
   }

   public ITextComponent getName() {
      return this.name;
   }

   private static void I() {
      I = new String[190 ^ 155];
      I["".length()] = I("撿噔", "ggvij");
      I[" ".length()] = I("撚氰勷唜", "DcPmf");
      I["  ".length()] = I("垆抦散杤", "spBPk");
      I["   ".length()] = I("烡媨労暁庻", "NgIYD");
      I[191 ^ 187] = I("尫瀙", "zpzzZ");
      I[105 ^ 108] = I("懒檇泅氾奂", "zwfyS");
      I[162 ^ 164] = I("棉娀", "RVjDC");
      I[122 ^ 125] = I("哅彳埢", "PjUcw");
      I[116 ^ 124] = I("刄煎", "AZcNi");
      I[45 ^ 36] = I("瀸斥椬呙樈", "RmtAE");
      I[115 ^ 121] = I("匮栰", "qTwEy");
      I[44 ^ 39] = I("梦困", "jvMwI");
      I[120 ^ 116] = I("嫊歆浵擜暣", "CcApV");
      I[179 ^ 190] = I("卢丰嫌", "NtOEw");
      I[172 ^ 162] = I("潈朸愩曇体", "celih");
      I[114 ^ 125] = I("濣", "PvMWa");
      I[72 ^ 88] = I("傶憘檲條挽", "tUgGq");
      I[215 ^ 198] = I("楪墴", "AsoRa");
      I[171 ^ 185] = I("惲汇椇栏", "YtxZi");
      I[186 ^ 169] = I("效亥技並浗", "wvUiy");
      I[120 ^ 108] = I("浥個摇剣", "FdFkT");
      I[60 ^ 41] = I("婖寻", "OgshY");
      I[182 ^ 160] = I("偏恢叠", "UxHkQ");
      I[147 ^ 132] = I("右仉敏灜孙", "xabCk");
      I[111 ^ 119] = I("歖拘刍枫", "YoPHv");
      I[157 ^ 132] = I("帅搻挑", "GZPPZ");
      I[5 ^ 31] = I("壹奅墂彉匇", "CBlXL");
      I[149 ^ 142] = I("枬搢僄嵍", "fJQIV");
      I[59 ^ 39] = I("啨悭屷匆毊", "wNoNz");
      I[87 ^ 74] = I("拀柩儗", "vqIro");
      I[127 ^ 97] = I("屦", "Kfmgx");
      I[150 ^ 137] = I("椺廌", "PEBHh");
      I[148 ^ 180] = I("刟揨抰", "nfHNd");
      I[227 ^ 194] = I("殢", "YSSjB");
      I[161 ^ 131] = I("悃恹", "GIokn");
      I[155 ^ 184] = I("咷", "WEujj");
      I[16 ^ 52] = I("廒嘛", "XGVsK");
   }

   public static enum Operation {
      // $FF: synthetic field
      ADD,
      // $FF: synthetic field
      UPDATE_STYLE,
      // $FF: synthetic field
      REMOVE,
      // $FF: synthetic field
      UPDATE_PROPERTIES,
      // $FF: synthetic field
      UPDATE_PCT;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      UPDATE_NAME;

      private static void I() {
         I = new String[170 ^ 172];
         I["".length()] = I("(-7", "iisVb");
         I[" ".length()] = I("*\n\u0018$\u0015=", "xOUkC");
         I["  ".length()] = I(" 1\b3\u00030>\u001c1\u0003", "uaLrW");
         I["   ".length()] = I(">\u0012\u0017\u0007\u0003.\u001d\u001d\u0007\u001a.", "kBSFW");
         I[19 ^ 23] = I("125\u001b\r!=\"\u000e\u0000('", "dbqZY");
         I[30 ^ 27] = I("\u0006\u001b\u001e\u0014\u0011\u0016\u0014\n\u0007\n\u0003\u000e\b\u0001\f\u0016\u0018", "SKZUE");
      }

      static {
         I();
         ADD = new SPacketUpdateBossInfo.Operation(I["".length()], "".length());
         REMOVE = new SPacketUpdateBossInfo.Operation(I[" ".length()], " ".length());
         UPDATE_PCT = new SPacketUpdateBossInfo.Operation(I["  ".length()], "  ".length());
         UPDATE_NAME = new SPacketUpdateBossInfo.Operation(I["   ".length()], "   ".length());
         UPDATE_STYLE = new SPacketUpdateBossInfo.Operation(I[149 ^ 145], 92 ^ 88);
         UPDATE_PROPERTIES = new SPacketUpdateBossInfo.Operation(I[1 ^ 4], 110 ^ 107);
         SPacketUpdateBossInfo.Operation[] var10000 = new SPacketUpdateBossInfo.Operation[66 ^ 68];
         var10000["".length()] = ADD;
         var10000[" ".length()] = REMOVE;
         var10000["  ".length()] = UPDATE_PCT;
         var10000["   ".length()] = UPDATE_NAME;
         var10000[114 ^ 118] = UPDATE_STYLE;
         var10000[174 ^ 171] = UPDATE_PROPERTIES;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 != 4);

         throw null;
      }
   }
}

package net.minecraft.network.play.server;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.ResourceLocation;

public class SPacketAdvancementInfo implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private boolean field_192605_a;
   // $FF: synthetic field
   private Set<ResourceLocation> field_192607_c;
   // $FF: synthetic field
   private Map<ResourceLocation, Advancement.Builder> field_192606_b;
   // $FF: synthetic field
   private Map<ResourceLocation, AdvancementProgress> field_192608_d;
   // $FF: synthetic field
   private static final String[] I;

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.field_192605_a = var1.readBoolean();
      this.field_192606_b = Maps.newHashMap();
      this.field_192607_c = Sets.newLinkedHashSet();
      this.field_192608_d = Maps.newHashMap();
      int var2 = var1.readVarIntFromBuffer();
      int var3 = "".length();

      do {
         ResourceLocation var4;
         if (var3 >= var2) {
            var2 = var1.readVarIntFromBuffer();
            var3 = "".length();

            do {
               if (var3 >= var2) {
                  var2 = var1.readVarIntFromBuffer();
                  var3 = "".length();

                  do {
                     if (var3 >= var2) {
                        return;
                     }

                     var4 = var1.func_192575_l();
                     this.field_192608_d.put(var4, AdvancementProgress.func_192100_b(var1));
                     I[188 ^ 184].length();
                     I[124 ^ 121].length();
                     I[113 ^ 119].length();
                     ++var3;
                     "".length();
                  } while(-1 >= -1);

                  throw null;
               }

               var4 = var1.func_192575_l();
               this.field_192607_c.add(var4);
               I["  ".length()].length();
               I["   ".length()].length();
               ++var3;
               "".length();
            } while(4 > 0);

            throw null;
         }

         var4 = var1.func_192575_l();
         Advancement.Builder var5 = Advancement.Builder.func_192060_b(var1);
         this.field_192606_b.put(var4, var5);
         I["".length()].length();
         I[" ".length()].length();
         ++var3;
         "".length();
      } while(2 >= 0);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.func_191981_a(this);
   }

   private static void I() {
      I = new String[105 ^ 114];
      I["".length()] = I("检", "hWLuN");
      I[" ".length()] = I("槿传灢垍", "YnkDZ");
      I["  ".length()] = I("堌卬擆", "GTiZi");
      I["   ".length()] = I("唖湦", "tyHMw");
      I[35 ^ 39] = I("壬嘄", "pRVkN");
      I[7 ^ 2] = I("娬憲啯怟宭", "BswkA");
      I[80 ^ 86] = I("一", "NaNEh");
      I[65 ^ 70] = I("格", "xjjjP");
      I[147 ^ 155] = I("埡", "cIFtI");
      I[104 ^ 97] = I("厳奉歔汉", "GAOMr");
      I[71 ^ 77] = I("倅凹", "qlWut");
      I[176 ^ 187] = I("湲楢嘚", "zPKbM");
      I[25 ^ 21] = I("帰召佣", "wTxrK");
      I[86 ^ 91] = I("妪于滣椝杯", "YFVhC");
      I[47 ^ 33] = I("嶲漞", "YTEYA");
      I[102 ^ 105] = I("季", "vXEHc");
      I[6 ^ 22] = I("櫑瀵", "tWNMi");
      I[98 ^ 115] = I("媂尾濾扳擼", "hskpW");
      I[144 ^ 130] = I("洖喊梒櫗壬", "vDgxs");
      I[131 ^ 144] = I("拸噁摩嬱", "jRIfk");
      I[117 ^ 97] = I("婻", "nTNaC");
      I[96 ^ 117] = I("浕毺氅涺尨", "lubIc");
      I[16 ^ 6] = I("卋截喍栎烞", "PcmcH");
      I[183 ^ 160] = I("捆朘岦偑橪", "gDjxH");
      I[104 ^ 112] = I("枎", "geLEq");
      I[221 ^ 196] = I("挕埧您", "sDHJY");
      I[171 ^ 177] = I("勚", "DmFIS");
   }

   public Map<ResourceLocation, AdvancementProgress> func_192604_c() {
      return this.field_192608_d;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 3);

      throw null;
   }

   public SPacketAdvancementInfo() {
   }

   public Map<ResourceLocation, Advancement.Builder> func_192603_a() {
      return this.field_192606_b;
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeBoolean(this.field_192605_a);
      I[8 ^ 15].length();
      var1.writeVarIntToBuffer(this.field_192606_b.size());
      I[143 ^ 135].length();
      I[180 ^ 189].length();
      Iterator var2 = this.field_192606_b.entrySet().iterator();

      do {
         Entry var3;
         if (!var2.hasNext()) {
            var1.writeVarIntToBuffer(this.field_192607_c.size());
            I[130 ^ 143].length();
            I[12 ^ 2].length();
            I[16 ^ 31].length();
            var2 = this.field_192607_c.iterator();

            do {
               if (!var2.hasNext()) {
                  var1.writeVarIntToBuffer(this.field_192608_d.size());
                  I[107 ^ 126].length();
                  I[85 ^ 67].length();
                  I[63 ^ 40].length();
                  var2 = this.field_192608_d.entrySet().iterator();

                  do {
                     if (!var2.hasNext()) {
                        return;
                     }

                     var3 = (Entry)var2.next();
                     var1.func_192572_a((ResourceLocation)var3.getKey());
                     I[155 ^ 131].length();
                     I[77 ^ 84].length();
                     I[150 ^ 140].length();
                     ((AdvancementProgress)var3.getValue()).func_192104_a(var1);
                     "".length();
                  } while(-1 < 3);

                  throw null;
               }

               ResourceLocation var6 = (ResourceLocation)var2.next();
               var1.func_192572_a(var6);
               I[130 ^ 146].length();
               I[99 ^ 114].length();
               I[113 ^ 99].length();
               I[93 ^ 78].length();
               I[75 ^ 95].length();
               "".length();
            } while(3 != 0);

            throw null;
         }

         var3 = (Entry)var2.next();
         ResourceLocation var4 = (ResourceLocation)var3.getKey();
         Advancement.Builder var5 = (Advancement.Builder)var3.getValue();
         var1.func_192572_a(var4);
         I[203 ^ 193].length();
         I[107 ^ 96].length();
         I[82 ^ 94].length();
         var5.func_192057_a(var1);
         "".length();
      } while(4 == 4);

      throw null;
   }

   public boolean func_192602_d() {
      return this.field_192605_a;
   }

   public SPacketAdvancementInfo(boolean var1, Collection<Advancement> var2, Set<ResourceLocation> var3, Map<ResourceLocation, AdvancementProgress> var4) {
      this.field_192605_a = var1;
      this.field_192606_b = Maps.newHashMap();
      Iterator var5 = var2.iterator();

      do {
         if (!var5.hasNext()) {
            this.field_192607_c = var3;
            this.field_192608_d = Maps.newHashMap(var4);
            return;
         }

         Advancement var6 = (Advancement)var5.next();
         this.field_192606_b.put(var6.func_192067_g(), var6.func_192075_a());
         "".length();
      } while(3 != 0);

      throw null;
   }

   public Set<ResourceLocation> func_192600_b() {
      return this.field_192607_c;
   }
}

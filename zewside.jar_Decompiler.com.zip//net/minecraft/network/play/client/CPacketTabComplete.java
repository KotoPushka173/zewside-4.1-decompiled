package net.minecraft.network.play.client;

import java.io.IOException;
import javax.annotation.Nullable;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.util.math.BlockPos;
import org.apache.commons.lang3.StringUtils;

public class CPacketTabComplete implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   @Nullable
   private BlockPos targetBlock;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private boolean hasTargetBlock;
   // $FF: synthetic field
   private String message;

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.message = var1.readStringFromBuffer(13825 + 19301 - 22018 + 21659);
      this.hasTargetBlock = var1.readBoolean();
      boolean var2 = var1.readBoolean();
      if (var2) {
         this.targetBlock = var1.readBlockPos();
      }

   }

   @Nullable
   public BlockPos getTargetBlock() {
      return this.targetBlock;
   }

   public CPacketTabComplete(String var1, @Nullable BlockPos var2, boolean var3) {
      this.message = var1;
      this.targetBlock = var2;
      this.hasTargetBlock = var3;
   }

   public CPacketTabComplete() {
   }

   public boolean hasTargetBlock() {
      return this.hasTargetBlock;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(StringUtils.substring(this.message, "".length(), 7450 + 19750 - 14944 + 20511));
      I["".length()].length();
      I[" ".length()].length();
      var1.writeBoolean(this.hasTargetBlock);
      I["  ".length()].length();
      I["   ".length()].length();
      int var10000;
      if (this.targetBlock != null) {
         var10000 = " ".length();
         "".length();
         if (2 <= 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var2 = var10000;
      var1.writeBoolean((boolean)var2);
      I[98 ^ 102].length();
      I[144 ^ 149].length();
      I[134 ^ 128].length();
      I[22 ^ 17].length();
      if (var2 != 0) {
         var1.writeBlockPos(this.targetBlock);
         I[32 ^ 40].length();
         I[16 ^ 25].length();
         I[97 ^ 107].length();
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 1);

      throw null;
   }

   public String getMessage() {
      return this.message;
   }

   private static void I() {
      I = new String[56 ^ 51];
      I["".length()] = I("林", "txeeG");
      I[" ".length()] = I("字囌", "qkRdn");
      I["  ".length()] = I("任嘶", "tUhOg");
      I["   ".length()] = I("孿曎曥徨", "FMNYw");
      I[141 ^ 137] = I("忲悧剬済予", "YMWAO");
      I[133 ^ 128] = I("孄惘", "qJqjr");
      I[63 ^ 57] = I("橉戾伽恐", "PdkAl");
      I[150 ^ 145] = I("恩嶂", "jajSm");
      I[53 ^ 61] = I("嗼", "oBYVx");
      I[54 ^ 63] = I("枸溏", "KpChF");
      I[11 ^ 1] = I("漈柂摪歾", "Gwcbu");
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processTabComplete(this);
   }

   static {
      I();
   }
}

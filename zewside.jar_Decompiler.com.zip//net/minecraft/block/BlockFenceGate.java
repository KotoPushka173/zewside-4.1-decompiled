package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockFenceGate extends BlockHorizontal {
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_CLOSED_SELECTED_XAXIS;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_COLLIDE_XAXIS_INWALL;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_CLOSED_SELECTED_ZAXIS;
   // $FF: synthetic field
   public static final PropertyBool POWERED;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_COLLIDE_ZAXIS_INWALL;
   // $FF: synthetic field
   public static final PropertyBool OPEN;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_COLLIDE_ZAXIS;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB_COLLIDE_XAXIS;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool IN_WALL;

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static void I() {
      I = new String[237 ^ 193];
      I["".length()] = I("挴囕浤", "IHdJv");
      I[" ".length()] = I("壥灥娭", "FPWdT");
      I["  ".length()] = I("挈嚡圾", "aGGGq");
      I["   ".length()] = I("桝涉", "CGWdZ");
      I[24 ^ 28] = I("暯渲憖柪", "buUmK");
      I[175 ^ 170] = I("峞", "OxLhR");
      I[150 ^ 144] = I("姊撲慉", "GZgYG");
      I[109 ^ 106] = I("庥", "kezcu");
      I[81 ^ 89] = I("灊橖坰沢", "gPArk");
      I[72 ^ 65] = I("洈柲", "mekAQ");
      I[137 ^ 131] = I("妥吶", "aTJOu");
      I[83 ^ 88] = I("朝汓", "LTBnd");
      I[68 ^ 72] = I("剼坑", "HlinA");
      I[191 ^ 178] = I("渻幟", "Uswxe");
      I[105 ^ 103] = I("奄咤", "OJkOn");
      I[56 ^ 55] = I("勰淝", "fzHkD");
      I[51 ^ 35] = I("侥媇", "fiBgW");
      I[66 ^ 83] = I("忋榈", "RmTeF");
      I[9 ^ 27] = I("欨書", "tRVQD");
      I[176 ^ 163] = I("偂岮", "ocNeD");
      I[70 ^ 82] = I("侑妿", "gZlOr");
      I[180 ^ 161] = I("槲敊", "goPYB");
      I[67 ^ 85] = I("廧榫", "cwLIP");
      I[210 ^ 197] = I("嘞沚", "BcVVV");
      I[156 ^ 132] = I("漲崌", "gamdl");
      I[58 ^ 35] = I("厜挒", "WIFmU");
      I[98 ^ 120] = I("嶌岰", "JsqAZ");
      I[170 ^ 177] = I("伧卓", "PXxiF");
      I[53 ^ 41] = I("摑兺", "cIqKh");
      I[29 ^ 0] = I("懠兂嶤", "FLyPw");
      I[152 ^ 134] = I("幐峿汐烺", "zFbrm");
      I[160 ^ 191] = I("啚洷姙沭揲", "ijLEh");
      I[3 ^ 35] = I("叏梓倎", "cQIeM");
      I[174 ^ 143] = I("朘扚氿寰", "UPwgo");
      I[92 ^ 126] = I("卂堐捌岢", "GqiNO");
      I[95 ^ 124] = I("毵", "tYVuj");
      I[166 ^ 130] = I("亴嶄奵", "thgkd");
      I[172 ^ 137] = I("嚆", "JvspE");
      I[136 ^ 174] = I("吺倂厭峼", "ZRdWE");
      I[18 ^ 53] = I("亜", "buHNR");
      I[110 ^ 70] = I("冊厑勹棵", "wpsCY");
      I[116 ^ 93] = I("\u0001%6\u0001", "nUSoy");
      I[46 ^ 4] = I("!6.\u0002(4=", "QYYgZ");
      I[19 ^ 56] = I("')\u000f\u000e5\"+", "NGPyT");
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[23 ^ 30];
      String var10001 = I[11 ^ 1];
      String var10002 = I[105 ^ 98];
      var10001 = I[178 ^ 190];
      var10000 = I[86 ^ 91];
      var10001 = I[76 ^ 66];
      var10002 = I[87 ^ 88];
      var10001 = I[152 ^ 136];
      var10000 = I[146 ^ 131];
      var10001 = I[14 ^ 28];
      var10002 = I[159 ^ 140];
      var10001 = I[187 ^ 175];
      var10000 = I[71 ^ 82];
      var10001 = I[179 ^ 165];
      var10002 = I[10 ^ 29];
      var10001 = I[95 ^ 71];
      var10000 = I[120 ^ 97];
      var10001 = I[5 ^ 31];
      var10002 = I[144 ^ 139];
      var10001 = I[152 ^ 132];
      I[16 ^ 13].length();
      IProperty[] var10003 = new IProperty[155 ^ 159];
      I[9 ^ 23].length();
      I[44 ^ 51].length();
      I[186 ^ 154].length();
      var10003["".length()] = FACING;
      I[181 ^ 148].length();
      I[171 ^ 137].length();
      var10003[" ".length()] = OPEN;
      I[5 ^ 38].length();
      I[109 ^ 73].length();
      var10003["  ".length()] = POWERED;
      I[41 ^ 12].length();
      I[27 ^ 61].length();
      I[160 ^ 135].length();
      I[59 ^ 19].length();
      var10003["   ".length()] = IN_WALL;
      return new BlockStateContainer(this, var10003);
   }

   static {
      I();
      OPEN = PropertyBool.create(I[107 ^ 66]);
      POWERED = PropertyBool.create(I[238 ^ 196]);
      IN_WALL = PropertyBool.create(I[183 ^ 156]);
      AABB_COLLIDE_ZAXIS = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 1.0D, 1.0D, 0.625D);
      AABB_COLLIDE_XAXIS = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 1.0D, 1.0D);
      AABB_COLLIDE_ZAXIS_INWALL = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 1.0D, 0.8125D, 0.625D);
      AABB_COLLIDE_XAXIS_INWALL = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 0.8125D, 1.0D);
      AABB_CLOSED_SELECTED_ZAXIS = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 1.0D, 1.5D, 0.625D);
      AABB_CLOSED_SELECTED_XAXIS = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 1.5D, 1.0D);
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      boolean var9 = var1.isBlockPowered(var2);
      return this.getDefaultState().withProperty(FACING, var8.getHorizontalFacing()).withProperty(OPEN, var9).withProperty(POWERED, var9).withProperty(IN_WALL, Boolean.valueOf((boolean)"".length()));
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      if (var4 != EnumFacing.UP && var4 != EnumFacing.DOWN) {
         BlockFaceShape var10000;
         if (((EnumFacing)var2.getValue(FACING)).getAxis() == var4.rotateY().getAxis()) {
            var10000 = BlockFaceShape.MIDDLE_POLE;
            "".length();
            if (4 <= 3) {
               throw null;
            }
         } else {
            var10000 = BlockFaceShape.UNDEFINED;
         }

         return var10000;
      } else {
         return BlockFaceShape.UNDEFINED;
      }
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (var1.getBlockState(var2.down()).getMaterial().isSolid()) {
         var10000 = super.canPlaceBlockAt(var1, var2);
         "".length();
         if (3 == 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote) {
         boolean var6 = var2.isBlockPowered(var3);
         if ((Boolean)var1.getValue(POWERED) != var6) {
            var2.setBlockState(var3, var1.withProperty(POWERED, var6).withProperty(OPEN, var6), "  ".length());
            I[33 ^ 39].length();
            I[181 ^ 178].length();
            I[125 ^ 117].length();
            if ((Boolean)var1.getValue(OPEN) != var6) {
               EntityPlayer var10001 = (EntityPlayer)null;
               int var10002;
               if (var6) {
                  var10002 = 391 + 379 - 100 + 338;
                  "".length();
                  if (3 == -1) {
                     throw null;
                  }
               } else {
                  var10002 = 4 + 462 - -506 + 42;
               }

               var2.playEvent(var10001, var10002, var3, "".length());
            }
         }
      }

   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if ((Boolean)var3.getValue(OPEN)) {
         var3 = var3.withProperty(OPEN, Boolean.valueOf((boolean)"".length()));
         var1.setBlockState(var2, var3, 206 ^ 196);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
         I[166 ^ 162].length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      } else {
         EnumFacing var10 = EnumFacing.fromAngle((double)var4.rotationYaw);
         if (var3.getValue(FACING) == var10.getOpposite()) {
            var3 = var3.withProperty(FACING, var10);
         }

         var3 = var3.withProperty(OPEN, Boolean.valueOf((boolean)" ".length()));
         var1.setBlockState(var2, var3, 143 ^ 133);
         I[97 ^ 100].length();
      }

      int var10002;
      if ((Boolean)var3.getValue(OPEN)) {
         var10002 = 867 + 645 - 705 + 201;
         "".length();
         if (2 == 1) {
            throw null;
         }
      } else {
         var10002 = 922 + 809 - 884 + 167;
      }

      var1.playEvent(var4, var10002, var2, "".length());
      return (boolean)" ".length();
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      var1 = this.getActualState(var1, var2, var3);
      AxisAlignedBB var10000;
      if ((Boolean)var1.getValue(IN_WALL)) {
         if (((EnumFacing)var1.getValue(FACING)).getAxis() == EnumFacing.Axis.X) {
            var10000 = AABB_COLLIDE_XAXIS_INWALL;
            "".length();
            if (4 <= 0) {
               throw null;
            }
         } else {
            var10000 = AABB_COLLIDE_ZAXIS_INWALL;
         }

         return var10000;
      } else {
         if (((EnumFacing)var1.getValue(FACING)).getAxis() == EnumFacing.Axis.X) {
            var10000 = AABB_COLLIDE_XAXIS;
            "".length();
            if (3 <= 2) {
               throw null;
            }
         } else {
            var10000 = AABB_COLLIDE_ZAXIS;
         }

         return var10000;
      }
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, EnumFacing.byHorizontalIndex(var1));
      PropertyBool var10001 = OPEN;
      int var10002;
      if ((var1 & (126 ^ 122)) != 0) {
         var10002 = " ".length();
         "".length();
         if (0 >= 4) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      var10000 = var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
      var10001 = POWERED;
      if ((var1 & (122 ^ 114)) != 0) {
         var10002 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      return (Boolean)var1.getBlockState(var2).getValue(OPEN);
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getHorizontalIndex();
      if ((Boolean)var1.getValue(POWERED)) {
         var2 |= 177 ^ 185;
      }

      if ((Boolean)var1.getValue(OPEN)) {
         var2 |= 176 ^ 180;
      }

      return var2;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      EnumFacing.Axis var4 = ((EnumFacing)var1.getValue(FACING)).getAxis();
      if (var4 == EnumFacing.Axis.Z && (var2.getBlockState(var3.west()).getBlock() == Blocks.COBBLESTONE_WALL || var2.getBlockState(var3.east()).getBlock() == Blocks.COBBLESTONE_WALL) || var4 == EnumFacing.Axis.X && (var2.getBlockState(var3.north()).getBlock() == Blocks.COBBLESTONE_WALL || var2.getBlockState(var3.south()).getBlock() == Blocks.COBBLESTONE_WALL)) {
         var1 = var1.withProperty(IN_WALL, Boolean.valueOf((boolean)" ".length()));
      }

      return var1;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      if ((Boolean)var1.getValue(OPEN)) {
         return NULL_AABB;
      } else {
         AxisAlignedBB var10000;
         if (((EnumFacing)var1.getValue(FACING)).getAxis() == EnumFacing.Axis.Z) {
            var10000 = AABB_CLOSED_SELECTED_ZAXIS;
            "".length();
            if (4 < 3) {
               throw null;
            }
         } else {
            var10000 = AABB_CLOSED_SELECTED_XAXIS;
         }

         return var10000;
      }
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return (boolean)" ".length();
   }

   public BlockFenceGate(BlockPlanks.EnumType var1) {
      super(Material.WOOD, var1.getMapColor());
      this.setDefaultState(this.blockState.getBaseState().withProperty(OPEN, Boolean.valueOf((boolean)"".length())).withProperty(POWERED, Boolean.valueOf((boolean)"".length())).withProperty(IN_WALL, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.REDSTONE);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }
}

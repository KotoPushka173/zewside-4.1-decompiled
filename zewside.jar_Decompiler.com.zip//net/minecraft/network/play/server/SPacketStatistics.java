package net.minecraft.network.play.server;

import com.google.common.collect.Maps;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;

public class SPacketStatistics implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private Map<StatBase, Integer> statisticMap;
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.statisticMap.size());
      I["  ".length()].length();
      I["   ".length()].length();
      I[93 ^ 89].length();
      Iterator var2 = this.statisticMap.entrySet().iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         Entry var3 = (Entry)var2.next();
         var1.writeString(((StatBase)var3.getKey()).statId);
         I[101 ^ 96].length();
         I[189 ^ 187].length();
         I[89 ^ 94].length();
         I[85 ^ 93].length();
         var1.writeVarIntToBuffer((Integer)var3.getValue());
         I[3 ^ 10].length();
         I[35 ^ 41].length();
         I[54 ^ 61].length();
         "".length();
      } while(4 >= 4);

      throw null;
   }

   private static void I() {
      I = new String[133 ^ 137];
      I["".length()] = I("妖戊毋", "wbWRU");
      I[" ".length()] = I("冲寗嫺烃", "zgWXz");
      I["  ".length()] = I("冯", "ABMXx");
      I["   ".length()] = I("圮宓擛姅", "kLfqP");
      I[196 ^ 192] = I("栅殑憷榻", "EnoaT");
      I[74 ^ 79] = I("欳橿榀", "ZZumP");
      I[153 ^ 159] = I("垢娿柹叶", "SZVCm");
      I[76 ^ 75] = I("幰槖焓嫦滽", "gHTWr");
      I[47 ^ 39] = I("毖棹朾崲溒", "MYFOP");
      I[155 ^ 146] = I("侀", "OZnuy");
      I[165 ^ 175] = I("攷", "pmIzW");
      I[127 ^ 116] = I("寑", "WBZdL");
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleStatistics(this);
   }

   public Map<StatBase, Integer> getStatisticMap() {
      return this.statisticMap;
   }

   public SPacketStatistics(Map<StatBase, Integer> var1) {
      this.statisticMap = var1;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != 4);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      int var2 = var1.readVarIntFromBuffer();
      this.statisticMap = Maps.newHashMap();
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            return;
         }

         StatBase var4 = StatList.getOneShotStat(var1.readStringFromBuffer(10833 + 27652 - 11691 + 5973));
         int var5 = var1.readVarIntFromBuffer();
         if (var4 != null) {
            this.statisticMap.put(var4, var5);
            I["".length()].length();
            I[" ".length()].length();
         }

         ++var3;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public SPacketStatistics() {
   }
}

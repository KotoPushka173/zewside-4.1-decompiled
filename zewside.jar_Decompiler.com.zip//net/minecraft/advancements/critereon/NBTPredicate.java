package net.minecraft.advancements.critereon;

import com.google.gson.JsonElement;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.command.CommandBase;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.JsonToNBT;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTException;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.util.JsonUtils;

public class NBTPredicate {
   // $FF: synthetic field
   public static final NBTPredicate field_193479_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   @Nullable
   private final NBTTagCompound field_193480_b;

   public NBTPredicate(@Nullable NBTTagCompound var1) {
      this.field_193480_b = var1;
   }

   public boolean func_193477_a(@Nullable NBTBase var1) {
      int var10000;
      if (var1 == null) {
         if (this == field_193479_a) {
            var10000 = " ".length();
            "".length();
            if (4 <= 0) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      } else {
         if (this.field_193480_b != null && !NBTUtil.areNBTEquals(this.field_193480_b, var1, (boolean)" ".length())) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (4 != 4) {
               throw null;
            }
         }

         return (boolean)var10000;
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public boolean func_193478_a(ItemStack var1) {
      int var10000;
      if (this == field_193479_a) {
         var10000 = " ".length();
         "".length();
         if (4 == 0) {
            throw null;
         }
      } else {
         var10000 = this.func_193477_a(var1.getTagCompound());
      }

      return (boolean)var10000;
   }

   private static void I() {
      I = new String[22 ^ 14];
      I["".length()] = I("冕法", "RyTBV");
      I[" ".length()] = I("垝埞", "NeWvL");
      I["  ".length()] = I("愠冀", "fFEzY");
      I["   ".length()] = I("洑搘", "hzOyx");
      I[57 ^ 61] = I("冥幎", "kAelV");
      I[50 ^ 55] = I("我汭", "qDRcv");
      I[130 ^ 132] = I("湖晗", "MaTHL");
      I[44 ^ 43] = I("姹娞", "SCKjq");
      I[85 ^ 93] = I("散亻", "OiHnI");
      I[110 ^ 103] = I("杠憐", "ZrnMJ");
      I[143 ^ 133] = I("床栵", "kinte");
      I[75 ^ 64] = I("悪孈", "lYFZy");
      I[160 ^ 172] = I("=:\u0015", "SXaWI");
      I[186 ^ 183] = I("忀凸励掣沆", "ajZYs");
      I[179 ^ 189] = I("愽棇", "mQufs");
      I[8 ^ 7] = I("乫剣", "BFMVz");
      I[20 ^ 4] = I("櫁必烰湲", "iAgjU");
      I[183 ^ 166] = I("漛擂满", "gcgpV");
      I[51 ^ 33] = I("坞庮", "PxjWs");
      I[145 ^ 130] = I("慖呪専", "OJWYh");
      I[40 ^ 60] = I("\u0013\u000f\u0006\u0000\t3\u0005P\u000f\u0007.A\u0004\u0000\u0002`A", "Zapae");
      I[56 ^ 45] = I("偤", "HuJWU");
      I[46 ^ 56] = I("垟埅煋", "AwtHP");
      I[175 ^ 184] = I("廁", "hPuqC");
   }

   static {
      I();
      field_193479_a = new NBTPredicate((NBTTagCompound)null);
   }

   public static NBTPredicate func_193476_a(@Nullable JsonElement var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[191 ^ 187];
      var10001 = I[108 ^ 105];
      var10002 = I[102 ^ 96];
      var10001 = I[30 ^ 25];
      var10000 = I[134 ^ 142];
      var10001 = I[184 ^ 177];
      var10002 = I[119 ^ 125];
      var10001 = I[152 ^ 147];
      if (var0 != null && !var0.isJsonNull()) {
         NBTTagCompound var1;
         try {
            var1 = JsonToNBT.getTagFromJson(JsonUtils.getString(var0, I[160 ^ 172]));
         } catch (NBTException var3) {
            I[42 ^ 39].length();
            I[191 ^ 177].length();
            I[170 ^ 165].length();
            I[174 ^ 190].length();
            I[38 ^ 55].length();
            I[172 ^ 190].length();
            I[40 ^ 59].length();
            JsonSyntaxException var4 = new JsonSyntaxException(I[61 ^ 41] + var3.getMessage());
            I[50 ^ 39].length();
            throw var4;
         }

         "".length();
         if (-1 >= 0) {
            throw null;
         } else {
            I[73 ^ 95].length();
            I[169 ^ 190].length();
            return new NBTPredicate(var1);
         }
      } else {
         return field_193479_a;
      }
   }

   public boolean func_193475_a(Entity var1) {
      int var10000;
      if (this == field_193479_a) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 0) {
            throw null;
         }
      } else {
         var10000 = this.func_193477_a(CommandBase.entityToNBT(var1));
      }

      return (boolean)var10000;
   }
}

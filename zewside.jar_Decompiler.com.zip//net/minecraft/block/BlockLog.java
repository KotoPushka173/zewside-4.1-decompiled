package net.minecraft.block;

import java.util.Iterator;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public abstract class BlockLog extends BlockRotatedPillar {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyEnum<BlockLog.EnumAxis> LOG_AXIS;

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      int var4 = 139 ^ 143;
      int var5 = 194 ^ 199;
      if (var1.isAreaLoaded(var2.add(-(156 ^ 153), -(67 ^ 70), -(56 ^ 61)), var2.add(65 ^ 68, 122 ^ 127, 130 ^ 135))) {
         Iterator var6 = BlockPos.getAllInBox(var2.add(-(139 ^ 143), -(21 ^ 17), -(90 ^ 94)), var2.add(64 ^ 68, 79 ^ 75, 165 ^ 161)).iterator();

         while(var6.hasNext()) {
            BlockPos var7 = (BlockPos)var6.next();
            IBlockState var8 = var1.getBlockState(var7);
            if (var8.getMaterial() == Material.LEAVES && !(Boolean)var8.getValue(BlockLeaves.CHECK_DECAY)) {
               var1.setBlockState(var7, var8.withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf((boolean)" ".length())), 186 ^ 190);
               I["".length()].length();
               I[" ".length()].length();
            }

            "".length();
            if (3 < 2) {
               throw null;
            }
         }
      }

   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("幆乂烅憋", "Udurs");
      I[" ".length()] = I("掓曚", "yXapI");
      I["  ".length()] = I("\u0016<!\u001f", "wDHlG");
   }

   static {
      I();
      LOG_AXIS = PropertyEnum.create(I["  ".length()], BlockLog.EnumAxis.class);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockLog$EnumAxis[((BlockLog.EnumAxis)var1.getValue(LOG_AXIS)).ordinal()]) {
         case 1:
            return var1.withProperty(LOG_AXIS, BlockLog.EnumAxis.Z);
         case 2:
            return var1.withProperty(LOG_AXIS, BlockLog.EnumAxis.X);
         default:
            return var1;
         }
      default:
         return var1;
      }
   }

   public BlockLog() {
      super(Material.WOOD);
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
      this.setHardness(2.0F);
      this.setSoundType(SoundType.WOOD);
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getStateFromMeta(var7).withProperty(LOG_AXIS, BlockLog.EnumAxis.fromFacingAxis(var3.getAxis()));
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 0);

      throw null;
   }

   public static enum EnumAxis implements IStringSerializable {
      // $FF: synthetic field
      X,
      // $FF: synthetic field
      Z,
      // $FF: synthetic field
      NONE;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      Y;

      // $FF: synthetic field
      private static final String[] I;

      public String getName() {
         return this.name;
      }

      public static BlockLog.EnumAxis fromFacingAxis(EnumFacing.Axis var0) {
         switch(null.$SwitchMap$net$minecraft$util$EnumFacing$Axis[var0.ordinal()]) {
         case 1:
            return X;
         case 2:
            return Y;
         case 3:
            return Z;
         default:
            return NONE;
         }
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 != 2);

         throw null;
      }

      public String toString() {
         return this.name;
      }

      private EnumAxis(String var3) {
         this.name = var3;
      }

      static {
         I();
         X = new BlockLog.EnumAxis(I["".length()], "".length(), I[" ".length()]);
         Y = new BlockLog.EnumAxis(I["  ".length()], " ".length(), I["   ".length()]);
         Z = new BlockLog.EnumAxis(I[187 ^ 191], "  ".length(), I[58 ^ 63]);
         NONE = new BlockLog.EnumAxis(I[157 ^ 155], "   ".length(), I[157 ^ 154]);
         BlockLog.EnumAxis[] var10000 = new BlockLog.EnumAxis[10 ^ 14];
         var10000["".length()] = X;
         var10000[" ".length()] = Y;
         var10000["  ".length()] = Z;
         var10000["   ".length()] = NONE;
      }

      private static void I() {
         I = new String[55 ^ 63];
         I["".length()] = I(":", "bafgT");
         I[" ".length()] = I("+", "ScQsp");
         I["  ".length()] = I("\u000b", "RDPQS");
         I["   ".length()] = I("\u0010", "iBGFV");
         I[7 ^ 3] = I("\u0011", "KjRwo");
         I[91 ^ 94] = I("\u0002", "xulOq");
         I[110 ^ 104] = I("\u001b!\n\"", "UnDgS");
         I[157 ^ 154] = I("-9\t\u0017", "CVgrO");
      }
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.scoreboard.IScoreCriteria;
import net.minecraft.scoreboard.ScoreObjective;

public class SPacketScoreboardObjective implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private String objectiveName;
   // $FF: synthetic field
   private String objectiveValue;
   // $FF: synthetic field
   private int action;
   // $FF: synthetic field
   private IScoreCriteria.EnumRenderType type;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 1);

      throw null;
   }

   public SPacketScoreboardObjective() {
   }

   static {
      I();
   }

   private static void I() {
      I = new String[76 ^ 68];
      I["".length()] = I("孢暎揜哢懤", "xfGVx");
      I[" ".length()] = I("殭揯挐", "kZvNz");
      I["  ".length()] = I("斸櫼歷炡儋", "ozGOG");
      I["   ".length()] = I("埏", "eMLHm");
      I[148 ^ 144] = I("煇楛檃惀", "cUCxd");
      I[53 ^ 48] = I("噖呃", "HVKXX");
      I[179 ^ 181] = I("棾濡屆晌棯", "tIAJP");
      I[18 ^ 21] = I("亠檒", "EgAhi");
   }

   public String getObjectiveName() {
      return this.objectiveName;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleScoreboardObjective(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.objectiveName);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeByte(this.action);
      I["  ".length()].length();
      if (this.action == 0 || this.action == "  ".length()) {
         var1.writeString(this.objectiveValue);
         I["   ".length()].length();
         I[70 ^ 66].length();
         var1.writeString(this.type.getRenderType());
         I[7 ^ 2].length();
         I[178 ^ 180].length();
         I[162 ^ 165].length();
      }

   }

   public SPacketScoreboardObjective(ScoreObjective var1, int var2) {
      this.objectiveName = var1.getName();
      this.objectiveValue = var1.getDisplayName();
      this.type = var1.getCriteria().getRenderType();
      this.action = var2;
   }

   public int getAction() {
      return this.action;
   }

   public String getObjectiveValue() {
      return this.objectiveValue;
   }

   public IScoreCriteria.EnumRenderType getRenderType() {
      return this.type;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.objectiveName = var1.readStringFromBuffer(26 ^ 10);
      this.action = var1.readByte();
      if (this.action == 0 || this.action == "  ".length()) {
         this.objectiveValue = var1.readStringFromBuffer(60 ^ 28);
         this.type = IScoreCriteria.EnumRenderType.getByName(var1.readStringFromBuffer(21 ^ 5));
      }

   }
}

package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockPistonExtension extends BlockDirectional {
   // $FF: synthetic field
   protected static final AxisAlignedBB DOWN_ARM_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB EAST_ARM_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB field_190968_N;
   // $FF: synthetic field
   protected static final AxisAlignedBB field_190969_O;
   // $FF: synthetic field
   protected static final AxisAlignedBB SOUTH_ARM_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_EXTENSION_SOUTH_AABB;
   // $FF: synthetic field
   public static final PropertyEnum<BlockPistonExtension.EnumPistonType> TYPE;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_EXTENSION_DOWN_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_EXTENSION_EAST_AABB;
   // $FF: synthetic field
   public static final PropertyBool SHORT;
   // $FF: synthetic field
   protected static final AxisAlignedBB field_190966_L;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_EXTENSION_NORTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB field_190964_J;
   // $FF: synthetic field
   protected static final AxisAlignedBB UP_ARM_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB field_190965_K;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_EXTENSION_WEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB NORTH_ARM_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB field_190967_M;
   // $FF: synthetic field
   protected static final AxisAlignedBB WEST_ARM_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_EXTENSION_UP_AABB;

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      super.breakBlock(var1, var2, var3);
      EnumFacing var4 = ((EnumFacing)var3.getValue(FACING)).getOpposite();
      var2 = var2.offset(var4);
      IBlockState var5 = var1.getBlockState(var2);
      if ((var5.getBlock() == Blocks.PISTON || var5.getBlock() == Blocks.STICKY_PISTON) && (Boolean)var5.getValue(BlockPistonBase.EXTENDED)) {
         var5.getBlock().dropBlockAsItem(var1, var2, var5, "".length());
         var1.setBlockToAir(var2);
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }

   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public BlockPistonExtension() {
      super(Material.PISTON);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(TYPE, BlockPistonExtension.EnumPistonType.DEFAULT).withProperty(SHORT, Boolean.valueOf((boolean)"".length())));
      this.setSoundType(SoundType.STONE);
      this.setHardness(0.5F);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      EnumFacing var6 = (EnumFacing)var1.getValue(FACING);
      BlockPos var7 = var3.offset(var6.getOpposite());
      IBlockState var8 = var2.getBlockState(var7);
      if (var8.getBlock() != Blocks.PISTON && var8.getBlock() != Blocks.STICKY_PISTON) {
         var2.setBlockToAir(var3);
         I[126 ^ 122].length();
         I[180 ^ 177].length();
         I[156 ^ 154].length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var8.neighborChanged(var2, var7, var4, var5);
      }

   }

   public boolean canPlaceBlockOnSide(World var1, BlockPos var2, EnumFacing var3) {
      return (boolean)"".length();
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return (boolean)" ".length();
   }

   private static void I() {
      I = new String[61 ^ 16];
      I["".length()] = I("倜呌", "AKZPM");
      I[" ".length()] = I("叾扡恍囂", "WJlgk");
      I["  ".length()] = I("樶彄", "YZhqu");
      I["   ".length()] = I("姭剻嗯", "WVCDq");
      I[0 ^ 4] = I("揊", "zZAyu");
      I[162 ^ 167] = I("戋嘈卍樦嚝", "XyQBc");
      I[16 ^ 22] = I("仟毳兣儚外", "GpofK");
      I[163 ^ 164] = I("旴洸", "NWDgu");
      I[66 ^ 74] = I("喊崀", "fWhtx");
      I[28 ^ 21] = I("涻啊", "yVJAk");
      I[10 ^ 0] = I("戉强", "hOnNR");
      I[83 ^ 88] = I("妶曇", "lhiWi");
      I[186 ^ 182] = I("潅懻刞浙", "pgZay");
      I[4 ^ 9] = I("啊冞勔", "jrgcb");
      I[191 ^ 177] = I("洅冕", "EswjJ");
      I[127 ^ 112] = I("撥換", "yyvmB");
      I[208 ^ 192] = I("叭汩", "CfdYo");
      I[24 ^ 9] = I("咅媃", "HOrFi");
      I[30 ^ 12] = I("娌涙", "MfPiV");
      I[76 ^ 95] = I("劲嵽", "vhGOm");
      I[83 ^ 71] = I("垲瀏", "xaGzD");
      I[131 ^ 150] = I("湋垤", "sCcHg");
      I[72 ^ 94] = I("栾呰", "JwCXq");
      I[122 ^ 109] = I("撀梼", "UqVjT");
      I[44 ^ 52] = I("橃殇", "gJELs");
      I[28 ^ 5] = I("搕杂", "uZcED");
      I[124 ^ 102] = I("壻剆", "JZmJe");
      I[88 ^ 67] = I("嚼汘", "CoBSz");
      I[107 ^ 119] = I("修抆", "hRAQa");
      I[87 ^ 74] = I("扖慕", "EbWSt");
      I[85 ^ 75] = I("仕惃櫛", "nOjJi");
      I[145 ^ 142] = I("孌", "SHxrQ");
      I[113 ^ 81] = I("摠恔哺", "JYPne");
      I[6 ^ 39] = I("拽寂", "XERWa");
      I[5 ^ 39] = I("吀", "bsbrB");
      I[97 ^ 66] = I("塻櫟劐挑澕", "pYdnS");
      I[227 ^ 199] = I("俑淡", "vjjnr");
      I[110 ^ 75] = I("哸后撵忡", "jTIdS");
      I[184 ^ 158] = I("旽炲嵎昷攃", "Zvirc");
      I[41 ^ 14] = I("偖", "SNsTB");
      I[143 ^ 167] = I("囕彻俵", "zaotV");
      I[60 ^ 21] = I("卽埫", "lloBL");
      I[184 ^ 146] = I("傀曮", "DUaxu");
      I[150 ^ 189] = I("\u0002\u0010\u001e.", "vinKN");
      I[7 ^ 43] = I(")\t#\u00179", "ZaLeM");
   }

   public void onBlockHarvested(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      if (var4.capabilities.isCreativeMode) {
         BlockPos var5 = var2.offset(((EnumFacing)var3.getValue(FACING)).getOpposite());
         Block var6 = var1.getBlockState(var5).getBlock();
         if (var6 == Blocks.PISTON || var6 == Blocks.STICKY_PISTON) {
            var1.setBlockToAir(var5);
            I["".length()].length();
         }
      }

      super.onBlockHarvested(var1, var2, var3, var4);
   }

   public boolean isFullyOpaque(IBlockState var1) {
      int var10000;
      if (var1.getValue(FACING) == EnumFacing.UP) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 == var2.getValue(FACING)) {
         var10000 = BlockFaceShape.SOLID;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[70 ^ 65];
      String var10001 = I[52 ^ 60];
      String var10002 = I[113 ^ 120];
      var10001 = I[39 ^ 45];
      ItemStack var4 = new ItemStack;
      I[84 ^ 95].length();
      I[138 ^ 134].length();
      I[16 ^ 29].length();
      BlockPistonBase var5;
      if (var3.getValue(TYPE) == BlockPistonExtension.EnumPistonType.STICKY) {
         var5 = Blocks.STICKY_PISTON;
         "".length();
         if (3 < 0) {
            throw null;
         }
      } else {
         var5 = Blocks.PISTON;
      }

      var4.<init>((Block)var5);
      return var4;
   }

   @Nullable
   public static EnumFacing getFacing(int var0) {
      int var1 = var0 & (72 ^ 79);
      EnumFacing var10000;
      if (var1 > (95 ^ 90)) {
         var10000 = null;
         "".length();
         if (4 != 4) {
            throw null;
         }
      } else {
         var10000 = EnumFacing.getFront(var1);
      }

      return var10000;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getIndex();
      if (var1.getValue(TYPE) == BlockPistonExtension.EnumPistonType.STICKY) {
         var2 |= 114 ^ 122;
      }

      return var2;
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      addCollisionBoxToList(var3, var4, var5, var1.getBoundingBox(var2, var3));
      addCollisionBoxToList(var3, var4, var5, this.getArmShape(var1));
   }

   private AxisAlignedBB getArmShape(IBlockState var1) {
      boolean var2 = (Boolean)var1.getValue(SHORT);
      AxisAlignedBB var10000;
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
      default:
         if (var2) {
            var10000 = field_190965_K;
            "".length();
            if (2 < 0) {
               throw null;
            }
         } else {
            var10000 = DOWN_ARM_AABB;
         }

         return var10000;
      case 2:
         if (var2) {
            var10000 = field_190964_J;
            "".length();
            if (4 <= 2) {
               throw null;
            }
         } else {
            var10000 = UP_ARM_AABB;
         }

         return var10000;
      case 3:
         if (var2) {
            var10000 = field_190967_M;
            "".length();
            if (4 != 4) {
               throw null;
            }
         } else {
            var10000 = NORTH_ARM_AABB;
         }

         return var10000;
      case 4:
         if (var2) {
            var10000 = field_190966_L;
            "".length();
            if (4 <= 0) {
               throw null;
            }
         } else {
            var10000 = SOUTH_ARM_AABB;
         }

         return var10000;
      case 5:
         if (var2) {
            var10000 = field_190969_O;
            "".length();
            if (4 < 2) {
               throw null;
            }
         } else {
            var10000 = WEST_ARM_AABB;
         }

         return var10000;
      case 6:
         if (var2) {
            var10000 = field_190968_N;
            "".length();
            if (0 < -1) {
               throw null;
            }
         } else {
            var10000 = EAST_ARM_AABB;
         }

         return var10000;
      }
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, getFacing(var1));
      PropertyEnum var10001 = TYPE;
      BlockPistonExtension.EnumPistonType var10002;
      if ((var1 & (22 ^ 30)) > 0) {
         var10002 = BlockPistonExtension.EnumPistonType.STICKY;
         "".length();
         if (0 == 4) {
            throw null;
         }
      } else {
         var10002 = BlockPistonExtension.EnumPistonType.DEFAULT;
      }

      return var10000.withProperty(var10001, var10002);
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[147 ^ 157];
      String var10001 = I[55 ^ 56];
      String var10002 = I[34 ^ 50];
      var10001 = I[66 ^ 83];
      var10000 = I[78 ^ 92];
      var10001 = I[41 ^ 58];
      var10002 = I[37 ^ 49];
      var10001 = I[125 ^ 104];
      var10000 = I[141 ^ 155];
      var10001 = I[63 ^ 40];
      var10002 = I[84 ^ 76];
      var10001 = I[156 ^ 133];
      var10000 = I[167 ^ 189];
      var10001 = I[131 ^ 152];
      var10002 = I[174 ^ 178];
      var10001 = I[137 ^ 148];
      I[139 ^ 149].length();
      I[126 ^ 97].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[35 ^ 3].length();
      I[146 ^ 179].length();
      var10003["".length()] = FACING;
      I[78 ^ 108].length();
      I[131 ^ 160].length();
      I[84 ^ 112].length();
      I[81 ^ 116].length();
      I[132 ^ 162].length();
      var10003[" ".length()] = TYPE;
      I[80 ^ 119].length();
      I[188 ^ 148].length();
      I[50 ^ 27].length();
      I[117 ^ 95].length();
      var10003["  ".length()] = SHORT;
      return new BlockStateContainer(this, var10003);
   }

   static {
      I();
      TYPE = PropertyEnum.create(I[155 ^ 176], BlockPistonExtension.EnumPistonType.class);
      SHORT = PropertyBool.create(I[7 ^ 43]);
      PISTON_EXTENSION_EAST_AABB = new AxisAlignedBB(0.75D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      PISTON_EXTENSION_WEST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.25D, 1.0D, 1.0D);
      PISTON_EXTENSION_SOUTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.75D, 1.0D, 1.0D, 1.0D);
      PISTON_EXTENSION_NORTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.25D);
      PISTON_EXTENSION_UP_AABB = new AxisAlignedBB(0.0D, 0.75D, 0.0D, 1.0D, 1.0D, 1.0D);
      PISTON_EXTENSION_DOWN_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.25D, 1.0D);
      UP_ARM_AABB = new AxisAlignedBB(0.375D, -0.25D, 0.375D, 0.625D, 0.75D, 0.625D);
      DOWN_ARM_AABB = new AxisAlignedBB(0.375D, 0.25D, 0.375D, 0.625D, 1.25D, 0.625D);
      SOUTH_ARM_AABB = new AxisAlignedBB(0.375D, 0.375D, -0.25D, 0.625D, 0.625D, 0.75D);
      NORTH_ARM_AABB = new AxisAlignedBB(0.375D, 0.375D, 0.25D, 0.625D, 0.625D, 1.25D);
      EAST_ARM_AABB = new AxisAlignedBB(-0.25D, 0.375D, 0.375D, 0.75D, 0.625D, 0.625D);
      WEST_ARM_AABB = new AxisAlignedBB(0.25D, 0.375D, 0.375D, 1.25D, 0.625D, 0.625D);
      field_190964_J = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 0.75D, 0.625D);
      field_190965_K = new AxisAlignedBB(0.375D, 0.25D, 0.375D, 0.625D, 1.0D, 0.625D);
      field_190966_L = new AxisAlignedBB(0.375D, 0.375D, 0.0D, 0.625D, 0.625D, 0.75D);
      field_190967_M = new AxisAlignedBB(0.375D, 0.375D, 0.25D, 0.625D, 0.625D, 1.0D);
      field_190968_N = new AxisAlignedBB(0.0D, 0.375D, 0.375D, 0.75D, 0.625D, 0.625D);
      field_190969_O = new AxisAlignedBB(0.25D, 0.375D, 0.375D, 1.0D, 0.625D, 0.625D);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
      case 1:
      default:
         return PISTON_EXTENSION_DOWN_AABB;
      case 2:
         return PISTON_EXTENSION_UP_AABB;
      case 3:
         return PISTON_EXTENSION_NORTH_AABB;
      case 4:
         return PISTON_EXTENSION_SOUTH_AABB;
      case 5:
         return PISTON_EXTENSION_WEST_AABB;
      case 6:
         return PISTON_EXTENSION_EAST_AABB;
      }
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      return (boolean)"".length();
   }

   public static enum EnumPistonType implements IStringSerializable {
      // $FF: synthetic field
      DEFAULT;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final String VARIANT;
      // $FF: synthetic field
      STICKY;

      static {
         I();
         DEFAULT = new BlockPistonExtension.EnumPistonType(I["".length()], "".length(), I[" ".length()]);
         STICKY = new BlockPistonExtension.EnumPistonType(I["  ".length()], " ".length(), I["   ".length()]);
         BlockPistonExtension.EnumPistonType[] var10000 = new BlockPistonExtension.EnumPistonType["  ".length()];
         var10000["".length()] = DEFAULT;
         var10000[" ".length()] = STICKY;
      }

      public String getName() {
         return this.VARIANT;
      }

      private static void I() {
         I = new String[93 ^ 89];
         I["".length()] = I("##*\b?+2", "gflIj");
         I[" ".length()] = I(">\u0019680<", "PvDUQ");
         I["  ".length()] = I("'.9\u00199-", "tzpZr");
         I["   ".length()] = I("4,\u000b)$>", "GXbJO");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 > -1);

         throw null;
      }

      public String toString() {
         return this.VARIANT;
      }

      private EnumPistonType(String var3) {
         this.VARIANT = var3;
      }
   }
}

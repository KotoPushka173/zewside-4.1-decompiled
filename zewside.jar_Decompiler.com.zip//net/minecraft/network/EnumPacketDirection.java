package net.minecraft.network;

public enum EnumPacketDirection {
   // $FF: synthetic field
   SERVERBOUND,
   // $FF: synthetic field
   CLIENTBOUND;

   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
      SERVERBOUND = new EnumPacketDirection(I["".length()], "".length());
      CLIENTBOUND = new EnumPacketDirection(I[" ".length()], " ".length());
      EnumPacketDirection[] var10000 = new EnumPacketDirection["  ".length()];
      var10000["".length()] = SERVERBOUND;
      var10000[" ".length()] = CLIENTBOUND;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 1);

      throw null;
   }

   private static void I() {
      I = new String["  ".length()];
      I["".length()] = I("0&\b\u0018\u00171!\u0015\u001b\u001c'", "ccZNR");
      I[" ".length()] = I("\n=:\n\r\u001d3<\u001a\r\r", "IqsOC");
   }
}

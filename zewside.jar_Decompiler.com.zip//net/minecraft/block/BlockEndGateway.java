package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEndGateway;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockEndGateway extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;

   public int quantityDropped(Random var1) {
      return "".length();
   }

   protected BlockEndGateway(Material var1) {
      super(var1);
      this.setLightLevel(1.0F);
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      IBlockState var5 = var2.getBlockState(var3.offset(var4));
      Block var6 = var5.getBlock();
      int var10000;
      if (!var5.isOpaqueCube() && var6 != Blocks.END_GATEWAY) {
         var10000 = " ".length();
         "".length();
         if (2 == -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   static {
      I();
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      TileEntity var5 = var2.getTileEntity(var3);
      if (var5 instanceof TileEntityEndGateway) {
         int var6 = ((TileEntityEndGateway)var5).getParticleAmount();
         int var7 = "".length();

         while(var7 < var6) {
            double var8 = (double)((float)var3.getX() + var4.nextFloat());
            double var10 = (double)((float)var3.getY() + var4.nextFloat());
            double var12 = (double)((float)var3.getZ() + var4.nextFloat());
            double var10000 = (double)var4.nextFloat();
            I[145 ^ 151].length();
            I[24 ^ 31].length();
            double var14 = (var10000 - 0.5D) * 0.5D;
            var10000 = (double)var4.nextFloat();
            I[17 ^ 25].length();
            double var16 = (var10000 - 0.5D) * 0.5D;
            var10000 = (double)var4.nextFloat();
            I[124 ^ 117].length();
            I[51 ^ 57].length();
            I[131 ^ 136].length();
            double var18 = (var10000 - 0.5D) * 0.5D;
            int var21 = var4.nextInt("  ".length()) * "  ".length();
            int var10001 = " ".length();
            I[170 ^ 166].length();
            I[3 ^ 14].length();
            int var20 = var21 - var10001;
            if (var4.nextBoolean()) {
               var12 = (double)var3.getZ() + 0.5D + 0.25D * (double)var20;
               var18 = (double)(var4.nextFloat() * 2.0F * (float)var20);
               "".length();
               if (4 == 1) {
                  throw null;
               }
            } else {
               var8 = (double)var3.getX() + 0.5D + 0.25D * (double)var20;
               var14 = (double)(var4.nextFloat() * 2.0F * (float)var20);
            }

            var2.spawnParticle(EnumParticleTypes.PORTAL, var8, var10, var12, var14, var16, var18);
            ++var7;
            "".length();
            if (0 < -1) {
               throw null;
            }
         }
      }

   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   private static void I() {
      I = new String[108 ^ 98];
      I["".length()] = I("灗委", "dVzjV");
      I[" ".length()] = I("拓咋", "GiOHS");
      I["  ".length()] = I("氇彠", "utUNi");
      I["   ".length()] = I("侘桜", "pTrKn");
      I[135 ^ 131] = I("乬捁", "QHCYc");
      I[84 ^ 81] = I("愑婚徽嗓", "pNoiK");
      I[143 ^ 137] = I("殥", "DyxtQ");
      I[183 ^ 176] = I("劄潘斦唬姟", "raeQs");
      I[119 ^ 127] = I("氲拇墜憂", "dGtLn");
      I[90 ^ 83] = I("币", "GzzRv");
      I[34 ^ 40] = I("椔匟扎", "rIiny");
      I[204 ^ 199] = I("潐炿檠啬", "ZkVWI");
      I[44 ^ 32] = I("摤抉烼囅", "NvwQM");
      I[111 ^ 98] = I("櫣晔杄宏", "llqta");
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[165 ^ 161].length();
      I[1 ^ 4].length();
      return new TileEntityEndGateway();
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.BLACK;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= -1);

      throw null;
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      return ItemStack.field_190927_a;
   }
}

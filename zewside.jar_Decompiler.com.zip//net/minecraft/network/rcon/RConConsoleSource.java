package net.minecraft.network.rcon;

import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;

public class RConConsoleSource implements ICommandSender {
   // $FF: synthetic field
   private final StringBuffer buffer = new StringBuffer();
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final MinecraftServer server;

   public boolean canCommandSenderUseCommand(int var1, String var2) {
      return (boolean)" ".length();
   }

   private static void I() {
      I = new String[72 ^ 76];
      I["".length()] = I("\u001b\f\u0007,", "IohBM");
      I[" ".length()] = I("囨咐摅峖", "Yghqq");
      I["  ".length()] = I("曅", "mnLdo");
      I["   ".length()] = I("泑涨淞弫", "izOrz");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   public void addChatMessage(ITextComponent var1) {
      this.buffer.append(var1.getUnformattedText());
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
   }

   public String getName() {
      return I["".length()];
   }

   static {
      I();
   }

   public MinecraftServer getServer() {
      return this.server;
   }

   public RConConsoleSource(MinecraftServer var1) {
      this.server = var1;
   }

   public World getEntityWorld() {
      return this.server.getEntityWorld();
   }

   public boolean sendCommandFeedback() {
      return (boolean)" ".length();
   }
}

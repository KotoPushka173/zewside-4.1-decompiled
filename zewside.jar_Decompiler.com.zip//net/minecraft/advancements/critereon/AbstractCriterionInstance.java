package net.minecraft.advancements.critereon;

import net.minecraft.advancements.ICriterionInstance;
import net.minecraft.util.ResourceLocation;

public class AbstractCriterionInstance implements ICriterionInstance {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final ResourceLocation field_192245_a;

   public AbstractCriterionInstance(ResourceLocation var1) {
      this.field_192245_a = var1;
   }

   private static void I() {
      I = new String[31 ^ 23];
      I["".length()] = I("憩侂", "dwKnp");
      I[" ".length()] = I("淣曰", "jStSL");
      I["  ".length()] = I("喚恦", "fXcJw");
      I["   ".length()] = I("櫣側", "xNCaB");
      I[79 ^ 75] = I("溳哊", "OgkGL");
      I[137 ^ 140] = I("劘", "RUCwl");
      I[130 ^ 132] = I("巬殯", "xFeRs");
      I[6 ^ 1] = I("8\r\u0007\u00158\u0018\f\u0000\"8\u0010\u001b\u0011\u0013#\u0016\u0001=\u000f9\r\u000e\u001a\u0002/\u0002\f\u0006\b>\u001c\u001d\u001d\u000e$D", "yotaJ");
   }

   static {
      I();
   }

   public String toString() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[165 ^ 161].length();
      I[163 ^ 166].length();
      I[96 ^ 102].length();
      return I[97 ^ 102] + this.field_192245_a + ('@' ^ '=');
   }

   public ResourceLocation func_192244_a() {
      return this.field_192245_a;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 >= 1);

      throw null;
   }
}

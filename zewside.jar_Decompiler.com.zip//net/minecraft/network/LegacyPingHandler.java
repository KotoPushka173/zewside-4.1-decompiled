package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LegacyPingHandler extends ChannelInboundHandlerAdapter {
   // $FF: synthetic field
   private final NetworkSystem networkSystem;
   // $FF: synthetic field
   private static final Logger LOGGER;
   // $FF: synthetic field
   private static final String[] I;

   public void channelRead(ChannelHandlerContext var1, Object var2) throws Exception {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[2 ^ 6];
      var10001 = I[197 ^ 192];
      var10002 = I[23 ^ 17];
      var10001 = I[96 ^ 103];
      var10000 = I[188 ^ 180];
      var10001 = I[36 ^ 45];
      var10002 = I[157 ^ 151];
      var10001 = I[76 ^ 71];
      var10000 = I[63 ^ 51];
      var10001 = I[177 ^ 188];
      var10002 = I[105 ^ 103];
      var10001 = I[91 ^ 84];
      var10000 = I[62 ^ 46];
      var10001 = I[140 ^ 157];
      var10002 = I[23 ^ 5];
      var10001 = I[166 ^ 181];
      var10000 = I[80 ^ 68];
      var10001 = I[144 ^ 133];
      var10002 = I[103 ^ 113];
      var10001 = I[134 ^ 145];
      var10000 = I[81 ^ 73];
      var10001 = I[7 ^ 30];
      var10002 = I[126 ^ 100];
      var10001 = I[91 ^ 64];
      var10000 = I[118 ^ 106];
      var10001 = I[93 ^ 64];
      var10002 = I[45 ^ 51];
      var10001 = I[182 ^ 169];
      var10000 = I[44 ^ 12];
      var10001 = I[116 ^ 85];
      var10002 = I[153 ^ 187];
      var10001 = I[190 ^ 157];
      var10000 = I[229 ^ 193];
      var10001 = I[86 ^ 115];
      var10002 = I[95 ^ 121];
      var10001 = I[151 ^ 176];
      var10000 = I[72 ^ 96];
      var10001 = I[139 ^ 162];
      var10002 = I[22 ^ 60];
      var10001 = I[235 ^ 192];
      var10000 = I[28 ^ 48];
      var10001 = I[144 ^ 189];
      var10002 = I[60 ^ 18];
      var10001 = I[74 ^ 101];
      var10000 = I[89 ^ 105];
      var10001 = I[60 ^ 13];
      var10002 = I[134 ^ 180];
      var10001 = I[74 ^ 121];
      var10000 = I[74 ^ 126];
      var10001 = I[124 ^ 73];
      var10002 = I[72 ^ 126];
      var10001 = I[102 ^ 81];
      ByteBuf var3 = (ByteBuf)var2;
      var3.markReaderIndex();
      I[171 ^ 147].length();
      int var4 = " ".length();

      label396: {
         label397: {
            label398: {
               label399: {
                  try {
                     try {
                        if (var3.readUnsignedByte() == 106 + 51 - 60 + 157) {
                           InetSocketAddress var5 = (InetSocketAddress)var1.channel().remoteAddress();
                           MinecraftServer var6 = this.networkSystem.getServer();
                           int var7 = var3.readableBytes();
                           Object[] var26;
                           switch(var7) {
                           case 0:
                              LOGGER.debug(I[153 ^ 160], var5.getAddress(), var5.getPort());
                              var10000 = I[137 ^ 179];
                              var26 = new Object["   ".length()];
                              I[26 ^ 33].length();
                              var26["".length()] = var6.getMOTD();
                              I[90 ^ 102].length();
                              I[122 ^ 71].length();
                              var26[" ".length()] = var6.getCurrentPlayerCount();
                              I[112 ^ 78].length();
                              I[81 ^ 110].length();
                              var26["  ".length()] = var6.getMaxPlayers();
                              String var8 = String.format(var10000, var26);
                              this.writeAndFlush(var1, this.getStringBuffer(var8));
                              "".length();
                              if (4 <= 2) {
                                 throw null;
                              }
                              break;
                           case 1:
                              if (var3.readUnsignedByte() != " ".length()) {
                                 break label396;
                              }

                              LOGGER.debug(I[122 ^ 50], var5.getAddress(), var5.getPort());
                              var10000 = I[229 ^ 172];
                              var26 = new Object[39 ^ 34];
                              I[90 ^ 16].length();
                              I[27 ^ 80].length();
                              I[38 ^ 106].length();
                              I[83 ^ 30].length();
                              var26["".length()] = 108 + 78 - 91 + 32;
                              I[44 ^ 98].length();
                              var26[" ".length()] = var6.getMinecraftVersion();
                              I[244 ^ 187].length();
                              I[76 ^ 28].length();
                              I[96 ^ 49].length();
                              var26["  ".length()] = var6.getMOTD();
                              I[66 ^ 16].length();
                              I[127 ^ 44].length();
                              I[9 ^ 93].length();
                              var26["   ".length()] = var6.getCurrentPlayerCount();
                              I[245 ^ 160].length();
                              I[210 ^ 132].length();
                              var26[8 ^ 12] = var6.getMaxPlayers();
                              String var9 = String.format(var10000, var26);
                              this.writeAndFlush(var1, this.getStringBuffer(var9));
                              "".length();
                              if (0 == 4) {
                                 throw null;
                              }
                              break;
                           default:
                              int var25;
                              if (var3.readUnsignedByte() == " ".length()) {
                                 var25 = " ".length();
                                 "".length();
                                 if (0 >= 3) {
                                    throw null;
                                 }
                              } else {
                                 var25 = "".length();
                              }

                              int var10 = var25;
                              int var27;
                              if (var3.readUnsignedByte() == 18 + 105 - -87 + 40) {
                                 var27 = " ".length();
                                 "".length();
                                 if (0 < -1) {
                                    throw null;
                                 }
                              } else {
                                 var27 = "".length();
                              }

                              var10 &= var27;
                              var10001 = I[88 ^ 15];
                              I[25 ^ 65].length();
                              I[199 ^ 158].length();
                              var10 &= var10001.equals(new String(var3.readBytes(var3.readShort() * "  ".length()).array(), StandardCharsets.UTF_16BE));
                              int var11 = var3.readUnsignedShort();
                              if (var3.readUnsignedByte() >= (143 ^ 198)) {
                                 var27 = " ".length();
                                 "".length();
                                 if (0 >= 3) {
                                    throw null;
                                 }
                              } else {
                                 var27 = "".length();
                              }

                              var10 &= var27;
                              if ("   ".length() + var3.readBytes(var3.readShort() * "  ".length()).array().length + (51 ^ 55) == var11) {
                                 var27 = " ".length();
                                 "".length();
                                 if (-1 >= 1) {
                                    throw null;
                                 }
                              } else {
                                 var27 = "".length();
                              }

                              var10 &= var27;
                              if (var3.readInt() <= 10511 + 27330 - -23256 + 4438) {
                                 var27 = " ".length();
                                 "".length();
                                 if (-1 < -1) {
                                    throw null;
                                 }
                              } else {
                                 var27 = "".length();
                              }

                              var10 &= var27;
                              if (var3.readableBytes() == 0) {
                                 var27 = " ".length();
                                 "".length();
                                 if (4 != 4) {
                                    throw null;
                                 }
                              } else {
                                 var27 = "".length();
                              }

                              var10 &= var27;
                              if (var10 == 0) {
                                 break label397;
                              }

                              LOGGER.debug(I[166 ^ 196], var5.getAddress(), var5.getPort());
                              var10000 = I[217 ^ 186];
                              var26 = new Object[189 ^ 184];
                              I[208 ^ 180].length();
                              I[198 ^ 163].length();
                              var26["".length()] = 84 + 24 - 11 + 30;
                              I[113 ^ 23].length();
                              I[223 ^ 184].length();
                              var26[" ".length()] = var6.getMinecraftVersion();
                              I[95 ^ 55].length();
                              I[206 ^ 167].length();
                              var26["  ".length()] = var6.getMOTD();
                              I[245 ^ 159].length();
                              I[50 ^ 89].length();
                              var26["   ".length()] = var6.getCurrentPlayerCount();
                              I[0 ^ 108].length();
                              I[247 ^ 154].length();
                              var26[136 ^ 140] = var6.getMaxPlayers();
                              String var12 = String.format(var10000, var26);
                              ByteBuf var13 = this.getStringBuffer(var12);

                              try {
                                 this.writeAndFlush(var1, var13);
                              } catch (Throwable var22) {
                                 var13.release();
                                 I[62 ^ 78].length();
                                 I[196 ^ 181].length();
                                 I[4 ^ 118].length();
                                 I[61 ^ 78].length();
                                 I[59 ^ 79].length();
                                 throw var22;
                              }

                              var13.release();
                              I[48 ^ 94].length();
                              I[16 ^ 127].length();
                              "".length();
                              if (3 <= 1) {
                                 throw null;
                              }
                           }

                           var3.release();
                           I[211 ^ 166].length();
                           I[78 ^ 56].length();
                           var4 = "".length();
                           break label398;
                        }
                     } catch (RuntimeException var23) {
                        break label399;
                     }
                  } catch (Throwable var24) {
                     if (var4 != 0) {
                        var3.resetReaderIndex();
                        I[134 + 88 - 176 + 102].length();
                        I[144 + 4 - 10 + 11].length();
                        var1.channel().pipeline().remove(I[121 + 52 - 92 + 69]);
                        I[90 + 56 - 35 + 40].length();
                        I[96 + 140 - 220 + 136].length();
                        var1.fireChannelRead(var2);
                        I[76 + 93 - 91 + 75].length();
                        I[125 + 24 - 51 + 56].length();
                        I[144 + 143 - 251 + 119].length();
                     }

                     I[147 + 30 - 162 + 141].length();
                     I[140 + 142 - 222 + 97].length();
                     throw var24;
                  }

                  if (var4 != 0) {
                     var3.resetReaderIndex();
                     I[90 + 83 - 98 + 55].length();
                     I[18 + 106 - 12 + 19].length();
                     I[54 + 108 - 36 + 6].length();
                     var1.channel().pipeline().remove(I[12 + 121 - 86 + 86]);
                     I[85 + 22 - 15 + 42].length();
                     I[36 + 48 - 64 + 115].length();
                     I[83 + 134 - 127 + 46].length();
                     I[18 + 8 - 6 + 117].length();
                     var1.fireChannelRead(var2);
                     I[132 + 65 - 128 + 69].length();
                     I[112 + 64 - 82 + 45].length();
                     I[135 + 100 - 123 + 28].length();
                     "".length();
                     if (3 < 2) {
                        throw null;
                     }
                  }

                  return;
               }

               if (var4 != 0) {
                  var3.resetReaderIndex();
                  I[73 + 111 - 52 + 9].length();
                  I[140 + 130 - 266 + 138].length();
                  var1.channel().pipeline().remove(I[9 + 131 - 113 + 116]);
                  I[60 + 111 - 89 + 62].length();
                  I[136 + 18 - 93 + 84].length();
                  I[14 + 62 - -20 + 50].length();
                  var1.fireChannelRead(var2);
                  I[78 + 123 - 67 + 13].length();
               }

               return;
            }

            if (var4 != 0) {
               var3.resetReaderIndex();
               I[216 ^ 175].length();
               I[1 ^ 121].length();
               I[42 ^ 83].length();
               var1.channel().pipeline().remove(I[209 ^ 171]);
               I[242 ^ 137].length();
               I[223 ^ 163].length();
               I[235 ^ 150].length();
               var1.fireChannelRead(var2);
               I[54 ^ 72].length();
               I[52 + 13 - 9 + 71].length();
               I[62 + 93 - 140 + 113].length();
               I[69 + 45 - -7 + 8].length();
            }

            return;
         }

         if (var4 != 0) {
            var3.resetReaderIndex();
            I[118 ^ 44].length();
            I[114 ^ 41].length();
            I[105 ^ 53].length();
            var1.channel().pipeline().remove(I[245 ^ 168]);
            I[2 ^ 92].length();
            I[22 ^ 73].length();
            var1.fireChannelRead(var2);
            I[166 ^ 198].length();
            I[93 ^ 60].length();
         }

         return;
      }

      if (var4 != 0) {
         var3.resetReaderIndex();
         I[37 ^ 101].length();
         I[225 ^ 160].length();
         I[34 ^ 96].length();
         var1.channel().pipeline().remove(I[228 ^ 167]);
         I[221 ^ 153].length();
         I[128 ^ 197].length();
         var1.fireChannelRead(var2);
         I[41 ^ 111].length();
         I[197 ^ 130].length();
      }

   }

   static {
      I();
      LOGGER = LogManager.getLogger();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 2);

      throw null;
   }

   private ByteBuf getStringBuffer(String var1) {
      ByteBuf var2 = Unpooled.buffer();
      var2.writeByte(151 + 240 - 282 + 146);
      I[50 + 138 - 102 + 74].length();
      I[151 + 42 - 184 + 152].length();
      char[] var3 = var1.toCharArray();
      var2.writeShort(var3.length);
      I[89 + 83 - 104 + 94].length();
      I[126 + 6 - -1 + 30].length();
      I[20 + 60 - 79 + 163].length();
      char[] var4 = var3;
      int var5 = var3.length;
      int var6 = "".length();

      do {
         if (var6 >= var5) {
            return var2;
         }

         char var7 = var4[var6];
         var2.writeChar(var7);
         I[44 + 111 - 145 + 155].length();
         I[73 + 143 - 182 + 132].length();
         ++var6;
         "".length();
      } while(4 == 4);

      throw null;
   }

   private static void I() {
      I = new String[87 + 6 - 29 + 103];
      I["".length()] = I("嶖嵙", "jpKeE");
      I[" ".length()] = I("傲杉", "pIUCH");
      I["  ".length()] = I("栩僷", "zeoDj");
      I["   ".length()] = I("侥孛", "frXKM");
      I[150 ^ 146] = I("带濥", "xkLes");
      I[161 ^ 164] = I("欳淞", "anlYp");
      I[177 ^ 183] = I("杆愄", "FAcJe");
      I[193 ^ 198] = I("烞法", "uXcAC");
      I[159 ^ 151] = I("卫嚊", "YYIIH");
      I[21 ^ 28] = I("嶍佒", "sfVXg");
      I[13 ^ 7] = I("柞兗", "WZURO");
      I[114 ^ 121] = I("泐橺", "MCeTG");
      I[100 ^ 104] = I("宭劮", "MCago");
      I[49 ^ 60] = I("噊凖", "XeRgl");
      I[115 ^ 125] = I("撽匡", "bpuAp");
      I[34 ^ 45] = I("墂减", "WRGIw");
      I[101 ^ 117] = I("帆惘", "XpCXX");
      I[27 ^ 10] = I("泑浐", "mjJQf");
      I[13 ^ 31] = I("涁槂", "eppHw");
      I[134 ^ 149] = I("庡潻", "YJcIG");
      I[53 ^ 33] = I("囘忀", "nmexe");
      I[101 ^ 112] = I("團挪", "TqXmb");
      I[40 ^ 62] = I("乭庌", "SGWqY");
      I[58 ^ 45] = I("啁埏", "xbkBJ");
      I[98 ^ 122] = I("呲氷", "nmeNU");
      I[0 ^ 25] = I("挆嵣", "kuULL");
      I[59 ^ 33] = I("槗渭", "COYAF");
      I[187 ^ 160] = I("媁怷", "qNWTz");
      I[130 ^ 158] = I("偬唺", "ntEJp");
      I[81 ^ 76] = I("勴侓", "YnDfC");
      I[70 ^ 88] = I("坒斩", "pAjlt");
      I[144 ^ 143] = I("橔敖", "LXwFY");
      I[227 ^ 195] = I("桎懩", "cATYs");
      I[24 ^ 57] = I("愄濡", "anMGz");
      I[185 ^ 155] = I("嫤堡", "IPakT");
      I[39 ^ 4] = I("摛偙", "eYtiu");
      I[158 ^ 186] = I("夫掂", "TujWv");
      I[173 ^ 136] = I("喉传", "itWYA");
      I[147 ^ 181] = I("櫬悬", "srbHi");
      I[35 ^ 4] = I("咸俥", "luFxL");
      I[121 ^ 81] = I("斒佦", "DMlSC");
      I[32 ^ 9] = I("洩汏", "WiNfP");
      I[170 ^ 128] = I("嬳濰", "nGkJO");
      I[128 ^ 171] = I("凳嫓", "WRIoC");
      I[185 ^ 149] = I("傻傝", "PIxPD");
      I[115 ^ 94] = I("停搒", "ANkWx");
      I[176 ^ 158] = I("仦庻", "GeGQK");
      I[61 ^ 18] = I("漨姮", "Votxu");
      I[17 ^ 33] = I("亱擳", "uRltZ");
      I[109 ^ 92] = I("瀋惙", "LmirH");
      I[91 ^ 105] = I("淌侳", "VwGnU");
      I[176 ^ 131] = I("崖彦", "GxYzl");
      I[177 ^ 133] = I("早晝", "kdfbs");
      I[69 ^ 112] = I("勀桏", "DfbmJ");
      I[14 ^ 56] = I("昿戏", "GlIHY");
      I[154 ^ 173] = I("券奞", "hCPkw");
      I[45 ^ 21] = I("朋", "urjwv");
      I[102 ^ 95] = I(")*\u001f\u0014NYkMBZJm\tZT\u001f1\u001e\u001eT\u0002>K\b\t", "yCqst");
      I[164 ^ 158] = I("l\u0017í\\\u0012îA.", "IdJyv");
      I[112 ^ 75] = I("斁汑峕沇埽", "IVNhV");
      I[24 ^ 36] = I("晩弇", "LIWye");
      I[27 ^ 38] = I("圖偑注怋嶢", "ZPaLm");
      I[22 ^ 40] = I("忦嵍", "XSmow");
      I[73 ^ 118] = I("梌喧", "kJRjV");
      I[198 ^ 134] = I("泱垤嘜孉慣", "WtAjQ");
      I[73 ^ 8] = I("槄浔挿庳收", "oHXYn");
      I[193 ^ 131] = I("淜什枨晡", "OJHcU");
      I[192 ^ 131] = I(":$?,//\u001e)8)$8", "VAXML");
      I[19 ^ 87] = I("毫栌橐浿濤", "tLAKu");
      I[203 ^ 142] = I("櫪湛日", "TjiIb");
      I[46 ^ 104] = I("巨庁攚", "modLy");
      I[56 ^ 127] = I("恰境娵戮", "beGSa");
      I[59 ^ 115] = I("\b=\"\u0012_x|}[Queb@K }l\u0013\u001779l\u000e\u0018b/1", "XTLue");
      I[249 ^ 176] = I("á{FD+Fo5aj5Jc\u0005Oc.", "FJFaO");
      I[228 ^ 174] = I("嵶", "uEfLP");
      I[92 ^ 23] = I("橝唂刺", "RDCzi");
      I[95 ^ 19] = I("剎嚅掙", "phzjK");
      I[223 ^ 146] = I("斞僨洩樢嬺", "jkWVJ");
      I[12 ^ 66] = I("惢峲桳任僳", "NWMjs");
      I[114 ^ 61] = I("嬔烞", "FJQsE");
      I[209 ^ 129] = I("惋怩戮烅掖", "jUdRV");
      I[195 ^ 146] = I("堥捰拭吃", "WTPxP");
      I[238 ^ 188] = I("栖櫴", "Gvjqn");
      I[239 ^ 188] = I("後", "WRBxo");
      I[76 ^ 24] = I("勉櫻湣媳", "Xpnfg");
      I[40 ^ 125] = I("本懆孓倎懬", "aqNnp");
      I[255 ^ 169] = I("涜嬰嶙拋", "zAlvx");
      I[107 ^ 60] = I("\u001c$\u001e8<?\u0000*\u0007&%", "QgbhU");
      I[210 ^ 138] = I("椝婷", "MFjlW");
      I[224 ^ 185] = I("摏徟", "kKdeV");
      I[67 ^ 25] = I("消欢寻涟", "tHLNh");
      I[58 ^ 97] = I("批歾炾佢", "FDQLP");
      I[91 ^ 7] = I("呕桇洏憰峩", "xoerm");
      I[0 ^ 93] = I("#\u0004\u0016\u0018\u00006>\u0000\f\u0006=\u0018", "Oaqyc");
      I[11 ^ 85] = I("湳廬摦橶剀", "IsEsO");
      I[193 ^ 158] = I("奧櫏捔", "Brpvc");
      I[0 ^ 96] = I("佭峆在", "sQMOG");
      I[244 ^ 149] = I("嚺惨", "qWEsl");
      I[85 ^ 55] = I("\u0001\u001d\u0006\fKq\\YEGxT\u000e\u0019\u001e<T\u0013\u0016K*\t", "Qthkq");
      I[124 ^ 31] = I("ÑapV\"vu\u0003sc\u0005PU\u0017FS4", "vPpsF");
      I[73 ^ 45] = I("抸動枊俺毩", "pGZrc");
      I[215 ^ 178] = I("杦焑埭保弿", "kTyIh");
      I[235 ^ 141] = I("揂呫愄", "PjNJe");
      I[43 ^ 76] = I("兙巩櫛檙淬", "yqbrA");
      I[41 ^ 65] = I("氡厮", "xZyWJ");
      I[47 ^ 70] = I("坨憆", "Wulfk");
      I[17 ^ 123] = I("孺浝桄步姗", "bkZEz");
      I[114 ^ 25] = I("椙愡梯掴", "hteGY");
      I[116 ^ 24] = I("扔", "MJdlz");
      I[64 ^ 45] = I("昉瀍", "LXdRy");
      I[66 ^ 44] = I("吸", "ARIpH");
      I[21 ^ 122] = I("僓", "TwSjx");
      I[9 ^ 121] = I("幰删", "QQbMo");
      I[198 ^ 183] = I("噿仐旄", "ESWzM");
      I[47 ^ 93] = I("欥幍", "XUwle");
      I[127 ^ 12] = I("揸旕枯敽昦", "suQDT");
      I[122 ^ 14] = I("欹", "vRMGF");
      I[23 ^ 98] = I("泤岂氪屬摑", "fRXjL");
      I[64 ^ 54] = I("坭佣啾嵁厐", "BDwPQ");
      I[112 ^ 7] = I("幌伋嶦促剃", "AkHwB");
      I[69 ^ 61] = I("櫐噫哞壨宥", "OQmaB");
      I[61 ^ 68] = I("泹", "phSII");
      I[223 ^ 165] = I("\t\u0010$\u0012/\u001c*2\u0006)\u0017\f", "euCsL");
      I[20 ^ 111] = I("坱婮倻欤岸", "FuNGT");
      I[215 ^ 171] = I("榓智持憌", "ZmXDI");
      I[112 ^ 13] = I("垙掤", "LuRhg");
      I[103 ^ 25] = I("叙柣", "rIytv");
      I[27 + 12 - -36 + 52] = I("凄复嘢洛刜", "kYcHM");
      I[30 + 13 - 2 + 87] = I("嘕囶枨寑塣", "HxtZI");
      I[84 + 31 - 56 + 70] = I("儑亐傯浙", "YSEdK");
      I[74 + 48 - 78 + 86] = I("彔夅淘揺", "oOCiR");
      I[71 + 106 - 94 + 48] = I("烌嫕", "BbTmB");
      I[104 + 98 - 80 + 10] = I("擒", "xQPdi");
      I[43 + 15 - -31 + 44] = I("\u001e\u001c!7;\u000b&7#=\u0000\u0000", "ryFVX");
      I[82 + 124 - 174 + 102] = I("掇", "TDkki");
      I[33 + 70 - 44 + 76] = I("了", "ZAJBZ");
      I[128 + 18 - 28 + 18] = I("実潧哘幂", "MORcy");
      I[114 + 97 - 204 + 130] = I("歠偺愊叢焹", "Mdcvz");
      I[55 + 41 - -38 + 4] = I("兕烓泃咗", "qfCfF");
      I[8 + 59 - 38 + 110] = I("屏墈烺恥", "FvOXC");
      I[18 + 133 - 54 + 43] = I("傠", "yhCpX");
      I[117 + 108 - 207 + 123] = I("杯", "CugTP");
      I[61 + 49 - 109 + 141] = I("栓曷匝", "DClOv");
      I[127 + 1 - -7 + 8] = I("\u001d.\u0004\u0006\n\b\u0014\u0012\u0012\f\u00032", "qKcgi");
      I[68 + 136 - 104 + 44] = I("呄利寯慡旿", "ObTdf");
      I[58 + 132 - 133 + 88] = I("听", "wIZtP");
      I[116 + 71 - 137 + 96] = I("淡拺敺", "WllDn");
      I[115 + 43 - 123 + 112] = I("卦悾", "vcitS");
      I[56 + 87 - 36 + 41] = I("擰", "HlBAI");
      I[16 + 109 - 14 + 38] = I("洃侭烠", "wBPQy");
      I[3 + 96 - 98 + 149] = I("\u001b.-89\u000e\u0014;,?\u00052", "wKJYZ");
      I[98 + 123 - 116 + 46] = I("徢杜湀澮", "vgApr");
      I[2 + 65 - 46 + 131] = I("几", "QELRN");
      I[79 + 151 - 217 + 140] = I("堘澯", "JLZWk");
      I[117 + 105 - 133 + 65] = I("匢焨泹渏", "QiWAy");
      I[16 + 152 - 76 + 63] = I("嚊恡唃", "HjmOv");
      I[125 + 146 - 243 + 128] = I("偅攅岟囬嘱", "zhJPE");
      I[122 + 112 - 227 + 150] = I("哑", "kpBmX");
      I[39 + 66 - -51 + 2] = I("嫭濬", "rEzLW");
      I[55 + 79 - 41 + 66] = I("歾伿", "nqXWH");
      I[33 + 39 - 34 + 122] = I("姲檩毑具", "nwJMY");
      I[70 + 67 - 73 + 97] = I("溚殼氢", "XTXUG");
      I[117 + 31 - 46 + 60] = I("圗剋毭慠", "MncKC");
      I[158 + 133 - 223 + 95] = I("梛敥孆", "iPlRY");
      I[104 + 111 - 89 + 38] = I("奻", "okTQP");
      I[154 + 137 - 147 + 21] = I("听坉", "XEuFI");
      I[13 + 138 - 90 + 105] = I("临哆", "zERmZ");
   }

   public LegacyPingHandler(NetworkSystem var1) {
      this.networkSystem = var1;
   }

   private void writeAndFlush(ChannelHandlerContext var1, ByteBuf var2) {
      var1.pipeline().firstContext().writeAndFlush(var2).addListener(ChannelFutureListener.CLOSE);
      I[121 + 136 - 241 + 142].length();
      I[73 + 117 - 41 + 10].length();
   }
}

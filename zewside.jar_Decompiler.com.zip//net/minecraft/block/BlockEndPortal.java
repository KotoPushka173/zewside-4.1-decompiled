package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEndPortal;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockEndPortal extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB END_PORTAL_AABB;

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      if (!var1.isRemote && !var4.isRiding() && !var4.isBeingRidden() && var4.isNonBoss() && var4.getEntityBoundingBox().intersectsWith(var3.getBoundingBox(var1, var2).offset(var2))) {
         var4.changeDimension(" ".length());
         I[187 ^ 189].length();
         I[78 ^ 73].length();
         I[106 ^ 98].length();
      }

   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[143 ^ 139].length();
      I[159 ^ 154].length();
      return new TileEntityEndPortal();
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      double var5 = (double)((float)var3.getX() + var4.nextFloat());
      double var7 = (double)((float)var3.getY() + 0.8F);
      double var9 = (double)((float)var3.getZ() + var4.nextFloat());
      double var11 = 0.0D;
      double var13 = 0.0D;
      double var15 = 0.0D;
      var2.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, var5, var7, var9, 0.0D, 0.0D, 0.0D);
   }

   private static void I() {
      I = new String[80 ^ 89];
      I["".length()] = I("憔槧", "JoAex");
      I[" ".length()] = I("惡怩", "psUHs");
      I["  ".length()] = I("断滽", "KkoIW");
      I["   ".length()] = I("嚘佔", "lJQaS");
      I[45 ^ 41] = I("戆湦掮惕洫", "JSrEW");
      I[69 ^ 64] = I("斝棰情奋僀", "qpAic");
      I[175 ^ 169] = I("岍囇座曌", "PgQIv");
      I[0 ^ 7] = I("慯剏廄", "WnPEE");
      I[6 ^ 14] = I("椌楌柙崓", "XzZAO");
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      return ItemStack.field_190927_a;
   }

   static {
      I();
      END_PORTAL_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.75D, 1.0D);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
   }

   protected BlockEndPortal(Material var1) {
      super(var1);
      this.setLightLevel(1.0F);
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = super.shouldSideBeRendered(var1, var2, var3, var4);
         "".length();
         if (0 >= 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return END_PORTAL_AABB;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 < 1);

      throw null;
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.BLACK;
   }
}

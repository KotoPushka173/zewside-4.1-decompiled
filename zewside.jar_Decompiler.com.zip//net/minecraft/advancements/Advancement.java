package net.minecraft.advancements;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.event.HoverEvent;
import org.apache.commons.lang3.ArrayUtils;

public class Advancement {
   // $FF: synthetic field
   private final AdvancementRewards field_192078_c;
   // $FF: synthetic field
   private final Advancement field_192076_a;
   // $FF: synthetic field
   private final DisplayInfo field_192077_b;
   // $FF: synthetic field
   private final ITextComponent field_193125_h;
   // $FF: synthetic field
   private final Map<String, Criterion> field_192080_e;
   // $FF: synthetic field
   private final ResourceLocation field_192079_d;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final String[][] field_192081_f;
   // $FF: synthetic field
   private final Set<Advancement> field_192082_g = Sets.newLinkedHashSet();

   public int hashCode() {
      return this.field_192079_d.hashCode();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 >= 1);

      throw null;
   }

   static {
      I();
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)" ".length();
      } else if (!(var1 instanceof Advancement)) {
         return (boolean)"".length();
      } else {
         Advancement var2 = (Advancement)var1;
         return this.field_192079_d.equals(var2.field_192079_d);
      }
   }

   @Nullable
   public DisplayInfo func_192068_c() {
      return this.field_192077_b;
   }

   public Iterable<Advancement> func_192069_e() {
      return this.field_192082_g;
   }

   public Advancement(ResourceLocation var1, @Nullable Advancement var2, @Nullable DisplayInfo var3, AdvancementRewards var4, Map<String, Criterion> var5, String[][] var6) {
      this.field_192079_d = var1;
      this.field_192077_b = var3;
      this.field_192080_e = ImmutableMap.copyOf(var5);
      this.field_192076_a = var2;
      this.field_192078_c = var4;
      this.field_192081_f = var6;
      if (var2 != null) {
         var2.func_192071_a(this);
      }

      if (var3 == null) {
         this.field_193125_h = new TextComponentString(var1.toString());
         "".length();
         if (3 < 3) {
            throw null;
         }
      } else {
         this.field_193125_h = new TextComponentString(I["".length()]);
         this.field_193125_h.getStyle().setColor(var3.func_192291_d().func_193229_c());
         ITextComponent var7 = var3.func_192297_a().createCopy();
         TextComponentString var8 = new TextComponentString(I[" ".length()]);
         ITextComponent var9 = var7.createCopy();
         var9.getStyle().setColor(var3.func_192291_d().func_193229_c());
         var8.appendSibling(var9);
         var8.appendText(I["  ".length()]);
         var8.appendSibling(var3.func_193222_b());
         var7.getStyle().setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, var8));
         this.field_193125_h.appendSibling(var7);
         this.field_193125_h.appendText(I["   ".length()]);
      }

   }

   public ITextComponent func_193123_j() {
      return this.field_193125_h;
   }

   public ResourceLocation func_192067_g() {
      return this.field_192079_d;
   }

   public void func_192071_a(Advancement var1) {
      this.field_192082_g.add(var1);
      I[181 ^ 163].length();
      I[130 ^ 149].length();
      I[149 ^ 141].length();
   }

   private static void I() {
      I = new String[116 ^ 109];
      I["".length()] = I("0", "kuzfT");
      I[" ".length()] = I("", "Hhnxz");
      I["  ".length()] = I("F", "LGUab");
      I["   ".length()] = I("\u001f", "BbWKT");
      I[108 ^ 104] = I("三堈", "trOhL");
      I[75 ^ 78] = I("仃吟", "VObwK");
      I[82 ^ 84] = I("医偹", "rLLjk");
      I[50 ^ 53] = I("忉愿", "iTLCb");
      I[183 ^ 191] = I("橲", "SkWbd");
      I[19 ^ 26] = I("娮姥", "itjQG");
      I[126 ^ 116] = I("曇婑", "XtjQf");
      I[172 ^ 167] = I("呌亞", "aYTbZ");
      I[131 ^ 143] = I("屲侠", "UvzFm");
      I[207 ^ 194] = I("欏", "NZhTd");
      I[4 ^ 10] = I("抲叠光挑孞", "glJpx");
      I[146 ^ 157] = I("2'\t\u0014(\u0004\u000f\u0000\u0012%\u000f-\u0001\t!\u000f:\u001f\r \\", "aNddD");
      I[94 ^ 78] = I("|l%1\u00075\"!m", "PLUPu");
      I[98 ^ 115] = I("\u0014\u001a\t\u0018", "zoetF");
      I[5 ^ 23] = I("Dh\t \u0010\u0018$\f0^", "hHmIc");
      I[29 ^ 14] = I("@r*<\u001a\r <*P", "lRXYm");
      I[167 ^ 179] = I("kB6! 3\u0007':(z", "GbUSI");
      I[130 ^ 151] = I("mK7''4\u00027';$\u000511k", "AkEBV");
      I[79 ^ 89] = I("淺", "bTwzi");
      I[78 ^ 89] = I("忚烧浯槠", "IJazb");
      I[125 ^ 101] = I("怲懤丒", "FGFyK");
   }

   public Map<String, Criterion> func_192073_f() {
      return this.field_192080_e;
   }

   public int func_193124_g() {
      return this.field_192081_f.length;
   }

   public String[][] func_192074_h() {
      return this.field_192081_f;
   }

   public AdvancementRewards func_192072_d() {
      return this.field_192078_c;
   }

   @Nullable
   public Advancement func_192070_b() {
      return this.field_192076_a;
   }

   public String toString() {
      String var10000 = I[156 ^ 149];
      String var10001 = I[27 ^ 17];
      String var10002 = I[36 ^ 47];
      var10001 = I[105 ^ 101];
      I[24 ^ 21].length();
      I[66 ^ 76].length();
      StringBuilder var1 = (new StringBuilder()).append(I[1 ^ 14]).append(this.func_192067_g()).append(I[164 ^ 180]);
      Object var2;
      if (this.field_192076_a == null) {
         var2 = I[103 ^ 118];
         "".length();
         if (3 <= -1) {
            throw null;
         }
      } else {
         var2 = this.field_192076_a.func_192067_g();
      }

      return var1.append(var2).append(I[130 ^ 144]).append(this.field_192077_b).append(I[187 ^ 168]).append(this.field_192078_c).append(I[178 ^ 166]).append(this.field_192080_e).append(I[34 ^ 55]).append(Arrays.deepToString(this.field_192081_f)).append((char)('\u007f' ^ '\u0002')).toString();
   }

   public Advancement.Builder func_192075_a() {
      String var10000 = I[111 ^ 107];
      String var10001 = I[58 ^ 63];
      String var10002 = I[25 ^ 31];
      var10001 = I[113 ^ 118];
      Advancement.Builder var1 = new Advancement.Builder;
      I[71 ^ 79].length();
      ResourceLocation var2;
      if (this.field_192076_a == null) {
         var2 = null;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var2 = this.field_192076_a.func_192067_g();
      }

      var1.<init>(var2, this.field_192077_b, this.field_192078_c, this.field_192080_e, this.field_192081_f);
      return var1;
   }

   public static class Builder {
      // $FF: synthetic field
      private final AdvancementRewards field_192064_d;
      // $FF: synthetic field
      private final String[][] field_192066_f;
      // $FF: synthetic field
      private final ResourceLocation field_192061_a;
      // $FF: synthetic field
      private Advancement field_192062_b;
      // $FF: synthetic field
      private final DisplayInfo field_192063_c;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final Map<String, Criterion> field_192065_e;

      public static Advancement.Builder func_192060_b(PacketBuffer var0) throws IOException {
         String var10000 = I[19 + 132 - 46 + 36];
         String var10001 = I[48 + 91 - 131 + 134];
         String var10002 = I[22 + 57 - 54 + 118];
         var10001 = I[77 + 21 - 92 + 138];
         ResourceLocation var7;
         if (var0.readBoolean()) {
            var7 = var0.func_192575_l();
            "".length();
            if (0 >= 4) {
               throw null;
            }
         } else {
            var7 = null;
         }

         ResourceLocation var1 = var7;
         DisplayInfo var8;
         if (var0.readBoolean()) {
            var8 = DisplayInfo.func_192295_b(var0);
            "".length();
            if (1 < 1) {
               throw null;
            }
         } else {
            var8 = null;
         }

         DisplayInfo var2 = var8;
         Map var3 = Criterion.func_192142_c(var0);
         String[][] var4 = new String[var0.readVarIntFromBuffer()][];
         int var5 = "".length();

         do {
            if (var5 >= var4.length) {
               I[90 + 32 - 16 + 39].length();
               I[9 + 87 - 84 + 134].length();
               return new Advancement.Builder(var1, var2, AdvancementRewards.field_192114_a, var3, var4);
            }

            var4[var5] = new String[var0.readVarIntFromBuffer()];
            int var6 = "".length();

            while(var6 < var4[var5].length) {
               var4[var5][var6] = var0.readStringFromBuffer(2793 + 9580 - -5822 + 14572);
               ++var6;
               "".length();
               if (0 >= 3) {
                  throw null;
               }
            }

            ++var5;
            "".length();
         } while(1 != 4);

         throw null;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(4 > 1);

         throw null;
      }

      public void func_192057_a(PacketBuffer var1) {
         if (this.field_192061_a == null) {
            var1.writeBoolean((boolean)"".length());
            I[173 ^ 168].length();
            I[183 ^ 177].length();
            I[20 ^ 19].length();
            "".length();
            if (3 <= 2) {
               throw null;
            }
         } else {
            var1.writeBoolean((boolean)" ".length());
            I[46 ^ 38].length();
            I[136 ^ 129].length();
            var1.func_192572_a(this.field_192061_a);
            I[95 ^ 85].length();
            I[143 ^ 132].length();
         }

         if (this.field_192063_c == null) {
            var1.writeBoolean((boolean)"".length());
            I[177 ^ 189].length();
            I[47 ^ 34].length();
            I[9 ^ 7].length();
            I[171 ^ 164].length();
            "".length();
            if (0 >= 3) {
               throw null;
            }
         } else {
            var1.writeBoolean((boolean)" ".length());
            I[19 ^ 3].length();
            I[213 ^ 196].length();
            this.field_192063_c.func_192290_a(var1);
         }

         Criterion.func_192141_a(this.field_192065_e, var1);
         var1.writeVarIntToBuffer(this.field_192066_f.length);
         I[190 ^ 172].length();
         I[91 ^ 72].length();
         I[165 ^ 177].length();
         String[][] var2 = this.field_192066_f;
         int var3 = var2.length;
         int var4 = "".length();

         do {
            if (var4 >= var3) {
               return;
            }

            String[] var5 = var2[var4];
            var1.writeVarIntToBuffer(var5.length);
            I[125 ^ 104].length();
            I[163 ^ 181].length();
            I[165 ^ 178].length();
            I[97 ^ 121].length();
            I[67 ^ 90].length();
            String[] var6 = var5;
            int var7 = var5.length;
            int var8 = "".length();

            while(var8 < var7) {
               String var9 = var6[var8];
               var1.writeString(var9);
               I[153 ^ 131].length();
               I[112 ^ 107].length();
               I[70 ^ 90].length();
               ++var8;
               "".length();
               if (0 >= 2) {
                  throw null;
               }
            }

            ++var4;
            "".length();
         } while(4 != -1);

         throw null;
      }

      public Advancement func_192056_a(ResourceLocation var1) {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         I[90 ^ 94].length();
         return new Advancement(var1, this.field_192062_b, this.field_192063_c, this.field_192064_d, this.field_192065_e, this.field_192066_f);
      }

      public String toString() {
         String var10000 = I[72 ^ 85];
         String var10001 = I[43 ^ 53];
         String var10002 = I[114 ^ 109];
         var10001 = I[10 ^ 42];
         I[53 ^ 20].length();
         I[110 ^ 76].length();
         return I[170 ^ 137] + this.field_192061_a + I[177 ^ 149] + this.field_192063_c + I[119 ^ 82] + this.field_192064_d + I[16 ^ 54] + this.field_192065_e + I[115 ^ 84] + Arrays.deepToString(this.field_192066_f) + ('Ç' ^ 'º');
      }

      static {
         I();
      }

      private static void I() {
         I = new String[50 + 12 - -5 + 80];
         I["".length()] = I("婹昔", "WeFIo");
         I[" ".length()] = I("櫔仿", "wTtTk");
         I["  ".length()] = I("朢叜", "nytYL");
         I["   ".length()] = I("怔湒", "ojOjr");
         I[143 ^ 139] = I("潬橚溲斞叩", "lmRHs");
         I[129 ^ 132] = I("俚孷", "jroxs");
         I[80 ^ 86] = I("囥樷", "FjtHB");
         I[181 ^ 178] = I("弥捘垇", "kFJZg");
         I[5 ^ 13] = I("季毂", "DtkMm");
         I[98 ^ 107] = I("侨夔", "PeJct");
         I[182 ^ 188] = I("悩瀫攈坼毵", "yIika");
         I[63 ^ 52] = I("侶換媪", "mxaHg");
         I[58 ^ 54] = I("址昮", "UBOAR");
         I[103 ^ 106] = I("儜揳", "BmYHm");
         I[41 ^ 39] = I("巉伷", "bMODg");
         I[92 ^ 83] = I("傟汝傲宙", "fdLeY");
         I[146 ^ 130] = I("沒妘垝櫞崢", "QKqXV");
         I[151 ^ 134] = I("孞懧", "uinDd");
         I[37 ^ 55] = I("嚕嚴彠", "ATLOy");
         I[7 ^ 20] = I("律悶", "hDfNT");
         I[154 ^ 142] = I("巯", "QJVsw");
         I[81 ^ 68] = I("侃炿峊劕亻", "vHDYS");
         I[28 ^ 10] = I("愇懺栤撾", "ofdaa");
         I[184 ^ 175] = I("借", "QmXcz");
         I[72 ^ 80] = I("婇", "yXZds");
         I[50 ^ 43] = I("卓瀯晞姟", "Lmwnp");
         I[72 ^ 82] = I("原垍敵宯晨", "zGBlQ");
         I[76 ^ 87] = I("攁岷愜宏", "IYoFM");
         I[44 ^ 48] = I("攜漘尭煒妚", "BaHwl");
         I[36 ^ 57] = I("櫵帯", "heqFb");
         I[143 ^ 145] = I("嗮泧", "gllkI");
         I[84 ^ 75] = I("櫾壸", "RhspH");
         I[139 ^ 171] = I("嚮儗", "kgihL");
         I[145 ^ 176] = I("头櫄刞嵂", "ZvJTP");
         I[54 ^ 20] = I("洛古川擹", "SpDlX");
         I[54 ^ 21] = I("&\u0002\u00179w3\u0007\u001239\u0011\u0006\t79\u0006\u0018\u00143%\u0017\r\u0010\u001b3O", "rcdRW");
         I[226 ^ 198] = I("YP\u001e\u0001\u001c\u0005\u001c\u001b\u0011R", "upzho");
         I[65 ^ 100] = I("Ym+'\u001f\u0014?=1U", "uMYBh");
         I[27 ^ 61] = I("_E\u0011;\u0003\u0007\u0000\u0000 \u000bN", "serIj");
         I[113 ^ 86] = I("JL*1:\u0013\u0005*1&\u0003\u0002,'v", "flXTK");
         I[175 ^ 135] = I("明刕", "AoZbO");
         I[173 ^ 132] = I("惖溨", "qpKAt");
         I[73 ^ 99] = I("撙傢", "tgSrJ");
         I[64 ^ 107] = I("扦寏", "XFigj");
         I[186 ^ 150] = I("墟偕", "Abqco");
         I[87 ^ 122] = I("嘦伣", "QeWDy");
         I[139 ^ 165] = I("捂殴", "LLkOM");
         I[142 ^ 161] = I("吧烦", "CugEr");
         I[139 ^ 187] = I("捅佔", "bPYMz");
         I[8 ^ 57] = I("慁暹", "sEQeS");
         I[65 ^ 115] = I("慫吾", "iLKQD");
         I[154 ^ 169] = I("夷姄", "RqZqk");
         I[174 ^ 154] = I("徲淈", "tOAwL");
         I[127 ^ 74] = I("梢掮", "NhaDd");
         I[83 ^ 101] = I("埏剃", "dNtvr");
         I[144 ^ 167] = I("忥汏", "hXoLv");
         I[105 ^ 81] = I("彥味", "rKIXI");
         I[26 ^ 35] = I("湪乚", "RkpiO");
         I[39 ^ 29] = I("欨涐", "hefHg");
         I[150 ^ 173] = I("兢丶", "Wheln");
         I[118 ^ 74] = I("樑媁", "ysbYs");
         I[56 ^ 5] = I("婓殃", "eCtVX");
         I[177 ^ 143] = I("愫准", "TAiij");
         I[72 ^ 119] = I("洕圴", "pgOFc");
         I[227 ^ 163] = I("巤刁", "MganC");
         I[73 ^ 8] = I("弆勿", "QyEJR");
         I[83 ^ 17] = I("吚噾", "Vgxpv");
         I[112 ^ 51] = I("啍伍", "pZgOK");
         I[15 ^ 75] = I("溗昤", "VNqcJ");
         I[216 ^ 157] = I("播嘺", "MYiAo");
         I[83 ^ 21] = I("嫦厃", "ArPqs");
         I[104 ^ 47] = I("楓曙", "ZgHPC");
         I[39 ^ 111] = I("湑倎", "oRTii");
         I[110 ^ 39] = I("曒丆", "PkvPA");
         I[105 ^ 35] = I("嵝昰", "QNHNY");
         I[77 ^ 6] = I("淎悢", "mcbxq");
         I[79 ^ 3] = I("樾姻", "btjBg");
         I[122 ^ 55] = I("杌咯", "FxyXP");
         I[61 ^ 115] = I("噼拃", "dBRaU");
         I[255 ^ 176] = I("恮扞", "dQYKK");
         I[196 ^ 148] = I("嶗店", "gTDdP");
         I[26 ^ 75] = I("性揽", "BDqJp");
         I[195 ^ 145] = I("枨厎", "DhZqC");
         I[254 ^ 173] = I("棞柒", "CTxLH");
         I[53 ^ 97] = I("俑煠", "qYMrt");
         I[206 ^ 155] = I("審壃", "qswjj");
         I[95 ^ 9] = I("婗泑", "yrFMu");
         I[201 ^ 158] = I("愚円", "oaEqZ");
         I[250 ^ 162] = I(">6\u0003\u0013-:", "NWqvC");
         I[78 ^ 23] = I("廢椹圽旾", "gMzDl");
         I[72 ^ 18] = I("4\u0012(\u0004\"0", "DsZaL");
         I[234 ^ 177] = I("\r88$:\b(", "iQKTV");
         I[29 ^ 65] = I("\u0013(7\u001f\u0001\u00168", "wADom");
         I[37 ^ 120] = I("\u0000/\u00045!\u00169", "rJsTS");
         I[33 ^ 127] = I("\u0016\u0002!\u0006+\u0007\u0019)", "upHrN");
         I[24 ^ 71] = I("柿屣桡柫儎", "LudlX");
         I[85 ^ 53] = I("\u0017\u00008\u000585\u0001#\u00018\"D-\u0016?\"\u0001<\r7v\u0007/\n89\u0010n\u00063v\u0001#\u0014\"/", "VdNdV");
         I[107 ^ 10] = I("廮殿伈", "xeWNo");
         I[58 ^ 88] = I("\u001d\u001c\u00011\u0011\u001d\u001c\u001d!\u0016\u001b\n", "oypDx");
         I[8 ^ 107] = I("催台夘儁慍", "bKivO");
         I[106 ^ 14] = I("搤啿", "VkpUR");
         I[95 ^ 58] = I("吨孡挆栙", "LqWmu");
         I[193 ^ 167] = I("两抺", "GiUmB");
         I[78 ^ 41] = I(" \u0016?>\u0005 \u0016#.\u0002&\u0000\u0015", "RsNKl");
         I[19 ^ 123] = I("\u000b", "VkRoo");
         I[83 ^ 58] = I("墸", "ApAiG");
         I[213 ^ 191] = I("瀵", "KSykD");
         I[203 ^ 160] = I("剔彊勼枆", "ewrUs");
         I[58 ^ 86] = I("枿浗", "FUStN");
         I[43 ^ 70] = I(";\u000f\u00058%;\u000f\u0019(\"=\u0019/", "IjtML");
         I[225 ^ 143] = I("\n3", "WhAZN");
         I[2 ^ 109] = I("?", "bHPTd");
         I[193 ^ 177] = I("図嬄", "dKwDi");
         I[75 ^ 58] = I("宮擿桦", "TKNUD");
         I[241 ^ 131] = I("炓", "WNmRy");
         I[85 ^ 38] = I("煁妼擣", "vIGvd");
         I[61 ^ 73] = I(" \u0001&&:\u0000\u0001:6=\u0006D2='\u0000\u001dw02\u001c\n8's\u0010\u0001w6>\u0002\u0010.", "rdWSS");
         I[39 ^ 82] = I("格嶲拿彰", "gnuAk");
         I[245 ^ 131] = I("橧匣殤孋", "lAJkX");
         I[39 ^ 80] = I("孩抴扞泓", "nnVxD");
         I[96 ^ 24] = I("征咮", "cWOUT");
         I[228 ^ 157] = I("漾", "HUktk");
         I[23 ^ 109] = I("岡", "hRjoH");
         I[101 ^ 30] = I("8\u001b)/\u000e\u001a\u001bb3\u0004\u001c\u0000+3\u0004\tU!3\b\u0019\u00100(\u000e\u0003Ue", "muBAa");
         I[246 ^ 138] = I("J", "mzRBH");
         I[98 ^ 31] = I("扭懿清欯", "oFgay");
         I[88 ^ 38] = I("櫗式", "xvJNm");
         I[1 + 118 - 65 + 73] = I("坂滘勗滤旙", "GvVHM");
         I[45 + 91 - 47 + 39] = I("滑溈", "fnREL");
         I[67 + 35 - 86 + 113] = I("拹榮", "UNbIK");
         I[47 + 32 - -25 + 26] = I("吻嫦懧壿旫", "RcRgH");
         I[33 + 83 - 115 + 130] = I("崛憴恥", "Syzfr");
         I[82 + 45 - 40 + 45] = I("楪欑拱帒", "kqICm");
         I[16 + 23 - -70 + 24] = I(")\"\u0003\u001a\b\u00189\u0005\u0000MM", "jPjnm");
         I[61 + 2 - -42 + 29] = I("mh\u001f\t9m<V\u001bw8-\u0007\u000f>8-\u001b\u001f9>h\u0010\u0015%j+\u0019\u0017'&-\u0002\u00138$fV.?#;V\u0013$$o\u0002Z$?8\u0006\u0015%>-\u0012Z5/ \u0017\f>%=\u0004Vw+$\u001aZ48!\u0002\u001f%#)V\u0017\"9<V\u00182j:\u0013\u000b\"#:\u0013\u001ey", "JHvzW");
         I[78 + 90 - 163 + 130] = I("呇昒圅撓氍", "wbtaU");
         I[82 + 56 - 34 + 32] = I("廽", "mqQNC");
         I[129 + 4 - 7 + 11] = I("怏彆忙", "fiVAk");
         I[45 + 40 - 83 + 136] = I("古咧庬孟", "hvwma");
         I[47 + 1 - 5 + 96] = I("樗圓應佞", "mdUVz");
         I[135 + 11 - 72 + 66] = I("嫄忱", "RgWig");
         I[98 + 103 - 73 + 13] = I("姀宰", "nmTkI");
         I[69 + 88 - 22 + 7] = I("斺曄", "ldqPa");
         I[51 + 30 - 8 + 70] = I("娼圷", "MrsCt");
         I[23 + 21 - -82 + 18] = I("橤欃", "Ognuq");
         I[85 + 99 - 127 + 88] = I("掯怍", "gBtva");
         I[81 + 144 - 183 + 104] = I("尨成党", "MBThW");
      }

      public boolean func_192058_a(Function<ResourceLocation, Advancement> var1) {
         if (this.field_192061_a == null) {
            return (boolean)" ".length();
         } else {
            this.field_192062_b = (Advancement)var1.apply(this.field_192061_a);
            int var10000;
            if (this.field_192062_b != null) {
               var10000 = " ".length();
               "".length();
               if (4 < 3) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      }

      public static Advancement.Builder func_192059_a(JsonObject var0, JsonDeserializationContext var1) {
         String var10000 = I[159 ^ 183];
         String var10001 = I[127 ^ 86];
         String var10002 = I[116 ^ 94];
         var10001 = I[15 ^ 36];
         var10000 = I[188 ^ 144];
         var10001 = I[8 ^ 37];
         var10002 = I[239 ^ 193];
         var10001 = I[234 ^ 197];
         var10000 = I[90 ^ 106];
         var10001 = I[131 ^ 178];
         var10002 = I[32 ^ 18];
         var10001 = I[245 ^ 198];
         var10000 = I[246 ^ 194];
         var10001 = I[48 ^ 5];
         var10002 = I[185 ^ 143];
         var10001 = I[83 ^ 100];
         var10000 = I[148 ^ 172];
         var10001 = I[176 ^ 137];
         var10002 = I[143 ^ 181];
         var10001 = I[6 ^ 61];
         var10000 = I[106 ^ 86];
         var10001 = I[114 ^ 79];
         var10002 = I[66 ^ 124];
         var10001 = I[127 ^ 64];
         var10000 = I[208 ^ 144];
         var10001 = I[86 ^ 23];
         var10002 = I[43 ^ 105];
         var10001 = I[128 ^ 195];
         var10000 = I[94 ^ 26];
         var10001 = I[135 ^ 194];
         var10002 = I[55 ^ 113];
         var10001 = I[98 ^ 37];
         var10000 = I[122 ^ 50];
         var10001 = I[34 ^ 107];
         var10002 = I[239 ^ 165];
         var10001 = I[192 ^ 139];
         var10000 = I[244 ^ 184];
         var10001 = I[54 ^ 123];
         var10002 = I[48 ^ 126];
         var10001 = I[95 ^ 16];
         var10000 = I[8 ^ 88];
         var10001 = I[85 ^ 4];
         var10002 = I[28 ^ 78];
         var10001 = I[237 ^ 190];
         var10000 = I[200 ^ 156];
         var10001 = I[96 ^ 53];
         var10002 = I[39 ^ 113];
         var10001 = I[150 ^ 193];
         ResourceLocation var25;
         if (var0.has(I[91 ^ 3])) {
            I[109 ^ 52].length();
            var25 = new ResourceLocation(JsonUtils.getString(var0, I[12 ^ 86]));
            "".length();
            if (0 < 0) {
               throw null;
            }
         } else {
            var25 = null;
         }

         ResourceLocation var2 = var25;
         DisplayInfo var26;
         if (var0.has(I[73 ^ 18])) {
            var26 = DisplayInfo.func_192294_a(JsonUtils.getJsonObject(var0, I[126 ^ 34]), var1);
            "".length();
            if (3 <= 0) {
               throw null;
            }
         } else {
            var26 = null;
         }

         DisplayInfo var3 = var26;
         AdvancementRewards var4 = (AdvancementRewards)JsonUtils.deserializeClass(var0, I[126 ^ 35], AdvancementRewards.field_192114_a, var1, AdvancementRewards.class);
         Map var5 = Criterion.func_192144_b(JsonUtils.getJsonObject(var0, I[24 ^ 70]), var1);
         JsonSyntaxException var31;
         if (var5.isEmpty()) {
            I[21 ^ 74].length();
            var31 = new JsonSyntaxException(I[253 ^ 157]);
            I[40 ^ 73].length();
            throw var31;
         } else {
            var10001 = I[245 ^ 151];
            I[167 ^ 196].length();
            I[23 ^ 115].length();
            JsonArray var6 = JsonUtils.getJsonArray(var0, var10001, new JsonArray());
            String[][] var7 = new String[var6.size()][];
            int var8 = "".length();

            do {
               int var10;
               if (var8 >= var6.size()) {
                  if (var7.length == 0) {
                     var7 = new String[var5.size()][];
                     var8 = "".length();
                     Iterator var16 = var5.keySet().iterator();

                     while(var16.hasNext()) {
                        String var21 = (String)var16.next();
                        int var32 = var8++;
                        String[] var30 = new String[" ".length()];
                        I[18 ^ 98].length();
                        I[23 ^ 102].length();
                        I[176 ^ 194].length();
                        var30["".length()] = var21;
                        var7[var32] = var30;
                        "".length();
                        if (1 < 0) {
                           throw null;
                        }
                     }
                  }

                  String[][] var17 = var7;
                  int var18 = var7.length;
                  var10 = "".length();

                  do {
                     int var13;
                     if (var10 >= var18) {
                        Iterator var19 = var5.keySet().iterator();

                        do {
                           if (!var19.hasNext()) {
                              I[88 + 127 - 105 + 28].length();
                              I[59 + 106 - 150 + 124].length();
                              I[34 + 44 - -6 + 56].length();
                              return new Advancement.Builder(var2, var3, var4, var5, var7);
                           }

                           String var20 = (String)var19.next();
                           var10 = "".length();
                           String[][] var22 = var7;
                           int var23 = var7.length;
                           var13 = "".length();

                           while(var13 < var23) {
                              String[] var24 = var22[var13];
                              if (ArrayUtils.contains(var24, var20)) {
                                 var10 = " ".length();
                                 "".length();
                                 if (false) {
                                    throw null;
                                 }
                                 break;
                              }

                              ++var13;
                              "".length();
                              if (false) {
                                 throw null;
                              }
                           }

                           if (var10 == 0) {
                              I[123 + 53 - 89 + 41].length();
                              I[107 + 38 - 103 + 87].length();
                              I[92 + 96 - 70 + 12].length();
                              I[120 + 101 - 205 + 115].length();
                              I[74 + 118 - 141 + 81].length();
                              var31 = new JsonSyntaxException(I[63 + 24 - 12 + 58] + var20 + I[0 + 71 - -13 + 50]);
                              I[8 + 76 - -27 + 24].length();
                              I[112 + 101 - 172 + 95].length();
                              I[41 + 38 - 50 + 108].length();
                              throw var31;
                           }

                           "".length();
                        } while(true);

                        throw null;
                     }

                     String[] var11 = var17[var10];
                     if (var11.length == 0 && var5.isEmpty()) {
                        I[25 ^ 106].length();
                        var31 = new JsonSyntaxException(I[228 ^ 144]);
                        I[86 ^ 35].length();
                        I[98 ^ 20].length();
                        throw var31;
                     }

                     String[] var12 = var11;
                     var13 = var11.length;
                     int var14 = "".length();

                     while(var14 < var13) {
                        String var15 = var12[var14];
                        if (!var5.containsKey(var15)) {
                           I[27 ^ 108].length();
                           I[36 ^ 92].length();
                           I[104 ^ 17].length();
                           I[81 ^ 43].length();
                           var31 = new JsonSyntaxException(I[101 ^ 30] + var15 + I[51 ^ 79]);
                           I[57 ^ 68].length();
                           I[107 ^ 21].length();
                           I[103 + 87 - 66 + 3].length();
                           throw var31;
                        }

                        ++var14;
                        "".length();
                        if (3 != 3) {
                           throw null;
                        }
                     }

                     ++var10;
                     "".length();
                  } while(-1 == -1);

                  throw null;
               }

               JsonElement var27 = var6.get(var8);
               I[53 ^ 80].length();
               I[91 ^ 61].length();
               JsonArray var9 = JsonUtils.getJsonArray(var27, I[226 ^ 133] + var8 + I[91 ^ 51]);
               var7[var8] = new String[var9.size()];
               var10 = "".length();

               while(var10 < var9.size()) {
                  String[] var29 = var7[var8];
                  JsonElement var28 = var9.get(var10);
                  I[38 ^ 79].length();
                  I[252 ^ 150].length();
                  I[52 ^ 95].length();
                  I[250 ^ 150].length();
                  var29[var10] = JsonUtils.getString(var28, I[96 ^ 13] + var8 + I[102 ^ 8] + var10 + I[102 ^ 9]);
                  ++var10;
                  "".length();
                  if (2 <= 1) {
                     throw null;
                  }
               }

               ++var8;
               "".length();
            } while(1 >= 1);

            throw null;
         }
      }

      Builder(@Nullable ResourceLocation var1, @Nullable DisplayInfo var2, AdvancementRewards var3, Map<String, Criterion> var4, String[][] var5) {
         this.field_192061_a = var1;
         this.field_192063_c = var2;
         this.field_192064_d = var3;
         this.field_192065_e = var4;
         this.field_192066_f = var5;
      }
   }
}

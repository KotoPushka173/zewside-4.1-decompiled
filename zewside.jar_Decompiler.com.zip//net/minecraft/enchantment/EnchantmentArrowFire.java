package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentArrowFire extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   public EnchantmentArrowFire(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.BOW, var2);
      this.setName(I["".length()]);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 != -1);

      throw null;
   }

   public int getMaxEnchantability(int var1) {
      return 188 ^ 142;
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("\u0010\u0011\u000b\u0015>7\n\u000b\u001f", "qcyzI");
   }

   public int getMaxLevel() {
      return " ".length();
   }

   public int getMinEnchantability(int var1) {
      return 171 ^ 191;
   }
}

package net.minecraft.dispenser;

import net.minecraft.block.BlockDispenser;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IProjectile;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public abstract class BehaviorProjectileDispense extends BehaviorDefaultDispenseItem {
   // $FF: synthetic field
   private static final String[] I;

   protected void playDispenseSound(IBlockSource var1) {
      var1.getWorld().playEvent(911 + 437 - 474 + 128, var1.getBlockPos(), "".length());
   }

   private static void I() {
      I = new String[49 ^ 53];
      I["".length()] = I("幷咠傛淥", "KHPXh");
      I[" ".length()] = I("幔厔埇", "npPfE");
      I["  ".length()] = I("抟奉戨", "QIvQc");
      I["   ".length()] = I("擡呍副幀", "VmwGp");
   }

   protected float getProjectileInaccuracy() {
      return 6.0F;
   }

   protected float getProjectileVelocity() {
      return 1.1F;
   }

   protected abstract IProjectile getProjectileEntity(World var1, IPosition var2, ItemStack var3);

   public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
      World var3 = var1.getWorld();
      IPosition var4 = BlockDispenser.getDispensePosition(var1);
      EnumFacing var5 = (EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING);
      IProjectile var6 = this.getProjectileEntity(var3, var4, var2);
      var6.setThrowableHeading((double)var5.getFrontOffsetX(), (double)((float)var5.getFrontOffsetY() + 0.1F), (double)var5.getFrontOffsetZ(), this.getProjectileVelocity(), this.getProjectileInaccuracy());
      var3.spawnEntityInWorld((Entity)var6);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var2.func_190918_g(" ".length());
      return var2;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   static {
      I();
   }
}

package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.List;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketEntityMetadata implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private List<EntityDataManager.DataEntry<?>> dataManagerEntries;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int entityId;

   public SPacketEntityMetadata(int var1, EntityDataManager var2, boolean var3) {
      this.entityId = var1;
      if (var3) {
         this.dataManagerEntries = var2.getAll();
         var2.setClean();
         "".length();
         if (2 >= 3) {
            throw null;
         }
      } else {
         this.dataManagerEntries = var2.getDirty();
      }

   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityMetadata(this);
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > -1);

      throw null;
   }

   public int getEntityId() {
      return this.entityId;
   }

   public List<EntityDataManager.DataEntry<?>> getDataManagerEntries() {
      return this.dataManagerEntries;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      EntityDataManager.writeEntries(this.dataManagerEntries, var1);
   }

   public SPacketEntityMetadata() {
   }

   private static void I() {
      I = new String[" ".length()];
      I["".length()] = I("槢最尀", "jDPmy");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.dataManagerEntries = EntityDataManager.readEntries(var1);
   }
}

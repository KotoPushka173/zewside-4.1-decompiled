package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockSlime extends BlockBreakable {
   // $FF: synthetic field
   private static final String[] I;

   public BlockSlime() {
      super(Material.CLAY, (boolean)"".length(), MapColor.GRASS);
      this.setCreativeTab(CreativeTabs.DECORATIONS);
      this.slipperiness = 0.8F;
   }

   private static void I() {
      I = new String[81 ^ 67];
      I["".length()] = I("噙淭", "nsMmG");
      I[" ".length()] = I("坳啣", "bJPbr");
      I["  ".length()] = I("帢漒", "tJLva");
      I["   ".length()] = I("煉坨", "ZVwvR");
      I[148 ^ 144] = I("召婜扐", "FqVIy");
      I[111 ^ 106] = I("沅劣沼", "cLJQY");
      I[179 ^ 181] = I("旼", "CpOVO");
      I[17 ^ 22] = I("巪溷", "eFFMg");
      I[73 ^ 65] = I("慕欪", "qAQqN");
      I[62 ^ 55] = I("勤愓", "bEHxZ");
      I[13 ^ 7] = I("奒啇", "kPeZi");
      I[44 ^ 39] = I("掿娵", "OfQOj");
      I[11 ^ 7] = I("楟煭", "xiaVB");
      I[127 ^ 114] = I("壡潻", "wjrki");
      I[122 ^ 116] = I("榧昩", "LaFwQ");
      I[207 ^ 192] = I("檓", "uBNve");
      I[27 ^ 11] = I("涇昘惚敒", "oILAZ");
      I[171 ^ 186] = I("摶岨岣嘝懰", "jdFWT");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 3);

      throw null;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.TRANSLUCENT;
   }

   static {
      I();
   }

   public void onLanded(World var1, Entity var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (var2.isSneaking()) {
         super.onLanded(var1, var2);
         "".length();
         if (4 <= 0) {
            throw null;
         }
      } else if (var2.motionY < 0.0D) {
         var2.motionY = -var2.motionY;
         if (!(var2 instanceof EntityLivingBase)) {
            I[126 ^ 122].length();
            I[51 ^ 54].length();
            I[174 ^ 168].length();
            var2.motionY *= 0.8D;
         }
      }

   }

   public void onEntityWalk(World var1, BlockPos var2, Entity var3) {
      String var10000 = I[39 ^ 32];
      String var10001 = I[97 ^ 105];
      String var10002 = I[62 ^ 55];
      var10001 = I[94 ^ 84];
      var10000 = I[0 ^ 11];
      var10001 = I[132 ^ 136];
      var10002 = I[28 ^ 17];
      var10001 = I[20 ^ 26];
      if (Math.abs(var3.motionY) < 0.1D && !var3.isSneaking()) {
         double var4 = 0.4D + Math.abs(var3.motionY) * 0.2D;
         I[38 ^ 41].length();
         I[104 ^ 120].length();
         var3.motionX *= var4;
         I[137 ^ 152].length();
         var3.motionZ *= var4;
      }

      super.onEntityWalk(var1, var2, var3);
   }

   public void onFallenUpon(World var1, BlockPos var2, Entity var3, float var4) {
      if (var3.isSneaking()) {
         super.onFallenUpon(var1, var2, var3, var4);
         "".length();
         if (2 == 1) {
            throw null;
         }
      } else {
         var3.fall(var4, 0.0F);
      }

   }
}

package net.minecraft.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerWorkbench;
import net.minecraft.stats.StatList;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;

public class BlockWorkbench extends Block {
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 0);

      throw null;
   }

   static {
      I();
   }

   private static void I() {
      I = new String[17 ^ 22];
      I["".length()] = I("槻明", "gwRep");
      I[" ".length()] = I("氀条", "vQDje");
      I["  ".length()] = I("焊捧", "HSsAp");
      I["   ".length()] = I("厦寎", "MZcAX");
      I[161 ^ 165] = I("洢枓灒榦恚", "ilsYn");
      I[8 ^ 13] = I("巤柯澿", "fiCTi");
      I[19 ^ 21] = I("揚廠櫄宑", "ugVlY");
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         I[163 ^ 167].length();
         I[99 ^ 102].length();
         I[187 ^ 189].length();
         var4.displayGui(new BlockWorkbench.InterfaceCraftingTable(var1, var2));
         var4.addStat(StatList.CRAFTING_TABLE_INTERACTION);
         return (boolean)" ".length();
      }
   }

   protected BlockWorkbench() {
      super(Material.WOOD);
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public static class InterfaceCraftingTable implements IInteractionObject {
      // $FF: synthetic field
      private final World world;
      // $FF: synthetic field
      private final BlockPos position;
      // $FF: synthetic field
      private static final String[] I;

      public InterfaceCraftingTable(World var1, BlockPos var2) {
         this.world = var1;
         this.position = var2;
      }

      public Container createContainer(InventoryPlayer var1, EntityPlayer var2) {
         String var10000 = I[147 ^ 131];
         String var10001 = I[92 ^ 77];
         String var10002 = I[47 ^ 61];
         var10001 = I[90 ^ 73];
         I[114 ^ 102].length();
         return new ContainerWorkbench(var1, this.world, this.position);
      }

      public boolean hasCustomName() {
         return (boolean)"".length();
      }

      private static void I() {
         I = new String[152 ^ 142];
         I["".length()] = I("6;2-\"<'4\u0014\"4+?.", "UISKV");
         I[" ".length()] = I("桏潅", "hYEfm");
         I["  ".length()] = I("欴忮", "tUEJP");
         I["   ".length()] = I("弛洅", "Wnbub");
         I[71 ^ 67] = I("峚中", "TAOZE");
         I[110 ^ 107] = I("枴娖", "meGve");
         I[95 ^ 89] = I("楚滊", "pcwlK");
         I[95 ^ 88] = I("杶撅", "YWpfg");
         I[115 ^ 123] = I("溜勔", "SNaTU");
         I[0 ^ 9] = I("擸", "zpUKh");
         I[133 ^ 143] = I("僥濥孈下", "gGTTR");
         I[201 ^ 194] = I("婠涢創", "CxOoD");
         I[110 ^ 98] = I("檿孶崟灸", "sPxcM");
         I[2 ^ 15] = I("柕歫增", "QUVBw");
         I[143 ^ 129] = I("浉屍恱", "bMqbH");
         I[98 ^ 109] = I("@\u001c( &", "nrIMC");
         I[153 ^ 137] = I("功宨", "YqPin");
         I[4 ^ 21] = I("忛敩", "uHVKv");
         I[10 ^ 24] = I("寉捔", "AWztd");
         I[33 ^ 50] = I("忽巽", "ecYsR");
         I[142 ^ 154] = I("卭并照厁", "rFYHP");
         I[116 ^ 97] = I("5\u001c\u0003\u0000**\u0014\u000b\u0011s;\u0007\f\u0003=1\u001b\n:=9\u0017\u0001\u0000", "XumeI");
      }

      public String getGuiID() {
         return I[26 ^ 15];
      }

      public ITextComponent getDisplayName() {
         String var10000 = I[" ".length()];
         String var10001 = I["  ".length()];
         String var10002 = I["   ".length()];
         var10001 = I[28 ^ 24];
         var10000 = I[55 ^ 50];
         var10001 = I[78 ^ 72];
         var10002 = I[95 ^ 88];
         var10001 = I[45 ^ 37];
         I[133 ^ 140].length();
         I[187 ^ 177].length();
         I[50 ^ 57].length();
         I[83 ^ 95].length();
         I[190 ^ 179].length();
         I[151 ^ 153].length();
         return new TextComponentTranslation(Blocks.CRAFTING_TABLE.getUnlocalizedName() + I[13 ^ 2], new Object["".length()]);
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 != 2);

         throw null;
      }

      static {
         I();
      }

      public String getName() {
         return I["".length()];
      }
   }
}

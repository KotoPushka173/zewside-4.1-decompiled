package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockPotato extends BlockCrops {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final AxisAlignedBB[] POTATO_AABB;

   protected Item getSeed() {
      return Items.POTATO;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return POTATO_AABB[(Integer)var1.getValue(this.getAgeProperty())];
   }

   private static void I() {
      I = new String[38 ^ 33];
      I["".length()] = I("弯撍", "szXBV");
      I[" ".length()] = I("寓幃", "ZRoip");
      I["  ".length()] = I("丽匪", "Rhmgz");
      I["   ".length()] = I("探櫹", "aalEU");
      I[72 ^ 76] = I("滆复宵啻", "AEshx");
      I[26 ^ 31] = I("举槃撐", "cXeBj");
      I[74 ^ 76] = I("墾煠烸啺", "bPvJg");
   }

   protected Item getCrop() {
      return Items.POTATO;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      super.dropBlockAsItemWithChance(var1, var2, var3, var4, var5);
      if (!var1.isRemote && this.isMaxAge(var3) && var1.rand.nextInt(53 ^ 7) == 0) {
         I[134 ^ 130].length();
         I[122 ^ 127].length();
         I[73 ^ 79].length();
         spawnAsEntity(var1, var2, new ItemStack(Items.POISONOUS_POTATO));
      }

   }

   static {
      I();
      AxisAlignedBB[] var10000 = new AxisAlignedBB[127 ^ 119];
      var10000["".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.125D, 1.0D);
      var10000[" ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.1875D, 1.0D);
      var10000["  ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.25D, 1.0D);
      var10000["   ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.3125D, 1.0D);
      var10000[9 ^ 13] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.375D, 1.0D);
      var10000[184 ^ 189] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.4375D, 1.0D);
      var10000[19 ^ 21] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
      var10000[111 ^ 104] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5625D, 1.0D);
      POTATO_AABB = var10000;
   }
}

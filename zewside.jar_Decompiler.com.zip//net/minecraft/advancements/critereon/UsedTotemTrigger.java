package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class UsedTotemTrigger implements ICriterionTrigger<UsedTotemTrigger.Instance> {
   // $FF: synthetic field
   private static final ResourceLocation field_193188_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<PlayerAdvancements, UsedTotemTrigger.Listeners> field_193189_b = Maps.newHashMap();

   public ResourceLocation func_192163_a() {
      return field_193188_a;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<UsedTotemTrigger.Instance> var2) {
      UsedTotemTrigger.Listeners var3 = (UsedTotemTrigger.Listeners)this.field_193189_b.get(var1);
      if (var3 != null) {
         var3.func_193506_b(var2);
         if (var3.func_193507_a()) {
            this.field_193189_b.remove(var1);
            I[12 ^ 5].length();
            I[71 ^ 77].length();
         }
      }

   }

   static {
      I();
      field_193188_a = new ResourceLocation(I[65 ^ 85]);
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193189_b.remove(var1);
      I[64 ^ 75].length();
      I[21 ^ 25].length();
   }

   private static void I() {
      I = new String[155 ^ 142];
      I["".length()] = I("櫏张", "AtNKv");
      I[" ".length()] = I("哻卅", "lwLCU");
      I["  ".length()] = I("朤埓", "LriZY");
      I["   ".length()] = I("廅暡", "deKiQ");
      I[29 ^ 25] = I("抯摥峧僛", "FuUuR");
      I[67 ^ 70] = I("檼堷煕歴曬", "fZyxT");
      I[187 ^ 189] = I("婺奭孁", "EJwuw");
      I[64 ^ 71] = I("拜幱卜", "AASxE");
      I[167 ^ 175] = I("汳泯揂", "mqleM");
      I[49 ^ 56] = I("咆浑优昲徠", "xiiRT");
      I[137 ^ 131] = I("倽樍懙", "ZndTg");
      I[173 ^ 166] = I("俼尽", "ithFp");
      I[40 ^ 36] = I("抳垩泘拢", "nORLj");
      I[184 ^ 181] = I("偯瀌", "hFWwb");
      I[61 ^ 51] = I("淭榕", "Ucaxk");
      I[85 ^ 90] = I("汩叞", "SGIcu");
      I[6 ^ 22] = I("灊匾", "lOFZf");
      I[101 ^ 116] = I(":1)>", "SELSQ");
      I[73 ^ 91] = I("旍奦憧滉", "KcvBZ");
      I[38 ^ 53] = I("潈忆", "DEjMt");
      I[31 ^ 11] = I("7\u0012\u001f\u000e\u00106\u000e\u000e\u000f\"", "BazjO");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 4);

      throw null;
   }

   public UsedTotemTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[12 ^ 1];
      String var10001 = I[182 ^ 184];
      String var10002 = I[170 ^ 165];
      var10001 = I[115 ^ 99];
      ItemPredicate var3 = ItemPredicate.func_192492_a(var1.get(I[91 ^ 74]));
      I[176 ^ 162].length();
      I[12 ^ 31].length();
      return new UsedTotemTrigger.Instance(var3);
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<UsedTotemTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      UsedTotemTrigger.Listeners var3 = (UsedTotemTrigger.Listeners)this.field_193189_b.get(var1);
      if (var3 == null) {
         I[159 ^ 155].length();
         I[194 ^ 199].length();
         I[53 ^ 51].length();
         var3 = new UsedTotemTrigger.Listeners(var1);
         this.field_193189_b.put(var1, var3);
         I[78 ^ 73].length();
         I[130 ^ 138].length();
      }

      var3.func_193508_a(var2);
   }

   public void func_193187_a(EntityPlayerMP var1, ItemStack var2) {
      UsedTotemTrigger.Listeners var3 = (UsedTotemTrigger.Listeners)this.field_193189_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_193509_a(var2);
      }

   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<UsedTotemTrigger.Instance>> field_193511_b = Sets.newHashSet();
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final PlayerAdvancements field_193510_a;

      static {
         I();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 < 4);

         throw null;
      }

      public boolean func_193507_a() {
         return this.field_193511_b.isEmpty();
      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193510_a = var1;
      }

      public void func_193509_a(ItemStack var1) {
         ArrayList var2 = null;
         Iterator var3 = this.field_193511_b.iterator();

         ICriterionTrigger.Listener var4;
         while(var3.hasNext()) {
            var4 = (ICriterionTrigger.Listener)var3.next();
            if (((UsedTotemTrigger.Instance)var4.func_192158_a()).func_193218_a(var1)) {
               if (var2 == null) {
                  var2 = Lists.newArrayList();
               }

               var2.add(var4);
               I[20 ^ 17].length();
               I[80 ^ 86].length();
            }

            "".length();
            if (-1 >= 2) {
               throw null;
            }
         }

         if (var2 != null) {
            var3 = var2.iterator();

            while(var3.hasNext()) {
               var4 = (ICriterionTrigger.Listener)var3.next();
               var4.func_192159_a(this.field_193510_a);
               "".length();
               if (4 != 4) {
                  throw null;
               }
            }
         }

      }

      public void func_193506_b(ICriterionTrigger.Listener<UsedTotemTrigger.Instance> var1) {
         this.field_193511_b.remove(var1);
         I["  ".length()].length();
         I["   ".length()].length();
         I[160 ^ 164].length();
      }

      private static void I() {
         I = new String[54 ^ 49];
         I["".length()] = I("弜", "bAzHv");
         I[" ".length()] = I("孻塱楣廼哿", "Yshdi");
         I["  ".length()] = I("搱", "OhhYi");
         I["   ".length()] = I("峮", "uENMr");
         I[66 ^ 70] = I("屬永叩浧", "xNtjO");
         I[39 ^ 34] = I("朶屁刃慨", "uDDHM");
         I[58 ^ 60] = I("殏押", "vDNmO");
      }

      public void func_193508_a(ICriterionTrigger.Listener<UsedTotemTrigger.Instance> var1) {
         this.field_193511_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final ItemPredicate field_193219_a;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 == 2);

         throw null;
      }

      public boolean func_193218_a(ItemStack var1) {
         return this.field_193219_a.func_192493_a(var1);
      }

      public Instance(ItemPredicate var1) {
         super(UsedTotemTrigger.field_193188_a);
         this.field_193219_a = var1;
      }
   }
}

package net.minecraft.block;

import com.google.common.base.Predicate;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityMinecartCommandBlock;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockRailDetector extends BlockRailBase {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool POWERED;
   // $FF: synthetic field
   public static final PropertyEnum<BlockRailBase.EnumRailDirection> SHAPE;

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote && (Boolean)var3.getValue(POWERED)) {
         this.updatePoweredState(var1, var2, var3);
      }

   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(SHAPE, BlockRailBase.EnumRailDirection.byMetadata(var1 & (22 ^ 17)));
      PropertyBool var10001 = POWERED;
      int var10002;
      if ((var1 & (42 ^ 34)) > 0) {
         var10002 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public int tickRate(World var1) {
      return 8 ^ 28;
   }

   private static void I() {
      I = new String[210 ^ 146];
      I["".length()] = I("庉洵", "aZhpP");
      I[" ".length()] = I("溂洔", "FfnkS");
      I["  ".length()] = I("劌抴", "VUvkw");
      I["   ".length()] = I("樯昒", "nRjOa");
      I[46 ^ 42] = I("咦服凶堾徟", "ibtvf");
      I[58 ^ 63] = I("哢垦夜", "EfzIs");
      I[3 ^ 5] = I("旐", "jSWEk");
      I[119 ^ 112] = I("徢斕屑溚溳", "wOIby");
      I[85 ^ 93] = I("浝墀擊", "UvYcC");
      I[83 ^ 90] = I("峾嚶", "IOvxC");
      I[179 ^ 185] = I("巯嶻", "UoSDn");
      I[176 ^ 187] = I("凐嵉", "BwoNU");
      I[161 ^ 173] = I("櫧欨", "RZMav");
      I[15 ^ 2] = I("慞嵣", "FxJxT");
      I[181 ^ 187] = I("溬幍", "dnWsm");
      I[155 ^ 148] = I("承度", "TDiva");
      I[132 ^ 148] = I("深厠", "QiByJ");
      I[119 ^ 102] = I("沈屨", "PFOXG");
      I[174 ^ 188] = I("搌勇", "XrnlK");
      I[66 ^ 81] = I("柊揜", "LoQHS");
      I[19 ^ 7] = I("怃棾乼伌", "MIFdI");
      I[150 ^ 131] = I("吽巺", "FGrFO");
      I[4 ^ 18] = I("淳殄", "XCESV");
      I[57 ^ 46] = I("榕卆", "SbKQH");
      I[166 ^ 190] = I("洟株", "qWmcE");
      I[154 ^ 131] = I("悬晄", "KRZZT");
      I[15 ^ 21] = I("廻橗按惗", "HFlSX");
      I[150 ^ 141] = I("灶", "hcBpa");
      I[2 ^ 30] = I("櫓", "WgmuX");
      I[0 ^ 29] = I("橸戗恠", "YVWDg");
      I[33 ^ 63] = I("吱捇", "WDIsa");
      I[49 ^ 46] = I("团渹佻", "XoPKr");
      I[5 ^ 37] = I("劳办槔俎幔", "vkAcK");
      I[60 ^ 29] = I("澈喃朁", "lPGFl");
      I[178 ^ 144] = I("心厷嚣", "SxkMA");
      I[186 ^ 153] = I("忩", "XAqpw");
      I[182 ^ 146] = I("嘰", "iJZup");
      I[9 ^ 44] = I("媛浀", "vaoho");
      I[101 ^ 67] = I("檌哘", "DpgTL");
      I[15 ^ 40] = I("惶喸", "ZExpF");
      I[38 ^ 14] = I("乹攀", "IwGBk");
      I[59 ^ 18] = I("板搭", "rmbgo");
      I[51 ^ 25] = I("弾叡", "EGEhM");
      I[17 ^ 58] = I("媳嶿", "tWkfW");
      I[127 ^ 83] = I("噜孿", "BFpEO");
      I[165 ^ 136] = I("欀惀", "mQJjz");
      I[6 ^ 40] = I("激屷", "hZcPw");
      I[141 ^ 162] = I("唬拇", "ExAyu");
      I[87 ^ 103] = I("暸曶", "xjXBN");
      I[59 ^ 10] = I("孩", "MKXWK");
      I[189 ^ 143] = I("婥桿瀥弱嘭", "crBaI");
      I[157 ^ 174] = I("榎惈浨", "PBraY");
      I[97 ^ 85] = I("炓嶎殍", "jJvWF");
      I[28 ^ 41] = I("哫嶧嚧", "CFTRb");
      I[175 ^ 153] = I("戫", "JzNjR");
      I[244 ^ 195] = I("巾氛剁匮刂", "BFXpt");
      I[40 ^ 16] = I("怔汊", "hGBRJ");
      I[110 ^ 87] = I("挣榬洜", "QRHDb");
      I[113 ^ 75] = I("嘱", "hirJw");
      I[117 ^ 78] = I("帇殸惭屵尮", "lXJhV");
      I[17 ^ 45] = I("勉寽侣", "egfqI");
      I[73 ^ 116] = I("瀔晸帅歸嚬", "IvanN");
      I[250 ^ 196] = I(">+\u0003!\u0012", "MCbQw");
      I[145 ^ 174] = I("7%\u0013\u0010\u0014\".", "GJduf");
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      BlockRailBase.EnumRailDirection var3 = (BlockRailBase.EnumRailDirection)var1.getValue(SHAPE);
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[var3.ordinal()]) {
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         default:
            return super.withMirror(var1, var2);
         }
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[var3.ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 3:
         case 4:
         default:
            "".length();
            if (4 <= 3) {
               throw null;
            }
            break;
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         }
      default:
         return super.withMirror(var1, var2);
      }
   }

   protected <T extends EntityMinecart> List<T> findMinecarts(World var1, BlockPos var2, Class<T> var3, Predicate<Entity>... var4) {
      AxisAlignedBB var5 = this.getDectectionBox(var2);
      List var10000;
      if (var4.length != " ".length()) {
         var10000 = var1.getEntitiesWithinAABB(var3, var5);
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10000 = var1.getEntitiesWithinAABB(var3, var5, var4["".length()]);
      }

      return var10000;
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      super.onBlockAdded(var1, var2, var3);
      this.updatePoweredState(var1, var2, var3);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      String var10000 = I[67 ^ 83];
      String var10001 = I[38 ^ 55];
      String var10002 = I[160 ^ 178];
      var10001 = I[59 ^ 40];
      if ((Boolean)var1.getValue(POWERED)) {
         List var4 = this.findMinecarts(var2, var3, EntityMinecartCommandBlock.class);
         if (!var4.isEmpty()) {
            return ((EntityMinecartCommandBlock)var4.get("".length())).getCommandBlockLogic().getSuccessCount();
         }

         Predicate[] var10004 = new Predicate[" ".length()];
         I[65 ^ 85].length();
         var10004["".length()] = EntitySelectors.HAS_INVENTORY;
         List var5 = this.findMinecarts(var2, var3, EntityMinecart.class, var10004);
         if (!var5.isEmpty()) {
            return Container.calcRedstoneFromInventory((IInventory)var5.get("".length()));
         }
      }

      return "".length();
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         }
      case 2:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 9:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
         case 10:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH);
         }
      case 3:
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).ordinal()]) {
         case 1:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
         case 2:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
         case 3:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
         case 4:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
         case 5:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
         case 6:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
         case 7:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
         case 8:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
         case 9:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
         case 10:
            return var1.withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH);
         }
      default:
         return var1;
      }
   }

   static {
      I();
      SHAPE = PropertyEnum.create(I[66 ^ 124], BlockRailBase.EnumRailDirection.class, new Predicate<BlockRailBase.EnumRailDirection>() {
         public boolean apply(@Nullable BlockRailBase.EnumRailDirection var1) {
            int var10000;
            if (var1 != BlockRailBase.EnumRailDirection.NORTH_EAST && var1 != BlockRailBase.EnumRailDirection.NORTH_WEST && var1 != BlockRailBase.EnumRailDirection.SOUTH_EAST && var1 != BlockRailBase.EnumRailDirection.SOUTH_WEST) {
               var10000 = " ".length();
               "".length();
               if (false) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(4 >= 1);

            throw null;
         }
      });
      POWERED = PropertyBool.create(I[82 ^ 109]);
   }

   private void updatePoweredState(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      boolean var4 = (Boolean)var3.getValue(POWERED);
      int var5 = "".length();
      List var6 = this.findMinecarts(var1, var2, EntityMinecart.class);
      if (!var6.isEmpty()) {
         var5 = " ".length();
      }

      if (var5 != 0 && !var4) {
         var1.setBlockState(var2, var3.withProperty(POWERED, Boolean.valueOf((boolean)" ".length())), "   ".length());
         I[154 ^ 158].length();
         I[152 ^ 157].length();
         I[81 ^ 87].length();
         this.updateConnectedRails(var1, var2, var3, (boolean)" ".length());
         var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
         var1.notifyNeighborsOfStateChange(var2.down(), this, (boolean)"".length());
         var1.markBlockRangeForRenderUpdate(var2, var2);
      }

      if (var5 == 0 && var4) {
         var1.setBlockState(var2, var3.withProperty(POWERED, Boolean.valueOf((boolean)"".length())), "   ".length());
         I[19 ^ 20].length();
         I[25 ^ 17].length();
         this.updateConnectedRails(var1, var2, var3, (boolean)"".length());
         var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
         var1.notifyNeighborsOfStateChange(var2.down(), this, (boolean)"".length());
         var1.markBlockRangeForRenderUpdate(var2, var2);
      }

      if (var5 != 0) {
         I[63 ^ 54].length();
         var1.scheduleUpdate(new BlockPos(var2), this, this.tickRate(var1));
      }

      var1.updateComparatorOutputLevel(var2, this);
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((BlockRailBase.EnumRailDirection)var1.getValue(SHAPE)).getMetadata();
      if ((Boolean)var1.getValue(POWERED)) {
         var2 |= 88 ^ 80;
      }

      return var2;
   }

   public IProperty<BlockRailBase.EnumRailDirection> getShapeProperty() {
      return SHAPE;
   }

   public void onEntityCollidedWithBlock(World var1, BlockPos var2, IBlockState var3, Entity var4) {
      if (!var1.isRemote && !(Boolean)var3.getValue(POWERED)) {
         this.updatePoweredState(var1, var2, var3);
      }

   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if ((Boolean)var1.getValue(POWERED)) {
         var10000 = 115 ^ 124;
         "".length();
         if (3 < 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   private AxisAlignedBB getDectectionBox(BlockPos var1) {
      String var10000 = I[91 ^ 78];
      String var10001 = I[73 ^ 95];
      String var10002 = I[211 ^ 196];
      var10001 = I[78 ^ 86];
      float var2 = 0.2F;
      I[185 ^ 160].length();
      I[126 ^ 100].length();
      I[156 ^ 135].length();
      I[173 ^ 177].length();
      double var5 = (double)((float)var1.getX() + 0.2F);
      double var10003 = (double)var1.getY();
      double var10004 = (double)((float)var1.getZ() + 0.2F);
      float var10005 = (float)(var1.getX() + " ".length());
      I[52 ^ 41].length();
      I[102 ^ 120].length();
      double var3 = (double)(var10005 - 0.2F);
      float var10006 = (float)(var1.getY() + " ".length());
      I[84 ^ 75].length();
      I[3 ^ 35].length();
      I[180 ^ 149].length();
      double var4 = (double)(var10006 - 0.2F);
      float var10007 = (float)(var1.getZ() + " ".length());
      I[16 ^ 50].length();
      I[114 ^ 81].length();
      I[164 ^ 128].length();
      return new AxisAlignedBB(var5, var10003, var10004, var3, var4, (double)(var10007 - 0.2F));
   }

   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (!(Boolean)var1.getValue(POWERED)) {
         return "".length();
      } else {
         int var10000;
         if (var4 == EnumFacing.UP) {
            var10000 = 130 ^ 141;
            "".length();
            if (false) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return var10000;
      }
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[173 ^ 136];
      String var10001 = I[138 ^ 172];
      String var10002 = I[80 ^ 119];
      var10001 = I[188 ^ 148];
      var10000 = I[8 ^ 33];
      var10001 = I[63 ^ 21];
      var10002 = I[165 ^ 142];
      var10001 = I[83 ^ 127];
      var10000 = I[63 ^ 18];
      var10001 = I[56 ^ 22];
      var10002 = I[59 ^ 20];
      var10001 = I[150 ^ 166];
      I[72 ^ 121].length();
      I[148 ^ 166].length();
      I[51 ^ 0].length();
      I[46 ^ 26].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[148 ^ 161].length();
      I[35 ^ 21].length();
      I[128 ^ 183].length();
      I[159 ^ 167].length();
      I[13 ^ 52].length();
      var10003["".length()] = SHAPE;
      I[82 ^ 104].length();
      I[78 ^ 117].length();
      I[165 ^ 153].length();
      I[188 ^ 129].length();
      var10003[" ".length()] = POWERED;
      return new BlockStateContainer(this, var10003);
   }

   protected void updateConnectedRails(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      String var10000 = I[61 ^ 55];
      String var10001 = I[153 ^ 146];
      String var10002 = I[159 ^ 147];
      var10001 = I[118 ^ 123];
      I[83 ^ 93].length();
      I[23 ^ 24].length();
      BlockRailBase.Rail var5 = new BlockRailBase.Rail(var1, var2, var3);
      Iterator var6 = var5.getConnectedRails().iterator();

      do {
         if (!var6.hasNext()) {
            return;
         }

         BlockPos var7 = (BlockPos)var6.next();
         IBlockState var8 = var1.getBlockState(var7);
         if (var8 != null) {
            var8.neighborChanged(var1, var7, var8.getBlock(), var2);
         }

         "".length();
      } while(2 != 3);

      throw null;
   }

   public boolean canProvidePower(IBlockState var1) {
      return (boolean)" ".length();
   }

   public BlockRailDetector() {
      super((boolean)" ".length());
      this.setDefaultState(this.blockState.getBaseState().withProperty(POWERED, Boolean.valueOf((boolean)"".length())).withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH));
      this.setTickRandomly((boolean)" ".length());
   }

   public void randomTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
   }
}

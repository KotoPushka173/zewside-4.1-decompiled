package net.minecraft.dispenser;

import net.minecraft.block.BlockDispenser;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class BehaviorDefaultDispenseItem implements IBehaviorDispenseItem {
   // $FF: synthetic field
   private static final String[] I;

   protected void playDispenseSound(IBlockSource var1) {
      var1.getWorld().playEvent(222 + 114 - -156 + 508, var1.getBlockPos(), "".length());
   }

   public final ItemStack dispense(IBlockSource var1, ItemStack var2) {
      ItemStack var3 = this.dispenseStack(var1, var2);
      this.playDispenseSound(var1);
      this.spawnDispenseParticles(var1, (EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING));
      return var3;
   }

   protected void spawnDispenseParticles(IBlockSource var1, EnumFacing var2) {
      var1.getWorld().playEvent(290 + 1349 - 618 + 979, var1.getBlockPos(), this.getWorldEventDataFrom(var2));
   }

   protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
      EnumFacing var3 = (EnumFacing)var1.getBlockState().getValue(BlockDispenser.FACING);
      IPosition var4 = BlockDispenser.getDispensePosition(var1);
      ItemStack var5 = var2.splitStack(" ".length());
      doDispense(var1.getWorld(), var5, 81 ^ 87, var3, var4);
      return var2;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 2);

      throw null;
   }

   public static void doDispense(World var0, ItemStack var1, int var2, EnumFacing var3, IPosition var4) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[49 ^ 53];
      var10001 = I[130 ^ 135];
      var10002 = I[155 ^ 157];
      var10001 = I[38 ^ 33];
      var10000 = I[19 ^ 27];
      var10001 = I[86 ^ 95];
      var10002 = I[130 ^ 136];
      var10001 = I[93 ^ 86];
      var10000 = I[62 ^ 50];
      var10001 = I[105 ^ 100];
      var10002 = I[117 ^ 123];
      var10001 = I[105 ^ 102];
      double var5 = var4.getX();
      double var7 = var4.getY();
      double var9 = var4.getZ();
      if (var3.getAxis() == EnumFacing.Axis.Y) {
         I[25 ^ 9].length();
         I[14 ^ 31].length();
         I[182 ^ 164].length();
         var7 -= 0.125D;
         "".length();
         if (-1 != -1) {
            throw null;
         }
      } else {
         I[85 ^ 70].length();
         I[119 ^ 99].length();
         var7 -= 0.15625D;
      }

      I[43 ^ 62].length();
      I[83 ^ 69].length();
      I[100 ^ 115].length();
      I[87 ^ 79].length();
      EntityItem var11 = new EntityItem(var0, var5, var7, var9, var1);
      double var12 = var0.rand.nextDouble() * 0.1D + 0.2D;
      var11.motionX = (double)var3.getFrontOffsetX() * var12;
      var11.motionY = 0.20000000298023224D;
      var11.motionZ = (double)var3.getFrontOffsetZ() * var12;
      I[74 ^ 83].length();
      I[15 ^ 21].length();
      var11.motionX += var0.rand.nextGaussian() * 0.007499999832361937D * (double)var2;
      I[87 ^ 76].length();
      I[76 ^ 80].length();
      var11.motionY += var0.rand.nextGaussian() * 0.007499999832361937D * (double)var2;
      I[109 ^ 112].length();
      I[31 ^ 1].length();
      var11.motionZ += var0.rand.nextGaussian() * 0.007499999832361937D * (double)var2;
      var0.spawnEntityInWorld(var11);
      I[111 ^ 112].length();
      I[115 ^ 83].length();
   }

   private static void I() {
      I = new String[14 ^ 47];
      I["".length()] = I("坔涏", "CcGgc");
      I[" ".length()] = I("弥拸", "VneXd");
      I["  ".length()] = I("幮欅", "eyYFe");
      I["   ".length()] = I("些撦", "OMzzu");
      I[8 ^ 12] = I("汏懷", "dVrxK");
      I[35 ^ 38] = I("朇憫", "jZCoO");
      I[148 ^ 146] = I("櫓灾", "RpPco");
      I[54 ^ 49] = I("刍斠", "LmESO");
      I[38 ^ 46] = I("局摅", "kduTg");
      I[133 ^ 140] = I("夽抶", "cfrAH");
      I[202 ^ 192] = I("毉潬", "alyBL");
      I[30 ^ 21] = I("妜場", "WgBBf");
      I[111 ^ 99] = I("栄呀", "mOYIm");
      I[124 ^ 113] = I("城柠", "JyuAB");
      I[169 ^ 167] = I("撿婄", "TXgpu");
      I[183 ^ 184] = I("唿啻", "adljO");
      I[187 ^ 171] = I("暔屢呬", "MHmPm");
      I[181 ^ 164] = I("傁欸", "BSDPf");
      I[85 ^ 71] = I("湈廥灗夆崖", "mAMKB");
      I[97 ^ 114] = I("橉朜圀曆潸", "YYYar");
      I[135 ^ 147] = I("便", "zIOBM");
      I[90 ^ 79] = I("嵥戽摃厇嘻", "XaXdp");
      I[18 ^ 4] = I("濤殏壅恉崈", "kbFef");
      I[70 ^ 81] = I("彀侊", "gyQBz");
      I[168 ^ 176] = I("梯柽乜烔擈", "slaxP");
      I[94 ^ 71] = I("哒", "vRDRE");
      I[18 ^ 8] = I("倢", "dNEJi");
      I[183 ^ 172] = I("歫歀泘堑", "wzbul");
      I[77 ^ 81] = I("並濴", "XxdKC");
      I[107 ^ 118] = I("凧夜灞", "cxrVA");
      I[95 ^ 65] = I("恫杈", "nzvpT");
      I[42 ^ 53] = I("姄橎", "SBmmX");
      I[57 ^ 25] = I("仇掦刟扄桭", "AOfnq");
   }

   private int getWorldEventDataFrom(EnumFacing var1) {
      return var1.getFrontOffsetX() + " ".length() + (var1.getFrontOffsetZ() + " ".length()) * "   ".length();
   }

   static {
      I();
   }
}

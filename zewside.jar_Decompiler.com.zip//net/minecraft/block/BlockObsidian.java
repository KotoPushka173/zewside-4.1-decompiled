package net.minecraft.block;

import java.util.Random;
import me.zewside.client.event.EventManager;
import me.zewside.client.event.events.impl.player.ObsidianPlaceEvent;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockObsidian extends Block {
   // $FF: synthetic field
   private static final String[] I;

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 1);

      throw null;
   }

   private static void I() {
      I = new String[158 ^ 152];
      I["".length()] = I("搞偘", "lpcBB");
      I[" ".length()] = I("椳刪", "gZFzb");
      I["  ".length()] = I("呫氨", "MvJBM");
      I["   ".length()] = I("挼側", "zTwtF");
      I[120 ^ 124] = I("唤媟峓檍澷", "LMXOh");
      I[61 ^ 56] = I("汅坢", "nhrKY");
   }

   public BlockObsidian() {
      super(Material.ROCK);
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.BLACK;
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[121 ^ 125].length();
      ObsidianPlaceEvent var6 = new ObsidianPlaceEvent(this, var2);
      EventManager.call(var6);
      I[133 ^ 128].length();
      super.onBlockPlacedBy(var1, var2, var3, var4, var5);
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.OBSIDIAN);
   }
}

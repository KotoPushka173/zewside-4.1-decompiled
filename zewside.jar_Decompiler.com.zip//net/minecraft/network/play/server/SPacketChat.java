package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;

public class SPacketChat implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private ITextComponent chatComponent;
   // $FF: synthetic field
   private ChatType type;
   // $FF: synthetic field
   private static final String[] I;

   private static void I() {
      I = new String[39 ^ 34];
      I["".length()] = I("崒工憟檶", "IArzf");
      I[" ".length()] = I("屰", "xHsBo");
      I["  ".length()] = I("歎娯揢", "spmoF");
      I["   ".length()] = I("溂啦", "KUPHQ");
      I[29 ^ 25] = I("楠槗攝煾侼", "vPFOa");
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 3);

      throw null;
   }

   public SPacketChat(ITextComponent var1, ChatType var2) {
      this.chatComponent = var1;
      this.type = var2;
   }

   public SPacketChat() {
   }

   public SPacketChat(ITextComponent var1) {
      this(var1, ChatType.SYSTEM);
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleChat(this);
   }

   public ChatType getChatType() {
      return this.type;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.chatComponent = var1.readTextComponent();
      this.type = ChatType.func_192582_a(var1.readByte());
   }

   public ChatType func_192590_c() {
      return this.type;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeTextComponent(this.chatComponent);
      I["".length()].length();
      I[" ".length()].length();
      var1.writeByte(this.type.func_192583_a());
      I["  ".length()].length();
      I["   ".length()].length();
      I[196 ^ 192].length();
   }

   public ITextComponent getChatComponent() {
      return this.chatComponent;
   }

   public boolean isSystem() {
      int var10000;
      if (this.type != ChatType.SYSTEM && this.type != ChatType.GAME_INFO) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (3 < 1) {
            throw null;
         }
      }

      return (boolean)var10000;
   }
}

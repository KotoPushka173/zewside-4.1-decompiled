package net.minecraft.block;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldProviderEnd;

public class BlockFire extends Block {
   // $FF: synthetic field
   public static final PropertyInteger AGE;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool EAST;
   // $FF: synthetic field
   public static final PropertyBool UPPER;
   // $FF: synthetic field
   public static final PropertyBool NORTH;
   // $FF: synthetic field
   public static final PropertyBool SOUTH;
   // $FF: synthetic field
   private final Map<Block, Integer> encouragements = Maps.newIdentityHashMap();
   // $FF: synthetic field
   public static final PropertyBool WEST;
   // $FF: synthetic field
   private final Map<Block, Integer> flammabilities = Maps.newIdentityHashMap();

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public MapColor getMapColor(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return MapColor.TNT;
   }

   public boolean requiresUpdates() {
      return (boolean)"".length();
   }

   private void catchOnFire(World var1, BlockPos var2, int var3, Random var4, int var5) {
      int var6 = this.getFlammability(var1.getBlockState(var2).getBlock());
      if (var4.nextInt(var3) < var6) {
         IBlockState var7 = var1.getBlockState(var2);
         if (var4.nextInt(var5 + (158 ^ 148)) < (39 ^ 34) && !var1.isRainingAt(var2)) {
            int var8 = var5 + var4.nextInt(87 ^ 82) / (74 ^ 78);
            if (var8 > (133 ^ 138)) {
               var8 = 147 ^ 156;
            }

            var1.setBlockState(var2, this.getDefaultState().withProperty(AGE, var8), "   ".length());
            I[221 ^ 196].length();
            I[134 ^ 156].length();
            I[62 ^ 37].length();
            I[105 ^ 117].length();
            "".length();
            if (1 <= 0) {
               throw null;
            }
         } else {
            var1.setBlockToAir(var2);
            I[127 ^ 98].length();
            I[222 ^ 192].length();
         }

         if (var7.getBlock() == Blocks.TNT) {
            Blocks.TNT.onBlockDestroyedByPlayer(var1, var2, var7.withProperty(BlockTNT.EXPLODE, Boolean.valueOf((boolean)" ".length())));
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 < 3);

      throw null;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (var1.provider.getDimensionType().getId() > 0 || !Blocks.PORTAL.trySpawnPortal(var1, var2)) {
         if (!var1.getBlockState(var2.down()).isFullyOpaque() && !this.canNeighborCatchFire(var1, var2)) {
            var1.setBlockToAir(var2);
            I[227 ^ 199].length();
            "".length();
            if (3 < 0) {
               throw null;
            }
         } else {
            var1.scheduleUpdate(var2, this, this.tickRate(var1) + var1.rand.nextInt(66 ^ 72));
         }
      }

   }

   public static void init() {
      Blocks.FIRE.setFireInfo(Blocks.PLANKS, 78 ^ 75, 37 ^ 49);
      Blocks.FIRE.setFireInfo(Blocks.DOUBLE_WOODEN_SLAB, 164 ^ 161, 50 ^ 38);
      Blocks.FIRE.setFireInfo(Blocks.WOODEN_SLAB, 46 ^ 43, 175 ^ 187);
      Blocks.FIRE.setFireInfo(Blocks.OAK_FENCE_GATE, 175 ^ 170, 176 ^ 164);
      Blocks.FIRE.setFireInfo(Blocks.SPRUCE_FENCE_GATE, 6 ^ 3, 84 ^ 64);
      Blocks.FIRE.setFireInfo(Blocks.BIRCH_FENCE_GATE, 129 ^ 132, 5 ^ 17);
      Blocks.FIRE.setFireInfo(Blocks.JUNGLE_FENCE_GATE, 188 ^ 185, 101 ^ 113);
      Blocks.FIRE.setFireInfo(Blocks.DARK_OAK_FENCE_GATE, 48 ^ 53, 185 ^ 173);
      Blocks.FIRE.setFireInfo(Blocks.ACACIA_FENCE_GATE, 77 ^ 72, 23 ^ 3);
      Blocks.FIRE.setFireInfo(Blocks.OAK_FENCE, 67 ^ 70, 2 ^ 22);
      Blocks.FIRE.setFireInfo(Blocks.SPRUCE_FENCE, 46 ^ 43, 122 ^ 110);
      Blocks.FIRE.setFireInfo(Blocks.BIRCH_FENCE, 37 ^ 32, 215 ^ 195);
      Blocks.FIRE.setFireInfo(Blocks.JUNGLE_FENCE, 100 ^ 97, 50 ^ 38);
      Blocks.FIRE.setFireInfo(Blocks.DARK_OAK_FENCE, 1 ^ 4, 179 ^ 167);
      Blocks.FIRE.setFireInfo(Blocks.ACACIA_FENCE, 123 ^ 126, 92 ^ 72);
      Blocks.FIRE.setFireInfo(Blocks.OAK_STAIRS, 132 ^ 129, 98 ^ 118);
      Blocks.FIRE.setFireInfo(Blocks.BIRCH_STAIRS, 14 ^ 11, 167 ^ 179);
      Blocks.FIRE.setFireInfo(Blocks.SPRUCE_STAIRS, 117 ^ 112, 187 ^ 175);
      Blocks.FIRE.setFireInfo(Blocks.JUNGLE_STAIRS, 25 ^ 28, 164 ^ 176);
      Blocks.FIRE.setFireInfo(Blocks.ACACIA_STAIRS, 97 ^ 100, 170 ^ 190);
      Blocks.FIRE.setFireInfo(Blocks.DARK_OAK_STAIRS, 186 ^ 191, 99 ^ 119);
      Blocks.FIRE.setFireInfo(Blocks.LOG, 83 ^ 86, 96 ^ 101);
      Blocks.FIRE.setFireInfo(Blocks.LOG2, 184 ^ 189, 66 ^ 71);
      Blocks.FIRE.setFireInfo(Blocks.LEAVES, 50 ^ 44, 74 ^ 118);
      Blocks.FIRE.setFireInfo(Blocks.LEAVES2, 70 ^ 88, 174 ^ 146);
      Blocks.FIRE.setFireInfo(Blocks.BOOKSHELF, 55 ^ 41, 60 ^ 40);
      Blocks.FIRE.setFireInfo(Blocks.TNT, 179 ^ 188, 47 ^ 75);
      Blocks.FIRE.setFireInfo(Blocks.TALLGRASS, 100 ^ 88, 47 ^ 75);
      Blocks.FIRE.setFireInfo(Blocks.DOUBLE_PLANT, 46 ^ 18, 225 ^ 133);
      Blocks.FIRE.setFireInfo(Blocks.YELLOW_FLOWER, 46 ^ 18, 213 ^ 177);
      Blocks.FIRE.setFireInfo(Blocks.RED_FLOWER, 139 ^ 183, 101 ^ 1);
      Blocks.FIRE.setFireInfo(Blocks.DEADBUSH, 11 ^ 55, 48 ^ 84);
      Blocks.FIRE.setFireInfo(Blocks.WOOL, 154 ^ 132, 95 ^ 99);
      Blocks.FIRE.setFireInfo(Blocks.VINE, 142 ^ 129, 226 ^ 134);
      Blocks.FIRE.setFireInfo(Blocks.COAL_BLOCK, 106 ^ 111, 39 ^ 34);
      Blocks.FIRE.setFireInfo(Blocks.HAY_BLOCK, 248 ^ 196, 61 ^ 41);
      Blocks.FIRE.setFireInfo(Blocks.CARPET, 106 ^ 86, 158 ^ 138);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean canCatchFire(IBlockAccess var1, BlockPos var2) {
      int var10000;
      if (this.getEncouragement(var1.getBlockState(var2).getBlock()) > 0) {
         var10000 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public int tickRate(World var1) {
      return 149 ^ 139;
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      IBlockState var10000;
      if (!var2.getBlockState(var3.down()).isFullyOpaque() && !Blocks.FIRE.canCatchFire(var2, var3.down())) {
         var10000 = var1.withProperty(NORTH, this.canCatchFire(var2, var3.north())).withProperty(EAST, this.canCatchFire(var2, var3.east())).withProperty(SOUTH, this.canCatchFire(var2, var3.south())).withProperty(WEST, this.canCatchFire(var2, var3.west())).withProperty(UPPER, this.canCatchFire(var2, var3.up()));
         "".length();
         if (-1 != -1) {
            throw null;
         }
      } else {
         var10000 = this.getDefaultState();
      }

      return var10000;
   }

   public boolean isCollidable() {
      return (boolean)"".length();
   }

   private static void I() {
      I = new String[222 ^ 188];
      I["".length()] = I("晐昜岹拚槕", "iEuBl");
      I[" ".length()] = I("亻妆", "UkHaa");
      I["  ".length()] = I("婤囨俜", "hOEtV");
      I["   ".length()] = I("岺侳", "zMVob");
      I[0 ^ 4] = I("嚀", "omgok");
      I[186 ^ 191] = I("今押抝垗傀", "aSCjt");
      I[22 ^ 16] = I("\u0005*\u0010!\u001f\u0004\u0011?+\u0006", "aEVHm");
      I[140 ^ 139] = I("於曾嘻倅", "Xacik");
      I[159 ^ 151] = I("斏楑庰恊", "idfDP");
      I[126 ^ 119] = I("槍傢", "wbcxo");
      I[10 ^ 0] = I("倸", "NnsXv");
      I[32 ^ 43] = I("幋", "NdZsh");
      I[176 ^ 188] = I("柏憃泇婝呪", "rhnFA");
      I[93 ^ 80] = I("囚氌吴瀎", "USZpO");
      I[21 ^ 27] = I("僄潎劶伎", "zGnxL");
      I[87 ^ 88] = I("光楆忭柚杞", "MRWQz");
      I[151 ^ 135] = I("涿殨權唞柤", "HvGwI");
      I[88 ^ 73] = I("劼塉拰嶒", "fqZss");
      I[110 ^ 124] = I("噒姑噉彦", "uDYyW");
      I[144 ^ 131] = I("侪橈", "ekyLj");
      I[79 ^ 91] = I("檚徐娆沿尟", "ECPhO");
      I[21 ^ 0] = I("墸", "IMDbm");
      I[190 ^ 168] = I("授嗳", "yXdxU");
      I[82 ^ 69] = I("毽暰旭淞倓", "QxHbj");
      I[175 ^ 183] = I("嶒澞滅滲", "PDXEY");
      I[34 ^ 59] = I("喜揬掁洽", "vXrYM");
      I[21 ^ 15] = I("汯嵐昻漅壈", "wlwfi");
      I[45 ^ 54] = I("垔剭潙", "QKdzY");
      I[97 ^ 125] = I("侓惠", "Nhgew");
      I[106 ^ 119] = I("傹埈浵", "ZVXby");
      I[67 ^ 93] = I("災煂喫桥桋", "BghmA");
      I[29 ^ 2] = I("嬅唒媜摀", "odFCo");
      I[36 ^ 4] = I("暩栳儶", "wsiEE");
      I[9 ^ 40] = I("晉", "hfkbD");
      I[52 ^ 22] = I("惵摪奄憅", "ONerF");
      I[41 ^ 10] = I("削夲樋", "ulVUn");
      I[97 ^ 69] = I("徛欋你抟濏", "NhXYy");
      I[136 ^ 173] = I("嬴濓抮墭庾", "RUILv");
      I[159 ^ 185] = I("厷堒婅", "fowtc");
      I[52 ^ 19] = I("兛廟漘", "PSdoF");
      I[114 ^ 90] = I("戅毓挣", "xIUIf");
      I[150 ^ 191] = I("俷嗅噥涑", "nuDlw");
      I[65 ^ 107] = I("働徶朼榵", "WSEzj");
      I[7 ^ 44] = I("僼滛", "zaIkn");
      I[46 ^ 2] = I("嗸廥", "QOyUM");
      I[43 ^ 6] = I("墋噜", "vevzC");
      I[122 ^ 84] = I("嵪愘", "HfUTS");
      I[70 ^ 105] = I("殭囌", "EYRAb");
      I[242 ^ 194] = I("嬨作", "reKXU");
      I[57 ^ 8] = I("傐渨", "JDheU");
      I[117 ^ 71] = I("埣戹", "GJmhv");
      I[188 ^ 143] = I("毉才", "ooqhC");
      I[154 ^ 174] = I("埍旦", "KtFFJ");
      I[2 ^ 55] = I("煔嶬", "POlIW");
      I[156 ^ 170] = I("候朚", "doqrh");
      I[131 ^ 180] = I("悺嫵", "SYucR");
      I[140 ^ 180] = I("昩殃", "oXlOB");
      I[23 ^ 46] = I("漣姇", "VJcYx");
      I[84 ^ 110] = I("业媔", "sKpiX");
      I[103 ^ 92] = I("抖澻", "BfSUQ");
      I[21 ^ 41] = I("俖椟", "QyibY");
      I[93 ^ 96] = I("嬔字", "vuYFD");
      I[6 ^ 56] = I("惹搢", "bUuSy");
      I[109 ^ 82] = I("潷婙", "DKxev");
      I[5 ^ 69] = I("每斃", "tmUzN");
      I[29 ^ 92] = I("拮文", "oTNxH");
      I[196 ^ 134] = I("東桯", "LAfsD");
      I[18 ^ 81] = I("扶毆", "ItJNE");
      I[206 ^ 138] = I("寐俵", "jnSCb");
      I[116 ^ 49] = I("崻晰", "xsjNm");
      I[211 ^ 149] = I("煷弳", "cmeIA");
      I[65 ^ 6] = I("捳擢", "TRImm");
      I[26 ^ 82] = I("嬳扇灖怫", "xSzFX");
      I[43 ^ 98] = I("浂嫳", "UczDP");
      I[85 ^ 31] = I("烖", "DGVDi");
      I[246 ^ 189] = I("巻殺棻敄", "rTxgz");
      I[202 ^ 134] = I("崹湄歵", "SvIGj");
      I[234 ^ 167] = I("凍氚墅", "rhkfJ");
      I[236 ^ 162] = I("堆庌洛使", "kPSnF");
      I[75 ^ 4] = I("姙娢曃沖扷", "cyEND");
      I[227 ^ 179] = I("唐", "sknCo");
      I[209 ^ 128] = I("擸", "GPXOA");
      I[33 ^ 115] = I("岥煇", "EBchb");
      I[60 ^ 111] = I("炡偠堅忾", "MYHZF");
      I[106 ^ 62] = I("沖堬櫋慀濔", "wMxul");
      I[147 ^ 198] = I("厍沿嶵", "KgoAx");
      I[220 ^ 138] = I("擲偿圕桰栜", "lhKMm");
      I[30 ^ 73] = I("惪捒劵", "Bshkx");
      I[64 ^ 24] = I("怹厀墩楡", "AEPLU");
      I[70 ^ 31] = I("挼婓岜", "MbrpE");
      I[77 ^ 23] = I("楢個啂炧", "DWvIw");
      I[104 ^ 51] = I("卦斱泣殐", "JAOIl");
      I[97 ^ 61] = I("\u0014\u000b\u001c", "ulypH");
      I[112 ^ 45] = I("\u0005\t%5\u001b", "kfWAs");
      I[68 ^ 26] = I("\u0007&< ", "bGOTu");
      I[90 ^ 5] = I("\u0014\u000e\u0017\u0004\u0004", "gabpl");
      I[7 ^ 103] = I("\u0005\u0014&\u0017", "rqUcB");
      I[252 ^ 157] = I("\u001d\u0002", "hrJhV");
   }

   private boolean canNeighborCatchFire(World var1, BlockPos var2) {
      EnumFacing[] var3 = EnumFacing.values();
      int var4 = var3.length;
      int var5 = "".length();

      do {
         if (var5 >= var4) {
            return (boolean)"".length();
         }

         EnumFacing var6 = var3[var5];
         if (this.canCatchFire(var1, var2.offset(var6))) {
            return (boolean)" ".length();
         }

         ++var5;
         "".length();
      } while(1 > 0);

      throw null;
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      if (var4.nextInt(174 ^ 182) == 0) {
         var2.playSound((double)((float)var3.getX() + 0.5F), (double)((float)var3.getY() + 0.5F), (double)((float)var3.getZ() + 0.5F), SoundEvents.BLOCK_FIRE_AMBIENT, SoundCategory.BLOCKS, 1.0F + var4.nextFloat(), var4.nextFloat() * 0.7F + 0.3F, (boolean)"".length());
      }

      int var5;
      double var6;
      double var8;
      double var10;
      if (!var2.getBlockState(var3.down()).isFullyOpaque() && !Blocks.FIRE.canCatchFire(var2, var3.down())) {
         if (Blocks.FIRE.canCatchFire(var2, var3.west())) {
            var5 = "".length();

            while(var5 < "  ".length()) {
               var6 = (double)var3.getX() + var4.nextDouble() * 0.10000000149011612D;
               var8 = (double)var3.getY() + var4.nextDouble();
               var10 = (double)var3.getZ() + var4.nextDouble();
               var2.spawnParticle(EnumParticleTypes.SMOKE_LARGE, var6, var8, var10, 0.0D, 0.0D, 0.0D);
               ++var5;
               "".length();
               if (-1 != -1) {
                  throw null;
               }
            }
         }

         double var10000;
         double var10001;
         if (Blocks.FIRE.canCatchFire(var2, var3.east())) {
            var5 = "".length();

            while(var5 < "  ".length()) {
               var10000 = (double)(var3.getX() + " ".length());
               var10001 = var4.nextDouble() * 0.10000000149011612D;
               I[169 ^ 140].length();
               var6 = var10000 - var10001;
               var8 = (double)var3.getY() + var4.nextDouble();
               var10 = (double)var3.getZ() + var4.nextDouble();
               var2.spawnParticle(EnumParticleTypes.SMOKE_LARGE, var6, var8, var10, 0.0D, 0.0D, 0.0D);
               ++var5;
               "".length();
               if (1 <= -1) {
                  throw null;
               }
            }
         }

         if (Blocks.FIRE.canCatchFire(var2, var3.north())) {
            var5 = "".length();

            while(var5 < "  ".length()) {
               var6 = (double)var3.getX() + var4.nextDouble();
               var8 = (double)var3.getY() + var4.nextDouble();
               var10 = (double)var3.getZ() + var4.nextDouble() * 0.10000000149011612D;
               var2.spawnParticle(EnumParticleTypes.SMOKE_LARGE, var6, var8, var10, 0.0D, 0.0D, 0.0D);
               ++var5;
               "".length();
               if (1 <= -1) {
                  throw null;
               }
            }
         }

         if (Blocks.FIRE.canCatchFire(var2, var3.south())) {
            var5 = "".length();

            while(var5 < "  ".length()) {
               var6 = (double)var3.getX() + var4.nextDouble();
               var8 = (double)var3.getY() + var4.nextDouble();
               var10000 = (double)(var3.getZ() + " ".length());
               var10001 = var4.nextDouble() * 0.10000000149011612D;
               I[179 ^ 149].length();
               I[102 ^ 65].length();
               I[108 ^ 68].length();
               var10 = var10000 - var10001;
               var2.spawnParticle(EnumParticleTypes.SMOKE_LARGE, var6, var8, var10, 0.0D, 0.0D, 0.0D);
               ++var5;
               "".length();
               if (3 == -1) {
                  throw null;
               }
            }
         }

         if (Blocks.FIRE.canCatchFire(var2, var3.up())) {
            var5 = "".length();

            while(var5 < "  ".length()) {
               var6 = (double)var3.getX() + var4.nextDouble();
               var10000 = (double)(var3.getY() + " ".length());
               var10001 = var4.nextDouble() * 0.10000000149011612D;
               I[163 ^ 138].length();
               I[115 ^ 89].length();
               var8 = var10000 - var10001;
               var10 = (double)var3.getZ() + var4.nextDouble();
               var2.spawnParticle(EnumParticleTypes.SMOKE_LARGE, var6, var8, var10, 0.0D, 0.0D, 0.0D);
               ++var5;
               "".length();
               if (4 <= 0) {
                  throw null;
               }
            }

            "".length();
            if (-1 >= 0) {
               throw null;
            }
         }
      } else {
         var5 = "".length();

         while(var5 < "   ".length()) {
            var6 = (double)var3.getX() + var4.nextDouble();
            var8 = (double)var3.getY() + var4.nextDouble() * 0.5D + 0.5D;
            var10 = (double)var3.getZ() + var4.nextDouble();
            var2.spawnParticle(EnumParticleTypes.SMOKE_LARGE, var6, var8, var10, 0.0D, 0.0D, 0.0D);
            ++var5;
            "".length();
            if (1 == 2) {
               throw null;
            }
         }
      }

   }

   protected boolean canDie(World var1, BlockPos var2) {
      int var10000;
      if (!var1.isRainingAt(var2) && !var1.isRainingAt(var2.west()) && !var1.isRainingAt(var2.east()) && !var1.isRainingAt(var2.north()) && !var1.isRainingAt(var2.south())) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (-1 != -1) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   private int getEncouragement(Block var1) {
      Integer var2 = (Integer)this.encouragements.get(var1);
      int var10000;
      if (var2 == null) {
         var10000 = "".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10000 = var2;
      }

      return var10000;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.getBlockState(var3.down()).isFullyOpaque() && !this.canNeighborCatchFire(var2, var3)) {
         var2.setBlockToAir(var3);
         I[104 ^ 119].length();
         I[167 ^ 135].length();
         I[29 ^ 60].length();
         I[136 ^ 170].length();
         I[38 ^ 5].length();
      }

   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[35 ^ 8];
      String var10001 = I[98 ^ 78];
      String var10002 = I[47 ^ 2];
      var10001 = I[170 ^ 132];
      var10000 = I[159 ^ 176];
      var10001 = I[173 ^ 157];
      var10002 = I[126 ^ 79];
      var10001 = I[42 ^ 24];
      var10000 = I[80 ^ 99];
      var10001 = I[5 ^ 49];
      var10002 = I[148 ^ 161];
      var10001 = I[83 ^ 101];
      var10000 = I[245 ^ 194];
      var10001 = I[3 ^ 59];
      var10002 = I[143 ^ 182];
      var10001 = I[136 ^ 178];
      var10000 = I[121 ^ 66];
      var10001 = I[4 ^ 56];
      var10002 = I[138 ^ 183];
      var10001 = I[122 ^ 68];
      var10000 = I[21 ^ 42];
      var10001 = I[132 ^ 196];
      var10002 = I[202 ^ 139];
      var10001 = I[55 ^ 117];
      var10000 = I[90 ^ 25];
      var10001 = I[100 ^ 32];
      var10002 = I[207 ^ 138];
      var10001 = I[2 ^ 68];
      I[11 ^ 76].length();
      I[91 ^ 19].length();
      I[78 ^ 7].length();
      IProperty[] var10003 = new IProperty[178 ^ 180];
      I[111 ^ 37].length();
      I[59 ^ 112].length();
      I[29 ^ 81].length();
      var10003["".length()] = AGE;
      I[89 ^ 20].length();
      var10003[" ".length()] = NORTH;
      I[209 ^ 159].length();
      I[230 ^ 169].length();
      I[91 ^ 11].length();
      var10003["  ".length()] = EAST;
      I[58 ^ 107].length();
      I[148 ^ 198].length();
      I[19 ^ 64].length();
      var10003["   ".length()] = SOUTH;
      I[218 ^ 142].length();
      I[107 ^ 62].length();
      I[242 ^ 164].length();
      I[9 ^ 94].length();
      I[240 ^ 168].length();
      var10003[28 ^ 24] = WEST;
      I[196 ^ 157].length();
      I[72 ^ 18].length();
      I[245 ^ 174].length();
      var10003[32 ^ 37] = UPPER;
      return new BlockStateContainer(this, var10003);
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(AGE, var1);
   }

   private int getNeighborEncouragement(World var1, BlockPos var2) {
      if (!var1.isAirBlock(var2)) {
         return "".length();
      } else {
         int var3 = "".length();
         EnumFacing[] var4 = EnumFacing.values();
         int var5 = var4.length;
         int var6 = "".length();

         do {
            if (var6 >= var5) {
               return var3;
            }

            EnumFacing var7 = var4[var6];
            var3 = Math.max(this.getEncouragement(var1.getBlockState(var2.offset(var7)).getBlock()), var3);
            ++var6;
            "".length();
         } while(3 == 3);

         throw null;
      }
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(AGE);
   }

   public void setFireInfo(Block var1, int var2, int var3) {
      this.encouragements.put(var1, var2);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      this.flammabilities.put(var1, var3);
      I["   ".length()].length();
      I[197 ^ 193].length();
      I[94 ^ 91].length();
   }

   protected BlockFire() {
      super(Material.FIRE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(AGE, "".length()).withProperty(NORTH, Boolean.valueOf((boolean)"".length())).withProperty(EAST, Boolean.valueOf((boolean)"".length())).withProperty(SOUTH, Boolean.valueOf((boolean)"".length())).withProperty(WEST, Boolean.valueOf((boolean)"".length())).withProperty(UPPER, Boolean.valueOf((boolean)"".length())));
      this.setTickRandomly((boolean)" ".length());
   }

   static {
      I();
      AGE = PropertyInteger.create(I[16 ^ 76], "".length(), 56 ^ 55);
      NORTH = PropertyBool.create(I[96 ^ 61]);
      EAST = PropertyBool.create(I[36 ^ 122]);
      SOUTH = PropertyBool.create(I[89 ^ 6]);
      WEST = PropertyBool.create(I[210 ^ 178]);
      UPPER = PropertyBool.create(I[71 ^ 38]);
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (!var1.getBlockState(var2.down()).isFullyOpaque() && !this.canNeighborCatchFire(var1, var2)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (-1 >= 2) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   private int getFlammability(Block var1) {
      Integer var2 = (Integer)this.flammabilities.get(var1);
      int var10000;
      if (var2 == null) {
         var10000 = "".length();
         "".length();
         if (-1 == 1) {
            throw null;
         }
      } else {
         var10000 = var2;
      }

      return var10000;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (var1.getGameRules().getBoolean(I[70 ^ 64])) {
         if (!this.canPlaceBlockAt(var1, var2)) {
            var1.setBlockToAir(var2);
            I[29 ^ 26].length();
            I[117 ^ 125].length();
         }

         Block var5 = var1.getBlockState(var2.down()).getBlock();
         int var10000;
         if (var5 != Blocks.NETHERRACK && var5 != Blocks.MAGMA) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (4 <= 1) {
               throw null;
            }
         }

         int var6 = var10000;
         if (var1.provider instanceof WorldProviderEnd && var5 == Blocks.BEDROCK) {
            var6 = " ".length();
         }

         int var7 = (Integer)var3.getValue(AGE);
         if (var6 == 0 && var1.isRaining() && this.canDie(var1, var2) && var4.nextFloat() < 0.2F + (float)var7 * 0.03F) {
            var1.setBlockToAir(var2);
            I[106 ^ 99].length();
            I[91 ^ 81].length();
            I[83 ^ 88].length();
            "".length();
            if (1 <= -1) {
               throw null;
            }
         } else {
            if (var7 < (103 ^ 104)) {
               var3 = var3.withProperty(AGE, var7 + var4.nextInt("   ".length()) / "  ".length());
               var1.setBlockState(var2, var3, 77 ^ 73);
               I[43 ^ 39].length();
               I[93 ^ 80].length();
               I[107 ^ 101].length();
            }

            var1.scheduleUpdate(var2, this, this.tickRate(var1) + var4.nextInt(90 ^ 80));
            if (var6 == 0) {
               if (!this.canNeighborCatchFire(var1, var2)) {
                  if (!var1.getBlockState(var2.down()).isFullyOpaque() || var7 > "   ".length()) {
                     var1.setBlockToAir(var2);
                     I[78 ^ 65].length();
                     I[20 ^ 4].length();
                  }

                  return;
               }

               if (!this.canCatchFire(var1, var2.down()) && var7 == (151 ^ 152) && var4.nextInt(25 ^ 29) == 0) {
                  var1.setBlockToAir(var2);
                  I[47 ^ 62].length();
                  I[215 ^ 197].length();
                  return;
               }
            }

            boolean var8 = var1.isBlockinHighHumidity(var2);
            int var9 = "".length();
            if (var8) {
               var9 = -(122 ^ 72);
            }

            this.catchOnFire(var1, var2.east(), 135 + 122 - 231 + 274 + var9, var4, var7);
            this.catchOnFire(var1, var2.west(), 26 + 299 - 178 + 153 + var9, var4, var7);
            this.catchOnFire(var1, var2.down(), 232 + 91 - 261 + 188 + var9, var4, var7);
            this.catchOnFire(var1, var2.up(), 169 + 114 - 200 + 167 + var9, var4, var7);
            this.catchOnFire(var1, var2.north(), 249 + 107 - 317 + 261 + var9, var4, var7);
            this.catchOnFire(var1, var2.south(), 216 + 170 - 147 + 61 + var9, var4, var7);
            int var10 = -" ".length();

            while(var10 <= " ".length()) {
               int var11 = -" ".length();

               while(var11 <= " ".length()) {
                  int var12 = -" ".length();

                  while(var12 <= (57 ^ 61)) {
                     if (var10 != 0 || var12 != 0 || var11 != 0) {
                        int var13 = 200 ^ 172;
                        if (var12 > " ".length()) {
                           int var10002 = " ".length();
                           I[173 ^ 190].length();
                           I[59 ^ 47].length();
                           I[55 ^ 34].length();
                           var13 += (var12 - var10002) * (192 ^ 164);
                        }

                        BlockPos var14 = var2.add(var10, var12, var11);
                        int var15 = this.getNeighborEncouragement(var1, var14);
                        if (var15 > 0) {
                           int var16 = (var15 + (134 ^ 174) + var1.getDifficulty().getDifficultyId() * (95 ^ 88)) / (var7 + (59 ^ 37));
                           if (var8) {
                              var16 /= "  ".length();
                           }

                           if (var16 > 0 && var4.nextInt(var13) <= var16 && (!var1.isRaining() || !this.canDie(var1, var14))) {
                              int var17 = var7 + var4.nextInt(10 ^ 15) / (152 ^ 156);
                              if (var17 > (179 ^ 188)) {
                                 var17 = 72 ^ 71;
                              }

                              var1.setBlockState(var14, var3.withProperty(AGE, var17), "   ".length());
                              I[81 ^ 71].length();
                              I[100 ^ 115].length();
                              I[216 ^ 192].length();
                           }
                        }
                     }

                     ++var12;
                     "".length();
                     if (2 < 1) {
                        throw null;
                     }
                  }

                  ++var11;
                  "".length();
                  if (2 < 2) {
                     throw null;
                  }
               }

               ++var10;
               "".length();
               if (3 < 1) {
                  throw null;
               }
            }
         }
      }

   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }
}

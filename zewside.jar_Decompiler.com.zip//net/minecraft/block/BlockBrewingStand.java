package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBrewingStand;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockBrewingStand extends BlockContainer {
   // $FF: synthetic field
   protected static final AxisAlignedBB STICK_AABB;
   // $FF: synthetic field
   public static final PropertyBool[] HAS_BOTTLE;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB BASE_AABB;

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.BREWING_STAND;
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      if (var5.hasDisplayName()) {
         TileEntity var6 = var1.getTileEntity(var2);
         if (var6 instanceof TileEntityBrewingStand) {
            ((TileEntityBrewingStand)var6).setName(var5.getDisplayName());
         }
      }

   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      int var3 = "".length();

      do {
         if (var3 >= "   ".length()) {
            return var2;
         }

         if ((Boolean)var1.getValue(HAS_BOTTLE[var3])) {
            var2 |= " ".length() << var3;
         }

         ++var3;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      double var5 = (double)((float)var3.getX() + 0.4F + var4.nextFloat() * 0.2F);
      double var7 = (double)((float)var3.getY() + 0.7F + var4.nextFloat() * 0.3F);
      double var9 = (double)((float)var3.getZ() + 0.4F + var4.nextFloat() * 0.2F);
      var2.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, var5, var7, var9, 0.0D, 0.0D, 0.0D);
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      TileEntity var4 = var1.getTileEntity(var2);
      if (var4 instanceof TileEntityBrewingStand) {
         InventoryHelper.dropInventoryItems(var1, (BlockPos)var2, (TileEntityBrewingStand)var4);
      }

      super.breakBlock(var1, var2, var3);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         TileEntity var10 = var1.getTileEntity(var2);
         if (var10 instanceof TileEntityBrewingStand) {
            var4.displayGUIChest((TileEntityBrewingStand)var10);
            var4.addStat(StatList.BREWINGSTAND_INTERACTION);
         }

         return (boolean)" ".length();
      }
   }

   static {
      I();
      PropertyBool[] var10000 = new PropertyBool["   ".length()];
      var10000["".length()] = PropertyBool.create(I[31 ^ 56]);
      var10000[" ".length()] = PropertyBool.create(I[41 ^ 1]);
      var10000["  ".length()] = PropertyBool.create(I[238 ^ 199]);
      HAS_BOTTLE = var10000;
      BASE_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.125D, 1.0D);
      STICK_AABB = new AxisAlignedBB(0.4375D, 0.0D, 0.4375D, 0.5625D, 0.875D, 0.5625D);
   }

   private static void I() {
      I = new String[33 ^ 11];
      I["".length()] = I("\b\u0004\u0007\tg\u0003\u0002\u0007\u0013 \u000f\u00171\u0010(\u000f\u0014L\n(\f\u0015", "apbdI");
      I[" ".length()] = I("潪孖", "xBcpS");
      I["  ".length()] = I("奬櫧", "pWmXt");
      I["   ".length()] = I("昛椳", "ItxWb");
      I[137 ^ 141] = I("浌櫖", "cilio");
      I[107 ^ 110] = I("澔伐侘", "PPvid");
      I[190 ^ 184] = I("摰佖姙娒", "bDYvI");
      I[143 ^ 136] = I("杻尸", "YKKec");
      I[3 ^ 11] = I("厛瀢", "PLPQI");
      I[140 ^ 133] = I("亹播", "yLltQ");
      I[72 ^ 66] = I("峅奺", "DsQGI");
      I[9 ^ 2] = I("惣憥殓曚式", "ILNnD");
      I[124 ^ 112] = I("堳淬汕唬巗", "AGPGH");
      I[59 ^ 54] = I("昚掓撝廢岠", "IzTZi");
      I[47 ^ 33] = I("呂午", "QCknw");
      I[50 ^ 61] = I("凅厑", "oMUsC");
      I[42 ^ 58] = I("嬇嗦", "QbaGK");
      I[114 ^ 99] = I("敟帰", "nKhWF");
      I[181 ^ 167] = I("排润", "aShyi");
      I[153 ^ 138] = I("吼椹", "AXHeZ");
      I[101 ^ 113] = I("木憜", "mdJnC");
      I[171 ^ 190] = I("炊漺", "HlETK");
      I[147 ^ 133] = I("呰峊", "ACusJ");
      I[18 ^ 5] = I("抑梒", "agxZh");
      I[98 ^ 122] = I("帴洑", "kSTJU");
      I[217 ^ 192] = I("榓拶", "hDZMq");
      I[164 ^ 190] = I("卉抁", "LMXHq");
      I[79 ^ 84] = I("侖扽", "ZfOTB");
      I[5 ^ 25] = I("嬕嵀", "fxarH");
      I[41 ^ 52] = I("巬杸", "BCgxp");
      I[132 ^ 154] = I("晋洘摳", "bnbNf");
      I[135 ^ 152] = I("涄", "mKNgP");
      I[163 ^ 131] = I("冕冾橰", "ifQPz");
      I[67 ^ 98] = I("弦敥昪", "duUVe");
      I[150 ^ 180] = I("搇凫愅侍", "JMzhf");
      I[19 ^ 48] = I("嗿", "JPjwA");
      I[9 ^ 45] = I("侮", "mStXi");
      I[85 ^ 112] = I("懻愹乂亝", "iEmaw");
      I[158 ^ 184] = I("尩旾汴愭", "aIJrY");
      I[151 ^ 176] = I("\u0000\u0013 5:\u0007\u0006'\u0006=7B", "hrSjX");
      I[173 ^ 133] = I("\u001c\u0005?\u000b7\u001b\u0010880+U", "tdLTU");
      I[90 ^ 115] = I("%\u0003\u0003.5\"\u0016\u0004\u001d2\u0012P", "MbpqW");
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[130 ^ 133];
      String var10001 = I[70 ^ 78];
      String var10002 = I[28 ^ 21];
      var10001 = I[8 ^ 2];
      I[14 ^ 5].length();
      I[62 ^ 50].length();
      I[84 ^ 89].length();
      return new ItemStack(Items.BREWING_STAND);
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[91 ^ 95];
      I[19 ^ 22].length();
      I[164 ^ 162].length();
      return new TileEntityBrewingStand();
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public String getLocalizedName() {
      return I18n.translateToLocal(I["".length()]);
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      addCollisionBoxToList(var3, var4, var5, STICK_AABB);
      addCollisionBoxToList(var3, var4, var5, BASE_AABB);
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var2 = this.getDefaultState();
      int var3 = "".length();

      do {
         if (var3 >= "   ".length()) {
            return var2;
         }

         PropertyBool var10001 = HAS_BOTTLE[var3];
         int var10002;
         if ((var1 & " ".length() << var3) > 0) {
            var10002 = " ".length();
            "".length();
            if (3 != 3) {
               throw null;
            }
         } else {
            var10002 = "".length();
         }

         var2 = var2.withProperty(var10001, Boolean.valueOf((boolean)var10002));
         ++var3;
         "".length();
      } while(1 > -1);

      throw null;
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return BASE_AABB;
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      return Container.calcRedstone(var2.getTileEntity(var3));
   }

   public BlockBrewingStand() {
      super(Material.IRON);
      this.setDefaultState(this.blockState.getBaseState().withProperty(HAS_BOTTLE["".length()], Boolean.valueOf((boolean)"".length())).withProperty(HAS_BOTTLE[" ".length()], Boolean.valueOf((boolean)"".length())).withProperty(HAS_BOTTLE["  ".length()], Boolean.valueOf((boolean)"".length())));
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[116 ^ 122];
      String var10001 = I[163 ^ 172];
      String var10002 = I[158 ^ 142];
      var10001 = I[86 ^ 71];
      var10000 = I[26 ^ 8];
      var10001 = I[24 ^ 11];
      var10002 = I[11 ^ 31];
      var10001 = I[120 ^ 109];
      var10000 = I[165 ^ 179];
      var10001 = I[86 ^ 65];
      var10002 = I[65 ^ 89];
      var10001 = I[83 ^ 74];
      var10000 = I[178 ^ 168];
      var10001 = I[96 ^ 123];
      var10002 = I[135 ^ 155];
      var10001 = I[109 ^ 112];
      I[52 ^ 42].length();
      I[71 ^ 88].length();
      I[6 ^ 38].length();
      IProperty[] var10003 = new IProperty["   ".length()];
      I[191 ^ 158].length();
      I[66 ^ 96].length();
      I[35 ^ 0].length();
      var10003["".length()] = HAS_BOTTLE["".length()];
      I[159 ^ 187].length();
      I[11 ^ 46].length();
      var10003[" ".length()] = HAS_BOTTLE[" ".length()];
      I[151 ^ 177].length();
      var10003["  ".length()] = HAS_BOTTLE["  ".length()];
      return new BlockStateContainer(this, var10003);
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }
}

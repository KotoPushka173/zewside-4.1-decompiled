package net.minecraft.network.login.server;

import com.mojang.authlib.GameProfile;
import java.io.IOException;
import java.util.UUID;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.login.INetHandlerLoginClient;

public class SPacketLoginSuccess implements Packet<INetHandlerLoginClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private GameProfile profile;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   static {
      I();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      String var2 = var1.readStringFromBuffer(162 ^ 134);
      String var3 = var1.readStringFromBuffer(113 ^ 97);
      UUID var4 = UUID.fromString(var2);
      I[55 ^ 51].length();
      I[126 ^ 123].length();
      I[33 ^ 39].length();
      I[84 ^ 83].length();
      this.profile = new GameProfile(var4, var3);
   }

   public GameProfile getProfile() {
      return this.profile;
   }

   private static void I() {
      I = new String[159 ^ 142];
      I["".length()] = I("櫱承", "cJXvi");
      I[" ".length()] = I("奮墁", "fVCjj");
      I["  ".length()] = I("溇杴", "TvnXE");
      I["   ".length()] = I("愝搎", "GRBiG");
      I[6 ^ 2] = I("旈忬", "mYOTj");
      I[100 ^ 97] = I("儭孂噾", "OIext");
      I[8 ^ 14] = I("涀", "vcmRR");
      I[14 ^ 9] = I("樅", "RpHuH");
      I[11 ^ 3] = I("", "ntuPC");
      I[46 ^ 39] = I("啃暰峓弪劺", "qAnDR");
      I[174 ^ 164] = I("厈漷瀌澳", "UXxWN");
      I[34 ^ 41] = I("壥仭压", "TBXCV");
      I[176 ^ 188] = I("恓", "tfgVE");
      I[0 ^ 13] = I("梃橍啄減", "hewoh");
      I[41 ^ 39] = I("形澖哯乵", "ovnLw");
      I[34 ^ 45] = I("冯", "JwjGo");
      I[124 ^ 108] = I("档漾", "kWkOt");
   }

   public void processPacket(INetHandlerLoginClient var1) {
      var1.handleLoginSuccess(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      UUID var2 = this.profile.getId();
      String var10001;
      if (var2 == null) {
         var10001 = I[169 ^ 161];
         "".length();
         if (4 == 1) {
            throw null;
         }
      } else {
         var10001 = var2.toString();
      }

      var1.writeString(var10001);
      I[184 ^ 177].length();
      I[132 ^ 142].length();
      I[103 ^ 108].length();
      I[100 ^ 104].length();
      I[207 ^ 194].length();
      var1.writeString(this.profile.getName());
      I[104 ^ 102].length();
      I[55 ^ 56].length();
      I[168 ^ 184].length();
   }

   public SPacketLoginSuccess() {
   }

   public SPacketLoginSuccess(GameProfile var1) {
      this.profile = var1;
   }
}

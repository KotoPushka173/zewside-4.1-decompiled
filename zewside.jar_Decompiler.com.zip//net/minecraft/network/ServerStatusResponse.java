package net.minecraft.network;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.mojang.authlib.GameProfile;
import java.lang.reflect.Type;
import java.util.UUID;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.text.ITextComponent;

public class ServerStatusResponse {
   // $FF: synthetic field
   private ServerStatusResponse.Version version;
   // $FF: synthetic field
   private ITextComponent description;
   // $FF: synthetic field
   private String favicon;
   // $FF: synthetic field
   private ServerStatusResponse.Players players;

   public ServerStatusResponse.Version getVersion() {
      return this.version;
   }

   public void setPlayers(ServerStatusResponse.Players var1) {
      this.players = var1;
   }

   public void setVersion(ServerStatusResponse.Version var1) {
      this.version = var1;
   }

   public String getFavicon() {
      return this.favicon;
   }

   public ITextComponent getServerDescription() {
      return this.description;
   }

   public ServerStatusResponse.Players getPlayers() {
      return this.players;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 > 0);

      throw null;
   }

   public void setFavicon(String var1) {
      this.favicon = var1;
   }

   public void setServerDescription(ITextComponent var1) {
      this.description = var1;
   }

   public static class Serializer implements JsonDeserializer<ServerStatusResponse>, JsonSerializer<ServerStatusResponse> {
      // $FF: synthetic field
      private static final String[] I;

      public ServerStatusResponse deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         String var10000 = I["".length()];
         String var10001 = I[" ".length()];
         String var10002 = I["  ".length()];
         var10001 = I["   ".length()];
         JsonObject var4 = JsonUtils.getJsonObject(var1, I[56 ^ 60]);
         I[74 ^ 79].length();
         I[147 ^ 149].length();
         ServerStatusResponse var5 = new ServerStatusResponse();
         if (var4.has(I[50 ^ 53])) {
            var5.setServerDescription((ITextComponent)var3.deserialize(var4.get(I[58 ^ 50]), ITextComponent.class));
         }

         if (var4.has(I[159 ^ 150])) {
            var5.setPlayers((ServerStatusResponse.Players)var3.deserialize(var4.get(I[108 ^ 102]), ServerStatusResponse.Players.class));
         }

         if (var4.has(I[164 ^ 175])) {
            var5.setVersion((ServerStatusResponse.Version)var3.deserialize(var4.get(I[149 ^ 153]), ServerStatusResponse.Version.class));
         }

         if (var4.has(I[42 ^ 39])) {
            var5.setFavicon(JsonUtils.getString(var4, I[116 ^ 122]));
         }

         return var5;
      }

      static {
         I();
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > -1);

         throw null;
      }

      private static void I() {
         I = new String[33 ^ 57];
         I["".length()] = I("抡姮", "weHle");
         I[" ".length()] = I("敮倔", "ERYDe");
         I["  ".length()] = I("孞坈", "faOnZ");
         I["   ".length()] = I("派旾", "TJzOu");
         I[5 ^ 1] = I("\u00028.1=\u0002", "qLOEH");
         I[179 ^ 182] = I("月坲嫓圤咧", "kcrOf");
         I[191 ^ 185] = I("刪扻埑嫞", "hcvSa");
         I[198 ^ 193] = I("  \u0004\u0004\u001e-5\u0003\u000e\u0003*", "DEwgl");
         I[36 ^ 44] = I("5\u001f7\u0004:8\n0\u000e'?", "QzDgH");
         I[75 ^ 66] = I("\u0012)%2\u0012\u00106", "bEDKw");
         I[43 ^ 33] = I("!)\u0004/-#6", "QEeVH");
         I[114 ^ 121] = I("\u0000\u0016>\u0002*\u0019\u001d", "vsLqC");
         I[124 ^ 112] = I("0\u0016\u0002\u00111)\u001d", "FspbX");
         I[5 ^ 8] = I("0\u0006\"\u000269\t", "VgTkU");
         I[49 ^ 63] = I("\u000e),\n\u0019\u0007&", "hHZcz");
         I[136 ^ 135] = I("吣一", "JEjbS");
         I[122 ^ 106] = I("们掿", "RiMnv");
         I[191 ^ 174] = I("偯嫍", "PFSzv");
         I[11 ^ 25] = I("妵戬", "aVEIX");
         I[45 ^ 62] = I("桎揼庎", "HyGTM");
         I[0 ^ 20] = I("\t=\u000b:6\u0004(\f0+\u0003", "mXxYD");
         I[46 ^ 59] = I(":\u0018\u00060)8\u0007", "JtgIL");
         I[97 ^ 119] = I("<\n \u0010.%\u0001", "JoRcG");
         I[8 ^ 31] = I("\r\u0016\"\u0013\u0002\u0004\u0019", "kwTza");
      }

      public JsonElement serialize(ServerStatusResponse var1, Type var2, JsonSerializationContext var3) {
         String var10000 = I[33 ^ 46];
         String var10001 = I[173 ^ 189];
         String var10002 = I[138 ^ 155];
         var10001 = I[166 ^ 180];
         I[36 ^ 55].length();
         JsonObject var4 = new JsonObject();
         if (var1.getServerDescription() != null) {
            var4.add(I[171 ^ 191], var3.serialize(var1.getServerDescription()));
         }

         if (var1.getPlayers() != null) {
            var4.add(I[164 ^ 177], var3.serialize(var1.getPlayers()));
         }

         if (var1.getVersion() != null) {
            var4.add(I[153 ^ 143], var3.serialize(var1.getVersion()));
         }

         if (var1.getFavicon() != null) {
            var4.addProperty(I[190 ^ 169], var1.getFavicon());
         }

         return var4;
      }
   }

   public static class Players {
      // $FF: synthetic field
      private final int maxPlayers;
      // $FF: synthetic field
      private GameProfile[] players;
      // $FF: synthetic field
      private final int onlinePlayerCount;

      public int getOnlinePlayerCount() {
         return this.onlinePlayerCount;
      }

      public int getMaxPlayers() {
         return this.maxPlayers;
      }

      public void setPlayers(GameProfile[] var1) {
         this.players = var1;
      }

      public GameProfile[] getPlayers() {
         return this.players;
      }

      public Players(int var1, int var2) {
         this.maxPlayers = var1;
         this.onlinePlayerCount = var2;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 == 3);

         throw null;
      }

      public static class Serializer implements JsonDeserializer<ServerStatusResponse.Players>, JsonSerializer<ServerStatusResponse.Players> {
         // $FF: synthetic field
         private static final String[] I;

         public JsonElement serialize(ServerStatusResponse.Players var1, Type var2, JsonSerializationContext var3) {
            String var10000 = I[105 ^ 117];
            String var10001 = I[5 ^ 24];
            String var10002 = I[117 ^ 107];
            var10001 = I[32 ^ 63];
            var10000 = I[117 ^ 85];
            var10001 = I[190 ^ 159];
            var10002 = I[33 ^ 3];
            var10001 = I[159 ^ 188];
            var10000 = I[159 ^ 187];
            var10001 = I[95 ^ 122];
            var10002 = I[77 ^ 107];
            var10001 = I[171 ^ 140];
            I[70 ^ 110].length();
            JsonObject var4 = new JsonObject();
            var4.addProperty(I[113 ^ 88], var1.getMaxPlayers());
            var4.addProperty(I[130 ^ 168], var1.getOnlinePlayerCount());
            if (var1.getPlayers() != null && var1.getPlayers().length > 0) {
               I[28 ^ 55].length();
               I[237 ^ 193].length();
               I[172 ^ 129].length();
               JsonArray var5 = new JsonArray();
               int var6 = "".length();

               while(var6 < var1.getPlayers().length) {
                  I[96 ^ 78].length();
                  I[174 ^ 129].length();
                  JsonObject var7 = new JsonObject();
                  UUID var8 = var1.getPlayers()[var6].getId();
                  var10001 = I[24 ^ 40];
                  if (var8 == null) {
                     var10002 = I[6 ^ 55];
                     "".length();
                     if (-1 >= 3) {
                        throw null;
                     }
                  } else {
                     var10002 = var8.toString();
                  }

                  var7.addProperty(var10001, var10002);
                  var7.addProperty(I[153 ^ 171], var1.getPlayers()[var6].getName());
                  var5.add(var7);
                  ++var6;
                  "".length();
                  if (3 < 0) {
                     throw null;
                  }
               }

               var4.add(I[244 ^ 199], var5);
            }

            return var4;
         }

         public ServerStatusResponse.Players deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            var10000 = I[78 ^ 74];
            var10001 = I[3 ^ 6];
            var10002 = I[117 ^ 115];
            var10001 = I[103 ^ 96];
            var10000 = I[144 ^ 152];
            var10001 = I[76 ^ 69];
            var10002 = I[40 ^ 34];
            var10001 = I[48 ^ 59];
            JsonObject var4 = JsonUtils.getJsonObject(var1, I[101 ^ 105]);
            I[1 ^ 12].length();
            I[66 ^ 76].length();
            I[162 ^ 173].length();
            I[11 ^ 27].length();
            ServerStatusResponse.Players var5 = new ServerStatusResponse.Players(JsonUtils.getInt(var4, I[53 ^ 36]), JsonUtils.getInt(var4, I[48 ^ 34]));
            if (JsonUtils.isJsonArray(var4, I[100 ^ 119])) {
               JsonArray var6 = JsonUtils.getJsonArray(var4, I[9 ^ 29]);
               if (var6.size() > 0) {
                  GameProfile[] var7 = new GameProfile[var6.size()];
                  int var8 = "".length();

                  while(var8 < var7.length) {
                     JsonElement var11 = var6.get(var8);
                     I[166 ^ 179].length();
                     I[2 ^ 20].length();
                     JsonObject var9 = JsonUtils.getJsonObject(var11, I[214 ^ 193] + var8 + I[75 ^ 83]);
                     String var10 = JsonUtils.getString(var9, I[121 ^ 96]);
                     I[190 ^ 164].length();
                     var7[var8] = new GameProfile(UUID.fromString(var10), JsonUtils.getString(var9, I[0 ^ 27]));
                     ++var8;
                     "".length();
                     if (-1 != -1) {
                        throw null;
                     }
                  }

                  var5.setPlayers(var7);
               }
            }

            return var5;
         }

         private static void I() {
            I = new String[242 ^ 198];
            I["".length()] = I("嵩徢", "oUrrH");
            I[" ".length()] = I("妸凙", "cxjto");
            I["  ".length()] = I("渺槾", "yZfeD");
            I["   ".length()] = I("旭夁", "wFUyz");
            I[173 ^ 169] = I("嘢样", "HCBCU");
            I[9 ^ 12] = I("漵槝", "TLMDk");
            I[33 ^ 39] = I("汐埄", "oeczT");
            I[98 ^ 101] = I("氤泺", "wlnjp");
            I[135 ^ 143] = I("栎杬", "ehNlS");
            I[158 ^ 151] = I("庫夂", "viYlN");
            I[71 ^ 77] = I("善桐", "NXcEx");
            I[179 ^ 184] = I("斣塭", "HtKUe");
            I[19 ^ 31] = I("):\u000f(\u001d+%", "YVnQx");
            I[201 ^ 196] = I("憴杬", "mSzPO");
            I[108 ^ 98] = I("只瀳歌", "QcSHW");
            I[143 ^ 128] = I("庎搁样汍嗆", "frQNr");
            I[86 ^ 70] = I("嚗棺梊代抋", "OXCeo");
            I[177 ^ 160] = I("\u0019\u0015?", "ttGep");
            I[180 ^ 166] = I("!\u0001&;>+", "NoJRP");
            I[121 ^ 106] = I("\u0018\r4\u0015\u001a\u000e", "klYev");
            I[174 ^ 186] = I("4; :\u0001\"", "GZMJm");
            I[114 ^ 103] = I("壑亊扨丠", "yAztr");
            I[16 ^ 6] = I("嶐湢塱囲", "AIBrp");
            I[166 ^ 177] = I("!89?\u0004#\u000f", "QTXFa");
            I[68 ^ 92] = I(".", "sihzh");
            I[108 ^ 117] = I("(2", "AVYae");
            I[219 ^ 193] = I("棄怩搜", "CENwL");
            I[150 ^ 141] = I("\u0005$\u0018\u0003", "kEufU");
            I[159 ^ 131] = I("沌巓", "QLmTl");
            I[159 ^ 130] = I("樈弋", "seFXF");
            I[66 ^ 92] = I("伐寓", "aRjpA");
            I[8 ^ 23] = I("埀峝", "FESJI");
            I[51 ^ 19] = I("垸壔", "GcmKV");
            I[145 ^ 176] = I("怪侚", "kcUdH");
            I[44 ^ 14] = I("捊淫", "zAxJE");
            I[124 ^ 95] = I("楬巖", "edgSR");
            I[153 ^ 189] = I("橼凈", "DEcLn");
            I[7 ^ 34] = I("份慻", "QSnHw");
            I[131 ^ 165] = I("岨椃", "KBHOO");
            I[34 ^ 5] = I("桽唪", "tgwPq");
            I[112 ^ 88] = I("沲厩公戎", "gIUaP");
            I[67 ^ 106] = I("\u000e'?", "cFGpd");
            I[165 ^ 143] = I("\u0019?%\"\"\u0013", "vQIKL");
            I[90 ^ 113] = I("丫帐妙", "RkJHC");
            I[113 ^ 93] = I("兤囘憗倭", "Rxdqu");
            I[42 ^ 7] = I("搮憽婗", "IaFhF");
            I[187 ^ 149] = I("峜囻刐寎", "adfTj");
            I[40 ^ 7] = I("塓", "mCUTZ");
            I[176 ^ 128] = I("0-", "YILqA");
            I[179 ^ 130] = I("", "OOChx");
            I[144 ^ 162] = I("\u0019\u0012\u000b/", "wsfJp");
            I[41 ^ 26] = I(">9/\u001d;(", "MXBmW");
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(2 == 2);

            throw null;
         }

         static {
            I();
         }
      }
   }

   public static class Version {
      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      private final int protocol;

      public int getProtocol() {
         return this.protocol;
      }

      public Version(String var1, int var2) {
         this.name = var1;
         this.protocol = var2;
      }

      public String getName() {
         return this.name;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(true);

         throw null;
      }

      public static class Serializer implements JsonDeserializer<ServerStatusResponse.Version>, JsonSerializer<ServerStatusResponse.Version> {
         // $FF: synthetic field
         private static final String[] I;

         public ServerStatusResponse.Version deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
            String var10000 = I["".length()];
            String var10001 = I[" ".length()];
            String var10002 = I["  ".length()];
            var10001 = I["   ".length()];
            JsonObject var4 = JsonUtils.getJsonObject(var1, I[154 ^ 158]);
            I[147 ^ 150].length();
            I[92 ^ 90].length();
            I[135 ^ 128].length();
            I[0 ^ 8].length();
            return new ServerStatusResponse.Version(JsonUtils.getString(var4, I[67 ^ 74]), JsonUtils.getInt(var4, I[169 ^ 163]));
         }

         private static void I() {
            I = new String[64 ^ 84];
            I["".length()] = I("淏岰", "eZkWp");
            I[" ".length()] = I("捩埦", "nOPAl");
            I["  ".length()] = I("夾昐", "yslFY");
            I["   ".length()] = I("哪嵱", "LqZKH");
            I[107 ^ 111] = I("\u0005\u00170\u0017$\u001c\u001c", "srBdM");
            I[145 ^ 148] = I("晌", "zCfSY");
            I[81 ^ 87] = I("嵆易", "kbvRl");
            I[186 ^ 189] = I("涧咭凝", "OVrMu");
            I[175 ^ 167] = I("呁宿怘夵櫝", "iVrzy");
            I[95 ^ 86] = I("4\u0003\"\u001f", "ZbOzu");
            I[112 ^ 122] = I("3?8\u001d# \";", "CMWiL");
            I[6 ^ 13] = I("烘濩", "Ixwwg");
            I[8 ^ 4] = I("岉嶨", "vfBbc");
            I[35 ^ 46] = I("案丫", "zBZrO");
            I[125 ^ 115] = I("汃俱", "rcacg");
            I[155 ^ 148] = I("搰桾峥榔", "ShAbE");
            I[115 ^ 99] = I("摀", "eKCKd");
            I[40 ^ 57] = I("咘唑", "RgCgq");
            I[99 ^ 113] = I("\u0005\u0017.)", "kvCLV");
            I[67 ^ 80] = I("\u0011%\r\u000e\u001d\u00028\u000e", "aWbzr");
         }

         public JsonElement serialize(ServerStatusResponse.Version var1, Type var2, JsonSerializationContext var3) {
            String var10000 = I[100 ^ 111];
            String var10001 = I[120 ^ 116];
            String var10002 = I[74 ^ 71];
            var10001 = I[34 ^ 44];
            I[145 ^ 158].length();
            I[145 ^ 129].length();
            I[107 ^ 122].length();
            JsonObject var4 = new JsonObject();
            var4.addProperty(I[162 ^ 176], var1.getName());
            var4.addProperty(I[162 ^ 177], var1.getProtocol());
            return var4;
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(1 != 2);

            throw null;
         }

         static {
            I();
         }
      }
   }
}

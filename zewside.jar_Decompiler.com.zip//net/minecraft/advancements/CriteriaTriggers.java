package net.minecraft.advancements;

import com.google.common.collect.Maps;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.advancements.critereon.BredAnimalsTrigger;
import net.minecraft.advancements.critereon.BrewedPotionTrigger;
import net.minecraft.advancements.critereon.ChangeDimensionTrigger;
import net.minecraft.advancements.critereon.ConstructBeaconTrigger;
import net.minecraft.advancements.critereon.ConsumeItemTrigger;
import net.minecraft.advancements.critereon.CuredZombieVillagerTrigger;
import net.minecraft.advancements.critereon.EffectsChangedTrigger;
import net.minecraft.advancements.critereon.EnchantedItemTrigger;
import net.minecraft.advancements.critereon.EnterBlockTrigger;
import net.minecraft.advancements.critereon.EntityHurtPlayerTrigger;
import net.minecraft.advancements.critereon.ImpossibleTrigger;
import net.minecraft.advancements.critereon.InventoryChangeTrigger;
import net.minecraft.advancements.critereon.ItemDurabilityTrigger;
import net.minecraft.advancements.critereon.KilledTrigger;
import net.minecraft.advancements.critereon.LevitationTrigger;
import net.minecraft.advancements.critereon.NetherTravelTrigger;
import net.minecraft.advancements.critereon.PlacedBlockTrigger;
import net.minecraft.advancements.critereon.PlayerHurtEntityTrigger;
import net.minecraft.advancements.critereon.PositionTrigger;
import net.minecraft.advancements.critereon.RecipeUnlockedTrigger;
import net.minecraft.advancements.critereon.SummonedEntityTrigger;
import net.minecraft.advancements.critereon.TameAnimalTrigger;
import net.minecraft.advancements.critereon.TickTrigger;
import net.minecraft.advancements.critereon.UsedEnderEyeTrigger;
import net.minecraft.advancements.critereon.UsedTotemTrigger;
import net.minecraft.advancements.critereon.VillagerTradeTrigger;
import net.minecraft.util.ResourceLocation;

public class CriteriaTriggers {
   // $FF: synthetic field
   public static final ConstructBeaconTrigger field_192131_k;
   // $FF: synthetic field
   public static final PositionTrigger field_192135_o;
   // $FF: synthetic field
   public static final ConsumeItemTrigger field_193138_y;
   // $FF: synthetic field
   public static final PlayerHurtEntityTrigger field_192127_g;
   // $FF: synthetic field
   public static final InventoryChangeTrigger field_192125_e;
   // $FF: synthetic field
   public static final EntityHurtPlayerTrigger field_192128_h;
   // $FF: synthetic field
   public static final KilledTrigger field_192122_b;
   // $FF: synthetic field
   public static final TickTrigger field_193135_v;
   // $FF: synthetic field
   public static final LevitationTrigger field_193133_t;
   // $FF: synthetic field
   public static final UsedEnderEyeTrigger field_192132_l;
   // $FF: synthetic field
   public static final VillagerTradeTrigger field_192138_r;
   // $FF: synthetic field
   public static final TameAnimalTrigger field_193136_w;
   // $FF: synthetic field
   public static final EnchantedItemTrigger field_192129_i;
   // $FF: synthetic field
   public static final EnterBlockTrigger field_192124_d;
   // $FF: synthetic field
   public static final KilledTrigger field_192123_c;
   // $FF: synthetic field
   public static final NetherTravelTrigger field_193131_B;
   // $FF: synthetic field
   public static final PlacedBlockTrigger field_193137_x;
   // $FF: synthetic field
   public static final UsedTotemTrigger field_193130_A;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PositionTrigger field_192136_p;
   // $FF: synthetic field
   public static final EffectsChangedTrigger field_193139_z;
   // $FF: synthetic field
   public static final ItemDurabilityTrigger field_193132_s;
   // $FF: synthetic field
   public static final BredAnimalsTrigger field_192134_n;
   // $FF: synthetic field
   private static final Map<ResourceLocation, ICriterionTrigger<?>> field_192139_s;
   // $FF: synthetic field
   public static final ChangeDimensionTrigger field_193134_u;
   // $FF: synthetic field
   public static final CuredZombieVillagerTrigger field_192137_q;
   // $FF: synthetic field
   public static final RecipeUnlockedTrigger field_192126_f;
   // $FF: synthetic field
   public static final SummonedEntityTrigger field_192133_m;
   // $FF: synthetic field
   public static final ImpossibleTrigger field_192121_a;
   // $FF: synthetic field
   public static final BrewedPotionTrigger field_192130_j;

   static {
      I();
      field_192139_s = Maps.newHashMap();
      field_192121_a = (ImpossibleTrigger)func_192118_a(new ImpossibleTrigger());
      field_192122_b = (KilledTrigger)func_192118_a(new KilledTrigger(new ResourceLocation(I[109 ^ 127])));
      field_192123_c = (KilledTrigger)func_192118_a(new KilledTrigger(new ResourceLocation(I[106 ^ 121])));
      field_192124_d = (EnterBlockTrigger)func_192118_a(new EnterBlockTrigger());
      field_192125_e = (InventoryChangeTrigger)func_192118_a(new InventoryChangeTrigger());
      field_192126_f = (RecipeUnlockedTrigger)func_192118_a(new RecipeUnlockedTrigger());
      field_192127_g = (PlayerHurtEntityTrigger)func_192118_a(new PlayerHurtEntityTrigger());
      field_192128_h = (EntityHurtPlayerTrigger)func_192118_a(new EntityHurtPlayerTrigger());
      field_192129_i = (EnchantedItemTrigger)func_192118_a(new EnchantedItemTrigger());
      field_192130_j = (BrewedPotionTrigger)func_192118_a(new BrewedPotionTrigger());
      field_192131_k = (ConstructBeaconTrigger)func_192118_a(new ConstructBeaconTrigger());
      field_192132_l = (UsedEnderEyeTrigger)func_192118_a(new UsedEnderEyeTrigger());
      field_192133_m = (SummonedEntityTrigger)func_192118_a(new SummonedEntityTrigger());
      field_192134_n = (BredAnimalsTrigger)func_192118_a(new BredAnimalsTrigger());
      field_192135_o = (PositionTrigger)func_192118_a(new PositionTrigger(new ResourceLocation(I[64 ^ 84])));
      field_192136_p = (PositionTrigger)func_192118_a(new PositionTrigger(new ResourceLocation(I[62 ^ 43])));
      field_192137_q = (CuredZombieVillagerTrigger)func_192118_a(new CuredZombieVillagerTrigger());
      field_192138_r = (VillagerTradeTrigger)func_192118_a(new VillagerTradeTrigger());
      field_193132_s = (ItemDurabilityTrigger)func_192118_a(new ItemDurabilityTrigger());
      field_193133_t = (LevitationTrigger)func_192118_a(new LevitationTrigger());
      field_193134_u = (ChangeDimensionTrigger)func_192118_a(new ChangeDimensionTrigger());
      field_193135_v = (TickTrigger)func_192118_a(new TickTrigger());
      field_193136_w = (TameAnimalTrigger)func_192118_a(new TameAnimalTrigger());
      field_193137_x = (PlacedBlockTrigger)func_192118_a(new PlacedBlockTrigger());
      field_193138_y = (ConsumeItemTrigger)func_192118_a(new ConsumeItemTrigger());
      field_193139_z = (EffectsChangedTrigger)func_192118_a(new EffectsChangedTrigger());
      field_193130_A = (UsedTotemTrigger)func_192118_a(new UsedTotemTrigger());
      field_193131_B = (NetherTravelTrigger)func_192118_a(new NetherTravelTrigger());
   }

   @Nullable
   public static <T extends ICriterionInstance> ICriterionTrigger<T> func_192119_a(ResourceLocation var0) {
      return (ICriterionTrigger)field_192139_s.get(var0);
   }

   private static <T extends ICriterionTrigger> T func_192118_a(T var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[139 ^ 143];
      var10001 = I[104 ^ 109];
      var10002 = I[113 ^ 119];
      var10001 = I[5 ^ 2];
      if (field_192139_s.containsKey(var0.func_192163_a())) {
         I[149 ^ 157].length();
         I[128 ^ 137].length();
         I[75 ^ 65].length();
         I[162 ^ 169].length();
         I[101 ^ 105].length();
         I[77 ^ 64].length();
         IllegalArgumentException var1 = new IllegalArgumentException(I[65 ^ 79] + var0.func_192163_a());
         I[206 ^ 193].length();
         I[6 ^ 22].length();
         throw var1;
      } else {
         field_192139_s.put(var0.func_192163_a(), var0);
         I[34 ^ 51].length();
         return var0;
      }
   }

   private static void I() {
      I = new String[148 ^ 130];
      I["".length()] = I("柈拴", "vVZbJ");
      I[" ".length()] = I("摮啷", "cvzzP");
      I["  ".length()] = I("垒冄", "fQZlZ");
      I["   ".length()] = I("媬免", "TgUgA");
      I[167 ^ 163] = I("戰悃", "rhHBK");
      I[14 ^ 11] = I("濪湙", "MCdkh");
      I[83 ^ 85] = I("台冏", "byFHi");
      I[112 ^ 119] = I("庰媹", "QmiZw");
      I[151 ^ 159] = I("婇憼屃抙囬", "IIOFj");
      I[165 ^ 172] = I("母囼", "EjnAV");
      I[58 ^ 48] = I("炇彲", "fuJub");
      I[85 ^ 94] = I("尩", "RzWEZ");
      I[189 ^ 177] = I("棋揹氞", "nSooy");
      I[41 ^ 36] = I("丆楙嚘慓擾", "nUUOU");
      I[57 ^ 55] = I("\u00113\u0004\u001c=6'\u0000\u0015t64\u001d\u00041'/\u001b\u001et<\"T", "UFtpT");
      I[127 ^ 112] = I("渳朮檿", "tIdvE");
      I[190 ^ 174] = I("煲壈堋壌", "nZFEp");
      I[143 ^ 158] = I("塨槲婦", "NiEiS");
      I[152 ^ 138] = I("\"'\n\u000f\u0002 \u0014\u0000\u001f\u000b>.\u000f)\u0002<?\u0002\u0002\u001e", "RKkvg");
      I[187 ^ 168] = I("\u0011&\u0000&.\r\u0017\u001f&6\u0018-\u0010\u0010*\u0018)\r*(", "tHtOZ");
      I[88 ^ 76] = I("#8\f\f\u0002&8\u0001", "OWomv");
      I[49 ^ 36] = I("\u0000\u0004(\u001e8,\u0001#1.\u0016\f", "shMnL");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= -1);

      throw null;
   }

   public static Iterable<? extends ICriterionTrigger<?>> func_192120_a() {
      return field_192139_s.values();
   }
}

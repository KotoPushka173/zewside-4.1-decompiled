package net.minecraft.advancements.critereon;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class EnchantmentPredicate {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final MinMaxBounds field_192468_c;
   // $FF: synthetic field
   private final Enchantment field_192467_b;
   // $FF: synthetic field
   public static final EnchantmentPredicate field_192466_a;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 3);

      throw null;
   }

   public static EnchantmentPredicate func_192464_a(@Nullable JsonElement var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[30 ^ 26];
      var10001 = I[106 ^ 111];
      var10002 = I[74 ^ 76];
      var10001 = I[45 ^ 42];
      var10000 = I[165 ^ 173];
      var10001 = I[123 ^ 114];
      var10002 = I[147 ^ 153];
      var10001 = I[38 ^ 45];
      var10000 = I[172 ^ 160];
      var10001 = I[77 ^ 64];
      var10002 = I[100 ^ 106];
      var10001 = I[68 ^ 75];
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = JsonUtils.getJsonObject(var0, I[97 ^ 113]);
         Enchantment var2 = null;
         if (var1.has(I[151 ^ 134])) {
            I[58 ^ 40].length();
            ResourceLocation var3 = new ResourceLocation(JsonUtils.getString(var1, I[177 ^ 162]));
            var2 = (Enchantment)Enchantment.REGISTRY.getObject(var3);
            if (var2 == null) {
               I[140 ^ 152].length();
               I[12 ^ 25].length();
               I[51 ^ 37].length();
               I[34 ^ 53].length();
               JsonSyntaxException var5 = new JsonSyntaxException(I[86 ^ 78] + var3 + I[101 ^ 124]);
               I[133 ^ 159].length();
               I[49 ^ 42].length();
               throw var5;
            }
         }

         MinMaxBounds var4 = MinMaxBounds.func_192515_a(var1.get(I[36 ^ 56]));
         I[57 ^ 36].length();
         I[185 ^ 167].length();
         return new EnchantmentPredicate(var2, var4);
      } else {
         return field_192466_a;
      }
   }

   private static void I() {
      I = new String[170 ^ 138];
      I["".length()] = I("忁柭", "kRSDO");
      I[" ".length()] = I("厚促", "KLCEv");
      I["  ".length()] = I("各伭", "mmwhG");
      I["   ".length()] = I("扡丈", "SckZS");
      I[165 ^ 161] = I("撡妔", "dLyzX");
      I[99 ^ 102] = I("厑拧", "hllOL");
      I[83 ^ 85] = I("擊嶰", "Cokym");
      I[169 ^ 174] = I("各嵇", "IuRij");
      I[131 ^ 139] = I("濿林", "Bgawm");
      I[87 ^ 94] = I("擬抈", "HDlVm");
      I[64 ^ 74] = I("垽墯", "iKbfu");
      I[16 ^ 27] = I("氿懨", "RvgAD");
      I[50 ^ 62] = I("兮吠", "VHKtP");
      I[139 ^ 134] = I("櫌渹", "rdwfI");
      I[18 ^ 28] = I("嗂朕", "YTxdW");
      I[13 ^ 2] = I("歴槮", "DyYMt");
      I[36 ^ 52] = I("-\b\u000f8\t&\u0012\u00015\u0006<", "HflPh");
      I[145 ^ 128] = I("\u0017%-*\u0019\u001c?#'\u0016\u0006", "rKNBx");
      I[98 ^ 112] = I("懅椽热搕殖", "STMQD");
      I[143 ^ 156] = I("#+;=\u0002(150\r2", "FEXUc");
      I[154 ^ 142] = I("弳拤吅", "XEYLe");
      I[73 ^ 92] = I("擸敹捚", "YjhtF");
      I[164 ^ 178] = I("晟噀堠", "HGmhd");
      I[15 ^ 24] = I("拹倰", "Ovcbz");
      I[135 ^ 159] = I("$%\u0005)\f\u0006%N\"\r\u0012#\u000f)\u0017\u001c.\u00003CV", "qKnGc");
      I[161 ^ 184] = I("b", "EyvJo");
      I[67 ^ 89] = I("儵泞", "WLoIF");
      I[170 ^ 177] = I("崝洘", "HDjUp");
      I[8 ^ 20] = I("/<\u000e\u001f\u00010", "CYxzm");
      I[122 ^ 103] = I("憭歖患勍椉", "yGWch");
      I[76 ^ 82] = I("媩天寪患", "DSMBu");
      I[220 ^ 195] = I("\u000b7\u0001\f\u0015\u0000-\u000f\u0001\u001a\u001a*", "nYbdt");
   }

   public boolean func_192463_a(Map<Enchantment, Integer> var1) {
      if (this.field_192467_b != null) {
         if (!var1.containsKey(this.field_192467_b)) {
            return (boolean)"".length();
         }

         int var2 = (Integer)var1.get(this.field_192467_b);
         if (this.field_192468_c != null && !this.field_192468_c.func_192514_a((float)var2)) {
            return (boolean)"".length();
         }

         "".length();
         if (4 <= 0) {
            throw null;
         }
      } else if (this.field_192468_c != null) {
         Iterator var4 = var1.values().iterator();

         do {
            if (!var4.hasNext()) {
               return (boolean)"".length();
            }

            Integer var3 = (Integer)var4.next();
            if (this.field_192468_c.func_192514_a((float)var3)) {
               return (boolean)" ".length();
            }

            "".length();
         } while(2 > 0);

         throw null;
      }

      return (boolean)" ".length();
   }

   public EnchantmentPredicate(@Nullable Enchantment var1, MinMaxBounds var2) {
      this.field_192467_b = var1;
      this.field_192468_c = var2;
   }

   public static EnchantmentPredicate[] func_192465_b(@Nullable JsonElement var0) {
      if (var0 != null && !var0.isJsonNull()) {
         JsonArray var1 = JsonUtils.getJsonArray(var0, I[79 ^ 80]);
         EnchantmentPredicate[] var2 = new EnchantmentPredicate[var1.size()];
         int var3 = "".length();

         do {
            if (var3 >= var2.length) {
               return var2;
            }

            var2[var3] = func_192464_a(var1.get(var3));
            ++var3;
            "".length();
         } while(0 != 3);

         throw null;
      } else {
         return new EnchantmentPredicate["".length()];
      }
   }

   public EnchantmentPredicate() {
      this.field_192467_b = null;
      this.field_192468_c = MinMaxBounds.field_192516_a;
   }

   static {
      I();
      field_192466_a = new EnchantmentPredicate();
   }
}

package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBanner;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockBanner extends BlockContainer {
   // $FF: synthetic field
   public static final PropertyInteger ROTATION;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   protected static final AxisAlignedBB STANDING_AABB;

   private ItemStack getTileDataItemStack(World var1, BlockPos var2) {
      TileEntity var3 = var1.getTileEntity(var2);
      ItemStack var10000;
      if (var3 instanceof TileEntityBanner) {
         var10000 = ((TileEntityBanner)var3).func_190615_l();
         "".length();
         if (-1 == 1) {
            throw null;
         }
      } else {
         var10000 = ItemStack.field_190927_a;
      }

      return var10000;
   }

   public String getLocalizedName() {
      return I18n.translateToLocal(I["".length()]);
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[" ".length()];
      String var10001 = I["  ".length()];
      String var10002 = I["   ".length()];
      var10001 = I[36 ^ 32];
      I[7 ^ 2].length();
      return new TileEntityBanner();
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (!this.hasInvalidNeighbor(var1, var2) && super.canPlaceBlockAt(var1, var2)) {
         var10000 = " ".length();
         "".length();
         if (2 < 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      ROTATION = PropertyInteger.create(I[157 ^ 144], "".length(), 108 ^ 99);
      STANDING_AABB = new AxisAlignedBB(0.25D, 0.0D, 0.25D, 0.75D, 1.0D, 0.75D);
   }

   protected BlockBanner() {
      super(Material.WOOD);
   }

   private static void I() {
      I = new String[60 ^ 50];
      I["".length()] = I("/6'7T$#,4\u001f4l52\u00132'l4\u001b+'", "FBBZz");
      I[" ".length()] = I("暃悵", "SViIg");
      I["  ".length()] = I("拙姥", "MNDre");
      I["   ".length()] = I("戝侸", "VRiAG");
      I[58 ^ 62] = I("淫倿", "fbKhH");
      I[23 ^ 18] = I("愤", "jRCjV");
      I[112 ^ 118] = I("传愄", "ZrMdM");
      I[71 ^ 64] = I("媖歟", "eOVFG");
      I[88 ^ 80] = I("嫫幻", "VUJff");
      I[88 ^ 81] = I("乲櫔", "DwMiF");
      I[80 ^ 90] = I("怢旊濉慼榳", "uyxjg");
      I[50 ^ 57] = I("檂毎弧抛", "AalNG");
      I[179 ^ 191] = I("凮", "QoRbb");
      I[53 ^ 56] = I("\u001e\u0007<\u0012\u000e\u0005\u0007&", "lhHsz");
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean canSpawnInBlock() {
      return (boolean)" ".length();
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.BANNER;
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      if (var5 instanceof TileEntityBanner) {
         TileEntityBanner var7 = (TileEntityBanner)var5;
         ItemStack var8 = var7.func_190615_l();
         spawnAsEntity(var1, var3, var8);
         "".length();
         if (1 == 3) {
            throw null;
         }
      } else {
         super.harvestBlock(var1, var2, var3, var4, (TileEntity)null, var6);
      }

   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      return (boolean)" ".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 != 0);

      throw null;
   }

   public void dropBlockAsItemWithChance(World var1, BlockPos var2, IBlockState var3, float var4, int var5) {
      ItemStack var6 = this.getTileDataItemStack(var1, var2);
      if (var6.isEmpty()) {
         super.dropBlockAsItemWithChance(var1, var2, var3, var4, var5);
         "".length();
         if (0 >= 3) {
            throw null;
         }
      } else {
         spawnAsEntity(var1, var2, var6);
      }

   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[70 ^ 64];
      String var10001 = I[33 ^ 38];
      String var10002 = I[1 ^ 9];
      var10001 = I[21 ^ 28];
      ItemStack var4 = this.getTileDataItemStack(var1, var2);
      ItemStack var5;
      if (var4.isEmpty()) {
         I[85 ^ 95].length();
         I[189 ^ 182].length();
         I[10 ^ 6].length();
         var5 = new ItemStack(Items.BANNER);
         "".length();
         if (0 >= 2) {
            throw null;
         }
      } else {
         var5 = var4;
      }

      return var5;
   }

   public static class BlockBannerStanding extends BlockBanner {
      // $FF: synthetic field
      private static final String[] I;

      public int getMetaFromState(IBlockState var1) {
         return (Integer)var1.getValue(ROTATION);
      }

      public IBlockState getStateFromMeta(int var1) {
         return this.getDefaultState().withProperty(ROTATION, var1);
      }

      public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
         if (!var2.getBlockState(var3.down()).getMaterial().isSolid()) {
            this.dropBlockAsItem(var2, var3, var1, "".length());
            var2.setBlockToAir(var3);
            I["".length()].length();
            I[" ".length()].length();
         }

         super.neighborChanged(var1, var2, var3, var4, var5);
      }

      public IBlockState withRotation(IBlockState var1, Rotation var2) {
         return var1.withProperty(ROTATION, var2.rotate((Integer)var1.getValue(ROTATION), 87 ^ 71));
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 < 4);

         throw null;
      }

      private static void I() {
         I = new String[105 ^ 102];
         I["".length()] = I("巟", "TTVLh");
         I[" ".length()] = I("槫", "fUcuD");
         I["  ".length()] = I("匏娒", "tmOvz");
         I["   ".length()] = I("湇倚", "IwNMF");
         I[16 ^ 20] = I("哾煟", "aMiTs");
         I[72 ^ 77] = I("欮湗", "SmpMu");
         I[114 ^ 116] = I("斃弅", "iAceU");
         I[180 ^ 179] = I("景浃", "tLoqp");
         I[186 ^ 178] = I("呫剬", "DXFNN");
         I[163 ^ 170] = I("扙氞", "tCBgA");
         I[16 ^ 26] = I("楑懙攊劻懟", "wVLGD");
         I[115 ^ 120] = I("墳晢嵱", "sUZTd");
         I[207 ^ 195] = I("匀崹匱務案", "KqQvY");
         I[204 ^ 193] = I("挌刅", "ueMZr");
         I[166 ^ 168] = I("攺沉摟勢", "SWkmc");
      }

      static {
         I();
      }

      public IBlockState withMirror(IBlockState var1, Mirror var2) {
         return var1.withProperty(ROTATION, var2.mirrorRotation((Integer)var1.getValue(ROTATION), 20 ^ 4));
      }

      public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
         return STANDING_AABB;
      }

      public BlockBannerStanding() {
         this.setDefaultState(this.blockState.getBaseState().withProperty(ROTATION, "".length()));
      }

      protected BlockStateContainer createBlockState() {
         String var10000 = I["  ".length()];
         String var10001 = I["   ".length()];
         String var10002 = I[136 ^ 140];
         var10001 = I[196 ^ 193];
         var10000 = I[179 ^ 181];
         var10001 = I[64 ^ 71];
         var10002 = I[19 ^ 27];
         var10001 = I[46 ^ 39];
         I[206 ^ 196].length();
         IProperty[] var10003 = new IProperty[" ".length()];
         I[5 ^ 14].length();
         I[201 ^ 197].length();
         I[149 ^ 152].length();
         I[101 ^ 107].length();
         var10003["".length()] = ROTATION;
         return new BlockStateContainer(this, var10003);
      }
   }

   public static class BlockBannerHanging extends BlockBanner {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      protected static final AxisAlignedBB NORTH_AABB;
      // $FF: synthetic field
      protected static final AxisAlignedBB WEST_AABB;
      // $FF: synthetic field
      protected static final AxisAlignedBB EAST_AABB;
      // $FF: synthetic field
      protected static final AxisAlignedBB SOUTH_AABB;

      public IBlockState withMirror(IBlockState var1, Mirror var2) {
         return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
      }

      public BlockBannerHanging() {
         this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
      }

      public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
         switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
         case 1:
         default:
            return NORTH_AABB;
         case 2:
            return SOUTH_AABB;
         case 3:
            return WEST_AABB;
         case 4:
            return EAST_AABB;
         }
      }

      public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
         EnumFacing var6 = (EnumFacing)var1.getValue(FACING);
         if (!var2.getBlockState(var3.offset(var6.getOpposite())).getMaterial().isSolid()) {
            this.dropBlockAsItem(var2, var3, var1, "".length());
            var2.setBlockToAir(var3);
            I["".length()].length();
         }

         super.neighborChanged(var1, var2, var3, var4, var5);
      }

      public IBlockState getStateFromMeta(int var1) {
         EnumFacing var2 = EnumFacing.getFront(var1);
         if (var2.getAxis() == EnumFacing.Axis.Y) {
            var2 = EnumFacing.NORTH;
         }

         return this.getDefaultState().withProperty(FACING, var2);
      }

      protected BlockStateContainer createBlockState() {
         String var10000 = I[" ".length()];
         String var10001 = I["  ".length()];
         String var10002 = I["   ".length()];
         var10001 = I[109 ^ 105];
         var10000 = I[121 ^ 124];
         var10001 = I[51 ^ 53];
         var10002 = I[40 ^ 47];
         var10001 = I[78 ^ 70];
         I[58 ^ 51].length();
         IProperty[] var10003 = new IProperty[" ".length()];
         I[187 ^ 177].length();
         I[146 ^ 153].length();
         var10003["".length()] = FACING;
         return new BlockStateContainer(this, var10003);
      }

      public IBlockState withRotation(IBlockState var1, Rotation var2) {
         return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 != 3);

         throw null;
      }

      private static void I() {
         I = new String[29 ^ 17];
         I["".length()] = I("夼刺嶰國坘", "qoTYz");
         I[" ".length()] = I("拘煈", "FIgnj");
         I["  ".length()] = I("滎殱", "ffhFD");
         I["   ".length()] = I("沧煻", "hpzTo");
         I[134 ^ 130] = I("櫔櫋", "etrDW");
         I[181 ^ 176] = I("咍敘", "lnLGg");
         I[80 ^ 86] = I("捲它", "XqSpJ");
         I[177 ^ 182] = I("櫾凷", "MVzcL");
         I[87 ^ 95] = I("伵愰", "OiiuS");
         I[119 ^ 126] = I("凡氻噛", "mhiCg");
         I[22 ^ 28] = I("渔坄", "zeMOf");
         I[206 ^ 197] = I("囍嗴恝", "FaiVS");
      }

      static {
         I();
         NORTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.875D, 1.0D, 0.78125D, 1.0D);
         SOUTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.78125D, 0.125D);
         WEST_AABB = new AxisAlignedBB(0.875D, 0.0D, 0.0D, 1.0D, 0.78125D, 1.0D);
         EAST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.125D, 0.78125D, 1.0D);
      }

      public int getMetaFromState(IBlockState var1) {
         return ((EnumFacing)var1.getValue(FACING)).getIndex();
      }
   }
}

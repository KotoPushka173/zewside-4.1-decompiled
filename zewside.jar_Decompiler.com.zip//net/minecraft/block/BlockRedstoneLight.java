package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRedstoneLight extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final boolean isOn;

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         if (this.isOn && !var1.isBlockPowered(var2)) {
            var1.setBlockState(var2, Blocks.REDSTONE_LAMP.getDefaultState(), "  ".length());
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            "".length();
            if (2 == -1) {
               throw null;
            }
         } else if (!this.isOn && var1.isBlockPowered(var2)) {
            var1.setBlockState(var2, Blocks.LIT_REDSTONE_LAMP.getDefaultState(), "  ".length());
            I["   ".length()].length();
            I[179 ^ 183].length();
         }
      }

   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote) {
         if (this.isOn && !var2.isBlockPowered(var3)) {
            var2.scheduleUpdate(var3, this, 141 ^ 137);
            "".length();
            if (0 >= 3) {
               throw null;
            }
         } else if (!this.isOn && var2.isBlockPowered(var3)) {
            var2.setBlockState(var3, Blocks.LIT_REDSTONE_LAMP.getDefaultState(), "  ".length());
            I[48 ^ 53].length();
            I[77 ^ 75].length();
         }
      }

   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Item.getItemFromBlock(Blocks.REDSTONE_LAMP);
   }

   private static void I() {
      I = new String[118 ^ 96];
      I["".length()] = I("浘", "wgZns");
      I[" ".length()] = I("撄", "gWZHc");
      I["  ".length()] = I("叠坞掙", "zXmSr");
      I["   ".length()] = I("擅儇梷憄", "xEKMu");
      I[23 ^ 19] = I("敲漩伞峧", "UOtZa");
      I[148 ^ 145] = I("峺伪嬮毹弦", "TkVpa");
      I[23 ^ 17] = I("峉倸楙攋待", "lBeZR");
      I[15 ^ 8] = I("娙僸城", "XyNdI");
      I[114 ^ 122] = I("垸", "HxHth");
      I[158 ^ 151] = I("婺奱帀濶屮", "RAkdN");
      I[134 ^ 140] = I("圁刔", "FBMcn");
      I[80 ^ 91] = I("嵂啎", "cJhVW");
      I[61 ^ 49] = I("愙堊", "wNAwC");
      I[152 ^ 149] = I("懰帀", "zTfaS");
      I[137 ^ 135] = I("垵抖烺剢", "qdnZi");
      I[83 ^ 92] = I("愠", "pZRfP");
      I[39 ^ 55] = I("橏峈", "qPkPB");
      I[5 ^ 20] = I("壢厲", "FYIRz");
      I[176 ^ 162] = I("擿塳", "OhATo");
      I[174 ^ 189] = I("摺伕", "IETCD");
      I[20 ^ 0] = I("櫎吥嫪櫬", "AHtpp");
      I[181 ^ 160] = I("唉嚂懺", "zDYPO");
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote && this.isOn && !var1.isBlockPowered(var2)) {
         var1.setBlockState(var2, Blocks.REDSTONE_LAMP.getDefaultState(), "  ".length());
         I[81 ^ 86].length();
         I[175 ^ 167].length();
         I[113 ^ 120].length();
      }

   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      String var10000 = I[140 ^ 156];
      String var10001 = I[180 ^ 165];
      String var10002 = I[29 ^ 15];
      var10001 = I[133 ^ 150];
      I[86 ^ 66].length();
      I[39 ^ 50].length();
      return new ItemStack(Blocks.REDSTONE_LAMP);
   }

   static {
      I();
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[19 ^ 25];
      String var10001 = I[10 ^ 1];
      String var10002 = I[85 ^ 89];
      var10001 = I[26 ^ 23];
      I[48 ^ 62].length();
      I[31 ^ 16].length();
      return new ItemStack(Blocks.REDSTONE_LAMP);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 < 4);

      throw null;
   }

   public BlockRedstoneLight(boolean var1) {
      super(Material.REDSTONE_LIGHT);
      this.isOn = var1;
      if (var1) {
         this.setLightLevel(1.0F);
      }

   }
}

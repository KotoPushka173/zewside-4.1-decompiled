package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import io.netty.util.ByteProcessor;
import java.io.DataOutput;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.channels.GatheringByteChannel;
import java.nio.channels.ScatteringByteChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTSizeTracker;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;

public class PacketBuffer extends ByteBuf {
   // $FF: synthetic field
   private final ByteBuf buf;
   // $FF: synthetic field
   private static final String[] I;

   public boolean hasMemoryAddress() {
      return this.buf.hasMemoryAddress();
   }

   public PacketBuffer(ByteBuf var1) {
      this.buf = var1;
   }

   public ByteBuf setBytes(int var1, ByteBuf var2, int var3, int var4) {
      return this.buf.setBytes(var1, var2, var3, var4);
   }

   public long memoryAddress() {
      return this.buf.memoryAddress();
   }

   public ByteBuf writerIndex(int var1) {
      return this.buf.writerIndex(var1);
   }

   public int writableBytes() {
      return this.buf.writableBytes();
   }

   public long readUnsignedInt() {
      return this.buf.readUnsignedInt();
   }

   public ByteBuf setLongLE(int var1, long var2) {
      return this.buf.setLongLE(var1, var2);
   }

   public ByteBuf setBoolean(int var1, boolean var2) {
      return this.buf.setBoolean(var1, var2);
   }

   public ByteBuf writeBytes(ByteBuf var1, int var2) {
      return this.buf.writeBytes(var1, var2);
   }

   public ByteBuf readRetainedSlice(int var1) {
      return this.buf.readRetainedSlice(var1);
   }

   public int forEachByte(ByteProcessor var1) {
      return this.buf.forEachByte(var1);
   }

   public long readLongLE() {
      return this.buf.readLongLE();
   }

   public long[] readLongArray(@Nullable long[] var1, int var2) {
      String var10000 = I[129 ^ 180];
      String var10001 = I[7 ^ 49];
      String var10002 = I[121 ^ 78];
      var10001 = I[46 ^ 22];
      var10000 = I[171 ^ 146];
      var10001 = I[58 ^ 0];
      var10002 = I[101 ^ 94];
      var10001 = I[96 ^ 92];
      int var3 = this.readVarIntFromBuffer();
      if (var1 == null || var1.length != var3) {
         if (var3 > var2) {
            I[13 ^ 48].length();
            I[179 ^ 141].length();
            I[188 ^ 131].length();
            I[109 ^ 45].length();
            I[26 ^ 91].length();
            I[239 ^ 173].length();
            DecoderException var5 = new DecoderException(I[105 ^ 42] + var3 + I[217 ^ 157] + var2);
            I[93 ^ 24].length();
            I[41 ^ 111].length();
            throw var5;
         }

         var1 = new long[var3];
      }

      int var4 = "".length();

      do {
         if (var4 >= var1.length) {
            return var1;
         }

         var1[var4] = this.readLong();
         ++var4;
         "".length();
      } while(2 > -1);

      throw null;
   }

   public PacketBuffer writeString(String var1) {
      String var10000 = I[67 + 6 - -106 + 46];
      String var10001 = I[152 + 79 - 23 + 18];
      String var10002 = I[185 + 130 - 164 + 76];
      var10001 = I[188 + 120 - 256 + 176];
      var10000 = I[155 + 20 - 172 + 226];
      var10001 = I[207 + 100 - 290 + 213];
      var10002 = I[171 + 162 - 176 + 74];
      var10001 = I[228 + 204 - 353 + 153];
      byte[] var2 = var1.getBytes(StandardCharsets.UTF_8);
      if (var2.length > 29830 + 233 - 17955 + 20659) {
         I[116 + 11 - -60 + 46].length();
         I[161 + 182 - 217 + 108].length();
         I[189 + 113 - 203 + 136].length();
         I[18 + 51 - -113 + 54].length();
         I[25 + 32 - -73 + 107].length();
         I[164 + 198 - 248 + 124].length();
         EncoderException var3 = new EncoderException(I[230 + 84 - 85 + 10] + var2.length + I[100 + 77 - -8 + 55] + (11467 + 27934 - 15453 + 8819) + I[228 + 228 - 322 + 107]);
         I[26 + 40 - -165 + 11].length();
         I[139 + 30 - 148 + 222].length();
         I[33 + 209 - 83 + 85].length();
         I[133 + 86 - 110 + 136].length();
         throw var3;
      } else {
         this.writeVarIntToBuffer(var2.length);
         I[145 + 126 - 263 + 238].length();
         I[168 + 183 - 176 + 72].length();
         I[150 + 85 - 106 + 119].length();
         I[205 + 220 - 411 + 235].length();
         I[125 + 76 - -44 + 5].length();
         this.writeBytes(var2);
         I[8 + 27 - -201 + 15].length();
         I[33 + 169 - -12 + 38].length();
         return this;
      }
   }

   public int maxWritableBytes() {
      return this.buf.maxWritableBytes();
   }

   public ByteBuf skipBytes(int var1) {
      return this.buf.skipBytes(var1);
   }

   public byte getByte(int var1) {
      return this.buf.getByte(var1);
   }

   public int writeBytes(ScatteringByteChannel var1, int var2) throws IOException {
      return this.buf.writeBytes(var1, var2);
   }

   public int writeCharSequence(CharSequence var1, Charset var2) {
      return this.buf.writeCharSequence(var1, var2);
   }

   public ByteBuf copy() {
      return this.buf.copy();
   }

   public int getBytes(int var1, FileChannel var2, long var3, int var5) throws IOException {
      return this.buf.getBytes(var1, var2, var3, var5);
   }

   public ItemStack readItemStackFromBuffer() throws IOException {
      String var10000 = I[138 + 125 - 231 + 140];
      String var10001 = I[100 + 70 - 32 + 35];
      String var10002 = I[125 + 12 - 29 + 66];
      var10001 = I[17 + 100 - -7 + 51];
      short var1 = this.readShort();
      if (var1 < 0) {
         return ItemStack.field_190927_a;
      } else {
         byte var2 = this.readByte();
         short var3 = this.readShort();
         I[53 + 99 - 143 + 167].length();
         I[83 + 30 - -56 + 8].length();
         ItemStack var4 = new ItemStack(Item.getItemById(var1), var2, var3);
         var4.setTagCompound(this.readNBTTagCompoundFromBuffer());
         return var4;
      }
   }

   public boolean isReadOnly() {
      return this.buf.isReadOnly();
   }

   public int getInt(int var1) {
      return this.buf.getInt(var1);
   }

   public boolean isReadable(int var1) {
      return this.buf.isReadable(var1);
   }

   public int getMediumLE(int var1) {
      return this.buf.getMediumLE(var1);
   }

   public boolean readBoolean() {
      return this.buf.readBoolean();
   }

   public ByteBuf writeMedium(int var1) {
      return this.buf.writeMedium(var1);
   }

   public ByteBuf writeBytes(byte[] var1, int var2, int var3) {
      return this.buf.writeBytes(var1, var2, var3);
   }

   public char getChar(int var1) {
      return this.buf.getChar(var1);
   }

   public String readStringFromBuffer(int var1) {
      String var10000 = I[29 + 173 - 122 + 98];
      String var10001 = I[68 + 7 - -15 + 89];
      String var10002 = I[3 + 2 - -14 + 161];
      var10001 = I[112 + 52 - 93 + 110];
      var10000 = I[51 + 172 - 182 + 141];
      var10001 = I[172 + 141 - 289 + 159];
      var10002 = I[58 + 100 - 15 + 41];
      var10001 = I[86 + 168 - 226 + 157];
      var10000 = I[37 + 7 - -48 + 94];
      var10001 = I[171 + 89 - 169 + 96];
      var10002 = I[180 + 174 - 289 + 123];
      var10001 = I[82 + 117 - 72 + 62];
      var10000 = I[37 + 93 - -19 + 41];
      var10001 = I[70 + 121 - 55 + 55];
      var10002 = I[140 + 100 - 91 + 43];
      var10001 = I[61 + 130 - 5 + 7];
      var10000 = I[25 + 68 - 9 + 110];
      var10001 = I[185 + 162 - 227 + 75];
      var10002 = I[75 + 75 - 49 + 95];
      var10001 = I[139 + 104 - 161 + 115];
      int var2 = this.readVarIntFromBuffer();
      DecoderException var4;
      if (var2 > var1 * (167 ^ 163)) {
         I[23 + 17 - -10 + 148].length();
         I[31 + 168 - 110 + 110].length();
         I[140 + 33 - 50 + 77].length();
         I[58 + 71 - 68 + 140].length();
         var4 = new DecoderException(I[197 + 21 - 79 + 63] + var2 + I[165 + 131 - 269 + 176] + var1 * (25 ^ 29) + I[132 + 151 - 159 + 80]);
         I[74 + 128 - 30 + 33].length();
         I[49 + 106 - -11 + 40].length();
         throw var4;
      } else if (var2 < 0) {
         I[29 + 59 - 54 + 173].length();
         I[86 + 169 - 112 + 65].length();
         var4 = new DecoderException(I[103 + 172 - 209 + 143]);
         I[57 + 90 - -19 + 44].length();
         I[17 + 167 - 108 + 135].length();
         throw var4;
      } else {
         String var3 = this.toString(this.readerIndex(), var2, StandardCharsets.UTF_8);
         this.readerIndex(this.readerIndex() + var2);
         I[19 + 159 - 136 + 170].length();
         if (var3.length() > var1) {
            I[115 + 207 - 169 + 60].length();
            I[93 + 212 - 224 + 133].length();
            I[153 + 46 - 198 + 214].length();
            I[66 + 185 - 152 + 117].length();
            I[91 + 57 - -69 + 0].length();
            I[165 + 129 - 122 + 46].length();
            I[97 + 151 - 175 + 146].length();
            var4 = new DecoderException(I[60 + 215 - 160 + 105] + var2 + I[171 + 49 - 123 + 124] + var1 + I[173 + 120 - 140 + 69]);
            I[29 + 131 - -42 + 21].length();
            I[2 + 172 - 141 + 191].length();
            throw var4;
         } else {
            return var3;
         }
      }
   }

   public long readVarLong() {
      String var10000 = I[100 ^ 54];
      String var10001 = I[253 ^ 174];
      String var10002 = I[9 ^ 93];
      var10001 = I[126 ^ 43];
      long var1 = 0L;
      int var3 = "".length();

      do {
         byte var4 = this.readByte();
         var1 |= (long)(var4 & 7 + 20 - -76 + 24) << var3++ * (132 ^ 131);
         if (var3 > (144 ^ 154)) {
            I[145 ^ 199].length();
            I[92 ^ 11].length();
            I[242 ^ 170].length();
            RuntimeException var5 = new RuntimeException(I[15 ^ 86]);
            I[250 ^ 160].length();
            I[17 ^ 74].length();
            I[102 ^ 58].length();
            throw var5;
         }

         if ((var4 & 10 + 28 - 0 + 90) != 73 + 121 - 106 + 40) {
            "".length();
            if (3 < 1) {
               throw null;
            }

            return var1;
         }

         "".length();
      } while(2 != 3);

      throw null;
   }

   public byte readByte() {
      return this.buf.readByte();
   }

   public long readLong() {
      return this.buf.readLong();
   }

   public ByteBuf touch() {
      return this.buf.touch();
   }

   public int hashCode() {
      return this.buf.hashCode();
   }

   public int getUnsignedShort(int var1) {
      return this.buf.getUnsignedShort(var1);
   }

   public ByteBuf writeBytes(ByteBuf var1, int var2, int var3) {
      return this.buf.writeBytes(var1, var2, var3);
   }

   public int bytesBefore(int var1, byte var2) {
      return this.buf.bytesBefore(var1, var2);
   }

   public short readShort() {
      return this.buf.readShort();
   }

   public short readUnsignedByte() {
      return this.buf.readUnsignedByte();
   }

   static {
      I();
   }

   public ByteBuf writeChar(int var1) {
      return this.buf.writeChar(var1);
   }

   public ByteBuf writeDouble(double var1) {
      return this.buf.writeDouble(var1);
   }

   public ByteBuf slice(int var1, int var2) {
      return this.buf.slice(var1, var2);
   }

   public int readMediumLE() {
      return this.buf.readMediumLE();
   }

   public ByteBuf asReadOnly() {
      return this.buf.asReadOnly();
   }

   public ByteBuf ensureWritable(int var1) {
      return this.buf.ensureWritable(var1);
   }

   public ByteBuf setInt(int var1, int var2) {
      return this.buf.setInt(var1, var2);
   }

   public int readUnsignedMedium() {
      return this.buf.readUnsignedMedium();
   }

   public ByteBuf readBytes(ByteBuf var1, int var2) {
      return this.buf.readBytes(var1, var2);
   }

   public int writeBytes(FileChannel var1, long var2, int var4) throws IOException {
      return this.buf.writeBytes(var1, var2, var4);
   }

   public CharSequence readCharSequence(int var1, Charset var2) {
      return this.buf.readCharSequence(var1, var2);
   }

   public int setBytes(int var1, ScatteringByteChannel var2, int var3) throws IOException {
      return this.buf.setBytes(var1, var2, var3);
   }

   @Nullable
   public NBTTagCompound readNBTTagCompoundFromBuffer() throws IOException {
      String var10000 = I[56 + 51 - 79 + 106];
      String var10001 = I[43 + 52 - 54 + 94];
      String var10002 = I[40 + 18 - 43 + 121];
      var10001 = I[0 + 101 - 5 + 41];
      var10000 = I[50 + 64 - 16 + 40];
      var10001 = I[77 + 134 - 85 + 13];
      var10002 = I[124 + 26 - 113 + 103];
      var10001 = I[24 + 28 - -89 + 0];
      var10000 = I[9 + 66 - 52 + 119];
      var10001 = I[83 + 140 - 101 + 21];
      var10002 = I[45 + 0 - -68 + 31];
      var10001 = I[118 + 45 - 107 + 89];
      int var1 = this.readerIndex();
      byte var2 = this.readByte();
      if (var2 == 0) {
         return null;
      } else {
         this.readerIndex(var1);
         I[48 + 105 - 152 + 145].length();
         I[59 + 141 - 185 + 132].length();

         try {
            I[3 + 113 - 76 + 108].length();
            ByteBufInputStream var6 = new ByteBufInputStream(this);
            I[89 + 28 - 21 + 53].length();
            I[14 + 112 - -10 + 14].length();
            return CompressedStreamTools.read(var6, new NBTSizeTracker(2097152L));
         } catch (IOException var4) {
            I[8 + 125 - 21 + 39].length();
            I[20 + 103 - 45 + 74].length();
            I[124 + 51 - 95 + 73].length();
            EncoderException var5 = new EncoderException(var4);
            I[71 + 140 - 135 + 78].length();
            I[45 + 44 - -61 + 5].length();
            I[142 + 80 - 148 + 82].length();
            I[107 + 5 - 28 + 73].length();
            throw var5;
         }
      }
   }

   public ByteBuf retain() {
      return this.buf.retain();
   }

   public PacketBuffer writeByteArray(byte[] var1) {
      this.writeVarIntToBuffer(var1.length);
      I["".length()].length();
      I[" ".length()].length();
      this.writeBytes(var1);
      I["  ".length()].length();
      I["   ".length()].length();
      I[86 ^ 82].length();
      return this;
   }

   public int readInt() {
      return this.buf.readInt();
   }

   public UUID readUuid() {
      String var10000 = I[38 ^ 70];
      String var10001 = I[33 ^ 64];
      String var10002 = I[224 ^ 130];
      var10001 = I[208 ^ 179];
      I[60 ^ 88].length();
      I[106 ^ 15].length();
      return new UUID(this.readLong(), this.readLong());
   }

   public int getBytes(int var1, GatheringByteChannel var2, int var3) throws IOException {
      return this.buf.getBytes(var1, var2, var3);
   }

   public ResourceLocation func_192575_l() {
      String var10000 = I[175 + 204 - 195 + 69];
      String var10001 = I[31 + 164 - 107 + 166];
      String var10002 = I[57 + 153 - 95 + 140];
      var10001 = I[200 + 68 - 63 + 51];
      I[14 + 64 - 61 + 240].length();
      I[130 + 138 - 156 + 146].length();
      return new ResourceLocation(this.readStringFromBuffer(1312 + 21192 - 7247 + 17510));
   }

   public ByteBuf order(ByteOrder var1) {
      return this.buf.order(var1);
   }

   public PacketBuffer writeLongArray(long[] var1) {
      this.writeVarIntToBuffer(var1.length);
      I[181 ^ 132].length();
      I[134 ^ 180].length();
      I[140 ^ 191].length();
      long[] var2 = var1;
      int var3 = var1.length;
      int var4 = "".length();

      do {
         if (var4 >= var3) {
            return this;
         }

         long var5 = var2[var4];
         this.writeLong(var5);
         I[240 ^ 196].length();
         ++var4;
         "".length();
      } while(1 != 2);

      throw null;
   }

   public ByteBuf getBytes(int var1, byte[] var2, int var3, int var4) {
      return this.buf.getBytes(var1, var2, var3, var4);
   }

   public ByteBuf copy(int var1, int var2) {
      return this.buf.copy(var1, var2);
   }

   public int readableBytes() {
      return this.buf.readableBytes();
   }

   public ByteBuf writeIntLE(int var1) {
      return this.buf.writeIntLE(var1);
   }

   public ByteBuf writeZero(int var1) {
      return this.buf.writeZero(var1);
   }

   public ByteOrder order() {
      return this.buf.order();
   }

   public int capacity() {
      return this.buf.capacity();
   }

   public ByteBuf getBytes(int var1, ByteBuf var2, int var3, int var4) {
      return this.buf.getBytes(var1, var2, var3, var4);
   }

   public <T extends Enum<T>> T readEnumValue(Class<T> var1) {
      return ((Enum[])((Enum[])var1.getEnumConstants()))[this.readVarIntFromBuffer()];
   }

   public int compareTo(ByteBuf var1) {
      return this.buf.compareTo(var1);
   }

   public ByteBuf setMediumLE(int var1, int var2) {
      return this.buf.setMediumLE(var1, var2);
   }

   public int refCnt() {
      return this.buf.refCnt();
   }

   public long getUnsignedInt(int var1) {
      return this.buf.getUnsignedInt(var1);
   }

   public ByteBuf markReaderIndex() {
      return this.buf.markReaderIndex();
   }

   public PacketBuffer writeTextComponent(ITextComponent var1) {
      return this.writeString(ITextComponent.Serializer.componentToJson(var1));
   }

   public int getUnsignedShortLE(int var1) {
      return this.buf.getUnsignedShortLE(var1);
   }

   public ByteBuffer nioBuffer(int var1, int var2) {
      return this.buf.nioBuffer(var1, var2);
   }

   public ByteBuf readBytes(ByteBuffer var1) {
      return this.buf.readBytes(var1);
   }

   public ByteBuf getBytes(int var1, ByteBuffer var2) {
      return this.buf.getBytes(var1, var2);
   }

   public ByteBuf getBytes(int var1, OutputStream var2, int var3) throws IOException {
      return this.buf.getBytes(var1, var2, var3);
   }

   public ByteBuf setMedium(int var1, int var2) {
      return this.buf.setMedium(var1, var2);
   }

   public int readUnsignedShort() {
      return this.buf.readUnsignedShort();
   }

   public ByteBuf touch(Object var1) {
      return this.buf.touch(var1);
   }

   public CharSequence getCharSequence(int var1, int var2, Charset var3) {
      return this.buf.getCharSequence(var1, var2, var3);
   }

   public PacketBuffer writeBlockPos(BlockPos var1) {
      this.writeLong(var1.toLong());
      I[223 ^ 152].length();
      I[37 ^ 109].length();
      I[84 ^ 29].length();
      return this;
   }

   public ByteBuf writeByte(int var1) {
      return this.buf.writeByte(var1);
   }

   public ByteBuffer nioBuffer() {
      return this.buf.nioBuffer();
   }

   public int indexOf(int var1, int var2, byte var3) {
      return this.buf.indexOf(var1, var2, var3);
   }

   public int readBytes(FileChannel var1, long var2, int var4) throws IOException {
      return this.buf.readBytes(var1, var2, var4);
   }

   public ByteBuf setShortLE(int var1, int var2) {
      return this.buf.setShortLE(var1, var2);
   }

   public ByteBuf readBytes(ByteBuf var1, int var2, int var3) {
      return this.buf.readBytes(var1, var2, var3);
   }

   public ByteBuffer[] nioBuffers() {
      return this.buf.nioBuffers();
   }

   public PacketBuffer writeNBTTagCompoundToBuffer(@Nullable NBTTagCompound var1) {
      String var10000 = I[205 ^ 163];
      String var10001 = I[31 ^ 112];
      String var10002 = I[255 ^ 143];
      var10001 = I[84 ^ 37];
      var10000 = I[65 ^ 51];
      var10001 = I[244 ^ 135];
      var10002 = I[8 ^ 124];
      var10001 = I[255 ^ 138];
      if (var1 == null) {
         this.writeByte("".length());
         I[251 ^ 141].length();
         I[44 ^ 91].length();
         I[93 ^ 37].length();
         I[103 ^ 30].length();
         "".length();
         if (2 <= 0) {
            throw null;
         }
      } else {
         try {
            I[19 ^ 105].length();
            I[251 ^ 128].length();
            I[195 ^ 191].length();
            I[62 ^ 67].length();
            CompressedStreamTools.write(var1, (DataOutput)(new ByteBufOutputStream(this)));
         } catch (IOException var3) {
            I[254 ^ 128].length();
            I[16 + 35 - 14 + 90].length();
            I[121 + 5 - 41 + 43].length();
            I[58 + 3 - 49 + 117].length();
            EncoderException var4 = new EncoderException(var3);
            I[78 + 0 - 18 + 70].length();
            I[5 + 35 - -65 + 26].length();
            I[39 + 42 - -33 + 18].length();
            I[94 + 21 - 59 + 77].length();
            throw var4;
         }

         "".length();
         if (4 < 4) {
            throw null;
         }
      }

      return this;
   }

   public String toString(int var1, int var2, Charset var3) {
      return this.buf.toString(var1, var2, var3);
   }

   public PacketBuffer func_192572_a(ResourceLocation var1) {
      this.writeString(var1.toString());
      I[93 + 218 - 59 + 7].length();
      I[30 + 184 - -2 + 44].length();
      I[259 + 26 - 145 + 121].length();
      I[213 + 105 - 291 + 235].length();
      I[56 + 200 - 233 + 240].length();
      return this;
   }

   public int getUnsignedMediumLE(int var1) {
      return this.buf.getUnsignedMediumLE(var1);
   }

   public PacketBuffer writeVarIntToBuffer(int var1) {
      while(true) {
         if ((var1 & -(74 + 86 - 32 + 0)) != 0) {
            this.writeByte(var1 & 40 + 106 - 77 + 58 | 106 + 100 - 172 + 94);
            I[59 ^ 93].length();
            var1 >>>= 75 ^ 76;
            "".length();
            if (3 == 3) {
               continue;
            }

            throw null;
         }

         this.writeByte(var1);
         I[210 ^ 181].length();
         return this;
      }
   }

   public ByteBuf readerIndex(int var1) {
      return this.buf.readerIndex(var1);
   }

   public int arrayOffset() {
      return this.buf.arrayOffset();
   }

   public int nioBufferCount() {
      return this.buf.nioBufferCount();
   }

   public byte[] readByteArray(int var1) {
      String var10000 = I[31 ^ 26];
      String var10001 = I[109 ^ 107];
      String var10002 = I[37 ^ 34];
      var10001 = I[53 ^ 61];
      var10000 = I[164 ^ 173];
      var10001 = I[140 ^ 134];
      var10002 = I[124 ^ 119];
      var10001 = I[156 ^ 144];
      int var2 = this.readVarIntFromBuffer();
      if (var2 > var1) {
         I[133 ^ 136].length();
         I[113 ^ 127].length();
         I[201 ^ 198].length();
         I[60 ^ 44].length();
         DecoderException var4 = new DecoderException(I[117 ^ 100] + var2 + I[83 ^ 65] + var1);
         I[76 ^ 95].length();
         I[85 ^ 65].length();
         I[134 ^ 147].length();
         throw var4;
      } else {
         byte[] var3 = new byte[var2];
         this.readBytes(var3);
         I[132 ^ 146].length();
         I[14 ^ 25].length();
         return var3;
      }
   }

   public ByteBuf setFloat(int var1, float var2) {
      return this.buf.setFloat(var1, var2);
   }

   public ByteBuf setLong(int var1, long var2) {
      return this.buf.setLong(var1, var2);
   }

   public boolean isReadable() {
      return this.buf.isReadable();
   }

   public boolean equals(Object var1) {
      return this.buf.equals(var1);
   }

   public boolean isWritable() {
      return this.buf.isWritable();
   }

   public int forEachByteDesc(ByteProcessor var1) {
      return this.buf.forEachByteDesc(var1);
   }

   public int getIntLE(int var1) {
      return this.buf.getIntLE(var1);
   }

   public int[] readVarIntArray(int var1) {
      String var10000 = I[176 ^ 174];
      String var10001 = I[120 ^ 103];
      String var10002 = I[76 ^ 108];
      var10001 = I[19 ^ 50];
      var10000 = I[28 ^ 62];
      var10001 = I[100 ^ 71];
      var10002 = I[44 ^ 8];
      var10001 = I[165 ^ 128];
      int var2 = this.readVarIntFromBuffer();
      if (var2 > var1) {
         I[60 ^ 26].length();
         I[99 ^ 68].length();
         I[124 ^ 84].length();
         I[139 ^ 162].length();
         I[46 ^ 4].length();
         I[19 ^ 56].length();
         I[108 ^ 64].length();
         DecoderException var5 = new DecoderException(I[25 ^ 52] + var2 + I[120 ^ 86] + var1);
         I[232 ^ 199].length();
         I[101 ^ 85].length();
         throw var5;
      } else {
         int[] var3 = new int[var2];
         int var4 = "".length();

         do {
            if (var4 >= var3.length) {
               return var3;
            }

            var3[var4] = this.readVarIntFromBuffer();
            ++var4;
            "".length();
         } while(3 >= 3);

         throw null;
      }
   }

   public ByteBuf unwrap() {
      return this.buf.unwrap();
   }

   public PacketBuffer writeUuid(UUID var1) {
      this.writeLong(var1.getMostSignificantBits());
      I[77 ^ 16].length();
      this.writeLong(var1.getLeastSignificantBits());
      I[201 ^ 151].length();
      I[11 ^ 84].length();
      return this;
   }

   public int ensureWritable(int var1, boolean var2) {
      return this.buf.ensureWritable(var1, var2);
   }

   public Date func_192573_m() {
      String var10000 = I[181 + 36 - 145 + 192];
      String var10001 = I[186 + 105 - 153 + 127];
      String var10002 = I[28 + 13 - -62 + 163];
      var10001 = I[155 + 226 - 158 + 44];
      I[244 + 112 - 310 + 222].length();
      I[268 + 192 - 424 + 233].length();
      return new Date(this.readLong());
   }

   public int readIntLE() {
      return this.buf.readIntLE();
   }

   public ByteBuf writeLong(long var1) {
      return this.buf.writeLong(var1);
   }

   public ByteBuf writeBytes(byte[] var1) {
      return this.buf.writeBytes(var1);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 2);

      throw null;
   }

   public ByteBuf writeBytes(ByteBuffer var1) {
      return this.buf.writeBytes(var1);
   }

   public boolean release(int var1) {
      return this.buf.release(var1);
   }

   public ByteBuf retainedSlice() {
      return this.buf.retainedSlice();
   }

   public ByteBuf slice() {
      return this.buf.slice();
   }

   public long[] readLongArray(@Nullable long[] var1) {
      return this.readLongArray(var1, this.readableBytes() / (82 ^ 90));
   }

   public ByteBuf setBytes(int var1, byte[] var2, int var3, int var4) {
      return this.buf.setBytes(var1, var2, var3, var4);
   }

   public ByteBuf getBytes(int var1, ByteBuf var2) {
      return this.buf.getBytes(var1, var2);
   }

   public ByteBuf writeMediumLE(int var1) {
      return this.buf.writeMediumLE(var1);
   }

   public ByteBuf writeShortLE(int var1) {
      return this.buf.writeShortLE(var1);
   }

   public ByteBuf setBytes(int var1, ByteBuffer var2) {
      return this.buf.setBytes(var1, var2);
   }

   public ByteBuf setBytes(int var1, byte[] var2) {
      return this.buf.setBytes(var1, var2);
   }

   public short getShortLE(int var1) {
      return this.buf.getShortLE(var1);
   }

   public int bytesBefore(byte var1) {
      return this.buf.bytesBefore(var1);
   }

   public ByteBuf duplicate() {
      return this.buf.duplicate();
   }

   public ByteBuf retainedDuplicate() {
      return this.buf.retainedDuplicate();
   }

   public boolean isWritable(int var1) {
      return this.buf.isWritable(var1);
   }

   public float getFloat(int var1) {
      return this.buf.getFloat(var1);
   }

   public int forEachByte(int var1, int var2, ByteProcessor var3) {
      return this.buf.forEachByte(var1, var2, var3);
   }

   public int getUnsignedMedium(int var1) {
      return this.buf.getUnsignedMedium(var1);
   }

   public ByteBuf setZero(int var1, int var2) {
      return this.buf.setZero(var1, var2);
   }

   public ByteBuf discardSomeReadBytes() {
      return this.buf.discardSomeReadBytes();
   }

   public double getDouble(int var1) {
      return this.buf.getDouble(var1);
   }

   public ByteBuf writeShort(int var1) {
      return this.buf.writeShort(var1);
   }

   public byte[] readByteArray() {
      return this.readByteArray(this.readableBytes());
   }

   public ByteBufAllocator alloc() {
      return this.buf.alloc();
   }

   public long getUnsignedIntLE(int var1) {
      return this.buf.getUnsignedIntLE(var1);
   }

   public ITextComponent readTextComponent() throws IOException {
      return ITextComponent.Serializer.jsonToComponent(this.readStringFromBuffer(32254 + 5543 - 24505 + 19475));
   }

   public int forEachByteDesc(int var1, int var2, ByteProcessor var3) {
      return this.buf.forEachByteDesc(var1, var2, var3);
   }

   public long getLongLE(int var1) {
      return this.buf.getLongLE(var1);
   }

   public ByteBuf writeLongLE(long var1) {
      return this.buf.writeLongLE(var1);
   }

   public long readUnsignedIntLE() {
      return this.buf.readUnsignedIntLE();
   }

   public int readUnsignedShortLE() {
      return this.buf.readUnsignedShortLE();
   }

   public ByteBuf writeFloat(float var1) {
      return this.buf.writeFloat(var1);
   }

   public ByteBuf markWriterIndex() {
      return this.buf.markWriterIndex();
   }

   public ByteBuf readBytes(byte[] var1, int var2, int var3) {
      return this.buf.readBytes(var1, var2, var3);
   }

   public ByteBuf writeBytes(ByteBuf var1) {
      return this.buf.writeBytes(var1);
   }

   public boolean hasArray() {
      return this.buf.hasArray();
   }

   public ByteBuf readBytes(int var1) {
      return this.buf.readBytes(var1);
   }

   public ByteBuf setBytes(int var1, ByteBuf var2, int var3) {
      return this.buf.setBytes(var1, var2, var3);
   }

   public float readFloat() {
      return this.buf.readFloat();
   }

   public int setBytes(int var1, InputStream var2, int var3) throws IOException {
      return this.buf.setBytes(var1, var2, var3);
   }

   public ByteBuf resetWriterIndex() {
      return this.buf.resetWriterIndex();
   }

   public String toString() {
      return this.buf.toString();
   }

   public ByteBuf resetReaderIndex() {
      return this.buf.resetReaderIndex();
   }

   public ByteBuf readSlice(int var1) {
      return this.buf.readSlice(var1);
   }

   public ByteBuffer[] nioBuffers(int var1, int var2) {
      return this.buf.nioBuffers(var1, var2);
   }

   public PacketBuffer writeVarLong(long var1) {
      while(true) {
         if ((var1 & -128L) != 0L) {
            this.writeByte((int)(var1 & 127L) | 60 + 106 - 133 + 95);
            I[67 ^ 43].length();
            I[49 ^ 88].length();
            I[53 ^ 95].length();
            var1 >>>= 199 ^ 192;
            "".length();
            if (3 >= -1) {
               continue;
            }

            throw null;
         }

         this.writeByte((int)var1);
         I[63 ^ 84].length();
         I[110 ^ 2].length();
         I[20 ^ 121].length();
         return this;
      }
   }

   public ByteBuf readBytes(byte[] var1) {
      return this.buf.readBytes(var1);
   }

   public ByteBuf setChar(int var1, int var2) {
      return this.buf.setChar(var1, var2);
   }

   public ByteBuf readBytes(OutputStream var1, int var2) throws IOException {
      return this.buf.readBytes(var1, var2);
   }

   public byte[] array() {
      return this.buf.array();
   }

   public ByteBuf capacity(int var1) {
      return this.buf.capacity(var1);
   }

   public boolean isDirect() {
      return this.buf.isDirect();
   }

   public ByteBuf setBytes(int var1, ByteBuf var2) {
      return this.buf.setBytes(var1, var2);
   }

   public short getShort(int var1) {
      return this.buf.getShort(var1);
   }

   public ByteBuf writeBoolean(boolean var1) {
      return this.buf.writeBoolean(var1);
   }

   public BlockPos readBlockPos() {
      return BlockPos.fromLong(this.readLong());
   }

   public ByteBuf retain(int var1) {
      return this.buf.retain(var1);
   }

   public int readBytes(GatheringByteChannel var1, int var2) throws IOException {
      return this.buf.readBytes(var1, var2);
   }

   public int writerIndex() {
      return this.buf.writerIndex();
   }

   public int readMedium() {
      return this.buf.readMedium();
   }

   public int readerIndex() {
      return this.buf.readerIndex();
   }

   public boolean release() {
      return this.buf.release();
   }

   public int bytesBefore(int var1, int var2, byte var3) {
      return this.buf.bytesBefore(var1, var2, var3);
   }

   public PacketBuffer writeEnumValue(Enum<?> var1) {
      return this.writeVarIntToBuffer(var1.ordinal());
   }

   public ByteBuf writeInt(int var1) {
      return this.buf.writeInt(var1);
   }

   public ByteBuf setShort(int var1, int var2) {
      return this.buf.setShort(var1, var2);
   }

   public PacketBuffer func_192574_a(Date var1) {
      this.writeLong(var1.getTime());
      I[114 + 259 - 222 + 119].length();
      I[124 + 177 - 276 + 246].length();
      I[238 + 38 - 103 + 99].length();
      return this;
   }

   public PacketBuffer writeItemStackToBuffer(ItemStack var1) {
      if (var1.isEmpty()) {
         this.writeShort(-" ".length());
         I[155 + 132 - 234 + 105].length();
         I[136 + 115 - 182 + 90].length();
         I[15 + 13 - 12 + 144].length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      } else {
         this.writeShort(Item.getIdFromItem(var1.getItem()));
         I[143 + 108 - 207 + 117].length();
         I[138 + 122 - 176 + 78].length();
         this.writeByte(var1.func_190916_E());
         I[81 + 131 - 156 + 107].length();
         this.writeShort(var1.getMetadata());
         I[97 + 128 - 94 + 33].length();
         I[85 + 91 - 140 + 129].length();
         I[137 + 128 - 182 + 83].length();
         I[93 + 138 - 147 + 83].length();
         I[152 + 50 - 177 + 143].length();
         NBTTagCompound var2 = null;
         if (var1.getItem().isDamageable() || var1.getItem().getShareTag()) {
            var2 = var1.getTagCompound();
         }

         this.writeNBTTagCompoundToBuffer(var2);
         I[53 + 41 - 93 + 168].length();
         I[154 + 5 - 35 + 46].length();
         I[169 + 36 - 96 + 62].length();
      }

      return this;
   }

   public ByteBuf setIntLE(int var1, int var2) {
      return this.buf.setIntLE(var1, var2);
   }

   public PacketBuffer writeVarIntArray(int[] var1) {
      this.writeVarIntToBuffer(var1.length);
      I[29 ^ 5].length();
      I[25 ^ 0].length();
      I[120 ^ 98].length();
      int[] var2 = var1;
      int var3 = var1.length;
      int var4 = "".length();

      do {
         if (var4 >= var3) {
            return this;
         }

         int var5 = var2[var4];
         this.writeVarIntToBuffer(var5);
         I[92 ^ 71].length();
         I[217 ^ 197].length();
         I[177 ^ 172].length();
         ++var4;
         "".length();
      } while(2 > 1);

      throw null;
   }

   public int readUnsignedMediumLE() {
      return this.buf.readUnsignedMediumLE();
   }

   public int readVarIntFromBuffer() {
      String var10000 = I[47 ^ 101];
      String var10001 = I[60 ^ 119];
      String var10002 = I[143 ^ 195];
      var10001 = I[37 ^ 104];
      int var1 = "".length();
      int var2 = "".length();

      do {
         byte var3 = this.readByte();
         var1 |= (var3 & 123 + 89 - 98 + 13) << var2++ * (108 ^ 107);
         if (var2 > (197 ^ 192)) {
            I[67 ^ 13].length();
            I[66 ^ 13].length();
            RuntimeException var4 = new RuntimeException(I[251 ^ 171]);
            I[222 ^ 143].length();
            throw var4;
         }

         if ((var3 & 54 + 111 - 119 + 82) != 53 + 90 - 72 + 57) {
            "".length();
            if (-1 != -1) {
               throw null;
            }

            return var1;
         }

         "".length();
      } while(3 != 0);

      throw null;
   }

   public ByteBuf setIndex(int var1, int var2) {
      return this.buf.setIndex(var1, var2);
   }

   private static void I() {
      I = new String[17 + 56 - -52 + 148];
      I["".length()] = I("扌渨揈", "KHlCf");
      I[" ".length()] = I("灇撎桺", "JmyTV");
      I["  ".length()] = I("寮榚", "DpAMa");
      I["   ".length()] = I("徆帓桯唏偂", "vMHqI");
      I[171 ^ 175] = I("堕兽徔堞娱", "ScBIX");
      I[51 ^ 54] = I("婶伐", "dAdIp");
      I[115 ^ 117] = I("戎殟", "fpsFf");
      I[52 ^ 51] = I("喔垖", "PWVaz");
      I[109 ^ 101] = I("榺櫒", "fpfSq");
      I[68 ^ 77] = I("檫彍", "QHEYu");
      I[118 ^ 124] = I("婜枙", "Qunec");
      I[147 ^ 152] = I("漒愪", "UyaNH");
      I[8 ^ 4] = I("後崣", "wrJpW");
      I[70 ^ 75] = I("夸", "auBqB");
      I[146 ^ 156] = I("敀", "pXXsv");
      I[40 ^ 39] = I("傏", "CLwIc");
      I[120 ^ 104] = I("廻", "JKLPQ");
      I[136 ^ 153] = I("\u0014\u001f=4\u0004$\u0014((e!\u000f=9e%\u000f34e", "VfIQE");
      I[22 ^ 4] = I("Q:>Z\u0012\u00184*\u001f\u0002Q'%\u001b\u001eQ2!\u0016\u001f\u00066)Z", "qSMzp");
      I[36 ^ 55] = I("庒勲撢圝", "eoxAq");
      I[170 ^ 190] = I("拭灬槼幥儢", "ZMChv");
      I[59 ^ 46] = I("懡未", "rgMYM");
      I[91 ^ 77] = I("帗", "rjUOF");
      I[74 ^ 93] = I("岁", "spAvV");
      I[32 ^ 56] = I("宺", "kYBpl");
      I[27 ^ 2] = I("櫫劰奥", "xmcJL");
      I[3 ^ 25] = I("煎敳", "Ckmea");
      I[21 ^ 14] = I("姇儬巣嫨", "FVNbm");
      I[9 ^ 21] = I("撴撠恂冻挞", "nsDat");
      I[73 ^ 84] = I("功瀆", "nhczh");
      I[3 ^ 29] = I("漶濤", "AWbOv");
      I[75 ^ 84] = I("漒嗯", "KAEEw");
      I[96 ^ 64] = I("墯嫓", "CMoUN");
      I[34 ^ 3] = I("灌棪", "TAkPr");
      I[22 ^ 52] = I("帣怡", "SSqFJ");
      I[143 ^ 172] = I("塂槨", "YfkCp");
      I[79 ^ 107] = I("思嶽", "QvQzZ");
      I[44 ^ 9] = I("付沦", "tRbcG");
      I[143 ^ 169] = I("潲", "cVuTm");
      I[124 ^ 91] = I("梆擠漋", "uWPsZ");
      I[97 ^ 73] = I("棇煞太", "BcORA");
      I[2 ^ 43] = I("寬廑懱嘿", "ZsZba");
      I[178 ^ 152] = I("捸揔", "KJeml");
      I[26 ^ 49] = I("煓氏", "JuWxY");
      I[33 ^ 13] = I("挦泒徼侴撓", "dmGrv");
      I[56 ^ 21] = I("\u00188=():\u0018=\u0013&7y8\b3&y<\b=+y", "NYOaG");
      I[164 ^ 138] = I("N\n9v\b\u0007\u0004-3\u0018N\u0017\"7\u0004N\u0002&:\u0005\u0019\u0006.v", "ncJVj");
      I[161 ^ 142] = I("搶楉烣払奵", "exdlF");
      I[114 ^ 66] = I("欵幺", "AcfVI");
      I[139 ^ 186] = I("嘚授傒泼倘", "aPvNo");
      I[174 ^ 156] = I("怸攏", "wLvEY");
      I[138 ^ 185] = I("暛", "PbFaz");
      I[99 ^ 87] = I("仐漦宗控", "vsEtJ");
      I[60 ^ 9] = I("栝檹", "GhTlS");
      I[21 ^ 35] = I("淏侍", "WpQHa");
      I[88 ^ 111] = I("侘榠", "luXJd");
      I[102 ^ 94] = I("浊島", "DgJOm");
      I[141 ^ 180] = I("櫘殍", "QcAOk");
      I[68 ^ 126] = I("曎拖", "HbzhA");
      I[187 ^ 128] = I("傇橿", "lRKIm");
      I[38 ^ 26] = I("咆彇", "AKicR");
      I[79 ^ 114] = I("榙嘋悅", "XzFIl");
      I[113 ^ 79] = I("攉拃媗泤弞", "DnnRm");
      I[2 ^ 61] = I("攪掍", "Dmaiy");
      I[99 ^ 35] = I("悱", "pFpsl");
      I[13 ^ 76] = I("堅悈商", "lKzep");
      I[21 ^ 87] = I("汽弚朠六", "PIDzq");
      I[21 ^ 86] = I("-\u0015\u0018\r\f\u0013\b\u0017\u0013m\u0016\u0013\u0002\u0002m\u0012\u0013\f\u000fm", "azvjM");
      I[60 ^ 120] = I("B$8w%\u000b*,25B9#6)B,';(\u0015(/w", "bMKWG");
      I[248 ^ 189] = I("捊侧", "nOIIW");
      I[211 ^ 149] = I("欆宴檥不", "ptIQD");
      I[103 ^ 32] = I("柖摛椧宨溚", "uNsGH");
      I[71 ^ 15] = I("抅抍澪", "EUYxt");
      I[139 ^ 194] = I("挨抁柒嵈", "jpjnP");
      I[113 ^ 59] = I("榚潧", "YrpEB");
      I[200 ^ 131] = I("刡巔", "lAosl");
      I[127 ^ 51] = I("嘚殄", "TgxeH");
      I[141 ^ 192] = I("堼岢", "fIPbi");
      I[192 ^ 142] = I("剌朣墇弥佳", "FObPy");
      I[5 ^ 74] = I("兽孱儕", "FFgwU");
      I[219 ^ 139] = I("\u00044%0\t&u#\u0016\br7>\u001e", "RUWyg");
      I[196 ^ 149] = I("啶", "CAAIy");
      I[93 ^ 15] = I("抡恧", "iwTsv");
      I[79 ^ 28] = I("欝櫔", "TdoJp");
      I[15 ^ 91] = I("孋戧", "vbyXi");
      I[98 ^ 55] = I("汶斿", "FkHhg");
      I[149 ^ 195] = I("儳容墜洖", "ishGL");
      I[248 ^ 175] = I("叟", "tHEAv");
      I[233 ^ 177] = I("昭帖漀徧愕", "nRWzY");
      I[56 ^ 97] = I("\u00116\b67)0Z\u000e7(w\u0018\u0013?", "GWzzX");
      I[97 ^ 59] = I("呎挅", "fBqHm");
      I[255 ^ 164] = I("幢泖刀剃", "SmiXU");
      I[11 ^ 87] = I("榨唿摅捯帉", "QhffG");
      I[41 ^ 116] = I("歒婃榕呛两", "ICLOD");
      I[247 ^ 169] = I("楿宮搟擲", "NrlKO");
      I[250 ^ 165] = I("岰冝", "PKGjP");
      I[80 ^ 48] = I("暩怎", "UBUjW");
      I[51 ^ 82] = I("沯律", "XIHbT");
      I[10 ^ 104] = I("巷烐", "McnpU");
      I[120 ^ 27] = I("晄凛", "KhuOG");
      I[36 ^ 64] = I("塟", "tPRLx");
      I[27 ^ 126] = I("惺", "kUoBY");
      I[232 ^ 142] = I("殊佘滻叹嫝", "pJxVN");
      I[67 ^ 36] = I("劋旄涺寻", "LVVsn");
      I[100 ^ 12] = I("慤", "owJrg");
      I[62 ^ 87] = I("梗", "OkcNm");
      I[11 ^ 97] = I("儝嘼", "dMwge");
      I[241 ^ 154] = I("沐捄例厑", "kkAdG");
      I[47 ^ 67] = I("夀橪檂", "CocIS");
      I[39 ^ 74] = I("婺沄", "YycSi");
      I[29 ^ 115] = I("仩摷", "rlSsH");
      I[232 ^ 135] = I("浍拵", "dBbHl");
      I[88 ^ 40] = I("戥泪", "TxBKA");
      I[110 ^ 31] = I("漒晷", "fMwux");
      I[193 ^ 179] = I("挘墏", "hQnCl");
      I[207 ^ 188] = I("僡廔", "kfOPA");
      I[177 ^ 197] = I("凼咾", "xzIZk");
      I[105 ^ 28] = I("悅楄", "kmdEj");
      I[31 ^ 105] = I("怞奈憍", "miblI");
      I[230 ^ 145] = I("幹壴昪捙", "ToKqV");
      I[13 ^ 117] = I("廢墓悴", "mcwXW");
      I[247 ^ 142] = I("墁渖泮堇炓", "mnSvO");
      I[44 ^ 86] = I("埤壨慼挏媉", "HBmGs");
      I[52 ^ 79] = I("偲妋慈", "UXbqg");
      I[50 ^ 78] = I("朘炽寫棲", "fgBls");
      I[122 ^ 7] = I("剠", "Kchze");
      I[104 ^ 22] = I("摼", "oydZu");
      I[25 + 10 - -75 + 17] = I("埡", "fmhjV");
      I[95 + 95 - 73 + 11] = I("戊幂幗圫洩", "nUEAy");
      I[120 + 128 - 184 + 65] = I("揫泊", "YSBXK");
      I[72 + 39 - 84 + 103] = I("嚵曯寊孻", "ymxRb");
      I[42 + 78 - 92 + 103] = I("毕乓傄吱偿", "gcAWm");
      I[5 + 10 - -113 + 4] = I("嚛榤撗橫勲", "bcbMH");
      I[34 + 14 - 16 + 101] = I("戫徽汅搽", "zGonN");
      I[45 + 68 - 69 + 90] = I("崪憁", "Qtatx");
      I[112 + 20 - 95 + 98] = I("媉溡", "oPWqE");
      I[113 + 52 - 98 + 69] = I("塧弬", "UMkXr");
      I[78 + 30 - 41 + 70] = I("捆斄", "iUbMV");
      I[14 + 34 - -72 + 18] = I("操掩", "mbTai");
      I[53 + 115 - 129 + 100] = I("尚杺", "hDDOq");
      I[16 + 87 - 29 + 66] = I("巌囊", "CzmGR");
      I[81 + 89 - 133 + 104] = I("撈啨", "VtfLC");
      I[89 + 8 - 56 + 101] = I("懻煇", "JBVeT");
      I[113 + 77 - 79 + 32] = I("勣嫓", "CbSkU");
      I[90 + 23 - 100 + 131] = I("仔卩", "bocIU");
      I[71 + 107 - 81 + 48] = I("瀗棺", "CqLGc");
      I[131 + 37 - 124 + 102] = I("兩摓円原", "soxcq");
      I[124 + 21 - 125 + 127] = I("僇夷", "BwrJX");
      I[30 + 109 - 102 + 111] = I("枣僄機", "RWXtO");
      I[61 + 103 - 112 + 97] = I("炯", "kmciD");
      I[128 + 93 - 171 + 100] = I("烷橲屽板擼", "EBHXs");
      I[119 + 120 - 235 + 147] = I("昗弑", "cgKCC");
      I[51 + 20 - 23 + 104] = I("啀淺溞炌", "Yaazi");
      I[61 + 81 - 109 + 120] = I("吊浙", "yPJKb");
      I[16 + 118 - 35 + 55] = I("澶", "uJJMa");
      I[90 + 30 - -30 + 5] = I("峤帡灡", "rFhqB");
      I[143 + 106 - 186 + 93] = I("愘櫿坸楂", "RQQJl");
      I[43 + 38 - 12 + 88] = I("幒奯", "yuwhE");
      I[84 + 67 - 65 + 72] = I("吣傾圱", "aMcTu");
      I[79 + 6 - 1 + 75] = I("敡", "fryua");
      I[31 + 14 - -88 + 27] = I("嵱嬲樲", "UHWAP");
      I[25 + 119 - 91 + 108] = I("廦暨替", "awnMZ");
      I[5 + 87 - -42 + 28] = I("巣", "cNLNv");
      I[134 + 54 - 184 + 159] = I("暊伞剽", "NwONt");
      I[40 + 89 - 121 + 156] = I("儻淙夛", "mCTnn");
      I[111 + 149 - 140 + 45] = I("斯搵恇壑", "EVIqR");
      I[45 + 97 - 87 + 111] = I("唆圲札", "mlKoe");
      I[154 + 45 - 111 + 79] = I("欦涭懿冝", "ejmdO");
      I[153 + 110 - 179 + 84] = I("汎圖炳", "otqYM");
      I[12 + 13 - 19 + 163] = I("宦慞杂尸", "OlfVK");
      I[135 + 20 - 15 + 30] = I("儋征丗欢嶰", "XJWew");
      I[144 + 115 - 172 + 84] = I("允", "CNvYl");
      I[143 + 20 - 56 + 65] = I("捄塡", "qdDZb");
      I[63 + 120 - 159 + 149] = I("榼夒", "dGFyC");
      I[14 + 93 - -61 + 6] = I("懣攍", "wqggV");
      I[151 + 170 - 313 + 167] = I("修嶼", "xITzd");
      I[23 + 123 - 121 + 151] = I("吀墺", "YjqYU");
      I[108 + 14 - -43 + 12] = I("剈樽煰", "KCuZQ");
      I[111 + 160 - 194 + 101] = I("济淿", "doUoK");
      I[29 + 13 - -12 + 125] = I("吲幮", "acPie");
      I[167 + 23 - 92 + 82] = I("潨洆", "GcNRF");
      I[51 + 132 - 78 + 76] = I("抈桒", "DBtDE");
      I[34 + 140 - 1 + 9] = I("崎枦", "cfAdc");
      I[142 + 162 - 163 + 42] = I("擈搰", "oBIUi");
      I[80 + 0 - 9 + 113] = I("刏樼", "IzJnW");
      I[126 + 63 - 83 + 79] = I("流杗", "MiIJt");
      I[118 + 185 - 131 + 14] = I("懝偧", "CRhep");
      I[180 + 173 - 221 + 55] = I("忁汚", "PbKGM");
      I[42 + 79 - -12 + 55] = I("崞汝", "ShkHq");
      I[65 + 154 - 34 + 4] = I("垷卽", "vrnqD");
      I[28 + 98 - 50 + 114] = I("悘憛", "ayZig");
      I[107 + 144 - 135 + 75] = I("情梬", "CejgM");
      I[181 + 27 - 103 + 87] = I("圐尀", "pJpqq");
      I[42 + 135 - 64 + 80] = I("潇汛", "vnudI");
      I[40 + 147 - 57 + 64] = I("搥昸", "EiQWk");
      I[1 + 51 - -72 + 71] = I("晸梘", "jqSEW");
      I[176 + 180 - 324 + 164] = I("堽樍", "ISpyS");
      I[145 + 179 - 176 + 49] = I("废晵", "kBzCf");
      I[73 + 11 - -97 + 17] = I("滵塵娞仩", "LpVbZ");
      I[118 + 123 - 239 + 197] = I("樦淲煢垺", "wpuPs");
      I[42 + 168 - 14 + 4] = I("溢厫厪", "oKjiY");
      I[35 + 165 - 91 + 92] = I("僸", "bnurh");
      I[84 + 39 - 78 + 157] = I("\u001c\f\tp7-\u0007\t93-\u0000L5++\u000b\b5!h\u0017\u0018\",&\u0003L20.\u0002\t\"e$\u0001\u000271 D\u0005#e$\u000b\u00027 :D\u00188$&D\u00011=!\t\u0019=e)\b\u0000?2-\u0000Lx", "HdlPE");
      I[16 + 152 - 2 + 37] = I("wMJ", "WsjCw");
      I[102 + 108 - 134 + 128] = I("Z", "siLLV");
      I[164 + 2 - 57 + 96] = I("岵啿妅嬃弤", "YJIuh");
      I[133 + 57 - 11 + 27] = I("延", "OYsLy");
      I[1 + 97 - 22 + 131] = I("悧桚", "mYUWE");
      I[92 + 11 - -14 + 91] = I("湫僭椗", "OYgDD");
      I[49 + 58 - -14 + 88] = I("\u0012\u001b\u0003s&#\u0010\u0003:\"#\u0017F6:%\u001c\u000260f\u0000\u0012!=(\u0014F1! \u0015\u0003!t*\u0016\b4 .S\u000f t*\u0016\u0015 t2\u001b\u0007=t<\u0016\u0014<uf$\u0003:&\"S\u0015'&/\u001d\u0001r", "FsfST");
      I[40 + 19 - -14 + 137] = I("凖仔吅捇崜", "mizLh");
      I[101 + 103 - 143 + 150] = I("攒咽峂", "zIrYe");
      I[158 + 207 - 348 + 195] = I("棎淹捶唔浉", "KnEbQ");
      I[67 + 26 - -60 + 60] = I("嵪斡", "sXEzh");
      I[117 + 8 - 7 + 96] = I("噫偨峰伥产", "QCrpX");
      I[99 + 120 - 88 + 84] = I("尦忾", "CtkEE");
      I[154 + 172 - 269 + 159] = I("啞", "mtoNv");
      I[148 + 63 - 133 + 139] = I("柢巠勯倽", "dofDt");
      I[180 + 127 - 277 + 188] = I("抋屉刧偦", "zGHIj");
      I[83 + 180 - 173 + 129] = I("均", "UdsIk");
      I[127 + 200 - 145 + 38] = I("=\u0002#B\u0002\f\t#\u000b\u0006\f\u000ef\u0011\u0004\u001b\u0003(\u0005P\u0005\u000f(\u0005\u0004\u0001J/\u0011P\u0005\u0005(\u0005\u0015\u001bJ2\n\u0011\u0007J+\u0003\b\u0000\u00073\u000fP\b\u0006*\r\u0007\f\u000efJ", "ijFbp");
      I[68 + 39 - 69 + 183] = I("LUO", "lkojM");
      I[55 + 25 - -117 + 25] = I("`", "IqFZu");
      I[66 + 132 - 20 + 45] = I("橬栶", "lNKhW");
      I[111 + 137 - 89 + 65] = I("涷俥惐嫞刑", "imXAH");
      I[18 + 108 - -86 + 13] = I("愾戃", "AevbI");
      I[121 + 68 - 166 + 203] = I("歂柑", "bwfom");
      I[9 + 137 - 22 + 103] = I("吗圄", "XdvjC");
      I[165 + 171 - 110 + 2] = I("栟挸", "mYBrG");
      I[83 + 22 - -46 + 78] = I("戈倀", "CmiDh");
      I[185 + 62 - 197 + 180] = I("剂傇", "rVwBS");
      I[125 + 170 - 149 + 85] = I("塊勆", "ftGaI");
      I[22 + 16 - -194 + 0] = I("煲嫞", "BziCz");
      I[64 + 81 - -74 + 14] = I("栆兖", "NDTDc");
      I[191 + 155 - 331 + 219] = I("派憟", "nnIGj");
      I[190 + 124 - 112 + 33] = I("栤傛問", "lrwZf");
      I[84 + 214 - 273 + 211] = I("偧叐刯", "vCTuC");
      I[207 + 121 - 188 + 97] = I("吀傎曆乂", "CVEhA");
      I[6 + 102 - 18 + 148] = I("壘", "RUQKO");
      I[57 + 214 - 51 + 19] = I("0\u001e%.\u001b\u0004J#(\u001aC\b> UK\u001d64U", "cjWGu");
      I[147 + 162 - 190 + 121] = I("s\u0004*>= F6$;<\u00026.ts\u000b22x", "SfSJX");
      I[10 + 160 - 25 + 96] = I("o", "Fcchw");
      I[172 + 218 - 242 + 94] = I("倲幢攓溹", "jhPMs");
      I[223 + 33 - 133 + 120] = I("檾愂", "QESUL");
      I[163 + 15 - 93 + 159] = I("彬搊划", "fZjqU");
      I[59 + 63 - 48 + 171] = I("徝唤泗嚻", "QTcmg");
      I[111 + 223 - 278 + 190] = I("咖", "xcrOm");
      I[0 + 243 - 196 + 200] = I("毝孤", "aJZOS");
      I[119 + 107 - -14 + 8] = I("泰氫湩", "LuAYp");
      I[210 + 5 - 103 + 137] = I("棍娌坎径捖", "xCPpt");
      I[221 + 69 - 44 + 4] = I("彺氶淳徯", "rzQVi");
      I[138 + 73 - 98 + 138] = I("夣徴", "ysmNC");
      I[234 + 179 - 232 + 71] = I("档尠溣吲澢", "QRodx");
      I[91 + 89 - -65 + 8] = I("僗忚", "hkPYG");
      I[8 + 91 - 58 + 213] = I("埀坈", "pRfxw");
      I[5 + 79 - 2 + 173] = I("揑僒", "zRUeb");
      I[170 + 181 - 149 + 54] = I("攩埙", "KGauq");
      I[139 + 168 - 279 + 229] = I("漆夨恠偩擎", "woMtv");
      I[78 + 227 - 144 + 97] = I("慖擥叉哪", "wMJee");
      I[26 + 27 - -170 + 36] = I("僒劂橮坫栋", "GBlhs");
      I[223 + 45 - 208 + 200] = I("圜婴漳柫", "YQkAq");
      I[99 + 202 - 264 + 224] = I("摶", "yfMtp");
      I[169 + 32 - 116 + 177] = I("慹伐但呞", "jBCyY");
      I[33 + 112 - 124 + 242] = I("仿檻掚啟佟", "KfyBl");
      I[242 + 81 - 256 + 197] = I("奾栗", "nkkcq");
      I[1 + 23 - -167 + 74] = I("客呼", "EPODR");
      I[189 + 122 - 150 + 105] = I("浵摿", "jdfLf");
      I[82 + 230 - 247 + 202] = I("媿梞", "vTwFN");
      I[10 + 215 - 159 + 202] = I("怋焨揪", "CopYn");
      I[205 + 48 - 120 + 136] = I("屨欷昜忋", "ErMmn");
      I[144 + 255 - 214 + 85] = I("抽淽侖婠", "okNdt");
      I[3 + 221 - 95 + 142] = I("檁息斌奴惂", "fZhYJ");
      I[186 + 190 - 263 + 159] = I("拮乏崪", "XyXZm");
   }

   public ByteBuf discardReadBytes() {
      return this.buf.discardReadBytes();
   }

   public String toString(Charset var1) {
      return this.buf.toString(var1);
   }

   public ByteBuf setByte(int var1, int var2) {
      return this.buf.setByte(var1, var2);
   }

   public static int getVarIntSize(int var0) {
      int var1 = " ".length();

      do {
         if (var1 >= (82 ^ 87)) {
            return 140 ^ 137;
         }

         if ((var0 & -" ".length() << var1 * (114 ^ 117)) == 0) {
            return var1;
         }

         ++var1;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public int[] readVarIntArray() {
      return this.readVarIntArray(this.readableBytes());
   }

   public ByteBuf clear() {
      return this.buf.clear();
   }

   public int setCharSequence(int var1, CharSequence var2, Charset var3) {
      return this.buf.setCharSequence(var1, var2, var3);
   }

   public double readDouble() {
      return this.buf.readDouble();
   }

   public ByteBuf readBytes(ByteBuf var1) {
      return this.buf.readBytes(var1);
   }

   public int maxCapacity() {
      return this.buf.maxCapacity();
   }

   public boolean getBoolean(int var1) {
      return this.buf.getBoolean(var1);
   }

   public int getMedium(int var1) {
      return this.buf.getMedium(var1);
   }

   public ByteBuf getBytes(int var1, ByteBuf var2, int var3) {
      return this.buf.getBytes(var1, var2, var3);
   }

   public ByteBuf getBytes(int var1, byte[] var2) {
      return this.buf.getBytes(var1, var2);
   }

   public ByteBuffer internalNioBuffer(int var1, int var2) {
      return this.buf.internalNioBuffer(var1, var2);
   }

   public int setBytes(int var1, FileChannel var2, long var3, int var5) throws IOException {
      return this.buf.setBytes(var1, var2, var3, var5);
   }

   public int writeBytes(InputStream var1, int var2) throws IOException {
      return this.buf.writeBytes(var1, var2);
   }

   public long getLong(int var1) {
      return this.buf.getLong(var1);
   }

   public short readShortLE() {
      return this.buf.readShortLE();
   }

   public ByteBuf setDouble(int var1, double var2) {
      return this.buf.setDouble(var1, var2);
   }

   public ByteBuf retainedSlice(int var1, int var2) {
      return this.buf.retainedSlice(var1, var2);
   }

   public char readChar() {
      return this.buf.readChar();
   }

   public short getUnsignedByte(int var1) {
      return this.buf.getUnsignedByte(var1);
   }
}

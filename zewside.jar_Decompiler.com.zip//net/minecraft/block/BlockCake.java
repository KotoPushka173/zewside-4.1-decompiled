package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockCake extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyInteger BITES;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] CAKE_AABB;

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.field_190931_a;
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(BITES);
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(BITES, var1);
   }

   public int quantityDropped(Random var1) {
      return "".length();
   }

   protected BlockCake() {
      super(Material.CAKE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(BITES, "".length()));
      this.setTickRandomly((boolean)" ".length());
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return CAKE_AABB[(Integer)var1.getValue(BITES)];
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 1);

      throw null;
   }

   static {
      I();
      BITES = PropertyInteger.create(I[14 ^ 42], "".length(), 127 ^ 121);
      AxisAlignedBB[] var10000 = new AxisAlignedBB[127 ^ 120];
      var10000["".length()] = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D);
      var10000[" ".length()] = new AxisAlignedBB(0.1875D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D);
      var10000["  ".length()] = new AxisAlignedBB(0.3125D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D);
      var10000["   ".length()] = new AxisAlignedBB(0.4375D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D);
      var10000[71 ^ 67] = new AxisAlignedBB(0.5625D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D);
      var10000[166 ^ 163] = new AxisAlignedBB(0.6875D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D);
      var10000[183 ^ 177] = new AxisAlignedBB(0.8125D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D);
      CAKE_AABB = var10000;
   }

   private static void I() {
      I = new String[180 ^ 145];
      I["".length()] = I("澅忋", "FXGhT");
      I[" ".length()] = I("匥", "ktBzu");
      I["  ".length()] = I("丂炄忨憭灠", "FmlDX");
      I["   ".length()] = I("云徒", "QZONb");
      I[97 ^ 101] = I("嵑挔", "fGQWb");
      I[192 ^ 197] = I("棉丮灩愐潙", "mLnSu");
      I[62 ^ 56] = I("毟峬忀嫓", "DJVun");
      I[95 ^ 88] = I("氭", "ozini");
      I[187 ^ 179] = I("少", "DdmIQ");
      I[184 ^ 177] = I("妸懜儣往", "MhHEj");
      I[109 ^ 103] = I("剰", "XlXgq");
      I[168 ^ 163] = I("嫃", "XVows");
      I[62 ^ 50] = I("戲楓", "LKsFl");
      I[73 ^ 68] = I("末偵", "jTZkM");
      I[159 ^ 145] = I("朋擖", "ktvjY");
      I[163 ^ 172] = I("敿堘", "wdFCx");
      I[184 ^ 168] = I("奿圕寧嚋", "NhfKv");
      I[119 ^ 102] = I("宾呡", "yyhlH");
      I[215 ^ 197] = I("揗淦", "YqGsK");
      I[174 ^ 189] = I("凓更", "bUCsP");
      I[209 ^ 197] = I("懨暊", "sQzyY");
      I[69 ^ 80] = I("崠潕", "VWMhp");
      I[35 ^ 53] = I("偵护", "HPfLN");
      I[146 ^ 133] = I("怆涋", "KjeFn");
      I[17 ^ 9] = I("墂抉", "QcSYV");
      I[36 ^ 61] = I("勔徘", "hmVjM");
      I[145 ^ 139] = I("啎仑", "QLekU");
      I[155 ^ 128] = I("晛峛啩浔", "ueeiW");
      I[132 ^ 152] = I("埁偹", "RKzbn");
      I[154 ^ 135] = I("滖懍泻", "ORTDG");
      I[33 ^ 63] = I("朘渜宣", "JRlvQ");
      I[162 ^ 189] = I("扢曪冶帷", "TmnTd");
      I[68 ^ 100] = I("坬挐哲洛", "hpRVy");
      I[35 ^ 2] = I("嚩戲", "ygIBn");
      I[181 ^ 151] = I("嶸", "eHvne");
      I[170 ^ 137] = I("朲儦", "cVWKT");
      I[51 ^ 23] = I("/\u0006\u0019\u0016\u001e", "Momsm");
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      int var10000 = 176 ^ 183;
      int var10001 = (Integer)var1.getValue(BITES);
      I[67 ^ 99].length();
      I[43 ^ 10].length();
      I[170 ^ 136].length();
      I[55 ^ 20].length();
      return (var10000 - var10001) * "  ".length();
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!this.canBlockStay(var2, var3)) {
         var2.setBlockToAir(var3);
         I[73 ^ 78].length();
         I[20 ^ 28].length();
         I[174 ^ 167].length();
         I[145 ^ 155].length();
         I[14 ^ 5].length();
      }

   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (!var1.isRemote) {
         return this.eatCake(var1, var2, var3, var4);
      } else {
         ItemStack var10 = var4.getHeldItem(var5);
         int var10000;
         if (!this.eatCake(var1, var2, var3, var4) && !var10.isEmpty()) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (4 <= 0) {
               throw null;
            }
         }

         return (boolean)var10000;
      }
   }

   private boolean eatCake(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4) {
      if (!var4.canEat((boolean)"".length())) {
         return (boolean)"".length();
      } else {
         var4.addStat(StatList.CAKE_SLICES_EATEN);
         var4.getFoodStats().addStats("  ".length(), 0.1F);
         int var5 = (Integer)var3.getValue(BITES);
         if (var5 < (13 ^ 11)) {
            var1.setBlockState(var2, var3.withProperty(BITES, var5 + " ".length()), "   ".length());
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            "".length();
            if (3 <= 1) {
               throw null;
            }
         } else {
            var1.setBlockToAir(var2);
            I["   ".length()].length();
            I[158 ^ 154].length();
            I[89 ^ 92].length();
            I[33 ^ 39].length();
         }

         return (boolean)" ".length();
      }
   }

   private boolean canBlockStay(World var1, BlockPos var2) {
      return var1.getBlockState(var2.down()).getMaterial().isSolid();
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[30 ^ 18];
      String var10001 = I[182 ^ 187];
      String var10002 = I[120 ^ 118];
      var10001 = I[188 ^ 179];
      I[1 ^ 17].length();
      I[48 ^ 33].length();
      I[143 ^ 157].length();
      return new ItemStack(Items.CAKE);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[182 ^ 165];
      String var10001 = I[118 ^ 98];
      String var10002 = I[103 ^ 114];
      var10001 = I[97 ^ 119];
      var10000 = I[50 ^ 37];
      var10001 = I[3 ^ 27];
      var10002 = I[136 ^ 145];
      var10001 = I[71 ^ 93];
      I[152 ^ 131].length();
      I[126 ^ 98].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[70 ^ 91].length();
      I[91 ^ 69].length();
      I[89 ^ 70].length();
      var10003["".length()] = BITES;
      return new BlockStateContainer(this, var10003);
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (super.canPlaceBlockAt(var1, var2)) {
         var10000 = this.canBlockStay(var1, var2);
         "".length();
         if (4 <= 2) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }
}

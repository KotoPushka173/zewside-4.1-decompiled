package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

public class SPacketSpawnObject implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int type;
   // $FF: synthetic field
   private int yaw;
   // $FF: synthetic field
   private int speedY;
   // $FF: synthetic field
   private double x;
   // $FF: synthetic field
   private int speedX;
   // $FF: synthetic field
   private double y;
   // $FF: synthetic field
   private int pitch;
   // $FF: synthetic field
   private UUID uniqueId;
   // $FF: synthetic field
   private double z;
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private int data;
   // $FF: synthetic field
   private int speedZ;
   // $FF: synthetic field
   private static final String[] I;

   public UUID getUniqueId() {
      return this.uniqueId;
   }

   public int getSpeedY() {
      return this.speedY;
   }

   static {
      I();
   }

   public SPacketSpawnObject(Entity var1, int var2, int var3) {
      this.entityId = var1.getEntityId();
      this.uniqueId = var1.getUniqueID();
      this.x = var1.posX;
      this.y = var1.posY;
      this.z = var1.posZ;
      this.pitch = MathHelper.floor(var1.rotationPitch * 256.0F / 360.0F);
      this.yaw = MathHelper.floor(var1.rotationYaw * 256.0F / 360.0F);
      this.type = var2;
      this.data = var3;
      double var4 = 3.9D;
      this.speedX = (int)(MathHelper.clamp(var1.motionX, -3.9D, 3.9D) * 8000.0D);
      this.speedY = (int)(MathHelper.clamp(var1.motionY, -3.9D, 3.9D) * 8000.0D);
      this.speedZ = (int)(MathHelper.clamp(var1.motionZ, -3.9D, 3.9D) * 8000.0D);
   }

   public double getZ() {
      return this.z;
   }

   public int getSpeedZ() {
      return this.speedZ;
   }

   public void setSpeedX(int var1) {
      this.speedX = var1;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.entityId = var1.readVarIntFromBuffer();
      this.uniqueId = var1.readUuid();
      this.type = var1.readByte();
      this.x = var1.readDouble();
      this.y = var1.readDouble();
      this.z = var1.readDouble();
      this.pitch = var1.readByte();
      this.yaw = var1.readByte();
      this.data = var1.readInt();
      this.speedX = var1.readShort();
      this.speedY = var1.readShort();
      this.speedZ = var1.readShort();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public double getY() {
      return this.y;
   }

   private static void I() {
      I = new String[95 ^ 64];
      I["".length()] = I("扈涜濞", "LueJK");
      I[" ".length()] = I("偢巖梷", "yoARo");
      I["  ".length()] = I("漪擌溩卛嫔", "AkENN");
      I["   ".length()] = I("灭擄", "ykrxR");
      I[7 ^ 3] = I("庛帲瀗掾", "aBTDL");
      I[41 ^ 44] = I("园毲惮峹", "cMVrP");
      I[169 ^ 175] = I("勠姐", "wuntx");
      I[182 ^ 177] = I("瀞娦澆", "gfZmv");
      I[44 ^ 36] = I("炅", "wMBrE");
      I[111 ^ 102] = I("卛副", "fxZkQ");
      I[120 ^ 114] = I("斥敝屾", "zfHWp");
      I[202 ^ 193] = I("割墟櫨封埦", "hNqsD");
      I[22 ^ 26] = I("昃彴", "ZhbUB");
      I[95 ^ 82] = I("塔僰", "wghJv");
      I[71 ^ 73] = I("堶溙漉", "VMTlH");
      I[72 ^ 71] = I("唛曭槈梳幀", "Niixq");
      I[184 ^ 168] = I("慁沣暅様", "sfcQu");
      I[44 ^ 61] = I("徛峤", "nQdIG");
      I[68 ^ 86] = I("擅墌坋塋", "CxrOM");
      I[151 ^ 132] = I("仺橄柣楎橸", "udbjH");
      I[19 ^ 7] = I("嚋灌", "PKUag");
      I[67 ^ 86] = I("惽溭", "jjZFu");
      I[10 ^ 28] = I("宸", "wuIHL");
      I[190 ^ 169] = I("契烸", "YwJrm");
      I[0 ^ 24] = I("烛懇瀾汕", "JicIc");
      I[129 ^ 152] = I("时湆", "rDtSq");
      I[0 ^ 26] = I("仰捼挺搣圷", "uqdJZ");
      I[77 ^ 86] = I("櫞採偾攊悏", "BgZze");
      I[32 ^ 60] = I("墆卓", "VkHNB");
      I[39 ^ 58] = I("巐瀸孿", "lgboR");
      I[167 ^ 185] = I("氵暾弑樞", "zuusM");
   }

   public SPacketSpawnObject() {
   }

   public double getX() {
      return this.x;
   }

   public int getSpeedX() {
      return this.speedX;
   }

   public int getYaw() {
      return this.yaw;
   }

   public int getData() {
      return this.data;
   }

   public SPacketSpawnObject(Entity var1, int var2) {
      this(var1, var2, "".length());
   }

   public void setSpeedZ(int var1) {
      this.speedZ = var1;
   }

   public int getEntityID() {
      return this.entityId;
   }

   public SPacketSpawnObject(Entity var1, int var2, int var3, BlockPos var4) {
      this(var1, var2, var3);
      this.x = (double)var4.getX();
      this.y = (double)var4.getY();
      this.z = (double)var4.getZ();
   }

   public int getType() {
      return this.type;
   }

   public void setSpeedY(int var1) {
      this.speedY = var1;
   }

   public void setData(int var1) {
      this.data = var1;
   }

   public int getPitch() {
      return this.pitch;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleSpawnObject(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeUuid(this.uniqueId);
      I["   ".length()].length();
      var1.writeByte(this.type);
      I[172 ^ 168].length();
      I[156 ^ 153].length();
      I[140 ^ 138].length();
      var1.writeDouble(this.x);
      I[76 ^ 75].length();
      I[60 ^ 52].length();
      I[83 ^ 90].length();
      var1.writeDouble(this.y);
      I[184 ^ 178].length();
      I[45 ^ 38].length();
      var1.writeDouble(this.z);
      I[145 ^ 157].length();
      I[128 ^ 141].length();
      I[39 ^ 41].length();
      var1.writeByte(this.pitch);
      I[26 ^ 21].length();
      I[100 ^ 116].length();
      I[126 ^ 111].length();
      var1.writeByte(this.yaw);
      I[170 ^ 184].length();
      I[142 ^ 157].length();
      I[68 ^ 80].length();
      I[172 ^ 185].length();
      var1.writeInt(this.data);
      I[124 ^ 106].length();
      var1.writeShort(this.speedX);
      I[160 ^ 183].length();
      I[170 ^ 178].length();
      var1.writeShort(this.speedY);
      I[59 ^ 34].length();
      I[148 ^ 142].length();
      I[16 ^ 11].length();
      I[147 ^ 143].length();
      var1.writeShort(this.speedZ);
      I[115 ^ 110].length();
      I[167 ^ 185].length();
   }
}

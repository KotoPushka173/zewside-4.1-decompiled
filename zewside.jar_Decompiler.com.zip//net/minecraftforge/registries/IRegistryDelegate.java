package net.minecraftforge.registries;

import net.minecraft.util.ResourceLocation;

public interface IRegistryDelegate<T> {
   T get();

   Class<T> type();

   ResourceLocation name();
}

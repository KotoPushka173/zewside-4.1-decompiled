package net.minecraft.dispenser;

import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;

public interface IBlockSource extends ILocatableSource {
   BlockPos getBlockPos();

   double getZ();

   IBlockState getBlockState();

   double getX();

   double getY();

   <T extends TileEntity> T getBlockTileEntity();
}

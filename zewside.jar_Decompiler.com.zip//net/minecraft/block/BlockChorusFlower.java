package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockChorusFlower extends Block {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyInteger AGE;

   private void placeGrownFlower(World var1, BlockPos var2, int var3) {
      var1.setBlockState(var2, this.getDefaultState().withProperty(AGE, var3), "  ".length());
      I[180 ^ 190].length();
      I[179 ^ 184].length();
      I[143 ^ 131].length();
      var1.playEvent(182 + 1004 - 856 + 703, var2, "".length());
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (super.canPlaceBlockAt(var1, var2) && this.canSurvive(var1, var2)) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public static void generatePlant(World var0, BlockPos var1, Random var2, int var3) {
      var0.setBlockState(var1, Blocks.CHORUS_PLANT.getDefaultState(), "  ".length());
      I[151 ^ 179].length();
      I[82 ^ 119].length();
      I[91 ^ 125].length();
      growTreeRecursive(var0, var1, var2, var1, var3, "".length());
   }

   public boolean canSurvive(World var1, BlockPos var2) {
      IBlockState var3 = var1.getBlockState(var2.down());
      Block var4 = var3.getBlock();
      if (var4 != Blocks.CHORUS_PLANT && var4 != Blocks.END_STONE) {
         if (var3.getMaterial() == Material.AIR) {
            int var5 = "".length();
            Iterator var6 = EnumFacing.Plane.HORIZONTAL.iterator();

            do {
               if (!var6.hasNext()) {
                  int var10000;
                  if (var5 == " ".length()) {
                     var10000 = " ".length();
                     "".length();
                     if (4 == 1) {
                        throw null;
                     }
                  } else {
                     var10000 = "".length();
                  }

                  return (boolean)var10000;
               }

               EnumFacing var7 = (EnumFacing)var6.next();
               IBlockState var8 = var1.getBlockState(var2.offset(var7));
               Block var9 = var8.getBlock();
               if (var9 == Blocks.CHORUS_PLANT) {
                  ++var5;
                  "".length();
                  if (2 == 1) {
                     throw null;
                  }
               } else if (var8.getMaterial() != Material.AIR) {
                  return (boolean)"".length();
               }

               "".length();
            } while(0 > -1);

            throw null;
         } else {
            return (boolean)"".length();
         }
      } else {
         return (boolean)" ".length();
      }
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.field_190931_a;
   }

   public int getMetaFromState(IBlockState var1) {
      return (Integer)var1.getValue(AGE);
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   protected BlockChorusFlower() {
      super(Material.PLANTS, MapColor.PURPLE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(AGE, "".length()));
      this.setCreativeTab(CreativeTabs.DECORATIONS);
      this.setTickRandomly((boolean)" ".length());
   }

   private void placeDeadFlower(World var1, BlockPos var2) {
      var1.setBlockState(var2, this.getDefaultState().withProperty(AGE, 193 ^ 196), "  ".length());
      I[152 ^ 149].length();
      I[95 ^ 81].length();
      var1.playEvent(863 + 102 - 261 + 330, var2, "".length());
   }

   protected ItemStack getSilkTouchDrop(IBlockState var1) {
      return ItemStack.field_190927_a;
   }

   private static void I() {
      I = new String[79 ^ 119];
      I["".length()] = I("歭幘土", "WMQHK");
      I[" ".length()] = I("湠洉", "dAcuT");
      I["  ".length()] = I("咷屘", "sKCSo");
      I["   ".length()] = I("傔", "uDbcm");
      I[29 ^ 25] = I("墔槒咛惚徼", "XlyAs");
      I[126 ^ 123] = I("峔捊揤", "PfCiT");
      I[151 ^ 145] = I("侶", "hdccB");
      I[41 ^ 46] = I("创两为嬮", "znHHz");
      I[118 ^ 126] = I("俨忚溌嚁", "zsIbv");
      I[25 ^ 16] = I("凸呆", "TEgUp");
      I[84 ^ 94] = I("庆剥偺惾梎", "wreMy");
      I[11 ^ 0] = I("樿", "pPUJl");
      I[12 ^ 0] = I("囦刣徲", "MyAZJ");
      I[190 ^ 179] = I("婟孪橔嶈", "Drapg");
      I[126 ^ 112] = I("壬實", "xCogB");
      I[157 ^ 146] = I("嬹呲", "pGoAg");
      I[99 ^ 115] = I("敫殻", "OIkdT");
      I[97 ^ 112] = I("曖滏", "gHret");
      I[117 ^ 103] = I("怨噉", "Gbdel");
      I[147 ^ 128] = I("侁壝", "JoDpd");
      I[110 ^ 122] = I("幰剣幪扜", "LQadA");
      I[141 ^ 152] = I("灮樧", "MjvDw");
      I[64 ^ 86] = I("剔奱搸俣柚", "whsDe");
      I[135 ^ 144] = I("抭媘", "NYtlk");
      I[161 ^ 185] = I("沮失", "EMbDm");
      I[182 ^ 175] = I("崆咽", "DJMWO");
      I[160 ^ 186] = I("扜悷", "UbHDq");
      I[150 ^ 141] = I("嵽匣", "AoncK");
      I[222 ^ 194] = I("嶉怦", "GQwPm");
      I[150 ^ 139] = I("堗崅", "TvGXv");
      I[36 ^ 58] = I("婄专", "gnyYI");
      I[22 ^ 9] = I("漄湓沅拆抨", "lYnTK");
      I[51 ^ 19] = I("伍", "KTgND");
      I[182 ^ 151] = I("夌暹", "FKwKZ");
      I[18 ^ 48] = I("姳叱瀸", "qFXIY");
      I[160 ^ 131] = I("叾偯彀婩嫅", "KJemV");
      I[101 ^ 65] = I("檔摗波喃杕", "hxRzS");
      I[129 ^ 164] = I("妗怵媚氭", "dwCtY");
      I[40 ^ 14] = I("夿炌劔瀬", "ezdiw");
      I[47 ^ 8] = I("偽", "aEtEz");
      I[22 ^ 62] = I("扴涳悗揅堮", "teFVZ");
      I[122 ^ 83] = I("彛搁冏奷檻", "UUlce");
      I[86 ^ 124] = I("扵", "BSfdv");
      I[2 ^ 41] = I("彛", "Kgsky");
      I[33 ^ 13] = I("巅呺帋叮", "qrkvq");
      I[140 ^ 161] = I("溽椙", "wlvTY");
      I[64 ^ 110] = I("拒倳樬", "KiivK");
      I[182 ^ 153] = I("媃媟姲悂", "dqPpW");
      I[166 ^ 150] = I("浊", "svFkX");
      I[6 ^ 55] = I("歰儃儜", "dxDTM");
      I[243 ^ 193] = I("峻俰", "zYbwx");
      I[89 ^ 106] = I("唠摠囶摳嵗", "htgTD");
      I[105 ^ 93] = I("烒墥柟", "qiXRE");
      I[176 ^ 133] = I("烑屛", "vhOEG");
      I[80 ^ 102] = I("泐剀櫴", "eocPp");
      I[108 ^ 91] = I("8 &", "YGCVa");
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   static {
      I();
      AGE = PropertyInteger.create(I[60 ^ 11], "".length(), 93 ^ 88);
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[166 ^ 177];
      String var10001 = I[103 ^ 127];
      String var10002 = I[2 ^ 27];
      var10001 = I[51 ^ 41];
      var10000 = I[77 ^ 86];
      var10001 = I[71 ^ 91];
      var10002 = I[10 ^ 23];
      var10001 = I[140 ^ 146];
      I[155 ^ 132].length();
      I[40 ^ 8].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[102 ^ 71].length();
      I[191 ^ 157].length();
      I[160 ^ 131].length();
      var10003["".length()] = AGE;
      return new BlockStateContainer(this, var10003);
   }

   public void harvestBlock(World var1, EntityPlayer var2, BlockPos var3, IBlockState var4, @Nullable TileEntity var5, ItemStack var6) {
      String var10000 = I[10 ^ 5];
      String var10001 = I[2 ^ 18];
      String var10002 = I[82 ^ 67];
      var10001 = I[63 ^ 45];
      super.harvestBlock(var1, var2, var3, var4, var5, var6);
      I[101 ^ 118].length();
      I[176 ^ 164].length();
      I[19 ^ 6].length();
      I[189 ^ 171].length();
      spawnAsEntity(var1, var3, new ItemStack(Item.getItemFromBlock(this)));
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!this.canSurvive(var2, var3)) {
         var2.scheduleUpdate(var3, this, " ".length());
      }

   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!this.canSurvive(var1, var2)) {
         var1.destroyBlock(var2, (boolean)" ".length());
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
         "".length();
         if (2 == 1) {
            throw null;
         }
      } else {
         BlockPos var5 = var2.up();
         if (var1.isAirBlock(var5) && var5.getY() < 41 + 58 - -15 + 142) {
            int var6 = (Integer)var3.getValue(AGE);
            if (var6 < (77 ^ 72) && var4.nextInt(" ".length()) == 0) {
               int var7 = "".length();
               int var8 = "".length();
               IBlockState var9 = var1.getBlockState(var2.down());
               Block var10 = var9.getBlock();
               int var11;
               int var12;
               if (var10 == Blocks.END_STONE) {
                  var7 = " ".length();
                  "".length();
                  if (1 < -1) {
                     throw null;
                  }
               } else if (var10 != Blocks.CHORUS_PLANT) {
                  if (var9.getMaterial() == Material.AIR) {
                     var7 = " ".length();
                  }
               } else {
                  var11 = " ".length();
                  var12 = "".length();

                  while(var12 < (93 ^ 89)) {
                     Block var13 = var1.getBlockState(var2.down(var11 + " ".length())).getBlock();
                     if (var13 != Blocks.CHORUS_PLANT) {
                        if (var13 == Blocks.END_STONE) {
                           var8 = " ".length();
                           "".length();
                           if (-1 >= 2) {
                              throw null;
                           }
                        }
                        break;
                     }

                     ++var11;
                     ++var12;
                     "".length();
                     if (0 >= 1) {
                        throw null;
                     }
                  }

                  var12 = 101 ^ 97;
                  if (var8 != 0) {
                     ++var12;
                  }

                  if (var11 < "  ".length() || var4.nextInt(var12) >= var11) {
                     var7 = " ".length();
                  }

                  "".length();
                  if (4 <= -1) {
                     throw null;
                  }
               }

               if (var7 != 0 && areAllNeighborsEmpty(var1, var5, (EnumFacing)null) && var1.isAirBlock(var2.up("  ".length()))) {
                  var1.setBlockState(var2, Blocks.CHORUS_PLANT.getDefaultState(), "  ".length());
                  I[148 ^ 144].length();
                  I[88 ^ 93].length();
                  I[34 ^ 36].length();
                  I[128 ^ 135].length();
                  this.placeGrownFlower(var1, var5, var6);
                  "".length();
                  if (1 == -1) {
                     throw null;
                  }
               } else if (var6 < (101 ^ 97)) {
                  var11 = var4.nextInt(79 ^ 75);
                  var12 = "".length();
                  if (var8 != 0) {
                     ++var11;
                  }

                  int var16 = "".length();

                  while(var16 < var11) {
                     EnumFacing var14 = EnumFacing.Plane.HORIZONTAL.random(var4);
                     BlockPos var15 = var2.offset(var14);
                     if (var1.isAirBlock(var15) && var1.isAirBlock(var15.down()) && areAllNeighborsEmpty(var1, var15, var14.getOpposite())) {
                        this.placeGrownFlower(var1, var15, var6 + " ".length());
                        var12 = " ".length();
                     }

                     ++var16;
                     "".length();
                     if (3 != 3) {
                        throw null;
                     }
                  }

                  if (var12 != 0) {
                     var1.setBlockState(var2, Blocks.CHORUS_PLANT.getDefaultState(), "  ".length());
                     I[165 ^ 173].length();
                     I[36 ^ 45].length();
                     "".length();
                     if (3 >= 4) {
                        throw null;
                     }
                  } else {
                     this.placeDeadFlower(var1, var2);
                  }

                  "".length();
                  if (0 == 2) {
                     throw null;
                  }
               } else if (var6 == (66 ^ 70)) {
                  this.placeDeadFlower(var1, var2);
               }
            }
         }
      }

   }

   private static void growTreeRecursive(World var0, BlockPos var1, Random var2, BlockPos var3, int var4, int var5) {
      int var6 = var2.nextInt(89 ^ 93) + " ".length();
      if (var5 == 0) {
         ++var6;
      }

      int var7 = "".length();

      while(var7 < var6) {
         BlockPos var8 = var1.up(var7 + " ".length());
         if (!areAllNeighborsEmpty(var0, var8, (EnumFacing)null)) {
            return;
         }

         var0.setBlockState(var8, Blocks.CHORUS_PLANT.getDefaultState(), "  ".length());
         I[80 ^ 119].length();
         I[185 ^ 145].length();
         I[95 ^ 118].length();
         I[56 ^ 18].length();
         ++var7;
         "".length();
         if (4 <= 2) {
            throw null;
         }
      }

      var7 = "".length();
      if (var5 < (28 ^ 24)) {
         int var12 = var2.nextInt(65 ^ 69);
         if (var5 == 0) {
            ++var12;
         }

         int var9 = "".length();

         while(var9 < var12) {
            EnumFacing var10 = EnumFacing.Plane.HORIZONTAL.random(var2);
            BlockPos var11 = var1.up(var6).offset(var10);
            int var10000 = var11.getX();
            int var10001 = var3.getX();
            I[56 ^ 19].length();
            I[26 ^ 54].length();
            if (Math.abs(var10000 - var10001) < var4) {
               var10000 = var11.getZ();
               var10001 = var3.getZ();
               I[97 ^ 76].length();
               I[111 ^ 65].length();
               I[234 ^ 197].length();
               I[113 ^ 65].length();
               I[131 ^ 178].length();
               if (Math.abs(var10000 - var10001) < var4 && var0.isAirBlock(var11) && var0.isAirBlock(var11.down()) && areAllNeighborsEmpty(var0, var11, var10.getOpposite())) {
                  var7 = " ".length();
                  var0.setBlockState(var11, Blocks.CHORUS_PLANT.getDefaultState(), "  ".length());
                  I[164 ^ 150].length();
                  I[53 ^ 6].length();
                  growTreeRecursive(var0, var11, var2, var3, var4, var5 + " ".length());
               }
            }

            ++var9;
            "".length();
            if (2 < -1) {
               throw null;
            }
         }
      }

      if (var7 == 0) {
         var0.setBlockState(var1.up(var6), Blocks.CHORUS_FLOWER.getDefaultState().withProperty(AGE, 137 ^ 140), "  ".length());
         I[184 ^ 140].length();
         I[13 ^ 56].length();
         I[114 ^ 68].length();
      }

   }

   public IBlockState getStateFromMeta(int var1) {
      return this.getDefaultState().withProperty(AGE, var1);
   }

   private static boolean areAllNeighborsEmpty(World var0, BlockPos var1, EnumFacing var2) {
      Iterator var3 = EnumFacing.Plane.HORIZONTAL.iterator();

      do {
         if (!var3.hasNext()) {
            return (boolean)" ".length();
         }

         EnumFacing var4 = (EnumFacing)var3.next();
         if (var4 != var2 && !var0.isAirBlock(var1.offset(var4))) {
            return (boolean)"".length();
         }

         "".length();
      } while(true);

      throw null;
   }
}

package net.minecraft.enchantment;

import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;

public class EnchantmentDigging extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   public boolean canApply(ItemStack var1) {
      int var10000;
      if (var1.getItem() == Items.SHEARS) {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      } else {
         var10000 = super.canApply(var1);
      }

      return (boolean)var10000;
   }

   private static void I() {
      I = new String[60 ^ 57];
      I["".length()] = I("\u000f\u0005,\u0001.\u0005\u000b", "klKfG");
      I[" ".length()] = I("俑杏卥昚價", "fyTIt");
      I["  ".length()] = I("澠愐掗", "MBFTN");
      I["   ".length()] = I("涖掤", "SDEsz");
      I[16 ^ 20] = I("壶", "SNFrn");
   }

   public int getMaxEnchantability(int var1) {
      return super.getMinEnchantability(var1) + (30 ^ 44);
   }

   public int getMaxLevel() {
      return 32 ^ 37;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 4);

      throw null;
   }

   static {
      I();
   }

   public int getMinEnchantability(int var1) {
      int var10000 = " ".length();
      int var10001 = 78 ^ 68;
      int var10003 = " ".length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      I[103 ^ 99].length();
      return var10000 + var10001 * (var1 - var10003);
   }

   protected EnchantmentDigging(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.DIGGER, var2);
      this.setName(I["".length()]);
   }
}

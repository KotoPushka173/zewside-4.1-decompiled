package net.minecraft.advancements;

import com.google.common.base.Function;
import com.google.common.base.Functions;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AdvancementList {
   // $FF: synthetic field
   private final Map<ResourceLocation, Advancement> field_192092_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final Logger field_192091_a;
   // $FF: synthetic field
   private final Set<Advancement> field_192094_d = Sets.newLinkedHashSet();
   // $FF: synthetic field
   private final Set<Advancement> field_192093_c = Sets.newLinkedHashSet();
   // $FF: synthetic field
   private AdvancementList.Listener field_192095_e;
   // $FF: synthetic field
   private static final String[] I;

   public Iterable<Advancement> func_192088_b() {
      return this.field_192093_c;
   }

   public void func_192087_a() {
      this.field_192092_b.clear();
      this.field_192093_c.clear();
      this.field_192094_d.clear();
      if (this.field_192095_e != null) {
         this.field_192095_e.func_191930_a();
      }

   }

   public Iterable<Advancement> func_192089_c() {
      return this.field_192092_b.values();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   private void func_192090_a(Advancement var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      Iterator var2 = var1.func_192069_e().iterator();

      do {
         if (!var2.hasNext()) {
            Logger var4 = field_192091_a;
            I[71 ^ 67].length();
            I[12 ^ 9].length();
            var4.info(I[115 ^ 117] + var1.func_192067_g());
            this.field_192092_b.remove(var1.func_192067_g());
            I[146 ^ 149].length();
            I[117 ^ 125].length();
            I[91 ^ 82].length();
            I[10 ^ 0].length();
            if (var1.func_192070_b() == null) {
               this.field_192093_c.remove(var1);
               I[33 ^ 42].length();
               I[170 ^ 166].length();
               I[135 ^ 138].length();
               I[159 ^ 145].length();
               I[163 ^ 172].length();
               if (this.field_192095_e != null) {
                  this.field_192095_e.func_191928_b(var1);
                  "".length();
                  if (1 < 1) {
                     throw null;
                  }
               }
            } else {
               this.field_192094_d.remove(var1);
               I[155 ^ 139].length();
               if (this.field_192095_e != null) {
                  this.field_192095_e.func_191929_d(var1);
               }
            }

            return;
         }

         Advancement var3 = (Advancement)var2.next();
         this.func_192090_a(var3);
         "".length();
      } while(3 >= 0);

      throw null;
   }

   @Nullable
   public Advancement func_192084_a(ResourceLocation var1) {
      return (Advancement)this.field_192092_b.get(var1);
   }

   private static void I() {
      I = new String[41 ^ 6];
      I["".length()] = I("巀泤", "ryrAt");
      I[" ".length()] = I("優曶", "kxweD");
      I["  ".length()] = I("槄灮", "QTcjc");
      I["   ".length()] = I("怼强", "hzeJL");
      I[80 ^ 84] = I("屳擲栻", "DiybZ");
      I[51 ^ 54] = I("垑橉晏", "IBjkm");
      I[78 ^ 72] = I("\u0015\u001d$\f?'R7\t?&\u0006v\n4%\u00138\b5>\u00178\u001fp", "SrVkP");
      I[51 ^ 52] = I("曩炙", "tgbHO");
      I[47 ^ 39] = I("樜歞烢", "iPyfZ");
      I[79 ^ 70] = I("廥漢沟仝", "nCnfM");
      I[23 ^ 29] = I("懶帊刈仃", "EsjbG");
      I[110 ^ 101] = I("壺塹", "mwgCb");
      I[30 ^ 18] = I("廞滶変刭", "QEXSL");
      I[56 ^ 53] = I("垀灾嶓涥坋", "jvLKT");
      I[136 ^ 134] = I("事樥楋", "KfaNO");
      I[31 ^ 16] = I("敕渁", "RRhhM");
      I[150 ^ 134] = I("剶擿小吕帡", "PBrZC");
      I[60 ^ 45] = I("湝呱", "XsdiB");
      I[80 ^ 66] = I("塊森", "eRxGs");
      I[100 ^ 119] = I("婓備", "CnDJv");
      I[7 ^ 19] = I("渘嘤", "swgOL");
      I[48 ^ 37] = I("槰沖抆炣", "ktXTd");
      I[175 ^ 185] = I("\u0001*\u000b\u0000T!*G\u0016\u00118*\u0011\u0001T4!\u0011\u0005\u001a6 \n\u0001\u001a!e", "UEgdt");
      I[77 ^ 90] = I("g$\u0013\u001fv\u000ef\u0002\u00048`2F\u00008(1F\u001c>&2F\u001f>&2F\u0002%", "GFfkV");
      I[182 ^ 174] = I("殌淴", "KlzvC");
      I[130 ^ 155] = I("揠厪", "ZffSE");
      I[130 ^ 152] = I("夃垨", "MOkzq");
      I[171 ^ 176] = I("倨垱", "IHmtD");
      I[8 ^ 20] = I("元慍", "LMrcj");
      I[55 ^ 42] = I("全搓", "cKDUJ");
      I[38 ^ 56] = I("摖嵳", "pSXZs");
      I[134 ^ 153] = I("丁攥", "fztQH");
      I[125 ^ 93] = I("愞戈嗱嵓彃", "IBAiK");
      I[82 ^ 115] = I("峖汐挊叫", "TnADF");
      I[56 ^ 26] = I("千", "vnKoM");
      I[21 ^ 54] = I("烆烓摋姧峞", "QGFmY");
      I[171 ^ 143] = I("利战奱哒宁", "FbbjP");
      I[85 ^ 112] = I("嚺偋審慟唷", "stcUs");
      I[109 ^ 75] = I("勗敓亓店", "Yfhcx");
      I[61 ^ 26] = I("咕噄戽", "xlkYv");
      I[14 ^ 38] = I("\u000b\u001a\u00126\u0007&R\u0013z\u000f'\u0014\u0003z\u0002,\u0003\u00064\u0000-\u0018\u00024\u0017h", "HugZc");
      I[189 ^ 148] = I("{n", "ANnSh");
      I[18 ^ 56] = I("嬧宴宄噬匍", "pRapI");
      I[113 ^ 90] = I("梂棐婜儐", "cEoGZ");
      I[65 ^ 109] = I("涐喌夑溄峄", "ScfiN");
      I[123 ^ 86] = I(">\u0000\u0019\f*\u0016O", "roxhO");
      I[73 ^ 103] = I("r\u000e\u0001\u0012\u001b<\f\u0000\t\u001f<\u001b\u0016", "Roedz");
   }

   public void func_192085_a(Set<ResourceLocation> var1) {
      String var10000 = I[33 ^ 48];
      String var10001 = I[144 ^ 130];
      String var10002 = I[97 ^ 114];
      var10001 = I[16 ^ 4];
      Iterator var2 = var1.iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         ResourceLocation var3 = (ResourceLocation)var2.next();
         Advancement var4 = (Advancement)this.field_192092_b.get(var3);
         if (var4 == null) {
            Logger var5 = field_192091_a;
            I[123 ^ 110].length();
            var5.warn(I[16 ^ 6] + var3 + I[95 ^ 72]);
            "".length();
            if (1 == 3) {
               throw null;
            }
         } else {
            this.func_192090_a(var4);
         }

         "".length();
      } while(3 > 2);

      throw null;
   }

   public void func_192083_a(Map<ResourceLocation, Advancement.Builder> var1) {
      String var10000 = I[5 ^ 29];
      String var10001 = I[160 ^ 185];
      String var10002 = I[123 ^ 97];
      var10001 = I[54 ^ 45];
      var10000 = I[118 ^ 106];
      var10001 = I[96 ^ 125];
      var10002 = I[170 ^ 180];
      var10001 = I[85 ^ 74];
      Function var2 = Functions.forMap(this.field_192092_b, (Object)null);

      Logger var9;
      while(!var1.isEmpty()) {
         int var3 = "".length();
         Iterator var4 = var1.entrySet().iterator();

         Entry var5;
         while(var4.hasNext()) {
            var5 = (Entry)var4.next();
            ResourceLocation var6 = (ResourceLocation)var5.getKey();
            Advancement.Builder var7 = (Advancement.Builder)var5.getValue();
            if (var7.func_192058_a(var2)) {
               Advancement var8 = var7.func_192056_a(var6);
               this.field_192092_b.put(var6, var8);
               I[20 ^ 52].length();
               var3 = " ".length();
               var4.remove();
               if (var8.func_192070_b() == null) {
                  this.field_192093_c.add(var8);
                  I[44 ^ 13].length();
                  if (this.field_192095_e != null) {
                     this.field_192095_e.func_191931_a(var8);
                     "".length();
                     if (-1 >= 3) {
                        throw null;
                     }
                  }
               } else {
                  this.field_192094_d.add(var8);
                  I[1 ^ 35].length();
                  I[68 ^ 103].length();
                  I[31 ^ 59].length();
                  if (this.field_192095_e != null) {
                     this.field_192095_e.func_191932_c(var8);
                  }
               }
            }

            "".length();
            if (-1 >= 0) {
               throw null;
            }
         }

         if (var3 == 0) {
            var4 = var1.entrySet().iterator();

            while(var4.hasNext()) {
               var5 = (Entry)var4.next();
               var9 = field_192091_a;
               I[36 ^ 1].length();
               I[59 ^ 29].length();
               I[175 ^ 136].length();
               var9.error(I[162 ^ 138] + var5.getKey() + I[169 ^ 128] + var5.getValue());
               "".length();
               if (4 < 2) {
                  throw null;
               }
            }

            "".length();
            if (3 <= 1) {
               throw null;
            }
            break;
         }

         "".length();
         if (false) {
            throw null;
         }
      }

      var9 = field_192091_a;
      I[26 ^ 48].length();
      I[183 ^ 156].length();
      I[14 ^ 34].length();
      var9.info(I[88 ^ 117] + this.field_192092_b.size() + I[136 ^ 166]);
   }

   static {
      I();
      field_192091_a = LogManager.getLogger();
   }

   public void func_192086_a(@Nullable AdvancementList.Listener var1) {
      this.field_192095_e = var1;
      if (var1 != null) {
         Iterator var2 = this.field_192093_c.iterator();

         Advancement var3;
         while(var2.hasNext()) {
            var3 = (Advancement)var2.next();
            var1.func_191931_a(var3);
            "".length();
            if (-1 >= 3) {
               throw null;
            }
         }

         var2 = this.field_192094_d.iterator();

         while(var2.hasNext()) {
            var3 = (Advancement)var2.next();
            var1.func_191932_c(var3);
            "".length();
            if (-1 == 0) {
               throw null;
            }
         }
      }

   }

   public interface Listener {
      void func_191929_d(Advancement var1);

      void func_191928_b(Advancement var1);

      void func_191931_a(Advancement var1);

      void func_191930_a();

      void func_191932_c(Advancement var1);
   }
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockGrass extends Block implements IGrowable {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool SNOWY;

   protected BlockGrass() {
      super(Material.GRASS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(SNOWY, Boolean.valueOf((boolean)"".length())));
      this.setTickRandomly((boolean)" ".length());
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[57 ^ 42];
      String var10001 = I[191 ^ 171];
      String var10002 = I[111 ^ 122];
      var10001 = I[110 ^ 120];
      var10000 = I[162 ^ 181];
      var10001 = I[63 ^ 39];
      var10002 = I[97 ^ 120];
      var10001 = I[50 ^ 40];
      I[96 ^ 123].length();
      I[55 ^ 43].length();
      I[82 ^ 79].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[167 ^ 185].length();
      I[187 ^ 164].length();
      I[21 ^ 53].length();
      var10003["".length()] = SNOWY;
      return new BlockStateContainer(this, var10003);
   }

   public void grow(World var1, Random var2, BlockPos var3, IBlockState var4) {
      BlockPos var5 = var3.up();
      int var6 = "".length();

      do {
         if (var6 >= 64 + 111 - 134 + 87) {
            return;
         }

         BlockPos var7 = var5;
         int var8 = "".length();

         while(true) {
            if (var8 >= var6 / (49 ^ 33)) {
               if (var1.getBlockState(var7).getBlock().blockMaterial == Material.AIR) {
                  if (var2.nextInt(55 ^ 63) == 0) {
                     BlockFlower.EnumFlowerType var9 = var1.getBiome(var7).pickRandomFlower(var2, var7);
                     BlockFlower var10 = var9.getBlockType().getBlock();
                     IBlockState var11 = var10.getDefaultState().withProperty(var10.getTypeProperty(), var9);
                     if (var10.canBlockStay(var1, var7, var11)) {
                        var1.setBlockState(var7, var11, "   ".length());
                        I[26 ^ 17].length();
                        I[132 ^ 136].length();
                     }

                     "".length();
                     if (4 <= -1) {
                        throw null;
                     }
                  } else {
                     IBlockState var12 = Blocks.TALLGRASS.getDefaultState().withProperty(BlockTallGrass.TYPE, BlockTallGrass.EnumType.GRASS);
                     if (Blocks.TALLGRASS.canBlockStay(var1, var7, var12)) {
                        var1.setBlockState(var7, var12, "   ".length());
                        I[69 ^ 72].length();
                     }

                     "".length();
                     if (2 != 2) {
                        throw null;
                     }
                  }
               }
               break;
            }

            int var10001 = var2.nextInt("   ".length());
            int var10002 = " ".length();
            I[55 ^ 57].length();
            var10001 -= var10002;
            var10002 = var2.nextInt("   ".length());
            int var10003 = " ".length();
            I[39 ^ 40].length();
            I[116 ^ 100].length();
            I[58 ^ 43].length();
            var10002 = (var10002 - var10003) * var2.nextInt("   ".length()) / "  ".length();
            var10003 = var2.nextInt("   ".length());
            int var10004 = " ".length();
            I[38 ^ 52].length();
            var7 = var7.add(var10001, var10002, var10003 - var10004);
            if (var1.getBlockState(var7.down()).getBlock() != Blocks.GRASS) {
               break;
            }

            if (var1.getBlockState(var7).isNormalCube()) {
               "".length();
               if (3 == 0) {
                  throw null;
               }
               break;
            }

            ++var8;
            "".length();
            if (2 == -1) {
               throw null;
            }
         }

         ++var6;
         "".length();
      } while(true);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   public boolean canUseBonemeal(World var1, Random var2, BlockPos var3, IBlockState var4) {
      return (boolean)" ".length();
   }

   private static void I() {
      I = new String[106 ^ 72];
      I["".length()] = I("墨桨橛冬扯", "ajNew");
      I[" ".length()] = I("瀜嗑", "cRQNB");
      I["  ".length()] = I("炄淿", "Kwvlg");
      I["   ".length()] = I("嘳憡囋", "LQgLk");
      I[89 ^ 93] = I("撷樞喳婹挆", "vheBA");
      I[24 ^ 29] = I("昼庥幺峑", "eeVBU");
      I[73 ^ 79] = I("勣扫", "oqkXC");
      I[160 ^ 167] = I("擟", "Lntwe");
      I[170 ^ 162] = I("慼拤暞", "SLBdf");
      I[105 ^ 96] = I("刲喧各", "uuuAw");
      I[47 ^ 37] = I("仾借厞", "GFiQp");
      I[135 ^ 140] = I("楻", "mQnxZ");
      I[83 ^ 95] = I("概姵", "yNCfE");
      I[36 ^ 41] = I("廦婤", "shaTo");
      I[54 ^ 56] = I("溽", "OQqAY");
      I[8 ^ 7] = I("岤歋杨榺憚", "trgkL");
      I[76 ^ 92] = I("塛果孄佒埰", "JozbJ");
      I[76 ^ 93] = I("帱曷嘦", "StLpR");
      I[151 ^ 133] = I("坞俾姎囃", "dKVmB");
      I[182 ^ 165] = I("弣旣", "AukQA");
      I[75 ^ 95] = I("啽尺", "iDtMZ");
      I[20 ^ 1] = I("巓嚿", "EkUSF");
      I[168 ^ 190] = I("潗巖", "fmxsZ");
      I[106 ^ 125] = I("儖崕", "ytPiy");
      I[107 ^ 115] = I("团埡", "nAANV");
      I[170 ^ 179] = I("媁沭", "HEupx");
      I[52 ^ 46] = I("湒憨", "aoLaG");
      I[220 ^ 199] = I("娕嗵檤", "QeMDr");
      I[25 ^ 5] = I("宮", "cTunx");
      I[76 ^ 81] = I("審斱", "pMZFz");
      I[102 ^ 120] = I("卬擂坹孢槓", "pAlFN");
      I[107 ^ 116] = I("择婮沯垩", "JDfln");
      I[64 ^ 96] = I("唙惤", "bZrWy");
      I[224 ^ 193] = I(";\r%\r\u0000", "HcJzy");
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT_MIPPED;
   }

   public boolean canGrow(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      return (boolean)" ".length();
   }

   static {
      I();
      SNOWY = PropertyBool.create(I[225 ^ 192]);
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      Block var4 = var2.getBlockState(var3.up()).getBlock();
      PropertyBool var10001 = SNOWY;
      int var10002;
      if (var4 != Blocks.SNOW && var4 != Blocks.SNOW_LAYER) {
         var10002 = "".length();
      } else {
         var10002 = " ".length();
         "".length();
         if (4 <= 0) {
            throw null;
         }
      }

      return var1.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Blocks.DIRT.getItemDropped(Blocks.DIRT.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.DIRT), var2, var3);
   }

   public int getMetaFromState(IBlockState var1) {
      return "".length();
   }

   public void updateTick(World var1, BlockPos var2, IBlockState var3, Random var4) {
      if (!var1.isRemote) {
         if (var1.getLightFromNeighbors(var2.up()) < (183 ^ 179) && var1.getBlockState(var2.up()).getLightOpacity() > "  ".length()) {
            var1.setBlockState(var2, Blocks.DIRT.getDefaultState());
            I["".length()].length();
            I[" ".length()].length();
            I["  ".length()].length();
            "".length();
            if (2 <= -1) {
               throw null;
            }
         } else if (var1.getLightFromNeighbors(var2.up()) >= (14 ^ 7)) {
            int var5 = "".length();

            while(var5 < (127 ^ 123)) {
               int var10001 = var4.nextInt("   ".length());
               int var10002 = " ".length();
               I["   ".length()].length();
               I[76 ^ 72].length();
               I[100 ^ 97].length();
               var10001 -= var10002;
               var10002 = var4.nextInt(103 ^ 98);
               int var10003 = "   ".length();
               I[9 ^ 15].length();
               var10002 -= var10003;
               var10003 = var4.nextInt("   ".length());
               int var10004 = " ".length();
               I[91 ^ 92].length();
               I[118 ^ 126].length();
               BlockPos var6 = var2.add(var10001, var10002, var10003 - var10004);
               if (var6.getY() >= 0 && var6.getY() < 243 + 14 - 59 + 58 && !var1.isBlockLoaded(var6)) {
                  return;
               }

               IBlockState var7 = var1.getBlockState(var6.up());
               IBlockState var8 = var1.getBlockState(var6);
               if (var8.getBlock() == Blocks.DIRT && var8.getValue(BlockDirt.VARIANT) == BlockDirt.DirtType.DIRT && var1.getLightFromNeighbors(var6.up()) >= (2 ^ 6) && var7.getLightOpacity() <= "  ".length()) {
                  var1.setBlockState(var6, Blocks.GRASS.getDefaultState());
                  I[151 ^ 158].length();
                  I[131 ^ 137].length();
               }

               ++var5;
               "".length();
               if (-1 < -1) {
                  throw null;
               }
            }
         }
      }

   }
}

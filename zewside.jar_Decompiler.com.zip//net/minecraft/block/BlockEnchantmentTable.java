package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEnchantmentTable;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockEnchantmentTable extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB AABB;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 4);

      throw null;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return AABB;
   }

   protected BlockEnchantmentTable() {
      super(Material.ROCK, MapColor.RED);
      this.setLightOpacity("".length());
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         TileEntity var10 = var1.getTileEntity(var2);
         if (var10 instanceof TileEntityEnchantmentTable) {
            var4.displayGui((TileEntityEnchantmentTable)var10);
         }

         return (boolean)" ".length();
      }
   }

   private static void I() {
      I = new String[41 ^ 37];
      I["".length()] = I("潵", "ccqKH");
      I[" ".length()] = I("湩", "Imcsg");
      I["  ".length()] = I("兑歮悙尼", "LFVRo");
      I["   ".length()] = I("溜墓毗", "yTCYR");
      I[153 ^ 157] = I("懿屼", "CsoSq");
      I[73 ^ 76] = I("幨問", "SpXWu");
      I[40 ^ 46] = I("佅什欸儜徰", "koEkf");
      I[51 ^ 52] = I("幉涾", "eqcqq");
      I[113 ^ 121] = I("啱椔", "EEqCA");
      I[205 ^ 196] = I("憏慊", "pfkwW");
      I[121 ^ 115] = I("唣嫀", "kspDW");
      I[67 ^ 72] = I("瀗妛栃檕", "rBYNy");
   }

   static {
      I();
      AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.75D, 1.0D);
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 == EnumFacing.DOWN) {
         var10000 = BlockFaceShape.SOLID;
         "".length();
         if (0 >= 2) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.UNDEFINED;
      }

      return var10000;
   }

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.MODEL;
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      super.randomDisplayTick(var1, var2, var3, var4);
      int var5 = -"  ".length();

      do {
         if (var5 > "  ".length()) {
            return;
         }

         int var6 = -"  ".length();

         while(var6 <= "  ".length()) {
            if (var5 > -"  ".length() && var5 < "  ".length() && var6 == -" ".length()) {
               var6 = "  ".length();
            }

            if (var4.nextInt(110 ^ 126) == 0) {
               int var7 = "".length();

               while(var7 <= " ".length()) {
                  BlockPos var8 = var3.add(var5, var7, var6);
                  if (var2.getBlockState(var8).getBlock() == Blocks.BOOKSHELF) {
                     if (!var2.isAirBlock(var3.add(var5 / "  ".length(), "".length(), var6 / "  ".length()))) {
                        "".length();
                        if (2 <= -1) {
                           throw null;
                        }
                        break;
                     }

                     EnumParticleTypes var10001 = EnumParticleTypes.ENCHANTMENT_TABLE;
                     double var10002 = (double)var3.getX() + 0.5D;
                     double var10003 = (double)var3.getY() + 2.0D;
                     double var10004 = (double)var3.getZ() + 0.5D;
                     double var10005 = (double)((float)var5 + var4.nextFloat());
                     I["".length()].length();
                     var10005 -= 0.5D;
                     float var10006 = (float)var7;
                     float var10007 = var4.nextFloat();
                     I[" ".length()].length();
                     I["  ".length()].length();
                     var10006 -= var10007;
                     I["   ".length()].length();
                     I[37 ^ 33].length();
                     double var9 = (double)(var10006 - 1.0F);
                     double var10 = (double)((float)var6 + var4.nextFloat());
                     I[191 ^ 186].length();
                     I[112 ^ 118].length();
                     var2.spawnParticle(var10001, var10002, var10003, var10004, var10005, var9, var10 - 0.5D);
                  }

                  ++var7;
                  "".length();
                  if (1 >= 3) {
                     throw null;
                  }
               }
            }

            ++var6;
            "".length();
            if (3 >= 4) {
               throw null;
            }
         }

         ++var5;
         "".length();
      } while(4 >= 4);

      throw null;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      super.onBlockPlacedBy(var1, var2, var3, var4, var5);
      if (var5.hasDisplayName()) {
         TileEntity var6 = var1.getTileEntity(var2);
         if (var6 instanceof TileEntityEnchantmentTable) {
            ((TileEntityEnchantmentTable)var6).setCustomName(var5.getDisplayName());
         }
      }

   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[99 ^ 100];
      String var10001 = I[189 ^ 181];
      String var10002 = I[92 ^ 85];
      var10001 = I[203 ^ 193];
      I[147 ^ 152].length();
      return new TileEntityEnchantmentTable();
   }
}

package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockSign extends BlockContainer {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB SIGN_AABB;

   public Item getItemDropped(IBlockState var1, Random var2, int var3) {
      return Items.SIGN;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[171 ^ 175].length();
      I[93 ^ 88].length();
      return new TileEntitySign();
   }

   public boolean canSpawnInBlock() {
      return (boolean)" ".length();
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var10000;
      if (!this.hasInvalidNeighbor(var1, var2) && super.canPlaceBlockAt(var1, var2)) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   static {
      I();
      SIGN_AABB = new AxisAlignedBB(0.25D, 0.0D, 0.25D, 0.75D, 1.0D, 0.75D);
   }

   public ItemStack getItem(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I[139 ^ 141];
      String var10001 = I[74 ^ 77];
      String var10002 = I[102 ^ 110];
      var10001 = I[160 ^ 169];
      I[33 ^ 43].length();
      I[147 ^ 152].length();
      return new ItemStack(Items.SIGN);
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         TileEntity var10 = var1.getTileEntity(var2);
         int var10000;
         if (var10 instanceof TileEntitySign) {
            var10000 = ((TileEntitySign)var10).executeCommand(var4);
            "".length();
            if (0 >= 4) {
               throw null;
            }
         } else {
            var10000 = "".length();
         }

         return (boolean)var10000;
      }
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return SIGN_AABB;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      return (boolean)" ".length();
   }

   protected BlockSign() {
      super(Material.WOOD);
   }

   private static void I() {
      I = new String[79 ^ 67];
      I["".length()] = I("媳廅", "ppvlJ");
      I[" ".length()] = I("崟左", "FGfWi");
      I["  ".length()] = I("斴櫬", "KBaLi");
      I["   ".length()] = I("涗倥", "vOkvI");
      I[149 ^ 145] = I("枬嶪", "itMqv");
      I[51 ^ 54] = I("寪兼", "ovHOJ");
      I[183 ^ 177] = I("潏欋", "JkaeE");
      I[145 ^ 150] = I("惍淴", "DfpfR");
      I[158 ^ 150] = I("堼垌", "BbXMH");
      I[105 ^ 96] = I("滞憠", "nHwha");
      I[205 ^ 199] = I("撤", "RFapB");
      I[28 ^ 23] = I("朻挧", "phgxA");
   }

   public boolean func_190946_v(IBlockState var1) {
      return (boolean)" ".length();
   }
}

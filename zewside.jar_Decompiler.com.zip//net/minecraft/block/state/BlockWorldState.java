package net.minecraft.block.state;

import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockWorldState {
   // $FF: synthetic field
   private final boolean forceLoad;
   // $FF: synthetic field
   private boolean tileEntityInitialized;
   // $FF: synthetic field
   private final BlockPos pos;
   // $FF: synthetic field
   private final World world;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private IBlockState state;
   // $FF: synthetic field
   private TileEntity tileEntity;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   static {
      I();
   }

   public BlockWorldState(World var1, BlockPos var2, boolean var3) {
      this.world = var1;
      this.pos = var2;
      this.forceLoad = var3;
   }

   public static Predicate<BlockWorldState> hasState(final Predicate<IBlockState> var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[190 ^ 186].length();
      I[131 ^ 134].length();
      return new Predicate<BlockWorldState>() {
         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(-1 < 3);

            throw null;
         }

         public boolean apply(@Nullable BlockWorldState var1) {
            int var10000;
            if (var1 != null && var0.apply(var1.getBlockState())) {
               var10000 = " ".length();
               "".length();
               if (false) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         }
      };
   }

   @Nullable
   public TileEntity getTileEntity() {
      if (this.tileEntity == null && !this.tileEntityInitialized) {
         this.tileEntity = this.world.getTileEntity(this.pos);
         this.tileEntityInitialized = (boolean)" ".length();
      }

      return this.tileEntity;
   }

   private static void I() {
      I = new String[50 ^ 52];
      I["".length()] = I("懪汇", "eugiZ");
      I[" ".length()] = I("夓剭", "GDbqq");
      I["  ".length()] = I("卒樟", "SKmEb");
      I["   ".length()] = I("儒堓", "zADgb");
      I[117 ^ 113] = I("搝", "pLvGv");
      I[17 ^ 20] = I("娡浽", "LeLQT");
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public IBlockState getBlockState() {
      if (this.state == null && (this.forceLoad || this.world.isBlockLoaded(this.pos))) {
         this.state = this.world.getBlockState(this.pos);
      }

      return this.state;
   }
}

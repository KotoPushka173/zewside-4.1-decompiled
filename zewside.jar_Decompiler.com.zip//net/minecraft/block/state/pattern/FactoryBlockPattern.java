package net.minecraft.block.state.pattern;

import com.google.common.base.Joiner;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.block.state.BlockWorldState;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

public class FactoryBlockPattern {
   // $FF: synthetic field
   private final List<String[]> depth = Lists.newArrayList();
   // $FF: synthetic field
   private int rowWidth;
   // $FF: synthetic field
   private static final Joiner COMMA_JOIN;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private final Map<Character, Predicate<BlockWorldState>> symbolMap = Maps.newHashMap();
   // $FF: synthetic field
   private int aisleHeight;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   private void checkMissingPredicates() {
      String var10000 = I[61 ^ 99];
      String var10001 = I[4 ^ 91];
      String var10002 = I[234 ^ 138];
      var10001 = I[67 ^ 34];
      var10000 = I[7 ^ 101];
      var10001 = I[96 ^ 3];
      var10002 = I[7 ^ 99];
      var10001 = I[19 ^ 118];
      ArrayList var1 = Lists.newArrayList();
      Iterator var2 = this.symbolMap.entrySet().iterator();

      do {
         if (!var2.hasNext()) {
            if (!var1.isEmpty()) {
               I[90 ^ 51].length();
               I[33 ^ 75].length();
               I[37 ^ 78].length();
               I[201 ^ 165].length();
               I[170 ^ 199].length();
               I[219 ^ 181].length();
               I[19 ^ 124].length();
               IllegalStateException var4 = new IllegalStateException(I[49 ^ 65] + COMMA_JOIN.join(var1) + I[105 ^ 24]);
               I[97 ^ 19].length();
               I[226 ^ 145].length();
               I[70 ^ 50].length();
               throw var4;
            }

            return;
         }

         Entry var3 = (Entry)var2.next();
         if (var3.getValue() == null) {
            var1.add(var3.getKey());
            I[12 ^ 106].length();
            I[236 ^ 139].length();
            I[111 ^ 7].length();
         }

         "".length();
      } while(2 != 0);

      throw null;
   }

   public FactoryBlockPattern where(char var1, Predicate<BlockWorldState> var2) {
      this.symbolMap.put(var1, var2);
      I[159 ^ 160].length();
      I[192 ^ 128].length();
      I[130 ^ 195].length();
      I[60 ^ 126].length();
      return this;
   }

   public static FactoryBlockPattern start() {
      String var10000 = I[254 ^ 198];
      String var10001 = I[159 ^ 166];
      String var10002 = I[39 ^ 29];
      var10001 = I[22 ^ 45];
      I[145 ^ 173].length();
      I[148 ^ 169].length();
      I[145 ^ 175].length();
      return new FactoryBlockPattern();
   }

   static {
      I();
      COMMA_JOIN = Joiner.on(I[24 ^ 109]);
   }

   private FactoryBlockPattern() {
      this.symbolMap.put(Character.valueOf((char)('¬' ^ '\u008c')), Predicates.alwaysTrue());
   }

   private Predicate<BlockWorldState>[][][] makePredicateArray() {
      String var10000 = I[64 ^ 11];
      String var10001 = I[121 ^ 53];
      String var10002 = I[47 ^ 98];
      var10001 = I[120 ^ 54];
      var10000 = I[49 ^ 126];
      var10001 = I[10 ^ 90];
      var10002 = I[31 ^ 78];
      var10001 = I[58 ^ 104];
      var10000 = I[235 ^ 184];
      var10001 = I[206 ^ 154];
      var10002 = I[113 ^ 36];
      var10001 = I[60 ^ 106];
      this.checkMissingPredicates();
      int[] var5 = new int["   ".length()];
      I[7 ^ 80].length();
      I[40 ^ 112].length();
      I[52 ^ 109].length();
      var5["".length()] = this.depth.size();
      I[12 ^ 86].length();
      I[105 ^ 50].length();
      I[227 ^ 191].length();
      var5[" ".length()] = this.aisleHeight;
      I[60 ^ 97].length();
      var5["  ".length()] = this.rowWidth;
      Predicate[][][] var1 = (Predicate[][][])((Predicate[][][])((Predicate[][][])Array.newInstance(Predicate.class, var5)));
      int var2 = "".length();

      do {
         if (var2 >= this.depth.size()) {
            return var1;
         }

         int var3 = "".length();

         while(var3 < this.aisleHeight) {
            int var4 = "".length();

            while(var4 < this.rowWidth) {
               var1[var2][var3][var4] = (Predicate)this.symbolMap.get(((String[])((String[])this.depth.get(var2)))[var3].charAt(var4));
               ++var4;
               "".length();
               if (2 <= 1) {
                  throw null;
               }
            }

            ++var3;
            "".length();
            if (4 == 1) {
               throw null;
            }
         }

         ++var2;
         "".length();
      } while(true);

      throw null;
   }

   public FactoryBlockPattern aisle(String... var1) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[39 ^ 35];
      var10001 = I[154 ^ 159];
      var10002 = I[125 ^ 123];
      var10001 = I[23 ^ 16];
      var10000 = I[33 ^ 41];
      var10001 = I[95 ^ 86];
      var10002 = I[42 ^ 32];
      var10001 = I[86 ^ 93];
      var10000 = I[98 ^ 110];
      var10001 = I[134 ^ 139];
      var10002 = I[175 ^ 161];
      var10001 = I[61 ^ 50];
      var10000 = I[104 ^ 120];
      var10001 = I[136 ^ 153];
      var10002 = I[1 ^ 19];
      var10001 = I[147 ^ 128];
      IllegalArgumentException var10;
      if (!ArrayUtils.isEmpty((Object[])var1) && !StringUtils.isEmpty(var1["".length()])) {
         if (this.depth.isEmpty()) {
            this.aisleHeight = var1.length;
            this.rowWidth = var1["".length()].length();
         }

         if (var1.length != this.aisleHeight) {
            I[65 ^ 85].length();
            I[162 ^ 183].length();
            I[189 ^ 171].length();
            I[117 ^ 98].length();
            I[116 ^ 108].length();
            var10 = new IllegalArgumentException(I[33 ^ 56] + this.aisleHeight + I[104 ^ 114] + var1.length + I[120 ^ 99]);
            I[12 ^ 16].length();
            I[72 ^ 85].length();
            I[85 ^ 75].length();
            throw var10;
         } else {
            String[] var2 = var1;
            int var3 = var1.length;
            int var4 = "".length();

            do {
               if (var4 >= var3) {
                  this.depth.add(var1);
                  I[139 ^ 164].length();
                  I[32 ^ 16].length();
                  return this;
               }

               String var5 = var2[var4];
               if (var5.length() != this.rowWidth) {
                  I[25 ^ 6].length();
                  I[73 ^ 105].length();
                  I[148 ^ 181].length();
                  I[136 ^ 170].length();
                  I[50 ^ 17].length();
                  I[189 ^ 153].length();
                  var10 = new IllegalArgumentException(I[22 ^ 51] + this.rowWidth + I[229 ^ 195] + var5.length() + I[92 ^ 123]);
                  I[64 ^ 104].length();
                  I[236 ^ 197].length();
                  I[142 ^ 164].length();
                  throw var10;
               }

               char[] var6 = var5.toCharArray();
               int var7 = var6.length;
               int var8 = "".length();

               while(var8 < var7) {
                  char var9 = var6[var8];
                  if (!this.symbolMap.containsKey(var9)) {
                     this.symbolMap.put(var9, (Object)null);
                     I[47 ^ 4].length();
                     I[72 ^ 100].length();
                     I[88 ^ 117].length();
                     I[158 ^ 176].length();
                  }

                  ++var8;
                  "".length();
                  if (2 <= -1) {
                     throw null;
                  }
               }

               ++var4;
               "".length();
            } while(1 > 0);

            throw null;
         }
      } else {
         I[1 ^ 48].length();
         I[27 ^ 41].length();
         I[24 ^ 43].length();
         var10 = new IllegalArgumentException(I[36 ^ 16]);
         I[158 ^ 171].length();
         I[15 ^ 57].length();
         I[71 ^ 112].length();
         throw var10;
      }
   }

   private static void I() {
      I = new String[92 ^ 42];
      I["".length()] = I("吵斟", "KwOIO");
      I[" ".length()] = I("掚楫", "uzkUb");
      I["  ".length()] = I("奥夒", "asKjY");
      I["   ".length()] = I("卻揢", "cDiZK");
      I[41 ^ 45] = I("棭撬", "EJydP");
      I[193 ^ 196] = I("巹唕", "bOfTK");
      I[110 ^ 104] = I("堳斛", "GWQkg");
      I[7 ^ 0] = I("墽喲", "ASZvD");
      I[4 ^ 12] = I("傖淛", "mPiot");
      I[59 ^ 50] = I("烙奖", "iaIaz");
      I[41 ^ 35] = I("尉朞", "ixzTu");
      I[169 ^ 162] = I("刿卨", "PMBYK");
      I[57 ^ 53] = I("浬愷", "wAYVY");
      I[73 ^ 68] = I("惟努", "IBhmQ");
      I[177 ^ 191] = I("巬漲", "lYDdz");
      I[126 ^ 113] = I("初搔", "iFFwC");
      I[128 ^ 144] = I("楤摐", "xKZGF");
      I[65 ^ 80] = I("券怪", "wbkqy");
      I[86 ^ 68] = I("圕帙", "ptEWX");
      I[59 ^ 40] = I("梭懍", "rDHTE");
      I[85 ^ 65] = I("洊塟欇", "SfmDL");
      I[53 ^ 32] = I("握", "TJyvm");
      I[77 ^ 91] = I("楸", "OeAbO");
      I[58 ^ 45] = I("淭", "mlfVF");
      I[185 ^ 161] = I("姁埆楯届", "JWNQs");
      I[57 ^ 32] = I("3)<50\u00024(p2\u001f\" 5s\u0001888s\u001e4%7;\u0002q#6s", "vQLPS");
      I[221 ^ 199] = I("@x\u0018\u001f\u0011L/\u001b\u0019E\u000b1\f\u000f\u000bL7\u0014\u000fE\u001b1\u000e\u0002E\rx\u0012\u000f\f\u000b0\u000eJ\n\nx", "lXzje");
      I[50 ^ 41] = I("}", "ThdoN");
      I[23 ^ 11] = I("厎枵亓柨孮", "uEQJK");
      I[134 ^ 155] = I("湨椑", "GOuHM");
      I[63 ^ 33] = I("垑哻兘", "gtodo");
      I[113 ^ 110] = I("劊侯曖", "ujjXK");
      I[12 ^ 44] = I("櫸亇俪垹", "xRPXE");
      I[0 ^ 33] = I("浈炿淩", "aQsvd");
      I[73 ^ 107] = I("姑借完发偠", "kNCUR");
      I[47 ^ 12] = I("壸厂尌", "vVuUg");
      I[136 ^ 172] = I("呙刽檿午", "QLfBh");
      I[122 ^ 95] = I(";\u001e\u0000M5\u0019\u001dT\u001f;\u0002\u0002T\u0004:U\u0005\u001c\bt\u0012\u0018\u0002\b:U\u0010\u001d\u001e8\u0010Q\u0015\u001f1U\u0005\u001c\bt\u0016\u001e\u0006\u001f1\u0016\u0005T\u001a=\u0011\u0005\u001cM|\u0010\t\u0004\b7\u0001\u0014\u0010M", "uqtmT");
      I[114 ^ 84] = I("VV\u0016&>\u0014\u0012P&%\u001fV\u0007 ?\u0012V", "zvpIK");
      I[151 ^ 176] = I("A", "hymRr");
      I[113 ^ 89] = I("慢", "IBRnY");
      I[138 ^ 163] = I("彺晫佥", "kJrbk");
      I[112 ^ 90] = I("噥烯敥剕振", "oarJv");
      I[234 ^ 193] = I("噪彐峥", "QyCow");
      I[46 ^ 2] = I("俧厉府懰婮", "sltIi");
      I[39 ^ 10] = I("瀧儜咟挖抺", "HQboH");
      I[88 ^ 118] = I("慄侸廯慕廃", "NAbuA");
      I[111 ^ 64] = I("檸攟掺", "QXSay");
      I[81 ^ 97] = I("搊潟圍", "RwKmh");
      I[190 ^ 143] = I("枒杳啙曂挘", "ZvbhV");
      I[171 ^ 153] = I("泮徇", "MrNkF");
      I[111 ^ 92] = I("叐專倖夜滷", "ROxzX");
      I[142 ^ 186] = I("0\u0003$'3U\u001e5'>\u0010\u001c:s,\u001a\u001ct2#\u0006\u00021", "unTSJ");
      I[71 ^ 114] = I("凣删栧昶", "koyIm");
      I[123 ^ 77] = I("暩俍壆仵", "WPomu");
      I[177 ^ 134] = I("垖掵偡浫価", "WxDkt");
      I[64 ^ 120] = I("兆岁", "YLUOG");
      I[165 ^ 156] = I("价廨", "ZrbAj");
      I[52 ^ 14] = I("囜涗", "FbhME");
      I[43 ^ 16] = I("埨媃", "CfDxK");
      I[147 ^ 175] = I("厂喖", "yiyuC");
      I[31 ^ 34] = I("圫榼慾", "hAkob");
      I[89 ^ 103] = I("渥槲儦拽", "SrQMD");
      I[106 ^ 85] = I("喩忇", "RymOR");
      I[28 ^ 92] = I("昦怢", "Hdsdw");
      I[20 ^ 85] = I("儐棋忀", "dYjvm");
      I[27 ^ 89] = I("婖媩", "LxuYJ");
      I[246 ^ 181] = I("憽浊", "lMXRu");
      I[36 ^ 96] = I("急堊", "FqIRR");
      I[72 ^ 13] = I("椱含", "fFEiK");
      I[107 ^ 45] = I("啲攁", "iARbf");
      I[239 ^ 168] = I("呌壤掲", "QMLCu");
      I[27 ^ 83] = I("槒样愂兽檋", "OrSdC");
      I[92 ^ 21] = I("橊摘", "XgxCq");
      I[225 ^ 171] = I("殧抽婐捏", "nPEHL");
      I[239 ^ 164] = I("娧卦", "evlvT");
      I[18 ^ 94] = I("晬换", "tRFIM");
      I[50 ^ 127] = I("毷嗲", "sbLIs");
      I[221 ^ 147] = I("杨札", "LCMom");
      I[194 ^ 141] = I("娲僼", "IhMLt");
      I[81 ^ 1] = I("功栿", "bjgiq");
      I[12 ^ 93] = I("湕樀", "XDDqm");
      I[235 ^ 185] = I("嬱淡", "HibsN");
      I[204 ^ 159] = I("澪僥", "UWqCI");
      I[78 ^ 26] = I("垣寋", "sGOct");
      I[108 ^ 57] = I("堎憄", "CYVkh");
      I[48 ^ 102] = I("噍拡", "JbVdX");
      I[60 ^ 107] = I("漹勷", "peYHX");
      I[159 ^ 199] = I("晌湀", "OiLxZ");
      I[155 ^ 194] = I("嗲朮批", "huZZL");
      I[211 ^ 137] = I("嘢", "FWBNZ");
      I[247 ^ 172] = I("夝冈潎曝樅", "fhIPb");
      I[215 ^ 139] = I("伸槫嘞愠", "tMTLT");
      I[57 ^ 100] = I("椾撲廟", "GsTQU");
      I[218 ^ 132] = I("涥峊", "kWPki");
      I[202 ^ 149] = I("洮斖", "czeOu");
      I[116 ^ 20] = I("慨渔", "GXFMC");
      I[203 ^ 170] = I("囵泺", "DZczn");
      I[208 ^ 178] = I("哭憴", "WoAtF");
      I[162 ^ 193] = I("夲嵾", "aMIjb");
      I[10 ^ 110] = I("涟劆", "dOmBY");
      I[47 ^ 74] = I("朆忦", "qEPvv");
      I[105 ^ 15] = I("娈", "nzxQh");
      I[33 ^ 70] = I("尗梠枩呦潙", "QwSpr");
      I[192 ^ 168] = I("朇敧押吼", "JgTKQ");
      I[76 ^ 37] = I("束", "GSPGg");
      I[10 ^ 96] = I("怿倌夞", "xnVrw");
      I[85 ^ 62] = I("倴嚟凜", "kbKpG");
      I[247 ^ 155] = I("忊前捒娪彽", "vTNei");
      I[244 ^ 153] = I("毰宪浣慝", "QpVSt");
      I[204 ^ 162] = I("噾", "PfNVK");
      I[251 ^ 148] = I("峺条堾", "TNVzD");
      I[123 ^ 11] = I("\u0014\u001b\u0006\u0001\"'\b\u0017\u00008d\u000f\f\u0017k'\u0001\u0002\u0017*'\u001d\u0006\u0017c7@C", "DiceK");
      I[12 ^ 125] = I("Y\u0003\u000b\bz\u0014\u000b\n\u001e3\u0017\u0005", "ybymZ");
      I[76 ^ 62] = I("夺溰實", "Rhnlq");
      I[107 ^ 24] = I("垢", "UhwdP");
      I[90 ^ 46] = I("夼塭", "cxAkx");
      I[20 ^ 97] = I("M", "aZqAV");
   }

   public BlockPattern build() {
      String var10000 = I[231 ^ 164];
      String var10001 = I[97 ^ 37];
      String var10002 = I[100 ^ 33];
      var10001 = I[58 ^ 124];
      I[58 ^ 125].length();
      I[83 ^ 27].length();
      I[210 ^ 155].length();
      I[222 ^ 148].length();
      return new BlockPattern(this.makePredicateArray());
   }
}

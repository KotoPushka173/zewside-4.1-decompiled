package net.minecraft.network;

import net.minecraft.util.IThreadListener;

public class PacketThreadUtil {
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   public static <T extends INetHandler> void checkThreadAndEnqueue(final Packet<T> var0, final T var1, IThreadListener var2) throws ThreadQuickExitException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (!var2.isCallingFromMinecraftThread()) {
         I[156 ^ 152].length();
         I[106 ^ 111].length();
         I[58 ^ 60].length();
         I[53 ^ 50].length();
         var2.addScheduledTask(new Runnable() {
            private static String I(String s, String s1) {
               StringBuilder sb = new StringBuilder();
               char[] key = s1.toCharArray();
               int i = "".length();
               char[] var5 = s.toCharArray();
               int var6 = var5.length;
               int var7 = "".length();

               do {
                  if (var7 >= var6) {
                     return sb.toString();
                  }

                  char c = var5[var7];
                  sb.append((char)(c ^ key[i % key.length]));
                  ++i;
                  ++var7;
                  "".length();
               } while(3 == 3);

               throw null;
            }

            public void run() {
               var0.processPacket(var1);
            }
         });
         I[0 ^ 8].length();
         I[23 ^ 30].length();
         I[137 ^ 131].length();
         ThreadQuickExitException var3 = ThreadQuickExitException.INSTANCE;
         I[95 ^ 84].length();
         I[143 ^ 131].length();
         I[11 ^ 6].length();
         throw var3;
      }
   }

   private static void I() {
      I = new String[49 ^ 63];
      I["".length()] = I("拒劈", "ZwsuU");
      I[" ".length()] = I("並军", "OCZzQ");
      I["  ".length()] = I("傄哶", "CXNlZ");
      I["   ".length()] = I("殻憏", "sgaEh");
      I[115 ^ 119] = I("汜幽哯摁", "pVcvu");
      I[171 ^ 174] = I("仴池", "CmMcw");
      I[153 ^ 159] = I("埆噩喞", "uyklu");
      I[179 ^ 180] = I("侺挜椊", "VKklR");
      I[133 ^ 141] = I("或旊仝庯", "WYtZz");
      I[96 ^ 105] = I("崂瀘", "WOFhk");
      I[127 ^ 117] = I("儳氢墈", "RujQt");
      I[48 ^ 59] = I("僿恛劍搌卽", "MiMON");
      I[115 ^ 127] = I("嘺欅株", "BHocN");
      I[81 ^ 92] = I("圻唀", "ViVxV");
   }

   static {
      I();
   }
}

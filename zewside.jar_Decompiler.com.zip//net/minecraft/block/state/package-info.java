package net.minecraft.block.state;

import javax.annotation.ParametersAreNonnullByDefault;
import mcp.MethodsReturnNonnullByDefault;

// $FF: synthetic class
@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
interface package-info {
}

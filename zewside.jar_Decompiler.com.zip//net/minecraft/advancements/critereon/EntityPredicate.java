package net.minecraft.advancements.critereon;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class EntityPredicate {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final EntityPredicate field_192483_a;
   // $FF: synthetic field
   private final ResourceLocation field_192484_b;
   // $FF: synthetic field
   private final MobEffectsPredicate field_193436_e;
   // $FF: synthetic field
   private final DistancePredicate field_192485_c;
   // $FF: synthetic field
   private final LocationPredicate field_193435_d;
   // $FF: synthetic field
   private final NBTPredicate field_193437_f;

   public EntityPredicate(@Nullable ResourceLocation var1, DistancePredicate var2, LocationPredicate var3, MobEffectsPredicate var4, NBTPredicate var5) {
      this.field_192484_b = var1;
      this.field_192485_c = var2;
      this.field_193435_d = var3;
      this.field_193436_e = var4;
      this.field_193437_f = var5;
   }

   private static void I() {
      I = new String[117 ^ 93];
      I["".length()] = I("丹榆", "BpbEP");
      I[" ".length()] = I("嶆坩", "FqSjf");
      I["  ".length()] = I("欓喸", "lTgpd");
      I["   ".length()] = I("徺侇", "NTHZP");
      I[155 ^ 159] = I("嘃励", "ulehQ");
      I[54 ^ 51] = I("帍湇", "nFiKS");
      I[18 ^ 20] = I("浞攩", "vksfT");
      I[14 ^ 9] = I("帙懎", "KxjhK");
      I[84 ^ 92] = I("徥嗥", "uuzsl");
      I[153 ^ 144] = I("垟凥", "NoATI");
      I[63 ^ 53] = I("哨倣", "DIhIm");
      I[145 ^ 154] = I("傌嘛", "KIzXy");
      I[90 ^ 86] = I("榉咎", "FubrG");
      I[188 ^ 177] = I("曝斯", "UdkaR");
      I[122 ^ 116] = I("擮婻", "vBoYN");
      I[26 ^ 21] = I("举氠", "sTrMj");
      I[64 ^ 80] = I("4\u000b\u00008;(", "QetQO");
      I[123 ^ 106] = I(",\f\u0000\u0004", "Xupax");
      I[122 ^ 104] = I("漰侬摝", "mxuCG");
      I[5 ^ 22] = I("榐沪搥", "kenNe");
      I[117 ^ 97] = I("杙抮匢摍毡", "jYUAm");
      I[54 ^ 35] = I(";\u000323", "OzBVf");
      I[77 ^ 91] = I("垆滋幁残婌", "fianw");
      I[163 ^ 180] = I("唣", "KMQkM");
      I[55 ^ 47] = I("檪庘峢", "xATcW");
      I[157 ^ 132] = I("殳", "Oyuil");
      I[69 ^ 95] = I("俴", "TmXtX");
      I[98 ^ 121] = I("漅榱湝忦", "ZQnPX");
      I[76 ^ 80] = I("挎冈", "ocpCF");
      I[115 ^ 110] = I("\u0002\"/\u0004> \"d\u000f?#%0\u0013q#54\u000fqp", "WLDjQ");
      I[16 ^ 14] = I("Vft#0\u001d#0u%\b:1&q\u001081oq", "qJTUQ");
      I[38 ^ 57] = I("楢姈", "LpuQH");
      I[75 ^ 107] = I("摿", "BFQeb");
      I[105 ^ 72] = I("\r\u0011\u001e80\u0007\u001b\b", "ixmLQ");
      I[12 ^ 46] = I("\n\u001d.\u00029\u000f\u001d#", "frMcM");
      I[149 ^ 182] = I("\u00044\u0001\"/\u0015!", "aRgGL");
      I[49 ^ 21] = I("'\u0005:", "IgNfr");
      I[102 ^ 67] = I("庀拢檗", "GLeWO");
      I[182 ^ 144] = I("孢", "cTzjf");
      I[162 ^ 133] = I("炭", "ufwOG");
   }

   public boolean func_192482_a(EntityPlayerMP var1, @Nullable Entity var2) {
      if (this == field_192483_a) {
         return (boolean)" ".length();
      } else if (var2 == null) {
         return (boolean)"".length();
      } else if (this.field_192484_b != null && !EntityList.isStringEntityName(var2, this.field_192484_b)) {
         return (boolean)"".length();
      } else if (!this.field_192485_c.func_193422_a(var1.posX, var1.posY, var1.posZ, var2.posX, var2.posY, var2.posZ)) {
         return (boolean)"".length();
      } else if (!this.field_193435_d.func_193452_a(var1.getServerWorld(), var2.posX, var2.posY, var2.posZ)) {
         return (boolean)"".length();
      } else {
         return (boolean)(!this.field_193436_e.func_193469_a(var2) ? "".length() : this.field_193437_f.func_193475_a(var2));
      }
   }

   static {
      I();
      field_192483_a = new EntityPredicate((ResourceLocation)null, DistancePredicate.field_193423_a, LocationPredicate.field_193455_a, MobEffectsPredicate.field_193473_a, NBTPredicate.field_193479_a);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(0 != 2);

      throw null;
   }

   public static EntityPredicate func_192481_a(@Nullable JsonElement var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[141 ^ 137];
      var10001 = I[115 ^ 118];
      var10002 = I[190 ^ 184];
      var10001 = I[78 ^ 73];
      var10000 = I[45 ^ 37];
      var10001 = I[72 ^ 65];
      var10002 = I[34 ^ 40];
      var10001 = I[116 ^ 127];
      var10000 = I[131 ^ 143];
      var10001 = I[108 ^ 97];
      var10002 = I[55 ^ 57];
      var10001 = I[171 ^ 164];
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = JsonUtils.getJsonObject(var0, I[65 ^ 81]);
         ResourceLocation var2 = null;
         if (var1.has(I[190 ^ 175])) {
            I[121 ^ 107].length();
            I[62 ^ 45].length();
            I[92 ^ 72].length();
            var2 = new ResourceLocation(JsonUtils.getString(var1, I[11 ^ 30]));
            if (!EntityList.isStringValidEntityName(var2)) {
               I[43 ^ 61].length();
               I[124 ^ 107].length();
               I[76 ^ 84].length();
               I[50 ^ 43].length();
               I[154 ^ 128].length();
               I[104 ^ 115].length();
               I[219 ^ 199].length();
               JsonSyntaxException var7 = new JsonSyntaxException(I[9 ^ 20] + var2 + I[52 ^ 42] + EntityList.func_192840_b());
               I[94 ^ 65].length();
               I[111 ^ 79].length();
               throw var7;
            }
         }

         DistancePredicate var3 = DistancePredicate.func_193421_a(var1.get(I[28 ^ 61]));
         LocationPredicate var4 = LocationPredicate.func_193454_a(var1.get(I[188 ^ 158]));
         MobEffectsPredicate var5 = MobEffectsPredicate.func_193471_a(var1.get(I[167 ^ 132]));
         NBTPredicate var6 = NBTPredicate.func_193476_a(var1.get(I[174 ^ 138]));
         I[128 ^ 165].length();
         I[115 ^ 85].length();
         I[5 ^ 34].length();
         return new EntityPredicate(var2, var3, var4, var5, var6);
      } else {
         return field_192483_a;
      }
   }
}

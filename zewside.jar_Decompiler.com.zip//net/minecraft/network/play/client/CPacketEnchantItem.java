package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketEnchantItem implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private int windowId;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int button;

   static {
      I();
   }

   public int getWindowId() {
      return this.windowId;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.windowId = var1.readByte();
      this.button = var1.readByte();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.windowId);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeByte(this.button);
      I[189 ^ 185].length();
      I[21 ^ 16].length();
   }

   private static void I() {
      I = new String[39 ^ 33];
      I["".length()] = I("墸彿煔", "LaWFd");
      I[" ".length()] = I("栾档櫴暫墠", "OuwLj");
      I["  ".length()] = I("姆惙栢", "puSQS");
      I["   ".length()] = I("捯澣戎", "vvuzC");
      I[101 ^ 97] = I("嬀扪旌墛", "mHaUe");
      I[191 ^ 186] = I("亐伧", "gHPjE");
   }

   public int getButton() {
      return this.button;
   }

   public CPacketEnchantItem(int var1, int var2) {
      this.windowId = var1;
      this.button = var2;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 0);

      throw null;
   }

   public CPacketEnchantItem() {
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processEnchantItem(this);
   }
}

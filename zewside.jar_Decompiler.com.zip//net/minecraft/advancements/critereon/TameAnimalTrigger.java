package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;

public class TameAnimalTrigger implements ICriterionTrigger<TameAnimalTrigger.Instance> {
   // $FF: synthetic field
   private final Map<PlayerAdvancements, TameAnimalTrigger.Listeners> field_193180_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final ResourceLocation field_193179_a;
   // $FF: synthetic field
   private static final String[] I;

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<TameAnimalTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      TameAnimalTrigger.Listeners var3 = (TameAnimalTrigger.Listeners)this.field_193180_b.get(var1);
      if (var3 == null) {
         I[71 ^ 67].length();
         I[158 ^ 155].length();
         I[52 ^ 50].length();
         I[142 ^ 137].length();
         var3 = new TameAnimalTrigger.Listeners(var1);
         this.field_193180_b.put(var1, var3);
         I[111 ^ 103].length();
         I[83 ^ 90].length();
      }

      var3.func_193496_a(var2);
   }

   private static void I() {
      I = new String[79 ^ 82];
      I["".length()] = I("庥漌", "mYneS");
      I[" ".length()] = I("崞匤", "UdQEf");
      I["  ".length()] = I("梛毟", "RYGZl");
      I["   ".length()] = I("欛咜", "ZejhG");
      I[105 ^ 109] = I("庌栅", "TRtAN");
      I[179 ^ 182] = I("枤拉椠悴倫", "PzLNN");
      I[5 ^ 3] = I("滤咸嫣", "NVkps");
      I[173 ^ 170] = I("巪欳殓厝", "lTboF");
      I[70 ^ 78] = I("宫汬殽", "RNEpg");
      I[119 ^ 126] = I("坿", "ZipKV");
      I[204 ^ 198] = I("溃", "MJzli");
      I[83 ^ 88] = I("姮乒枔", "nwbwx");
      I[87 ^ 91] = I("厵忸漙", "ckxSj");
      I[78 ^ 67] = I("嚢槲", "TqAnB");
      I[94 ^ 80] = I("烲保", "tJTAV");
      I[92 ^ 83] = I("慩故", "PMoqg");
      I[12 ^ 28] = I("偷", "YYqqJ");
      I[175 ^ 190] = I("娰侖", "tTIqq");
      I[87 ^ 69] = I("仢倷", "FHNQJ");
      I[189 ^ 174] = I("浍歛", "BBdJw");
      I[162 ^ 182] = I("庞上", "hlPTa");
      I[176 ^ 165] = I("囜氿", "QjWtv");
      I[60 ^ 42] = I("4\b\u0013\f\u001a(", "Qfgen");
      I[163 ^ 180] = I("忔暩擤匕瀁", "yyKPB");
      I[137 ^ 145] = I("瀡抵", "nNHBS");
      I[121 ^ 96] = I("娸倉", "nKykH");
      I[180 ^ 174] = I("榌彄", "ZxSAu");
      I[132 ^ 159] = I("啫凛嗆宲", "UGOUf");
      I[168 ^ 180] = I("\u000e68-\t\u001b9<%7\u0016", "zWUHV");
   }

   public TameAnimalTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[14 ^ 28];
      String var10001 = I[143 ^ 156];
      String var10002 = I[210 ^ 198];
      var10001 = I[129 ^ 148];
      EntityPredicate var3 = EntityPredicate.func_192481_a(var1.get(I[49 ^ 39]));
      I[96 ^ 119].length();
      I[186 ^ 162].length();
      I[134 ^ 159].length();
      I[132 ^ 158].length();
      I[84 ^ 79].length();
      return new TameAnimalTrigger.Instance(var3);
   }

   public void func_193178_a(EntityPlayerMP var1, EntityAnimal var2) {
      TameAnimalTrigger.Listeners var3 = (TameAnimalTrigger.Listeners)this.field_193180_b.get(var1.func_192039_O());
      if (var3 != null) {
         var3.func_193497_a(var1, var2);
      }

   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_193180_b.remove(var1);
      I[191 ^ 177].length();
      I[174 ^ 161].length();
      I[8 ^ 24].length();
      I[80 ^ 65].length();
   }

   public ResourceLocation func_192163_a() {
      return field_193179_a;
   }

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<TameAnimalTrigger.Instance> var2) {
      TameAnimalTrigger.Listeners var3 = (TameAnimalTrigger.Listeners)this.field_193180_b.get(var1);
      if (var3 != null) {
         var3.func_193494_b(var2);
         if (var3.func_193495_a()) {
            this.field_193180_b.remove(var1);
            I[158 ^ 148].length();
            I[116 ^ 127].length();
            I[108 ^ 96].length();
            I[187 ^ 182].length();
         }
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 > 0);

      throw null;
   }

   static {
      I();
      field_193179_a = new ResourceLocation(I[105 ^ 117]);
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final EntityPredicate field_193217_a;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 >= 1);

         throw null;
      }

      public boolean func_193216_a(EntityPlayerMP var1, EntityAnimal var2) {
         return this.field_193217_a.func_192482_a(var1, var2);
      }

      public Instance(EntityPredicate var1) {
         super(TameAnimalTrigger.field_193179_a);
         this.field_193217_a = var1;
      }
   }

   static class Listeners {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final PlayerAdvancements field_193498_a;
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<TameAnimalTrigger.Instance>> field_193499_b = Sets.newHashSet();

      public void func_193497_a(EntityPlayerMP var1, EntityAnimal var2) {
         ArrayList var3 = null;
         Iterator var4 = this.field_193499_b.iterator();

         ICriterionTrigger.Listener var5;
         while(var4.hasNext()) {
            var5 = (ICriterionTrigger.Listener)var4.next();
            if (((TameAnimalTrigger.Instance)var5.func_192158_a()).func_193216_a(var1, var2)) {
               if (var3 == null) {
                  var3 = Lists.newArrayList();
               }

               var3.add(var5);
               I[156 ^ 148].length();
               I[50 ^ 59].length();
            }

            "".length();
            if (-1 >= 0) {
               throw null;
            }
         }

         if (var3 != null) {
            var4 = var3.iterator();

            while(var4.hasNext()) {
               var5 = (ICriterionTrigger.Listener)var4.next();
               var5.func_192159_a(this.field_193498_a);
               "".length();
               if (4 <= 2) {
                  throw null;
               }
            }
         }

      }

      public Listeners(PlayerAdvancements var1) {
         this.field_193498_a = var1;
      }

      public void func_193496_a(ICriterionTrigger.Listener<TameAnimalTrigger.Instance> var1) {
         this.field_193499_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }

      static {
         I();
      }

      private static void I() {
         I = new String[108 ^ 102];
         I["".length()] = I("嵟呱浓", "CsYMF");
         I[" ".length()] = I("樬", "bWWsu");
         I["  ".length()] = I("扩慣", "gWnqD");
         I["   ".length()] = I("昻匼剦嬱嫡", "WXZca");
         I[10 ^ 14] = I("婫丹炣僃", "GOQBE");
         I[149 ^ 144] = I("匶", "ZdbqO");
         I[95 ^ 89] = I("宂溭旴", "puFYM");
         I[66 ^ 69] = I("歓", "BrHLz");
         I[48 ^ 56] = I("亿怛戟", "njAwr");
         I[89 ^ 80] = I("匪", "wKKDf");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 != -1);

         throw null;
      }

      public void func_193494_b(ICriterionTrigger.Listener<TameAnimalTrigger.Instance> var1) {
         this.field_193499_b.remove(var1);
         I[28 ^ 24].length();
         I[91 ^ 94].length();
         I[19 ^ 21].length();
         I[22 ^ 17].length();
      }

      public boolean func_193495_a() {
         return this.field_193499_b.isEmpty();
      }
   }
}

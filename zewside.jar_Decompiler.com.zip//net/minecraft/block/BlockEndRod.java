package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockEndRod extends BlockDirectional {
   // $FF: synthetic field
   protected static final AxisAlignedBB END_ROD_EW_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB END_ROD_NS_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB END_ROD_VERTICAL_AABB;

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      return (boolean)" ".length();
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var2 = this.getDefaultState();
      var2 = var2.withProperty(FACING, EnumFacing.getFront(var1));
      return var2;
   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      switch(null.$SwitchMap$net$minecraft$util$EnumFacing$Axis[((EnumFacing)var1.getValue(FACING)).getAxis().ordinal()]) {
      case 1:
      default:
         return END_ROD_EW_AABB;
      case 2:
         return END_ROD_NS_AABB;
      case 3:
         return END_ROD_VERTICAL_AABB;
      }
   }

   static {
      I();
      END_ROD_VERTICAL_AABB = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 1.0D, 0.625D);
      END_ROD_NS_AABB = new AxisAlignedBB(0.375D, 0.375D, 0.0D, 0.625D, 0.625D, 1.0D);
      END_ROD_EW_AABB = new AxisAlignedBB(0.0D, 0.375D, 0.375D, 1.0D, 0.625D, 0.625D);
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[2 ^ 11];
      String var10001 = I[177 ^ 187];
      String var10002 = I[206 ^ 197];
      var10001 = I[55 ^ 59];
      var10000 = I[36 ^ 41];
      var10001 = I[66 ^ 76];
      var10002 = I[13 ^ 2];
      var10001 = I[62 ^ 46];
      I[63 ^ 46].length();
      I[163 ^ 177].length();
      I[63 ^ 44].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[112 ^ 100].length();
      var10003["".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   public EnumPushReaction getMobilityFlag(IBlockState var1) {
      return EnumPushReaction.NORMAL;
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      EnumFacing var5 = (EnumFacing)var1.getValue(FACING);
      double var10000 = (double)var3.getX() + 0.55D;
      double var10001 = (double)(var4.nextFloat() * 0.1F);
      I["".length()].length();
      double var6 = var10000 - var10001;
      var10000 = (double)var3.getY() + 0.55D;
      var10001 = (double)(var4.nextFloat() * 0.1F);
      I[" ".length()].length();
      I["  ".length()].length();
      double var8 = var10000 - var10001;
      var10000 = (double)var3.getZ() + 0.55D;
      var10001 = (double)(var4.nextFloat() * 0.1F);
      I["   ".length()].length();
      I[166 ^ 162].length();
      double var10 = var10000 - var10001;
      float var14 = (var4.nextFloat() + var4.nextFloat()) * 0.4F;
      I[119 ^ 114].length();
      I[170 ^ 172].length();
      I[147 ^ 148].length();
      I[47 ^ 39].length();
      double var12 = (double)(0.4F - var14);
      if (var4.nextInt(139 ^ 142) == 0) {
         var2.spawnParticle(EnumParticleTypes.END_ROD, var6 + (double)var5.getFrontOffsetX() * var12, var8 + (double)var5.getFrontOffsetY() * var12, var10 + (double)var5.getFrontOffsetZ() * var12, var4.nextGaussian() * 0.005D, var4.nextGaussian() * 0.005D, var4.nextGaussian() * 0.005D);
      }

   }

   protected BlockEndRod() {
      super(Material.CIRCUITS);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.UP));
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withProperty(FACING, var2.mirror((EnumFacing)var1.getValue(FACING)));
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumFacing)var1.getValue(FACING)).getIndex();
   }

   private static void I() {
      I = new String[93 ^ 72];
      I["".length()] = I("囜兞煡", "jmKYP");
      I[" ".length()] = I("煊撧廉姳", "KHStc");
      I["  ".length()] = I("氁敏厾嗕", "XDdKf");
      I["   ".length()] = I("峯楂湦", "FZjAJ");
      I[1 ^ 5] = I("嚯榒撧", "ERSjW");
      I[68 ^ 65] = I("徛佾槇垘", "MaRwQ");
      I[153 ^ 159] = I("恳", "dODjf");
      I[39 ^ 32] = I("唡", "zkVpp");
      I[184 ^ 176] = I("忬娮哅", "HhniN");
      I[114 ^ 123] = I("慬濱", "FRgFv");
      I[172 ^ 166] = I("吮孷", "pYxWn");
      I[186 ^ 177] = I("况埰", "wDExM");
      I[86 ^ 90] = I("橇慳", "SmOUA");
      I[11 ^ 6] = I("湓冄", "OhHDV");
      I[70 ^ 72] = I("沲湁", "SFbhl");
      I[9 ^ 6] = I("宧呓", "isewe");
      I[99 ^ 115] = I("孄堟", "LOldT");
      I[54 ^ 39] = I("灬", "TIIOc");
      I[107 ^ 121] = I("墈", "vSPcc");
      I[85 ^ 70] = I("岇悺嗽", "OAWXi");
      I[162 ^ 182] = I("拿搋喃", "pvZtM");
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      IBlockState var9 = var1.getBlockState(var2.offset(var3.getOpposite()));
      if (var9.getBlock() == Blocks.END_ROD) {
         EnumFacing var10 = (EnumFacing)var9.getValue(FACING);
         if (var10 == var3) {
            return this.getDefaultState().withProperty(FACING, var3.getOpposite());
         }
      }

      return this.getDefaultState().withProperty(FACING, var3);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 >= 2);

      throw null;
   }
}

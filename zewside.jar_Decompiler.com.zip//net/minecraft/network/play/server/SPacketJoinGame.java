package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.GameType;
import net.minecraft.world.WorldType;

public class SPacketJoinGame implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int dimension;
   // $FF: synthetic field
   private GameType gameType;
   // $FF: synthetic field
   private boolean hardcoreMode;
   // $FF: synthetic field
   private WorldType worldType;
   // $FF: synthetic field
   private int playerId;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int maxPlayers;
   // $FF: synthetic field
   private boolean reducedDebugInfo;
   // $FF: synthetic field
   private EnumDifficulty difficulty;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 == 4);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.playerId = var1.readInt();
      short var2 = var1.readUnsignedByte();
      int var10001;
      if ((var2 & (10 ^ 2)) == (149 ^ 157)) {
         var10001 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10001 = "".length();
      }

      this.hardcoreMode = (boolean)var10001;
      int var3 = var2 & -(190 ^ 183);
      this.gameType = GameType.getByID(var3);
      this.dimension = var1.readInt();
      this.difficulty = EnumDifficulty.getDifficultyEnum(var1.readUnsignedByte());
      this.maxPlayers = var1.readUnsignedByte();
      this.worldType = WorldType.parseWorldType(var1.readStringFromBuffer(74 ^ 90));
      if (this.worldType == null) {
         this.worldType = WorldType.DEFAULT;
      }

      this.reducedDebugInfo = var1.readBoolean();
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleJoinGame(this);
   }

   public GameType getGameType() {
      return this.gameType;
   }

   public int getPlayerId() {
      return this.playerId;
   }

   private static void I() {
      I = new String[64 ^ 85];
      I["".length()] = I("刲峬晌嚩", "uNNTF");
      I[" ".length()] = I("厠杇勼儳", "HcsHq");
      I["  ".length()] = I("斉俠", "nqnmp");
      I["   ".length()] = I("婊原塳梕婁", "hybDD");
      I[162 ^ 166] = I("嵧呖", "WKrUr");
      I[98 ^ 103] = I("呡怙烤杬", "tLNZG");
      I[108 ^ 106] = I("堁漝焱煜幁", "qSroG");
      I[152 ^ 159] = I("兀刈淫", "SxnaY");
      I[23 ^ 31] = I("博", "Wkkjk");
      I[32 ^ 41] = I("烂儱徎嵭煉", "ivKsL");
      I[147 ^ 153] = I("摘榯宠拼", "zHHXi");
      I[87 ^ 92] = I("撌憊", "PnmHn");
      I[127 ^ 115] = I("淯浍", "RBCVn");
      I[113 ^ 124] = I("婇歆愄掅戾", "bKZlO");
      I[138 ^ 132] = I("丄媏嚩", "DfVOp");
      I[63 ^ 48] = I("搚凾惯樭", "orlLt");
      I[118 ^ 102] = I("沱慴", "EqNzj");
      I[179 ^ 162] = I("喕恍嚅", "vfknd");
      I[113 ^ 99] = I("承抆勯", "GHkJN");
      I[189 ^ 174] = I("偂幐汬", "UUBSn");
      I[157 ^ 137] = I("溮檎幂", "eCJvl");
   }

   public SPacketJoinGame() {
   }

   public SPacketJoinGame(int var1, GameType var2, boolean var3, int var4, EnumDifficulty var5, int var6, WorldType var7, boolean var8) {
      this.playerId = var1;
      this.dimension = var4;
      this.difficulty = var5;
      this.gameType = var2;
      this.maxPlayers = var6;
      this.hardcoreMode = var3;
      this.worldType = var7;
      this.reducedDebugInfo = var8;
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeInt(this.playerId);
      I["".length()].length();
      I[" ".length()].length();
      int var2 = this.gameType.getID();
      if (this.hardcoreMode) {
         var2 |= 22 ^ 30;
      }

      var1.writeByte(var2);
      I["  ".length()].length();
      I["   ".length()].length();
      I[154 ^ 158].length();
      I[100 ^ 97].length();
      var1.writeInt(this.dimension);
      I[89 ^ 95].length();
      I[180 ^ 179].length();
      I[187 ^ 179].length();
      I[127 ^ 118].length();
      var1.writeByte(this.difficulty.getDifficultyId());
      I[67 ^ 73].length();
      I[10 ^ 1].length();
      I[24 ^ 20].length();
      var1.writeByte(this.maxPlayers);
      I[118 ^ 123].length();
      I[82 ^ 92].length();
      I[131 ^ 140].length();
      var1.writeString(this.worldType.getWorldTypeName());
      I[172 ^ 188].length();
      I[140 ^ 157].length();
      I[148 ^ 134].length();
      var1.writeBoolean(this.reducedDebugInfo);
      I[64 ^ 83].length();
      I[81 ^ 69].length();
   }

   public EnumDifficulty getDifficulty() {
      return this.difficulty;
   }

   public boolean isReducedDebugInfo() {
      return this.reducedDebugInfo;
   }

   public WorldType getWorldType() {
      return this.worldType;
   }

   public int getDimension() {
      return this.dimension;
   }

   public boolean isHardcoreMode() {
      return this.hardcoreMode;
   }

   public int getMaxPlayers() {
      return this.maxPlayers;
   }
}

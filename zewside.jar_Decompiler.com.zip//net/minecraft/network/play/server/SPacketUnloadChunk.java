package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketUnloadChunk implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int z;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private int x;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeInt(this.x);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeInt(this.z);
      I["   ".length()].length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   private static void I() {
      I = new String[12 ^ 8];
      I["".length()] = I("挫旋壓嚢梋", "llaPg");
      I[" ".length()] = I("柶孝做微", "LNpQM");
      I["  ".length()] = I("泄峽医", "yHmIA");
      I["   ".length()] = I("氭桦御抣", "JcXfE");
   }

   public int getZ() {
      return this.z;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.x = var1.readInt();
      this.z = var1.readInt();
   }

   public SPacketUnloadChunk(int var1, int var2) {
      this.x = var1;
      this.z = var2;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.processChunkUnload(this);
   }

   static {
      I();
   }

   public int getX() {
      return this.x;
   }

   public SPacketUnloadChunk() {
   }
}

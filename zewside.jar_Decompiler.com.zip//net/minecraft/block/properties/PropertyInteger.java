package net.minecraft.block.properties;

import com.google.common.base.Optional;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.HashSet;

public class PropertyInteger extends PropertyHelper<Integer> {
   // $FF: synthetic field
   private final ImmutableSet<Integer> allowedValues;
   // $FF: synthetic field
   private static final String[] I;

   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)" ".length();
      } else if (var1 instanceof PropertyInteger && super.equals(var1)) {
         PropertyInteger var2 = (PropertyInteger)var1;
         return this.allowedValues.equals(var2.allowedValues);
      } else {
         return (boolean)"".length();
      }
   }

   protected PropertyInteger(String var1, int var2, int var3) {
      super(var1, Integer.class);
      if (var2 < 0) {
         throw new IllegalArgumentException(I["".length()] + var1 + I[" ".length()]);
      } else if (var3 <= var2) {
         throw new IllegalArgumentException(I["  ".length()] + var1 + I["   ".length()] + var2 + I[52 ^ 48]);
      } else {
         HashSet var4 = Sets.newHashSet();
         int var5 = var2;

         do {
            if (var5 > var3) {
               this.allowedValues = ImmutableSet.copyOf(var4);
               return;
            }

            var4.add(var5);
            ++var5;
            "".length();
         } while(3 > 1);

         throw null;
      }
   }

   private static void I() {
      I = new String[134 ^ 140];
      I["".length()] = I("\u00078\fA%+=\u0017\u0004s%7B", "JQbaS");
      I[" ".length()] = I("y\u000e\u0014&\u0016y\u0001\u0004uRy\f\u0013u\u0005+\u0006\u0000!\u0007+", "YcaUb");
      I["  ".length()] = I("8\u000f=t\u001e\u0014\u000201H\u001a\be", "unETh");
      I["   ".length()] = I("C4\u0006\t\u0002C;\u0016Z\u0011\u0011<\u0012\u000e\u0013\u0011y\u0007\u0012\u0017\ry\u001e\u0013\u0018Cq", "cYszv");
      I[83 ^ 87] = I("}", "TJMYL");
      I[32 ^ 37] = I("岤帩", "mRnoa");
      I[125 ^ 123] = I("撽丣", "xFQiE");
      I[31 ^ 24] = I("岯檬", "KxDNH");
      I[85 ^ 93] = I("尽濾", "rmDTV");
      I[104 ^ 97] = I("丣噧亭嚮俓", "GhAgg");
   }

   static {
      I();
   }

   public static PropertyInteger create(String var0, int var1, int var2) {
      String var10000 = I[82 ^ 87];
      String var10001 = I[36 ^ 34];
      String var10002 = I[31 ^ 24];
      var10001 = I[110 ^ 102];
      I[2 ^ 11].length();
      return new PropertyInteger(var0, var1, var2);
   }

   public String getName(Integer var1) {
      return var1.toString();
   }

   public int hashCode() {
      return (4 ^ 27) * super.hashCode() + this.allowedValues.hashCode();
   }

   public Collection<Integer> getAllowedValues() {
      return this.allowedValues;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public Optional<Integer> parseValue(String var1) {
      try {
         Integer var2 = Integer.valueOf(var1);
         Optional var10000;
         if (this.allowedValues.contains(var2)) {
            var10000 = Optional.of(var2);
            "".length();
            if (0 == 3) {
               throw null;
            }
         } else {
            var10000 = Optional.absent();
         }

         return var10000;
      } catch (NumberFormatException var3) {
         return Optional.absent();
      }
   }
}

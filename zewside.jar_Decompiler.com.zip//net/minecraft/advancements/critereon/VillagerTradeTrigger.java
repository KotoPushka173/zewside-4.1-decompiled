package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class VillagerTradeTrigger implements ICriterionTrigger<VillagerTradeTrigger.Instance> {
   // $FF: synthetic field
   private final Map<PlayerAdvancements, VillagerTradeTrigger.Listeners> field_192238_b = Maps.newHashMap();
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final ResourceLocation field_192237_a;

   public void func_192164_b(PlayerAdvancements var1, ICriterionTrigger.Listener<VillagerTradeTrigger.Instance> var2) {
      VillagerTradeTrigger.Listeners var3 = (VillagerTradeTrigger.Listeners)this.field_192238_b.get(var1);
      if (var3 != null) {
         var3.func_192538_b(var2);
         if (var3.func_192539_a()) {
            this.field_192238_b.remove(var1);
            I[199 ^ 192].length();
            I[86 ^ 94].length();
            I[47 ^ 38].length();
         }
      }

   }

   public ResourceLocation func_192163_a() {
      return field_192237_a;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 > 0);

      throw null;
   }

   public VillagerTradeTrigger.Instance func_192166_a(JsonObject var1, JsonDeserializationContext var2) {
      String var10000 = I[39 ^ 42];
      String var10001 = I[98 ^ 108];
      String var10002 = I[100 ^ 107];
      var10001 = I[116 ^ 100];
      EntityPredicate var3 = EntityPredicate.func_192481_a(var1.get(I[84 ^ 69]));
      ItemPredicate var4 = ItemPredicate.func_192492_a(var1.get(I[37 ^ 55]));
      I[185 ^ 170].length();
      I[0 ^ 20].length();
      I[37 ^ 48].length();
      return new VillagerTradeTrigger.Instance(var3, var4);
   }

   static {
      I();
      field_192237_a = new ResourceLocation(I[16 ^ 6]);
   }

   public void func_192167_a(PlayerAdvancements var1) {
      this.field_192238_b.remove(var1);
      I[84 ^ 94].length();
      I[61 ^ 54].length();
      I[94 ^ 82].length();
   }

   private static void I() {
      I = new String[18 ^ 5];
      I["".length()] = I("崃涯", "zufMe");
      I[" ".length()] = I("昁唄", "QisRu");
      I["  ".length()] = I("栞抲", "rIgid");
      I["   ".length()] = I("恉僚", "jsIvi");
      I[129 ^ 133] = I("尺檛剽啣兗", "kYlVy");
      I[196 ^ 193] = I("恁杻摸徔", "pnrbM");
      I[90 ^ 92] = I("瀺唳殎", "aRYEu");
      I[5 ^ 2] = I("煎嗉彨曭愗", "vkzHo");
      I[18 ^ 26] = I("橽恚拐姛", "rCaTo");
      I[22 ^ 31] = I("噼嚾徟啵淵", "wJIDd");
      I[184 ^ 178] = I("擢摯党棣榠", "hGBSo");
      I[49 ^ 58] = I("攰戰", "sdMXy");
      I[185 ^ 181] = I("峸屽洄恶汥", "ZFVNi");
      I[206 ^ 195] = I("偧摲", "UuTVt");
      I[138 ^ 132] = I("峵効", "ouASY");
      I[41 ^ 38] = I("杂剌", "ZVhVM");
      I[58 ^ 42] = I("咡岊", "pVCIM");
      I[65 ^ 80] = I(" \u0019#.\u00121\u0015=", "VpOBs");
      I[74 ^ 88] = I("\u001e?\u0015\u001e", "wKpsT");
      I[147 ^ 128] = I("兖啢溧", "OuaId");
      I[55 ^ 35] = I("斓梈滐巫惤", "ySlav");
      I[90 ^ 79] = I("挡奤", "MxkGi");
      I[118 ^ 96] = I("\u001f-4#\"\u000e!*\u00107\u001b%<*", "iDXOC");
   }

   public void func_192165_a(PlayerAdvancements var1, ICriterionTrigger.Listener<VillagerTradeTrigger.Instance> var2) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      VillagerTradeTrigger.Listeners var3 = (VillagerTradeTrigger.Listeners)this.field_192238_b.get(var1);
      if (var3 == null) {
         I[174 ^ 170].length();
         I[111 ^ 106].length();
         var3 = new VillagerTradeTrigger.Listeners(var1);
         this.field_192238_b.put(var1, var3);
         I[131 ^ 133].length();
      }

      var3.func_192540_a(var2);
   }

   public void func_192234_a(EntityPlayerMP var1, EntityVillager var2, ItemStack var3) {
      VillagerTradeTrigger.Listeners var4 = (VillagerTradeTrigger.Listeners)this.field_192238_b.get(var1.func_192039_O());
      if (var4 != null) {
         var4.func_192537_a(var1, var2, var3);
      }

   }

   static class Listeners {
      // $FF: synthetic field
      private final Set<ICriterionTrigger.Listener<VillagerTradeTrigger.Instance>> field_192542_b = Sets.newHashSet();
      // $FF: synthetic field
      private final PlayerAdvancements field_192541_a;
      // $FF: synthetic field
      private static final String[] I;

      public Listeners(PlayerAdvancements var1) {
         this.field_192541_a = var1;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 < 3);

         throw null;
      }

      public void func_192537_a(EntityPlayerMP var1, EntityVillager var2, ItemStack var3) {
         ArrayList var4 = null;
         Iterator var5 = this.field_192542_b.iterator();

         ICriterionTrigger.Listener var6;
         while(var5.hasNext()) {
            var6 = (ICriterionTrigger.Listener)var5.next();
            if (((VillagerTradeTrigger.Instance)var6.func_192158_a()).func_192285_a(var1, var2, var3)) {
               if (var4 == null) {
                  var4 = Lists.newArrayList();
               }

               var4.add(var6);
               I[88 ^ 80].length();
            }

            "".length();
            if (2 >= 4) {
               throw null;
            }
         }

         if (var4 != null) {
            var5 = var4.iterator();

            while(var5.hasNext()) {
               var6 = (ICriterionTrigger.Listener)var5.next();
               var6.func_192159_a(this.field_192541_a);
               "".length();
               if (0 < 0) {
                  throw null;
               }
            }
         }

      }

      static {
         I();
      }

      private static void I() {
         I = new String[137 ^ 128];
         I["".length()] = I("濽崫恵淚堙", "hYgKH");
         I[" ".length()] = I("嬪", "IiUSA");
         I["  ".length()] = I("寎淮孊", "DcXmh");
         I["   ".length()] = I("攍戈庅", "nnsUp");
         I[20 ^ 16] = I("潊", "PeKSY");
         I[152 ^ 157] = I("寔浶", "MqKJj");
         I[23 ^ 17] = I("激戉", "UJwFG");
         I[164 ^ 163] = I("圹", "cfydn");
         I[97 ^ 105] = I("兼", "riYMs");
      }

      public boolean func_192539_a() {
         return this.field_192542_b.isEmpty();
      }

      public void func_192540_a(ICriterionTrigger.Listener<VillagerTradeTrigger.Instance> var1) {
         this.field_192542_b.add(var1);
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
      }

      public void func_192538_b(ICriterionTrigger.Listener<VillagerTradeTrigger.Instance> var1) {
         this.field_192542_b.remove(var1);
         I[27 ^ 31].length();
         I[31 ^ 26].length();
         I[149 ^ 147].length();
         I[115 ^ 116].length();
      }
   }

   public static class Instance extends AbstractCriterionInstance {
      // $FF: synthetic field
      private final ItemPredicate field_192287_b;
      // $FF: synthetic field
      private final EntityPredicate field_192286_a;

      public Instance(EntityPredicate var1, ItemPredicate var2) {
         super(VillagerTradeTrigger.field_192237_a);
         this.field_192286_a = var1;
         this.field_192287_b = var2;
      }

      public boolean func_192285_a(EntityPlayerMP var1, EntityVillager var2, ItemStack var3) {
         return (boolean)(!this.field_192286_a.func_192482_a(var1, var2) ? "".length() : this.field_192287_b.func_192493_a(var3));
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 > 0);

         throw null;
      }
   }
}

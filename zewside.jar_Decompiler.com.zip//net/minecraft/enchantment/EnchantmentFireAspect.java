package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantmentFireAspect extends Enchantment {
   // $FF: synthetic field
   private static final String[] I;

   public int getMinEnchantability(int var1) {
      int var10000 = 66 ^ 72;
      int var10001 = 74 ^ 94;
      int var10003 = " ".length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      I[79 ^ 75].length();
      return var10000 + var10001 * (var1 - var10003);
   }

   public int getMaxEnchantability(int var1) {
      return super.getMinEnchantability(var1) + (102 ^ 84);
   }

   private static void I() {
      I = new String[177 ^ 180];
      I["".length()] = I("\r&(4", "kOZQV");
      I[" ".length()] = I("椀欠擫业俙", "xYFMN");
      I["  ".length()] = I("临勻嬍潠", "OwIxh");
      I["   ".length()] = I("瀤債歭住", "KPVJf");
      I[199 ^ 195] = I("湚", "tgyTq");
   }

   static {
      I();
   }

   public int getMaxLevel() {
      return "  ".length();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 == -1);

      throw null;
   }

   protected EnchantmentFireAspect(Enchantment.Rarity var1, EntityEquipmentSlot... var2) {
      super(var1, EnumEnchantmentType.WEAPON, var2);
      this.setName(I["".length()]);
   }
}

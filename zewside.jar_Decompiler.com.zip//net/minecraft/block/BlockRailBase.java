package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockRailBase extends Block {
   // $FF: synthetic field
   protected static final AxisAlignedBB FLAT_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected final boolean isPowered;
   // $FF: synthetic field
   protected static final AxisAlignedBB field_190959_b;

   public abstract IProperty<BlockRailBase.EnumRailDirection> getShapeProperty();

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      super.breakBlock(var1, var2, var3);
      if (((BlockRailBase.EnumRailDirection)var3.getValue(this.getShapeProperty())).isAscending()) {
         var1.notifyNeighborsOfStateChange(var2.up(), this, (boolean)"".length());
      }

      if (this.isPowered) {
         var1.notifyNeighborsOfStateChange(var2, this, (boolean)"".length());
         var1.notifyNeighborsOfStateChange(var2.down(), this, (boolean)"".length());
      }

   }

   public BlockRenderLayer getBlockLayer() {
      return BlockRenderLayer.CUTOUT;
   }

   public static boolean isRailBlock(World var0, BlockPos var1) {
      return isRailBlock(var0.getBlockState(var1));
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      return var1.getBlockState(var2.down()).isFullyOpaque();
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      BlockRailBase.EnumRailDirection var10000;
      if (var1.getBlock() == this) {
         var10000 = (BlockRailBase.EnumRailDirection)var1.getValue(this.getShapeProperty());
         "".length();
         if (3 == 1) {
            throw null;
         }
      } else {
         var10000 = null;
      }

      BlockRailBase.EnumRailDirection var4 = var10000;
      AxisAlignedBB var5;
      if (var4 != null && var4.isAscending()) {
         var5 = field_190959_b;
         "".length();
         if (4 <= 0) {
            throw null;
         }
      } else {
         var5 = FLAT_AABB;
      }

      return var5;
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote) {
         var3 = this.updateDir(var1, var2, var3, (boolean)" ".length());
         if (this.isPowered) {
            var3.neighborChanged(var1, var2, this, var2);
         }
      }

   }

   public static boolean isRailBlock(IBlockState var0) {
      Block var1 = var0.getBlock();
      int var10000;
      if (var1 != Blocks.RAIL && var1 != Blocks.GOLDEN_RAIL && var1 != Blocks.DETECTOR_RAIL && var1 != Blocks.ACTIVATOR_RAIL) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   protected IBlockState updateDir(World var1, BlockPos var2, IBlockState var3, boolean var4) {
      String var10000 = I["  ".length()];
      String var10001 = I["   ".length()];
      String var10002 = I[71 ^ 67];
      var10001 = I[35 ^ 38];
      IBlockState var5;
      if (var1.isRemote) {
         var5 = var3;
         "".length();
         if (false) {
            throw null;
         }
      } else {
         I[106 ^ 108].length();
         I[120 ^ 127].length();
         var5 = (new BlockRailBase.Rail(var1, var2, var3)).place(var1.isBlockPowered(var2), var4).getBlockState();
      }

      return var5;
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote) {
         BlockRailBase.EnumRailDirection var6 = (BlockRailBase.EnumRailDirection)var1.getValue(this.getShapeProperty());
         int var7 = "".length();
         if (!var2.getBlockState(var3.down()).isFullyOpaque()) {
            var7 = " ".length();
         }

         if (var6 == BlockRailBase.EnumRailDirection.ASCENDING_EAST && !var2.getBlockState(var3.east()).isFullyOpaque()) {
            var7 = " ".length();
            "".length();
            if (4 != 4) {
               throw null;
            }
         } else if (var6 == BlockRailBase.EnumRailDirection.ASCENDING_WEST && !var2.getBlockState(var3.west()).isFullyOpaque()) {
            var7 = " ".length();
            "".length();
            if (0 == -1) {
               throw null;
            }
         } else if (var6 == BlockRailBase.EnumRailDirection.ASCENDING_NORTH && !var2.getBlockState(var3.north()).isFullyOpaque()) {
            var7 = " ".length();
            "".length();
            if (1 >= 3) {
               throw null;
            }
         } else if (var6 == BlockRailBase.EnumRailDirection.ASCENDING_SOUTH && !var2.getBlockState(var3.south()).isFullyOpaque()) {
            var7 = " ".length();
         }

         if (var7 != 0 && !var2.isAirBlock(var3)) {
            this.dropBlockAsItem(var2, var3, var1, "".length());
            var2.setBlockToAir(var3);
            I["".length()].length();
            I[" ".length()].length();
            "".length();
            if (4 != 4) {
               throw null;
            }
         } else {
            this.updateState(var1, var2, var3, var4);
         }
      }

   }

   protected void updateState(IBlockState var1, World var2, BlockPos var3, Block var4) {
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return NULL_AABB;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(-1 < 1);

      throw null;
   }

   protected BlockRailBase(boolean var1) {
      super(Material.CIRCUITS);
      this.isPowered = var1;
      this.setCreativeTab(CreativeTabs.TRANSPORTATION);
   }

   private static void I() {
      I = new String[67 ^ 75];
      I["".length()] = I("于挀勫", "djJUH");
      I[" ".length()] = I("慳嬊", "OFAfy");
      I["  ".length()] = I("戧们", "VeJJM");
      I["   ".length()] = I("毃崝", "tSMlQ");
      I[16 ^ 20] = I("傕婷", "QYgYp");
      I[173 ^ 168] = I("柀學", "nvbSx");
      I[147 ^ 149] = I("擳掉洪", "rLAes");
      I[55 ^ 48] = I("娗刄", "xZGlU");
   }

   public EnumPushReaction getMobilityFlag(IBlockState var1) {
      return EnumPushReaction.NORMAL;
   }

   static {
      I();
      FLAT_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.125D, 1.0D);
      field_190959_b = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D);
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public class Rail {
      // $FF: synthetic field
      private final BlockRailBase block;
      // $FF: synthetic field
      private final World world;
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      private final List<BlockPos> connectedRails = Lists.newArrayList();
      // $FF: synthetic field
      private final BlockPos pos;
      // $FF: synthetic field
      private final boolean isPowered;
      // $FF: synthetic field
      private IBlockState state;

      private void updateConnectedRails(BlockRailBase.EnumRailDirection var1) {
         this.connectedRails.clear();
         switch(null.$SwitchMap$net$minecraft$block$BlockRailBase$EnumRailDirection[var1.ordinal()]) {
         case 1:
            this.connectedRails.add(this.pos.north());
            I["".length()].length();
            I[" ".length()].length();
            this.connectedRails.add(this.pos.south());
            I["  ".length()].length();
            I["   ".length()].length();
            I[16 ^ 20].length();
            I[109 ^ 104].length();
            "".length();
            if (2 <= 1) {
               throw null;
            }
            break;
         case 2:
            this.connectedRails.add(this.pos.west());
            I[145 ^ 151].length();
            this.connectedRails.add(this.pos.east());
            I[33 ^ 38].length();
            I[50 ^ 58].length();
            I[169 ^ 160].length();
            I[165 ^ 175].length();
            "".length();
            if (3 <= 0) {
               throw null;
            }
            break;
         case 3:
            this.connectedRails.add(this.pos.west());
            I[171 ^ 160].length();
            I[123 ^ 119].length();
            I[152 ^ 149].length();
            this.connectedRails.add(this.pos.east().up());
            I[3 ^ 13].length();
            I[167 ^ 168].length();
            "".length();
            if (3 <= 0) {
               throw null;
            }
            break;
         case 4:
            this.connectedRails.add(this.pos.west().up());
            I[43 ^ 59].length();
            I[32 ^ 49].length();
            I[211 ^ 193].length();
            this.connectedRails.add(this.pos.east());
            I[37 ^ 54].length();
            I[160 ^ 180].length();
            I[118 ^ 99].length();
            "".length();
            if (2 != 2) {
               throw null;
            }
            break;
         case 5:
            this.connectedRails.add(this.pos.north().up());
            I[8 ^ 30].length();
            I[24 ^ 15].length();
            this.connectedRails.add(this.pos.south());
            I[21 ^ 13].length();
            "".length();
            if (0 == 3) {
               throw null;
            }
            break;
         case 6:
            this.connectedRails.add(this.pos.north());
            I[170 ^ 179].length();
            this.connectedRails.add(this.pos.south().up());
            I[185 ^ 163].length();
            I[77 ^ 86].length();
            "".length();
            if (1 >= 2) {
               throw null;
            }
            break;
         case 7:
            this.connectedRails.add(this.pos.east());
            I[57 ^ 37].length();
            I[138 ^ 151].length();
            I[123 ^ 101].length();
            this.connectedRails.add(this.pos.south());
            I[187 ^ 164].length();
            I[68 ^ 100].length();
            "".length();
            if (4 < 0) {
               throw null;
            }
            break;
         case 8:
            this.connectedRails.add(this.pos.west());
            I[106 ^ 75].length();
            this.connectedRails.add(this.pos.south());
            I[101 ^ 71].length();
            I[44 ^ 15].length();
            I[141 ^ 169].length();
            "".length();
            if (false) {
               throw null;
            }
            break;
         case 9:
            this.connectedRails.add(this.pos.west());
            I[37 ^ 0].length();
            I[114 ^ 84].length();
            this.connectedRails.add(this.pos.north());
            I[18 ^ 53].length();
            I[190 ^ 150].length();
            "".length();
            if (-1 >= 0) {
               throw null;
            }
            break;
         case 10:
            this.connectedRails.add(this.pos.east());
            I[37 ^ 12].length();
            I[153 ^ 179].length();
            this.connectedRails.add(this.pos.north());
            I[176 ^ 155].length();
            I[1 ^ 45].length();
         }

      }

      private boolean isConnectedToRail(BlockRailBase.Rail var1) {
         return this.isConnectedTo(var1.pos);
      }

      private static void I() {
         I = new String[209 ^ 184];
         I["".length()] = I("傑撌", "lkCjG");
         I[" ".length()] = I("匩壞扎寒屭", "sEEni");
         I["  ".length()] = I("佔吜唌流忻", "yUyOk");
         I["   ".length()] = I("幙愓唴侱", "hqrHH");
         I[125 ^ 121] = I("楿渫奎", "Cesmr");
         I[196 ^ 193] = I("涽涔", "VuFYG");
         I[98 ^ 100] = I("戾捡偪棘", "clCCC");
         I[98 ^ 101] = I("掀", "GvKLg");
         I[38 ^ 46] = I("檗吧汿參凲", "wRXmT");
         I[86 ^ 95] = I("噬焯", "QnsHD");
         I[125 ^ 119] = I("泂刹咺", "eQzCU");
         I[41 ^ 34] = I("杪侁", "BXMzj");
         I[134 ^ 138] = I("漼悹傝渙", "CHlyN");
         I[6 ^ 11] = I("楂孏栀乍", "RxNxk");
         I[174 ^ 160] = I("怿", "Niamt");
         I[88 ^ 87] = I("侹扯灿溦梞", "CzLHs");
         I[133 ^ 149] = I("嚪嶴楈挝峐", "jTubb");
         I[43 ^ 58] = I("暚", "XjIMg");
         I[92 ^ 78] = I("啙桰嗸", "qZote");
         I[8 ^ 27] = I("攩修濼枃", "gLvfd");
         I[10 ^ 30] = I("澰烦匃俓兣", "HyEQB");
         I[177 ^ 164] = I("侵搧异搉", "urmlX");
         I[4 ^ 18] = I("揆嘓慲櫮", "tOGHA");
         I[158 ^ 137] = I("匶", "sejfA");
         I[152 ^ 128] = I("佺", "HaMNe");
         I[147 ^ 138] = I("孜叾", "xpljX");
         I[109 ^ 119] = I("災", "isnxs");
         I[101 ^ 126] = I("佻僐旳揀", "TeVCI");
         I[60 ^ 32] = I("澐悌伣", "BxQxz");
         I[68 ^ 89] = I("噦扃却", "nIrwZ");
         I[96 ^ 126] = I("仍", "yBPUl");
         I[5 ^ 26] = I("潭挾", "JdKka");
         I[226 ^ 194] = I("幮峼", "LwkQg");
         I[55 ^ 22] = I("与", "IrCFn");
         I[229 ^ 199] = I("叔沕", "SDLdA");
         I[186 ^ 153] = I("嬧", "TjTSZ");
         I[119 ^ 83] = I("横浇", "JWLGG");
         I[0 ^ 37] = I("匀偐故刲摝", "LVIbJ");
         I[75 ^ 109] = I("恐涜撿", "zabbK");
         I[170 ^ 141] = I("昵卉", "MyfrX");
         I[161 ^ 137] = I("嗜", "Nwbri");
         I[19 ^ 58] = I("媯沠塰歀", "tFpJP");
         I[106 ^ 64] = I("媏氡漫海恔", "pYNhj");
         I[33 ^ 10] = I("慱", "oIDTy");
         I[82 ^ 126] = I("岕", "FYEjQ");
         I[134 ^ 171] = I("揪嚚槒尘", "dYIJL");
         I[8 ^ 38] = I("嬼廏堧", "Hzvww");
         I[130 ^ 173] = I("囎勗", "MsjoH");
         I[28 ^ 44] = I("厞侗灳喚啼", "ZfmOc");
         I[129 ^ 176] = I("广劽", "bISub");
         I[33 ^ 19] = I("拲幡奬", "pQMmd");
         I[161 ^ 146] = I("埇媬", "CJgFQ");
         I[134 ^ 178] = I("偉攻", "FYjJW");
         I[165 ^ 144] = I("嬔台", "Havwr");
         I[178 ^ 132] = I("夁愢", "IENKB");
         I[119 ^ 64] = I("柜潩", "OKDYu");
         I[148 ^ 172] = I("弼抜", "jRFAW");
         I[72 ^ 113] = I("厑垀", "giHvN");
         I[102 ^ 92] = I("捅欴", "HJqYY");
         I[56 ^ 3] = I("帨嘽", "uPFdK");
         I[190 ^ 130] = I("溌匮", "OkGZC");
         I[17 ^ 44] = I("師滂", "GCIrd");
         I[120 ^ 70] = I("恪灨", "ftQMY");
         I[160 ^ 159] = I("廷債", "MhFNJ");
         I[47 ^ 111] = I("炥永", "GIoZh");
         I[99 ^ 34] = I("樱乁", "xxStp");
         I[131 ^ 193] = I("刺嚝", "NLSyE");
         I[32 ^ 99] = I("坫橄", "VvBNM");
         I[221 ^ 153] = I("径潶", "XSzeh");
         I[34 ^ 103] = I("惮孄", "XBPPG");
         I[207 ^ 137] = I("敇扈", "UlRtZ");
         I[30 ^ 89] = I("炯漯", "WwTiI");
         I[80 ^ 24] = I("浃專", "pdZhk");
         I[251 ^ 178] = I("巴創", "KsWNZ");
         I[192 ^ 138] = I("樂抧", "NuiOe");
         I[50 ^ 121] = I("唥婹漊", "XFkCN");
         I[219 ^ 151] = I("仅戩帘抎忸", "aKiaw");
         I[251 ^ 182] = I("俇杈", "vaDQF");
         I[22 ^ 88] = I("攗", "cNSDj");
         I[18 ^ 93] = I("怚搇", "okHlF");
         I[200 ^ 152] = I("圽冹吿娀歾", "LIbaB");
         I[25 ^ 72] = I("檣宀柽傟", "nzltN");
         I[216 ^ 138] = I("氉曶槤倹氮", "xGUtr");
         I[239 ^ 188] = I("咺囲叻伝", "pdceo");
         I[72 ^ 28] = I("槣帒溰搲嫏", "xHtZh");
         I[65 ^ 20] = I("摍", "UBwWG");
         I[58 ^ 108] = I("恶", "MJHjr");
         I[33 ^ 118] = I("圬佃婡", "lqzzk");
         I[224 ^ 184] = I("氊养懻潐", "kvbuH");
         I[110 ^ 55] = I("厈", "AMSpP");
         I[230 ^ 188] = I("徣彸垂敗", "LNbCn");
         I[50 ^ 105] = I("椓娌儻", "XpoIa");
         I[39 ^ 123] = I("惁帼", "WCYwl");
         I[70 ^ 27] = I("娨", "uFmua");
         I[122 ^ 36] = I("剿", "cjmys");
         I[201 ^ 150] = I("桩塇澥恜", "NiWkR");
         I[12 ^ 108] = I("弫", "OHnCv");
         I[250 ^ 155] = I("抃嗖垂曔", "RaALI");
         I[204 ^ 174] = I("七傂", "PINjp");
         I[32 ^ 67] = I("廵倨", "rilcR");
         I[124 ^ 24] = I("泮屙哠伧殺", "duITd");
         I[102 ^ 3] = I("槺彁惟唀嶿", "WfAMH");
         I[24 ^ 126] = I("枥", "vdAmH");
         I[81 ^ 54] = I("搑择予儉拘", "IPNog");
         I[192 ^ 168] = I("拕悛為", "LyIoN");
      }

      public Rail(World var2, BlockPos var3, IBlockState var4) {
         this.world = var2;
         this.pos = var3;
         this.state = var4;
         this.block = (BlockRailBase)var4.getBlock();
         BlockRailBase.EnumRailDirection var5 = (BlockRailBase.EnumRailDirection)var4.getValue(this.block.getShapeProperty());
         this.isPowered = this.block.isPowered;
         this.updateConnectedRails(var5);
      }

      private boolean hasRailAt(BlockPos var1) {
         int var10000;
         if (!BlockRailBase.isRailBlock(this.world, var1) && !BlockRailBase.isRailBlock(this.world, var1.up()) && !BlockRailBase.isRailBlock(this.world, var1.down())) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (1 < 0) {
               throw null;
            }
         }

         return (boolean)var10000;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(-1 < 3);

         throw null;
      }

      private void removeSoftConnections() {
         int var1 = "".length();

         do {
            if (var1 >= this.connectedRails.size()) {
               return;
            }

            BlockRailBase.Rail var2 = this.findRailAt((BlockPos)this.connectedRails.get(var1));
            if (var2 != null && var2.isConnectedToRail(this)) {
               this.connectedRails.set(var1, var2.pos);
               I[12 ^ 33].length();
               "".length();
               if (3 <= 2) {
                  throw null;
               }
            } else {
               this.connectedRails.remove(var1--);
               I[190 ^ 144].length();
               I[97 ^ 78].length();
               I[100 ^ 84].length();
               I[132 ^ 181].length();
               I[38 ^ 20].length();
            }

            ++var1;
            "".length();
         } while(1 >= -1);

         throw null;
      }

      private boolean canConnectTo(BlockRailBase.Rail var1) {
         int var10000;
         if (!this.isConnectedToRail(var1) && this.connectedRails.size() == "  ".length()) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (1 <= -1) {
               throw null;
            }
         }

         return (boolean)var10000;
      }

      private boolean hasNeighborRail(BlockPos var1) {
         BlockRailBase.Rail var2 = this.findRailAt(var1);
         if (var2 == null) {
            return (boolean)"".length();
         } else {
            var2.removeSoftConnections();
            return var2.canConnectTo(this);
         }
      }

      public List<BlockPos> getConnectedRails() {
         return this.connectedRails;
      }

      static {
         I();
      }

      public IBlockState getBlockState() {
         return this.state;
      }

      private void connectTo(BlockRailBase.Rail var1) {
         this.connectedRails.add(var1.pos);
         I[4 ^ 103].length();
         I[102 ^ 2].length();
         BlockPos var2 = this.pos.north();
         BlockPos var3 = this.pos.south();
         BlockPos var4 = this.pos.west();
         BlockPos var5 = this.pos.east();
         boolean var6 = this.isConnectedTo(var2);
         boolean var7 = this.isConnectedTo(var3);
         boolean var8 = this.isConnectedTo(var4);
         boolean var9 = this.isConnectedTo(var5);
         BlockRailBase.EnumRailDirection var10 = null;
         if (var6 || var7) {
            var10 = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
         }

         if (var8 || var9) {
            var10 = BlockRailBase.EnumRailDirection.EAST_WEST;
         }

         if (!this.isPowered) {
            if (var7 && var9 && !var6 && !var8) {
               var10 = BlockRailBase.EnumRailDirection.SOUTH_EAST;
            }

            if (var7 && var8 && !var6 && !var9) {
               var10 = BlockRailBase.EnumRailDirection.SOUTH_WEST;
            }

            if (var6 && var8 && !var7 && !var9) {
               var10 = BlockRailBase.EnumRailDirection.NORTH_WEST;
            }

            if (var6 && var9 && !var7 && !var8) {
               var10 = BlockRailBase.EnumRailDirection.NORTH_EAST;
            }
         }

         if (var10 == BlockRailBase.EnumRailDirection.NORTH_SOUTH) {
            if (BlockRailBase.isRailBlock(this.world, var2.up())) {
               var10 = BlockRailBase.EnumRailDirection.ASCENDING_NORTH;
            }

            if (BlockRailBase.isRailBlock(this.world, var3.up())) {
               var10 = BlockRailBase.EnumRailDirection.ASCENDING_SOUTH;
            }
         }

         if (var10 == BlockRailBase.EnumRailDirection.EAST_WEST) {
            if (BlockRailBase.isRailBlock(this.world, var5.up())) {
               var10 = BlockRailBase.EnumRailDirection.ASCENDING_EAST;
            }

            if (BlockRailBase.isRailBlock(this.world, var4.up())) {
               var10 = BlockRailBase.EnumRailDirection.ASCENDING_WEST;
            }
         }

         if (var10 == null) {
            var10 = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
         }

         this.state = this.state.withProperty(this.block.getShapeProperty(), var10);
         this.world.setBlockState(this.pos, this.state, "   ".length());
         I[88 ^ 61].length();
      }

      protected int countAdjacentRails() {
         int var1 = "".length();
         Iterator var2 = EnumFacing.Plane.HORIZONTAL.iterator();

         do {
            if (!var2.hasNext()) {
               return var1;
            }

            EnumFacing var3 = (EnumFacing)var2.next();
            if (this.hasRailAt(this.pos.offset(var3))) {
               ++var1;
            }

            "".length();
         } while(2 == 2);

         throw null;
      }

      private boolean isConnectedTo(BlockPos var1) {
         int var2 = "".length();

         do {
            if (var2 >= this.connectedRails.size()) {
               return (boolean)"".length();
            }

            BlockPos var3 = (BlockPos)this.connectedRails.get(var2);
            if (var3.getX() == var1.getX() && var3.getZ() == var1.getZ()) {
               return (boolean)" ".length();
            }

            ++var2;
            "".length();
         } while(4 == 4);

         throw null;
      }

      public BlockRailBase.Rail place(boolean var1, boolean var2) {
         BlockPos var3 = this.pos.north();
         BlockPos var4 = this.pos.south();
         BlockPos var5 = this.pos.west();
         BlockPos var6 = this.pos.east();
         boolean var7 = this.hasNeighborRail(var3);
         boolean var8 = this.hasNeighborRail(var4);
         boolean var9 = this.hasNeighborRail(var5);
         boolean var10 = this.hasNeighborRail(var6);
         BlockRailBase.EnumRailDirection var11 = null;
         if ((var7 || var8) && !var9 && !var10) {
            var11 = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
         }

         if ((var9 || var10) && !var7 && !var8) {
            var11 = BlockRailBase.EnumRailDirection.EAST_WEST;
         }

         if (!this.isPowered) {
            if (var8 && var10 && !var7 && !var9) {
               var11 = BlockRailBase.EnumRailDirection.SOUTH_EAST;
            }

            if (var8 && var9 && !var7 && !var10) {
               var11 = BlockRailBase.EnumRailDirection.SOUTH_WEST;
            }

            if (var7 && var9 && !var8 && !var10) {
               var11 = BlockRailBase.EnumRailDirection.NORTH_WEST;
            }

            if (var7 && var10 && !var8 && !var9) {
               var11 = BlockRailBase.EnumRailDirection.NORTH_EAST;
            }
         }

         if (var11 == null) {
            if (var7 || var8) {
               var11 = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
            }

            if (var9 || var10) {
               var11 = BlockRailBase.EnumRailDirection.EAST_WEST;
            }

            if (!this.isPowered) {
               if (var1) {
                  if (var8 && var10) {
                     var11 = BlockRailBase.EnumRailDirection.SOUTH_EAST;
                  }

                  if (var9 && var8) {
                     var11 = BlockRailBase.EnumRailDirection.SOUTH_WEST;
                  }

                  if (var10 && var7) {
                     var11 = BlockRailBase.EnumRailDirection.NORTH_EAST;
                  }

                  if (var7 && var9) {
                     var11 = BlockRailBase.EnumRailDirection.NORTH_WEST;
                     "".length();
                     if (4 == -1) {
                        throw null;
                     }
                  }
               } else {
                  if (var7 && var9) {
                     var11 = BlockRailBase.EnumRailDirection.NORTH_WEST;
                  }

                  if (var10 && var7) {
                     var11 = BlockRailBase.EnumRailDirection.NORTH_EAST;
                  }

                  if (var9 && var8) {
                     var11 = BlockRailBase.EnumRailDirection.SOUTH_WEST;
                  }

                  if (var8 && var10) {
                     var11 = BlockRailBase.EnumRailDirection.SOUTH_EAST;
                  }
               }
            }
         }

         if (var11 == BlockRailBase.EnumRailDirection.NORTH_SOUTH) {
            if (BlockRailBase.isRailBlock(this.world, var3.up())) {
               var11 = BlockRailBase.EnumRailDirection.ASCENDING_NORTH;
            }

            if (BlockRailBase.isRailBlock(this.world, var4.up())) {
               var11 = BlockRailBase.EnumRailDirection.ASCENDING_SOUTH;
            }
         }

         if (var11 == BlockRailBase.EnumRailDirection.EAST_WEST) {
            if (BlockRailBase.isRailBlock(this.world, var6.up())) {
               var11 = BlockRailBase.EnumRailDirection.ASCENDING_EAST;
            }

            if (BlockRailBase.isRailBlock(this.world, var5.up())) {
               var11 = BlockRailBase.EnumRailDirection.ASCENDING_WEST;
            }
         }

         if (var11 == null) {
            var11 = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
         }

         this.updateConnectedRails(var11);
         this.state = this.state.withProperty(this.block.getShapeProperty(), var11);
         if (var2 || this.world.getBlockState(this.pos) != this.state) {
            this.world.setBlockState(this.pos, this.state, "   ".length());
            I[127 ^ 25].length();
            I[126 ^ 25].length();
            I[213 ^ 189].length();
            int var12 = "".length();

            while(var12 < this.connectedRails.size()) {
               BlockRailBase.Rail var13 = this.findRailAt((BlockPos)this.connectedRails.get(var12));
               if (var13 != null) {
                  var13.removeSoftConnections();
                  if (var13.canConnectTo(this)) {
                     var13.connectTo(this);
                  }
               }

               ++var12;
               "".length();
               if (2 < -1) {
                  throw null;
               }
            }
         }

         return this;
      }

      @Nullable
      private BlockRailBase.Rail findRailAt(BlockPos var1) {
         String var10000 = I[94 ^ 109];
         String var10001 = I[143 ^ 187];
         String var10002 = I[91 ^ 110];
         var10001 = I[5 ^ 51];
         var10000 = I[30 ^ 41];
         var10001 = I[71 ^ 127];
         var10002 = I[78 ^ 119];
         var10001 = I[249 ^ 195];
         var10000 = I[65 ^ 122];
         var10001 = I[251 ^ 199];
         var10002 = I[17 ^ 44];
         var10001 = I[42 ^ 20];
         var10000 = I[111 ^ 80];
         var10001 = I[27 ^ 91];
         var10002 = I[207 ^ 142];
         var10001 = I[233 ^ 171];
         var10000 = I[48 ^ 115];
         var10001 = I[8 ^ 76];
         var10002 = I[118 ^ 51];
         var10001 = I[46 ^ 104];
         var10000 = I[200 ^ 143];
         var10001 = I[46 ^ 102];
         var10002 = I[228 ^ 173];
         var10001 = I[226 ^ 168];
         IBlockState var2 = this.world.getBlockState(var1);
         BlockRailBase var5;
         if (BlockRailBase.isRailBlock(var2)) {
            I[36 ^ 111].length();
            I[142 ^ 194].length();
            var5 = BlockRailBase.this;
            I[72 ^ 5].length();
            I[211 ^ 157].length();
            var5.getClass();
            I[203 ^ 132].length();
            return var5.new Rail(this.world, var1, var2);
         } else {
            BlockPos var3 = var1.up();
            var2 = this.world.getBlockState(var3);
            if (BlockRailBase.isRailBlock(var2)) {
               I[97 ^ 49].length();
               I[149 ^ 196].length();
               I[34 ^ 112].length();
               I[240 ^ 163].length();
               var5 = BlockRailBase.this;
               I[71 ^ 19].length();
               I[75 ^ 30].length();
               I[119 ^ 33].length();
               I[6 ^ 81].length();
               var5.getClass();
               I[253 ^ 165].length();
               I[114 ^ 43].length();
               I[215 ^ 141].length();
               return var5.new Rail(this.world, var3, var2);
            } else {
               var3 = var1.down();
               var2 = this.world.getBlockState(var3);
               BlockRailBase.Rail var4;
               if (BlockRailBase.isRailBlock(var2)) {
                  I[240 ^ 171].length();
                  I[229 ^ 185].length();
                  I[94 ^ 3].length();
                  var5 = BlockRailBase.this;
                  I[9 ^ 87].length();
                  I[113 ^ 46].length();
                  I[8 ^ 104].length();
                  var5.getClass();
                  I[255 ^ 158].length();
                  I[27 ^ 121].length();
                  var4 = var5.new Rail(this.world, var3, var2);
                  "".length();
                  if (2 == -1) {
                     throw null;
                  }
               } else {
                  var4 = null;
               }

               return var4;
            }
         }
      }
   }

   public static enum EnumRailDirection implements IStringSerializable {
      // $FF: synthetic field
      NORTH_SOUTH,
      // $FF: synthetic field
      ASCENDING_EAST,
      // $FF: synthetic field
      EAST_WEST,
      // $FF: synthetic field
      ASCENDING_WEST,
      // $FF: synthetic field
      SOUTH_WEST;

      // $FF: synthetic field
      private final int meta;
      // $FF: synthetic field
      SOUTH_EAST,
      // $FF: synthetic field
      NORTH_WEST,
      // $FF: synthetic field
      ASCENDING_SOUTH;

      // $FF: synthetic field
      private final String name;
      // $FF: synthetic field
      ASCENDING_NORTH;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      NORTH_EAST;

      public int getMetadata() {
         return this.meta;
      }

      public boolean isAscending() {
         int var10000;
         if (this != ASCENDING_NORTH && this != ASCENDING_EAST && this != ASCENDING_SOUTH && this != ASCENDING_WEST) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (0 >= 3) {
               throw null;
            }
         }

         return (boolean)var10000;
      }

      public String getName() {
         return this.name;
      }

      private static void I() {
         I = new String[64 ^ 84];
         I["".length()] = I("\u001c\u0002>\u0015\u001f\r\u001e#\u0014\u0003\u001a", "RMlAW");
         I[" ".length()] = I("\u001c.\u001b\u001d+-2\u0006\u001c7\u001a", "rAiiC");
         I["  ".length()] = I(".\u00142,=<\u00102,", "kUaxb");
         I["   ".length()] = I("\u001f5\u0015?0\r1\u0015?", "zTfKo");
         I[3 ^ 7] = I("\u0005\u00184\u00108\u0000\u00029\u0012)\u0001\n$\u0001", "DKwUv");
         I[107 ^ 110] = I("$$\u00162<!>\u001b0\r 6\u0006#", "EWuWR");
         I[88 ^ 94] = I("4\u00062\f'1\u001c?\u000e6\"\u0010\"\u001d", "uUqIi");
         I[86 ^ 81] = I("\n\u0007$\u0001\u0006\u000f\u001d)\u00037\u001c\u00114\u0010", "ktGdh");
         I[11 ^ 3] = I("\r\"\u0011?,\b8\u001c==\u0002>\u0000.*", "LqRzb");
         I[130 ^ 139] = I("&\"),\"#8$.\u0013)>8=$", "GQJIL");
         I[190 ^ 180] = I("\u0018\u0003\u0014\u0001\b\u001d\u0019\u0019\u0003\u0019\n\u001f\u0002\u0010\u000e", "YPWDF");
         I[107 ^ 96] = I("00:\u0003\u00195*7\u0001(\",,\u0012\u001f", "QCYfw");
         I[1 ^ 13] = I("\u001b:\u0016\f&\u00170\u0002\u000b:", "HuCXn");
         I[26 ^ 23] = I("#+\r;\n\u000f!\u0019<\u0016", "PDxOb");
         I[205 ^ 195] = I("0\u0003-%\u001c<\u001b=\"\u0000", "cLxqT");
         I[189 ^ 178] = I("9::<?\u0015\"*;#", "JUOHW");
         I[90 ^ 74] = I("7\"\u0014\u0001)&:\u0003\u00065", "ymFUa");
         I[77 ^ 92] = I("\u0016;0\u0016?'#'\u0011#", "xTBbW");
         I[123 ^ 105] = I("8&\u0013'*),\u0000 6", "viAsb");
         I[182 ^ 165] = I("\u001d'$9:,-7>&", "sHVMR");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(true);

         throw null;
      }

      public static BlockRailBase.EnumRailDirection byMetadata(int var0) {
         if (var0 < 0 || var0 >= META_LOOKUP.length) {
            var0 = "".length();
         }

         return META_LOOKUP[var0];
      }

      private EnumRailDirection(int var3, String var4) {
         this.meta = var3;
         this.name = var4;
      }

      public String toString() {
         return this.name;
      }

      static {
         I();
         NORTH_SOUTH = new BlockRailBase.EnumRailDirection(I["".length()], "".length(), "".length(), I[" ".length()]);
         EAST_WEST = new BlockRailBase.EnumRailDirection(I["  ".length()], " ".length(), " ".length(), I["   ".length()]);
         ASCENDING_EAST = new BlockRailBase.EnumRailDirection(I[9 ^ 13], "  ".length(), "  ".length(), I[1 ^ 4]);
         ASCENDING_WEST = new BlockRailBase.EnumRailDirection(I[138 ^ 140], "   ".length(), "   ".length(), I[155 ^ 156]);
         ASCENDING_NORTH = new BlockRailBase.EnumRailDirection(I[46 ^ 38], 104 ^ 108, 47 ^ 43, I[187 ^ 178]);
         ASCENDING_SOUTH = new BlockRailBase.EnumRailDirection(I[32 ^ 42], 77 ^ 72, 158 ^ 155, I[109 ^ 102]);
         SOUTH_EAST = new BlockRailBase.EnumRailDirection(I[134 ^ 138], 184 ^ 190, 31 ^ 25, I[186 ^ 183]);
         SOUTH_WEST = new BlockRailBase.EnumRailDirection(I[204 ^ 194], 136 ^ 143, 64 ^ 71, I[188 ^ 179]);
         NORTH_WEST = new BlockRailBase.EnumRailDirection(I[185 ^ 169], 74 ^ 66, 43 ^ 35, I[164 ^ 181]);
         NORTH_EAST = new BlockRailBase.EnumRailDirection(I[133 ^ 151], 111 ^ 102, 164 ^ 173, I[162 ^ 177]);
         BlockRailBase.EnumRailDirection[] var10000 = new BlockRailBase.EnumRailDirection[59 ^ 49];
         var10000["".length()] = NORTH_SOUTH;
         var10000[" ".length()] = EAST_WEST;
         var10000["  ".length()] = ASCENDING_EAST;
         var10000["   ".length()] = ASCENDING_WEST;
         var10000[189 ^ 185] = ASCENDING_NORTH;
         var10000[175 ^ 170] = ASCENDING_SOUTH;
         var10000[170 ^ 172] = SOUTH_EAST;
         var10000[88 ^ 95] = SOUTH_WEST;
         var10000[137 ^ 129] = NORTH_WEST;
         var10000[15 ^ 6] = NORTH_EAST;
         BlockRailBase.EnumRailDirection[] var0 = values();
         int var1 = var0.length;
         int var2 = "".length();

         do {
            if (var2 >= var1) {
               return;
            }

            BlockRailBase.EnumRailDirection var3 = var0[var2];
            META_LOOKUP[var3.getMetadata()] = var3;
            ++var2;
            "".length();
         } while(1 >= 1);

         throw null;
      }
   }
}

package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class CPacketResourcePackStatus implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private CPacketResourcePackStatus.Action action;

   public CPacketResourcePackStatus(CPacketResourcePackStatus.Action var1) {
      this.action = var1;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.action);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
   }

   static {
      I();
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 2);

      throw null;
   }

   private static void I() {
      I = new String[139 ^ 143];
      I["".length()] = I("憒怉炭槯傐", "VDaCP");
      I[" ".length()] = I("抖淊", "OGDmu");
      I["  ".length()] = I("僽丫", "BhlDa");
      I["   ".length()] = I("垽屧娇昇寣", "oQcoM");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.action = (CPacketResourcePackStatus.Action)var1.readEnumValue(CPacketResourcePackStatus.Action.class);
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.handleResourcePackStatus(this);
   }

   public CPacketResourcePackStatus() {
   }

   public static enum Action {
      // $FF: synthetic field
      SUCCESSFULLY_LOADED,
      // $FF: synthetic field
      FAILED_DOWNLOAD,
      // $FF: synthetic field
      ACCEPTED,
      // $FF: synthetic field
      DECLINED;

      // $FF: synthetic field
      private static final String[] I;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(3 >= 0);

         throw null;
      }

      private static void I() {
         I = new String[109 ^ 105];
         I["".length()] = I("\u0006\u0013\u000e\u0002\u0017\u0006\u0015\u000b\u0014\u001e\u0019\u001f\u0012\r\u001d\u0014\u0002\b\u0005", "UFMAR");
         I[" ".length()] = I(")\u0015\u0013\u00020#\u0015\u0014", "mPPNy");
         I["  ".length()] = I("3\u0006\u0005\b\u00171\u0018\b\u000b\u0005;\u000b\u0003\u0005\u0016", "uGLDR");
         I["   ".length()] = I("*\u000b\u0002$\u0005?\r\u0005", "kHAaU");
      }

      static {
         I();
         SUCCESSFULLY_LOADED = new CPacketResourcePackStatus.Action(I["".length()], "".length());
         DECLINED = new CPacketResourcePackStatus.Action(I[" ".length()], " ".length());
         FAILED_DOWNLOAD = new CPacketResourcePackStatus.Action(I["  ".length()], "  ".length());
         ACCEPTED = new CPacketResourcePackStatus.Action(I["   ".length()], "   ".length());
         CPacketResourcePackStatus.Action[] var10000 = new CPacketResourcePackStatus.Action[42 ^ 46];
         var10000["".length()] = SUCCESSFULLY_LOADED;
         var10000[" ".length()] = DECLINED;
         var10000["  ".length()] = FAILED_DOWNLOAD;
         var10000["   ".length()] = ACCEPTED;
      }
   }
}

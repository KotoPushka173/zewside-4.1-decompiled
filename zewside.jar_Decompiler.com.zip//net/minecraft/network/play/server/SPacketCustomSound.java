package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.SoundCategory;
import org.apache.commons.lang3.Validate;

public class SPacketCustomSound implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int z;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private float volume;
   // $FF: synthetic field
   private float pitch;
   // $FF: synthetic field
   private SoundCategory category;
   // $FF: synthetic field
   private int y;
   // $FF: synthetic field
   private int x;
   // $FF: synthetic field
   private String soundName;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeString(this.soundName);
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
      var1.writeEnumValue(this.category);
      I[116 ^ 112].length();
      I[52 ^ 49].length();
      I[15 ^ 9].length();
      var1.writeInt(this.x);
      I[21 ^ 18].length();
      var1.writeInt(this.y);
      I[103 ^ 111].length();
      I[186 ^ 179].length();
      var1.writeInt(this.z);
      I[56 ^ 50].length();
      var1.writeFloat(this.volume);
      I[166 ^ 173].length();
      var1.writeFloat(this.pitch);
      I[49 ^ 61].length();
      I[89 ^ 84].length();
      I[186 ^ 180].length();
   }

   public SPacketCustomSound(String var1, SoundCategory var2, double var3, double var5, double var7, float var9, float var10) {
      this.y = 251425736 + 1794032927 - 1410973999 + 1512998983;
      Validate.notNull(var1, I["".length()], new Object["".length()]);
      this.soundName = var1;
      this.category = var2;
      this.x = (int)(var3 * 8.0D);
      this.y = (int)(var5 * 8.0D);
      this.z = (int)(var7 * 8.0D);
      this.volume = var9;
      this.pitch = var10;
   }

   public SoundCategory getCategory() {
      return this.category;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleCustomSound(this);
   }

   public SPacketCustomSound() {
      this.y = 1041882667 + 1075475648 - 186644217 + 216769549;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(1 > 0);

      throw null;
   }

   public float getPitch() {
      return this.pitch;
   }

   public double getX() {
      return (double)((float)this.x / 8.0F);
   }

   public String getSoundName() {
      return this.soundName;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.soundName = var1.readStringFromBuffer(120 + 233 - 298 + 201);
      this.category = (SoundCategory)var1.readEnumValue(SoundCategory.class);
      this.x = var1.readInt();
      this.y = var1.readInt();
      this.z = var1.readInt();
      this.volume = var1.readFloat();
      this.pitch = var1.readFloat();
   }

   private static void I() {
      I = new String[22 ^ 25];
      I["".length()] = I("\f\u0005\u00001", "bdmTc");
      I[" ".length()] = I("夰", "ISKlI");
      I["  ".length()] = I("潙奊櫆揤", "CeheP");
      I["   ".length()] = I("故咛", "HscEd");
      I[179 ^ 183] = I("旍沅捼拻", "iLDfn");
      I[143 ^ 138] = I("暥倠", "wvwDD");
      I[117 ^ 115] = I("沫斿溎", "Dmwqz");
      I[135 ^ 128] = I("伭宖戣忢惪", "YjgFp");
      I[52 ^ 60] = I("弰弗湎", "gJygP");
      I[205 ^ 196] = I("懍姘", "HYjQf");
      I[175 ^ 165] = I("揧毳", "BySWC");
      I[174 ^ 165] = I("嘱坉哴", "EQsah");
      I[179 ^ 191] = I("挙沍", "UaxFK");
      I[6 ^ 11] = I("峠云", "opSRu");
      I[22 ^ 24] = I("屜咓悼烴", "AphMs");
   }

   public float getVolume() {
      return this.volume;
   }

   public double getZ() {
      return (double)((float)this.z / 8.0F);
   }

   public double getY() {
      return (double)((float)this.y / 8.0F);
   }

   static {
      I();
   }
}

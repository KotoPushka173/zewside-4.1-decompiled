package net.minecraft.block;

import java.util.Iterator;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.InventoryLargeChest;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.ILockableContainer;
import net.minecraft.world.World;

public class BlockChest extends BlockContainer {
   // $FF: synthetic field
   public static final PropertyDirection FACING;
   // $FF: synthetic field
   protected static final AxisAlignedBB NOT_CONNECTED_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB WEST_CHEST_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB NORTH_CHEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB SOUTH_CHEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB EAST_CHEST_AABB;
   // $FF: synthetic field
   public final BlockChest.Type chestType;

   public EnumBlockRenderType getRenderType(IBlockState var1) {
      return EnumBlockRenderType.ENTITYBLOCK_ANIMATED;
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (var1.isRemote) {
         return (boolean)" ".length();
      } else {
         ILockableContainer var10 = this.getLockableContainer(var1, var2);
         if (var10 != null) {
            var4.displayGUIChest(var10);
            if (this.chestType == BlockChest.Type.BASIC) {
               var4.addStat(StatList.CHEST_OPENED);
               "".length();
               if (4 < 1) {
                  throw null;
               }
            } else if (this.chestType == BlockChest.Type.TRAP) {
               var4.addStat(StatList.TRAPPED_CHEST_TRIGGERED);
            }
         }

         return (boolean)" ".length();
      }
   }

   public int getMetaFromState(IBlockState var1) {
      return ((EnumFacing)var1.getValue(FACING)).getIndex();
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      EnumFacing var6 = EnumFacing.byHorizontalIndex(MathHelper.floor((double)(var4.rotationYaw * 4.0F / 360.0F) + 0.5D) & "   ".length()).getOpposite();
      var3 = var3.withProperty(FACING, var6);
      BlockPos var7 = var2.north();
      BlockPos var8 = var2.south();
      BlockPos var9 = var2.west();
      BlockPos var10 = var2.east();
      int var10000;
      if (this == var1.getBlockState(var7).getBlock()) {
         var10000 = " ".length();
         "".length();
         if (4 == 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var11 = var10000;
      if (this == var1.getBlockState(var8).getBlock()) {
         var10000 = " ".length();
         "".length();
         if (3 != 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var12 = var10000;
      if (this == var1.getBlockState(var9).getBlock()) {
         var10000 = " ".length();
         "".length();
         if (4 == 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var13 = var10000;
      if (this == var1.getBlockState(var10).getBlock()) {
         var10000 = " ".length();
         "".length();
         if (1 == -1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      int var14 = var10000;
      if (var11 == 0 && var12 == 0 && var13 == 0 && var14 == 0) {
         var1.setBlockState(var2, var3, "   ".length());
         I["   ".length()].length();
         I[140 ^ 136].length();
         I[31 ^ 26].length();
         "".length();
         if (1 >= 3) {
            throw null;
         }
      } else if (var6.getAxis() != EnumFacing.Axis.X || var11 == 0 && var12 == 0) {
         if (var6.getAxis() == EnumFacing.Axis.Z && (var13 != 0 || var14 != 0)) {
            if (var13 != 0) {
               var1.setBlockState(var9, var3, "   ".length());
               I[169 ^ 175].length();
               I[51 ^ 52].length();
               I[184 ^ 176].length();
               I[144 ^ 153].length();
               I[104 ^ 98].length();
               "".length();
               if (-1 >= 0) {
                  throw null;
               }
            } else {
               var1.setBlockState(var10, var3, "   ".length());
               I[174 ^ 165].length();
               I[167 ^ 171].length();
               I[107 ^ 102].length();
            }

            var1.setBlockState(var2, var3, "   ".length());
            I[13 ^ 3].length();
            I[43 ^ 36].length();
            I[131 ^ 147].length();
            "".length();
            if (-1 >= 3) {
               throw null;
            }
         }
      } else {
         if (var11 != 0) {
            var1.setBlockState(var7, var3, "   ".length());
            I[74 ^ 91].length();
            I[213 ^ 199].length();
            "".length();
            if (4 <= 3) {
               throw null;
            }
         } else {
            var1.setBlockState(var8, var3, "   ".length());
            I[159 ^ 140].length();
            I[117 ^ 97].length();
            I[30 ^ 11].length();
         }

         var1.setBlockState(var2, var3, "   ".length());
         I[176 ^ 166].length();
         I[138 ^ 157].length();
         I[11 ^ 19].length();
      }

      if (var5.hasDisplayName()) {
         TileEntity var15 = var1.getTileEntity(var2);
         if (var15 instanceof TileEntityChest) {
            ((TileEntityChest)var15).func_190575_a(var5.getDisplayName());
         }
      }

   }

   private boolean isOcelotSittingOnChest(World var1, BlockPos var2) {
      String var10000 = I[16 ^ 35];
      String var10001 = I[3 ^ 55];
      String var10002 = I[147 ^ 166];
      var10001 = I[59 ^ 13];
      I[14 ^ 57].length();
      I[105 ^ 81].length();
      I[67 ^ 122].length();
      Iterator var3 = var1.getEntitiesWithinAABB(EntityOcelot.class, new AxisAlignedBB((double)var2.getX(), (double)(var2.getY() + " ".length()), (double)var2.getZ(), (double)(var2.getX() + " ".length()), (double)(var2.getY() + "  ".length()), (double)(var2.getZ() + " ".length()))).iterator();

      do {
         if (!var3.hasNext()) {
            return (boolean)"".length();
         }

         Entity var4 = (Entity)var3.next();
         EntityOcelot var5 = (EntityOcelot)var4;
         if (var5.isSitting()) {
            return (boolean)" ".length();
         }

         "".length();
      } while(3 > 1);

      throw null;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   public boolean canPlaceBlockAt(World var1, BlockPos var2) {
      int var3 = "".length();
      BlockPos var4 = var2.west();
      BlockPos var5 = var2.east();
      BlockPos var6 = var2.north();
      BlockPos var7 = var2.south();
      if (var1.getBlockState(var4).getBlock() == this) {
         if (this.isDoubleChest(var1, var4)) {
            return (boolean)"".length();
         }

         ++var3;
      }

      if (var1.getBlockState(var5).getBlock() == this) {
         if (this.isDoubleChest(var1, var5)) {
            return (boolean)"".length();
         }

         ++var3;
      }

      if (var1.getBlockState(var6).getBlock() == this) {
         if (this.isDoubleChest(var1, var6)) {
            return (boolean)"".length();
         }

         ++var3;
      }

      if (var1.getBlockState(var7).getBlock() == this) {
         if (this.isDoubleChest(var1, var7)) {
            return (boolean)"".length();
         }

         ++var3;
      }

      int var10000;
      if (var3 <= " ".length()) {
         var10000 = " ".length();
         "".length();
         if (2 <= 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[104 ^ 82];
      String var10001 = I[111 ^ 84];
      String var10002 = I[133 ^ 185];
      var10001 = I[40 ^ 21];
      var10000 = I[178 ^ 140];
      var10001 = I[92 ^ 99];
      var10002 = I[242 ^ 178];
      var10001 = I[94 ^ 31];
      I[133 ^ 199].length();
      I[118 ^ 53].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[115 ^ 55].length();
      I[237 ^ 168].length();
      I[118 ^ 48].length();
      I[193 ^ 134].length();
      var10003["".length()] = FACING;
      return new BlockStateContainer(this, var10003);
   }

   @Nullable
   public ILockableContainer getContainer(World var1, BlockPos var2, boolean var3) {
      String var10000 = I[10 ^ 17];
      String var10001 = I[29 ^ 1];
      String var10002 = I[98 ^ 127];
      var10001 = I[100 ^ 122];
      var10000 = I[44 ^ 51];
      var10001 = I[26 ^ 58];
      var10002 = I[125 ^ 92];
      var10001 = I[174 ^ 140];
      TileEntity var4 = var1.getTileEntity(var2);
      if (!(var4 instanceof TileEntityChest)) {
         return null;
      } else {
         Object var5 = (TileEntityChest)var4;
         if (!var3 && this.isBlocked(var1, var2)) {
            return null;
         } else {
            Iterator var6 = EnumFacing.Plane.HORIZONTAL.iterator();

            do {
               if (!var6.hasNext()) {
                  return (ILockableContainer)var5;
               }

               EnumFacing var7 = (EnumFacing)var6.next();
               BlockPos var8 = var2.offset(var7);
               Block var9 = var1.getBlockState(var8).getBlock();
               if (var9 == this) {
                  if (this.isBlocked(var1, var8)) {
                     return null;
                  }

                  TileEntity var10 = var1.getTileEntity(var8);
                  if (var10 instanceof TileEntityChest) {
                     if (var7 != EnumFacing.WEST && var7 != EnumFacing.NORTH) {
                        I[31 ^ 60].length();
                        I[23 ^ 51].length();
                        var5 = new InventoryLargeChest(I[65 ^ 100], (ILockableContainer)var5, (TileEntityChest)var10);
                        "".length();
                        if (3 < 2) {
                           throw null;
                        }
                     } else {
                        I[79 ^ 105].length();
                        I[100 ^ 67].length();
                        I[119 ^ 95].length();
                        var5 = new InventoryLargeChest(I[92 ^ 117], (TileEntityChest)var10, (ILockableContainer)var5);
                     }
                  }
               }

               "".length();
            } while(2 != 0);

            throw null;
         }
      }
   }

   private static void I() {
      I = new String[247 ^ 191];
      I["".length()] = I("惴忍", "HxQlz");
      I[" ".length()] = I("振洯煋", "JXdhh");
      I["  ".length()] = I("北挨", "uQGtE");
      I["   ".length()] = I("抑檨", "zGfJy");
      I[79 ^ 75] = I("厇摸儾液匴", "ibShG");
      I[169 ^ 172] = I("匦嬽", "eGFds");
      I[140 ^ 138] = I("厘泟埿", "DhTbb");
      I[63 ^ 56] = I("嵕枆", "yUZGZ");
      I[99 ^ 107] = I("湕堯潯", "qDhmB");
      I[18 ^ 27] = I("墮", "GAKnD");
      I[52 ^ 62] = I("斷", "NmJZB");
      I[134 ^ 141] = I("往澸丼", "rfKBz");
      I[98 ^ 110] = I("擨丅倳捦属", "gbGOn");
      I[42 ^ 39] = I("囐", "apGKL");
      I[64 ^ 78] = I("摺渮歍", "atoTU");
      I[130 ^ 141] = I("撖曵吤戆単", "smobB");
      I[54 ^ 38] = I("娺圭泣廈", "tRCLo");
      I[124 ^ 109] = I("揳毷嚶沁汃", "OALKq");
      I[67 ^ 81] = I("涷", "CfgFK");
      I[185 ^ 170] = I("榤兕徾", "ppoTR");
      I[170 ^ 190] = I("枂儏", "WclpR");
      I[35 ^ 54] = I("欲潑恓棶崎", "zwjFf");
      I[190 ^ 168] = I("暥恤棕", "dOdZV");
      I[133 ^ 146] = I("憩咣抦", "ljuDU");
      I[90 ^ 66] = I("扭喛", "HMVls");
      I[139 ^ 146] = I("怰困媄", "rDkvL");
      I[68 ^ 94] = I("接", "ocELl");
      I[29 ^ 6] = I("偖娜", "kLQgm");
      I[179 ^ 175] = I("掛次", "Akynu");
      I[71 ^ 90] = I("烑攓", "nlhVw");
      I[76 ^ 82] = I("檐沓", "ajyNb");
      I[26 ^ 5] = I("潯库", "lmIpZ");
      I[97 ^ 65] = I("湃厬", "oeEVj");
      I[121 ^ 88] = I("柀乘", "ZrIpf");
      I[189 ^ 159] = I("婟灹", "MhNvO");
      I[111 ^ 76] = I("搸徿", "dAHny");
      I[119 ^ 83] = I("昵夎庐俎", "eEoIs");
      I[64 ^ 101] = I("\u0002';8'\b&0>h\u0002 0?2%' .*\u0004", "aHULF");
      I[226 ^ 196] = I("浫刦世匼", "rpMpU");
      I[99 ^ 68] = I("尩垱湤啶", "KwdQf");
      I[9 ^ 33] = I("中棟二", "uGpEE");
      I[86 ^ 127] = I("\t6#<\f\u00037(:C\t1(;\u0019.68*\u0001\u000f", "jYMHm");
      I[165 ^ 143] = I("帡恶", "qoorn");
      I[163 ^ 136] = I("厉朳", "KDRFN");
      I[14 ^ 34] = I("娷嗿", "WNbHP");
      I[48 ^ 29] = I("垏櫭", "bDrvg");
      I[155 ^ 181] = I("孾殄", "aSxbi");
      I[94 ^ 113] = I("修搛", "kzYuX");
      I[34 ^ 18] = I("墓捄梾庄參", "bGyfJ");
      I[24 ^ 41] = I("栚", "BynBD");
      I[183 ^ 133] = I("漫", "GBZFk");
      I[19 ^ 32] = I("墏歭", "BeOui");
      I[55 ^ 3] = I("垜愷", "kxBtP");
      I[76 ^ 121] = I("桲张", "IEgcP");
      I[172 ^ 154] = I("煹妔", "iUZcY");
      I[128 ^ 183] = I("惂", "UuRMx");
      I[171 ^ 147] = I("復彏濶", "hJlGd");
      I[80 ^ 105] = I("槒", "sRlTt");
      I[109 ^ 87] = I("柾孉", "UZqeD");
      I[103 ^ 92] = I("亍囯", "PhmyY");
      I[36 ^ 24] = I("晪嘬", "XgmhX");
      I[165 ^ 152] = I("掝悯", "RPSyI");
      I[170 ^ 148] = I("怘吇", "qNHVf");
      I[140 ^ 179] = I("厚厘", "axDHQ");
      I[200 ^ 136] = I("炴丰", "kMxjh");
      I[116 ^ 53] = I("塘勞", "DXqIW");
      I[29 ^ 95] = I("姙", "kFxWo");
      I[132 ^ 199] = I("溈売", "frXcN");
      I[58 ^ 126] = I("撱壃垡嫸", "mFYrb");
      I[26 ^ 95] = I("榔", "RHIeO");
      I[88 ^ 30] = I("剕", "POELC");
      I[66 ^ 5] = I("哕嗵暧墚刚", "tvJJw");
   }

   public boolean hasComparatorInputOverride(IBlockState var1) {
      return (boolean)" ".length();
   }

   public void breakBlock(World var1, BlockPos var2, IBlockState var3) {
      TileEntity var4 = var1.getTileEntity(var2);
      if (var4 instanceof IInventory) {
         InventoryHelper.dropInventoryItems(var1, var2, (IInventory)var4);
         var1.updateComparatorOutputLevel(var2, this);
      }

      super.breakBlock(var1, var2, var3);
   }

   public IBlockState correctFacing(World var1, BlockPos var2, IBlockState var3) {
      EnumFacing var4 = null;
      Iterator var5 = EnumFacing.Plane.HORIZONTAL.iterator();

      while(var5.hasNext()) {
         EnumFacing var6 = (EnumFacing)var5.next();
         IBlockState var7 = var1.getBlockState(var2.offset(var6));
         if (var7.getBlock() == this) {
            return var3;
         }

         if (var7.isFullBlock()) {
            if (var4 != null) {
               var4 = null;
               "".length();
               if (3 < 2) {
                  throw null;
               }
               break;
            }

            var4 = var6;
         }

         "".length();
         if (0 < -1) {
            throw null;
         }
      }

      if (var4 != null) {
         return var3.withProperty(FACING, var4.getOpposite());
      } else {
         EnumFacing var8 = (EnumFacing)var3.getValue(FACING);
         if (var1.getBlockState(var2.offset(var8)).isFullBlock()) {
            var8 = var8.getOpposite();
         }

         if (var1.getBlockState(var2.offset(var8)).isFullBlock()) {
            var8 = var8.rotateY();
         }

         if (var1.getBlockState(var2.offset(var8)).isFullBlock()) {
            var8 = var8.getOpposite();
         }

         return var3.withProperty(FACING, var8);
      }
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      if (var2.getBlockState(var3.north()).getBlock() == this) {
         return NORTH_CHEST_AABB;
      } else if (var2.getBlockState(var3.south()).getBlock() == this) {
         return SOUTH_CHEST_AABB;
      } else if (var2.getBlockState(var3.west()).getBlock() == this) {
         return WEST_CHEST_AABB;
      } else {
         AxisAlignedBB var10000;
         if (var2.getBlockState(var3.east()).getBlock() == this) {
            var10000 = EAST_CHEST_AABB;
            "".length();
            if (4 <= -1) {
               throw null;
            }
         } else {
            var10000 = NOT_CONNECTED_AABB;
         }

         return var10000;
      }
   }

   public int getStrongPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      int var10000;
      if (var4 == EnumFacing.UP) {
         var10000 = var1.getWeakPower(var2, var3, var4);
         "".length();
         if (1 <= 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   protected BlockChest(BlockChest.Type var1) {
      super(Material.WOOD);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
      this.chestType = var1;
      CreativeTabs var10001;
      if (var1 == BlockChest.Type.TRAP) {
         var10001 = CreativeTabs.REDSTONE;
         "".length();
         if (-1 == 3) {
            throw null;
         }
      } else {
         var10001 = CreativeTabs.DECORATIONS;
      }

      this.setCreativeTab(var10001);
   }

   @Nullable
   public ILockableContainer getLockableContainer(World var1, BlockPos var2) {
      return this.getContainer(var1, var2, (boolean)"".length());
   }

   private boolean isBelowSolidBlock(World var1, BlockPos var2) {
      return var1.getBlockState(var2.up()).isNormalCube();
   }

   private boolean isBlocked(World var1, BlockPos var2) {
      int var10000;
      if (!this.isBelowSolidBlock(var1, var2) && !this.isOcelotSittingOnChest(var1, var2)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public boolean canProvidePower(IBlockState var1) {
      int var10000;
      if (this.chestType == BlockChest.Type.TRAP) {
         var10000 = " ".length();
         "".length();
         if (-1 >= 0) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public boolean func_190946_v(IBlockState var1) {
      return (boolean)" ".length();
   }

   public int getComparatorInputOverride(IBlockState var1, World var2, BlockPos var3) {
      return Container.calcRedstoneFromInventory(this.getLockableContainer(var2, var3));
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      String var10000 = I[123 ^ 81];
      String var10001 = I[27 ^ 48];
      String var10002 = I[47 ^ 3];
      var10001 = I[1 ^ 44];
      I[6 ^ 40].length();
      I[73 ^ 102].length();
      I[136 ^ 184].length();
      I[155 ^ 170].length();
      I[3 ^ 49].length();
      return new TileEntityChest();
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      this.checkForSurroundingChests(var1, var2, var3);
      I["".length()].length();
      Iterator var4 = EnumFacing.Plane.HORIZONTAL.iterator();

      do {
         if (!var4.hasNext()) {
            return;
         }

         EnumFacing var5 = (EnumFacing)var4.next();
         BlockPos var6 = var2.offset(var5);
         IBlockState var7 = var1.getBlockState(var6);
         if (var7.getBlock() == this) {
            this.checkForSurroundingChests(var1, var6, var7);
            I[" ".length()].length();
            I["  ".length()].length();
         }

         "".length();
      } while(1 >= -1);

      throw null;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      super.neighborChanged(var1, var2, var3, var4, var5);
      TileEntity var6 = var2.getTileEntity(var3);
      if (var6 instanceof TileEntityChest) {
         var6.updateContainingBlockInfo();
      }

   }

   public int getWeakPower(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      if (!var1.canProvidePower()) {
         return "".length();
      } else {
         int var5 = "".length();
         TileEntity var6 = var2.getTileEntity(var3);
         if (var6 instanceof TileEntityChest) {
            var5 = ((TileEntityChest)var6).numPlayersUsing;
         }

         return MathHelper.clamp(var5, "".length(), 164 ^ 171);
      }
   }

   public IBlockState getStateFromMeta(int var1) {
      EnumFacing var2 = EnumFacing.getFront(var1);
      if (var2.getAxis() == EnumFacing.Axis.Y) {
         var2 = EnumFacing.NORTH;
      }

      return this.getDefaultState().withProperty(FACING, var2);
   }

   static {
      I();
      FACING = BlockHorizontal.FACING;
      NORTH_CHEST_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0D, 0.9375D, 0.875D, 0.9375D);
      SOUTH_CHEST_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.875D, 1.0D);
      WEST_CHEST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0625D, 0.9375D, 0.875D, 0.9375D);
      EAST_CHEST_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 1.0D, 0.875D, 0.9375D);
      NOT_CONNECTED_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.875D, 0.9375D);
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   private boolean isDoubleChest(World var1, BlockPos var2) {
      if (var1.getBlockState(var2).getBlock() != this) {
         return (boolean)"".length();
      } else {
         Iterator var3 = EnumFacing.Plane.HORIZONTAL.iterator();

         do {
            if (!var3.hasNext()) {
               return (boolean)"".length();
            }

            EnumFacing var4 = (EnumFacing)var3.next();
            if (var1.getBlockState(var2.offset(var4)).getBlock() == this) {
               return (boolean)" ".length();
            }

            "".length();
         } while(0 < 3);

         throw null;
      }
   }

   public IBlockState checkForSurroundingChests(World var1, BlockPos var2, IBlockState var3) {
      if (var1.isRemote) {
         return var3;
      } else {
         IBlockState var4 = var1.getBlockState(var2.north());
         IBlockState var5 = var1.getBlockState(var2.south());
         IBlockState var6 = var1.getBlockState(var2.west());
         IBlockState var7 = var1.getBlockState(var2.east());
         EnumFacing var8 = (EnumFacing)var3.getValue(FACING);
         BlockPos var10000;
         if (var4.getBlock() != this && var5.getBlock() != this) {
            boolean var15 = var4.isFullBlock();
            boolean var16 = var5.isFullBlock();
            if (var6.getBlock() == this || var7.getBlock() == this) {
               if (var6.getBlock() == this) {
                  var10000 = var2.west();
                  "".length();
                  if (4 != 4) {
                     throw null;
                  }
               } else {
                  var10000 = var2.east();
               }

               BlockPos var17 = var10000;
               IBlockState var18 = var1.getBlockState(var17.north());
               IBlockState var13 = var1.getBlockState(var17.south());
               var8 = EnumFacing.SOUTH;
               EnumFacing var14;
               if (var6.getBlock() == this) {
                  var14 = (EnumFacing)var6.getValue(FACING);
                  "".length();
                  if (4 <= -1) {
                     throw null;
                  }
               } else {
                  var14 = (EnumFacing)var7.getValue(FACING);
               }

               if (var14 == EnumFacing.NORTH) {
                  var8 = EnumFacing.NORTH;
               }

               if ((var15 || var18.isFullBlock()) && !var16 && !var13.isFullBlock()) {
                  var8 = EnumFacing.SOUTH;
               }

               if ((var16 || var13.isFullBlock()) && !var15 && !var18.isFullBlock()) {
                  var8 = EnumFacing.NORTH;
               }
            }

            "".length();
            if (3 == 2) {
               throw null;
            }
         } else {
            if (var4.getBlock() == this) {
               var10000 = var2.north();
               "".length();
               if (3 != 3) {
                  throw null;
               }
            } else {
               var10000 = var2.south();
            }

            BlockPos var9 = var10000;
            IBlockState var10 = var1.getBlockState(var9.west());
            IBlockState var11 = var1.getBlockState(var9.east());
            var8 = EnumFacing.EAST;
            EnumFacing var12;
            if (var4.getBlock() == this) {
               var12 = (EnumFacing)var4.getValue(FACING);
               "".length();
               if (false) {
                  throw null;
               }
            } else {
               var12 = (EnumFacing)var5.getValue(FACING);
            }

            if (var12 == EnumFacing.WEST) {
               var8 = EnumFacing.WEST;
            }

            if ((var6.isFullBlock() || var10.isFullBlock()) && !var7.isFullBlock() && !var11.isFullBlock()) {
               var8 = EnumFacing.EAST;
            }

            if ((var7.isFullBlock() || var11.isFullBlock()) && !var6.isFullBlock() && !var10.isFullBlock()) {
               var8 = EnumFacing.WEST;
            }
         }

         var3 = var3.withProperty(FACING, var8);
         var1.setBlockState(var2, var3, "   ".length());
         I[168 ^ 177].length();
         I[88 ^ 66].length();
         return var3;
      }
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > -1);

      throw null;
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      return BlockFaceShape.UNDEFINED;
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, var8.getHorizontalFacing());
   }

   public static enum Type {
      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      TRAP,
      // $FF: synthetic field
      BASIC;

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(2 != 4);

         throw null;
      }

      private static void I() {
         I = new String["  ".length()];
         I["".length()] = I(" \u0004\u0001\u0010&", "bERYe");
         I[" ".length()] = I("9\"5\u0002", "mptRw");
      }

      static {
         I();
         BASIC = new BlockChest.Type(I["".length()], "".length());
         TRAP = new BlockChest.Type(I[" ".length()], " ".length());
         BlockChest.Type[] var10000 = new BlockChest.Type["  ".length()];
         var10000["".length()] = BASIC;
         var10000[" ".length()] = TRAP;
      }
   }
}

package net.minecraft.network.login.client;

import java.io.IOException;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.SecretKey;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.login.INetHandlerLoginServer;
import net.minecraft.util.CryptManager;

public class CPacketEncryptionResponse implements Packet<INetHandlerLoginServer> {
   // $FF: synthetic field
   private byte[] verifyTokenEncrypted = new byte["".length()];
   // $FF: synthetic field
   private byte[] secretKeyEncrypted = new byte["".length()];
   // $FF: synthetic field
   private static final String[] I;

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByteArray(this.secretKeyEncrypted);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      var1.writeByteArray(this.verifyTokenEncrypted);
      I["   ".length()].length();
      I[182 ^ 178].length();
   }

   public byte[] getVerifyToken(PrivateKey var1) {
      byte[] var10000;
      if (var1 == null) {
         var10000 = this.verifyTokenEncrypted;
         "".length();
         if (0 < -1) {
            throw null;
         }
      } else {
         var10000 = CryptManager.decryptData(var1, this.verifyTokenEncrypted);
      }

      return var10000;
   }

   public CPacketEncryptionResponse(SecretKey var1, PublicKey var2, byte[] var3) {
      this.secretKeyEncrypted = CryptManager.encryptData(var2, var1.getEncoded());
      this.verifyTokenEncrypted = CryptManager.encryptData(var2, var3);
   }

   public SecretKey getSecretKey(PrivateKey var1) {
      return CryptManager.decryptSharedKey(var1, this.secretKeyEncrypted);
   }

   public CPacketEncryptionResponse() {
   }

   public void processPacket(INetHandlerLoginServer var1) {
      var1.processEncryptionResponse(this);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(true);

      throw null;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.secretKeyEncrypted = var1.readByteArray();
      this.verifyTokenEncrypted = var1.readByteArray();
   }

   private static void I() {
      I = new String[107 ^ 110];
      I["".length()] = I("咶灮木俌", "qaASm");
      I[" ".length()] = I("懜", "YebWe");
      I["  ".length()] = I("椙", "ahJaM");
      I["   ".length()] = I("巇", "dERtv");
      I[194 ^ 198] = I("崎岃", "CbHxM");
   }

   static {
      I();
   }
}

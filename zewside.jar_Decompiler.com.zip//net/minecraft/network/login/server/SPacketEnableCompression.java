package net.minecraft.network.login.server;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.login.INetHandlerLoginClient;

public class SPacketEnableCompression implements Packet<INetHandlerLoginClient> {
   // $FF: synthetic field
   private int compressionThreshold;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   private static void I() {
      I = new String["   ".length()];
      I["".length()] = I("克柹桯摡", "KOQky");
      I[" ".length()] = I("歖埛劼氠揼", "qOpQz");
      I["  ".length()] = I("巕", "tEnAm");
   }

   public void processPacket(INetHandlerLoginClient var1) {
      var1.handleEnableCompression(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.compressionThreshold);
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.compressionThreshold = var1.readVarIntFromBuffer();
   }

   public SPacketEnableCompression() {
   }

   public int getCompressionThreshold() {
      return this.compressionThreshold;
   }

   static {
      I();
   }

   public SPacketEnableCompression(int var1) {
      this.compressionThreshold = var1;
   }
}

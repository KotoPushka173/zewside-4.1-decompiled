package net.minecraft.network.play.server;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketEntityProperties implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private int entityId;
   // $FF: synthetic field
   private final List<SPacketEntityProperties.Snapshot> snapshots = Lists.newArrayList();
   // $FF: synthetic field
   private static final String[] I;

   public List<SPacketEntityProperties.Snapshot> getSnapshots() {
      return this.snapshots;
   }

   public int getEntityId() {
      return this.entityId;
   }

   public SPacketEntityProperties(int var1, Collection<IAttributeInstance> var2) {
      this.entityId = var1;
      Iterator var3 = var2.iterator();

      do {
         if (!var3.hasNext()) {
            return;
         }

         IAttributeInstance var4 = (IAttributeInstance)var3.next();
         this.snapshots.add(new SPacketEntityProperties.Snapshot(var4.getAttribute().getAttributeUnlocalizedName(), var4.getBaseValue(), var4.getModifiers()));
         "".length();
      } while(true);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 == 3);

      throw null;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeVarIntToBuffer(this.entityId);
      I[148 ^ 129].length();
      I[131 ^ 149].length();
      I[50 ^ 37].length();
      I[144 ^ 136].length();
      var1.writeInt(this.snapshots.size());
      I[82 ^ 75].length();
      I[221 ^ 199].length();
      Iterator var2 = this.snapshots.iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         SPacketEntityProperties.Snapshot var3 = (SPacketEntityProperties.Snapshot)var2.next();
         var1.writeString(var3.getName());
         I[46 ^ 53].length();
         I[10 ^ 22].length();
         var1.writeDouble(var3.getBaseValue());
         I[21 ^ 8].length();
         I[135 ^ 153].length();
         var1.writeVarIntToBuffer(var3.getModifiers().size());
         I[59 ^ 36].length();
         I[162 ^ 130].length();
         I[230 ^ 199].length();
         Iterator var4 = var3.getModifiers().iterator();

         while(var4.hasNext()) {
            AttributeModifier var5 = (AttributeModifier)var4.next();
            var1.writeUuid(var5.getID());
            I[137 ^ 171].length();
            I[159 ^ 188].length();
            I[106 ^ 78].length();
            var1.writeDouble(var5.getAmount());
            I[140 ^ 169].length();
            var1.writeByte(var5.getOperation());
            I[48 ^ 22].length();
            I[95 ^ 120].length();
            I[129 ^ 169].length();
            I[125 ^ 84].length();
            "".length();
            if (1 < -1) {
               throw null;
            }
         }

         "".length();
      } while(3 > -1);

      throw null;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.handleEntityProperties(this);
   }

   public SPacketEntityProperties() {
   }

   private static void I() {
      I = new String[179 ^ 153];
      I["".length()] = I("憲敹", "ksfDp");
      I[" ".length()] = I("湀岋", "XgTyF");
      I["  ".length()] = I("戙圩", "zbiir");
      I["   ".length()] = I("巼悿", "vvHfh");
      I[102 ^ 98] = I("囂力", "LOvsf");
      I[160 ^ 165] = I("府捯", "evEXv");
      I[13 ^ 11] = I("揁徆", "mkqqn");
      I[72 ^ 79] = I("滉淍", "vPwuW");
      I[82 ^ 90] = I("栦炟", "qJFJq");
      I[107 ^ 98] = I("忇桎揧凹", "sFJAD");
      I[137 ^ 131] = I("湀", "RxYQD");
      I[182 ^ 189] = I("\f/\t\u001c8./B\u0001.7\"\u0007\u0016w85\u0016\u0000>;4\u0016\u0017w4.\u0006\u001b10$\u0010", "YAbrW");
      I[161 ^ 173] = I("勇卺段", "yjsoX");
      I[128 ^ 141] = I("幁厚", "cxjqw");
      I[157 ^ 147] = I("堄峺淖", "Ndtdv");
      I[144 ^ 159] = I("曑囜冟湜", "CoPlm");
      I[151 ^ 135] = I("暅", "pDANF");
      I[77 ^ 92] = I("格", "fmtej");
      I[27 ^ 9] = I("梍巃懊", "UAkFb");
      I[73 ^ 90] = I("啪", "Fltdc");
      I[106 ^ 126] = I("汆帺", "lLsSj");
      I[165 ^ 176] = I("澸尬", "twPoi");
      I[19 ^ 5] = I("咫泮曜溬溊", "znuJX");
      I[51 ^ 36] = I("搰尹", "JYovD");
      I[141 ^ 149] = I("愿卤", "JVGQS");
      I[84 ^ 77] = I("偞涿傃堥", "itnaN");
      I[127 ^ 101] = I("帐噪栵崨", "ccpTd");
      I[19 ^ 8] = I("檣呴", "ddZEr");
      I[29 ^ 1] = I("汲垟巳", "ZWLlj");
      I[24 ^ 5] = I("涿匶柼帿", "weRan");
      I[123 ^ 101] = I("屧", "MCJQe");
      I[114 ^ 109] = I("坊", "NcaXw");
      I[20 ^ 52] = I("欣劒", "UItii");
      I[225 ^ 192] = I("埄灸僈", "ZisZm");
      I[146 ^ 176] = I("戺揮婤嘡", "YuQqJ");
      I[133 ^ 166] = I("孍搢", "aYUeO");
      I[135 ^ 163] = I("喇榙儭堨交", "inTNz");
      I[181 ^ 144] = I("旣溹溨俸", "mjbxs");
      I[225 ^ 199] = I("俪", "muxpg");
      I[11 ^ 44] = I("捦椶在", "GbgMl");
      I[94 ^ 118] = I("圦", "surhp");
      I[176 ^ 153] = I("櫺圃噞囝", "Xweel");
   }

   static {
      I();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[147 ^ 151];
      var10001 = I[92 ^ 89];
      var10002 = I[165 ^ 163];
      var10001 = I[190 ^ 185];
      this.entityId = var1.readVarIntFromBuffer();
      int var2 = var1.readInt();
      int var3 = "".length();

      do {
         if (var3 >= var2) {
            return;
         }

         String var4 = var1.readStringFromBuffer(210 ^ 146);
         double var5 = var1.readDouble();
         ArrayList var7 = Lists.newArrayList();
         int var8 = var1.readVarIntFromBuffer();
         int var9 = "".length();

         while(var9 < var8) {
            UUID var10 = var1.readUuid();
            I[96 ^ 104].length();
            I[78 ^ 71].length();
            I[29 ^ 23].length();
            var7.add(new AttributeModifier(var10, I[55 ^ 60], var1.readDouble(), var1.readByte()));
            I[143 ^ 131].length();
            I[125 ^ 112].length();
            I[27 ^ 21].length();
            ++var9;
            "".length();
            if (4 < 2) {
               throw null;
            }
         }

         List var11 = this.snapshots;
         I[30 ^ 17].length();
         I[154 ^ 138].length();
         I[100 ^ 117].length();
         var11.add(new SPacketEntityProperties.Snapshot(var4, var5, var7));
         I[44 ^ 62].length();
         I[101 ^ 118].length();
         I[52 ^ 32].length();
         ++var3;
         "".length();
      } while(4 > 3);

      throw null;
   }

   public class Snapshot {
      // $FF: synthetic field
      private final Collection<AttributeModifier> modifiers;
      // $FF: synthetic field
      private final double baseValue;
      // $FF: synthetic field
      private final String name;

      public Snapshot(String var2, double var3, Collection<AttributeModifier> var5) {
         this.name = var2;
         this.baseValue = var3;
         this.modifiers = var5;
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(0 < 2);

         throw null;
      }

      public double getBaseValue() {
         return this.baseValue;
      }

      public Collection<AttributeModifier> getModifiers() {
         return this.modifiers;
      }

      public String getName() {
         return this.name;
      }
   }
}

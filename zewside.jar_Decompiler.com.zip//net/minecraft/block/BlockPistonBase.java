package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockPistonStructureHelper;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityPiston;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockPistonBase extends BlockDirectional {
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_BASE_DOWN_AABB;
   // $FF: synthetic field
   private final boolean isSticky;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_BASE_UP_AABB;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_BASE_EAST_AABB;
   // $FF: synthetic field
   public static final PropertyBool EXTENDED;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_BASE_SOUTH_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_BASE_WEST_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB PISTON_BASE_NORTH_AABB;

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   public IBlockState getStateForPlacement(World var1, BlockPos var2, EnumFacing var3, float var4, float var5, float var6, int var7, EntityLivingBase var8) {
      return this.getDefaultState().withProperty(FACING, EnumFacing.func_190914_a(var2, var8)).withProperty(EXTENDED, Boolean.valueOf((boolean)"".length()));
   }

   public boolean eventReceived(IBlockState var1, World var2, BlockPos var3, int var4, int var5) {
      EnumFacing var6 = (EnumFacing)var1.getValue(FACING);
      if (!var2.isRemote) {
         boolean var7 = this.shouldBeExtended(var2, var3, var6);
         if (var7 && var4 == " ".length()) {
            var2.setBlockState(var3, var1.withProperty(EXTENDED, Boolean.valueOf((boolean)" ".length())), "  ".length());
            I[190 ^ 182].length();
            I[191 ^ 182].length();
            I[149 ^ 159].length();
            return (boolean)"".length();
         }

         if (!var7 && var4 == 0) {
            return (boolean)"".length();
         }
      }

      if (var4 == 0) {
         if (!this.doMove(var2, var3, var6, (boolean)" ".length())) {
            return (boolean)"".length();
         }

         var2.setBlockState(var3, var1.withProperty(EXTENDED, Boolean.valueOf((boolean)" ".length())), "   ".length());
         I[171 ^ 160].length();
         I[140 ^ 128].length();
         I[137 ^ 132].length();
         var2.playSound((EntityPlayer)null, var3, SoundEvents.BLOCK_PISTON_EXTEND, SoundCategory.BLOCKS, 0.5F, var2.rand.nextFloat() * 0.25F + 0.6F);
         "".length();
         if (4 <= -1) {
            throw null;
         }
      } else if (var4 == " ".length()) {
         TileEntity var14 = var2.getTileEntity(var3.offset(var6));
         if (var14 instanceof TileEntityPiston) {
            ((TileEntityPiston)var14).clearPistonTileEntity();
         }

         IBlockState var10002 = Blocks.PISTON_EXTENSION.getDefaultState().withProperty(BlockPistonMoving.FACING, var6);
         PropertyEnum var10003 = BlockPistonMoving.TYPE;
         BlockPistonExtension.EnumPistonType var10004;
         if (this.isSticky) {
            var10004 = BlockPistonExtension.EnumPistonType.STICKY;
            "".length();
            if (4 <= 1) {
               throw null;
            }
         } else {
            var10004 = BlockPistonExtension.EnumPistonType.DEFAULT;
         }

         var2.setBlockState(var3, var10002.withProperty(var10003, var10004), "   ".length());
         I[111 ^ 97].length();
         I[206 ^ 193].length();
         var2.setTileEntity(var3, BlockPistonMoving.createTilePiston(this.getStateFromMeta(var5), var6, (boolean)"".length(), (boolean)" ".length()));
         if (this.isSticky) {
            BlockPos var8 = var3.add(var6.getFrontOffsetX() * "  ".length(), var6.getFrontOffsetY() * "  ".length(), var6.getFrontOffsetZ() * "  ".length());
            IBlockState var9 = var2.getBlockState(var8);
            Block var10 = var9.getBlock();
            int var11 = "".length();
            if (var10 == Blocks.PISTON_EXTENSION) {
               TileEntity var12 = var2.getTileEntity(var8);
               if (var12 instanceof TileEntityPiston) {
                  TileEntityPiston var13 = (TileEntityPiston)var12;
                  if (var13.getFacing() == var6 && var13.isExtending()) {
                     var13.clearPistonTileEntity();
                     var11 = " ".length();
                  }
               }
            }

            if (var11 == 0 && var9.getMaterial() != Material.AIR && canPush(var9, var2, var8, var6.getOpposite(), (boolean)"".length(), var6) && (var9.getMobilityFlag() == EnumPushReaction.NORMAL || var10 == Blocks.PISTON || var10 == Blocks.STICKY_PISTON)) {
               this.doMove(var2, var3, var6, (boolean)"".length());
               I[147 ^ 131].length();
               I[105 ^ 120].length();
               I[179 ^ 161].length();
            }

            "".length();
            if (-1 >= 0) {
               throw null;
            }
         } else {
            var2.setBlockToAir(var3.offset(var6));
            I[27 ^ 8].length();
            I[169 ^ 189].length();
            I[56 ^ 45].length();
            I[171 ^ 189].length();
         }

         var2.playSound((EntityPlayer)null, var3, SoundEvents.BLOCK_PISTON_CONTRACT, SoundCategory.BLOCKS, 0.5F, var2.rand.nextFloat() * 0.15F + 0.6F);
      }

      return (boolean)" ".length();
   }

   public boolean causesSuffocation(IBlockState var1) {
      int var10000;
      if (!(Boolean)var1.getValue(EXTENDED)) {
         var10000 = " ".length();
         "".length();
         if (4 <= 3) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return (boolean)var10000;
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      return var1.withRotation(var2.toRotation((EnumFacing)var1.getValue(FACING)));
   }

   static {
      I();
      EXTENDED = PropertyBool.create(I[110 ^ 32]);
      PISTON_BASE_EAST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.75D, 1.0D, 1.0D);
      PISTON_BASE_WEST_AABB = new AxisAlignedBB(0.25D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      PISTON_BASE_SOUTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.75D);
      PISTON_BASE_NORTH_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.25D, 1.0D, 1.0D, 1.0D);
      PISTON_BASE_UP_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.75D, 1.0D);
      PISTON_BASE_DOWN_AABB = new AxisAlignedBB(0.0D, 0.25D, 0.0D, 1.0D, 1.0D, 1.0D);
   }

   private boolean doMove(World var1, BlockPos var2, EnumFacing var3, boolean var4) {
      String var10000 = I[79 ^ 82];
      String var10001 = I[24 ^ 6];
      String var10002 = I[162 ^ 189];
      var10001 = I[57 ^ 25];
      if (!var4) {
         var1.setBlockToAir(var2.offset(var3));
         I[113 ^ 80].length();
         I[17 ^ 51].length();
         I[15 ^ 44].length();
         I[162 ^ 134].length();
      }

      I[130 ^ 167].length();
      I[54 ^ 16].length();
      I[108 ^ 75].length();
      BlockPistonStructureHelper var5 = new BlockPistonStructureHelper(var1, var2, var3, var4);
      if (!var5.canMove()) {
         return (boolean)"".length();
      } else {
         List var6 = var5.getBlocksToMove();
         ArrayList var7 = Lists.newArrayList();
         int var8 = "".length();

         do {
            if (var8 >= var6.size()) {
               List var16 = var5.getBlocksToDestroy();
               int var17 = var6.size() + var16.size();
               IBlockState[] var10 = new IBlockState[var17];
               EnumFacing var21;
               if (var4) {
                  var21 = var3;
                  "".length();
                  if (4 <= 3) {
                     throw null;
                  }
               } else {
                  var21 = var3.getOpposite();
               }

               EnumFacing var11 = var21;
               int var22 = var16.size();
               int var23 = " ".length();
               I[14 ^ 39].length();
               I[19 ^ 57].length();
               I[75 ^ 96].length();
               I[165 ^ 137].length();
               int var12 = var22 - var23;

               do {
                  BlockPos var13;
                  IBlockState var14;
                  if (var12 < 0) {
                     var22 = var6.size();
                     var23 = " ".length();
                     I[118 ^ 70].length();
                     I[160 ^ 145].length();
                     var12 = var22 - var23;

                     do {
                        if (var12 < 0) {
                           BlockPos var18 = var2.offset(var3);
                           if (var4) {
                              BlockPistonExtension.EnumPistonType var24;
                              if (this.isSticky) {
                                 var24 = BlockPistonExtension.EnumPistonType.STICKY;
                                 "".length();
                                 if (false) {
                                    throw null;
                                 }
                              } else {
                                 var24 = BlockPistonExtension.EnumPistonType.DEFAULT;
                              }

                              BlockPistonExtension.EnumPistonType var19 = var24;
                              var14 = Blocks.PISTON_HEAD.getDefaultState().withProperty(BlockPistonExtension.FACING, var3).withProperty(BlockPistonExtension.TYPE, var19);
                              IBlockState var27 = Blocks.PISTON_EXTENSION.getDefaultState().withProperty(BlockPistonMoving.FACING, var3);
                              PropertyEnum var25 = BlockPistonMoving.TYPE;
                              BlockPistonExtension.EnumPistonType var26;
                              if (this.isSticky) {
                                 var26 = BlockPistonExtension.EnumPistonType.STICKY;
                                 "".length();
                                 if (-1 != -1) {
                                    throw null;
                                 }
                              } else {
                                 var26 = BlockPistonExtension.EnumPistonType.DEFAULT;
                              }

                              IBlockState var15 = var27.withProperty(var25, var26);
                              var1.setBlockState(var18, var15, 28 ^ 24);
                              I[186 ^ 141].length();
                              var1.setTileEntity(var18, BlockPistonMoving.createTilePiston(var14, var3, (boolean)" ".length(), (boolean)" ".length()));
                           }

                           var22 = var16.size();
                           var23 = " ".length();
                           I[36 ^ 28].length();
                           I[162 ^ 155].length();
                           I[171 ^ 145].length();
                           int var20 = var22 - var23;

                           do {
                              if (var20 < 0) {
                                 var22 = var6.size();
                                 var23 = " ".length();
                                 I[120 ^ 67].length();
                                 I[164 ^ 152].length();
                                 I[187 ^ 134].length();
                                 var20 = var22 - var23;

                                 do {
                                    if (var20 < 0) {
                                       if (var4) {
                                          var1.notifyNeighborsOfStateChange(var18, Blocks.PISTON_HEAD, (boolean)"".length());
                                       }

                                       return (boolean)" ".length();
                                    }

                                    var1.notifyNeighborsOfStateChange((BlockPos)var6.get(var20), var10[var17++].getBlock(), (boolean)"".length());
                                    --var20;
                                    "".length();
                                 } while(4 >= 3);

                                 throw null;
                              }

                              var1.notifyNeighborsOfStateChange((BlockPos)var16.get(var20), var10[var17++].getBlock(), (boolean)"".length());
                              --var20;
                              "".length();
                           } while(3 >= 2);

                           throw null;
                        }

                        var13 = (BlockPos)var6.get(var12);
                        var14 = var1.getBlockState(var13);
                        var1.setBlockState(var13, Blocks.AIR.getDefaultState(), "  ".length());
                        I[44 ^ 30].length();
                        I[120 ^ 75].length();
                        I[142 ^ 186].length();
                        var13 = var13.offset(var11);
                        var1.setBlockState(var13, Blocks.PISTON_EXTENSION.getDefaultState().withProperty(FACING, var3), 38 ^ 34);
                        I[88 ^ 109].length();
                        I[144 ^ 166].length();
                        var1.setTileEntity(var13, BlockPistonMoving.createTilePiston((IBlockState)var7.get(var12), var3, var4, (boolean)"".length()));
                        --var17;
                        var10[var17] = var14;
                        --var12;
                        "".length();
                     } while(0 != 2);

                     throw null;
                  }

                  var13 = (BlockPos)var16.get(var12);
                  var14 = var1.getBlockState(var13);
                  var14.getBlock().dropBlockAsItem(var1, var13, var14, "".length());
                  var1.setBlockState(var13, Blocks.AIR.getDefaultState(), 75 ^ 79);
                  I[177 ^ 156].length();
                  I[18 ^ 60].length();
                  I[135 ^ 168].length();
                  --var17;
                  var10[var17] = var14;
                  --var12;
                  "".length();
               } while(4 >= 0);

               throw null;
            }

            BlockPos var9 = (BlockPos)var6.get(var8);
            var7.add(var1.getBlockState(var9).getActualState(var1, var9));
            I[12 ^ 36].length();
            ++var8;
            "".length();
         } while(true);

         throw null;
      }
   }

   public void onBlockPlacedBy(World var1, BlockPos var2, IBlockState var3, EntityLivingBase var4, ItemStack var5) {
      var1.setBlockState(var2, var3.withProperty(FACING, EnumFacing.func_190914_a(var2, var4)), "  ".length());
      I["".length()].length();
      I[" ".length()].length();
      I["  ".length()].length();
      if (!var1.isRemote) {
         this.checkForMove(var1, var2, var3);
      }

   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      var2 = this.getActualState(var2, var1, var3);
      BlockFaceShape var10000;
      if (var2.getValue(FACING) != var4.getOpposite() && (Boolean)var2.getValue(EXTENDED)) {
         var10000 = BlockFaceShape.UNDEFINED;
         "".length();
         if (0 >= 3) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.SOLID;
      }

      return var10000;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 == 2);

      throw null;
   }

   public BlockPistonBase(boolean var1) {
      super(Material.PISTON);
      this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(EXTENDED, Boolean.valueOf((boolean)"".length())));
      this.isSticky = var1;
      this.setSoundType(SoundType.STONE);
      this.setHardness(0.5F);
      this.setCreativeTab(CreativeTabs.REDSTONE);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      if (!var2.isRemote) {
         this.checkForMove(var2, var3, var1);
      }

   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[40 ^ 22];
      String var10001 = I[106 ^ 85];
      String var10002 = I[193 ^ 129];
      var10001 = I[64 ^ 1];
      var10000 = I[221 ^ 159];
      var10001 = I[101 ^ 38];
      var10002 = I[64 ^ 4];
      var10001 = I[43 ^ 110];
      var10000 = I[75 ^ 13];
      var10001 = I[130 ^ 197];
      var10002 = I[224 ^ 168];
      var10001 = I[75 ^ 2];
      I[85 ^ 31].length();
      IProperty[] var10003 = new IProperty["  ".length()];
      I[3 ^ 72].length();
      var10003["".length()] = FACING;
      I[80 ^ 28].length();
      I[121 ^ 52].length();
      var10003[" ".length()] = EXTENDED;
      return new BlockStateContainer(this, var10003);
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      if (!var1.isRemote && var1.getTileEntity(var2) == null) {
         this.checkForMove(var1, var2, var3);
      }

   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private void checkForMove(World var1, BlockPos var2, IBlockState var3) {
      String var10000 = I["   ".length()];
      String var10001 = I[45 ^ 41];
      String var10002 = I[47 ^ 42];
      var10001 = I[88 ^ 94];
      EnumFacing var4 = (EnumFacing)var3.getValue(FACING);
      boolean var5 = this.shouldBeExtended(var1, var2, var4);
      if (var5 && !(Boolean)var3.getValue(EXTENDED)) {
         I[7 ^ 0].length();
         if ((new BlockPistonStructureHelper(var1, var2, var4, (boolean)" ".length())).canMove()) {
            var1.addBlockEvent(var2, this, "".length(), var4.getIndex());
            "".length();
            if (0 == 2) {
               throw null;
            }
         }
      } else if (!var5 && (Boolean)var3.getValue(EXTENDED)) {
         var1.addBlockEvent(var2, this, " ".length(), var4.getIndex());
      }

   }

   private boolean shouldBeExtended(World var1, BlockPos var2, EnumFacing var3) {
      EnumFacing[] var4 = EnumFacing.values();
      int var5 = var4.length;
      int var6 = "".length();

      do {
         if (var6 >= var5) {
            if (var1.isSidePowered(var2, EnumFacing.DOWN)) {
               return (boolean)" ".length();
            }

            BlockPos var9 = var2.up();
            EnumFacing[] var10 = EnumFacing.values();
            var6 = var10.length;
            int var11 = "".length();

            do {
               if (var11 >= var6) {
                  return (boolean)"".length();
               }

               EnumFacing var8 = var10[var11];
               if (var8 != EnumFacing.DOWN && var1.isSidePowered(var9.offset(var8), var8)) {
                  return (boolean)" ".length();
               }

               ++var11;
               "".length();
            } while(0 >= 0);

            throw null;
         }

         EnumFacing var7 = var4[var6];
         if (var7 != var3 && var1.isSidePowered(var2.offset(var7), var7)) {
            return (boolean)" ".length();
         }

         ++var6;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public static boolean canPush(IBlockState var0, World var1, BlockPos var2, EnumFacing var3, boolean var4, EnumFacing var5) {
      Block var6 = var0.getBlock();
      if (var6 == Blocks.OBSIDIAN) {
         return (boolean)"".length();
      } else if (!var1.getWorldBorder().contains(var2)) {
         return (boolean)"".length();
      } else if (var2.getY() >= 0 && (var3 != EnumFacing.DOWN || var2.getY() != 0)) {
         int var10000 = var2.getY();
         int var10001 = var1.getHeight();
         int var10002 = " ".length();
         I[74 ^ 93].length();
         I[221 ^ 197].length();
         I[179 ^ 170].length();
         I[143 ^ 149].length();
         if (var10000 <= var10001 - var10002) {
            if (var3 == EnumFacing.UP) {
               var10000 = var2.getY();
               var10001 = var1.getHeight();
               var10002 = " ".length();
               I[191 ^ 164].length();
               I[184 ^ 164].length();
               if (var10000 == var10001 - var10002) {
                  return (boolean)"".length();
               }
            }

            if (var6 != Blocks.PISTON && var6 != Blocks.STICKY_PISTON) {
               if (var0.getBlockHardness(var1, var2) == -1.0F) {
                  return (boolean)"".length();
               }

               switch(null.$SwitchMap$net$minecraft$block$material$EnumPushReaction[var0.getMobilityFlag().ordinal()]) {
               case 1:
                  return (boolean)"".length();
               case 2:
                  return var4;
               case 3:
                  if (var3 == var5) {
                     var10000 = " ".length();
                     "".length();
                     if (4 < 2) {
                        throw null;
                     }
                  } else {
                     var10000 = "".length();
                  }

                  return (boolean)var10000;
               default:
                  "".length();
                  if (2 <= 1) {
                     throw null;
                  }
               }
            } else if ((Boolean)var0.getValue(EXTENDED)) {
               return (boolean)"".length();
            }

            if (!var6.hasTileEntity()) {
               var10000 = " ".length();
               "".length();
               if (2 <= 0) {
                  throw null;
               }
            } else {
               var10000 = "".length();
            }

            return (boolean)var10000;
         } else {
            return (boolean)"".length();
         }
      } else {
         return (boolean)"".length();
      }
   }

   public boolean isFullyOpaque(IBlockState var1) {
      int var10000;
      if ((Boolean)var1.getValue(EXTENDED) && var1.getValue(FACING) != EnumFacing.DOWN) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (-1 == 3) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState().withProperty(FACING, getFacing(var1));
      PropertyBool var10001 = EXTENDED;
      int var10002;
      if ((var1 & (133 ^ 141)) > 0) {
         var10002 = " ".length();
         "".length();
         if (2 != 2) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public int getMetaFromState(IBlockState var1) {
      int var2 = "".length();
      var2 |= ((EnumFacing)var1.getValue(FACING)).getIndex();
      if ((Boolean)var1.getValue(EXTENDED)) {
         var2 |= 4 ^ 12;
      }

      return var2;
   }

   private static void I() {
      I = new String[47 ^ 96];
      I["".length()] = I("枹佪", "jnuqS");
      I[" ".length()] = I("嚘显婂", "OaOqf");
      I["  ".length()] = I("收浓沩", "CQcoy");
      I["   ".length()] = I("捝檭", "ZwEei");
      I[194 ^ 198] = I("枕渗", "YpTzP");
      I[25 ^ 28] = I("晞偝", "McdCc");
      I[80 ^ 86] = I("固幀", "znWwn");
      I[121 ^ 126] = I("淋杚枚宍", "XABUM");
      I[46 ^ 38] = I("屾抵棥專歺", "PvJvm");
      I[82 ^ 91] = I("桙", "vXHWw");
      I[189 ^ 183] = I("媬宽", "eKeER");
      I[27 ^ 16] = I("亇廐姜", "PomDy");
      I[121 ^ 117] = I("嫜搾", "ZutTI");
      I[181 ^ 184] = I("煤", "jAfJZ");
      I[128 ^ 142] = I("暃", "zsXci");
      I[0 ^ 15] = I("劸", "HUJWV");
      I[12 ^ 28] = I("屆埶", "xEFju");
      I[118 ^ 103] = I("憆喸姇滩洸", "KOQmO");
      I[160 ^ 178] = I("倝儯悌", "GKrYa");
      I[85 ^ 70] = I("洬泉方", "PxKde");
      I[158 ^ 138] = I("伇巜備拥懩", "tnqNf");
      I[213 ^ 192] = I("內噛儠", "cDAbZ");
      I[65 ^ 87] = I("棅", "eBBWt");
      I[158 ^ 137] = I("拝廠幏", "GcEJI");
      I[85 ^ 77] = I("搈", "xIvEv");
      I[35 ^ 58] = I("嚃", "HetxY");
      I[36 ^ 62] = I("撴嗱厧伶", "GVQeG");
      I[139 ^ 144] = I("涇漍棉", "ZUJCI");
      I[141 ^ 145] = I("柷烃噅", "qYbQi");
      I[103 ^ 122] = I("僛嘉", "VvGmm");
      I[169 ^ 183] = I("娐壊", "rIrBE");
      I[105 ^ 118] = I("憨挼", "QCfSb");
      I[174 ^ 142] = I("氾檘", "QNjTH");
      I[45 ^ 12] = I("俚旃净扲梤", "TPLTC");
      I[154 ^ 184] = I("士孮与匸", "KGdiL");
      I[57 ^ 26] = I("噲檴攔氁", "DDtAr");
      I[175 ^ 139] = I("煫刡廂", "SLPUe");
      I[73 ^ 108] = I("戏劎", "bvfPX");
      I[67 ^ 101] = I("椔坑揝刭", "SOBNM");
      I[54 ^ 17] = I("垣慫", "VxGce");
      I[129 ^ 169] = I("洖", "DvarI");
      I[3 ^ 42] = I("死喅嬙回墕", "CbQKW");
      I[189 ^ 151] = I("滠棻岯撊峏", "aevVS");
      I[93 ^ 118] = I("樕", "cbIic");
      I[119 ^ 91] = I("懴", "yAhah");
      I[165 ^ 136] = I("棊", "kJmeK");
      I[92 ^ 114] = I("峩咶今旰", "NHXwE");
      I[39 ^ 8] = I("噮", "xQlyY");
      I[73 ^ 121] = I("揯炏堛澾幉", "lNDue");
      I[0 ^ 49] = I("伭", "tDoWP");
      I[39 ^ 21] = I("櫧捰", "owTef");
      I[141 ^ 190] = I("储曖妆廹慊", "jgiei");
      I[88 ^ 108] = I("摎垂丝奞", "vMvHm");
      I[26 ^ 47] = I("沤摩崀帷", "OiQIS");
      I[152 ^ 174] = I("均泞孀宆岙", "WiMYl");
      I[142 ^ 185] = I("兞唞彪冀样", "gxeDL");
      I[164 ^ 156] = I("氚按槳", "zgYun");
      I[88 ^ 97] = I("樾囗", "EJlqo");
      I[148 ^ 174] = I("嗢帕", "bKGUe");
      I[101 ^ 94] = I("慨喴挾崁", "oNHSC");
      I[137 ^ 181] = I("沆拪慜椮", "AvTEp");
      I[162 ^ 159] = I("商慿厦捒洏", "BuTGG");
      I[158 ^ 160] = I("槦儎", "JLhHs");
      I[153 ^ 166] = I("昵撎", "HNXPv");
      I[47 ^ 111] = I("滓愬", "idktC");
      I[205 ^ 140] = I("僩嬏", "ZxDYd");
      I[26 ^ 88] = I("掋濛", "fyJZG");
      I[119 ^ 52] = I("噏嶞", "tCXFQ");
      I[112 ^ 52] = I("烀兣", "FVueB");
      I[234 ^ 175] = I("杖兽", "sXOZT");
      I[128 ^ 198] = I("囡斂", "gHGNh");
      I[76 ^ 11] = I("灸媚", "QkoNk");
      I[197 ^ 141] = I("櫜曛", "ODdVW");
      I[63 ^ 118] = I("囘堶", "DSJMu");
      I[99 ^ 41] = I("湃卦晜恚", "JyEst");
      I[1 ^ 74] = I("弹", "KLbRr");
      I[210 ^ 158] = I("憀炴塭厫仹", "LfJUk");
      I[58 ^ 119] = I("朗埊", "kuqWl");
      I[70 ^ 8] = I("+4&+\f*)6", "NLRNb");
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      addCollisionBoxToList(var3, var4, var5, var1.getBoundingBox(var2, var3));
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      return var1.withProperty(FACING, var2.rotate((EnumFacing)var1.getValue(FACING)));
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      if ((Boolean)var1.getValue(EXTENDED)) {
         switch(null.$SwitchMap$net$minecraft$util$EnumFacing[((EnumFacing)var1.getValue(FACING)).ordinal()]) {
         case 1:
            return PISTON_BASE_DOWN_AABB;
         case 2:
         default:
            return PISTON_BASE_UP_AABB;
         case 3:
            return PISTON_BASE_NORTH_AABB;
         case 4:
            return PISTON_BASE_SOUTH_AABB;
         case 5:
            return PISTON_BASE_WEST_AABB;
         case 6:
            return PISTON_BASE_EAST_AABB;
         }
      } else {
         return FULL_BLOCK_AABB;
      }
   }

   @Nullable
   public static EnumFacing getFacing(int var0) {
      int var1 = var0 & (6 ^ 1);
      EnumFacing var10000;
      if (var1 > (102 ^ 99)) {
         var10000 = null;
         "".length();
         if (3 < 0) {
            throw null;
         }
      } else {
         var10000 = EnumFacing.getFront(var1);
      }

      return var10000;
   }
}

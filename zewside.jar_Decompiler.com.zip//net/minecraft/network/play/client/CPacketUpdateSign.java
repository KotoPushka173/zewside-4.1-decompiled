package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;

public class CPacketUpdateSign implements Packet<INetHandlerPlayServer> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private BlockPos pos;
   // $FF: synthetic field
   private String[] lines;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 1);

      throw null;
   }

   static {
      I();
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeBlockPos(this.pos);
      I["".length()].length();
      I[" ".length()].length();
      int var2 = "".length();

      do {
         if (var2 >= (104 ^ 108)) {
            return;
         }

         var1.writeString(this.lines[var2]);
         I["  ".length()].length();
         I["   ".length()].length();
         ++var2;
         "".length();
      } while(-1 < 3);

      throw null;
   }

   public BlockPos getPosition() {
      return this.pos;
   }

   private static void I() {
      I = new String[53 ^ 49];
      I["".length()] = I("帶媙漭慸瀃", "AJsRw");
      I[" ".length()] = I("伂嶼", "GxHnJ");
      I["  ".length()] = I("平", "UHwNw");
      I["   ".length()] = I("愁", "FCRxd");
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.pos = var1.readBlockPos();
      this.lines = new String[9 ^ 13];
      int var2 = "".length();

      do {
         if (var2 >= (31 ^ 27)) {
            return;
         }

         this.lines[var2] = var1.readStringFromBuffer(100 + 192 - 244 + 336);
         ++var2;
         "".length();
      } while(0 < 2);

      throw null;
   }

   public String[] getLines() {
      return this.lines;
   }

   public CPacketUpdateSign(BlockPos var1, ITextComponent[] var2) {
      this.pos = var1;
      String[] var10001 = new String[107 ^ 111];
      var10001["".length()] = var2["".length()].getUnformattedText();
      var10001[" ".length()] = var2[" ".length()].getUnformattedText();
      var10001["  ".length()] = var2["  ".length()].getUnformattedText();
      var10001["   ".length()] = var2["   ".length()].getUnformattedText();
      this.lines = var10001;
   }

   public void processPacket(INetHandlerPlayServer var1) {
      var1.processUpdateSign(this);
   }

   public CPacketUpdateSign() {
   }
}

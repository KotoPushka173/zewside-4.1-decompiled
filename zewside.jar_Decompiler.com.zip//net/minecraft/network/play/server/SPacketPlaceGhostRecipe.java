package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketPlaceGhostRecipe implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private IRecipe field_194315_b;
   // $FF: synthetic field
   private int field_194314_a;

   public int func_194313_b() {
      return this.field_194314_a;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 > 0);

      throw null;
   }

   public SPacketPlaceGhostRecipe() {
   }

   public IRecipe func_194311_a() {
      return this.field_194315_b;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.func_194307_a(this);
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeByte(this.field_194314_a);
      I["".length()].length();
      var1.writeVarIntToBuffer(CraftingManager.func_193375_a(this.field_194315_b));
      I[" ".length()].length();
      I["  ".length()].length();
      I["   ".length()].length();
   }

   public SPacketPlaceGhostRecipe(int var1, IRecipe var2) {
      this.field_194314_a = var1;
      this.field_194315_b = var2;
   }

   static {
      I();
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.field_194314_a = var1.readByte();
      this.field_194315_b = CraftingManager.func_193374_a(var1.readVarIntFromBuffer());
   }

   private static void I() {
      I = new String[85 ^ 81];
      I["".length()] = I("憄壉嵝淹", "bAXzt");
      I[" ".length()] = I("懻忬", "ACllG");
      I["  ".length()] = I("媋", "qivnk");
      I["   ".length()] = I("櫸游", "VIyRS");
   }
}

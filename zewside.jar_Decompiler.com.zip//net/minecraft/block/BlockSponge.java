package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.NonNullList;
import net.minecraft.util.Tuple;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;

public class BlockSponge extends Block {
   // $FF: synthetic field
   public static final PropertyBool WET;
   // $FF: synthetic field
   private static final String[] I;

   public int damageDropped(IBlockState var1) {
      int var10000;
      if ((Boolean)var1.getValue(WET)) {
         var10000 = " ".length();
         "".length();
         if (2 == 1) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   static {
      I();
      WET = PropertyBool.create(I[25 ^ 95]);
   }

   public void onBlockAdded(World var1, BlockPos var2, IBlockState var3) {
      this.tryAbsorb(var1, var2, var3);
   }

   public String getLocalizedName() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      I[132 ^ 128].length();
      I[154 ^ 159].length();
      return I18n.translateToLocal(this.getUnlocalizedName() + I[198 ^ 192]);
   }

   private boolean absorb(World var1, BlockPos var2) {
      String var10000 = I[40 ^ 34];
      String var10001 = I[45 ^ 38];
      String var10002 = I[167 ^ 171];
      var10001 = I[159 ^ 146];
      var10000 = I[2 ^ 12];
      var10001 = I[118 ^ 121];
      var10002 = I[4 ^ 20];
      var10001 = I[19 ^ 2];
      LinkedList var3 = Lists.newLinkedList();
      ArrayList var4 = Lists.newArrayList();
      I[21 ^ 7].length();
      I[6 ^ 21].length();
      var3.add(new Tuple(var2, "".length()));
      I[42 ^ 62].length();
      I[189 ^ 168].length();
      int var5 = "".length();

      BlockPos var7;
      while(!var3.isEmpty()) {
         Tuple var6 = (Tuple)var3.poll();
         var7 = (BlockPos)var6.getFirst();
         int var8 = (Integer)var6.getSecond();
         EnumFacing[] var9 = EnumFacing.values();
         int var10 = var9.length;
         int var11 = "".length();

         while(var11 < var10) {
            EnumFacing var12 = var9[var11];
            BlockPos var13 = var7.offset(var12);
            if (var1.getBlockState(var13).getMaterial() == Material.WATER) {
               var1.setBlockState(var13, Blocks.AIR.getDefaultState(), "  ".length());
               I[81 ^ 71].length();
               I[142 ^ 153].length();
               I[18 ^ 10].length();
               var4.add(var13);
               I[21 ^ 12].length();
               I[104 ^ 114].length();
               I[14 ^ 21].length();
               ++var5;
               if (var8 < (80 ^ 86)) {
                  I[159 ^ 131].length();
                  I[155 ^ 134].length();
                  I[106 ^ 116].length();
                  var3.add(new Tuple(var13, var8 + " ".length()));
                  I[65 ^ 94].length();
                  I[110 ^ 78].length();
                  I[185 ^ 152].length();
               }
            }

            ++var11;
            "".length();
            if (4 <= 3) {
               throw null;
            }
         }

         if (var5 > (199 ^ 135)) {
            "".length();
            if (false) {
               throw null;
            }
            break;
         }

         "".length();
         if (3 < 1) {
            throw null;
         }
      }

      Iterator var14 = var4.iterator();

      do {
         if (!var14.hasNext()) {
            int var15;
            if (var5 > 0) {
               var15 = " ".length();
               "".length();
               if (2 != 2) {
                  throw null;
               }
            } else {
               var15 = "".length();
            }

            return (boolean)var15;
         }

         var7 = (BlockPos)var14.next();
         var1.notifyNeighborsOfStateChange(var7, Blocks.AIR, (boolean)"".length());
         "".length();
      } while(2 == 2);

      throw null;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(2 >= 0);

      throw null;
   }

   public void getSubBlocks(CreativeTabs var1, NonNullList<ItemStack> var2) {
      String var10000 = I[35 ^ 1];
      String var10001 = I[175 ^ 140];
      String var10002 = I[42 ^ 14];
      var10001 = I[98 ^ 71];
      var10000 = I[135 ^ 161];
      var10001 = I[184 ^ 159];
      var10002 = I[189 ^ 149];
      var10001 = I[119 ^ 94];
      I[8 ^ 34].length();
      I[83 ^ 120].length();
      I[170 ^ 134].length();
      var2.add(new ItemStack(this, " ".length(), "".length()));
      I[167 ^ 138].length();
      I[101 ^ 75].length();
      I[39 ^ 8].length();
      var2.add(new ItemStack(this, " ".length(), " ".length()));
      I[44 ^ 28].length();
      I[6 ^ 55].length();
      I[128 ^ 178].length();
      I[62 ^ 13].length();
      I[245 ^ 193].length();
   }

   public IBlockState getStateFromMeta(int var1) {
      IBlockState var10000 = this.getDefaultState();
      PropertyBool var10001 = WET;
      int var10002;
      if ((var1 & " ".length()) == " ".length()) {
         var10002 = " ".length();
         "".length();
         if (2 == 0) {
            throw null;
         }
      } else {
         var10002 = "".length();
      }

      return var10000.withProperty(var10001, Boolean.valueOf((boolean)var10002));
   }

   public void randomDisplayTick(IBlockState var1, World var2, BlockPos var3, Random var4) {
      if ((Boolean)var1.getValue(WET)) {
         EnumFacing var5 = EnumFacing.random(var4);
         if (var5 != EnumFacing.UP && !var2.getBlockState(var3.offset(var5)).isFullyOpaque()) {
            double var6 = (double)var3.getX();
            double var8 = (double)var3.getY();
            double var10 = (double)var3.getZ();
            if (var5 == EnumFacing.DOWN) {
               I[99 ^ 32].length();
               I[17 ^ 85].length();
               I[85 ^ 16].length();
               var8 -= 0.05D;
               var6 += var4.nextDouble();
               var10 += var4.nextDouble();
               "".length();
               if (1 <= -1) {
                  throw null;
               }
            } else {
               var8 += var4.nextDouble() * 0.8D;
               if (var5.getAxis() == EnumFacing.Axis.X) {
                  var10 += var4.nextDouble();
                  if (var5 == EnumFacing.EAST) {
                     ++var6;
                     "".length();
                     if (3 <= 2) {
                        throw null;
                     }
                  } else {
                     var6 += 0.05D;
                     "".length();
                     if (3 != 3) {
                        throw null;
                     }
                  }
               } else {
                  var6 += var4.nextDouble();
                  if (var5 == EnumFacing.SOUTH) {
                     ++var10;
                     "".length();
                     if (4 <= 3) {
                        throw null;
                     }
                  } else {
                     var10 += 0.05D;
                  }
               }
            }

            var2.spawnParticle(EnumParticleTypes.DRIP_WATER, var6, var8, var10, 0.0D, 0.0D, 0.0D);
         }
      }

   }

   protected void tryAbsorb(World var1, BlockPos var2, IBlockState var3) {
      if (!(Boolean)var3.getValue(WET) && this.absorb(var1, var2)) {
         var1.setBlockState(var2, var3.withProperty(WET, Boolean.valueOf((boolean)" ".length())), "  ".length());
         I[31 ^ 24].length();
         I[137 ^ 129].length();
         I[41 ^ 32].length();
         var1.playEvent(34 + 821 - -790 + 356, var2, Block.getIdFromBlock(Blocks.WATER));
      }

   }

   private static void I() {
      I = new String[51 ^ 116];
      I["".length()] = I("噝婝", "GIfjN");
      I[" ".length()] = I("氣凈", "qQVGZ");
      I["  ".length()] = I("偻夿", "evSLz");
      I["   ".length()] = I("增慛", "uKzcf");
      I[102 ^ 98] = I("娀", "eCAck");
      I[41 ^ 44] = I("倁檛冤", "REysR");
      I[191 ^ 185] = I("\u007f\u0012\u000b\u0003T?\u0017\u0014\u001f", "Qvyzz");
      I[195 ^ 196] = I("嚘混炯", "RUDLh");
      I[3 ^ 11] = I("兑毸", "KikDX");
      I[201 ^ 192] = I("担乲", "XNjUT");
      I[106 ^ 96] = I("嚗妨", "ypNrw");
      I[173 ^ 166] = I("灛嫧", "aynWS");
      I[159 ^ 147] = I("岈湉", "AqgPE");
      I[153 ^ 148] = I("媭濋", "JnMom");
      I[31 ^ 17] = I("動冋", "NbmZL");
      I[163 ^ 172] = I("彺抴", "Byalm");
      I[70 ^ 86] = I("剶嬭", "gusGn");
      I[168 ^ 185] = I("刓埯", "dwgpl");
      I[170 ^ 184] = I("慁", "eWLEx");
      I[73 ^ 90] = I("傭梯殔", "nSYVL");
      I[73 ^ 93] = I("揵壂伃添", "YnIWZ");
      I[50 ^ 39] = I("岙瀽懲", "vZcfA");
      I[155 ^ 141] = I("倓乚杤", "TgMBs");
      I[32 ^ 55] = I("垑漪", "VIyHR");
      I[64 ^ 88] = I("溭", "NnLKj");
      I[167 ^ 190] = I("圖吳淵匐凄", "bOTyU");
      I[170 ^ 176] = I("澇坬桪", "zIOqk");
      I[69 ^ 94] = I("溉炠取", "GMzTJ");
      I[90 ^ 70] = I("伪洸枀柮", "ztfYJ");
      I[74 ^ 87] = I("延氡沑氱", "oEHww");
      I[137 ^ 151] = I("另暗呜", "VVPuD");
      I[71 ^ 88] = I("匰", "efDXA");
      I[25 ^ 57] = I("嵆偡宯", "NODhK");
      I[108 ^ 77] = I("勽僋", "DRnmO");
      I[68 ^ 102] = I("梭帆", "BkUuu");
      I[36 ^ 7] = I("亠愸", "nbqpE");
      I[152 ^ 188] = I("屁吩", "zZXVv");
      I[107 ^ 78] = I("呑杍", "SlBkd");
      I[75 ^ 109] = I("基浗", "FpmVa");
      I[30 ^ 57] = I("柈懜", "XKCsm");
      I[22 ^ 62] = I("娀澨", "AzDNA");
      I[129 ^ 168] = I("橭吘", "Jwsdc");
      I[119 ^ 93] = I("巜幧", "gwxvA");
      I[148 ^ 191] = I("孥暑", "EMOcs");
      I[188 ^ 144] = I("妠孉幊漟潖", "EPfWW");
      I[191 ^ 146] = I("斸嵴勖", "ewtQQ");
      I[106 ^ 68] = I("沦唡夸扸弱", "RuCDV");
      I[158 ^ 177] = I("滴斚始", "neHka");
      I[122 ^ 74] = I("云吢毵张浀", "kFvzr");
      I[65 ^ 112] = I("滩梪", "lhyEH");
      I[155 ^ 169] = I("俣", "qXcyp");
      I[82 ^ 97] = I("嫷橶妑俣澔", "QFYxl");
      I[64 ^ 116] = I("摓岨", "WHWns");
      I[111 ^ 90] = I("姭唩", "yznik");
      I[79 ^ 121] = I("渟唑", "OUTaL");
      I[95 ^ 104] = I("唏榐", "cEadD");
      I[40 ^ 16] = I("垇嚇", "AERyp");
      I[19 ^ 42] = I("寜圈", "CEGiI");
      I[34 ^ 24] = I("槵侔", "xVKsS");
      I[51 ^ 8] = I("屳楕", "yFrlu");
      I[137 ^ 181] = I("泦嘯", "cFHrX");
      I[109 ^ 80] = I("椤涜倗擶屠", "OLcII");
      I[85 ^ 107] = I("柊呃", "scDma");
      I[191 ^ 128] = I("敮", "MekoY");
      I[197 ^ 133] = I("摢", "GGQWf");
      I[242 ^ 179] = I("泒晍啧", "bCqBq");
      I[19 ^ 81] = I("埜", "rxlMy");
      I[70 ^ 5] = I("拝嬚", "ZYWhT");
      I[92 ^ 24] = I("灏懕埪抑", "fOHcD");
      I[243 ^ 182] = I("怊揈享", "sBGvW");
      I[92 ^ 26] = I("\u001d\u0003\"", "jfVtO");
   }

   public int getMetaFromState(IBlockState var1) {
      int var10000;
      if ((Boolean)var1.getValue(WET)) {
         var10000 = " ".length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      } else {
         var10000 = "".length();
      }

      return var10000;
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I[93 ^ 104];
      String var10001 = I[20 ^ 34];
      String var10002 = I[170 ^ 157];
      var10001 = I[70 ^ 126];
      var10000 = I[179 ^ 138];
      var10001 = I[50 ^ 8];
      var10002 = I[10 ^ 49];
      var10001 = I[173 ^ 145];
      I[88 ^ 101].length();
      IProperty[] var10003 = new IProperty[" ".length()];
      I[122 ^ 68].length();
      I[174 ^ 145].length();
      I[233 ^ 169].length();
      I[17 ^ 80].length();
      I[192 ^ 130].length();
      var10003["".length()] = WET;
      return new BlockStateContainer(this, var10003);
   }

   protected BlockSponge() {
      super(Material.SPONGE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(WET, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
   }

   public void neighborChanged(IBlockState var1, World var2, BlockPos var3, Block var4, BlockPos var5) {
      this.tryAbsorb(var2, var3, var1);
      super.neighborChanged(var1, var2, var3, var4, var5);
   }
}

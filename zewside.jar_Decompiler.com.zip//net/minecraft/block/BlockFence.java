package net.minecraft.block;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemLead;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockFence extends Block {
   // $FF: synthetic field
   public static final AxisAlignedBB PILLAR_AABB;
   // $FF: synthetic field
   protected static final AxisAlignedBB[] BOUNDING_BOXES;
   // $FF: synthetic field
   public static final AxisAlignedBB WEST_AABB;
   // $FF: synthetic field
   public static final AxisAlignedBB EAST_AABB;
   // $FF: synthetic field
   public static final AxisAlignedBB NORTH_AABB;
   // $FF: synthetic field
   public static final AxisAlignedBB SOUTH_AABB;
   // $FF: synthetic field
   public static final PropertyBool EAST;
   // $FF: synthetic field
   public static final PropertyBool SOUTH;
   // $FF: synthetic field
   public static final PropertyBool NORTH;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   public static final PropertyBool WEST;

   private static int getBoundingBoxIdx(IBlockState var0) {
      int var1 = "".length();
      if ((Boolean)var0.getValue(NORTH)) {
         var1 |= " ".length() << EnumFacing.NORTH.getHorizontalIndex();
      }

      if ((Boolean)var0.getValue(EAST)) {
         var1 |= " ".length() << EnumFacing.EAST.getHorizontalIndex();
      }

      if ((Boolean)var0.getValue(SOUTH)) {
         var1 |= " ".length() << EnumFacing.SOUTH.getHorizontalIndex();
      }

      if ((Boolean)var0.getValue(WEST)) {
         var1 |= " ".length() << EnumFacing.WEST.getHorizontalIndex();
      }

      return var1;
   }

   public boolean shouldSideBeRendered(IBlockState var1, IBlockAccess var2, BlockPos var3, EnumFacing var4) {
      return (boolean)" ".length();
   }

   public BlockFence(Material var1, MapColor var2) {
      super(var1, var2);
      this.setDefaultState(this.blockState.getBaseState().withProperty(NORTH, Boolean.valueOf((boolean)"".length())).withProperty(EAST, Boolean.valueOf((boolean)"".length())).withProperty(SOUTH, Boolean.valueOf((boolean)"".length())).withProperty(WEST, Boolean.valueOf((boolean)"".length())));
      this.setCreativeTab(CreativeTabs.DECORATIONS);
   }

   protected static boolean func_194142_e(Block var0) {
      int var10000;
      if (!Block.func_193382_c(var0) && var0 != Blocks.BARRIER && var0 != Blocks.MELON_BLOCK && var0 != Blocks.PUMPKIN && var0 != Blocks.LIT_PUMPKIN) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (-1 != -1) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public IBlockState withRotation(IBlockState var1, Rotation var2) {
      switch(null.$SwitchMap$net$minecraft$util$Rotation[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(EAST, var1.getValue(WEST)).withProperty(SOUTH, var1.getValue(NORTH)).withProperty(WEST, var1.getValue(EAST));
      case 2:
         return var1.withProperty(NORTH, var1.getValue(EAST)).withProperty(EAST, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(WEST)).withProperty(WEST, var1.getValue(NORTH));
      case 3:
         return var1.withProperty(NORTH, var1.getValue(WEST)).withProperty(EAST, var1.getValue(NORTH)).withProperty(SOUTH, var1.getValue(EAST)).withProperty(WEST, var1.getValue(SOUTH));
      default:
         return var1;
      }
   }

   public IBlockState getActualState(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      return var1.withProperty(NORTH, this.canConnectTo(var2, var3.north(), EnumFacing.SOUTH)).withProperty(EAST, this.canConnectTo(var2, var3.east(), EnumFacing.WEST)).withProperty(SOUTH, this.canConnectTo(var2, var3.south(), EnumFacing.NORTH)).withProperty(WEST, this.canConnectTo(var2, var3.west(), EnumFacing.EAST));
   }

   public IBlockState withMirror(IBlockState var1, Mirror var2) {
      switch(null.$SwitchMap$net$minecraft$util$Mirror[var2.ordinal()]) {
      case 1:
         return var1.withProperty(NORTH, var1.getValue(SOUTH)).withProperty(SOUTH, var1.getValue(NORTH));
      case 2:
         return var1.withProperty(EAST, var1.getValue(WEST)).withProperty(WEST, var1.getValue(EAST));
      default:
         return super.withMirror(var1, var2);
      }
   }

   public void addCollisionBoxToList(IBlockState var1, World var2, BlockPos var3, AxisAlignedBB var4, List<AxisAlignedBB> var5, @Nullable Entity var6, boolean var7) {
      if (!var7) {
         var1 = var1.getActualState(var2, var3);
      }

      addCollisionBoxToList(var3, var4, var5, PILLAR_AABB);
      if ((Boolean)var1.getValue(NORTH)) {
         addCollisionBoxToList(var3, var4, var5, NORTH_AABB);
      }

      if ((Boolean)var1.getValue(EAST)) {
         addCollisionBoxToList(var3, var4, var5, EAST_AABB);
      }

      if ((Boolean)var1.getValue(SOUTH)) {
         addCollisionBoxToList(var3, var4, var5, SOUTH_AABB);
      }

      if ((Boolean)var1.getValue(WEST)) {
         addCollisionBoxToList(var3, var4, var5, WEST_AABB);
      }

   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   public boolean isFullCube(IBlockState var1) {
      return (boolean)"".length();
   }

   static {
      I();
      NORTH = PropertyBool.create(I[56 ^ 24]);
      EAST = PropertyBool.create(I[230 ^ 199]);
      SOUTH = PropertyBool.create(I[228 ^ 198]);
      WEST = PropertyBool.create(I[85 ^ 118]);
      AxisAlignedBB[] var10000 = new AxisAlignedBB[105 ^ 121];
      var10000["".length()] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 1.0D, 0.625D);
      var10000[" ".length()] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 1.0D, 1.0D);
      var10000["  ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 0.625D, 1.0D, 0.625D);
      var10000["   ".length()] = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 0.625D, 1.0D, 1.0D);
      var10000[157 ^ 153] = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 1.0D, 0.625D);
      var10000[110 ^ 107] = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 1.0D, 1.0D);
      var10000[45 ^ 43] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.625D, 1.0D, 0.625D);
      var10000[53 ^ 50] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.625D, 1.0D, 1.0D);
      var10000[27 ^ 19] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 1.0D, 1.0D, 0.625D);
      var10000[54 ^ 63] = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 1.0D, 1.0D, 1.0D);
      var10000[130 ^ 136] = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 1.0D, 1.0D, 0.625D);
      var10000[123 ^ 112] = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 1.0D, 1.0D, 1.0D);
      var10000[144 ^ 156] = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 1.0D, 1.0D, 0.625D);
      var10000[137 ^ 132] = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      var10000[135 ^ 137] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.625D);
      var10000[155 ^ 148] = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      BOUNDING_BOXES = var10000;
      PILLAR_AABB = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 1.5D, 0.625D);
      SOUTH_AABB = new AxisAlignedBB(0.375D, 0.0D, 0.625D, 0.625D, 1.5D, 1.0D);
      WEST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 0.375D, 1.5D, 0.625D);
      NORTH_AABB = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 1.5D, 0.375D);
      EAST_AABB = new AxisAlignedBB(0.625D, 0.0D, 0.375D, 1.0D, 1.5D, 0.625D);
   }

   public AxisAlignedBB getBoundingBox(IBlockState var1, IBlockAccess var2, BlockPos var3) {
      var1 = this.getActualState(var1, var2, var3);
      return BOUNDING_BOXES[getBoundingBoxIdx(var1)];
   }

   public boolean canConnectTo(IBlockAccess var1, BlockPos var2, EnumFacing var3) {
      IBlockState var4 = var1.getBlockState(var2);
      BlockFaceShape var5 = var4.func_193401_d(var1, var2, var3);
      Block var6 = var4.getBlock();
      int var10000;
      if (var5 != BlockFaceShape.MIDDLE_POLE || var4.getMaterial() != this.blockMaterial && !(var6 instanceof BlockFenceGate)) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (false) {
            throw null;
         }
      }

      int var7 = var10000;
      if ((func_194142_e(var6) || var5 != BlockFaceShape.SOLID) && var7 == 0) {
         var10000 = "".length();
      } else {
         var10000 = " ".length();
         "".length();
         if (1 >= 4) {
            throw null;
         }
      }

      return (boolean)var10000;
   }

   public boolean onBlockActivated(World var1, BlockPos var2, IBlockState var3, EntityPlayer var4, EnumHand var5, EnumFacing var6, float var7, float var8, float var9) {
      if (!var1.isRemote) {
         return ItemLead.attachToFence(var4, var1, var2);
      } else {
         ItemStack var10 = var4.getHeldItem(var5);
         int var10000;
         if (var10.getItem() != Items.LEAD && !var10.isEmpty()) {
            var10000 = "".length();
         } else {
            var10000 = " ".length();
            "".length();
            if (-1 != -1) {
               throw null;
            }
         }

         return (boolean)var10000;
      }
   }

   public int getMetaFromState(IBlockState var1) {
      return "".length();
   }

   protected BlockStateContainer createBlockState() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[136 ^ 140];
      var10001 = I[138 ^ 143];
      var10002 = I[94 ^ 88];
      var10001 = I[51 ^ 52];
      var10000 = I[36 ^ 44];
      var10001 = I[154 ^ 147];
      var10002 = I[100 ^ 110];
      var10001 = I[32 ^ 43];
      var10000 = I[27 ^ 23];
      var10001 = I[169 ^ 164];
      var10002 = I[77 ^ 67];
      var10001 = I[25 ^ 22];
      var10000 = I[103 ^ 119];
      var10001 = I[101 ^ 116];
      var10002 = I[3 ^ 17];
      var10001 = I[130 ^ 145];
      I[11 ^ 31].length();
      I[69 ^ 80].length();
      I[151 ^ 129].length();
      I[135 ^ 144].length();
      IProperty[] var10003 = new IProperty[4 ^ 0];
      I[32 ^ 56].length();
      I[14 ^ 23].length();
      var10003["".length()] = NORTH;
      I[33 ^ 59].length();
      I[2 ^ 25].length();
      var10003[" ".length()] = EAST;
      I[23 ^ 11].length();
      var10003["  ".length()] = WEST;
      I[2 ^ 31].length();
      I[179 ^ 173].length();
      I[156 ^ 131].length();
      var10003["   ".length()] = SOUTH;
      return new BlockStateContainer(this, var10003);
   }

   public boolean isPassable(IBlockAccess var1, BlockPos var2) {
      return (boolean)"".length();
   }

   public boolean isOpaqueCube(IBlockState var1) {
      return (boolean)"".length();
   }

   private static void I() {
      I = new String[65 ^ 101];
      I["".length()] = I("梕晳", "lSjlA");
      I[" ".length()] = I("娼庖", "GzRRX");
      I["  ".length()] = I("撲暮", "yuSPa");
      I["   ".length()] = I("掩帢", "VlPLj");
      I[182 ^ 178] = I("尉巕", "sTiMv");
      I[36 ^ 33] = I("潆挽", "MVDph");
      I[160 ^ 166] = I("摢侞", "SBAYR");
      I[86 ^ 81] = I("區敛", "WXFIP");
      I[40 ^ 32] = I("勏炫", "epSiZ");
      I[165 ^ 172] = I("櫦奒", "JZxkv");
      I[180 ^ 190] = I("烔泯", "yZDaZ");
      I[16 ^ 27] = I("帟炟", "LuWNM");
      I[172 ^ 160] = I("儉氖", "irSHE");
      I[157 ^ 144] = I("嵭損", "nLVKC");
      I[40 ^ 38] = I("戚坏", "HRMmE");
      I[28 ^ 19] = I("涁湏", "OcVvN");
      I[27 ^ 11] = I("悾濌", "XiSzM");
      I[169 ^ 184] = I("懡瀍", "RlkWz");
      I[110 ^ 124] = I("栛昇", "tYhCy");
      I[39 ^ 52] = I("奣憳", "muLQf");
      I[106 ^ 126] = I("师渏哗愩", "OFhNF");
      I[129 ^ 148] = I("楉倏栀", "RqyED");
      I[114 ^ 100] = I("泱寃吙呭杘", "HwZNx");
      I[138 ^ 157] = I("椏", "ayBpx");
      I[189 ^ 165] = I("尓", "ClngP");
      I[128 ^ 153] = I("整", "egANY");
      I[75 ^ 81] = I("煜弙买", "AsRFg");
      I[161 ^ 186] = I("宑傢揯", "xJPlU");
      I[160 ^ 188] = I("抐泧五", "RhPsm");
      I[173 ^ 176] = I("槕殣", "qRqLH");
      I[58 ^ 36] = I("抆", "dEKrv");
      I[17 ^ 14] = I("堶抨囉屴", "LZCnr");
      I[125 ^ 93] = I("4\u0019$,\u000f", "ZvVXg");
      I[95 ^ 126] = I("\u000e\r+\u0002", "klXvz");
      I[231 ^ 197] = I("2?\u0002\u00048", "APwpP");
      I[116 ^ 87] = I(">\b;\r", "ImHyO");
   }

   public BlockFaceShape func_193383_a(IBlockAccess var1, IBlockState var2, BlockPos var3, EnumFacing var4) {
      BlockFaceShape var10000;
      if (var4 != EnumFacing.UP && var4 != EnumFacing.DOWN) {
         var10000 = BlockFaceShape.MIDDLE_POLE;
         "".length();
         if (3 == 4) {
            throw null;
         }
      } else {
         var10000 = BlockFaceShape.CENTER;
      }

      return var10000;
   }
}

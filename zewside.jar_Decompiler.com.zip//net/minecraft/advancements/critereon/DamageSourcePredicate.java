package net.minecraft.advancements.critereon;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraft.util.JsonUtils;

public class DamageSourcePredicate {
   // $FF: synthetic field
   private final EntityPredicate field_193419_i;
   // $FF: synthetic field
   private final EntityPredicate field_193420_j;
   // $FF: synthetic field
   private final Boolean field_192452_d;
   // $FF: synthetic field
   private final Boolean field_192451_c;
   // $FF: synthetic field
   private final Boolean field_192456_h;
   // $FF: synthetic field
   private final Boolean field_192454_f;
   // $FF: synthetic field
   private final Boolean field_192453_e;
   // $FF: synthetic field
   private final Boolean field_192450_b;
   // $FF: synthetic field
   private final Boolean field_192455_g;
   // $FF: synthetic field
   public static DamageSourcePredicate field_192449_a;
   // $FF: synthetic field
   private static final String[] I;

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(4 != 2);

      throw null;
   }

   public DamageSourcePredicate(@Nullable Boolean var1, @Nullable Boolean var2, @Nullable Boolean var3, @Nullable Boolean var4, @Nullable Boolean var5, @Nullable Boolean var6, @Nullable Boolean var7, EntityPredicate var8, EntityPredicate var9) {
      this.field_192450_b = var1;
      this.field_192451_c = var2;
      this.field_192452_d = var3;
      this.field_192453_e = var4;
      this.field_192454_f = var5;
      this.field_192455_g = var6;
      this.field_192456_h = var7;
      this.field_193419_i = var8;
      this.field_193420_j = var9;
   }

   public static DamageSourcePredicate func_192447_a(@Nullable JsonElement var0) {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = JsonUtils.getJsonObject(var0, I[34 ^ 38]);
         Boolean var2 = func_192448_a(var1, I[143 ^ 138]);
         Boolean var3 = func_192448_a(var1, I[60 ^ 58]);
         Boolean var4 = func_192448_a(var1, I[73 ^ 78]);
         Boolean var5 = func_192448_a(var1, I[41 ^ 33]);
         Boolean var6 = func_192448_a(var1, I[63 ^ 54]);
         Boolean var7 = func_192448_a(var1, I[163 ^ 169]);
         Boolean var8 = func_192448_a(var1, I[114 ^ 121]);
         EntityPredicate var9 = EntityPredicate.func_192481_a(var1.get(I[9 ^ 5]));
         EntityPredicate var10 = EntityPredicate.func_192481_a(var1.get(I[36 ^ 41]));
         I[83 ^ 93].length();
         I[116 ^ 123].length();
         I[183 ^ 167].length();
         return new DamageSourcePredicate(var2, var3, var4, var5, var6, var7, var8, var9, var10);
      } else {
         return field_192449_a;
      }
   }

   @Nullable
   private static Boolean func_192448_a(JsonObject var0, String var1) {
      Boolean var10000;
      if (var0.has(var1)) {
         var10000 = JsonUtils.getBoolean(var0, var1);
         "".length();
         if (1 >= 2) {
            throw null;
         }
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public DamageSourcePredicate() {
      this.field_192450_b = null;
      this.field_192451_c = null;
      this.field_192452_d = null;
      this.field_192453_e = null;
      this.field_192454_f = null;
      this.field_192455_g = null;
      this.field_192456_h = null;
      this.field_193419_i = EntityPredicate.field_192483_a;
      this.field_193420_j = EntityPredicate.field_192483_a;
   }

   static {
      I();
      field_192449_a = new DamageSourcePredicate();
   }

   private static void I() {
      I = new String[189 ^ 172];
      I["".length()] = I("句溣", "RHekP");
      I[" ".length()] = I("壒斐", "efjeb");
      I["  ".length()] = I("媌号", "yoREj");
      I["   ".length()] = I("攇丒", "NtQkT");
      I[10 ^ 14] = I(",+%\b\u0017-j<\u0010\u0000-", "HJHip");
      I[146 ^ 151] = I("&\u0002044 \u001b\n'2&\u001d\n", "OqoDF");
      I[187 ^ 189] = I("#\u0006\n$\t:\u0019:2\u0018%\u001b", "JuUAq");
      I[77 ^ 74] = I("\u0006;&-7\u0017'%\u0013%\u0016/9>", "dBVLD");
      I[99 ^ 107] = I("4,\b\u0017\u0004%0\u000b)\u001e8#\r\u001a\u00193'\u0019\u0014\u001e:<\f\u000f", "VUxvw");
      I[155 ^ 146] = I("8\u000f;8\u001c)\u00138\u0006\u0002;\u0011\":", "ZvKYo");
      I[61 ^ 55] = I("\u0001\u0004;\u000f%\u001a\u0012", "hwdiL");
      I[19 ^ 24] = I("1\u001c\u0011\u0004\u000b?\u0006-", "XoNij");
      I[90 ^ 86] = I("\u0014%8\u000b\u0011\u0004\u0013/\u0000\u0006\u001983", "pLJnr");
      I[201 ^ 196] = I(":\u001a9\b\u001a,*)\u0014\r \u00015", "IuLzy");
      I[31 ^ 17] = I("崺煢", "gfqyw");
      I[143 ^ 128] = I("昝", "pYioU");
      I[208 ^ 192] = I("刜巶嶲炍嗰", "IpsxY");
   }

   public boolean func_193418_a(EntityPlayerMP var1, DamageSource var2) {
      if (this == field_192449_a) {
         return (boolean)" ".length();
      } else if (this.field_192450_b != null && this.field_192450_b != var2.isProjectile()) {
         return (boolean)"".length();
      } else if (this.field_192451_c != null && this.field_192451_c != var2.isExplosion()) {
         return (boolean)"".length();
      } else if (this.field_192452_d != null && this.field_192452_d != var2.isUnblockable()) {
         return (boolean)"".length();
      } else if (this.field_192453_e != null && this.field_192453_e != var2.canHarmInCreative()) {
         return (boolean)"".length();
      } else if (this.field_192454_f != null && this.field_192454_f != var2.isDamageAbsolute()) {
         return (boolean)"".length();
      } else if (this.field_192455_g != null && this.field_192455_g != var2.isFireDamage()) {
         return (boolean)"".length();
      } else if (this.field_192456_h != null && this.field_192456_h != var2.isMagicDamage()) {
         return (boolean)"".length();
      } else {
         return (boolean)(!this.field_193419_i.func_192482_a(var1, var2.getSourceOfDamage()) ? "".length() : this.field_193420_j.func_192482_a(var1, var2.getEntity()));
      }
   }
}

package net.minecraft.advancements;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.util.EnumTypeAdapterFactory;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AdvancementManager {
   // $FF: synthetic field
   private final File field_192785_d;
   // $FF: synthetic field
   private boolean field_193768_e;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private static final AdvancementList field_192784_c;
   // $FF: synthetic field
   private static final Gson field_192783_b;
   // $FF: synthetic field
   private static final Logger field_192782_a;

   public AdvancementManager(@Nullable File var1) {
      this.field_192785_d = var1;
      this.func_192779_a();
   }

   private Map<ResourceLocation, Advancement.Builder> func_192781_c() {
      String var10000 = I["".length()];
      String var10001 = I[" ".length()];
      String var10002 = I["  ".length()];
      var10001 = I["   ".length()];
      var10000 = I[191 ^ 187];
      var10001 = I[171 ^ 174];
      var10002 = I[39 ^ 33];
      var10001 = I[70 ^ 65];
      var10000 = I[153 ^ 145];
      var10001 = I[140 ^ 133];
      var10002 = I[32 ^ 42];
      var10001 = I[95 ^ 84];
      var10000 = I[124 ^ 112];
      var10001 = I[151 ^ 154];
      var10002 = I[179 ^ 189];
      var10001 = I[151 ^ 152];
      var10000 = I[166 ^ 182];
      var10001 = I[191 ^ 174];
      var10002 = I[140 ^ 158];
      var10001 = I[11 ^ 24];
      if (this.field_192785_d == null) {
         return Maps.newHashMap();
      } else {
         HashMap var1 = Maps.newHashMap();
         this.field_192785_d.mkdirs();
         I[175 ^ 187].length();
         I[160 ^ 181].length();
         I[183 ^ 161].length();
         File var10 = this.field_192785_d;
         String[] var12 = new String[" ".length()];
         I[190 ^ 169].length();
         I[20 ^ 12].length();
         I[41 ^ 48].length();
         var12["".length()] = I[64 ^ 90];
         Iterator var2 = FileUtils.listFiles(var10, var12, (boolean)" ".length()).iterator();

         do {
            if (!var2.hasNext()) {
               return var1;
            }

            File var3 = (File)var2.next();
            String var4 = FilenameUtils.removeExtension(this.field_192785_d.toURI().relativize(var3.toURI()).toString());
            String[] var5 = var4.split(I[107 ^ 112], "  ".length());
            if (var5.length == "  ".length()) {
               label48: {
                  I[112 ^ 108].length();
                  I[121 ^ 100].length();
                  ResourceLocation var6 = new ResourceLocation(var5["".length()], var5[" ".length()]);

                  Logger var11;
                  try {
                     Advancement.Builder var7 = (Advancement.Builder)JsonUtils.gsonDeserialize(field_192783_b, FileUtils.readFileToString(var3, StandardCharsets.UTF_8), Advancement.Builder.class);
                     if (var7 == null) {
                        var11 = field_192782_a;
                        I[69 ^ 91].length();
                        I[156 ^ 131].length();
                        I[32 ^ 0].length();
                        var11.error(I[113 ^ 80] + var6 + I[2 ^ 32] + var3 + I[34 ^ 1]);
                        "".length();
                        if (4 <= 3) {
                           throw null;
                        }
                     } else {
                        var1.put(var6, var7);
                        I[81 ^ 117].length();
                        I[24 ^ 61].length();
                     }
                  } catch (JsonParseException | IllegalArgumentException var8) {
                     var11 = field_192782_a;
                     I[17 ^ 55].length();
                     I[10 ^ 45].length();
                     I[233 ^ 193].length();
                     I[15 ^ 38].length();
                     var11.error(I[123 ^ 81] + var6, var8);
                     this.field_193768_e = (boolean)" ".length();
                     "".length();
                     if (2 == 2) {
                        break label48;
                     }

                     throw null;
                  } catch (IOException var9) {
                     var11 = field_192782_a;
                     I[190 ^ 149].length();
                     I[190 ^ 146].length();
                     var11.error(I[27 ^ 54] + var6 + I[54 ^ 24] + var3, var9);
                     this.field_193768_e = (boolean)" ".length();
                     break label48;
                  }

                  "".length();
                  if (4 < 1) {
                     throw null;
                  }
               }
            }

            "".length();
         } while(0 != 2);

         throw null;
      }
   }

   public Iterable<Advancement> func_192780_b() {
      return field_192784_c.func_192089_c();
   }

   public boolean func_193767_b() {
      return this.field_193768_e;
   }

   public void func_192779_a() {
      this.field_193768_e = (boolean)"".length();
      field_192784_c.func_192087_a();
      Map var1 = this.func_192781_c();
      this.func_192777_a(var1);
      field_192784_c.func_192083_a(var1);
      Iterator var2 = field_192784_c.func_192088_b().iterator();

      do {
         if (!var2.hasNext()) {
            return;
         }

         Advancement var3 = (Advancement)var2.next();
         if (var3.func_192068_c() != null) {
            AdvancementTreeNode.func_192323_a(var3);
         }

         "".length();
      } while(2 == 2);

      throw null;
   }

   private void func_192777_a(Map<ResourceLocation, Advancement.Builder> var1) {
      String var10000 = I[125 ^ 82];
      String var10001 = I[31 ^ 47];
      String var10002 = I[121 ^ 72];
      var10001 = I[63 ^ 13];
      var10000 = I[75 ^ 120];
      var10001 = I[77 ^ 121];
      var10002 = I[111 ^ 90];
      var10001 = I[113 ^ 71];
      var10000 = I[170 ^ 157];
      var10001 = I[53 ^ 13];
      var10002 = I[66 ^ 123];
      var10001 = I[19 ^ 41];
      var10000 = I[100 ^ 95];
      var10001 = I[181 ^ 137];
      var10002 = I[54 ^ 11];
      var10001 = I[38 ^ 24];
      FileSystem var2 = null;

      label269: {
         label264: {
            label263: {
               try {
                  try {
                     URL var3 = AdvancementManager.class.getResource(I[106 ^ 85]);
                     if (var3 == null) {
                        field_192782_a.error(I[103 ^ 58]);
                        this.field_193768_e = (boolean)" ".length();
                        break label264;
                     }

                     URI var4 = var3.toURI();
                     Path var5;
                     Logger var30;
                     if (I[96 ^ 32].equals(var4.getScheme())) {
                        var5 = Paths.get(CraftingManager.class.getResource(I[123 ^ 58]).toURI());
                        "".length();
                        if (4 <= 3) {
                           throw null;
                        }
                     } else {
                        if (!I[77 ^ 15].equals(var4.getScheme())) {
                           var30 = field_192782_a;
                           I[76 ^ 15].length();
                           I[192 ^ 132].length();
                           var30.error(I[245 ^ 176] + var4 + I[36 ^ 98]);
                           this.field_193768_e = (boolean)" ".length();
                           break label263;
                        }

                        var2 = FileSystems.newFileSystem(var4, Collections.emptyMap());
                        var5 = var2.getPath(I[77 ^ 10]);
                     }

                     Iterator var6 = Files.walk(var5).iterator();

                     while(var6.hasNext()) {
                        Path var7 = (Path)var6.next();
                        if (I[47 ^ 103].equals(FilenameUtils.getExtension(var7.toString()))) {
                           Path var8 = var5.relativize(var7);
                           String var9 = FilenameUtils.removeExtension(var8.toString()).replaceAll(I[29 ^ 84], I[38 ^ 108]);
                           I[56 ^ 115].length();
                           ResourceLocation var10 = new ResourceLocation(I[202 ^ 134], var9);
                           if (!var1.containsKey(var10)) {
                              label272: {
                                 BufferedReader var11 = null;

                                 label252: {
                                    label251: {
                                       try {
                                          try {
                                             var11 = Files.newBufferedReader(var7);
                                             Advancement.Builder var12 = (Advancement.Builder)JsonUtils.func_193839_a(field_192783_b, var11, Advancement.Builder.class);
                                             var1.put(var10, var12);
                                             I[109 ^ 32].length();
                                             I[11 ^ 69].length();
                                             I[218 ^ 149].length();
                                             I[35 ^ 115].length();
                                             I[16 ^ 65].length();
                                             break label252;
                                          } catch (JsonParseException var25) {
                                             var30 = field_192782_a;
                                             I[113 ^ 35].length();
                                             I[253 ^ 174].length();
                                             I[17 ^ 69].length();
                                             I[32 ^ 117].length();
                                             var30.error(I[117 ^ 35] + var10, var25);
                                             this.field_193768_e = (boolean)" ".length();
                                          } catch (IOException var26) {
                                             var30 = field_192782_a;
                                             I[108 ^ 59].length();
                                             I[62 ^ 102].length();
                                             var30.error(I[204 ^ 149] + var10 + I[238 ^ 180] + var7, var26);
                                             this.field_193768_e = (boolean)" ".length();
                                             break label251;
                                          }
                                       } catch (Throwable var27) {
                                          IOUtils.closeQuietly(var11);
                                          I[199 ^ 156].length();
                                          I[69 ^ 25].length();
                                          throw var27;
                                       }

                                       IOUtils.closeQuietly(var11);
                                       "".length();
                                       if (-1 >= 2) {
                                          throw null;
                                       }
                                       break label272;
                                    }

                                    IOUtils.closeQuietly(var11);
                                    "".length();
                                    if (1 >= 3) {
                                       throw null;
                                    }
                                    break label272;
                                 }

                                 IOUtils.closeQuietly(var11);
                                 "".length();
                                 if (3 < 3) {
                                    throw null;
                                 }
                              }
                           }
                        }

                        "".length();
                        if (false) {
                           throw null;
                        }
                     }
                  } catch (URISyntaxException | IOException var28) {
                     field_192782_a.error(I[63 ^ 97], var28);
                     this.field_193768_e = (boolean)" ".length();
                     break label269;
                  }
               } catch (Throwable var29) {
                  IOUtils.closeQuietly(var2);
                  I[60 ^ 99].length();
                  I[77 ^ 45].length();
                  I[117 ^ 20].length();
                  I[3 ^ 97].length();
                  throw var29;
               }

               IOUtils.closeQuietly(var2);
               return;
            }

            IOUtils.closeQuietly(var2);
            return;
         }

         IOUtils.closeQuietly(var2);
         "".length();
         if (1 >= 4) {
            throw null;
         }

         return;
      }

      IOUtils.closeQuietly(var2);
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 != 4);

      throw null;
   }

   @Nullable
   public Advancement func_192778_a(ResourceLocation var1) {
      return field_192784_c.func_192084_a(var1);
   }

   private static void I() {
      I = new String[110 ^ 13];
      I["".length()] = I("働撎", "TvJhu");
      I[" ".length()] = I("徽孵", "xuwon");
      I["  ".length()] = I("偤奥", "TIUTz");
      I["   ".length()] = I("帔業", "TzHML");
      I[199 ^ 195] = I("厬僘", "efMBJ");
      I[16 ^ 21] = I("煢棗", "xlcNJ");
      I[179 ^ 181] = I("尮尷", "rMbrl");
      I[172 ^ 171] = I("悳崤", "JdDPr");
      I[144 ^ 152] = I("姯嶂", "ObuUm");
      I[181 ^ 188] = I("廨卶", "ITbAK");
      I[191 ^ 181] = I("巪泡", "DALmg");
      I[49 ^ 58] = I("嵯噖", "BczEg");
      I[115 ^ 127] = I("兌愌", "mFimx");
      I[16 ^ 29] = I("勊嫸", "LrRVL");
      I[137 ^ 135] = I("清傑", "rJTgW");
      I[17 ^ 30] = I("毨挃", "aWrqx");
      I[31 ^ 15] = I("悟炗", "MEtYY");
      I[92 ^ 77] = I("炍挦", "kBtQQ");
      I[191 ^ 173] = I("亂姷", "gvThT");
      I[13 ^ 30] = I("泎媤", "WBnjJ");
      I[183 ^ 163] = I("楹媖", "wtaNz");
      I[105 ^ 124] = I("晭夆吾", "isPaO");
      I[191 ^ 169] = I("楠挛", "eHcml");
      I[215 ^ 192] = I("埦嘼", "BJjfG");
      I[172 ^ 180] = I("愯搨使毖作", "UDmxC");
      I[178 ^ 171] = I("尻仪多匁弐", "Pjzxe");
      I[82 ^ 72] = I(")>: ", "CMUNd");
      I[126 ^ 101] = I("L", "cAoLa");
      I[28 ^ 0] = I("哖匣槀汁", "coytW");
      I[72 ^ 85] = I("巘堶堒唗", "vAQpC");
      I[119 ^ 105] = I("洢泗唕", "fAoZm");
      I[160 ^ 191] = I("喔榃檴屘姳", "SlusW");
      I[36 ^ 4] = I("枖攨淫壉煼", "TEkcV");
      I[115 ^ 82] = I("\u0013\u001e'=\u000e>V&q\u0006?\u00106q\t%\u0002&>\u0007p\u00106'\u000b>\u00127<\u000f>\u0005r", "PqRQj");
      I[187 ^ 153] = I("m\u0007<\u000b'm", "MaNdJ");
      I[108 ^ 79] = I("D\u0016\u0007X*\u0010P\u0007X&\t\u0007\u0000\u0001c\u000b\u0005T\u00166\b\u001b", "dwtxC");
      I[186 ^ 158] = I("厃", "FZHON");
      I[179 ^ 150] = I("擼始淶枫溮", "CLWoG");
      I[34 ^ 4] = I("又", "zaOLQ");
      I[147 ^ 180] = I("厜", "IhUTI");
      I[56 ^ 16] = I("劒渟淉槷", "iqSLc");
      I[80 ^ 121] = I("廬屹县忪擳", "pRyiN");
      I[3 ^ 41] = I(" #\u0002\u0018;\u001e%P\u000e \u0002-\u0002K>\u001f#\u0014\u0002<\u0017b\u0013\u001e!\u0004-\u001dK3\u00144\u0011\u00051\u0015/\u0015\u0005&P", "pBpkR");
      I[86 ^ 125] = I("憁學勽姅", "sJhdY");
      I[13 ^ 33] = I("暐峚毥潣", "VAwHL");
      I[162 ^ 143] = I("\r,%\u0019\u0002 d$U\u0014+\"4U\u0005;0$\u001a\u000bn\"4\u0003\u0007  5\u0018\u0003 7p", "NCPuf");
      I[84 ^ 122] = I("k\u0003\u0004(%k", "KevGH");
      I[191 ^ 144] = I("寐唗", "AfkhB");
      I[94 ^ 110] = I("晇嚍", "aOTux");
      I[118 ^ 71] = I("僙毎", "PDGWX");
      I[165 ^ 151] = I("偭澹", "KKKeI");
      I[16 ^ 35] = I("杙炰", "aBLDO");
      I[188 ^ 136] = I("灕漎", "GnAiB");
      I[4 ^ 49] = I("兛义", "zbvYb");
      I[24 ^ 46] = I("俲彷", "hcKZt");
      I[96 ^ 87] = I("倁擹", "gxWXB");
      I[114 ^ 74] = I("沞捤", "wsnyw");
      I[96 ^ 89] = I("挪榊", "yluUw");
      I[51 ^ 9] = I("朴擋", "zWPGO");
      I[63 ^ 4] = I("变噆", "VKZPa");
      I[30 ^ 34] = I("榄宓", "ktRjt");
      I[173 ^ 144] = I("徲晻", "GDZQm");
      I[11 ^ 53] = I("後炒", "bJxnC");
      I[176 ^ 143] = I("x\u000f\u001e*\u0016#\u001dBw\u001e4\u000f\u001e*\u0016#\u001d\u001f6\u001c#", "WnmYs");
      I[209 ^ 145] = I("/;63", "IRZVB");
      I[200 ^ 137] = I("v\b0\u0017--\u001al\t!7\f \u0016)?\u001dl\u0005,/\b-\u0007-4\f-\u0010;", "YiCdH");
      I[232 ^ 170] = I("=9*", "WXXhd");
      I[82 ^ 17] = I("兎", "kIoSU");
      I[53 ^ 113] = I("桫坹潴搗", "biREH");
      I[36 ^ 97] = I("\u0017\u0014>\u000f12\u0015?\u000e$&Z>\u0019)'\u0017(Z", "BzMzA");
      I[117 ^ 51] = I("A\u0012\u001e\u0000\b\u000f\u0001L\r\u000eA\n\u0005\n\u0015A\u0007\u0000\u0015A\u0003\u0013\u0005\u0015\u0015L\u000f\u0002Y\u0000\u0005\u0010\r\u0017\u0002\u0004\u000b\t\u0017\u0015\u0012FD78(YE", "aflya");
      I[78 ^ 9] = I("b\u0018?\u0016.9\nc\b\"#\u001c/\u0017*+\rc\u0004/;\u0018\"\u0006. \u001c\"\u00118", "MyLeK");
      I[26 ^ 82] = I(">55/", "TFZAM");
      I[57 ^ 112] = I("0\u0006", "lZGxQ");
      I[246 ^ 188] = I("}", "RYaqP");
      I[121 ^ 50] = I("掯", "FlSVp");
      I[76 ^ 0] = I("41$\u001f6+9,\u000e", "YXJzU");
      I[65 ^ 12] = I("升嫽炖溄", "iBnUw");
      I[29 ^ 83] = I("壇兌滽圭應", "hIrpQ");
      I[248 ^ 183] = I("擒", "WVRZy");
      I[205 ^ 157] = I("姭", "KSdbx");
      I[61 ^ 108] = I("極", "SzNEp");
      I[63 ^ 109] = I("了溑煗", "NxZsb");
      I[41 ^ 122] = I("峘", "hYGzK");
      I[147 ^ 199] = I("峲澰曭易", "UgGIx");
      I[151 ^ 194] = I("悮", "RKZcj");
      I[0 ^ 86] = I("\u001e\u0000\u0004!\f \u0006V7\u0017<\u000e\u0004r\t!\u0000\u0012;\u000b)A\u0014'\f\"\u0015[;\u000bn\u0000\u0012$\u0004 \u0002\u0013?\u0000 \u0015V", "NavRe");
      I[11 ^ 92] = I("濊廧", "rreLa");
      I[213 ^ 141] = I("椛嬡炣", "OzuQn");
      I[27 ^ 66] = I("\u0015,8\u0005/8d9I93\")I*25,\u0007(3.(\u0007?v", "VCMiK");
      I[49 ^ 107] = I("V\u0002\u001f\n\u000bV", "vdmef");
      I[213 ^ 142] = I("幫堒敥叉棤", "bpeDZ");
      I[47 ^ 115] = I("扼屪僘", "yExKy");
      I[90 ^ 7] = I("*\u0005\u0005\u0018\u0001\u0007M\u0004T\u0003\u0000\u0004\u0014TK\u0004\t\u0011\u0007\u0016\f\u001e\u0003\u0006\n\u0006\u001e", "ijpte");
      I[46 ^ 112] = I("3\"\u0005\u000e6\u001ej\u0004B5\u00159P\u0003r\u001c$\u0003\u0016r\u001f+P\u0003>\u001cm\u0012\u0017;\u001c9]\u000b<P,\u0014\u00143\u001e.\u0015\u000f7\u001e9P\u0004;\u001c(\u0003", "pMpbR");
      I[248 ^ 167] = I("想", "myIop");
      I[160 ^ 192] = I("暐懪", "MFmwq");
      I[196 ^ 165] = I("呞屜娴", "WzoUX");
      I[51 ^ 81] = I("檌槤出厤", "kmzVJ");
   }

   static {
      I();
      field_192782_a = LogManager.getLogger();
      field_192783_b = (new GsonBuilder()).registerTypeHierarchyAdapter(Advancement.Builder.class, new JsonDeserializer<Advancement.Builder>() {
         // $FF: synthetic field
         private static final String[] I;

         public Advancement.Builder deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
            JsonObject var4 = JsonUtils.getJsonObject(var1, I["".length()]);
            return Advancement.Builder.func_192059_a(var4, var3);
         }

         static {
            I();
         }

         private static String I(String s, String s1) {
            StringBuilder sb = new StringBuilder();
            char[] key = s1.toCharArray();
            int i = "".length();
            char[] var5 = s.toCharArray();
            int var6 = var5.length;
            int var7 = "".length();

            do {
               if (var7 >= var6) {
                  return sb.toString();
               }

               char c = var5[var7];
               sb.append((char)(c ^ key[i % key.length]));
               ++i;
               ++var7;
               "".length();
            } while(true);

            throw null;
         }

         private static void I() {
            I = new String[" ".length()];
            I["".length()] = I(";\u0005\u0004\u001989\u0004\u001f\u001d8.", "ZarxV");
         }
      }).registerTypeAdapter(AdvancementRewards.class, new AdvancementRewards.Deserializer()).registerTypeHierarchyAdapter(ITextComponent.class, new ITextComponent.Serializer()).registerTypeHierarchyAdapter(Style.class, new Style.Serializer()).registerTypeAdapterFactory(new EnumTypeAdapterFactory()).create();
      field_192784_c = new AdvancementList();
   }
}

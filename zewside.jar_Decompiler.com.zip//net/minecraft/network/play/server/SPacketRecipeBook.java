package net.minecraft.network.play.server;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class SPacketRecipeBook implements Packet<INetHandlerPlayClient> {
   // $FF: synthetic field
   private List<IRecipe> field_192596_a;
   // $FF: synthetic field
   private static final String[] I;
   // $FF: synthetic field
   private List<IRecipe> field_193647_c;
   // $FF: synthetic field
   private boolean field_192598_c;
   // $FF: synthetic field
   private SPacketRecipeBook.State field_193646_a;
   // $FF: synthetic field
   private boolean field_192599_d;

   public SPacketRecipeBook(SPacketRecipeBook.State var1, List<IRecipe> var2, List<IRecipe> var3, boolean var4, boolean var5) {
      this.field_193646_a = var1;
      this.field_192596_a = var2;
      this.field_193647_c = var3;
      this.field_192598_c = var4;
      this.field_192599_d = var5;
   }

   private static void I() {
      I = new String[218 ^ 193];
      I["".length()] = I("灹墘尢椯滠", "vdkZH");
      I[" ".length()] = I("搷咰唜慌", "ePAMy");
      I["  ".length()] = I("檃寑撔匞哷", "GtNyL");
      I["   ".length()] = I("晿楰彾", "MfKMi");
      I[150 ^ 146] = I("娼却", "RfICy");
      I[68 ^ 65] = I("凇", "fGnmb");
      I[194 ^ 196] = I("哄幞侗", "QgMvx");
      I[132 ^ 131] = I("勝榝撀", "DvKrH");
      I[51 ^ 59] = I("坵廫瀧", "AAzIX");
      I[128 ^ 137] = I("歅公幥圈彦", "vXVOu");
      I[53 ^ 63] = I("捇杫搅", "aWOix");
      I[51 ^ 56] = I("樬栌墪墦栌", "UheWL");
      I[78 ^ 66] = I("妒命", "ThtCJ");
      I[83 ^ 94] = I("怮只溳", "fuuwk");
      I[37 ^ 43] = I("努", "tZHXi");
      I[181 ^ 186] = I("怘怷楚歉", "Crqtj");
      I[156 ^ 140] = I("惯楧亜嗤", "AszRo");
      I[62 ^ 47] = I("侂潮潿", "zwgxM");
      I[40 ^ 58] = I("号扰噍剌", "JPUmy");
      I[122 ^ 105] = I("氋", "ktmUq");
      I[75 ^ 95] = I("彳忈", "DzgrI");
      I[0 ^ 21] = I("堈嗵炸枙嬂", "tDRys");
      I[163 ^ 181] = I("庺沫殦楇", "elZGb");
      I[19 ^ 4] = I("凷榸樊潾", "MNVPJ");
      I[67 ^ 91] = I("洟沶", "Bbwra");
      I[82 ^ 75] = I("嗴佟", "gPoWc");
      I[169 ^ 179] = I("漊嵠侦", "KwQLc");
   }

   public boolean func_192593_c() {
      return this.field_192598_c;
   }

   public void processPacket(INetHandlerPlayClient var1) {
      var1.func_191980_a(this);
   }

   public SPacketRecipeBook() {
   }

   public boolean func_192594_d() {
      return this.field_192599_d;
   }

   static {
      I();
   }

   public SPacketRecipeBook.State func_194151_e() {
      return this.field_193646_a;
   }

   public void writePacketData(PacketBuffer var1) throws IOException {
      var1.writeEnumValue(this.field_193646_a);
      I[168 ^ 160].length();
      I[149 ^ 156].length();
      I[95 ^ 85].length();
      var1.writeBoolean(this.field_192598_c);
      I[44 ^ 39].length();
      I[1 ^ 13].length();
      var1.writeBoolean(this.field_192599_d);
      I[130 ^ 143].length();
      I[145 ^ 159].length();
      var1.writeVarIntToBuffer(this.field_192596_a.size());
      I[77 ^ 66].length();
      I[64 ^ 80].length();
      I[91 ^ 74].length();
      I[78 ^ 92].length();
      Iterator var2 = this.field_192596_a.iterator();

      IRecipe var3;
      while(var2.hasNext()) {
         var3 = (IRecipe)var2.next();
         var1.writeVarIntToBuffer(CraftingManager.func_193375_a(var3));
         I[94 ^ 77].length();
         I[93 ^ 73].length();
         I[183 ^ 162].length();
         I[118 ^ 96].length();
         "".length();
         if (2 <= 1) {
            throw null;
         }
      }

      if (this.field_193646_a == SPacketRecipeBook.State.INIT) {
         var1.writeVarIntToBuffer(this.field_193647_c.size());
         I[16 ^ 7].length();
         I[151 ^ 143].length();
         var2 = this.field_193647_c.iterator();

         while(var2.hasNext()) {
            var3 = (IRecipe)var2.next();
            var1.writeVarIntToBuffer(CraftingManager.func_193375_a(var3));
            I[82 ^ 75].length();
            I[78 ^ 84].length();
            "".length();
            if (0 >= 1) {
               throw null;
            }
         }
      }

   }

   public List<IRecipe> func_192595_a() {
      return this.field_192596_a;
   }

   private static String I(String s, String s1) {
      StringBuilder sb = new StringBuilder();
      char[] key = s1.toCharArray();
      int i = "".length();
      char[] var5 = s.toCharArray();
      int var6 = var5.length;
      int var7 = "".length();

      do {
         if (var7 >= var6) {
            return sb.toString();
         }

         char c = var5[var7];
         sb.append((char)(c ^ key[i % key.length]));
         ++i;
         ++var7;
         "".length();
      } while(3 >= 2);

      throw null;
   }

   public List<IRecipe> func_193644_b() {
      return this.field_193647_c;
   }

   public void readPacketData(PacketBuffer var1) throws IOException {
      this.field_193646_a = (SPacketRecipeBook.State)var1.readEnumValue(SPacketRecipeBook.State.class);
      this.field_192598_c = var1.readBoolean();
      this.field_192599_d = var1.readBoolean();
      int var2 = var1.readVarIntFromBuffer();
      this.field_192596_a = Lists.newArrayList();
      int var3 = "".length();

      while(var3 < var2) {
         this.field_192596_a.add(CraftingManager.func_193374_a(var1.readVarIntFromBuffer()));
         I["".length()].length();
         I[" ".length()].length();
         I["  ".length()].length();
         I["   ".length()].length();
         I[89 ^ 93].length();
         ++var3;
         "".length();
         if (3 <= 1) {
            throw null;
         }
      }

      if (this.field_193646_a == SPacketRecipeBook.State.INIT) {
         var2 = var1.readVarIntFromBuffer();
         this.field_193647_c = Lists.newArrayList();
         var3 = "".length();

         while(var3 < var2) {
            this.field_193647_c.add(CraftingManager.func_193374_a(var1.readVarIntFromBuffer()));
            I[82 ^ 87].length();
            I[53 ^ 51].length();
            I[135 ^ 128].length();
            ++var3;
            "".length();
            if (2 != 2) {
               throw null;
            }
         }
      }

   }

   public static enum State {
      // $FF: synthetic field
      REMOVE;

      // $FF: synthetic field
      private static final String[] I;
      // $FF: synthetic field
      ADD,
      // $FF: synthetic field
      INIT;

      private static void I() {
         I = new String["   ".length()];
         I["".length()] = I("*\u0003\u001d;", "cMTog");
         I[" ".length()] = I(")(\u0016", "hlRJU");
         I["  ".length()] = I("7#\u0000*\u001c ", "efMeJ");
      }

      private static String I(String s, String s1) {
         StringBuilder sb = new StringBuilder();
         char[] key = s1.toCharArray();
         int i = "".length();
         char[] var5 = s.toCharArray();
         int var6 = var5.length;
         int var7 = "".length();

         do {
            if (var7 >= var6) {
               return sb.toString();
            }

            char c = var5[var7];
            sb.append((char)(c ^ key[i % key.length]));
            ++i;
            ++var7;
            "".length();
         } while(1 >= 1);

         throw null;
      }

      static {
         I();
         INIT = new SPacketRecipeBook.State(I["".length()], "".length());
         ADD = new SPacketRecipeBook.State(I[" ".length()], " ".length());
         REMOVE = new SPacketRecipeBook.State(I["  ".length()], "  ".length());
         SPacketRecipeBook.State[] var10000 = new SPacketRecipeBook.State["   ".length()];
         var10000["".length()] = INIT;
         var10000[" ".length()] = ADD;
         var10000["  ".length()] = REMOVE;
      }
   }
}
